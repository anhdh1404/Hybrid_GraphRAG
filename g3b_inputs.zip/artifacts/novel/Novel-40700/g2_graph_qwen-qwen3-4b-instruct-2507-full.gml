graph [
  node [
    id 0
    label "C:Novel-40700_00000"
    kind "chunk"
    chunk_id "Novel-40700_00000"
  ]
  node [
    id 1
    label "U:Novel-40700_00000#0"
    kind "unit"
    chunk_id "Novel-40700_00000"
    text "The play 'Dandy Dick' was written by Arthur W. Pinero and is a farce produced for the old Court Theatre, part of a series of comedic plays that brought laughter and prosperity to the management of Arthur Cecil and John Clayton."
    community 0
  ]
  node [
    id 2
    label "E:DANDY DICK"
    kind "entity"
    name "DANDY DICK"
    community 0
  ]
  node [
    id 3
    label "E:ARTHUR W. PINERO"
    kind "entity"
    name "ARTHUR W. PINERO"
    community 0
  ]
  node [
    id 4
    label "E:OLD COURT THEATRE"
    kind "entity"
    name "OLD COURT THEATRE"
    community 0
  ]
  node [
    id 5
    label "E:ARTHUR CECIL"
    kind "entity"
    name "ARTHUR CECIL"
    community 0
  ]
  node [
    id 6
    label "E:JOHN CLAYTON"
    kind "entity"
    name "JOHN CLAYTON"
    community 0
  ]
  node [
    id 7
    label "U:Novel-40700_00000#1"
    kind "unit"
    chunk_id "Novel-40700_00000"
    text "'Dandy Dick' is considered the swan-song of the old Court Theatre and of the partnership between Arthur Cecil and John Clayton, as it was the play in which John Clayton was performing when he died."
    community 0
  ]
  node [
    id 8
    label "E:DEATH"
    kind "entity"
    name "DEATH"
    community 0
  ]
  node [
    id 9
    label "E:ARTHUR CECIL AND JOHN CLAYTON PARTNERSHIP"
    kind "entity"
    name "ARTHUR CECIL AND JOHN CLAYTON PARTNERSHIP"
    community 0
  ]
  node [
    id 10
    label "U:Novel-40700_00000#2"
    kind "unit"
    chunk_id "Novel-40700_00000"
    text "The production of 'Dandy Dick' is regarded as a tour de force in terms of performance."
    community 0
  ]
  node [
    id 11
    label "E:TOUR DE FORCE"
    kind "entity"
    name "TOUR DE FORCE"
    community 0
  ]
  node [
    id 12
    label "C:Novel-40700_00001"
    kind "chunk"
    chunk_id "Novel-40700_00001"
  ]
  node [
    id 13
    label "U:Novel-40700_00001#0"
    kind "unit"
    chunk_id "Novel-40700_00001"
    text "The production of 'Dandy Dick' is regarded as a notable achievement. 'The Schoolmistress' had concluded its successful run, and Mr. Pinero was contracted to write its successor by a specific date. Mr. Clayton visited Brighton, where Mr. Pinero was working, to hear him read the two completed acts of the new play. Mr. Pinero expressed dissatisfaction with his work and decided to start a completely new play based on a more promising idea. Due to the urgency of needing a successor to 'The Schoolmistress', Mr. Clayton was convinced by Mr. Pinero's concept of a play centered on a dean who is dignified but becomes undignified after an indiscreet act. Mr. Clayton returned to London with sketches of the required scenes and allowed Mr. Pinero to begin work on the new play. Within a few weeks, and by the time the scenery was ready, the new play was completed, with the character of Noah Topping suggested by the rural constable of a village near Brighton."
    community 4
  ]
  node [
    id 14
    label "E:SCHOOLMISTRESS"
    kind "entity"
    name "SCHOOLMISTRESS"
    community 4
  ]
  node [
    id 15
    label "E:MR. PINERO"
    kind "entity"
    name "MR. PINERO"
    community 4
  ]
  node [
    id 16
    label "E:MR. CLAYTON"
    kind "entity"
    name "MR. CLAYTON"
    community 4
  ]
  node [
    id 17
    label "E:BRIGHTON"
    kind "entity"
    name "BRIGHTON"
    community 4
  ]
  node [
    id 18
    label "E:NEW PLAY"
    kind "entity"
    name "NEW PLAY"
    community 4
  ]
  node [
    id 19
    label "E:DEAN"
    kind "entity"
    name "DEAN"
    community -1
  ]
  node [
    id 20
    label "E:INDISCREET ACT"
    kind "entity"
    name "INDISCREET ACT"
    community 4
  ]
  node [
    id 21
    label "E:UNDIGNIFIED DILEMMA"
    kind "entity"
    name "UNDIGNIFIED DILEMMA"
    community 4
  ]
  node [
    id 22
    label "E:RURAL CONSTABLE"
    kind "entity"
    name "RURAL CONSTABLE"
    community 4
  ]
  node [
    id 23
    label "E:NOAH TOPPING"
    kind "entity"
    name "NOAH TOPPING"
    community 4
  ]
  node [
    id 24
    label "E:SCENIC PREPARATION"
    kind "entity"
    name "SCENIC PREPARATION"
    community 4
  ]
  node [
    id 25
    label "E:HIS WORK"
    kind "entity"
    name "HIS WORK"
    community 4
  ]
  node [
    id 26
    label "E:COMPLETELY NEW PLAY"
    kind "entity"
    name "COMPLETELY NEW PLAY"
    community 4
  ]
  node [
    id 27
    label "E:PLAY CENTERED ON A DEAN WHO IS DIGNIFIED BUT BECOMES UNDIGNIFIED AFTER AN INDISCREET ACT"
    kind "entity"
    name "PLAY CENTERED ON A DEAN WHO IS DIGNIFIED BUT BECOMES UNDIGNIFIED AFTER AN INDISCREET ACT"
    community 4
  ]
  node [
    id 28
    label "E:MR. PINERO'S IDEA"
    kind "entity"
    name "MR. PINERO'S IDEA"
    community 4
  ]
  node [
    id 29
    label "E:SKETCHES OF THE REQUIRED SCENES"
    kind "entity"
    name "SKETCHES OF THE REQUIRED SCENES"
    community 4
  ]
  node [
    id 30
    label "E:BY THE TIME THE SCENERY WAS READY"
    kind "entity"
    name "BY THE TIME THE SCENERY WAS READY"
    community 4
  ]
  node [
    id 31
    label "U:Novel-40700_00001#1"
    kind "unit"
    chunk_id "Novel-40700_00001"
    text "The character of Noah Topping in the new play was inspired by a rural constable from a village adjacent to Brighton. The rural constable proposed the character to Mr. Pinero, who then incorporated it into the play."
    community 4
  ]
  node [
    id 32
    label "E:VILLAGE ADJACENT TO BRIGHTON"
    kind "entity"
    name "VILLAGE ADJACENT TO BRIGHTON"
    community 4
  ]
  node [
    id 33
    label "C:Novel-40700_00002"
    kind "chunk"
    chunk_id "Novel-40700_00002"
  ]
  node [
    id 34
    label "U:Novel-40700_00002#0"
    kind "unit"
    chunk_id "Novel-40700_00002"
    text "The play Dandy Dick was produced at the Royal Court Theatre in Sloane Square, S.W. on Thursday, January 27th, 1887, and received a favorable initial reception, quickly becoming a complete success."
    community 0
  ]
  node [
    id 35
    label "E:ROYAL COURT THEATRE"
    kind "entity"
    name "ROYAL COURT THEATRE"
    community 0
  ]
  node [
    id 36
    label "E:SLOANE SQUARE"
    kind "entity"
    name "SLOANE SQUARE"
    community 0
  ]
  node [
    id 37
    label "E:S.W."
    kind "entity"
    name "S.W."
    community 0
  ]
  node [
    id 38
    label "E:1887-01-27"
    kind "entity"
    name "1887-01-27"
    community 0
  ]
  node [
    id 39
    label "E:THURSDAY"
    kind "entity"
    name "THURSDAY"
    community 0
  ]
  node [
    id 40
    label "E:FAVORABLE INITIAL RECEPTION"
    kind "entity"
    name "FAVORABLE INITIAL RECEPTION"
    community 0
  ]
  node [
    id 41
    label "E:COMPLETE SUCCESS"
    kind "entity"
    name "COMPLETE SUCCESS"
    community 0
  ]
  node [
    id 42
    label "U:Novel-40700_00002#1"
    kind "unit"
    chunk_id "Novel-40700_00002"
    text "The first-night programme for Dandy Dick listed the lessees and managers as Mr. John Clayton and Mr. Arthur Cecil, and specified that the play was an original farce in three acts by A. W. Pinero."
    community 0
  ]
  node [
    id 43
    label "E:MR. JOHN CLAYTON"
    kind "entity"
    name "MR. JOHN CLAYTON"
    community 1
  ]
  node [
    id 44
    label "E:MR. ARTHUR CECIL"
    kind "entity"
    name "MR. ARTHUR CECIL"
    community 0
  ]
  node [
    id 45
    label "E:A. W. PINERO"
    kind "entity"
    name "A. W. PINERO"
    community 0
  ]
  node [
    id 46
    label "E:ORIGINAL FARCE"
    kind "entity"
    name "ORIGINAL FARCE"
    community 0
  ]
  node [
    id 47
    label "E:THREE ACTS"
    kind "entity"
    name "THREE ACTS"
    community 0
  ]
  node [
    id 48
    label "U:Novel-40700_00002#2"
    kind "unit"
    chunk_id "Novel-40700_00002"
    text "The cast of Dandy Dick included The Very Rev. Augustine Jedd, D.D. as Mr. John Clayton (Dean of St. Marvell's), Sir Tristram Mardon, Bart as Mr. Edmund Maurice, Major Tarver (quartered at Mr. F. Kerr), Mr. Darby (Durnstone, near) as Mr. H. Everfield, Blore (Butler at the Deanery) as Mr. Arthur Cecil, Noah Topping (Constable at St. Marvell's) as Mr. W. H. Denny, Hatcham (Sir Tristram's groom) as Mr. W. Lugg, Georgiana Tidman (a widow, the Dean's sister) as Mrs. John Wood, Salome (the Dean's daughters) as Miss Marie Lewes and Miss Norreys, and Hannah Topping (formerly in service at the Deanery) as Miss Laura Linden."
    community 1
  ]
  node [
    id 49
    label "E:VERY REV. AUGUSTINE JEDD"
    kind "entity"
    name "VERY REV. AUGUSTINE JEDD"
    community 1
  ]
  node [
    id 50
    label "E:MR. EDMUND MAURICE"
    kind "entity"
    name "MR. EDMUND MAURICE"
    community 13
  ]
  node [
    id 51
    label "E:MAJOR TARVER"
    kind "entity"
    name "MAJOR TARVER"
    community 1
  ]
  node [
    id 52
    label "E:MR. F. KERR"
    kind "entity"
    name "MR. F. KERR"
    community 1
  ]
  node [
    id 53
    label "E:MR. H. EVERSFIELD"
    kind "entity"
    name "MR. H. EVERSFIELD"
    community 1
  ]
  node [
    id 54
    label "E:BLORE"
    kind "entity"
    name "BLORE"
    community -1
  ]
  node [
    id 55
    label "E:MR. W. H. DENNY"
    kind "entity"
    name "MR. W. H. DENNY"
    community 4
  ]
  node [
    id 56
    label "E:HATCHAM"
    kind "entity"
    name "HATCHAM"
    community 12
  ]
  node [
    id 57
    label "E:MR. W. LUGG"
    kind "entity"
    name "MR. W. LUGG"
    community 12
  ]
  node [
    id 58
    label "E:GEORGIANA TIDMAN"
    kind "entity"
    name "GEORGIANA TIDMAN"
    community 13
  ]
  node [
    id 59
    label "E:MRS. JOHN WOOD"
    kind "entity"
    name "MRS. JOHN WOOD"
    community 0
  ]
  node [
    id 60
    label "E:SALOME"
    kind "entity"
    name "SALOME"
    community -1
  ]
  node [
    id 61
    label "E:MISS MARIE LEWES"
    kind "entity"
    name "MISS MARIE LEWES"
    community 1
  ]
  node [
    id 62
    label "E:MISS NORREYS"
    kind "entity"
    name "MISS NORREYS"
    community 1
  ]
  node [
    id 63
    label "E:MISS LAURA LINDEN"
    kind "entity"
    name "MISS LAURA LINDEN"
    community 1
  ]
  node [
    id 64
    label "E:ST. MARVELL'S"
    kind "entity"
    name "ST. MARVELL'S"
    community 0
  ]
  node [
    id 65
    label "E:DEANERY"
    kind "entity"
    name "DEANERY"
    community 0
  ]
  node [
    id 66
    label "E:DURNSTONE"
    kind "entity"
    name "DURNSTONE"
    community 1
  ]
  node [
    id 67
    label "E:DEAN'S SISTERS"
    kind "entity"
    name "DEAN'S SISTERS"
    community 1
  ]
  node [
    id 68
    label "E:DEAN'S DAUGHTERS"
    kind "entity"
    name "DEAN'S DAUGHTERS"
    community 1
  ]
  node [
    id 69
    label "E:SIR TRISTRAM MARDON"
    kind "entity"
    name "SIR TRISTRAM MARDON"
    community 13
  ]
  node [
    id 70
    label "E:MR. DARBEY"
    kind "entity"
    name "MR. DARBEY"
    community 1
  ]
  node [
    id 71
    label "E:HANNAH TOPPING"
    kind "entity"
    name "HANNAH TOPPING"
    community 1
  ]
  node [
    id 72
    label "U:Novel-40700_00002#3"
    kind "unit"
    chunk_id "Novel-40700_00002"
    text "The play Dandy Dick is set in Act I at the Deanery of St. Marvell's in the morning, in Act II at the same place in the evening, and in Act III the next day."
    community 0
  ]
  node [
    id 73
    label "E:ACT I"
    kind "entity"
    name "ACT I"
    community 0
  ]
  node [
    id 74
    label "E:ACT II"
    kind "entity"
    name "ACT II"
    community 0
  ]
  node [
    id 75
    label "E:ACT III"
    kind "entity"
    name "ACT III"
    community 0
  ]
  node [
    id 76
    label "E:MORNING"
    kind "entity"
    name "MORNING"
    community 0
  ]
  node [
    id 77
    label "E:EVENING"
    kind "entity"
    name "EVENING"
    community 0
  ]
  node [
    id 78
    label "E:NEXT DAY"
    kind "entity"
    name "NEXT DAY"
    community 0
  ]
  node [
    id 79
    label "C:Novel-40700_00003"
    kind "chunk"
    chunk_id "Novel-40700_00003"
  ]
  node [
    id 80
    label "U:Novel-40700_00003#0"
    kind "unit"
    chunk_id "Novel-40700_00003"
    text "At the Deanery, St. Marvell's, the play 'Dandy Dick' was performed 171 times between its first night and the 22nd of July, when the old theatre was demolished and Mr. Clayton transferred the play to Toole's Theatre, where it ran for 75 additional nights."
    community 0
  ]
  node [
    id 81
    label "E:171"
    kind "entity"
    name "171"
    community 0
  ]
  node [
    id 82
    label "E:22D OF JULY"
    kind "entity"
    name "22D OF JULY"
    community 0
  ]
  node [
    id 83
    label "E:OLD THEATRE"
    kind "entity"
    name "OLD THEATRE"
    community 0
  ]
  node [
    id 84
    label "E:TOOLE'S THEATRE"
    kind "entity"
    name "TOOLE'S THEATRE"
    community 0
  ]
  node [
    id 85
    label "E:75"
    kind "entity"
    name "75"
    community 0
  ]
  node [
    id 86
    label "E:171 TIMES"
    kind "entity"
    name "171 TIMES"
    community 0
  ]
  node [
    id 87
    label "E:75 NIGHTS"
    kind "entity"
    name "75 NIGHTS"
    community 0
  ]
  node [
    id 88
    label "U:Novel-40700_00003#1"
    kind "unit"
    chunk_id "Novel-40700_00003"
    text "A company under the auspices of the Court management had already been sent to perform 'Dandy Dick' in the provinces, but when the play was withdrawn from London, Mr. Clayton set out with a company and it was during this tour that he died at Liverpool."
    community 4
  ]
  node [
    id 89
    label "E:COURT MANAGEMENT"
    kind "entity"
    name "COURT MANAGEMENT"
    community 4
  ]
  node [
    id 90
    label "E:PROVINCES"
    kind "entity"
    name "PROVINCES"
    community 4
  ]
  node [
    id 91
    label "E:LIVERPOOL"
    kind "entity"
    name "LIVERPOOL"
    community 4
  ]
  node [
    id 92
    label "E:LONDON"
    kind "entity"
    name "LONDON"
    community 4
  ]
  node [
    id 93
    label "U:Novel-40700_00003#2"
    kind "unit"
    chunk_id "Novel-40700_00003"
    text "In America, Mr. Daly produced 'Dandy Dick' with Miss Ada Rehan in the role of Mrs. John Wood, but the play achieved only limited success; in Australia, the reception was enthusiastic and the play ran for an unusual length of time in both Melbourne and Sydney."
    community 0
  ]
  node [
    id 94
    label "E:MR. DALLY"
    kind "entity"
    name "MR. DALLY"
    community 0
  ]
  node [
    id 95
    label "E:MISS ADA REHAN"
    kind "entity"
    name "MISS ADA REHAN"
    community 0
  ]
  node [
    id 96
    label "E:AMERICA"
    kind "entity"
    name "AMERICA"
    community 0
  ]
  node [
    id 97
    label "E:AUSTRALIA"
    kind "entity"
    name "AUSTRALIA"
    community 0
  ]
  node [
    id 98
    label "E:MELBOURNE"
    kind "entity"
    name "MELBOURNE"
    community 0
  ]
  node [
    id 99
    label "E:SYDNEY"
    kind "entity"
    name "SYDNEY"
    community 0
  ]
  node [
    id 100
    label "U:Novel-40700_00003#3"
    kind "unit"
    chunk_id "Novel-40700_00003"
    text "In the character of the Dean, Mr. G. W. performed."
    community 0
  ]
  node [
    id 101
    label "E:MR. G. W."
    kind "entity"
    name "MR. G. W."
    community 0
  ]
  node [
    id 102
    label "C:Novel-40700_00004"
    kind "chunk"
    chunk_id "Novel-40700_00004"
  ]
  node [
    id 103
    label "U:Novel-40700_00004#0"
    kind "unit"
    chunk_id "Novel-40700_00004"
    text "Mr. G. W. Anson played the role of the Dean and achieved perhaps his greatest success in Australia, while Mr. Robert Brough portrayed the policeman. The scene is set in the morning-room of the Deanery of St. Marvells, a bright spring morning with a large arched opening to the library and a deeply-recessed window facing the garden, creating an atmosphere of comfort and serenity. SALOME, a tall, handsome, dark girl of about twenty-three, sits with her elbows on her knees, staring into vacancy. SHEBA, a fair little girl of about seventeen wearing short petticoats, shares her despondency and lies prostrate on the settee. SALOME exclaims 'Oh! oh my! oh my! oh my!' and SHEBA responds with 'Oh, my gracious goodness, goodness gracious me!' as both walk about excitedly. SALOME says there's only one terrible word for it&#8212;'it's a fix!' and SHEBA replies it's worse than that&#8212;'it's a scrape!' and asks how they were led into it. SALOME replies 'How did we get led into it?' and asks SHEBA to say 'Halves, Sheba, please.'"
    community 21
  ]
  node [
    id 104
    label "E:MR. G. W. ANSON"
    kind "entity"
    name "MR. G. W. ANSON"
    community 21
  ]
  node [
    id 105
    label "E:MR. ROBERT BROUGH"
    kind "entity"
    name "MR. ROBERT BROUGH"
    community 21
  ]
  node [
    id 106
    label "E:POLICE OFFICER"
    kind "entity"
    name "POLICE OFFICER"
    community 21
  ]
  node [
    id 107
    label "E:SHEBA"
    kind "entity"
    name "SHEBA"
    community -1
  ]
  node [
    id 108
    label "E:ST. MARVELLS DEANERY"
    kind "entity"
    name "ST. MARVELLS DEANERY"
    community 21
  ]
  node [
    id 109
    label "E:MORNING ROOM"
    kind "entity"
    name "MORNING ROOM"
    community 21
  ]
  node [
    id 110
    label "E:LIBRARY"
    kind "entity"
    name "LIBRARY"
    community 19
  ]
  node [
    id 111
    label "E:GARDEN"
    kind "entity"
    name "GARDEN"
    community 16
  ]
  node [
    id 112
    label "E:SPRING"
    kind "entity"
    name "SPRING"
    community 21
  ]
  node [
    id 113
    label "E:COMFORT"
    kind "entity"
    name "COMFORT"
    community 21
  ]
  node [
    id 114
    label "E:SERENITY"
    kind "entity"
    name "SERENITY"
    community 21
  ]
  node [
    id 115
    label "E:TALL HANDSOME DARK GIRL"
    kind "entity"
    name "TALL HANDSOME DARK GIRL"
    community 21
  ]
  node [
    id 116
    label "E:FAIR LITTLE GIRL"
    kind "entity"
    name "FAIR LITTLE GIRL"
    community 21
  ]
  node [
    id 117
    label "E:ABOUT TWENTY-THREE"
    kind "entity"
    name "ABOUT TWENTY-THREE"
    community 21
  ]
  node [
    id 118
    label "E:ABOUT SEVENTEEN"
    kind "entity"
    name "ABOUT SEVENTEEN"
    community 21
  ]
  node [
    id 119
    label "E:SHORT PETTICOATS"
    kind "entity"
    name "SHORT PETTICOATS"
    community 21
  ]
  node [
    id 120
    label "E:VACUITY"
    kind "entity"
    name "VACUITY"
    community 21
  ]
  node [
    id 121
    label "E:PROSTRATE"
    kind "entity"
    name "PROSTRATE"
    community 21
  ]
  node [
    id 122
    label "E:SETTEE"
    kind "entity"
    name "SETTEE"
    community 3
  ]
  node [
    id 123
    label "E:OH OH MY"
    kind "entity"
    name "OH OH MY"
    community 21
  ]
  node [
    id 124
    label "E:GOODNESS GRACIOUS ME"
    kind "entity"
    name "GOODNESS GRACIOUS ME"
    community 21
  ]
  node [
    id 125
    label "E:FIX"
    kind "entity"
    name "FIX"
    community 21
  ]
  node [
    id 126
    label "E:SCRAPE"
    kind "entity"
    name "SCRAPE"
    community 21
  ]
  node [
    id 127
    label "E:LED INTO IT"
    kind "entity"
    name "LED INTO IT"
    community 21
  ]
  node [
    id 128
    label "E:HALVES"
    kind "entity"
    name "HALVES"
    community 21
  ]
  node [
    id 129
    label "E:ARCHED OPENING"
    kind "entity"
    name "ARCHED OPENING"
    community 21
  ]
  node [
    id 130
    label "E:DEEPLY RECESSED WINDOW"
    kind "entity"
    name "DEEPLY RECESSED WINDOW"
    community 21
  ]
  node [
    id 131
    label "E:TWENTY-THREE"
    kind "entity"
    name "TWENTY-THREE"
    community 21
  ]
  node [
    id 132
    label "E:SEVENTEEN"
    kind "entity"
    name "SEVENTEEN"
    community 21
  ]
  node [
    id 133
    label "C:Novel-40700_00005"
    kind "chunk"
    chunk_id "Novel-40700_00005"
  ]
  node [
    id 134
    label "U:Novel-40700_00005#0"
    kind "unit"
    chunk_id "Novel-40700_00005"
    text "Salome asks how they got led into attending the Fancy Dress Masked Ball at Durnstone, which is promoted by the Officers of the Hussars. She believes the young gentleman who has impressed Sheba is only a lieutenant, not an officer, despite calling himself one. Sheba insists Mr. Darbey is certainly an officer, a small one, and accuses Salome of being disrespectful. Salome agrees that appearing at the Durnstone Athenaeum on the arms of Major Tarver and Mr. Darbey, unknown to Papa, will make them equally wicked, and expresses regret over the decision. Sheba says they are not yet wrong, only going to be wrong, and that she will repent to-morrow, while Salome says she repents now upon seeing the cost of the fancy dresses."
    community 5
  ]
  node [
    id 135
    label "E:MR. DARBEDY"
    kind "entity"
    name "MR. DARBEDY"
    community 5
  ]
  node [
    id 136
    label "E:OFFICERS OF THE HUSKARS"
    kind "entity"
    name "OFFICERS OF THE HUSKARS"
    community 5
  ]
  node [
    id 137
    label "E:FANCY DRESS MASKED BALL"
    kind "entity"
    name "FANCY DRESS MASKED BALL"
    community 5
  ]
  node [
    id 138
    label "E:DURNSTONE ATHENAUM"
    kind "entity"
    name "DURNSTONE ATHENAUM"
    community 11
  ]
  node [
    id 139
    label "E:DEAR PAPA"
    kind "entity"
    name "DEAR PAPA"
    community 5
  ]
  node [
    id 140
    label "E:LIEUTENANT"
    kind "entity"
    name "LIEUTENANT"
    community 5
  ]
  node [
    id 141
    label "E:ACCOUNT FOR FANCY DRESSES"
    kind "entity"
    name "ACCOUNT FOR FANCY DRESSES"
    community 5
  ]
  node [
    id 142
    label "E:YOUNG GENTLEMAN"
    kind "entity"
    name "YOUNG GENTLEMAN"
    community 5
  ]
  node [
    id 143
    label "E:OFFICER"
    kind "entity"
    name "OFFICER"
    community 5
  ]
  node [
    id 144
    label "E:SMALL OFFICER"
    kind "entity"
    name "SMALL OFFICER"
    community 5
  ]
  node [
    id 145
    label "E:YOUNG GENTLEMAN IS NOT AN OFFICER"
    kind "entity"
    name "YOUNG GENTLEMAN IS NOT AN OFFICER"
    community 5
  ]
  node [
    id 146
    label "E:SALOME OF BEING DISRESPECTFUL"
    kind "entity"
    name "SALOME OF BEING DISRESPECTFUL"
    community 5
  ]
  node [
    id 147
    label "E:APPEARING AT DURNSTONE ATHENAUM WILL MAKE THEM EQUALLY WICKED"
    kind "entity"
    name "APPEARING AT DURNSTONE ATHENAUM WILL MAKE THEM EQUALLY WICKED"
    community 5
  ]
  node [
    id 148
    label "E:THEY ARE ONLY GOING TO BE WRONG"
    kind "entity"
    name "THEY ARE ONLY GOING TO BE WRONG"
    community 5
  ]
  node [
    id 149
    label "E:TO-MORROW"
    kind "entity"
    name "TO-MORROW"
    community 5
  ]
  node [
    id 150
    label "E:AFTER SEEING THE ACCOUNT FOR THE FANCY DRESSES"
    kind "entity"
    name "AFTER SEEING THE ACCOUNT FOR THE FANCY DRESSES"
    community 5
  ]
  node [
    id 151
    label "U:Novel-40700_00005#1"
    kind "unit"
    chunk_id "Novel-40700_00005"
    text "Salome takes an envelope from her pocket and almost cries, saying that Sheba would repent if she had seen the account for the fancy dresses, implying the cost is high and makes the plan seem unreasonable."
    community 5
  ]
  node [
    id 152
    label "E:IF SHE HAD SEEN THE ACCOUNT FOR THE FANCY DRESSES"
    kind "entity"
    name "IF SHE HAD SEEN THE ACCOUNT FOR THE FANCY DRESSES"
    community 5
  ]
  node [
    id 153
    label "C:Novel-40700_00006"
    kind "chunk"
    chunk_id "Novel-40700_00006"
  ]
  node [
    id 154
    label "U:Novel-40700_00006#0"
    kind "unit"
    chunk_id "Novel-40700_00006"
    text "Salome confirms that the Major enclosed the dresses' patterns to her this morning. Sheba is shocked to learn that Major Tarver may have shown the patterns to the costumier. Salome explains that she sealed the patterns and marked them 'To be opened only by a lady' to prevent the Major from viewing them. Major Tarver requested to pay for the dresses, but Salome refused, and he became unhappy until he agreed to yield to a lady. Salome reads from the letter: 'Debtor to Lewis Isaacs, Costumier to the Queen, Bow Street. One gown--period French Revolution, 1798--Fifteen guineas! Trimmings, linings, buttons, frillings--Seven guineas!' Sheba is deeply affected and sinks to her knees upon hearing the cost."
    community 17
  ]
  node [
    id 155
    label "E:BROWN PAPER PATTERNS"
    kind "entity"
    name "BROWN PAPER PATTERNS"
    community 17
  ]
  node [
    id 156
    label "E:COSTUMIER"
    kind "entity"
    name "COSTUMIER"
    community 17
  ]
  node [
    id 157
    label "E:LEWIS ISAACS"
    kind "entity"
    name "LEWIS ISAACS"
    community 17
  ]
  node [
    id 158
    label "E:QUEEN"
    kind "entity"
    name "QUEEN"
    community 17
  ]
  node [
    id 159
    label "E:BOW STREET"
    kind "entity"
    name "BOW STREET"
    community 17
  ]
  node [
    id 160
    label "E:ONE GOWN"
    kind "entity"
    name "ONE GOWN"
    community 17
  ]
  node [
    id 161
    label "E:FRENCH REVOLUTION"
    kind "entity"
    name "FRENCH REVOLUTION"
    community 17
  ]
  node [
    id 162
    label "E:1798"
    kind "entity"
    name "1798"
    community 17
  ]
  node [
    id 163
    label "E:FIFTEEN GUINEAS"
    kind "entity"
    name "FIFTEEN GUINEAS"
    community 17
  ]
  node [
    id 164
    label "E:SEVEN GUINEAS"
    kind "entity"
    name "SEVEN GUINEAS"
    community 17
  ]
  node [
    id 165
    label "E:DRESSES MADE IN LONDON"
    kind "entity"
    name "DRESSES MADE IN LONDON"
    community 17
  ]
  node [
    id 166
    label "E:TO BE OPENED ONLY BY A LADY"
    kind "entity"
    name "TO BE OPENED ONLY BY A LADY"
    community 17
  ]
  node [
    id 167
    label "E:DRESSES"
    kind "entity"
    name "DRESSES"
    community 17
  ]
  node [
    id 168
    label "E:MAJOR TARVER PAYING FOR DRESSES"
    kind "entity"
    name "MAJOR TARVER PAYING FOR DRESSES"
    community 17
  ]
  node [
    id 169
    label "E:LADY"
    kind "entity"
    name "LADY"
    community 16
  ]
  node [
    id 170
    label "E:BROWN PAPER PATTERNS TO THE COSTUMIER"
    kind "entity"
    name "BROWN PAPER PATTERNS TO THE COSTUMIER"
    community 17
  ]
  node [
    id 171
    label "E:PERIOD FRENCH REVOLUTION, 1798"
    kind "entity"
    name "PERIOD FRENCH REVOLUTION, 1798"
    community 17
  ]
  node [
    id 172
    label "E:TRIMMINGS, LININGS, BUTTONS, FRILLINGS"
    kind "entity"
    name "TRIMMINGS, LININGS, BUTTONS, FRILLINGS"
    community 17
  ]
  node [
    id 173
    label "U:Novel-40700_00006#1"
    kind "unit"
    chunk_id "Novel-40700_00006"
    text "Salome reads the letter from Major Tarver to the costumier, which specifies the cost of the gown and its trimmings. Sheba reacts with hysterical distress upon hearing the amount and the details of the order."
    community 17
  ]
  node [
    id 174
    label "E:LETTER FROM MAJOR TARVER"
    kind "entity"
    name "LETTER FROM MAJOR TARVER"
    community 17
  ]
  node [
    id 175
    label "E:COST OF THE GOWN"
    kind "entity"
    name "COST OF THE GOWN"
    community 17
  ]
  node [
    id 176
    label "C:Novel-40700_00007"
    kind "chunk"
    chunk_id "Novel-40700_00007"
  ]
  node [
    id 177
    label "U:Novel-40700_00007#0"
    kind "unit"
    chunk_id "Novel-40700_00007"
    text "Sheba and Salome argue over a dress bill, with Sheba claiming the dress costs less than Salome's. Salome reads from a listing: one skirt and bodice for a flower girl at ten guineas, trimmings and linings at five guineas, extras at two guineas, totaling forty pounds nineteen, with terms of cash. Sheba says the amount is less than Salome's and expresses regret over their lack of charity in town. Salome says Papa hasn't paid their dressmaker's bill and is pressed for money. Sheba suggests they get Papa in a good humor and ask him for money, noting he knows they haven't been charitable for a long time."
    community 2
  ]
  node [
    id 178
    label "E:ONE SKIRT AND BODICE"
    kind "entity"
    name "ONE SKIRT AND BODICE"
    community 2
  ]
  node [
    id 179
    label "E:FLOWER GIRL"
    kind "entity"
    name "FLOWER GIRL"
    community 2
  ]
  node [
    id 180
    label "E:TEN GUINEAS"
    kind "entity"
    name "TEN GUINEAS"
    community 2
  ]
  node [
    id 181
    label "E:TRIMMINGS"
    kind "entity"
    name "TRIMMINGS"
    community 2
  ]
  node [
    id 182
    label "E:LININGS"
    kind "entity"
    name "LININGS"
    community 2
  ]
  node [
    id 183
    label "E:BUTTONS"
    kind "entity"
    name "BUTTONS"
    community 2
  ]
  node [
    id 184
    label "E:FRILLINGS"
    kind "entity"
    name "FRILLINGS"
    community 2
  ]
  node [
    id 185
    label "E:FIVE GUINEAS"
    kind "entity"
    name "FIVE GUINEAS"
    community 2
  ]
  node [
    id 186
    label "E:EXTRAS"
    kind "entity"
    name "EXTRAS"
    community 2
  ]
  node [
    id 187
    label "E:TWO GUINEAS"
    kind "entity"
    name "TWO GUINEAS"
    community 2
  ]
  node [
    id 188
    label "E:FOURTY POUNDS NINETEEN"
    kind "entity"
    name "FOURTY POUNDS NINETEEN"
    community 2
  ]
  node [
    id 189
    label "E:LADIES OWN BROWN PAPER PATTERNS"
    kind "entity"
    name "LADIES OWN BROWN PAPER PATTERNS"
    community 2
  ]
  node [
    id 190
    label "E:CASH"
    kind "entity"
    name "CASH"
    community 2
  ]
  node [
    id 191
    label "E:PAPA"
    kind "entity"
    name "PAPA"
    community 15
  ]
  node [
    id 192
    label "E:DRESSMAKER"
    kind "entity"
    name "DRESSMAKER"
    community 2
  ]
  node [
    id 193
    label "E:CHARITY"
    kind "entity"
    name "CHARITY"
    community 2
  ]
  node [
    id 194
    label "E:GOOD HUMOR"
    kind "entity"
    name "GOOD HUMOR"
    community 2
  ]
  node [
    id 195
    label "E:PRESENT OF MONEY"
    kind "entity"
    name "PRESENT OF MONEY"
    community 2
  ]
  node [
    id 196
    label "E:PRESSURE FOR MONEY"
    kind "entity"
    name "PRESSURE FOR MONEY"
    community 2
  ]
  node [
    id 197
    label "E:PAPA KNOWS THEY HAVEN'T BEEN CHARITABLE FOR A LONG TIME"
    kind "entity"
    name "PAPA KNOWS THEY HAVEN'T BEEN CHARITABLE FOR A LONG TIME"
    community 2
  ]
  node [
    id 198
    label "E:PAPA HASN'T PAID THEIR DRESSMAKER'S BILL"
    kind "entity"
    name "PAPA HASN'T PAID THEIR DRESSMAKER'S BILL"
    community 2
  ]
  node [
    id 199
    label "E:PAPA IS PRESSED FOR MONEY"
    kind "entity"
    name "PAPA IS PRESSED FOR MONEY"
    community 2
  ]
  node [
    id 200
    label "E:GET PAPA IN A GOOD HUMOR"
    kind "entity"
    name "GET PAPA IN A GOOD HUMOR"
    community 2
  ]
  node [
    id 201
    label "E:ASK PAPA FOR A PRESENT OF MONEY"
    kind "entity"
    name "ASK PAPA FOR A PRESENT OF MONEY"
    community 2
  ]
  node [
    id 202
    label "E:THEY HAVEN'T BEEN CHARITABLE IN THE TOWN FOR EVER SO LONG"
    kind "entity"
    name "THEY HAVEN'T BEEN CHARITABLE IN THE TOWN FOR EVER SO LONG"
    community 2
  ]
  node [
    id 203
    label "U:Novel-40700_00007#1"
    kind "unit"
    chunk_id "Novel-40700_00007"
    text "Sheba and Salome embrace after the argument, with Salome exclaiming 'Oh, Sheba!' and Sheba responding 'Salome!' They both express disbelief about the amount of money required, with Salome saying her heart weighs twenty and asking what they should do. Sheba jokes that if they were older, they would write notes to Papa and commit suicide, but Salome says that is out of the question due to their upbringing. Sheba then proposes they be brave and wear the dresses, and Salome agrees but worries about the cost."
    community 2
  ]
  node [
    id 204
    label "E:HEART"
    kind "entity"
    name "HEART"
    community 2
  ]
  node [
    id 205
    label "E:TWENTY"
    kind "entity"
    name "TWENTY"
    community 2
  ]
  node [
    id 206
    label "E:WHAT SHALL WE DO"
    kind "entity"
    name "WHAT SHALL WE DO"
    community 2
  ]
  node [
    id 207
    label "E:BRAVE WOMEN"
    kind "entity"
    name "BRAVE WOMEN"
    community 2
  ]
  node [
    id 208
    label "E:WEAR THE DRESSES"
    kind "entity"
    name "WEAR THE DRESSES"
    community 2
  ]
  node [
    id 209
    label "E:BILL"
    kind "entity"
    name "BILL"
    community 2
  ]
  node [
    id 210
    label "E:UPBRINGING"
    kind "entity"
    name "UPBRINGING"
    community 2
  ]
  node [
    id 211
    label "E:COMMIT SUICIDE"
    kind "entity"
    name "COMMIT SUICIDE"
    community 2
  ]
  node [
    id 212
    label "E:COAX PAPA"
    kind "entity"
    name "COAX PAPA"
    community 2
  ]
  node [
    id 213
    label "E:HER HEART WEIGHS TWENTY"
    kind "entity"
    name "HER HEART WEIGHS TWENTY"
    community 2
  ]
  node [
    id 214
    label "E:WHAT THEY SHOULD DO"
    kind "entity"
    name "WHAT THEY SHOULD DO"
    community 2
  ]
  node [
    id 215
    label "E:THEY WOULD WRITE NOTES TO PAPA AND COMMIT SUICIDE"
    kind "entity"
    name "THEY WOULD WRITE NOTES TO PAPA AND COMMIT SUICIDE"
    community 2
  ]
  node [
    id 216
    label "E:THAT COMMITTING SUICIDE IS OUT OF THE QUESTION"
    kind "entity"
    name "THAT COMMITTING SUICIDE IS OUT OF THE QUESTION"
    community 2
  ]
  node [
    id 217
    label "E:BE BRAVE WOMEN AND WEAR THE DRESSES"
    kind "entity"
    name "BE BRAVE WOMEN AND WEAR THE DRESSES"
    community 2
  ]
  node [
    id 218
    label "C:Novel-40700_00008"
    kind "chunk"
    chunk_id "Novel-40700_00008"
  ]
  node [
    id 219
    label "U:Novel-40700_00008#0"
    kind "unit"
    chunk_id "Novel-40700_00008"
    text "He hasn't paid the proper dressmaker's bill yet, and the speaker is sure he is pressed for money. Sheba says they can't help that when they themselves are pressed for money&#8212;poor dear Papa. Salome suggests that if poor Papa refuses to give them a present, they must play the piano when he is at work on his Concordance&#8212;poor dear Papa. They agree not to wrong poor Papa in advance and instead decide to think about how nice they will look. Sheba says she will definitely do it, and Salome says she will too. Salome adds that stealing out of the house with Major Tarver when poor dear Papa has gone to bed would make Gerald Tarver die for her. Sheba says so would Nugent Darbey, and adds that she is not old enough to know better. Salome replies that Sheba is not much younger than she is. Sheba says indeed, Salome, and then asks why she is kept in short skirts. Salome says she can't lengthen Sheba's skirts until she is married. Blore, the butler, enters benignly and says the two soldier gentlemen have just ridden up, Miss Salome. The girls clutch each other's hands. Salome asks if he means Major Tarver. Sheba confirms that Mr. Darbey is also there."
    community 18
  ]
  node [
    id 220
    label "E:PROPER DRESSMAKER'S BILL"
    kind "entity"
    name "PROPER DRESSMAKER'S BILL"
    community 18
  ]
  node [
    id 221
    label "E:POOR DEAR PAPA"
    kind "entity"
    name "POOR DEAR PAPA"
    community 18
  ]
  node [
    id 222
    label "E:CONCORDANCE"
    kind "entity"
    name "CONCORDANCE"
    community 18
  ]
  node [
    id 223
    label "E:SHORT SKIRTS"
    kind "entity"
    name "SHORT SKIRTS"
    community 18
  ]
  node [
    id 224
    label "E:MARRIED"
    kind "entity"
    name "MARRIED"
    community 18
  ]
  node [
    id 225
    label "E:TWO SOLDIER GENTLEMEN"
    kind "entity"
    name "TWO SOLDIER GENTLEMEN"
    community 18
  ]
  node [
    id 226
    label "E:RIDING UP"
    kind "entity"
    name "RIDING UP"
    community 18
  ]
  node [
    id 227
    label "E:GIRLS"
    kind "entity"
    name "GIRLS"
    community 18
  ]
  node [
    id 228
    label "E:CLUTCH EACH OTHER'S HANDS"
    kind "entity"
    name "CLUTCH EACH OTHER'S HANDS"
    community 18
  ]
  node [
    id 229
    label "E:THEY ARE PRESSED FOR MONEY"
    kind "entity"
    name "THEY ARE PRESSED FOR MONEY"
    community 18
  ]
  node [
    id 230
    label "E:POOR DEAR PAPA REFUSES TO GIVE THEM A PRESENT"
    kind "entity"
    name "POOR DEAR PAPA REFUSES TO GIVE THEM A PRESENT"
    community 18
  ]
  node [
    id 231
    label "E:PAPA IS AT WORK ON HIS CONCORDANCE"
    kind "entity"
    name "PAPA IS AT WORK ON HIS CONCORDANCE"
    community 18
  ]
  node [
    id 232
    label "E:HOW NICE THEY WILL LOOK"
    kind "entity"
    name "HOW NICE THEY WILL LOOK"
    community 18
  ]
  node [
    id 233
    label "E:PLAYING THE PIANO"
    kind "entity"
    name "PLAYING THE PIANO"
    community 18
  ]
  node [
    id 234
    label "E:STEALING OUT OF THE HOUSE WITH MAJOR TARVER"
    kind "entity"
    name "STEALING OUT OF THE HOUSE WITH MAJOR TARVER"
    community 18
  ]
  node [
    id 235
    label "E:SHE IS KEPT IN SHORT SKIRTS"
    kind "entity"
    name "SHE IS KEPT IN SHORT SKIRTS"
    community 18
  ]
  node [
    id 236
    label "E:SHEBA'S SKIRTS UNTIL SHE IS MARRIED"
    kind "entity"
    name "SHEBA'S SKIRTS UNTIL SHE IS MARRIED"
    community 18
  ]
  node [
    id 237
    label "E:ROOM"
    kind "entity"
    name "ROOM"
    community 25
  ]
  node [
    id 238
    label "E:MISS SALOME"
    kind "entity"
    name "MISS SALOME"
    community 18
  ]
  node [
    id 239
    label "E:AFTER BLORE'S ANNOUNCEMENT"
    kind "entity"
    name "AFTER BLORE'S ANNOUNCEMENT"
    community 18
  ]
  node [
    id 240
    label "E:MR. DARBEY IS THERE"
    kind "entity"
    name "MR. DARBEY IS THERE"
    community 18
  ]
  node [
    id 241
    label "U:Novel-40700_00008#1"
    kind "unit"
    chunk_id "Novel-40700_00008"
    text "Blore, the butler, enters benignly and says the two soldier gentlemen have just ridden up, Miss Salome. The girls clutch each other's hands. Salome asks if he means Major Tarver. Sheba confirms that Mr. Darbey is also there."
    community 18
  ]
  node [
    id 242
    label "E:BUTLER"
    kind "entity"
    name "BUTLER"
    community 18
  ]
  node [
    id 243
    label "C:Novel-40700_00009"
    kind "chunk"
    chunk_id "Novel-40700_00009"
  ]
  node [
    id 244
    label "U:Novel-40700_00009#0"
    kind "unit"
    chunk_id "Novel-40700_00009"
    text "The girls clutch each other's hands. Salome asks if they mean Major Tarver, and Sheba adds Mr. Darbey, stating they have called to inquire after poor Papa. Salome expresses surprise at the mention of Papa, and Blore offers to show them in, to which Sheba agrees and instructs him to hang his h's on the hat-stand. Blore laughs sweetly at Sheba and playfully shakes his fingers at her, then exits behind their backs, saying 'Ussies!' and leaving the room. Salome asks if Sheba is all right, and Sheba confirms she is. Salome then remarks that Gerald Tarver dismounts well, and Sheba jokes that he left his liver in India, to which Salome replies that only part of it was left and that he gave the part to his Queen. Sheba then pretends to sit in an artificial attitude and asks where they will be, to which Salome responds that she will perform her voice. Sheba agrees and they decide to run away and come in unconsciously. They run off through the library, and Blore enters with Major Tarver and Mr. Darbey, who are both dressed in regimentals."
    community 1
  ]
  node [
    id 245
    label "E:POOR PAPA"
    kind "entity"
    name "POOR PAPA"
    community 21
  ]
  node [
    id 246
    label "E:GERALD TARVER"
    kind "entity"
    name "GERALD TARVER"
    community 1
  ]
  node [
    id 247
    label "E:HAT-STAND"
    kind "entity"
    name "HAT-STAND"
    community 1
  ]
  node [
    id 248
    label "E:REGIMENTALS"
    kind "entity"
    name "REGIMENTALS"
    community 1
  ]
  node [
    id 249
    label "E:USSIES"
    kind "entity"
    name "USSIES"
    community 1
  ]
  node [
    id 250
    label "C:Novel-40700_00010"
    kind "chunk"
    chunk_id "Novel-40700_00010"
  ]
  node [
    id 251
    label "U:Novel-40700_00010#0"
    kind "unit"
    chunk_id "Novel-40700_00010"
    text "BLORE shows in MAJOR TARVER and MR. DARBEY, who are both dressed in regimentals. MAJOR TARVER is a middle-aged, tall, angular officer with a thin face, yellow complexion, and red eyes, and he alternates between great excitement and depression. MR. DARBEY is a boy with a pompous and patronizing manner."
    community 1
  ]
  node [
    id 252
    label "E:THIN FACE"
    kind "entity"
    name "THIN FACE"
    community 1
  ]
  node [
    id 253
    label "E:YELLOW COMPLEXION"
    kind "entity"
    name "YELLOW COMPLEXION"
    community 1
  ]
  node [
    id 254
    label "E:RED EYES"
    kind "entity"
    name "RED EYES"
    community 1
  ]
  node [
    id 255
    label "E:MIDDLE-AGED"
    kind "entity"
    name "MIDDLE-AGED"
    community 1
  ]
  node [
    id 256
    label "E:TALL"
    kind "entity"
    name "TALL"
    community 1
  ]
  node [
    id 257
    label "E:ANGULAR"
    kind "entity"
    name "ANGULAR"
    community 1
  ]
  node [
    id 258
    label "E:BOY"
    kind "entity"
    name "BOY"
    community 3
  ]
  node [
    id 259
    label "E:POMPOUS"
    kind "entity"
    name "POMPOUS"
    community 1
  ]
  node [
    id 260
    label "E:PATRONIZING"
    kind "entity"
    name "PATRONIZING"
    community 1
  ]
  node [
    id 261
    label "E:POMPOUS MANNER"
    kind "entity"
    name "POMPOUS MANNER"
    community 1
  ]
  node [
    id 262
    label "E:PATRONIZING MANNER"
    kind "entity"
    name "PATRONIZING MANNER"
    community 1
  ]
  node [
    id 263
    label "U:Novel-40700_00010#1"
    kind "unit"
    chunk_id "Novel-40700_00010"
    text "DARBEY says the Dean is out of the way. BLORE confirms that the Dean is out of the way. TARVER asks how the Dean is, and suggests perhaps Miss Jedd is at home. BLORE confirms that Miss Jedd is out of the way. TARVER says it would be discourteous to leave without asking after Miss Jedd. DARBEY calls it deuced bad form. BLORE says the ladies were there a minute ago. SALOME and SHEBA walk in, with SALOME having her arm around her sister's waist and looking up to her with a sweet, trusting smile. They are confused upon seeing TARVER and DARBEY. TARVER takes SALOME's hand eagerly. DARBEY rises and puts a glass to his eye. SALOME says they were startled. TARVER expresses agony of contrition. DARBEY says he is awfully cut up."
    community 3
  ]
  node [
    id 264
    label "E:DARBEY"
    kind "entity"
    name "DARBEY"
    community 3
  ]
  node [
    id 265
    label "E:TARVER"
    kind "entity"
    name "TARVER"
    community 3
  ]
  node [
    id 266
    label "E:MISS JEDD"
    kind "entity"
    name "MISS JEDD"
    community 3
  ]
  node [
    id 267
    label "E:GLASS"
    kind "entity"
    name "GLASS"
    community 3
  ]
  node [
    id 268
    label "E:SWEET TRUSTING SMILE"
    kind "entity"
    name "SWEET TRUSTING SMILE"
    community 3
  ]
  node [
    id 269
    label "E:CONFUSION"
    kind "entity"
    name "CONFUSION"
    community 3
  ]
  node [
    id 270
    label "E:AGONY OF CONTRITION"
    kind "entity"
    name "AGONY OF CONTRITION"
    community 3
  ]
  node [
    id 271
    label "E:AWFUL CUT UP"
    kind "entity"
    name "AWFUL CUT UP"
    community 3
  ]
  node [
    id 272
    label "E:DEAN IS OUT OF THE WAY"
    kind "entity"
    name "DEAN IS OUT OF THE WAY"
    community 3
  ]
  node [
    id 273
    label "E:MISS JEDD IS OUT OF THE WAY"
    kind "entity"
    name "MISS JEDD IS OUT OF THE WAY"
    community 3
  ]
  node [
    id 274
    label "E:LEAVE WITHOUT ASKING AFTER MISS JEDD"
    kind "entity"
    name "LEAVE WITHOUT ASKING AFTER MISS JEDD"
    community 3
  ]
  node [
    id 275
    label "E:DEUCED BAD FORM"
    kind "entity"
    name "DEUCED BAD FORM"
    community 3
  ]
  node [
    id 276
    label "E:LADIES WERE THERE A MINUTE AGO"
    kind "entity"
    name "LADIES WERE THERE A MINUTE AGO"
    community 3
  ]
  node [
    id 277
    label "E:TARVER AND DARBEY"
    kind "entity"
    name "TARVER AND DARBEY"
    community 25
  ]
  node [
    id 278
    label "E:SALOME'S HAND"
    kind "entity"
    name "SALOME'S HAND"
    community 3
  ]
  node [
    id 279
    label "E:GLASS TO HIS EYE"
    kind "entity"
    name "GLASS TO HIS EYE"
    community 3
  ]
  node [
    id 280
    label "E:THEY WERE STARTLED"
    kind "entity"
    name "THEY WERE STARTLED"
    community 3
  ]
  node [
    id 281
    label "E:HE IS AWFULLY CUT UP"
    kind "entity"
    name "HE IS AWFULLY CUT UP"
    community 3
  ]
  node [
    id 282
    label "C:Novel-40700_00011"
    kind "chunk"
    chunk_id "Novel-40700_00011"
  ]
  node [
    id 283
    label "U:Novel-40700_00011#0"
    kind "unit"
    chunk_id "Novel-40700_00011"
    text "TARVER expresses contrition, DARBEY says they are deeply upset to hear it, SHEBA states they never imagined finding two visitors for Papa, BLORE claims he was told to show the gentlemen in by Miss Sheba, and the girls guiltily glare at BLORE; SALOME, with suppressed rage, tells BLORE he needn't wait, and BLORE, to himself, says let 'em 'ang that on the 'atstand and exits."
    community 15
  ]
  node [
    id 284
    label "E:GENTLEMEN"
    kind "entity"
    name "GENTLEMEN"
    community 11
  ]
  node [
    id 285
    label "E:MISS SHEBA"
    kind "entity"
    name "MISS SHEBA"
    community 15
  ]
  node [
    id 286
    label "E:CAST-OFF CLOTHING DISTRIBUTION LEAGUE"
    kind "entity"
    name "CAST-OFF CLOTHING DISTRIBUTION LEAGUE"
    community 15
  ]
  node [
    id 287
    label "E:COSTOMES"
    kind "entity"
    name "COSTOMES"
    community 15
  ]
  node [
    id 288
    label "E:HAMPER"
    kind "entity"
    name "HAMPER"
    community 6
  ]
  node [
    id 289
    label "E:PARADE"
    kind "entity"
    name "PARADE"
    community 15
  ]
  node [
    id 290
    label "E:FINAL ARRANGEMENTS"
    kind "entity"
    name "FINAL ARRANGEMENTS"
    community 15
  ]
  node [
    id 291
    label "E:TONIGHT"
    kind "entity"
    name "TONIGHT"
    community 15
  ]
  node [
    id 292
    label "E:LIVER"
    kind "entity"
    name "LIVER"
    community 19
  ]
  node [
    id 293
    label "E:NERVES"
    kind "entity"
    name "NERVES"
    community 15
  ]
  node [
    id 294
    label "E:DESPOUNDENCY"
    kind "entity"
    name "DESPOUNDENCY"
    community 15
  ]
  node [
    id 295
    label "E:EXCITED"
    kind "entity"
    name "EXCITED"
    community 15
  ]
  node [
    id 296
    label "E:FIT OF DESPOUNDENCY"
    kind "entity"
    name "FIT OF DESPOUNDENCY"
    community 15
  ]
  node [
    id 297
    label "E:TWO VISITORS FOR PAPA"
    kind "entity"
    name "TWO VISITORS FOR PAPA"
    community 15
  ]
  node [
    id 298
    label "E:HIMSELF"
    kind "entity"
    name "HIMSELF"
    community 20
  ]
  node [
    id 299
    label "U:Novel-40700_00011#1"
    kind "unit"
    chunk_id "Novel-40700_00011"
    text "TARVER tells SALOME they planned to ride over directly after parade to make final arrangements for tonight and asks if the costumes have arrived; SALOME confirms they arrived yesterday in a hamper labeled 'Miss Jedd, Secretary, Cast-off Clothing Distribution League'; TARVER says that was his idea, which came to him in the middle of the night."
    community 15
  ]
  node [
    id 300
    label "E:MIDDLE OF THE NIGHT"
    kind "entity"
    name "MIDDLE OF THE NIGHT"
    community 15
  ]
  node [
    id 301
    label "E:YESTERDAY"
    kind "entity"
    name "YESTERDAY"
    community 15
  ]
  node [
    id 302
    label "E:MISS JEDD, SECRETARY, CAST-OFF CLOTHING DISTRIBUTION LEAGUE"
    kind "entity"
    name "MISS JEDD, SECRETARY, CAST-OFF CLOTHING DISTRIBUTION LEAGUE"
    community 15
  ]
  node [
    id 303
    label "U:Novel-40700_00011#2"
    kind "unit"
    chunk_id "Novel-40700_00011"
    text "SALOME, addressing Major Tarver, says his terrible strain on nerves is very bad for him with his liver; TARVER responds that his liver is frightfully injurious, and that although he is excited and at his best, the alternating fits of hopeless despondency are shocking to witness and endure."
    community 15
  ]
  node [
    id 304
    label "E:STRAIN"
    kind "entity"
    name "STRAIN"
    community 15
  ]
  node [
    id 305
    label "C:Novel-40700_00012"
    kind "chunk"
    chunk_id "Novel-40700_00012"
  ]
  node [
    id 306
    label "U:Novel-40700_00012#0"
    kind "unit"
    chunk_id "Novel-40700_00012"
    text "Salome says to Tarver that it is all due to India, and expresses regret over what she has said; Tarver responds that he will never forgive her. Salome insists she will forgive him, and Tarver says his forgetfulness has caused a severe depression attack. Salome then leads Tarver to a chair, where he sinks into a ghastly state."
    community 3
  ]
  node [
    id 307
    label "E:INDIA"
    kind "entity"
    name "INDIA"
    community 3
  ]
  node [
    id 308
    label "E:FORGETFULNESS"
    kind "entity"
    name "FORGETFULNESS"
    community 3
  ]
  node [
    id 309
    label "E:DEPRESSION"
    kind "entity"
    name "DEPRESSION"
    community 3
  ]
  node [
    id 310
    label "E:ATTACK"
    kind "entity"
    name "ATTACK"
    community 3
  ]
  node [
    id 311
    label "U:Novel-40700_00012#1"
    kind "unit"
    chunk_id "Novel-40700_00012"
    text "Darby enters from the library with Sheba and compliments her on her remarks about the army, saying on behalf of the army he thanks her and claims they are not a bad sort overall. Sheba says there is a grand future before Darby, and Darby replies that if he continues as he is, there might be one."
    community 15
  ]
  node [
    id 312
    label "E:ARMY"
    kind "entity"
    name "ARMY"
    community 15
  ]
  node [
    id 313
    label "E:FUTURE"
    kind "entity"
    name "FUTURE"
    community 15
  ]
  node [
    id 314
    label "E:ARRANGEMENTS"
    kind "entity"
    name "ARRANGEMENTS"
    community 15
  ]
  node [
    id 315
    label "E:FANCY BALL"
    kind "entity"
    name "FANCY BALL"
    community 15
  ]
  node [
    id 316
    label "E:NOT A BAD SORT"
    kind "entity"
    name "NOT A BAD SORT"
    community 15
  ]
  node [
    id 317
    label "E:HE CONTINUES AS HE IS"
    kind "entity"
    name "HE CONTINUES AS HE IS"
    community 15
  ]
  node [
    id 318
    label "U:Novel-40700_00012#2"
    kind "unit"
    chunk_id "Novel-40700_00012"
    text "Tarver asks Salome what time the house is entirely quiet; Salome says that poor dear Papa goes out with Blore at half-past nine, after which all is rest and peacefulness. Tarver suggests that if they arrive with the closed carriage at ten, they can have the house to themselves."
    community 15
  ]
  node [
    id 319
    label "E:HALF-PAST NINE"
    kind "entity"
    name "HALF-PAST NINE"
    community 15
  ]
  node [
    id 320
    label "E:CLOSED CARROUSE"
    kind "entity"
    name "CLOSED CARROUSE"
    community 15
  ]
  node [
    id 321
    label "E:HOUSE"
    kind "entity"
    name "HOUSE"
    community 15
  ]
  node [
    id 322
    label "E:TEN"
    kind "entity"
    name "TEN"
    community 15
  ]
  node [
    id 323
    label "U:Novel-40700_00012#3"
    kind "unit"
    chunk_id "Novel-40700_00012"
    text "Darby says that Tarver's strange livah has thrown all the arrangements for the Fancy Ball onto his shoulders. Salome and Tarver re-enter and observe Darby, commenting that this is when he is enjoying life."
    community 3
  ]
  node [
    id 324
    label "E:LIVAH"
    kind "entity"
    name "LIVAH"
    community 3
  ]
  node [
    id 325
    label "E:ENJOYING LIFE"
    kind "entity"
    name "ENJOYING LIFE"
    community 3
  ]
  node [
    id 326
    label "E:FANCY BALL ARRANGEMENTS"
    kind "entity"
    name "FANCY BALL ARRANGEMENTS"
    community 3
  ]
  node [
    id 327
    label "E:HE IS WITH TARVER"
    kind "entity"
    name "HE IS WITH TARVER"
    community 3
  ]
  node [
    id 328
    label "C:Novel-40700_00013"
    kind "chunk"
    chunk_id "Novel-40700_00013"
  ]
  node [
    id 329
    label "U:Novel-40700_00013#0"
    kind "unit"
    chunk_id "Novel-40700_00013"
    text "Salome and Tarver re-enter the scene, and Tarver laughs convulsively, saying 'Ha! ha! ha! ho! he! he! Good, eh, Miss Jedd?' Salome remarks that if their dear Papa hears them crunching down the gravel path, he might be upset. Tarver then sinks onto the settee with a vacant stare, his arms hanging helplessly. Darby tells Sheba that now Tarver's career is a burden to him. Salome offers Major Tarver a glass of water, and Tarver thanks her, saying he wants the water with the least suggestion of cayenne pepper. Sheba looks out the window and exclaims 'Oh, Salome! Papa! Papa!' Tarver responds 'The Dean?' Darby confirms 'The Dean!' They all collect themselves in a fluster. The two girls go to meet their father, who enters at the window with his head bowed and his hands behind his back, in deep thought. The Dean is described as a portly man of about fifty, with a dignified demeanor, a suave voice and persuasive manner, and a noble brow surmounted by silver-gray hair. Blore follows The Dean, carrying some books, a small bunch of flowers, and an umbrella. Salome tenderly says 'Papa!' and Sheba exclaims 'Papsey!'."
    community 15
  ]
  node [
    id 330
    label "E:GRAVEL PATH"
    kind "entity"
    name "GRAVEL PATH"
    community 15
  ]
  node [
    id 331
    label "E:CAYENNE PEPPER"
    kind "entity"
    name "CAYENNE PEPPER"
    community 15
  ]
  node [
    id 332
    label "E:BOOKS"
    kind "entity"
    name "BOOKS"
    community 15
  ]
  node [
    id 333
    label "E:FLOWERS"
    kind "entity"
    name "FLOWERS"
    community 15
  ]
  node [
    id 334
    label "E:UMBRELLA"
    kind "entity"
    name "UMBRELLA"
    community 7
  ]
  node [
    id 335
    label "E:FATHER"
    kind "entity"
    name "FATHER"
    community 22
  ]
  node [
    id 336
    label "E:DEAN'S DIGNIFIED DEMEANOR"
    kind "entity"
    name "DEAN'S DIGNIFIED DEMEANOR"
    community 15
  ]
  node [
    id 337
    label "E:DEAN'S SUAVE VOICE"
    kind "entity"
    name "DEAN'S SUAVE VOICE"
    community 15
  ]
  node [
    id 338
    label "E:DEAN'S PERSUASIVE MANNER"
    kind "entity"
    name "DEAN'S PERSUASIVE MANNER"
    community 15
  ]
  node [
    id 339
    label "E:DEAN'S NOBLE BROW"
    kind "entity"
    name "DEAN'S NOBLE BROW"
    community 15
  ]
  node [
    id 340
    label "E:SILVER-GRAY HAIR"
    kind "entity"
    name "SILVER-GRAY HAIR"
    community 15
  ]
  node [
    id 341
    label "E:LEAST SUGGESTION OF CAYENNE PEPPER"
    kind "entity"
    name "LEAST SUGGESTION OF CAYENNE PEPPER"
    community 15
  ]
  node [
    id 342
    label "E:PORTLY MAN OF ABOUT FIFTY"
    kind "entity"
    name "PORTLY MAN OF ABOUT FIFTY"
    community 15
  ]
  node [
    id 343
    label "E:DIGNIFIED DEMEANOR"
    kind "entity"
    name "DIGNIFIED DEMEANOR"
    community 15
  ]
  node [
    id 344
    label "E:SUAVE VOICE"
    kind "entity"
    name "SUAVE VOICE"
    community 15
  ]
  node [
    id 345
    label "E:PERSUASIVE MANNER"
    kind "entity"
    name "PERSUASIVE MANNER"
    community 15
  ]
  node [
    id 346
    label "E:NOBLE BROW SURMOUNTED BY SILVER-GRAY HAIR"
    kind "entity"
    name "NOBLE BROW SURMOUNTED BY SILVER-GRAY HAIR"
    community 15
  ]
  node [
    id 347
    label "E:PAPSEY"
    kind "entity"
    name "PAPSEY"
    community 2
  ]
  node [
    id 348
    label "C:Novel-40700_00014"
    kind "chunk"
    chunk_id "Novel-40700_00014"
  ]
  node [
    id 349
    label "U:Novel-40700_00014#0"
    kind "unit"
    chunk_id "Novel-40700_00014"
    text "The Dean rouses himself, sees his children Salome and Sheba, removes his hat, and addresses them as 'Salome' and 'my toy-child'. He then notices Tarver and Darbey and remarks that they are strangers. Salome reproaches him, explaining that Major Tarver and Mr. Darbey have ridden from Durnstone to inquire about his cold. Sheba takes the gold-rimmed pince-nez from the Dean's waistcoat and places it before his eyes. The Dean corrects himself, calling Darbey by name and expressing that their visit is kind, and he insists they share his simple dinner at six o'clock on Tuesday night. He specifies the meal as leg of mutton, hot, and custards, cold, with Salome and Sheba confirming their preferences."
    community 1
  ]
  node [
    id 350
    label "E:GOLD-RIMMED PINCE-NEZ"
    kind "entity"
    name "GOLD-RIMMED PINCE-NEZ"
    community 1
  ]
  node [
    id 351
    label "E:TUESDAY NIGHT"
    kind "entity"
    name "TUESDAY NIGHT"
    community 1
  ]
  node [
    id 352
    label "E:SIX O'CLOCK"
    kind "entity"
    name "SIX O'CLOCK"
    community 1
  ]
  node [
    id 353
    label "E:LEG OF MUTTON"
    kind "entity"
    name "LEG OF MUTTON"
    community 1
  ]
  node [
    id 354
    label "E:HOT"
    kind "entity"
    name "HOT"
    community 1
  ]
  node [
    id 355
    label "E:CUSTARDS"
    kind "entity"
    name "CUSTARDS"
    community 11
  ]
  node [
    id 356
    label "E:COLD"
    kind "entity"
    name "COLD"
    community 1
  ]
  node [
    id 357
    label "E:MR. GARVEY"
    kind "entity"
    name "MR. GARVEY"
    community 2
  ]
  node [
    id 358
    label "C:Novel-40700_00015"
    kind "chunk"
    chunk_id "Novel-40700_00015"
  ]
  node [
    id 359
    label "U:Novel-40700_00015#0"
    kind "unit"
    chunk_id "Novel-40700_00015"
    text "SHEBA orders mutton hot and custards, Papsey. THE DEAN thanks a child-like person and orders custards cold and a welcome warm. TARVER looks at SALOME, who nods violently, and responds with hesitation before affirming he is certainly the Dean. DARBEY expresses delight to the Dean and receives a severe look, then leaves the room with an important cough into the Library. The men and girls speak in undertones. TARVER expresses depression and asks what will happen that night. SALOME explains that since TARVER will have to drive over to dine, both he and DARBEY will be present and ready to take them back to Durnstone. DARBEY agrees and says they can stay in the lane until they are ready. TARVER asks when they will make their preparations, noting it will take him a long time to look like Charles the First. SHEBA suggests they can drive around Durnstone while TARVER dresses. SALOME admires TARVER, calling him Charles the First. DARBEY says his idea was Charles the Martyr, noting Tarver is a martyr to his liver. SHEBA exclaims they will all look magnificent. SALOME agrees. TARVER calls the idea grand. DARBEY ends with a statement."
    community 19
  ]
  node [
    id 360
    label "E:PASTEY"
    kind "entity"
    name "PASTEY"
    community 19
  ]
  node [
    id 361
    label "E:CHARLES THE FIRST"
    kind "entity"
    name "CHARLES THE FIRST"
    community 19
  ]
  node [
    id 362
    label "E:CHARLES THE MARTYR"
    kind "entity"
    name "CHARLES THE MARTYR"
    community 19
  ]
  node [
    id 363
    label "E:LANE"
    kind "entity"
    name "LANE"
    community 19
  ]
  node [
    id 364
    label "E:WELCOME"
    kind "entity"
    name "WELCOME"
    community 19
  ]
  node [
    id 365
    label "E:UNDERTONES"
    kind "entity"
    name "UNDERTONES"
    community 19
  ]
  node [
    id 366
    label "E:PREPARATIONS"
    kind "entity"
    name "PREPARATIONS"
    community 19
  ]
  node [
    id 367
    label "E:DRIVING"
    kind "entity"
    name "DRIVING"
    community 19
  ]
  node [
    id 368
    label "E:DRESSING"
    kind "entity"
    name "DRESSING"
    community 19
  ]
  node [
    id 369
    label "E:MARTYR"
    kind "entity"
    name "MARTYR"
    community 19
  ]
  node [
    id 370
    label "E:MAGNIFICENT"
    kind "entity"
    name "MAGNIFICENT"
    community 19
  ]
  node [
    id 371
    label "E:MUTTON HOT"
    kind "entity"
    name "MUTTON HOT"
    community 19
  ]
  node [
    id 372
    label "E:TOY-CHILD"
    kind "entity"
    name "TOY-CHILD"
    community 19
  ]
  node [
    id 373
    label "E:CUSTARDS COLD"
    kind "entity"
    name "CUSTARDS COLD"
    community 19
  ]
  node [
    id 374
    label "E:WELCOME WARM"
    kind "entity"
    name "WELCOME WARM"
    community 19
  ]
  node [
    id 375
    label "E:MEN AND GIRLS"
    kind "entity"
    name "MEN AND GIRLS"
    community 19
  ]
  node [
    id 376
    label "E:WHAT WILL HAPPEN THAT NIGHT"
    kind "entity"
    name "WHAT WILL HAPPEN THAT NIGHT"
    community 19
  ]
  node [
    id 377
    label "E:TARVER WILL DRIVE OVER TO DINE"
    kind "entity"
    name "TARVER WILL DRIVE OVER TO DINE"
    community 19
  ]
  node [
    id 378
    label "E:TARVER AND DARBEY WILL BE PRESENT"
    kind "entity"
    name "TARVER AND DARBEY WILL BE PRESENT"
    community 19
  ]
  node [
    id 379
    label "E:THEY WILL BE READY TO TAKE THEM BACK TO DURNSTONE"
    kind "entity"
    name "THEY WILL BE READY TO TAKE THEM BACK TO DURNSTONE"
    community 19
  ]
  node [
    id 380
    label "E:THEY CAN STAY IN THE LANE"
    kind "entity"
    name "THEY CAN STAY IN THE LANE"
    community 19
  ]
  node [
    id 381
    label "E:WHEN PREPARATIONS WILL BE MADE"
    kind "entity"
    name "WHEN PREPARATIONS WILL BE MADE"
    community 19
  ]
  node [
    id 382
    label "E:IT WILL TAKE HIM A LONG TIME TO LOOK LIKE CHARLES THE FIRST"
    kind "entity"
    name "IT WILL TAKE HIM A LONG TIME TO LOOK LIKE CHARLES THE FIRST"
    community 19
  ]
  node [
    id 383
    label "E:THEY CAN DRIVE AROUND DURNSTONE WHILE TARVER DRESSES"
    kind "entity"
    name "THEY CAN DRIVE AROUND DURNSTONE WHILE TARVER DRESSES"
    community 19
  ]
  node [
    id 384
    label "E:TARVER IS A MARTYR TO HIS LIVER"
    kind "entity"
    name "TARVER IS A MARTYR TO HIS LIVER"
    community 19
  ]
  node [
    id 385
    label "E:THEY WILL ALL LOOK MAGNIFICENT"
    kind "entity"
    name "THEY WILL ALL LOOK MAGNIFICENT"
    community 19
  ]
  node [
    id 386
    label "E:GRAND IDEA"
    kind "entity"
    name "GRAND IDEA"
    community 19
  ]
  node [
    id 387
    label "E:STATEMENT"
    kind "entity"
    name "STATEMENT"
    community 19
  ]
  node [
    id 388
    label "U:Novel-40700_00015#1"
    kind "unit"
    chunk_id "Novel-40700_00015"
    text "SHEBA, TARVER, SALOME, and DARBEY are characters in a scene involving a house, a library, and a dinner event at Durnstone. The characters discuss preparations for a dinner, including dressing and driving around the estate. TARVER is concerned about how long it will take him to dress like Charles the First, and SALOME praises him for that. DARBEY refers to Tarver as a martyr to his liver and suggests Charles the Martyr as a theme. SHEBA and SALOME express enthusiasm about looking magnificent. The scene takes place in a domestic setting with undertones of humor and social commentary."
    community 19
  ]
  node [
    id 389
    label "E:DINNER"
    kind "entity"
    name "DINNER"
    community 1
  ]
  node [
    id 390
    label "E:SOCIAL COMMENTARY"
    kind "entity"
    name "SOCIAL COMMENTARY"
    community 19
  ]
  node [
    id 391
    label "E:DRESSING LIKE CHARLES THE FIRST"
    kind "entity"
    name "DRESSING LIKE CHARLES THE FIRST"
    community 19
  ]
  node [
    id 392
    label "E:TARVER AS A MARTYR TO HIS LIVER"
    kind "entity"
    name "TARVER AS A MARTYR TO HIS LIVER"
    community 19
  ]
  node [
    id 393
    label "E:LOOKING MAGNIFICENT"
    kind "entity"
    name "LOOKING MAGNIFICENT"
    community 19
  ]
  node [
    id 394
    label "E:SCENE"
    kind "entity"
    name "SCENE"
    community 19
  ]
  node [
    id 395
    label "E:DOMESTIC SETTING"
    kind "entity"
    name "DOMESTIC SETTING"
    community 19
  ]
  node [
    id 396
    label "U:Novel-40700_00015#2"
    kind "unit"
    chunk_id "Novel-40700_00015"
    text "The characters are in a domestic setting where they discuss preparations for a dinner at Durnstone. TARVER is worried about dressing like Charles the First, and SALOME compliments him on that. DARBEY humorously calls Tarver a martyr to his liver and suggests Charles the Martyr as a theme. SHEBA and SALOME express excitement about looking magnificent. The conversation occurs in the house, with the library being a location where the Dean is present and later leaves. The men and women speak in undertones, indicating a private, possibly humorous or tense atmosphere."
    community 19
  ]
  node [
    id 397
    label "E:PRIVATE ATMOSPHERE"
    kind "entity"
    name "PRIVATE ATMOSPHERE"
    community 19
  ]
  node [
    id 398
    label "E:TARVER A MARTYR TO HIS LIVER"
    kind "entity"
    name "TARVER A MARTYR TO HIS LIVER"
    community 19
  ]
  node [
    id 399
    label "E:CONVERSATION"
    kind "entity"
    name "CONVERSATION"
    community 15
  ]
  node [
    id 400
    label "E:MEN AND WOMEN"
    kind "entity"
    name "MEN AND WOMEN"
    community 19
  ]
  node [
    id 401
    label "C:Novel-40700_00016"
    kind "chunk"
    chunk_id "Novel-40700_00016"
  ]
  node [
    id 402
    label "U:Novel-40700_00016#0"
    kind "unit"
    chunk_id "Novel-40700_00016"
    text "Sheba exclaims, 'Oh! sha'n't we all look magnificent?' Salome responds, 'Oh!' Tarver agrees, calling it a 'grand idea&#8212;the whole thing!' Darby calls it a 'regular army notion.' They are all excited when The Dean re-enters with an anxious look, carrying a bundle of papers. Salome says, 'Here is Papa!' and they rush to various seats in constrained attitudes. Tarver says to The Dean, 'We waited to say&#8212;good-morning.' The Dean takes his hand abstractedly and replies, 'How kind! Good-morning!' Darby asks, 'Six o'clock sharp, Dean?' The Dean answers, 'At six, punctually.' Salome is instructed to represent him by escorting the gentlemen to the gate. Sheba follows slyly when The Dean looks up from his papers. The Dean calls out, 'Sheba!' Sheba replies, 'Papsey!' The Dean says, 'Check me in a growing tendency to dislike Mr. Garvey. At dinner, Sheba, watch that I carve for him fairly.' Sheba replies, 'Yes, Papsey!' The Dean turns away and sits on the settee. Sheba walks towards the door, folds her hands, and then bounds out. The Dean turns the papers over in his hand solemnly and says, 'Bills!' He rises, walks thoughtfully to a chair, sits, and examines the papers again, saying, 'Bills!'."
    community 2
  ]
  node [
    id 403
    label "E:GATE"
    kind "entity"
    name "GATE"
    community 23
  ]
  node [
    id 404
    label "E:PAPAY"
    kind "entity"
    name "PAPAY"
    community 2
  ]
  node [
    id 405
    label "E:BILLS"
    kind "entity"
    name "BILLS"
    community 2
  ]
  node [
    id 406
    label "E:OH! SHA'N'T WE ALL LOOK MAGNIFICENT?"
    kind "entity"
    name "OH! SHA'N'T WE ALL LOOK MAGNIFICENT?"
    community 2
  ]
  node [
    id 407
    label "E:OH!"
    kind "entity"
    name "OH!"
    community 2
  ]
  node [
    id 408
    label "E:GRAND IDEA&#8212;THE WHOLE THING"
    kind "entity"
    name "GRAND IDEA&#8212;THE WHOLE THING"
    community 2
  ]
  node [
    id 409
    label "E:REGULAR ARMY NOTION"
    kind "entity"
    name "REGULAR ARMY NOTION"
    community 2
  ]
  node [
    id 410
    label "E:BUNDLE OF PAPERS"
    kind "entity"
    name "BUNDLE OF PAPERS"
    community 2
  ]
  node [
    id 411
    label "E:HERE IS PAPA!"
    kind "entity"
    name "HERE IS PAPA!"
    community 2
  ]
  node [
    id 412
    label "E:GOOD-MORNING"
    kind "entity"
    name "GOOD-MORNING"
    community 2
  ]
  node [
    id 413
    label "E:SIX O'CLOCK SHARP, DEAN?"
    kind "entity"
    name "SIX O'CLOCK SHARP, DEAN?"
    community 2
  ]
  node [
    id 414
    label "E:AT SIX, PUNCTUALLY"
    kind "entity"
    name "AT SIX, PUNCTUALLY"
    community 2
  ]
  node [
    id 415
    label "E:GENTLEMEN TO THE GATE"
    kind "entity"
    name "GENTLEMEN TO THE GATE"
    community 2
  ]
  node [
    id 416
    label "E:CARVING FOR MR. GARVEY"
    kind "entity"
    name "CARVING FOR MR. GARVEY"
    community 2
  ]
  node [
    id 417
    label "E:SOLEMNLY"
    kind "entity"
    name "SOLEMNLY"
    community 2
  ]
  node [
    id 418
    label "E:CHAIR"
    kind "entity"
    name "CHAIR"
    community 2
  ]
  node [
    id 419
    label "E:PAPERS AGAIN"
    kind "entity"
    name "PAPERS AGAIN"
    community 2
  ]
  node [
    id 420
    label "C:Novel-40700_00017"
    kind "chunk"
    chunk_id "Novel-40700_00017"
  ]
  node [
    id 421
    label "U:Novel-40700_00017#0"
    kind "unit"
    chunk_id "Novel-40700_00017"
    text "He rises, walks thoughtfully to a chair, sits and examines papers again, then rises again, walks to another chair, and sinks into it with a groan, repeatedly saying 'Bills!'"
    community 2
  ]
  node [
    id 422
    label "U:Novel-40700_00017#1"
    kind "unit"
    chunk_id "Novel-40700_00017"
    text "SALOME and SHEBA re-enter and whisper to each other that Papa is alone, with SHEBA suggesting a beautiful opportunity to ask for money, and both exclaiming 'Poor dear Papa!'"
    community 18
  ]
  node [
    id 423
    label "E:MONEY"
    kind "entity"
    name "MONEY"
    community 18
  ]
  node [
    id 424
    label "E:OPPORTUNITY"
    kind "entity"
    name "OPPORTUNITY"
    community 18
  ]
  node [
    id 425
    label "U:Novel-40700_00017#2"
    kind "unit"
    chunk_id "Novel-40700_00017"
    text "SALOME and SHEBA link their hands, walk as if going out through the Library, and the DEAN calls them not to go, rises, and is rushed by the girls who turn him like a top and dance around him"
    community 19
  ]
  node [
    id 426
    label "E:DANCING"
    kind "entity"
    name "DANCING"
    community 19
  ]
  node [
    id 427
    label "E:SALOME AND SHEBA"
    kind "entity"
    name "SALOME AND SHEBA"
    community 19
  ]
  node [
    id 428
    label "U:Novel-40700_00017#3"
    kind "unit"
    chunk_id "Novel-40700_00017"
    text "The DEAN pants, stops the girls, SHEBA says Papsey is in a good humor, SALOME pins his chin and says he always is, SHEBA says Papsey will listen to their little wants, and they force him into a chair with SALOME sitting on the ground embracing his legs and SHEBA lying on the top of the table"
    community 2
  ]
  node [
    id 429
    label "E:TABLE"
    kind "entity"
    name "TABLE"
    community 5
  ]
  node [
    id 430
    label "E:L--S--D"
    kind "entity"
    name "L--S--D"
    community 2
  ]
  node [
    id 431
    label "E:L--S"
    kind "entity"
    name "L--S"
    community 2
  ]
  node [
    id 432
    label "E:THEY&#34;S LITTLE WANTS"
    kind "entity"
    name "THEY&#34;S LITTLE WANTS"
    community 2
  ]
  node [
    id 433
    label "E:DEAN&#34;S LEGS"
    kind "entity"
    name "DEAN&#34;S LEGS"
    community 2
  ]
  node [
    id 434
    label "U:Novel-40700_00017#4"
    kind "unit"
    chunk_id "Novel-40700_00017"
    text "The DEAN says their wants are very little and asks Salome what they are, Salome asks if Papa has any spare cash, the DEAN calls Salome playful, SHEBA says 'L--s--d' or 'L--s' and never mind the 'd'"
    community 2
  ]
  node [
    id 435
    label "E:SPARE CASH"
    kind "entity"
    name "SPARE CASH"
    community 2
  ]
  node [
    id 436
    label "E:PLAYFUL"
    kind "entity"
    name "PLAYFUL"
    community 2
  ]
  node [
    id 437
    label "E:D"
    kind "entity"
    name "D"
    community 2
  ]
  node [
    id 438
    label "E:VERY LITTLE"
    kind "entity"
    name "VERY LITTLE"
    community 2
  ]
  node [
    id 439
    label "E:IF PAPA HAS SPARE CASH"
    kind "entity"
    name "IF PAPA HAS SPARE CASH"
    community 2
  ]
  node [
    id 440
    label "E:L--S--D OR L--S AND NEVER MIND THE D"
    kind "entity"
    name "L--S--D OR L--S AND NEVER MIND THE D"
    community 2
  ]
  node [
    id 441
    label "C:Novel-40700_00018"
    kind "chunk"
    chunk_id "Novel-40700_00018"
  ]
  node [
    id 442
    label "U:Novel-40700_00018#0"
    kind "unit"
    chunk_id "Novel-40700_00018"
    text "SHEBA and SALOME babbled for money, breaking a reserve that had existed for at least a fortnight, which made the DEAN glad and gave him the opportunity to meet their demands with candor. The DEAN expresses love and solicitude for them but states he has no spare cash. He rises, walks to the piano, and begins arranging his bills. SALOME scrambles up from the floor in horror, SHEBA wriggles off the table, and both drop onto the same chair and huddle together. SALOME says to herself, 'Lost!', and SHEBA says to herself, 'Done for!'. The DEAN then declares that this kind of behavior must stop, stating that the dressmaker's bill is shocking, the milliner gives an analytical record of the feverish beatings of the hot pulse of fashion, and the general draper blows a rancorous blast which would bring dismay to the stoutest heart."
    community 5
  ]
  node [
    id 443
    label "E:DRESSMAKER'S BILL"
    kind "entity"
    name "DRESSMAKER'S BILL"
    community 5
  ]
  node [
    id 444
    label "E:MILLINER"
    kind "entity"
    name "MILLINER"
    community 5
  ]
  node [
    id 445
    label "E:GENERAL DRAPER"
    kind "entity"
    name "GENERAL DRAPER"
    community 5
  ]
  node [
    id 446
    label "E:PIANO"
    kind "entity"
    name "PIANO"
    community 11
  ]
  node [
    id 447
    label "E:FORTNIGHT"
    kind "entity"
    name "FORTNIGHT"
    community 5
  ]
  node [
    id 448
    label "E:HORROR"
    kind "entity"
    name "HORROR"
    community 5
  ]
  node [
    id 449
    label "E:FEVERISH BEATINGS"
    kind "entity"
    name "FEVERISH BEATINGS"
    community 5
  ]
  node [
    id 450
    label "E:HOT PULSE OF FASHION"
    kind "entity"
    name "HOT PULSE OF FASHION"
    community 5
  ]
  node [
    id 451
    label "E:RANCOROUS BLAST"
    kind "entity"
    name "RANCOROUS BLAST"
    community 5
  ]
  node [
    id 452
    label "E:STOUTEST HEART"
    kind "entity"
    name "STOUTEST HEART"
    community 5
  ]
  node [
    id 453
    label "E:SHEBA AND SALOME"
    kind "entity"
    name "SHEBA AND SALOME"
    community 5
  ]
  node [
    id 454
    label "E:SHEBA AND SALOME BABBLED FOR MONEY"
    kind "entity"
    name "SHEBA AND SALOME BABBLED FOR MONEY"
    community 5
  ]
  node [
    id 455
    label "E:FLOOR"
    kind "entity"
    name "FLOOR"
    community 5
  ]
  node [
    id 456
    label "E:SAME CHAIR"
    kind "entity"
    name "SAME CHAIR"
    community 5
  ]
  node [
    id 457
    label "E:LOST"
    kind "entity"
    name "LOST"
    community 5
  ]
  node [
    id 458
    label "E:DONE FOR"
    kind "entity"
    name "DONE FOR"
    community 5
  ]
  node [
    id 459
    label "E:SHOCKING"
    kind "entity"
    name "SHOCKING"
    community 5
  ]
  node [
    id 460
    label "E:FEVERISH BEATINGS OF THE HOT PULSE OF FASHION"
    kind "entity"
    name "FEVERISH BEATINGS OF THE HOT PULSE OF FASHION"
    community 5
  ]
  node [
    id 461
    label "C:Novel-40700_00019"
    kind "chunk"
    chunk_id "Novel-40700_00019"
  ]
  node [
    id 462
    label "U:Novel-40700_00019#0"
    kind "unit"
    chunk_id "Novel-40700_00019"
    text "The Dean expresses frustration with his daughters' emotional outbursts, stating that such expressions preserve family unity, and claims that the total number of 'weeds' growing in the garden of paternity is 156, 18, and 3, totaling 177. He also states that the money he can immediately command is under five hundred pounds."
    community 7
  ]
  node [
    id 463
    label "E:DOMESTIC UNISON"
    kind "entity"
    name "DOMESTIC UNISON"
    community 7
  ]
  node [
    id 464
    label "E:WEEDS"
    kind "entity"
    name "WEEDS"
    community 7
  ]
  node [
    id 465
    label "E:GARDEN OF PATERNITY"
    kind "entity"
    name "GARDEN OF PATERNITY"
    community 7
  ]
  node [
    id 466
    label "E:156"
    kind "entity"
    name "156"
    community 7
  ]
  node [
    id 467
    label "E:18"
    kind "entity"
    name "18"
    community 7
  ]
  node [
    id 468
    label "E:3"
    kind "entity"
    name "3"
    community 7
  ]
  node [
    id 469
    label "E:177"
    kind "entity"
    name "177"
    community 7
  ]
  node [
    id 470
    label "E:FIVE HUNDRED POUNDS"
    kind "entity"
    name "FIVE HUNDRED POUNDS"
    community 7
  ]
  node [
    id 471
    label "E:UNBOSOMINGS PRESERVE DOMESTIC UNISON"
    kind "entity"
    name "UNBOSOMINGS PRESERVE DOMESTIC UNISON"
    community 7
  ]
  node [
    id 472
    label "U:Novel-40700_00019#1"
    kind "unit"
    chunk_id "Novel-40700_00019"
    text "The Dean hands Salome a copy of 'The Times' from yesterday, pointing to a paragraph that states Dr. Jedd, the Dean of St. Marvells, has subscribed one thousand pounds to the Restoration Fund due to his anxiety for the preservation of the Minister Spire, which threatens to undermine his health."
    community 10
  ]
  node [
    id 473
    label "E:TIMES"
    kind "entity"
    name "TIMES"
    community 20
  ]
  node [
    id 474
    label "E:DR. JEDD"
    kind "entity"
    name "DR. JEDD"
    community 10
  ]
  node [
    id 475
    label "E:ST. MARVELLS"
    kind "entity"
    name "ST. MARVELLS"
    community 10
  ]
  node [
    id 476
    label "E:RESTORATION FUND"
    kind "entity"
    name "RESTORATION FUND"
    community 20
  ]
  node [
    id 477
    label "E:ONE THOUSAND POUNDS"
    kind "entity"
    name "ONE THOUSAND POUNDS"
    community 10
  ]
  node [
    id 478
    label "E:MINISTER SPIRE"
    kind "entity"
    name "MINISTER SPIRE"
    community 10
  ]
  node [
    id 479
    label "E:ANXIETY FOR PRESERVATION"
    kind "entity"
    name "ANXIETY FOR PRESERVATION"
    community 10
  ]
  node [
    id 480
    label "E:HEALTH"
    kind "entity"
    name "HEALTH"
    community 10
  ]
  node [
    id 481
    label "C:Novel-40700_00020"
    kind "chunk"
    chunk_id "Novel-40700_00020"
  ]
  node [
    id 482
    label "U:Novel-40700_00020#0"
    kind "unit"
    chunk_id "Novel-40700_00020"
    text "SHEBA and SALOME express indignation over the need for seven additional donors to secure their summer dresses, with SHEBA questioning whether they will come; the DEAN responds that times are bad but one never knows, and if the donors do not come, the girls will still receive their dresses as usual; if they do come, the DEAN says they will all rejoice, and the girls echo this with 'Rejoice!', adding that they must also retrench, meaning to reduce expenses, with the phrase 'Two R's: Retrench and Rejoice'"
    community 5
  ]
  node [
    id 483
    label "E:SEVEN OTHER DONORS"
    kind "entity"
    name "SEVEN OTHER DONORS"
    community 5
  ]
  node [
    id 484
    label "E:SUM"
    kind "entity"
    name "SUM"
    community 5
  ]
  node [
    id 485
    label "E:SUM OF MONEY"
    kind "entity"
    name "SUM OF MONEY"
    community 5
  ]
  node [
    id 486
    label "E:SUM OF MONEY PER DONOR"
    kind "entity"
    name "SUM OF MONEY PER DONOR"
    community 5
  ]
  node [
    id 487
    label "E:NEW SUMMER DRESSES"
    kind "entity"
    name "NEW SUMMER DRESSES"
    community 5
  ]
  node [
    id 488
    label "E:RETRENCH"
    kind "entity"
    name "RETRENCH"
    community 5
  ]
  node [
    id 489
    label "E:REJOICE"
    kind "entity"
    name "REJOICE"
    community 5
  ]
  node [
    id 490
    label "E:SPORT AND RELAXATION REPRESSION GUILD"
    kind "entity"
    name "SPORT AND RELAXATION REPRESSION GUILD"
    community 5
  ]
  node [
    id 491
    label "E:RACES"
    kind "entity"
    name "RACES"
    community 6
  ]
  node [
    id 492
    label "E:ST. MARVELLS SPRING MEETING"
    kind "entity"
    name "ST. MARVELLS SPRING MEETING"
    community 5
  ]
  node [
    id 493
    label "E:LETTERS"
    kind "entity"
    name "LETTERS"
    community 5
  ]
  node [
    id 494
    label "E:MR. HODDER"
    kind "entity"
    name "MR. HODDER"
    community 5
  ]
  node [
    id 495
    label "E:FIRST DAY OF THE RACES"
    kind "entity"
    name "FIRST DAY OF THE RACES"
    community 5
  ]
  node [
    id 496
    label "E:NEW SUMMER DRESSES WILL BE RECEIVED AS USUAL"
    kind "entity"
    name "NEW SUMMER DRESSES WILL BE RECEIVED AS USUAL"
    community 5
  ]
  node [
    id 497
    label "E:ALL WILL REJOICE"
    kind "entity"
    name "ALL WILL REJOICE"
    community 5
  ]
  node [
    id 498
    label "U:Novel-40700_00020#1"
    kind "unit"
    chunk_id "Novel-40700_00020"
    text "BLORE enters with two letters, hears SALOME and SHEBA crying, and comments that they have had a scolding, suggesting they should hang the scolding on the hatstand; he then leaves"
    community 5
  ]
  node [
    id 499
    label "E:SCOLDING"
    kind "entity"
    name "SCOLDING"
    community 5
  ]
  node [
    id 500
    label "E:HATSTAND"
    kind "entity"
    name "HATSTAND"
    community 5
  ]
  node [
    id 501
    label "E:THEY HAVE HAD A SCOLDING"
    kind "entity"
    name "THEY HAVE HAD A SCOLDING"
    community 5
  ]
  node [
    id 502
    label "E:SCOLDING ON THE HATSTAND"
    kind "entity"
    name "SCOLDING ON THE HATSTAND"
    community 5
  ]
  node [
    id 503
    label "C:Novel-40700_00021"
    kind "chunk"
    chunk_id "Novel-40700_00021"
  ]
  node [
    id 504
    label "U:Novel-40700_00021#0"
    kind "unit"
    chunk_id "Novel-40700_00021"
    text "Blore states that no servant is allowed to leave the Deanery on any pretense while the races are on, and the Dean acknowledges this rule with appreciation."
    community 6
  ]
  node [
    id 505
    label "U:Novel-40700_00021#1"
    kind "unit"
    chunk_id "Novel-40700_00021"
    text "The Dean announces that his widowed sister, Georgiana Tidman, is coming to live with them after reconciling with her after many years."
    community 13
  ]
  node [
    id 506
    label "E:DAUGHTERS"
    kind "entity"
    name "DAUGHTERS"
    community 13
  ]
  node [
    id 507
    label "E:RETRENCHMENT"
    kind "entity"
    name "RETRENCHMENT"
    community 13
  ]
  node [
    id 508
    label "E:EXPENSES"
    kind "entity"
    name "EXPENSES"
    community 13
  ]
  node [
    id 509
    label "U:Novel-40700_00021#2"
    kind "unit"
    chunk_id "Novel-40700_00021"
    text "The daughters, Salome and Sheba, express surprise and reluctance about their aunt Georgiana coming to live with them, with Sheba stating they do not want her."
    community 13
  ]
  node [
    id 510
    label "C:Novel-40700_00022"
    kind "chunk"
    chunk_id "Novel-40700_00022"
  ]
  node [
    id 511
    label "U:Novel-40700_00022#0"
    kind "unit"
    chunk_id "Novel-40700_00022"
    text "The Dean reveals that Aunt Georgiana married a man whose existence he never recognized; the man died ten years ago and was described as a misguided individual who bred horses for racing and profit, and was known as a Gentleman Jockey. It was said that if he vexed her, she could take a stone off his weight in half an hour, and eventually his neck was dislocated. The Dean says he came a cropper and left a widow, and that Georgiana Tidman did not go to her brother despite being a widow herself."
    community 17
  ]
  node [
    id 512
    label "E:AUNT GEORGIANA"
    kind "entity"
    name "AUNT GEORGIANA"
    community 17
  ]
  node [
    id 513
    label "E:AUNT WHATS HER NAME"
    kind "entity"
    name "AUNT WHATS HER NAME"
    community 17
  ]
  node [
    id 514
    label "E:AUNT SHEBA"
    kind "entity"
    name "AUNT SHEBA"
    community 17
  ]
  node [
    id 515
    label "E:MAN WHO BREWED HORSES"
    kind "entity"
    name "MAN WHO BREWED HORSES"
    community 17
  ]
  node [
    id 516
    label "E:GENTLEMAN JOCKEY"
    kind "entity"
    name "GENTLEMAN JOCKEY"
    community 17
  ]
  node [
    id 517
    label "E:NECK DISLOCATED"
    kind "entity"
    name "NECK DISLOCATED"
    community 17
  ]
  node [
    id 518
    label "E:DECEASED"
    kind "entity"
    name "DECEASED"
    community 17
  ]
  node [
    id 519
    label "E:TEN YEARS AGO"
    kind "entity"
    name "TEN YEARS AGO"
    community 17
  ]
  node [
    id 520
    label "E:WIDOW"
    kind "entity"
    name "WIDOW"
    community 17
  ]
  node [
    id 521
    label "E:BREEDING HORSES FOR RACING"
    kind "entity"
    name "BREEDING HORSES FOR RACING"
    community 17
  ]
  node [
    id 522
    label "E:AMUSEMENT AND PROFIT"
    kind "entity"
    name "AMUSEMENT AND PROFIT"
    community 17
  ]
  node [
    id 523
    label "E:TAKE A STONE OFF HIS WEIGHT"
    kind "entity"
    name "TAKE A STONE OFF HIS WEIGHT"
    community 17
  ]
  node [
    id 524
    label "E:CAME A CROPPER"
    kind "entity"
    name "CAME A CROPPER"
    community 17
  ]
  node [
    id 525
    label "U:Novel-40700_00022#1"
    kind "unit"
    chunk_id "Novel-40700_00022"
    text "The Dean says that after the man died, it would be natural for Aunt Georgiana to go to her brother, who is also a widower, but she did not do so."
    community 17
  ]
  node [
    id 526
    label "E:AUNT GEORGIANA'S BROTHER"
    kind "entity"
    name "AUNT GEORGIANA'S BROTHER"
    community 17
  ]
  node [
    id 527
    label "E:WIDOWER"
    kind "entity"
    name "WIDOWER"
    community 17
  ]
  node [
    id 528
    label "E:AUNT SHEBA'S BROTHER"
    kind "entity"
    name "AUNT SHEBA'S BROTHER"
    community 17
  ]
  node [
    id 529
    label "C:Novel-40700_00023"
    kind "chunk"
    chunk_id "Novel-40700_00023"
  ]
  node [
    id 530
    label "U:Novel-40700_00023#0"
    kind "unit"
    chunk_id "Novel-40700_00023"
    text "Maddened by grief, she continued the career of her misguided husband and for years was called 'the Daisy of the Turf' using her own terrible words."
    community 13
  ]
  node [
    id 531
    label "E:GRIEF"
    kind "entity"
    name "GRIEF"
    community 13
  ]
  node [
    id 532
    label "E:MISGUIDED HUSBAND"
    kind "entity"
    name "MISGUIDED HUSBAND"
    community 13
  ]
  node [
    id 533
    label "E:DAISY OF THE TURF"
    kind "entity"
    name "DAISY OF THE TURF"
    community 13
  ]
  node [
    id 534
    label "U:Novel-40700_00023#1"
    kind "unit"
    chunk_id "Novel-40700_00023"
    text "Retribution came in the form of ill luck that affected her horses, stock, and everything else, leading to all of her possessions being sold at auction. This was the moment when the speaker wrote, 'Come to me, my children yearn for you.'"
    community 22
  ]
  node [
    id 535
    label "E:RETRIBUTION"
    kind "entity"
    name "RETRIBUTION"
    community 22
  ]
  node [
    id 536
    label "E:ILL LUCK"
    kind "entity"
    name "ILL LUCK"
    community 22
  ]
  node [
    id 537
    label "E:HORSES"
    kind "entity"
    name "HORSES"
    community 22
  ]
  node [
    id 538
    label "E:STOCK"
    kind "entity"
    name "STOCK"
    community 22
  ]
  node [
    id 539
    label "E:HAMMER"
    kind "entity"
    name "HAMMER"
    community 22
  ]
  node [
    id 540
    label "E:CHILDREN"
    kind "entity"
    name "CHILDREN"
    community 16
  ]
  node [
    id 541
    label "E:TELEGRAM"
    kind "entity"
    name "TELEGRAM"
    community 22
  ]
  node [
    id 542
    label "E:COME TO ME MY CHILDREN YEARN FOR YOU"
    kind "entity"
    name "COME TO ME MY CHILDREN YEARN FOR YOU"
    community 22
  ]
  node [
    id 543
    label "U:Novel-40700_00023#2"
    kind "unit"
    chunk_id "Novel-40700_00023"
    text "The Dean offered a place of rest and forgetfulness at the Deanery of St. Marvells, which includes household duties and a stable with only a thirteen-year-old pony, and said she is coming soon."
    community 7
  ]
  node [
    id 544
    label "E:DEANERY OF ST. MARVELLS"
    kind "entity"
    name "DEANERY OF ST. MARVELLS"
    community 7
  ]
  node [
    id 545
    label "E:HOUSEHOLD"
    kind "entity"
    name "HOUSEHOLD"
    community 7
  ]
  node [
    id 546
    label "E:STABLE"
    kind "entity"
    name "STABLE"
    community 7
  ]
  node [
    id 547
    label "E:THIRTEEN-YEAR-OLD PONY"
    kind "entity"
    name "THIRTEEN-YEAR-OLD PONY"
    community 7
  ]
  node [
    id 548
    label "E:SOON"
    kind "entity"
    name "SOON"
    community 7
  ]
  node [
    id 549
    label "U:Novel-40700_00023#3"
    kind "unit"
    chunk_id "Novel-40700_00023"
    text "The Dean warned that Sheba and Salome would find her a sad, broken, weary, and wave-tossed person, and that their task would be to win back a flickering smile from her wan features."
    community 22
  ]
  node [
    id 550
    label "E:SAD BROKEN CREATURE"
    kind "entity"
    name "SAD BROKEN CREATURE"
    community 22
  ]
  node [
    id 551
    label "E:WEARY FRAGMENT"
    kind "entity"
    name "WEARY FRAGMENT"
    community 22
  ]
  node [
    id 552
    label "E:WAVE-TOSSED DERELICT"
    kind "entity"
    name "WAVE-TOSSED DERELICT"
    community 22
  ]
  node [
    id 553
    label "E:FICKERING SMILE"
    kind "entity"
    name "FICKERING SMILE"
    community 22
  ]
  node [
    id 554
    label "E:WAN FEATURES"
    kind "entity"
    name "WAN FEATURES"
    community 22
  ]
  node [
    id 555
    label "U:Novel-40700_00023#4"
    kind "unit"
    chunk_id "Novel-40700_00023"
    text "Blore enters with a telegram, and Sheba says that Aunt Tidman does not flicker a smile at her, while Salome says she wouldn't be in her shoes for anything, and Sheba says 'Salt in her bed, Salome!'"
    community 22
  ]
  node [
    id 556
    label "E:AUNT TIDMAN"
    kind "entity"
    name "AUNT TIDMAN"
    community 22
  ]
  node [
    id 557
    label "E:SALT IN HER BED"
    kind "entity"
    name "SALT IN HER BED"
    community 22
  ]
  node [
    id 558
    label "E:AUNT TIDMAN DOES NOT FLICKER A SMILE AT ME"
    kind "entity"
    name "AUNT TIDMAN DOES NOT FLICKER A SMILE AT ME"
    community 22
  ]
  node [
    id 559
    label "E:I WOULD NOT BE IN HER SHOES FOR SOMETHING"
    kind "entity"
    name "I WOULD NOT BE IN HER SHOES FOR SOMETHING"
    community 22
  ]
  node [
    id 560
    label "C:Novel-40700_00024"
    kind "chunk"
    chunk_id "Novel-40700_00024"
  ]
  node [
    id 561
    label "U:Novel-40700_00024#0"
    kind "unit"
    chunk_id "Novel-40700_00024"
    text "Salome says she wouldn't be in her shoes for something, and Sheba responds that salt is in Salome's bed. Salome confirms both salt in her bed and a peg missing from the rattling window. The Dean announces that his aunt, Georgiana, slept at the Wheatsheaf inn in Durnstone last night and is arriving this morning. Salome and Sheba exclaim that she is coming today. The Dean instructs Blore to get the chaise ready. He then says he and Salome will drive to Durnstone to bring Aunt Georgiana over, and asks Sheba for his hat. The gate bell is heard, and the Dean is uncertain whether it is Georgiana arriving. Blore appears with a frightened look and says it is Mrs. Tidman. Mrs. Tidman enters, described as a jovial, noisy woman with masculine-style dress, including a billy cock hat and coaching coat, and she greets the Dean as 'Gus, my boy' and asks how he is."
    community 13
  ]
  node [
    id 562
    label "E:WHEATSHEAF"
    kind "entity"
    name "WHEATSHEAF"
    community 13
  ]
  node [
    id 563
    label "E:MRS. TIDMAN"
    kind "entity"
    name "MRS. TIDMAN"
    community 10
  ]
  node [
    id 564
    label "E:BILLY COCK HAT"
    kind "entity"
    name "BILLY COCK HAT"
    community 13
  ]
  node [
    id 565
    label "E:COACHING COAT"
    kind "entity"
    name "COACHING COAT"
    community 13
  ]
  node [
    id 566
    label "E:GUS"
    kind "entity"
    name "GUS"
    community 8
  ]
  node [
    id 567
    label "E:HAT"
    kind "entity"
    name "HAT"
    community 16
  ]
  node [
    id 568
    label "E:GATE BELL"
    kind "entity"
    name "GATE BELL"
    community 23
  ]
  node [
    id 569
    label "E:CHAISE"
    kind "entity"
    name "CHAISE"
    community 13
  ]
  node [
    id 570
    label "E:RATTLING WINDOW"
    kind "entity"
    name "RATTLING WINDOW"
    community 13
  ]
  node [
    id 571
    label "E:GEORGIANA TIDMAN SLEPT AT THE WHEATSHEAF IN DURNSTONE LAST NIGHT"
    kind "entity"
    name "GEORGIANA TIDMAN SLEPT AT THE WHEATSHEAF IN DURNSTONE LAST NIGHT"
    community 13
  ]
  node [
    id 572
    label "E:MRS. TIDMAN ARRIVED"
    kind "entity"
    name "MRS. TIDMAN ARRIVED"
    community 13
  ]
  node [
    id 573
    label "E:JOVIAL AND NOISY"
    kind "entity"
    name "JOVIAL AND NOISY"
    community 13
  ]
  node [
    id 574
    label "E:GUS, MY BOY"
    kind "entity"
    name "GUS, MY BOY"
    community 13
  ]
  node [
    id 575
    label "C:Novel-40700_00025"
    kind "chunk"
    chunk_id "Novel-40700_00025"
  ]
  node [
    id 576
    label "U:Novel-40700_00025#0"
    kind "unit"
    chunk_id "Novel-40700_00025"
    text "Gus, referred to as Augustin by the Dean, is addressed by Georgiana, who calls him 'my boy' and criticizes him for gaining too much weight, suggesting he should be given a ten-miler daily in a blanket. The Dean responds with dignity, calling Georgiana his dear sister."
    community 8
  ]
  node [
    id 577
    label "E:AUGUSTIN"
    kind "entity"
    name "AUGUSTIN"
    community 8
  ]
  node [
    id 578
    label "E:GEORGIANA"
    kind "entity"
    name "GEORGIANA"
    community -1
  ]
  node [
    id 579
    label "E:TEN-MILER"
    kind "entity"
    name "TEN-MILER"
    community 8
  ]
  node [
    id 580
    label "E:BLANKET"
    kind "entity"
    name "BLANKET"
    community 8
  ]
  node [
    id 581
    label "E:CORN"
    kind "entity"
    name "CORN"
    community 8
  ]
  node [
    id 582
    label "E:MY BOY"
    kind "entity"
    name "MY BOY"
    community 8
  ]
  node [
    id 583
    label "E:FLESH"
    kind "entity"
    name "FLESH"
    community 8
  ]
  node [
    id 584
    label "E:TEN-MILER IN A BLANKET"
    kind "entity"
    name "TEN-MILER IN A BLANKET"
    community 8
  ]
  node [
    id 585
    label "E:MY DEAR SISTER"
    kind "entity"
    name "MY DEAR SISTER"
    community 8
  ]
  node [
    id 586
    label "U:Novel-40700_00025#1"
    kind "unit"
    chunk_id "Novel-40700_00025"
    text "Georgiana asks Salome and Sheba to kiss her, then surveys them critically, touching each with the end of her cane. She inquires about their names, and Salome and Sheba respond by stating their names are Salome and Sheba respectively."
    community 18
  ]
  node [
    id 587
    label "E:CANES"
    kind "entity"
    name "CANES"
    community 18
  ]
  node [
    id 588
    label "E:NAMES"
    kind "entity"
    name "NAMES"
    community 18
  ]
  node [
    id 589
    label "E:AUNT"
    kind "entity"
    name "AUNT"
    community 18
  ]
  node [
    id 590
    label "E:TWO GIRLS"
    kind "entity"
    name "TWO GIRLS"
    community 18
  ]
  node [
    id 591
    label "E:END OF HER CANE"
    kind "entity"
    name "END OF HER CANE"
    community 18
  ]
  node [
    id 592
    label "U:Novel-40700_00025#2"
    kind "unit"
    chunk_id "Novel-40700_00025"
    text "Georgiana comments on Sheba's stable companion, suggesting it could give her a stone and then get its nose in front. The Dean objects, saying that Georgiana's well-intentioned but inappropriate illustrations are not followed by the children."
    community 16
  ]
  node [
    id 593
    label "E:STABLE COMPANION"
    kind "entity"
    name "STABLE COMPANION"
    community 16
  ]
  node [
    id 594
    label "E:ILLUSTRATIONS"
    kind "entity"
    name "ILLUSTRATIONS"
    community 16
  ]
  node [
    id 595
    label "E:COULD GIVE HER A STONE AND THEN GET HER NOSE IN FRONT"
    kind "entity"
    name "COULD GIVE HER A STONE AND THEN GET HER NOSE IN FRONT"
    community 16
  ]
  node [
    id 596
    label "E:WELL-INTENTIONED BUT INAPPROPRIATE ILLUSTRATIONS"
    kind "entity"
    name "WELL-INTENTIONED BUT INAPPROPRIATE ILLUSTRATIONS"
    community 16
  ]
  node [
    id 597
    label "U:Novel-40700_00025#3"
    kind "unit"
    chunk_id "Novel-40700_00025"
    text "Georgiana and the Dean reflect on their past, recalling that it has been nearly twenty years since they last shared corn together, and that since then they have both run many races, though they have never met in the same events."
    community 8
  ]
  node [
    id 598
    label "E:TWENTY YEARS"
    kind "entity"
    name "TWENTY YEARS"
    community 8
  ]
  node [
    id 599
    label "E:NEARLY TWENTY YEARS AGO"
    kind "entity"
    name "NEARLY TWENTY YEARS AGO"
    community 8
  ]
  node [
    id 600
    label "E:MANY RACES"
    kind "entity"
    name "MANY RACES"
    community 8
  ]
  node [
    id 601
    label "E:SAME EVENTS"
    kind "entity"
    name "SAME EVENTS"
    community 8
  ]
  node [
    id 602
    label "E:ESTRANGEMENT"
    kind "entity"
    name "ESTRANGEMENT"
    community 8
  ]
  node [
    id 603
    label "C:Novel-40700_00026"
    kind "chunk"
    chunk_id "Novel-40700_00026"
  ]
  node [
    id 604
    label "U:Novel-40700_00026#0"
    kind "unit"
    chunk_id "Novel-40700_00026"
    text "Since then, Georgiana and Gus have both run many races but have never competed in the same events. The world has treated them harshly at times, and they have been punished, pulled, and led down often, yet they remain sound in the wind. Gus is doing well and is currently competing neck-and-neck with his Bishop in the race. Georgiana has dropped out of the race because the mares do not last, and Gus has kindly provided her with a dry stable, a clean litter, and kept her out of the shafts of a 'Shrewsbury and Talbot' race."
    community 8
  ]
  node [
    id 605
    label "E:WORLD"
    kind "entity"
    name "WORLD"
    community 8
  ]
  node [
    id 606
    label "E:GEORGE TIDD"
    kind "entity"
    name "GEORGE TIDD"
    community 6
  ]
  node [
    id 607
    label "E:SHREWSBURY AND TALBOT"
    kind "entity"
    name "SHREWSBURY AND TALBOT"
    community 8
  ]
  node [
    id 608
    label "E:MARES"
    kind "entity"
    name "MARES"
    community 8
  ]
  node [
    id 609
    label "E:LITTER"
    kind "entity"
    name "LITTER"
    community 8
  ]
  node [
    id 610
    label "E:NECK-AND-NECK"
    kind "entity"
    name "NECK-AND-NECK"
    community 8
  ]
  node [
    id 611
    label "E:TONE"
    kind "entity"
    name "TONE"
    community 8
  ]
  node [
    id 612
    label "E:BISHOP"
    kind "entity"
    name "BISHOP"
    community 8
  ]
  node [
    id 613
    label "U:Novel-40700_00026#1"
    kind "unit"
    chunk_id "Novel-40700_00026"
    text "Sheba whispers to Salome that she does not quite understand Georgiana, but she likes Aunt Georgiana. Salome agrees and says she does not see Georgiana as a weary fragment or a chastened widow."
    community 8
  ]
  node [
    id 614
    label "E:CHASTENED WIDOW"
    kind "entity"
    name "CHASTENED WIDOW"
    community 8
  ]
  node [
    id 615
    label "C:Novel-40700_00027"
    kind "chunk"
    chunk_id "Novel-40700_00027"
  ]
  node [
    id 616
    label "U:Novel-40700_00027#0"
    kind "unit"
    chunk_id "Novel-40700_00027"
    text "George Tidd is a person known for setting things quite square in a palace or a puddle; his racing name is George Tidd, and his colors were crimson and black diamonds."
    community 6
  ]
  node [
    id 617
    label "E:CRIMSON AND BLACK DIAMONDS"
    kind "entity"
    name "CRIMSON AND BLACK DIAMONDS"
    community 6
  ]
  node [
    id 618
    label "U:Novel-40700_00027#1"
    kind "unit"
    chunk_id "Novel-40700_00027"
    text "Georgiana identifies herself as George Tidd and states that people at Newmarket will tell all about her; she produces a pocket-handkerchief that is crimson and black."
    community 6
  ]
  node [
    id 619
    label "E:NEWMARKET"
    kind "entity"
    name "NEWMARKET"
    community 6
  ]
  node [
    id 620
    label "E:POCKET-HANDKERCHIEF"
    kind "entity"
    name "POCKET-HANDKERCHIEF"
    community 6
  ]
  node [
    id 621
    label "U:Novel-40700_00027#2"
    kind "unit"
    chunk_id "Novel-40700_00027"
    text "The Dean expresses interest in Georgiana's letter, stating that the idea of abandoning sport and its mental distraction is finally abandoned, and Georgiana responds that her colors will not be seen at the post again."
    community 6
  ]
  node [
    id 622
    label "E:SPORT"
    kind "entity"
    name "SPORT"
    community 6
  ]
  node [
    id 623
    label "E:MENTAL DISTRACTION"
    kind "entity"
    name "MENTAL DISTRACTION"
    community 6
  ]
  node [
    id 624
    label "E:POST"
    kind "entity"
    name "POST"
    community 6
  ]
  node [
    id 625
    label "E:COLORS"
    kind "entity"
    name "COLORS"
    community 6
  ]
  node [
    id 626
    label "E:SPORT WAS FINALLY ABANDONED"
    kind "entity"
    name "SPORT WAS FINALLY ABANDONED"
    community 6
  ]
  node [
    id 627
    label "U:Novel-40700_00027#3"
    kind "unit"
    chunk_id "Novel-40700_00027"
    text "Georgiana says that the contemplation of sport as a mental distraction may be weaned from her over time, and the Dean responds with 'in time' before a visitor arrives."
    community 6
  ]
  node [
    id 628
    label "E:IN TIME"
    kind "entity"
    name "IN TIME"
    community 6
  ]
  node [
    id 629
    label "U:Novel-40700_00027#4"
    kind "unit"
    chunk_id "Novel-40700_00027"
    text "Georgiana announces that a visitor has arrived and will go upstairs to have a groom brought down; she instructs the girls to make the running and asks Augustin about the feeding time."
    community 13
  ]
  node [
    id 630
    label "E:LUNCHEON"
    kind "entity"
    name "LUNCHEON"
    community 13
  ]
  node [
    id 631
    label "E:ONE O'CLOCK"
    kind "entity"
    name "ONE O'CLOCK"
    community 13
  ]
  node [
    id 632
    label "C:Novel-40700_00028"
    kind "chunk"
    chunk_id "Novel-40700_00028"
  ]
  node [
    id 633
    label "U:Novel-40700_00028#0"
    kind "unit"
    chunk_id "Novel-40700_00028"
    text "Luncheon is served at one o'clock. Georgiana remarks that the air is fresh and expresses her pleasure at getting her nose-bag, then leaves with the girls. The Dean mentions that his sister Georgiana is widowed and feels disturbed by her arrival on the eve of the terrible races at St. Marvells. Blore enters with a card that reads 'Sir Tristram Mardon'. The Dean welcomes Mardon, noting that they haven't met since Oxford. Blore re-enters with Sir Tristram Mardon, a well-preserved man of about fifty with a ruddy face and jovial manner, typical of a thorough English sporting gentleman. Sir Tristram greets the Dean as 'Jedd' and calls them 'boys again' in a boisterous tone."
    community 13
  ]
  node [
    id 634
    label "E:OXFORD"
    kind "entity"
    name "OXFORD"
    community 13
  ]
  node [
    id 635
    label "E:NOSEBAG"
    kind "entity"
    name "NOSEBAG"
    community 13
  ]
  node [
    id 636
    label "E:SERENE ATMOSPHERE"
    kind "entity"
    name "SERENE ATMOSPHERE"
    community 13
  ]
  node [
    id 637
    label "E:TERIBLE RACES"
    kind "entity"
    name "TERIBLE RACES"
    community 13
  ]
  node [
    id 638
    label "E:RUDDY FACE"
    kind "entity"
    name "RUDDY FACE"
    community 13
  ]
  node [
    id 639
    label "E:JOVIAL MANNER"
    kind "entity"
    name "JOVIAL MANNER"
    community 13
  ]
  node [
    id 640
    label "E:THOROUGH ENGLISH SPORTING GENTLEMAN"
    kind "entity"
    name "THOROUGH ENGLISH SPORTING GENTLEMAN"
    community 13
  ]
  node [
    id 641
    label "E:FRESH"
    kind "entity"
    name "FRESH"
    community 13
  ]
  node [
    id 642
    label "E:GEORGIANA'S ARRIVAL ON THE EVE OF THE TERRIBLE RACES AT ST. MARVELLS"
    kind "entity"
    name "GEORGIANA'S ARRIVAL ON THE EVE OF THE TERRIBLE RACES AT ST. MARVELLS"
    community 13
  ]
  node [
    id 643
    label "E:CARD"
    kind "entity"
    name "CARD"
    community 13
  ]
  node [
    id 644
    label "E:JEDD"
    kind "entity"
    name "JEDD"
    community 13
  ]
  node [
    id 645
    label "E:BOYS AGAIN"
    kind "entity"
    name "BOYS AGAIN"
    community 13
  ]
  node [
    id 646
    label "U:Novel-40700_00028#1"
    kind "unit"
    chunk_id "Novel-40700_00028"
    text "The Dean and Sir Tristram Mardon, who haven't met since Oxford, greet each other warmly and refer to their past friendship as 'boys again'."
    community 13
  ]
  node [
    id 647
    label "C:Novel-40700_00029"
    kind "chunk"
    chunk_id "Novel-40700_00029"
  ]
  node [
    id 648
    label "U:Novel-40700_00029#0"
    kind "unit"
    chunk_id "Novel-40700_00029"
    text "Sir Tristram and the Dean are playing as boys, with Sir Tristram hitting the Dean violently in the chest, prompting the Dean to recall how rough Mardon used to be."
    community 11
  ]
  node [
    id 649
    label "E:SIR TRISTRAM"
    kind "entity"
    name "SIR TRISTRAM"
    community -1
  ]
  node [
    id 650
    label "E:BOYS"
    kind "entity"
    name "BOYS"
    community 11
  ]
  node [
    id 651
    label "E:MARDON"
    kind "entity"
    name "MARDON"
    community 11
  ]
  node [
    id 652
    label "E:ROUGH"
    kind "entity"
    name "ROUGH"
    community 11
  ]
  node [
    id 653
    label "U:Novel-40700_00029#1"
    kind "unit"
    chunk_id "Novel-40700_00029"
    text "Sir Tristram claims he is still a bachelor, having been terribly jilted by a woman years ago and has since lived in blinkers, and asks if the Dean is married."
    community 18
  ]
  node [
    id 654
    label "E:BLINKERS"
    kind "entity"
    name "BLINKERS"
    community 18
  ]
  node [
    id 655
    label "E:15 YEARS"
    kind "entity"
    name "15 YEARS"
    community 18
  ]
  node [
    id 656
    label "U:Novel-40700_00029#2"
    kind "unit"
    chunk_id "Novel-40700_00029"
    text "Sir Tristram expresses regret for reopening an old wound, and the Dean asks him to be quiet, Mardon, and says he is here for the races."
    community 6
  ]
  node [
    id 657
    label "E:OLD WOUND"
    kind "entity"
    name "OLD WOUND"
    community 6
  ]
  node [
    id 658
    label "E:PREACH NEXT SUNDAY"
    kind "entity"
    name "PREACH NEXT SUNDAY"
    community 6
  ]
  node [
    id 659
    label "C:Novel-40700_00030"
    kind "chunk"
    chunk_id "Novel-40700_00030"
  ]
  node [
    id 660
    label "U:Novel-40700_00030#0"
    kind "unit"
    chunk_id "Novel-40700_00030"
    text "Sir Tristram Mardon insists on participating in the races and mentions that his horse Dandy Dick, weighing nine stone two, will be ridden by Tom Gallawood. He asks the Dean to consider his colors&#8212;black and white with a pink cap&#8212;and claims that Bonny Betsy, a bay mare, cannot get down a steep hill with a boy on her back, noting that George Tidd knew she was strong when she stayed with Dandy Dick to the end."
    community 13
  ]
  node [
    id 661
    label "E:NINE STONE TWO"
    kind "entity"
    name "NINE STONE TWO"
    community 13
  ]
  node [
    id 662
    label "E:TOM GALLAWOOD"
    kind "entity"
    name "TOM GALLAWOOD"
    community 13
  ]
  node [
    id 663
    label "E:BLACK AND WHITE"
    kind "entity"
    name "BLACK AND WHITE"
    community 13
  ]
  node [
    id 664
    label "E:PINK CAP"
    kind "entity"
    name "PINK CAP"
    community 13
  ]
  node [
    id 665
    label "E:BONNY BETSY"
    kind "entity"
    name "BONNY BETSY"
    community 13
  ]
  node [
    id 666
    label "E:BAY MALE"
    kind "entity"
    name "BAY MALE"
    community 13
  ]
  node [
    id 667
    label "U:Novel-40700_00030#1"
    kind "unit"
    chunk_id "Novel-40700_00030"
    text "The Dean is surprised by the mention of George Tidd and expresses concern about the scandal involving Bonny Betsy, but Sir Tristram insists that the mare is capable of staying with Dandy Dick to the end, indicating that George Tidd had confidence in her performance."
    community 13
  ]
  node [
    id 668
    label "E:SCANDAL"
    kind "entity"
    name "SCANDAL"
    community 13
  ]
  node [
    id 669
    label "E:STAYING WITH DANDY DICK"
    kind "entity"
    name "STAYING WITH DANDY DICK"
    community 13
  ]
  node [
    id 670
    label "E:PERFORMANCE"
    kind "entity"
    name "PERFORMANCE"
    community 13
  ]
  node [
    id 671
    label "C:Novel-40700_00031"
    kind "chunk"
    chunk_id "Novel-40700_00031"
  ]
  node [
    id 672
    label "U:Novel-40700_00031#0"
    kind "unit"
    chunk_id "Novel-40700_00031"
    text "The Dean is aghast upon hearing that George is Tidd, and corrects the name to Georgiana Tidman. Sir Tristram states that Dandy came out of her stable after she was smashed. The Dean expresses surprise and says he is pleased to revive their old acquaintance, but cannot offer hospitality at the Deanery. Sir Tristram says he and his horse are at 'The Swan' and invites the Dean to come and look at Dandy Dick. The Dean explains that his position in St. Marvells limits his ability to offer hospitality. Sir Tristram misunderstands and thinks the Dean's colors do not show up well at the hill or at 'The Swan' Inn. The Dean recalls that in his youth he made the heaviest book on the Derby among their fellows and always lost. Sir Tristram remembers that the Dean once matched a mare of his own against a mare of Lord Beckslade's for fifty pounds, but the Dean clarifies that the mare was dreadfully beaten and not in the race."
    community 0
  ]
  node [
    id 673
    label "E:GEORGINA TIDMAN"
    kind "entity"
    name "GEORGINA TIDMAN"
    community 0
  ]
  node [
    id 674
    label "E:DANDY"
    kind "entity"
    name "DANDY"
    community 12
  ]
  node [
    id 675
    label "E:SWAN"
    kind "entity"
    name "SWAN"
    community 0
  ]
  node [
    id 676
    label "E:DERBY"
    kind "entity"
    name "DERBY"
    community 0
  ]
  node [
    id 677
    label "E:LORD BECKSLADE"
    kind "entity"
    name "LORD BECKSLADE"
    community 0
  ]
  node [
    id 678
    label "E:MARE"
    kind "entity"
    name "MARE"
    community 0
  ]
  node [
    id 679
    label "E:FIFTY POUNDS"
    kind "entity"
    name "FIFTY POUNDS"
    community 0
  ]
  node [
    id 680
    label "E:GEORGE"
    kind "entity"
    name "GEORGE"
    community 0
  ]
  node [
    id 681
    label "E:SHE WAS SMASHED"
    kind "entity"
    name "SHE WAS SMASHED"
    community 12
  ]
  node [
    id 682
    label "C:Novel-40700_00032"
    kind "chunk"
    chunk_id "Novel-40700_00032"
  ]
  node [
    id 683
    label "U:Novel-40700_00032#0"
    kind "unit"
    chunk_id "Novel-40700_00032"
    text "The Dean confirms that she was not in the incident, but was dreadfully beaten; Sir Tristram expresses sorrow over a promising young man ending in this way, and says he is only sorry, not offended."
    community 11
  ]
  node [
    id 684
    label "E:BEATEN"
    kind "entity"
    name "BEATEN"
    community 11
  ]
  node [
    id 685
    label "E:PROMISING LAD"
    kind "entity"
    name "PROMISING LAD"
    community 11
  ]
  node [
    id 686
    label "E:INCIDENT"
    kind "entity"
    name "INCIDENT"
    community 11
  ]
  node [
    id 687
    label "U:Novel-40700_00032#1"
    kind "unit"
    chunk_id "Novel-40700_00032"
    text "Georgiana enters with Salome and Sheba, all three laughing and chatting, appearing to be the best of friends; Sir Tristram is surprised to see 'Mr. Tidd' and roars with laughter."
    community 11
  ]
  node [
    id 688
    label "E:MR. TIDD"
    kind "entity"
    name "MR. TIDD"
    community 11
  ]
  node [
    id 689
    label "U:Novel-40700_00032#2"
    kind "unit"
    chunk_id "Novel-40700_00032"
    text "Sir Tristram asks the Dean if he has been chaffing him, and the Dean denies it; Sir Tristram says he has been roasting his old friend; the Dean responds with dignity, stating that Sir Tristram Mardon is a pal of his and that Mrs. Tidman is his sister."
    community 11
  ]
  node [
    id 690
    label "E:CHAFFING SIR TRISTRAM"
    kind "entity"
    name "CHAFFING SIR TRISTRAM"
    community 11
  ]
  node [
    id 691
    label "E:OLD FRIEND"
    kind "entity"
    name "OLD FRIEND"
    community 11
  ]
  node [
    id 692
    label "E:SIR TRISTRAM MARDON IS A PAL OF HIS"
    kind "entity"
    name "SIR TRISTRAM MARDON IS A PAL OF HIS"
    community 11
  ]
  node [
    id 693
    label "E:MRS. TIDMAN IS HIS SISTER"
    kind "entity"
    name "MRS. TIDMAN IS HIS SISTER"
    community 11
  ]
  node [
    id 694
    label "C:Novel-40700_00033"
    kind "chunk"
    chunk_id "Novel-40700_00033"
  ]
  node [
    id 695
    label "U:Novel-40700_00033#0"
    kind "unit"
    chunk_id "Novel-40700_00033"
    text "Sir Tristram Mardon states that Mrs. Tidman is his sister, and that the two horses Salome and Sheba are of the same stock and were foaled in the same stable. He points to Salome and Sheba to emphasize this connection, and mentions that there are yearlings among the horses, which are his nieces."
    community 10
  ]
  node [
    id 696
    label "E:SAME STOCK"
    kind "entity"
    name "SAME STOCK"
    community 10
  ]
  node [
    id 697
    label "E:SAME STABLE"
    kind "entity"
    name "SAME STABLE"
    community 10
  ]
  node [
    id 698
    label "E:YEARLINGS"
    kind "entity"
    name "YEARLINGS"
    community 10
  ]
  node [
    id 699
    label "E:NIECES"
    kind "entity"
    name "NIECES"
    community 10
  ]
  node [
    id 700
    label "U:Novel-40700_00033#1"
    kind "unit"
    chunk_id "Novel-40700_00033"
    text "Sir Tristram Mardon bows to Georgiana, calls her George, and says he is glad to see her despite not knowing her family connection, and mentions that he and Georgiana were at Oxford together."
    community 13
  ]
  node [
    id 701
    label "U:Novel-40700_00033#2"
    kind "unit"
    chunk_id "Novel-40700_00033"
    text "The Dean, in horror, calls Salome and Sheba children and says he must speak to them, then excuses himself to go into the garden, where he reflects on having a widowed sister and what to do about it."
    community 16
  ]
  node [
    id 702
    label "E:WIDOWED SISTER"
    kind "entity"
    name "WIDOWED SISTER"
    community 16
  ]
  node [
    id 703
    label "U:Novel-40700_00033#3"
    kind "unit"
    chunk_id "Novel-40700_00033"
    text "Sheba tells Salome that their father is like their pa, reacting in the same way when they are getting interested, and Salome agrees to come back in a minute, so they exit by the window."
    community 22
  ]
  node [
    id 704
    label "E:PA"
    kind "entity"
    name "PA"
    community 22
  ]
  node [
    id 705
    label "E:WINDOW"
    kind "entity"
    name "WINDOW"
    community 14
  ]
  node [
    id 706
    label "U:Novel-40700_00033#4"
    kind "unit"
    chunk_id "Novel-40700_00033"
    text "Sir Tristram says he won't have Georgiana staying with him because he is down in the area racing."
    community 13
  ]
  node [
    id 707
    label "E:RACING"
    kind "entity"
    name "RACING"
    community 13
  ]
  node [
    id 708
    label "E:DOWN HERE"
    kind "entity"
    name "DOWN HERE"
    community 13
  ]
  node [
    id 709
    label "C:Novel-40700_00034"
    kind "chunk"
    chunk_id "Novel-40700_00034"
  ]
  node [
    id 710
    label "U:Novel-40700_00034#0"
    kind "unit"
    chunk_id "Novel-40700_00034"
    text "Georgiana refuses to allow Sir Tristram to stay, stating he won't have him. Sir Tristram responds that he is down here racing and explains that he is a Dean. Georgiana challenges him by saying she will be a Dean too, offering to lay a thousand sovereigns on a gooseberry that she will be a Dean in the house. Sir Tristram suggests that the Dean is thinking of the Canons and the Bishop, and Georgiana replies that they are all right when cheered up. She promises to lunch on the hill with the Canons marking her card and the Bishop mixing the salad, and offers to make it all right with Augustin if asked. Sir Tristram declines, saying he is fixed at the 'Swan' with Dandy Dick. Georgiana expresses surprise at the mention of Dandy Dick, and Sir Tristram says he brought him down with lavender, noting that Dandy Dick runs for the Durnstone Handicap tomorrow. Georgiana states she knows little about the horse, but what she doesn't know she dreams. She asks if Dandy Dick is fit. Sir Tristram says the horse is as fit as a fiddle, shining like a mirror, and will romp in. Georgiana exclaims that he will dance in, calling Sir Tristram 'Tris Mardon' with surprise."
    community 8
  ]
  node [
    id 711
    label "E:CANONS"
    kind "entity"
    name "CANONS"
    community 8
  ]
  node [
    id 712
    label "E:LAVENDER"
    kind "entity"
    name "LAVENDER"
    community 8
  ]
  node [
    id 713
    label "E:DURNSTONE HANDICAP"
    kind "entity"
    name "DURNSTONE HANDICAP"
    community 0
  ]
  node [
    id 714
    label "E:GOOSEBERRY"
    kind "entity"
    name "GOOSEBERRY"
    community 8
  ]
  node [
    id 715
    label "E:AUTUMN MEETING"
    kind "entity"
    name "AUTUMN MEETING"
    community 8
  ]
  node [
    id 716
    label "E:LUNCHING ON THE HILL"
    kind "entity"
    name "LUNCHING ON THE HILL"
    community 8
  ]
  node [
    id 717
    label "E:MARKING CARD"
    kind "entity"
    name "MARKING CARD"
    community 8
  ]
  node [
    id 718
    label "E:MIXING SALAD"
    kind "entity"
    name "MIXING SALAD"
    community 8
  ]
  node [
    id 719
    label "E:THOUSAND SOVEREIGNS"
    kind "entity"
    name "THOUSAND SOVEREIGNS"
    community 8
  ]
  node [
    id 720
    label "E:FITNESS"
    kind "entity"
    name "FITNESS"
    community 8
  ]
  node [
    id 721
    label "E:ROMP"
    kind "entity"
    name "ROMP"
    community 8
  ]
  node [
    id 722
    label "E:DANCE"
    kind "entity"
    name "DANCE"
    community 8
  ]
  node [
    id 723
    label "E:FIDDLE"
    kind "entity"
    name "FIDDLE"
    community 8
  ]
  node [
    id 724
    label "E:MIRROR"
    kind "entity"
    name "MIRROR"
    community 8
  ]
  node [
    id 725
    label "E:HORSE"
    kind "entity"
    name "HORSE"
    community 12
  ]
  node [
    id 726
    label "E:DREAM"
    kind "entity"
    name "DREAM"
    community 8
  ]
  node [
    id 727
    label "E:CHEERED UP"
    kind "entity"
    name "CHEERED UP"
    community 8
  ]
  node [
    id 728
    label "E:HILL"
    kind "entity"
    name "HILL"
    community 6
  ]
  node [
    id 729
    label "E:WHAT SHE DOESN'T KNOW"
    kind "entity"
    name "WHAT SHE DOESN'T KNOW"
    community 8
  ]
  node [
    id 730
    label "E:TRIS MARDON"
    kind "entity"
    name "TRIS MARDON"
    community 8
  ]
  node [
    id 731
    label "C:Novel-40700_00035"
    kind "chunk"
    chunk_id "Novel-40700_00035"
  ]
  node [
    id 732
    label "U:Novel-40700_00035#0"
    kind "unit"
    chunk_id "Novel-40700_00035"
    text "Georgiana claims that Dandy Dick does not belong entirely to Sir Tristram, stating that he only owns half of the horse. Sir Tristram confirms he has a half share, which was acquired when Dandy Dick was sold at auction to John Fielder the trainer. Georgiana asserts that the other half belongs to her, explaining that she asked John Fielder to help her secure it after seeing Dandy Dick marched out before the auctioneer. She adds that she promised Augustin she would not own any animals with four legs, so John sold her half to Sir Tristram, and she claims she does not own a whole horse but insists that half a horse is better than no bread, and they are partners."
    community 0
  ]
  node [
    id 733
    label "E:JOHN FIELDER"
    kind "entity"
    name "JOHN FIELDER"
    community 0
  ]
  node [
    id 734
    label "E:HALF SHARE"
    kind "entity"
    name "HALF SHARE"
    community 0
  ]
  node [
    id 735
    label "E:SALE"
    kind "entity"
    name "SALE"
    community 0
  ]
  node [
    id 736
    label "E:AUCTIONEER"
    kind "entity"
    name "AUCTIONEER"
    community 0
  ]
  node [
    id 737
    label "E:PARTNERSHIP"
    kind "entity"
    name "PARTNERSHIP"
    community 0
  ]
  node [
    id 738
    label "E:ANY ANIMAL WITH FOUR LEGS"
    kind "entity"
    name "ANY ANIMAL WITH FOUR LEGS"
    community 0
  ]
  node [
    id 739
    label "E:WHOLE HORSE"
    kind "entity"
    name "WHOLE HORSE"
    community 0
  ]
  node [
    id 740
    label "E:NO BREAD"
    kind "entity"
    name "NO BREAD"
    community 0
  ]
  node [
    id 741
    label "U:Novel-40700_00035#1"
    kind "unit"
    chunk_id "Novel-40700_00035"
    text "Sir Tristram laughs loudly at Georgiana's statement, calling out about the Dean. Salome and Sheba enter unperceived. Sir Tristram continues to laugh and apologizes to Georgiana, saying he was distracted by the Dean."
    community 4
  ]
  node [
    id 742
    label "E:LAUGHTER"
    kind "entity"
    name "LAUGHTER"
    community 4
  ]
  node [
    id 743
    label "E:THEATER"
    kind "entity"
    name "THEATER"
    community 4
  ]
  node [
    id 744
    label "C:Novel-40700_00036"
    kind "chunk"
    chunk_id "Novel-40700_00036"
  ]
  node [
    id 745
    label "U:Novel-40700_00036#0"
    kind "unit"
    chunk_id "Novel-40700_00036"
    text "Georgiana laughs while apologizing to George, then states that since he is fit, he will be backed for the Durnstone Handicap, and adds that if she is not a richer woman by a thousand pounds by tomorrow night, she will have had a bad day. She expresses that she is willing to bet all her money on Dandy Dick for the race."
    community 0
  ]
  node [
    id 746
    label "E:1000 POUNDS"
    kind "entity"
    name "1000 POUNDS"
    community 20
  ]
  node [
    id 747
    label "E:TOMORROW NIGHT"
    kind "entity"
    name "TOMORROW NIGHT"
    community 0
  ]
  node [
    id 748
    label "U:Novel-40700_00036#1"
    kind "unit"
    chunk_id "Novel-40700_00036"
    text "Sheba and Salome enter the room, and Sheba tells Georgiana that Salome has something to say, but Salome corrects her, saying it is Sheba who has something to say. Georgiana notices that Sheba is shivering and calls her 'little un' before catching her hand."
    community 0
  ]
  node [
    id 749
    label "E:SHEBA'S SHIVERING"
    kind "entity"
    name "SHEBA'S SHIVERING"
    community 0
  ]
  node [
    id 750
    label "E:LITTLE UN"
    kind "entity"
    name "LITTLE UN"
    community 0
  ]
  node [
    id 751
    label "C:Novel-40700_00037"
    kind "chunk"
    chunk_id "Novel-40700_00037"
  ]
  node [
    id 752
    label "U:Novel-40700_00037#0"
    kind "unit"
    chunk_id "Novel-40700_00037"
    text "Georgiana catches hold of Sheba and says she is shivering. Sheba responds that they heard Georgiana mention a thousand pounds. Sheba expresses that a thousand pounds is a large amount and that they, as poor girls, want only a little. Georgiana confirms that the topic is money, and Sheba explains that Salome has gotten into debt. Georgiana reacts with surprise. Salome denies having any debt, stating she has no more than Sheba. Sheba says she is also in debt, but initially only asked for Salome, now asks for both. Sheba mentions that Papa told them Aunt Tidman has known troubles. Georgiana confirms she has had many troubles. Sheba says they are weary fragments and are everything awful but chastened widows, and that they owe forty pounds unknown to Pa. Salome states the amount is forty pounds, nineteen. Georgiana scolds them for crying and acting about forty pounds. Sheba says they only have fifteen and threepence of their own. Sheba asks Georgiana if she knows something about the Races."
    community 22
  ]
  node [
    id 753
    label "E:THOUSAND POUNDS"
    kind "entity"
    name "THOUSAND POUNDS"
    community 20
  ]
  node [
    id 754
    label "E:FOURTY POUNDS"
    kind "entity"
    name "FOURTY POUNDS"
    community 22
  ]
  node [
    id 755
    label "E:FIFTEEN AND THREE PENCE"
    kind "entity"
    name "FIFTEEN AND THREE PENCE"
    community 22
  ]
  node [
    id 756
    label "E:POOR GIRLS"
    kind "entity"
    name "POOR GIRLS"
    community 22
  ]
  node [
    id 757
    label "E:THEY"
    kind "entity"
    name "THEY"
    community 10
  ]
  node [
    id 758
    label "C:Novel-40700_00038"
    kind "chunk"
    chunk_id "Novel-40700_00038"
  ]
  node [
    id 759
    label "U:Novel-40700_00038#0"
    kind "unit"
    chunk_id "Novel-40700_00038"
    text "Aunt Georgiana is asked by Sheba and Salome if she knows something about horse races, and when she confirms that Dandy Dick is a horse, they request that he win them forty pounds, nineteen. Aunt Georgiana refuses, but the girls insist, and after being persuaded, she agrees to let them bet on Dandy Dick by putting their petticoats on him, which frightens them."
    community 17
  ]
  node [
    id 760
    label "E:40 POUNDS 19"
    kind "entity"
    name "40 POUNDS 19"
    community 17
  ]
  node [
    id 761
    label "E:50 POUNDS"
    kind "entity"
    name "50 POUNDS"
    community 17
  ]
  node [
    id 762
    label "E:HORSE RACES"
    kind "entity"
    name "HORSE RACES"
    community 17
  ]
  node [
    id 763
    label "E:BETTING ON DANDY DICK"
    kind "entity"
    name "BETTING ON DANDY DICK"
    community 17
  ]
  node [
    id 764
    label "E:BET ON DANDY DICK BY PUTTING PETTICOATS ON HIM"
    kind "entity"
    name "BET ON DANDY DICK BY PUTTING PETTICOATS ON HIM"
    community 17
  ]
  node [
    id 765
    label "E:PUTTING PETTICOATS ON DANDY DICK"
    kind "entity"
    name "PUTTING PETTICOATS ON DANDY DICK"
    community 17
  ]
  node [
    id 766
    label "U:Novel-40700_00038#1"
    kind "unit"
    chunk_id "Novel-40700_00038"
    text "In the morning-room at the Deanery, after dinner, Sheba is playing the piano, Salome is lounging on the settee, and Aunt Georgiana is pouring out tea."
    community 11
  ]
  node [
    id 767
    label "E:MORNING-ROOM AT THE DEANERY"
    kind "entity"
    name "MORNING-ROOM AT THE DEANERY"
    community 11
  ]
  node [
    id 768
    label "E:TEA"
    kind "entity"
    name "TEA"
    community 11
  ]
  node [
    id 769
    label "C:Novel-40700_00039"
    kind "chunk"
    chunk_id "Novel-40700_00039"
  ]
  node [
    id 770
    label "U:Novel-40700_00039#0"
    kind "unit"
    chunk_id "Novel-40700_00039"
    text "Sheba is playing the piano, Salome is lolling on the settee, and Georgianana is pouring out tea. They are dressed in evening dress. Georgianana calls Salome Sally and says the evening is too short for her name. Salome agrees and asks for two lumps of sugar. Georgianana asks Sheba if she is the little one, and Sheba replies she wants two lumps and one in the saucer to eat. Georgianana remarks that it is a relief to shake off the gentlemen, and Salome asks if she thinks so. Sheba says she does not think so. Georgianana notes that she understands why her foot was always in the way under the dinner table. She offers two cups to the girls, who take them. Salome says she thought the dinner was an overwhelming success. Sheba says all their dinners are held at the Deanery. Georgianana says it was awfully jolly but the mutton was overdone. Salome attributes the overdone mutton to the new cook's one failing. Georgianana says the potatoes were not bad&#8212;they rattled. Sheba says the cook never can manage potatoes. Georgianana asks what was wrong with the custards. Salome says it was the cook's first attempt at custards. Georgianana notes that despite this, the dinner served one useful end: they now know the chimney needs sweeping. Salome says the dinner was frightfully jolly overall. Sheba agrees, saying take it all round."
    community 11
  ]
  node [
    id 771
    label "E:SALLY"
    kind "entity"
    name "SALLY"
    community 11
  ]
  node [
    id 772
    label "E:EVENING DRESS"
    kind "entity"
    name "EVENING DRESS"
    community 11
  ]
  node [
    id 773
    label "E:SUGAR"
    kind "entity"
    name "SUGAR"
    community 11
  ]
  node [
    id 774
    label "E:LUMP"
    kind "entity"
    name "LUMP"
    community 11
  ]
  node [
    id 775
    label "E:SAUCER"
    kind "entity"
    name "SAUCER"
    community 11
  ]
  node [
    id 776
    label "E:MUTTON"
    kind "entity"
    name "MUTTON"
    community 11
  ]
  node [
    id 777
    label "E:POTATOES"
    kind "entity"
    name "POTATOES"
    community 11
  ]
  node [
    id 778
    label "E:CHIMNEY"
    kind "entity"
    name "CHIMNEY"
    community 11
  ]
  node [
    id 779
    label "E:FOOT"
    kind "entity"
    name "FOOT"
    community 11
  ]
  node [
    id 780
    label "E:CUPS"
    kind "entity"
    name "CUPS"
    community 11
  ]
  node [
    id 781
    label "E:OVERDONE"
    kind "entity"
    name "OVERDONE"
    community 11
  ]
  node [
    id 782
    label "E:RAVELLED"
    kind "entity"
    name "RAVELLED"
    community 11
  ]
  node [
    id 783
    label "E:FIRST ATTEMPT"
    kind "entity"
    name "FIRST ATTEMPT"
    community 11
  ]
  node [
    id 784
    label "E:NEEDS SWEEPING"
    kind "entity"
    name "NEEDS SWEEPING"
    community 11
  ]
  node [
    id 785
    label "E:JOLLY"
    kind "entity"
    name "JOLLY"
    community 11
  ]
  node [
    id 786
    label "E:DINNER-TABLE"
    kind "entity"
    name "DINNER-TABLE"
    community 11
  ]
  node [
    id 787
    label "E:OVERWHELMING SUCCESS"
    kind "entity"
    name "OVERWHELMING SUCCESS"
    community 11
  ]
  node [
    id 788
    label "E:AWFULLY JOLLY"
    kind "entity"
    name "AWFULLY JOLLY"
    community 11
  ]
  node [
    id 789
    label "E:NEW COOK"
    kind "entity"
    name "NEW COOK"
    community 11
  ]
  node [
    id 790
    label "E:COOK'S FIRST ATTEMPT"
    kind "entity"
    name "COOK'S FIRST ATTEMPT"
    community 11
  ]
  node [
    id 791
    label "E:SWEEPING"
    kind "entity"
    name "SWEEPING"
    community 11
  ]
  node [
    id 792
    label "E:FRIGHTFULLY JOLLY"
    kind "entity"
    name "FRIGHTFULLY JOLLY"
    community 11
  ]
  node [
    id 793
    label "E:TAKES IT ALL ROUND"
    kind "entity"
    name "TAKES IT ALL ROUND"
    community 11
  ]
  node [
    id 794
    label "C:Novel-40700_00040"
    kind "chunk"
    chunk_id "Novel-40700_00040"
  ]
  node [
    id 795
    label "U:Novel-40700_00040#0"
    kind "unit"
    chunk_id "Novel-40700_00040"
    text "SALOME, SHEBA, and GEORGIANA discuss a dinner that was described as frightfully jolly, with SHEBA noting that one must take things all round, and GEORGIANA questioning why they were all sad and silent despite the lively dinner."
    community 11
  ]
  node [
    id 796
    label "E:FRIGHTFULLY JOILY DINNER"
    kind "entity"
    name "FRIGHTFULLY JOILY DINNER"
    community 11
  ]
  node [
    id 797
    label "U:Novel-40700_00040#1"
    kind "unit"
    chunk_id "Novel-40700_00040"
    text "SHEBA says that Dear Papa was as lively as an owl with neuralgia, indicating he was energetic despite having neuralgia."
    community 5
  ]
  node [
    id 798
    label "E:OWL"
    kind "entity"
    name "OWL"
    community 5
  ]
  node [
    id 799
    label "E:NEURALGIA"
    kind "entity"
    name "NEURALGIA"
    community 5
  ]
  node [
    id 800
    label "U:Novel-40700_00040#2"
    kind "unit"
    chunk_id "Novel-40700_00040"
    text "GEORGIANA states that Major Tarver is not a conversational cracker, and SALOME adds that Gerald Tarver has no liver to speak of, suggesting he is unable to speak."
    community 1
  ]
  node [
    id 801
    label "E:TO SPEAK OF"
    kind "entity"
    name "TO SPEAK OF"
    community 1
  ]
  node [
    id 802
    label "U:Novel-40700_00040#3"
    kind "unit"
    chunk_id "Novel-40700_00040"
    text "GEORGIANA suggests that Gerald Tarver might have spoken about his lungs instead of his liver to cheer them up, implying a lack of speech due to liver issues."
    community 1
  ]
  node [
    id 803
    label "E:LUNGS"
    kind "entity"
    name "LUNGS"
    community 1
  ]
  node [
    id 804
    label "U:Novel-40700_00040#4"
    kind "unit"
    chunk_id "Novel-40700_00040"
    text "SHEBA recalls that Mr. Darbey was about to make a witty remark, but the servant handed him a dish and he shied at it, causing them to lose that moment of humor."
    community 5
  ]
  node [
    id 805
    label "E:SERVANT"
    kind "entity"
    name "SERVANT"
    community 5
  ]
  node [
    id 806
    label "E:WITTY REMARK"
    kind "entity"
    name "WITTY REMARK"
    community 5
  ]
  node [
    id 807
    label "E:DISH"
    kind "entity"
    name "DISH"
    community 5
  ]
  node [
    id 808
    label "E:SHIED"
    kind "entity"
    name "SHIED"
    community 5
  ]
  node [
    id 809
    label "U:Novel-40700_00040#5"
    kind "unit"
    chunk_id "Novel-40700_00040"
    text "SALOME and SHEBA agree that they should congratulate themselves on having a frightfully jolly dinner, and SHEBA confirms that once the house is silent, they will exit through the front door."
    community 11
  ]
  node [
    id 810
    label "E:FRONT DOOR"
    kind "entity"
    name "FRONT DOOR"
    community 11
  ]
  node [
    id 811
    label "U:Novel-40700_00040#6"
    kind "unit"
    chunk_id "Novel-40700_00040"
    text "SHEBA instructs that they will enter again by the window once the house is silent."
    community 14
  ]
  node [
    id 812
    label "U:Novel-40700_00040#7"
    kind "unit"
    chunk_id "Novel-40700_00040"
    text "GEORGIANA takes out her betting book to work out figures, stating that if Dandy Dick hasn't fed better at the 'Swan' than they have at the Deanery, he won't be in the first three."
    community 0
  ]
  node [
    id 813
    label "E:FIRST THREE"
    kind "entity"
    name "FIRST THREE"
    community 0
  ]
  node [
    id 814
    label "E:BETTING BOOK"
    kind "entity"
    name "BETTING BOOK"
    community 0
  ]
  node [
    id 815
    label "E:SWAN AND DEANERY"
    kind "entity"
    name "SWAN AND DEANERY"
    community 0
  ]
  node [
    id 816
    label "C:Novel-40700_00041"
    kind "chunk"
    chunk_id "Novel-40700_00041"
  ]
  node [
    id 817
    label "U:Novel-40700_00041#0"
    kind "unit"
    chunk_id "Novel-40700_00041"
    text "SALOME asks how they can enter again; SHEBA replies that they can use the window, which has a patent safety fastening and can be opened with a hairpin."
    community 14
  ]
  node [
    id 818
    label "E:PATENT SAFETY FASTENING"
    kind "entity"
    name "PATENT SAFETY FASTENING"
    community 14
  ]
  node [
    id 819
    label "E:HAIRPIN"
    kind "entity"
    name "HAIRPIN"
    community 14
  ]
  node [
    id 820
    label "U:Novel-40700_00041#1"
    kind "unit"
    chunk_id "Novel-40700_00041"
    text "SALOME says they are courageous girls; SHEBA agrees and states that they are not ordinary young ladies."
    community 5
  ]
  node [
    id 821
    label "E:COURAGEOUS GIRLS"
    kind "entity"
    name "COURAGEOUS GIRLS"
    community 5
  ]
  node [
    id 822
    label "E:ORDINARY YOUNG LADIES"
    kind "entity"
    name "ORDINARY YOUNG LADIES"
    community 5
  ]
  node [
    id 823
    label "E:SALOME AND SHEBA NOT ORDINARY YOUNG LADIES"
    kind "entity"
    name "SALOME AND SHEBA NOT ORDINARY YOUNG LADIES"
    community 5
  ]
  node [
    id 824
    label "U:Novel-40700_00041#2"
    kind "unit"
    chunk_id "Novel-40700_00041"
    text "SALOME reflects that if they had known Aunt longer, they might have confided in her and taken her with them; SHEBA says poor Aunt and that they mustn't spoil her."
    community 18
  ]
  node [
    id 825
    label "E:CONFIDED IN HER"
    kind "entity"
    name "CONFIDED IN HER"
    community 18
  ]
  node [
    id 826
    label "E:TOOK HER WITH THEM"
    kind "entity"
    name "TOOK HER WITH THEM"
    community 18
  ]
  node [
    id 827
    label "E:SPOIL HER"
    kind "entity"
    name "SPOIL HER"
    community 18
  ]
  node [
    id 828
    label "U:Novel-40700_00041#3"
    kind "unit"
    chunk_id "Novel-40700_00041"
    text "DARBEY, speaking from outside, says he differs with the Dean; GEORGIANA says he would come out in spots like measles if he tried to remember her name."
    community 5
  ]
  node [
    id 829
    label "E:WAX-WORKS"
    kind "entity"
    name "WAX-WORKS"
    community 5
  ]
  node [
    id 830
    label "E:DARBEY ENTERS"
    kind "entity"
    name "DARBEY ENTERS"
    community 5
  ]
  node [
    id 831
    label "U:Novel-40700_00041#4"
    kind "unit"
    chunk_id "Novel-40700_00041"
    text "THE DEAN tells SALOME and SHEBA that it is useless to battle against a feeling of positive distaste for Mr. Darbey; SALOME asks what he means by 'against what', and the Dean clarifies it is a feeling of distaste for Mr. Darbey."
    community 5
  ]
  node [
    id 832
    label "E:FEELING OF POSITIVE DISTASTE"
    kind "entity"
    name "FEELING OF POSITIVE DISTASTE"
    community 5
  ]
  node [
    id 833
    label "U:Novel-40700_00041#5"
    kind "unit"
    chunk_id "Novel-40700_00041"
    text "SHEBA says that Wellington was at his age, implying a comparison to the current situation; MAJOR TARVER enters, pale and haggard, and SALOME greets him."
    community 15
  ]
  node [
    id 834
    label "E:WELLINGTON"
    kind "entity"
    name "WELLINGTON"
    community 15
  ]
  node [
    id 835
    label "U:Novel-40700_00041#6"
    kind "unit"
    chunk_id "Novel-40700_00041"
    text "MAJOR TARVER gasps upon seeing SALOME and asks if she is not well again."
    community 1
  ]
  node [
    id 836
    label "E:SALOME IS NOT WELL AGAIN"
    kind "entity"
    name "SALOME IS NOT WELL AGAIN"
    community 1
  ]
  node [
    id 837
    label "C:Novel-40700_00042"
    kind "chunk"
    chunk_id "Novel-40700_00042"
  ]
  node [
    id 838
    label "U:Novel-40700_00042#0"
    kind "unit"
    chunk_id "Novel-40700_00042"
    text "Major Tarver gasps and says he is not well again, attributing it to indigestion, which he claims is always the case after dinner."
    community 1
  ]
  node [
    id 839
    label "E:INDIGESTION"
    kind "entity"
    name "INDIGESTION"
    community 1
  ]
  node [
    id 840
    label "U:Novel-40700_00042#1"
    kind "unit"
    chunk_id "Novel-40700_00042"
    text "Salome asks Major Tarver what he would do if the trumpet summoned him to battle, and Tarver replies that he would pack a few charcoal biscuits and go out."
    community 1
  ]
  node [
    id 841
    label "E:TRUMPET"
    kind "entity"
    name "TRUMPET"
    community 1
  ]
  node [
    id 842
    label "E:CHARCOAL BISCUITS"
    kind "entity"
    name "CHARCOAL BISCUITS"
    community 1
  ]
  node [
    id 843
    label "E:BATTLE"
    kind "entity"
    name "BATTLE"
    community 1
  ]
  node [
    id 844
    label "U:Novel-40700_00042#2"
    kind "unit"
    chunk_id "Novel-40700_00042"
    text "Georgiana says she has never studied the Army Guide, and Darby confirms that the Army has trained nurses, to which Georgiana asks if the Colonel would send one with a perambulator to fetch Major Tarver at half-past eight."
    community 15
  ]
  node [
    id 845
    label "E:ARMY NURSES"
    kind "entity"
    name "ARMY NURSES"
    community 15
  ]
  node [
    id 846
    label "E:PERAMBULATOR"
    kind "entity"
    name "PERAMBULATOR"
    community 15
  ]
  node [
    id 847
    label "E:COLONEL"
    kind "entity"
    name "COLONEL"
    community 15
  ]
  node [
    id 848
    label "E:HALF-PAST EIGHT"
    kind "entity"
    name "HALF-PAST EIGHT"
    community 15
  ]
  node [
    id 849
    label "U:Novel-40700_00042#3"
    kind "unit"
    chunk_id "Novel-40700_00042"
    text "Georgiana tells Darby that her boy, Gus, seems out of condition, and the Dean says he is anxious for the post to bring today's 'Times' and has offered a thousand pounds to the Restoration Fund."
    community 20
  ]
  node [
    id 850
    label "U:Novel-40700_00042#4"
    kind "unit"
    chunk_id "Novel-40700_00042"
    text "Tarver jumps up excitedly and sings to himself the line 'Come into the garden, Maud, for the black bat' to Salome, who remarks that he is now himself again."
    community 1
  ]
  node [
    id 851
    label "E:BLACK BAT"
    kind "entity"
    name "BLACK BAT"
    community 1
  ]
  node [
    id 852
    label "E:MAUD"
    kind "entity"
    name "MAUD"
    community 1
  ]
  node [
    id 853
    label "E:HIMSELF AGAIN"
    kind "entity"
    name "HIMSELF AGAIN"
    community 1
  ]
  node [
    id 854
    label "C:Novel-40700_00043"
    kind "chunk"
    chunk_id "Novel-40700_00043"
  ]
  node [
    id 855
    label "U:Novel-40700_00043#0"
    kind "unit"
    chunk_id "Novel-40700_00043"
    text "Tarver is excited when asked to sing, comparing the experience to a carbonate of soda lozenge. He states that his music is in his overcoat pocket. Sheba mentions that Mr. Darbey has brought his violin. Tarver, in rage, glares at Darbey and says he always presumes with his fiddle when he is going to entertain, noting that his fiddle is never hoarse but he is sometimes. Darbey, to himself, says Tarver always tries to cut him out with his elderly Chest C and that he ought to put it on the Retired List. Tarver declares he will sing Darbey off his legs that night and claims he is in lovely voice. He then walks into the library and sings 'Come into the garden, Maud'. Darbey, to himself, says Tarver needn't bother himself because while Tarver was dozing in the carriage, he threw Darbey's music out of the window. Tarver re-enters triumphantly, and Blore re-enters carrying a violin-case and a leather music roll."
    community 19
  ]
  node [
    id 856
    label "E:CARTE OF SODA LOZENGE"
    kind "entity"
    name "CARTE OF SODA LOZENGE"
    community 19
  ]
  node [
    id 857
    label "E:CHEST C"
    kind "entity"
    name "CHEST C"
    community 3
  ]
  node [
    id 858
    label "E:RETIRED LIST"
    kind "entity"
    name "RETIRED LIST"
    community 19
  ]
  node [
    id 859
    label "E:VIOLIN"
    kind "entity"
    name "VIOLIN"
    community 3
  ]
  node [
    id 860
    label "E:MUSIC"
    kind "entity"
    name "MUSIC"
    community 3
  ]
  node [
    id 861
    label "E:CARRIAGE"
    kind "entity"
    name "CARRIAGE"
    community 19
  ]
  node [
    id 862
    label "E:HALL"
    kind "entity"
    name "HALL"
    community 19
  ]
  node [
    id 863
    label "E:OVERCOAT POCKET"
    kind "entity"
    name "OVERCOAT POCKET"
    community 19
  ]
  node [
    id 864
    label "E:VIOLIN CASE"
    kind "entity"
    name "VIOLIN CASE"
    community 19
  ]
  node [
    id 865
    label "E:LEATHER MUSIC ROLL"
    kind "entity"
    name "LEATHER MUSIC ROLL"
    community 3
  ]
  node [
    id 866
    label "E:SING"
    kind "entity"
    name "SING"
    community 19
  ]
  node [
    id 867
    label "E:COME INTO THE GARDEN MAUD"
    kind "entity"
    name "COME INTO THE GARDEN MAUD"
    community 3
  ]
  node [
    id 868
    label "E:VIOLIN CASE AND LEATHER MUSIC ROLL"
    kind "entity"
    name "VIOLIN CASE AND LEATHER MUSIC ROLL"
    community 19
  ]
  node [
    id 869
    label "C:Novel-40700_00044"
    kind "chunk"
    chunk_id "Novel-40700_00044"
  ]
  node [
    id 870
    label "U:Novel-40700_00044#0"
    kind "unit"
    chunk_id "Novel-40700_00044"
    text "TARVER re-enters triumphantly. BLORE re-enters, carrying a violin-case and a leather music roll. DARBEY takes the violin-case, opens it, and produces his violin and music. BLORE hands the music roll to TARVER and goes out. TARVER, to SALOME, says his tones are like a beautiful bell this evening and that he is glad for all their sakes. He takes the music roll from BLORE and thanks him. SALOME asks what piece TARVER will begin with. TARVER replies that he has begun with 'Come into the garden, Maud' for years and years. He opens the music roll, which is empty, and exclaims that he has forgotten his music. SALOME and SHEBA respond with concern, saying 'Oh! Major Tarver!' TARVER sinks onto the settee in despair. SHEBA says never mind, Mr. Darbey will play. DARBEY tunes his violin and offers to play with SHEBA accompanying him to the end of the world. SHEBA sits at the piano. DARBEY says his mother believes his bowing is like Joachim's because she has heard Joachim. SHEBA asks why. DARBEY replies that she has heard Joachim. DARBEY begins to play and SHEBA accompanies him. SALOME sits beside TARVER."
    community 3
  ]
  node [
    id 871
    label "E:VIOLIN-CASE"
    kind "entity"
    name "VIOLIN-CASE"
    community 3
  ]
  node [
    id 872
    label "E:JOACHIM"
    kind "entity"
    name "JOACHIM"
    community 3
  ]
  node [
    id 873
    label "E:END OF THE WORLD"
    kind "entity"
    name "END OF THE WORLD"
    community 3
  ]
  node [
    id 874
    label "E:BOWING"
    kind "entity"
    name "BOWING"
    community 3
  ]
  node [
    id 875
    label "E:MOTHER"
    kind "entity"
    name "MOTHER"
    community 3
  ]
  node [
    id 876
    label "E:STAGE"
    kind "entity"
    name "STAGE"
    community 3
  ]
  node [
    id 877
    label "E:BEAUTIFUL BELL"
    kind "entity"
    name "BEAUTIFUL BELL"
    community 3
  ]
  node [
    id 878
    label "E:ALL THEIR SAKES"
    kind "entity"
    name "ALL THEIR SAKES"
    community 3
  ]
  node [
    id 879
    label "E:TO THE END OF THE WORLD"
    kind "entity"
    name "TO THE END OF THE WORLD"
    community 3
  ]
  node [
    id 880
    label "U:Novel-40700_00044#1"
    kind "unit"
    chunk_id "Novel-40700_00044"
    text "GEORGIANA is present at the scene."
    community 3
  ]
  node [
    id 881
    label "C:Novel-40700_00045"
    kind "chunk"
    chunk_id "Novel-40700_00045"
  ]
  node [
    id 882
    label "U:Novel-40700_00045#0"
    kind "unit"
    chunk_id "Novel-40700_00045"
    text "DARBEY plays and SHEBA accompanies him. SALOME sits beside TARVER. GEORGIANA thinks to herself that George, her boy, is not in a bad box and that this is a regular pure, simple, English Evening at Home."
    community 3
  ]
  node [
    id 883
    label "E:ENGLISH EVENING AT HOME"
    kind "entity"
    name "ENGLISH EVENING AT HOME"
    community 3
  ]
  node [
    id 884
    label "U:Novel-40700_00045#1"
    kind "unit"
    chunk_id "Novel-40700_00045"
    text "THE DEAN mumbles to himself about owing a thousand pounds to the Restoration Fund and having bills to settle, expressing concern over what he should do."
    community 20
  ]
  node [
    id 885
    label "U:Novel-40700_00045#2"
    kind "unit"
    chunk_id "Novel-40700_00045"
    text "SALOME hopes her ball-dress will make all other women mad."
    community 3
  ]
  node [
    id 886
    label "E:BALL-DRESS"
    kind "entity"
    name "BALL-DRESS"
    community 3
  ]
  node [
    id 887
    label "E:OTHER WOMEN"
    kind "entity"
    name "OTHER WOMEN"
    community 3
  ]
  node [
    id 888
    label "U:Novel-40700_00045#3"
    kind "unit"
    chunk_id "Novel-40700_00045"
    text "TARVER, glaring at DARBEY, says he would like to garrote him with his bass string."
    community 3
  ]
  node [
    id 889
    label "E:BASS STRING"
    kind "entity"
    name "BASS STRING"
    community 3
  ]
  node [
    id 890
    label "E:GARROTE"
    kind "entity"
    name "GARROTE"
    community 3
  ]
  node [
    id 891
    label "U:Novel-40700_00045#4"
    kind "unit"
    chunk_id "Novel-40700_00045"
    text "GEORGIANA, frowning at her betting book, decides to hedge a bit over the Crumbleigh Stakes."
    community 0
  ]
  node [
    id 892
    label "E:CRUMBLEIGH STAKES"
    kind "entity"
    name "CRUMBLEIGH STAKES"
    community 0
  ]
  node [
    id 893
    label "U:Novel-40700_00045#5"
    kind "unit"
    chunk_id "Novel-40700_00045"
    text "DARBEY, while playing, wonders how old Tarver's Chest C likes a holiday."
    community 3
  ]
  node [
    id 894
    label "E:HOLIDAY"
    kind "entity"
    name "HOLIDAY"
    community 3
  ]
  node [
    id 895
    label "U:Novel-40700_00045#6"
    kind "unit"
    chunk_id "Novel-40700_00045"
    text "SHEBA, while playing, says they must get Pa to bed early because Papa is always dreadfully in the way."
    community 22
  ]
  node [
    id 896
    label "E:BED"
    kind "entity"
    name "BED"
    community 22
  ]
  node [
    id 897
    label "E:IN THE WAY"
    kind "entity"
    name "IN THE WAY"
    community 22
  ]
  node [
    id 898
    label "U:Novel-40700_00045#7"
    kind "unit"
    chunk_id "Novel-40700_00045"
    text "GEORGIANA, looking around, says there's nothing like it in any other country, emphasizing it is a regular, pure, simple, English Evening at Home."
    community 3
  ]
  node [
    id 899
    label "E:OTHER COUNTRIES"
    kind "entity"
    name "OTHER COUNTRIES"
    community 3
  ]
  node [
    id 900
    label "U:Novel-40700_00045#8"
    kind "unit"
    chunk_id "Novel-40700_00045"
    text "BLORE enters quickly, cutting 'The Times' with a paper-knife, and the music stops abruptly; all the ladies glare at him and hush him down."
    community 20
  ]
  node [
    id 901
    label "E:PAPER-KNIFE"
    kind "entity"
    name "PAPER-KNIFE"
    community 20
  ]
  node [
    id 902
    label "E:LADIES"
    kind "entity"
    name "LADIES"
    community 20
  ]
  node [
    id 903
    label "C:Novel-40700_00046"
    kind "chunk"
    chunk_id "Novel-40700_00046"
  ]
  node [
    id 904
    label "U:Novel-40700_00046#0"
    kind "unit"
    chunk_id "Novel-40700_00046"
    text "The Dean takes a paper from Blore, admits it is his fault that there may be something of special interest in 'The Times', thanks Blore, and then scans the paper. He is surprised to find a mention of his anxiety being relieved by a munificent offer from seven wealthy people, including three brewers, who have each donated a thousand pounds to aid the restoration of the Minster Spire. He remarks that the relief will likely be felt only tomorrow and explains that the Spire is only slightly out of repair and not sufficiently so to warrant the involvement of three brewers."
    community 20
  ]
  node [
    id 905
    label "E:SEVEN WEALTHY PEOPLE"
    kind "entity"
    name "SEVEN WEALTHY PEOPLE"
    community 20
  ]
  node [
    id 906
    label "E:THREE BREWERS"
    kind "entity"
    name "THREE BREWERS"
    community 20
  ]
  node [
    id 907
    label "E:MINSTER SPIRE"
    kind "entity"
    name "MINSTER SPIRE"
    community 20
  ]
  node [
    id 908
    label "E:ANXIETY"
    kind "entity"
    name "ANXIETY"
    community 20
  ]
  node [
    id 909
    label "E:RELIEF"
    kind "entity"
    name "RELIEF"
    community 20
  ]
  node [
    id 910
    label "E:FRESH AIR"
    kind "entity"
    name "FRESH AIR"
    community 20
  ]
  node [
    id 911
    label "E:POSSIBLE SPECIAL INTEREST IN THE TIMES"
    kind "entity"
    name "POSSIBLE SPECIAL INTEREST IN THE TIMES"
    community 20
  ]
  node [
    id 912
    label "E:MENTION OF ANXIETY BEING RELIEVED"
    kind "entity"
    name "MENTION OF ANXIETY BEING RELIEVED"
    community 20
  ]
  node [
    id 913
    label "E:RESTORATION OF MINSTER SPIRE"
    kind "entity"
    name "RESTORATION OF MINSTER SPIRE"
    community 20
  ]
  node [
    id 914
    label "E:TOMORROW"
    kind "entity"
    name "TOMORROW"
    community 20
  ]
  node [
    id 915
    label "E:SLIGHTLY OUT OF REPAIR"
    kind "entity"
    name "SLIGHTLY OUT OF REPAIR"
    community 20
  ]
  node [
    id 916
    label "E:NOT SUFFICIENTLY WARRANTED"
    kind "entity"
    name "NOT SUFFICIENTLY WARRANTED"
    community 20
  ]
  node [
    id 917
    label "U:Novel-40700_00046#1"
    kind "unit"
    chunk_id "Novel-40700_00046"
    text "Georgiana questions the Dean about the Spire, asking what is wrong with it and whether nobody sleeps in it. The Dean responds that the Spire is only slightly out of repair and that the involvement of three brewers is not justified due to the minimal state of disrepair."
    community 20
  ]
  node [
    id 918
    label "E:WHETHER NOBODY SLEEPS IN IT"
    kind "entity"
    name "WHETHER NOBODY SLEEPS IN IT"
    community 20
  ]
  node [
    id 919
    label "E:NOT JUSTIFIED"
    kind "entity"
    name "NOT JUSTIFIED"
    community 20
  ]
  node [
    id 920
    label "C:Novel-40700_00047"
    kind "chunk"
    chunk_id "Novel-40700_00047"
  ]
  node [
    id 921
    label "U:Novel-40700_00047#0"
    kind "unit"
    chunk_id "Novel-40700_00047"
    text "A character says they will enjoy the fresh air and goes to the window, drawing back the curtains to see a bright red glare in the sky. The red glare is identified as a conflagration, and the characters GEORGIANA, SALOME, and SHEBA react with alarm, asking where the fire is and if they are safe. BLORE enters with a scared look and announces that the old Swan Inn is on fire. The gate-bell rings violently in the distance. Georgiana screeches and demands a hat, coat, and boots, instructing SALOME, SHEBA, and TARVER to go to the window. The DEAN stops Georgiana from leaving and tells her to respect herself, reminding her she is his sister and a lady. Georgiana insists she is not and declares she is going to help clear the stables at The Swan Inn."
    community 16
  ]
  node [
    id 922
    label "E:OLD SWAN INN"
    kind "entity"
    name "OLD SWAN INN"
    community 16
  ]
  node [
    id 923
    label "E:GATE-BELL"
    kind "entity"
    name "GATE-BELL"
    community 16
  ]
  node [
    id 924
    label "E:STABLES"
    kind "entity"
    name "STABLES"
    community 16
  ]
  node [
    id 925
    label "E:BOOTS"
    kind "entity"
    name "BOOTS"
    community 16
  ]
  node [
    id 926
    label "E:COAT"
    kind "entity"
    name "COAT"
    community 16
  ]
  node [
    id 927
    label "E:FIRE"
    kind "entity"
    name "FIRE"
    community 16
  ]
  node [
    id 928
    label "E:CONFLAGRATION"
    kind "entity"
    name "CONFLAGRATION"
    community 16
  ]
  node [
    id 929
    label "E:SKY"
    kind "entity"
    name "SKY"
    community 16
  ]
  node [
    id 930
    label "E:OLD SWAN INN IS ON FIRE"
    kind "entity"
    name "OLD SWAN INN IS ON FIRE"
    community 16
  ]
  node [
    id 931
    label "E:IN THE DISTANCE"
    kind "entity"
    name "IN THE DISTANCE"
    community 16
  ]
  node [
    id 932
    label "E:HAT AND COAT"
    kind "entity"
    name "HAT AND COAT"
    community 16
  ]
  node [
    id 933
    label "E:PAIR OF BOOTS"
    kind "entity"
    name "PAIR OF BOOTS"
    community 16
  ]
  node [
    id 934
    label "E:STABLES AT THE SWAN INN"
    kind "entity"
    name "STABLES AT THE SWAN INN"
    community 16
  ]
  node [
    id 935
    label "E:GEORGIANA SHE IS A LADY"
    kind "entity"
    name "GEORGIANA SHE IS A LADY"
    community 16
  ]
  node [
    id 936
    label "E:GEORGIANA FROM LEAVING"
    kind "entity"
    name "GEORGIANA FROM LEAVING"
    community 16
  ]
  node [
    id 937
    label "E:SCARED LOOK"
    kind "entity"
    name "SCARED LOOK"
    community 16
  ]
  node [
    id 938
    label "U:Novel-40700_00047#1"
    kind "unit"
    chunk_id "Novel-40700_00047"
    text "The characters GEORGIANA, SALOME, SHEBA, and TARVER are present at a scene where a fire at the old Swan Inn is discovered. The fire is described as a conflagration, and the characters express fear and ask where it is and if they are safe. BLORE reports the fire, and the gate-bell rings. Georgiana becomes agitated and demands clothing and boots, and insists on going to help at the stables. The DEAN tries to restrain her, reminding her of her status as a lady, but she refuses and declares her intent to help at the stables."
    community 16
  ]
  node [
    id 939
    label "C:Novel-40700_00048"
    kind "chunk"
    chunk_id "Novel-40700_00048"
  ]
  node [
    id 940
    label "U:Novel-40700_00048#0"
    kind "unit"
    chunk_id "Novel-40700_00048"
    text "The Dean reminds Georgiana of her identity as his sister, a lady. Georgiana insists that George Tidd is a man, not a woman. Sir Tristram rushes in breathlessly, and Georgiana rushes to him, clutching his coat. Sir Tristram, exhausted, responds with 'Oh!' Georgiana asks if the horse is safe, and Sir Tristram confirms it is safe and sound. Georgiana is surprised and remarks that the old horse has backed himself to win the handicap. She sinks into a chair. Tarver and Darby with Salome and Sheba stand looking out of the window. Sir Tristram says George's tail is singed a bit. Georgiana notes that the less weight the horse carries tomorrow will be beneficial. She begins to cry and says that dear old Dandy was never much to look at. Sir Tristram explains that the fools threw two pails of cold water over the horse to put out the fire. Georgiana says that is what has harmed the horse. The Dean asks Georgiana what a horse is, and she replies that a horse is a living example to a Dean. The Dean goes distractedly into the library. Georgiana asks where the animal is. Sir Tristram says his man Hatcham is running the horse up and down the lane to try to get it warm again. Georgiana asks where they will put the homeless beast now. Sir Tristram says he does not know."
    community 12
  ]
  node [
    id 941
    label "E:HANDICAP"
    kind "entity"
    name "HANDICAP"
    community 12
  ]
  node [
    id 942
    label "E:COLD WATER"
    kind "entity"
    name "COLD WATER"
    community 12
  ]
  node [
    id 943
    label "E:WARMING"
    kind "entity"
    name "WARMING"
    community 12
  ]
  node [
    id 944
    label "E:HOMELESS BEAST"
    kind "entity"
    name "HOMELESS BEAST"
    community 12
  ]
  node [
    id 945
    label "E:TAIL"
    kind "entity"
    name "TAIL"
    community 12
  ]
  node [
    id 946
    label "E:WEIGHT"
    kind "entity"
    name "WEIGHT"
    community 8
  ]
  node [
    id 947
    label "E:FOLKS"
    kind "entity"
    name "FOLKS"
    community 12
  ]
  node [
    id 948
    label "E:SAFE AND SOUND"
    kind "entity"
    name "SAFE AND SOUND"
    community 12
  ]
  node [
    id 949
    label "E:SINGED"
    kind "entity"
    name "SINGED"
    community 12
  ]
  node [
    id 950
    label "E:LIVING EXAMPLE TO A DEAN"
    kind "entity"
    name "LIVING EXAMPLE TO A DEAN"
    community 12
  ]
  node [
    id 951
    label "E:DEAR OLD DANDY"
    kind "entity"
    name "DEAR OLD DANDY"
    community 12
  ]
  node [
    id 952
    label "E:UP AND DOWN THE LANE"
    kind "entity"
    name "UP AND DOWN THE LANE"
    community 12
  ]
  node [
    id 953
    label "C:Novel-40700_00049"
    kind "chunk"
    chunk_id "Novel-40700_00049"
  ]
  node [
    id 954
    label "U:Novel-40700_00049#0"
    kind "unit"
    chunk_id "Novel-40700_00049"
    text "Georgiana proposes to bring Dandy Dick, the homeless beast, into their stables, suggesting that Sir Tristram will be the one to take Dandy out of the Swan and lead him into the Deanery."
    community 0
  ]
  node [
    id 955
    label "E:PARTNER"
    kind "entity"
    name "PARTNER"
    community 0
  ]
  node [
    id 956
    label "E:FLAMES"
    kind "entity"
    name "FLAMES"
    community 3
  ]
  node [
    id 957
    label "E:ONE PARTNER"
    kind "entity"
    name "ONE PARTNER"
    community 0
  ]
  node [
    id 958
    label "E:OTHER PARTNER"
    kind "entity"
    name "OTHER PARTNER"
    community 0
  ]
  node [
    id 959
    label "U:Novel-40700_00049#1"
    kind "unit"
    chunk_id "Novel-40700_00049"
    text "The Dean is distressed and appeals to Mardon, but Sir Tristram mocks him, and Georgiana mocks the Dean by saying she will only consider him after he has two pails of water thrown over him."
    community 11
  ]
  node [
    id 960
    label "E:PAILS OF WATER"
    kind "entity"
    name "PAILS OF WATER"
    community 11
  ]
  node [
    id 961
    label "U:Novel-40700_00049#2"
    kind "unit"
    chunk_id "Novel-40700_00049"
    text "Sir Tristram takes off his coat and throws it over Georgiana's shoulders, calling her a brick, and Georgiana quietly tells him that one partner pulls Dandy out of the Swan and the other leads Dandy into the Deanery, then they both leave."
    community 0
  ]
  node [
    id 962
    label "U:Novel-40700_00049#3"
    kind "unit"
    chunk_id "Novel-40700_00049"
    text "The Dean exclaims that he will be famous in the sporting papers for having Dandy Dick, and he walks into the library where Salome, Tarver, Darby, and Sheba enter from the window, and Tarver says they're getting the flames under."
    community 20
  ]
  node [
    id 963
    label "E:SPORTING PAPERS"
    kind "entity"
    name "SPORTING PAPERS"
    community 20
  ]
  node [
    id 964
    label "E:DEANERY STABLES"
    kind "entity"
    name "DEANERY STABLES"
    community 24
  ]
  node [
    id 965
    label "E:SIR TRISTRAM MARDON'S DANDY DICK"
    kind "entity"
    name "SIR TRISTRAM MARDON'S DANDY DICK"
    community 20
  ]
  node [
    id 966
    label "E:SPORTING DEAN"
    kind "entity"
    name "SPORTING DEAN"
    community 20
  ]
  node [
    id 967
    label "C:Novel-40700_00050"
    kind "chunk"
    chunk_id "Novel-40700_00050"
  ]
  node [
    id 968
    label "U:Novel-40700_00050#0"
    kind "unit"
    chunk_id "Novel-40700_00050"
    text "They are preparing to manage the flames. If Darbey had brought his goloshes, he would have been present at multiple locations."
    community 3
  ]
  node [
    id 969
    label "E:GOLOSHES"
    kind "entity"
    name "GOLOSHES"
    community 3
  ]
  node [
    id 970
    label "E:MULTIPLE LOCATIONS"
    kind "entity"
    name "MULTIPLE LOCATIONS"
    community 3
  ]
  node [
    id 971
    label "U:Novel-40700_00050#1"
    kind "unit"
    chunk_id "Novel-40700_00050"
    text "In the presence of civilians, the military exercises wise discretion by restraining themselves."
    community 10
  ]
  node [
    id 972
    label "E:MILITARY"
    kind "entity"
    name "MILITARY"
    community 10
  ]
  node [
    id 973
    label "E:CIVILIANS"
    kind "entity"
    name "CIVILIANS"
    community 10
  ]
  node [
    id 974
    label "E:WISE DISCRETION"
    kind "entity"
    name "WISE DISCRETION"
    community 10
  ]
  node [
    id 975
    label "E:RESTRAINING"
    kind "entity"
    name "RESTRAINING"
    community 10
  ]
  node [
    id 976
    label "E:PRESENCE OF CIVILIANS"
    kind "entity"
    name "PRESENCE OF CIVILIANS"
    community 10
  ]
  node [
    id 977
    label "U:Novel-40700_00050#2"
    kind "unit"
    chunk_id "Novel-40700_00050"
    text "Sheba tells Tarver and Darbey to leave so they can quiet the house, noting that poor Papa appears worried. Sheba and Salome express concern for Papa, and Salome calls out that Major Tarver and Mr. Darbey must go. The Dean arrives from the library and says he is very remiss. Tarver and Darbey shake hands, with Tarver calling the evening fascinating and Darbey calling it charming. Blore enters and tells Salome to hat the gate. Salome advises Papa not to risk the cold. Blore exits, followed by Sheba, Salome, and Tarver. Darbey returns to the Dean and suggests they meet on Monday, but the Dean refuses, saying he will not say Monday, and Darbey offers any time he likes."
    community 19
  ]
  node [
    id 978
    label "E:MONDAY"
    kind "entity"
    name "MONDAY"
    community 19
  ]
  node [
    id 979
    label "E:HAT THE GATE"
    kind "entity"
    name "HAT THE GATE"
    community 19
  ]
  node [
    id 980
    label "E:WORRIED"
    kind "entity"
    name "WORRIED"
    community 19
  ]
  node [
    id 981
    label "E:FASCINATING EVENING"
    kind "entity"
    name "FASCINATING EVENING"
    community 19
  ]
  node [
    id 982
    label "E:CHARMING"
    kind "entity"
    name "CHARMING"
    community 19
  ]
  node [
    id 983
    label "E:SHAKING HANDS"
    kind "entity"
    name "SHAKING HANDS"
    community 19
  ]
  node [
    id 984
    label "E:PAPA LOOKS WORRIED"
    kind "entity"
    name "PAPA LOOKS WORRIED"
    community 19
  ]
  node [
    id 985
    label "E:MAJOR TARVER AND MR. DARBEDY MUST GO"
    kind "entity"
    name "MAJOR TARVER AND MR. DARBEDY MUST GO"
    community 19
  ]
  node [
    id 986
    label "E:PAPA NOT TO RISK THE COLD"
    kind "entity"
    name "PAPA NOT TO RISK THE COLD"
    community 19
  ]
  node [
    id 987
    label "E:VERY REMISS"
    kind "entity"
    name "VERY REMISS"
    community 19
  ]
  node [
    id 988
    label "E:FASCINATING"
    kind "entity"
    name "FASCINATING"
    community 19
  ]
  node [
    id 989
    label "E:SALOME TO HAT THE GATE"
    kind "entity"
    name "SALOME TO HAT THE GATE"
    community 19
  ]
  node [
    id 990
    label "E:DEAN ON MONDAY"
    kind "entity"
    name "DEAN ON MONDAY"
    community 19
  ]
  node [
    id 991
    label "C:Novel-40700_00051"
    kind "chunk"
    chunk_id "Novel-40700_00051"
  ]
  node [
    id 992
    label "U:Novel-40700_00051#0"
    kind "unit"
    chunk_id "Novel-40700_00051"
    text "The Dean restrains his anger and says he will not say Monday; Darbey agrees to any time and offers to get fellow patrons to support him when the Dean preaches. The Dean later reflects that if he had not restrained himself, he might have been violently rude to Darbey, a guest under his roof. Darbey returns to the room with his violin and demands it back, leaving with dignity. The Dean runs after Darbey, horrified, to explain. Georgiana and Sir Tristram enter through the window. Georgiana comforts Sir Tristram, saying he will recover from the chill and that Darbey recognized her when she kissed his nose. Sir Tristram says he would be a fool of a horse if he hadn't felt flattered by the kiss. Georgiana says Darbey knows he is in the Deanery too."
    community 19
  ]
  node [
    id 993
    label "E:PREACH"
    kind "entity"
    name "PREACH"
    community 19
  ]
  node [
    id 994
    label "E:FELLOW PATRONAGE"
    kind "entity"
    name "FELLOW PATRONAGE"
    community 19
  ]
  node [
    id 995
    label "E:CHILL"
    kind "entity"
    name "CHILL"
    community 7
  ]
  node [
    id 996
    label "U:Novel-40700_00051#1"
    kind "unit"
    chunk_id "Novel-40700_00051"
    text "The Dean declares that if Mr. Darbey ever returns to the Deanery, he will not see him again."
    community 0
  ]
  node [
    id 997
    label "C:Novel-40700_00052"
    kind "chunk"
    chunk_id "Novel-40700_00052"
  ]
  node [
    id 998
    label "U:Novel-40700_00052#0"
    kind "unit"
    chunk_id "Novel-40700_00052"
    text "Georgiana says that George is not a fool and knows he is in the Deanery; she notes that when she led him in, he raised his eyes and laid his ears back. Sir Tristram expresses pity about George's tail, to which Georgiana replies that watching his head the next day will be more revealing. Hatcham, a groom, enters and asks if they are there; Sir Tristram responds that he is not. Hatcham reports that Dandy is eating steadily, like a baby with a bottle. Georgiana tells him not to close his eyes all night. Hatcham says he does not, and that he has secured the constable, Mr. Topping, to sit with him for company's sake. Sir Tristram asks about the constable, and Hatcham reveals that he is considering the possibility that the fire at the 'Swan' was not an accident but incenderism, and that their horse, Dandy, might have been the object. Sir Tristram is shocked, and Hatcham explains that is why he is not going to watch alone. Sir Tristram orders Hatcham to leave, and both Georgiana and Sir Tristram pace up and down excitedly. Hatcham concludes by stating that there is only one mortal fear he has about Dandy."
    community 12
  ]
  node [
    id 999
    label "E:INCENDERISM"
    kind "entity"
    name "INCENDERISM"
    community 12
  ]
  node [
    id 1000
    label "E:MR. TOPPING"
    kind "entity"
    name "MR. TOPPING"
    community 12
  ]
  node [
    id 1001
    label "E:BABY WITH A BOTTLE"
    kind "entity"
    name "BABY WITH A BOTTLE"
    community 12
  ]
  node [
    id 1002
    label "E:EYES"
    kind "entity"
    name "EYES"
    community 12
  ]
  node [
    id 1003
    label "E:EARS"
    kind "entity"
    name "EARS"
    community 12
  ]
  node [
    id 1004
    label "E:HEAD"
    kind "entity"
    name "HEAD"
    community 12
  ]
  node [
    id 1005
    label "E:CLOSED EYES"
    kind "entity"
    name "CLOSED EYES"
    community 12
  ]
  node [
    id 1006
    label "E:COMPANY"
    kind "entity"
    name "COMPANY"
    community 12
  ]
  node [
    id 1007
    label "E:MORTAL FEAR"
    kind "entity"
    name "MORTAL FEAR"
    community 12
  ]
  node [
    id 1008
    label "E:GEORGE RAISED HIS EYES AND LAID HIS EARS BACK"
    kind "entity"
    name "GEORGE RAISED HIS EYES AND LAID HIS EARS BACK"
    community 12
  ]
  node [
    id 1009
    label "E:GEORGE'S TAIL"
    kind "entity"
    name "GEORGE'S TAIL"
    community 12
  ]
  node [
    id 1010
    label "E:GEORGE'S HEAD THE NEXT DAY WILL BE REVEALING"
    kind "entity"
    name "GEORGE'S HEAD THE NEXT DAY WILL BE REVEALING"
    community 12
  ]
  node [
    id 1011
    label "E:HATCHAM'S QUESTION"
    kind "entity"
    name "HATCHAM'S QUESTION"
    community 12
  ]
  node [
    id 1012
    label "E:DANDY IS EATING STEADILY"
    kind "entity"
    name "DANDY IS EATING STEADILY"
    community 12
  ]
  node [
    id 1013
    label "E:EYES ALL NIGHT"
    kind "entity"
    name "EYES ALL NIGHT"
    community 12
  ]
  node [
    id 1014
    label "E:FIRE AT THE SWAN"
    kind "entity"
    name "FIRE AT THE SWAN"
    community 12
  ]
  node [
    id 1015
    label "E:HATCHAM'S SUGGESTION"
    kind "entity"
    name "HATCHAM'S SUGGESTION"
    community 12
  ]
  node [
    id 1016
    label "E:HATCHAM TO LEAVE"
    kind "entity"
    name "HATCHAM TO LEAVE"
    community 12
  ]
  node [
    id 1017
    label "U:Novel-40700_00052#1"
    kind "unit"
    chunk_id "Novel-40700_00052"
    text "Hatcham, a groom, expresses concern about Dandy, stating that there is only one mortal fear he has about the horse."
    community 12
  ]
  node [
    id 1018
    label "C:Novel-40700_00053"
    kind "chunk"
    chunk_id "Novel-40700_00053"
  ]
  node [
    id 1019
    label "U:Novel-40700_00053#0"
    kind "unit"
    chunk_id "Novel-40700_00053"
    text "Georgiana and Sir Tristram discuss their Dandy, a horse, and express concern that the horse has not yet discovered it has a tail, and when it does, it will be distressed. Hatcham, a stable hand, confirms this and warns that the horse, being proud, will be ashamed of itself when it discovers the tail is missing, and suggests keeping the stable dark to prevent the horse from noticing. They consider how the horse's bereavement will affect it, noting that the horse would not understand how to hide its lack of a tail, unlike humans who can conceal such things."
    community 12
  ]
  node [
    id 1020
    label "E:PRIDE"
    kind "entity"
    name "PRIDE"
    community 12
  ]
  node [
    id 1021
    label "E:BEREAVEMENT"
    kind "entity"
    name "BEREAVEMENT"
    community 12
  ]
  node [
    id 1022
    label "E:DARKNESS"
    kind "entity"
    name "DARKNESS"
    community 12
  ]
  node [
    id 1023
    label "E:HUMAN"
    kind "entity"
    name "HUMAN"
    community 12
  ]
  node [
    id 1024
    label "E:TAIL IS DISCOVERED"
    kind "entity"
    name "TAIL IS DISCOVERED"
    community 12
  ]
  node [
    id 1025
    label "E:DANDY WILL BE ASHAMED"
    kind "entity"
    name "DANDY WILL BE ASHAMED"
    community 12
  ]
  node [
    id 1026
    label "E:STABLE DARK"
    kind "entity"
    name "STABLE DARK"
    community 12
  ]
  node [
    id 1027
    label "U:Novel-40700_00053#1"
    kind "unit"
    chunk_id "Novel-40700_00053"
    text "The Dean enters the room with Blore, who carries a lighted lantern. The Dean reproaches Georgiana for returning, and asks about the horse. Georgiana replies that the horse is in the stables, safe and secure. The Dean groans and says they are locking up, as the children, exhausted from the alarm, ask him to say good-night. He adds that the fire is now extinguished."
    community 16
  ]
  node [
    id 1028
    label "E:ALARM"
    kind "entity"
    name "ALARM"
    community 16
  ]
  node [
    id 1029
    label "E:GOOD-NIGHT"
    kind "entity"
    name "GOOD-NIGHT"
    community 16
  ]
  node [
    id 1030
    label "E:LOCKING UP"
    kind "entity"
    name "LOCKING UP"
    community 16
  ]
  node [
    id 1031
    label "E:HORSE IS IN STABLES"
    kind "entity"
    name "HORSE IS IN STABLES"
    community 16
  ]
  node [
    id 1032
    label "E:EXTINGUISHED"
    kind "entity"
    name "EXTINGUISHED"
    community 16
  ]
  node [
    id 1033
    label "C:Novel-40700_00054"
    kind "chunk"
    chunk_id "Novel-40700_00054"
  ]
  node [
    id 1034
    label "U:Novel-40700_00054#0"
    kind "unit"
    chunk_id "Novel-40700_00054"
    text "The fire is quite extinguished. Blore reports that military personnel have been sent to Durnstone to watch the ruins in case of another outbreak, which will stop the wicked Ball at the Hathanaeum."
    community 10
  ]
  node [
    id 1035
    label "E:RUINS"
    kind "entity"
    name "RUINS"
    community 10
  ]
  node [
    id 1036
    label "E:ANOTHER OUTBREAK"
    kind "entity"
    name "ANOTHER OUTBREAK"
    community 10
  ]
  node [
    id 1037
    label "E:WICKED BALL"
    kind "entity"
    name "WICKED BALL"
    community 10
  ]
  node [
    id 1038
    label "E:HATHANAEUM"
    kind "entity"
    name "HATHANAEUM"
    community 10
  ]
  node [
    id 1039
    label "U:Novel-40700_00054#1"
    kind "unit"
    chunk_id "Novel-40700_00054"
    text "Georgiana suggests stowing Sir Tristram in the old nursery, which has Sheba's little cot still standing, to avoid pitching him out of his loft. She notes there are toys there for playing if he wakes early."
    community 8
  ]
  node [
    id 1040
    label "E:OLD NURSERY"
    kind "entity"
    name "OLD NURSERY"
    community 8
  ]
  node [
    id 1041
    label "E:SHEBA'S LITTLE COT"
    kind "entity"
    name "SHEBA'S LITTLE COT"
    community 8
  ]
  node [
    id 1042
    label "E:TOYS"
    kind "entity"
    name "TOYS"
    community 8
  ]
  node [
    id 1043
    label "E:LOFT"
    kind "entity"
    name "LOFT"
    community 8
  ]
  node [
    id 1044
    label "U:Novel-40700_00054#2"
    kind "unit"
    chunk_id "Novel-40700_00054"
    text "Georgiana instructs Blore to put Sir Tristram to bed carefully in the nursery. Sir Tristram says good-night to the Dean and claims he is too tired for a game of Piquet."
    community 16
  ]
  node [
    id 1045
    label "E:NURSERY"
    kind "entity"
    name "NURSERY"
    community 16
  ]
  node [
    id 1046
    label "E:PIQUET"
    kind "entity"
    name "PIQUET"
    community 16
  ]
  node [
    id 1047
    label "C:Novel-40700_00055"
    kind "chunk"
    chunk_id "Novel-40700_00055"
  ]
  node [
    id 1048
    label "U:Novel-40700_00055#0"
    kind "unit"
    chunk_id "Novel-40700_00055"
    text "The speaker, THE DEAN, states that he is not playing cards that night and adds that he never plays cards. SIR TRISTRAM responds by saying he will teach THE DEAN to play during his stay at the Deanery, and THE DEAN expresses relief that SIR TRISTRAM is staying with him."
    community 21
  ]
  node [
    id 1049
    label "E:CARDS"
    kind "entity"
    name "CARDS"
    community 21
  ]
  node [
    id 1050
    label "U:Novel-40700_00055#1"
    kind "unit"
    chunk_id "Novel-40700_00055"
    text "SIR TRISTRAM says good-night to GEORGIANA, who replies with good-night and expresses a blessing for the little child in the cot. GEORGIANA then calls out to SIR TRISTRAM to take his pipe with him, saying they will smoke all over the Deanery."
    community 0
  ]
  node [
    id 1051
    label "E:PIPE"
    kind "entity"
    name "PIPE"
    community 0
  ]
  node [
    id 1052
    label "E:LITTLE INNOCENT"
    kind "entity"
    name "LITTLE INNOCENT"
    community 0
  ]
  node [
    id 1053
    label "U:Novel-40700_00055#2"
    kind "unit"
    chunk_id "Novel-40700_00055"
    text "THE DEAN says he never smokes, but questions whether GEORGIANA does. GEORGIANA hums merrily and then says to THE DEAN, 'Gus, I don't like your looks, I shall let the Vet see you in the morning. What's wrong with you?' THE DEAN shakes his head mournfully and sinks on the settee."
    community 2
  ]
  node [
    id 1054
    label "E:VET"
    kind "entity"
    name "VET"
    community 2
  ]
  node [
    id 1055
    label "E:SMOKING"
    kind "entity"
    name "SMOKING"
    community 2
  ]
  node [
    id 1056
    label "U:Novel-40700_00055#3"
    kind "unit"
    chunk_id "Novel-40700_00055"
    text "GEORGIANA asks THE DEAN if he has money, and THE DEAN says there are bills that he will eventually pay. GEORGIANA asks if he is short, and THE DEAN responds that he is not short but rather 'stumped-out of coin' and 'run low', and that very little would settle the bills."
    community 2
  ]
  node [
    id 1057
    label "E:COIN"
    kind "entity"
    name "COIN"
    community 2
  ]
  node [
    id 1058
    label "C:Novel-40700_00056"
    kind "chunk"
    chunk_id "Novel-40700_00056"
  ]
  node [
    id 1059
    label "U:Novel-40700_00056#0"
    kind "unit"
    chunk_id "Novel-40700_00056"
    text "The Dean believes that very little would settle the bills, but he claims there are many estimable worthy men who do not possess a thousand pounds, and he includes himself in that number."
    community 20
  ]
  node [
    id 1060
    label "E:ESTIMABLE WORTHY MEN"
    kind "entity"
    name "ESTIMABLE WORTHY MEN"
    community 20
  ]
  node [
    id 1061
    label "U:Novel-40700_00056#1"
    kind "unit"
    chunk_id "Novel-40700_00056"
    text "Georgiana asks when the settling day will be, and the Dean responds that unless the restoration is immediately started, the spire will certainly crumble."
    community 8
  ]
  node [
    id 1062
    label "E:RESTORATION"
    kind "entity"
    name "RESTORATION"
    community 8
  ]
  node [
    id 1063
    label "E:SPIRE"
    kind "entity"
    name "SPIRE"
    community 8
  ]
  node [
    id 1064
    label "E:SETTLING DAY"
    kind "entity"
    name "SETTLING DAY"
    community 8
  ]
  node [
    id 1065
    label "E:SPIRE FROM CRUMBLING"
    kind "entity"
    name "SPIRE FROM CRUMBLING"
    community 8
  ]
  node [
    id 1066
    label "U:Novel-40700_00056#2"
    kind "unit"
    chunk_id "Novel-40700_00056"
    text "Georgiana suggests a match between the Dean and the spire, stating that whichever parts first will settle the bills, and asks Gus if he will let his little sister lend him a hand."
    community 8
  ]
  node [
    id 1067
    label "E:LITTLE SISTER"
    kind "entity"
    name "LITTLE SISTER"
    community 8
  ]
  node [
    id 1068
    label "E:LITTLE SISTER TO LEND A HAND"
    kind "entity"
    name "LITTLE SISTER TO LEND A HAND"
    community 8
  ]
  node [
    id 1069
    label "U:Novel-40700_00056#3"
    kind "unit"
    chunk_id "Novel-40700_00056"
    text "Georgiana whispers to the Dean and asks if he can raise fifty pounds by to-morrow morning, and the Dean agrees to raise more than fifty pounds."
    community 0
  ]
  node [
    id 1070
    label "E:TO-MORROW MORNING"
    kind "entity"
    name "TO-MORROW MORNING"
    community 0
  ]
  node [
    id 1071
    label "E:MORE THAN FIFTY POUNDS"
    kind "entity"
    name "MORE THAN FIFTY POUNDS"
    community 0
  ]
  node [
    id 1072
    label "U:Novel-40700_00056#4"
    kind "unit"
    chunk_id "Novel-40700_00056"
    text "Georgiana decides to have the fifty pounds 'clapped on to Dandy Dick', which shocks the Dean."
    community 0
  ]
  node [
    id 1073
    label "C:Novel-40700_00057"
    kind "chunk"
    chunk_id "Novel-40700_00057"
  ]
  node [
    id 1074
    label "U:Novel-40700_00057#0"
    kind "unit"
    chunk_id "Novel-40700_00057"
    text "Georgiana decides to clap a certain item on Dandy Dick, claiming he is a moral certainty despite the water buckets and his tail coming down the hill, and emphasizes that there is nothing like him in terms of weight. She instructs Gus to keep the matter secret from the Canons and Archdeacons, warning they would shorten the price if they found out. Georgiana tells Gus to take his poor widowed sister's tip and sleep peacefully. She then presses him warmly and kisses him. The Dean, horrified, asks Mrs. Tidman to go to her room. Georgiana calls Augustin, and the Dean says he will try to find words in the morning to express his horror regarding her proposal, but for now, he treats her as his parents' child and trusts her bed is well aired. Georgiana agrees and says she has done all she can for the Spire, then says good night to Augustin. She adds that if he is wiser in the morning, he should send Blore to the race course so he can put the money on for him. The Dean replies that his poor devoted old servant Blore would be lost on a race course. Georgiana responds with surprise, saying 'Would he!'"
    community 8
  ]
  node [
    id 1075
    label "E:TWO BUCKETS OF WATER"
    kind "entity"
    name "TWO BUCKETS OF WATER"
    community 8
  ]
  node [
    id 1076
    label "E:TAIL COMING DOWN THE HILL"
    kind "entity"
    name "TAIL COMING DOWN THE HILL"
    community 8
  ]
  node [
    id 1077
    label "E:ARCHDEACONS"
    kind "entity"
    name "ARCHDEACONS"
    community 8
  ]
  node [
    id 1078
    label "E:MORAL"
    kind "entity"
    name "MORAL"
    community 8
  ]
  node [
    id 1079
    label "E:RACE COURSE"
    kind "entity"
    name "RACE COURSE"
    community 8
  ]
  node [
    id 1080
    label "E:PROPOSAL"
    kind "entity"
    name "PROPOSAL"
    community 8
  ]
  node [
    id 1081
    label "E:WISER"
    kind "entity"
    name "WISER"
    community 8
  ]
  node [
    id 1082
    label "E:OLD SERVANT"
    kind "entity"
    name "OLD SERVANT"
    community 8
  ]
  node [
    id 1083
    label "E:TIP"
    kind "entity"
    name "TIP"
    community 0
  ]
  node [
    id 1084
    label "E:SLEEP"
    kind "entity"
    name "SLEEP"
    community 8
  ]
  node [
    id 1085
    label "E:WELL AERED"
    kind "entity"
    name "WELL AERED"
    community 8
  ]
  node [
    id 1086
    label "E:GOOD NIGHT"
    kind "entity"
    name "GOOD NIGHT"
    community 8
  ]
  node [
    id 1087
    label "E:BON SOIR"
    kind "entity"
    name "BON SOIR"
    community 8
  ]
  node [
    id 1088
    label "E:OLD BOY"
    kind "entity"
    name "OLD BOY"
    community 8
  ]
  node [
    id 1089
    label "E:CANONS AND ARCHDEACONS"
    kind "entity"
    name "CANONS AND ARCHDEACONS"
    community 8
  ]
  node [
    id 1090
    label "E:WIDOWED SISTER'S TIP"
    kind "entity"
    name "WIDOWED SISTER'S TIP"
    community 8
  ]
  node [
    id 1091
    label "E:AS PEACEFULLY AS A BLESSED BABY"
    kind "entity"
    name "AS PEACEFULLY AS A BLESSED BABY"
    community 8
  ]
  node [
    id 1092
    label "E:PARENTS' CHILD"
    kind "entity"
    name "PARENTS' CHILD"
    community 8
  ]
  node [
    id 1093
    label "E:BED IS WELL AERED"
    kind "entity"
    name "BED IS WELL AERED"
    community 8
  ]
  node [
    id 1094
    label "C:Novel-40700_00058"
    kind "chunk"
    chunk_id "Novel-40700_00058"
  ]
  node [
    id 1095
    label "U:Novel-40700_00058#0"
    kind "unit"
    chunk_id "Novel-40700_00058"
    text "The Dean expresses concern about his servant Blore being lost on a race-course, and Georgiana confirms that Blore was at St. Marvells Races last summer, where he was quite at home. Georgiana recognizes Blore immediately upon entering the Deanery."
    community 10
  ]
  node [
    id 1096
    label "E:TATTERSALL'S RING"
    kind "entity"
    name "TATTERSALL'S RING"
    community 10
  ]
  node [
    id 1097
    label "E:LAST SUMMER"
    kind "entity"
    name "LAST SUMMER"
    community 10
  ]
  node [
    id 1098
    label "U:Novel-40700_00058#1"
    kind "unit"
    chunk_id "Novel-40700_00058"
    text "The Dean asks what Blore was doing at St. Marvells Races, and Georgiana replies that he was investing the savings of the Dean's cook and housemaid."
    community 0
  ]
  node [
    id 1099
    label "E:COOK"
    kind "entity"
    name "COOK"
    community 0
  ]
  node [
    id 1100
    label "E:HOUSEMAID"
    kind "entity"
    name "HOUSEMAID"
    community 0
  ]
  node [
    id 1101
    label "E:ST. MARVELLS RACES"
    kind "entity"
    name "ST. MARVELLS RACES"
    community 0
  ]
  node [
    id 1102
    label "U:Novel-40700_00058#2"
    kind "unit"
    chunk_id "Novel-40700_00058"
    text "Georgiana instructs Blore to bring breakfast at nine sharp, pack a hamper with a cold chicken, French rolls, and two bottles of Heidsieck, label it 'George Tidd', and send it to the Hill."
    community 6
  ]
  node [
    id 1103
    label "E:BREAKFAST"
    kind "entity"
    name "BREAKFAST"
    community 6
  ]
  node [
    id 1104
    label "E:NINE"
    kind "entity"
    name "NINE"
    community 6
  ]
  node [
    id 1105
    label "E:COLD CHICKEN"
    kind "entity"
    name "COLD CHICKEN"
    community 6
  ]
  node [
    id 1106
    label "E:FRENCH ROLLS"
    kind "entity"
    name "FRENCH ROLLS"
    community 6
  ]
  node [
    id 1107
    label "E:HEIDSIECK"
    kind "entity"
    name "HEIDSIECK"
    community 6
  ]
  node [
    id 1108
    label "E:TWO BOTTLES OF HEIDSIECK"
    kind "entity"
    name "TWO BOTTLES OF HEIDSIECK"
    community 6
  ]
  node [
    id 1109
    label "U:Novel-40700_00058#3"
    kind "unit"
    chunk_id "Novel-40700_00058"
    text "The Dean sinks into a chair and clutches his forehead after Georgiana leaves, and Blore comments that she is a dear, high-spirited lady, then asks if the Dean is well."
    community 6
  ]
  node [
    id 1110
    label "E:FOREHEAD"
    kind "entity"
    name "FOREHEAD"
    community 6
  ]
  node [
    id 1111
    label "U:Novel-40700_00058#4"
    kind "unit"
    chunk_id "Novel-40700_00058"
    text "The Dean orders Blore to lock up, saying he will speak to him in the morning."
    community 6
  ]
  node [
    id 1112
    label "E:LOCK UP"
    kind "entity"
    name "LOCK UP"
    community 6
  ]
  node [
    id 1113
    label "C:Novel-40700_00059"
    kind "chunk"
    chunk_id "Novel-40700_00059"
  ]
  node [
    id 1114
    label "U:Novel-40700_00059#0"
    kind "unit"
    chunk_id "Novel-40700_00059"
    text "Blore enters the Deanery, finds bank-notes on the Dean's dressing-table, and presents them to the Dean, who recognizes them as notes he had placed there to be sent to the bank the next day. The Dean counts the notes and confirms they amount to fifty pounds."
    community 17
  ]
  node [
    id 1115
    label "E:DRESSING-TABLE"
    kind "entity"
    name "DRESSING-TABLE"
    community 17
  ]
  node [
    id 1116
    label "E:BANK"
    kind "entity"
    name "BANK"
    community 17
  ]
  node [
    id 1117
    label "U:Novel-40700_00059#1"
    kind "unit"
    chunk_id "Novel-40700_00059"
    text "The Dean expresses concern about a dreadful wave threatening the Deanery, describing a series of disturbing events in the past few hours: a horse with sporting tendencies in the stables, its vicious owner in the nursery, and his widowed sister smoking a cigarette at her bedroom window with her feet on the window-ledge. He hears footsteps in the garden and sees only the old spire against the threatening sky."
    community 16
  ]
  node [
    id 1118
    label "E:SPORTING TENDENCIES"
    kind "entity"
    name "SPORTING TENDENCIES"
    community 16
  ]
  node [
    id 1119
    label "E:CIGARETTE"
    kind "entity"
    name "CIGARETTE"
    community 16
  ]
  node [
    id 1120
    label "E:BEDROOM WINDOW"
    kind "entity"
    name "BEDROOM WINDOW"
    community 16
  ]
  node [
    id 1121
    label "E:FEET ON WINDOW-LEDGE"
    kind "entity"
    name "FEET ON WINDOW-LEDGE"
    community 16
  ]
  node [
    id 1122
    label "E:OLD SPIRE"
    kind "entity"
    name "OLD SPIRE"
    community 16
  ]
  node [
    id 1123
    label "E:THREATENING SKY"
    kind "entity"
    name "THREATENING SKY"
    community 16
  ]
  node [
    id 1124
    label "E:DREADFUL WAVE"
    kind "entity"
    name "DREADFUL WAVE"
    community 16
  ]
  node [
    id 1125
    label "E:HORSE'S OWNER"
    kind "entity"
    name "HORSE'S OWNER"
    community 16
  ]
  node [
    id 1126
    label "E:WINDOW-LEDGE"
    kind "entity"
    name "WINDOW-LEDGE"
    community 16
  ]
  node [
    id 1127
    label "U:Novel-40700_00059#2"
    kind "unit"
    chunk_id "Novel-40700_00059"
    text "The Dean identifies the old spire as his principal creditor, the most conspicuous object in the city."
    community 16
  ]
  node [
    id 1128
    label "E:PRINCIPAL CREDITOR"
    kind "entity"
    name "PRINCIPAL CREDITOR"
    community 16
  ]
  node [
    id 1129
    label "E:CITY"
    kind "entity"
    name "CITY"
    community 16
  ]
  node [
    id 1130
    label "C:Novel-40700_00060"
    kind "chunk"
    chunk_id "Novel-40700_00060"
  ]
  node [
    id 1131
    label "U:Novel-40700_00060#0"
    kind "unit"
    chunk_id "Novel-40700_00060"
    text "Georgiana urged the Dean to accept fifty pounds, which he initially considered, but then rejected when Blore approached him with the money. Blore claims he was at St. Marvells Races last summer and feared the notes might blow away due to the open window. The Dean questions Blore about his presence at the races, and Blore confesses that he has occasionally participated in betting on the races, both on his own account and for the kitchen, calling it a 'wicious institution' that spends more money than the Deanery does in a year. The Dean expresses frustration and calls Blore a weak creature, especially when he has a tip, and acknowledges the temptation of such offers."
    community 0
  ]
  node [
    id 1132
    label "E:OPEN WINDOW"
    kind "entity"
    name "OPEN WINDOW"
    community 0
  ]
  node [
    id 1133
    label "E:KITCHEN"
    kind "entity"
    name "KITCHEN"
    community 25
  ]
  node [
    id 1134
    label "E:WICIOUS INSTITUTION"
    kind "entity"
    name "WICIOUS INSTITUTION"
    community 0
  ]
  node [
    id 1135
    label "E:NOTES WOULD BLEED AWAY"
    kind "entity"
    name "NOTES WOULD BLEED AWAY"
    community 0
  ]
  node [
    id 1136
    label "E:WEAK CREATURE"
    kind "entity"
    name "WEAK CREATURE"
    community 0
  ]
  node [
    id 1137
    label "U:Novel-40700_00060#1"
    kind "unit"
    chunk_id "Novel-40700_00060"
    text "The Dean, upon hearing Blore's confession, expresses that he knew it would happen and calls Blore a weak creature, especially when he has a tip, and admits he himself is also susceptible to such temptation."
    community 0
  ]
  node [
    id 1138
    label "C:Novel-40700_00061"
    kind "chunk"
    chunk_id "Novel-40700_00061"
  ]
  node [
    id 1139
    label "U:Novel-40700_00061#0"
    kind "unit"
    chunk_id "Novel-40700_00061"
    text "The Dean admits to being tempted by a bet on a horse race, specifically on Dandy Dick, which is described as an old horse made of mahogany, with odds of ten to one against him. The Dean impulsively decides to place a fifty-pound bet on Dandy Dick, hands the money to Blore, and then recoils in horror. Blore whispers that he had not expected the Dean to be such an ardent sportsman and that the Dean will not give him his notice after this. Blore assures the Dean that their personal weaknesses are kept secret, and they remain outwardly respectable and respected."
    community 0
  ]
  node [
    id 1140
    label "E:MAHOGANY"
    kind "entity"
    name "MAHOGANY"
    community 0
  ]
  node [
    id 1141
    label "E:TEN TO ONE"
    kind "entity"
    name "TEN TO ONE"
    community 0
  ]
  node [
    id 1142
    label "E:BET"
    kind "entity"
    name "BET"
    community 0
  ]
  node [
    id 1143
    label "E:HORSE RACE"
    kind "entity"
    name "HORSE RACE"
    community 0
  ]
  node [
    id 1144
    label "E:NOTICE"
    kind "entity"
    name "NOTICE"
    community 11
  ]
  node [
    id 1145
    label "E:WEAKNESSES"
    kind "entity"
    name "WEAKNESSES"
    community 0
  ]
  node [
    id 1146
    label "E:RESPECTABLE"
    kind "entity"
    name "RESPECTABLE"
    community 0
  ]
  node [
    id 1147
    label "E:ARDENT SPORTSMAN"
    kind "entity"
    name "ARDENT SPORTSMAN"
    community 0
  ]
  node [
    id 1148
    label "E:OUTWARDLY"
    kind "entity"
    name "OUTWARDLY"
    community 0
  ]
  node [
    id 1149
    label "E:RESPECTED"
    kind "entity"
    name "RESPECTED"
    community 0
  ]
  node [
    id 1150
    label "U:Novel-40700_00061#1"
    kind "unit"
    chunk_id "Novel-40700_00061"
    text "Blore, after receiving the money from the Dean, quietly expresses surprise at the Dean's passion for sports and implies that the Dean's actions will affect their professional relationship, specifically that the Dean will not give him his notice. Blore also confirms that their personal flaws are understood to be hidden and that they maintain a respectable public image."
    community 0
  ]
  node [
    id 1151
    label "E:DEAN'S PASSION FOR SPORTS"
    kind "entity"
    name "DEAN'S PASSION FOR SPORTS"
    community 0
  ]
  node [
    id 1152
    label "C:Novel-40700_00062"
    kind "chunk"
    chunk_id "Novel-40700_00062"
  ]
  node [
    id 1153
    label "U:Novel-40700_00062#0"
    kind "unit"
    chunk_id "Novel-40700_00062"
    text "The character puts the notes into his pocket, wishes the dean good-night, walks to the door, and leaves. The dean tries to recall him but fails. The character says that an old man has been his pattern and example for years. He then exclaims that Edward Blore's hide is shattered and wishes the dean calm and happy dreams, and good luck with his money. Blore leaves and the dean gradually regains his self-possession."
    community 21
  ]
  node [
    id 1154
    label "E:CHARACTER"
    kind "entity"
    name "CHARACTER"
    community 21
  ]
  node [
    id 1155
    label "E:EDWARD BLORE"
    kind "entity"
    name "EDWARD BLORE"
    community 21
  ]
  node [
    id 1156
    label "E:HIDE SHATTERED"
    kind "entity"
    name "HIDE SHATTERED"
    community 21
  ]
  node [
    id 1157
    label "E:CALM AND APPEALING DREAMS"
    kind "entity"
    name "CALM AND APPEALING DREAMS"
    community 21
  ]
  node [
    id 1158
    label "E:GOOD RUN FOR MONEY"
    kind "entity"
    name "GOOD RUN FOR MONEY"
    community 21
  ]
  node [
    id 1159
    label "E:OLD MAN"
    kind "entity"
    name "OLD MAN"
    community 21
  ]
  node [
    id 1160
    label "E:EDWARD BLORE'S HIDE IS SHATTERED"
    kind "entity"
    name "EDWARD BLORE'S HIDE IS SHATTERED"
    community 21
  ]
  node [
    id 1161
    label "U:Novel-40700_00062#1"
    kind "unit"
    chunk_id "Novel-40700_00062"
    text "The dean is upset, says Blore has left that day, and upon realizing Blore is gone, fears the Spire may gain five hundred pounds if he does not call him back. He decides not to dwell on it and begins reading a book randomly from the bookshelf. He hears the sound of rain and thunder, which he compares to the tempest in his mind. He reads a book titled 'The Horse and its Ailments, by John Cox, M. R. C. V. S.' and recalls using it to treat his old mare at Oxford. He then reads a passage about 'Simple remedies for chills--the Bolus' and realizes his stable horse is suffering from a chill."
    community 7
  ]
  node [
    id 1162
    label "E:RAIN"
    kind "entity"
    name "RAIN"
    community 7
  ]
  node [
    id 1163
    label "E:THUNDER"
    kind "entity"
    name "THUNDER"
    community 12
  ]
  node [
    id 1164
    label "E:OLD MARE"
    kind "entity"
    name "OLD MARE"
    community 7
  ]
  node [
    id 1165
    label "E:BOOK"
    kind "entity"
    name "BOOK"
    community 7
  ]
  node [
    id 1166
    label "E:SIMPLE REMEDIES FOR CHILLS"
    kind "entity"
    name "SIMPLE REMEDIES FOR CHILLS"
    community 7
  ]
  node [
    id 1167
    label "E:BOLUS"
    kind "entity"
    name "BOLUS"
    community 7
  ]
  node [
    id 1168
    label "E:BLORE HAS LEFT"
    kind "entity"
    name "BLORE HAS LEFT"
    community 7
  ]
  node [
    id 1169
    label "E:SPIRE MAY GAIN FIVE HUNDRED POUNDS"
    kind "entity"
    name "SPIRE MAY GAIN FIVE HUNDRED POUNDS"
    community 7
  ]
  node [
    id 1170
    label "E:BLORE LEAVING"
    kind "entity"
    name "BLORE LEAVING"
    community 7
  ]
  node [
    id 1171
    label "E:RAIN AND THUNDER"
    kind "entity"
    name "RAIN AND THUNDER"
    community 7
  ]
  node [
    id 1172
    label "E:RAIN AND THUNDER TO TEMPEST IN MIND"
    kind "entity"
    name "RAIN AND THUNDER TO TEMPEST IN MIND"
    community 7
  ]
  node [
    id 1173
    label "E:STABLE HORSE IS SUFFERING FROM A CHILL"
    kind "entity"
    name "STABLE HORSE IS SUFFERING FROM A CHILL"
    community 7
  ]
  node [
    id 1174
    label "C:Novel-40700_00063"
    kind "chunk"
    chunk_id "Novel-40700_00063"
  ]
  node [
    id 1175
    label "U:Novel-40700_00063#0"
    kind "unit"
    chunk_id "Novel-40700_00063"
    text "The beast in the Dean's stable is suffering from a chill. The Dean believes it would be humane to administer a Bolus to the animal as a precaution against the chill and relies on Blore's aid and discretion in ministering to any guest in the Deanery."
    community 7
  ]
  node [
    id 1176
    label "E:BEAST"
    kind "entity"
    name "BEAST"
    community 7
  ]
  node [
    id 1177
    label "E:GUEST"
    kind "entity"
    name "GUEST"
    community 7
  ]
  node [
    id 1178
    label "U:Novel-40700_00063#1"
    kind "unit"
    chunk_id "Novel-40700_00063"
    text "Blore is aware that the Dean intends to administer a Bolus to the animal in the stable to prevent a chill, and he comments that the Dean is someone who doesn't miss an opportunity, implying he is a person who takes advantage of chances."
    community 7
  ]
  node [
    id 1179
    label "C:Novel-40700_00064"
    kind "chunk"
    chunk_id "Novel-40700_00064"
  ]
  node [
    id 1180
    label "U:Novel-40700_00064#0"
    kind "unit"
    chunk_id "Novel-40700_00064"
    text "The Dean shrinks from BLORE with a groan, places a medicine chest on the table, takes up a book, and hands it to BLORE with his finger on a page, instructing him to fetch medical supplies from the kitchen quickly. He states that it has been exactly seven and twenty years since he last approached a horse medically and expresses concern that the Bolus will give the animal an unfair advantage over its competitors, emphasizing that he does not desire this outcome."
    community 7
  ]
  node [
    id 1181
    label "E:MEDICINE CHEST"
    kind "entity"
    name "MEDICINE CHEST"
    community 24
  ]
  node [
    id 1182
    label "E:SEVEN AND TWENTY YEARS"
    kind "entity"
    name "SEVEN AND TWENTY YEARS"
    community 7
  ]
  node [
    id 1183
    label "E:COMPETITORS"
    kind "entity"
    name "COMPETITORS"
    community 7
  ]
  node [
    id 1184
    label "E:BOLUS GIVING UNFAIR ADVANTAGE TO COMPETITORS"
    kind "entity"
    name "BOLUS GIVING UNFAIR ADVANTAGE TO COMPETITORS"
    community 7
  ]
  node [
    id 1185
    label "U:Novel-40700_00064#1"
    kind "unit"
    chunk_id "Novel-40700_00064"
    text "BLORE enters carrying a tray with a small flour-barrel, rolling-pin, white china basin, carafe of water, napkin, and the book. The Dean recoils, then guiltily takes the tray and places it on the table, thanking BLORE."
    community 24
  ]
  node [
    id 1186
    label "E:TRAY"
    kind "entity"
    name "TRAY"
    community 24
  ]
  node [
    id 1187
    label "E:FLOUR-BARREL"
    kind "entity"
    name "FLOUR-BARREL"
    community 24
  ]
  node [
    id 1188
    label "E:ROLLING-PIN"
    kind "entity"
    name "ROLLING-PIN"
    community 24
  ]
  node [
    id 1189
    label "E:WHITE CHINA BASIN"
    kind "entity"
    name "WHITE CHINA BASIN"
    community 24
  ]
  node [
    id 1190
    label "E:CARAFE OF WATER"
    kind "entity"
    name "CARAFE OF WATER"
    community 24
  ]
  node [
    id 1191
    label "E:NAPKIN"
    kind "entity"
    name "NAPKIN"
    community 24
  ]
  node [
    id 1192
    label "U:Novel-40700_00064#2"
    kind "unit"
    chunk_id "Novel-40700_00064"
    text "BLORE watches The Dean from the window curtain and remarks that his eyes are awful, and he does not seem to know the 'appy Deanery when he sees such proceedings a'goin' on at the dead of night. A heavy roll of thunder is heard, and The Dean mixes a pudding and stirs it with the rolling-pin."
    community 12
  ]
  node [
    id 1193
    label "E:PROCEEDINGS"
    kind "entity"
    name "PROCEEDINGS"
    community 10
  ]
  node [
    id 1194
    label "E:PUDDING"
    kind "entity"
    name "PUDDING"
    community 12
  ]
  node [
    id 1195
    label "C:Novel-40700_00065"
    kind "chunk"
    chunk_id "Novel-40700_00065"
  ]
  node [
    id 1196
    label "U:Novel-40700_00065#0"
    kind "unit"
    chunk_id "Novel-40700_00065"
    text "The old half-forgotten time returns to the speaker, who is once again a promising youth at college. He reflects to himself that one might think by his appearance he is going to poison his family, and expresses concern that if anything serious happened to the animal in their stable, Bonny-Betsy, the deserving horse he has trusted with his hard-earned savings, would be lost. He recalls that he previously obtained a substance a month ago to destroy a black retriever that fell from a hill, but now realizes the poison is in his pantry and could not have been used for cooking purposes. The speaker also mentions that he will carry out the act and quietly steals out of the room unseen by the Dean."
    community 14
  ]
  node [
    id 1197
    label "E:SPEAKER"
    kind "entity"
    name "SPEAKER"
    community 14
  ]
  node [
    id 1198
    label "E:OLD HALF-FORGOTTEN TIME"
    kind "entity"
    name "OLD HALF-FORGOTTEN TIME"
    community 14
  ]
  node [
    id 1199
    label "E:COLLEGE"
    kind "entity"
    name "COLLEGE"
    community 14
  ]
  node [
    id 1200
    label "E:BONNY-BETSY"
    kind "entity"
    name "BONNY-BETSY"
    community 14
  ]
  node [
    id 1201
    label "E:HARD-EARNED SAVINGS"
    kind "entity"
    name "HARD-EARNED SAVINGS"
    community 14
  ]
  node [
    id 1202
    label "E:BLACK RETRIEVER"
    kind "entity"
    name "BLACK RETRIEVER"
    community 14
  ]
  node [
    id 1203
    label "E:POISON"
    kind "entity"
    name "POISON"
    community 14
  ]
  node [
    id 1204
    label "E:PANTRY"
    kind "entity"
    name "PANTRY"
    community 14
  ]
  node [
    id 1205
    label "E:DRUGS"
    kind "entity"
    name "DRUGS"
    community 14
  ]
  node [
    id 1206
    label "E:ONE MIGHT THINK HE IS GOING TO POISON HIS FAMILY"
    kind "entity"
    name "ONE MIGHT THINK HE IS GOING TO POISON HIS FAMILY"
    community 14
  ]
  node [
    id 1207
    label "E:COOKING PURPOSES"
    kind "entity"
    name "COOKING PURPOSES"
    community 14
  ]
  node [
    id 1208
    label "E:ACT"
    kind "entity"
    name "ACT"
    community 14
  ]
  node [
    id 1209
    label "E:UNSEEN BY THE DEAN"
    kind "entity"
    name "UNSEEN BY THE DEAN"
    community 14
  ]
  node [
    id 1210
    label "E:OLD STREETS AT OXFORD"
    kind "entity"
    name "OLD STREETS AT OXFORD"
    community 14
  ]
  node [
    id 1211
    label "E:BROAD MEADOWS"
    kind "entity"
    name "BROAD MEADOWS"
    community 14
  ]
  node [
    id 1212
    label "E:TALL SPIRE OF THE COLLEGE"
    kind "entity"
    name "TALL SPIRE OF THE COLLEGE"
    community 14
  ]
  node [
    id 1213
    label "E:BILLS AND SPIRES"
    kind "entity"
    name "BILLS AND SPIRES"
    community 14
  ]
  node [
    id 1214
    label "U:Novel-40700_00065#1"
    kind "unit"
    chunk_id "Novel-40700_00065"
    text "The Dean recalls walking through the old streets of Oxford, avoiding shops where he owes his youthful bills. He pounds the rolling-pin vigorously as he speaks, and expresses that his life seems composed entirely of bills and spires. He sees the broad meadows and the tall spire of the college, which symbolizes his entire life."
    community 14
  ]
  node [
    id 1215
    label "E:SHOPS"
    kind "entity"
    name "SHOPS"
    community 14
  ]
  node [
    id 1216
    label "E:YOUTHFUL BILLS"
    kind "entity"
    name "YOUTHFUL BILLS"
    community 14
  ]
  node [
    id 1217
    label "E:LIFE"
    kind "entity"
    name "LIFE"
    community 14
  ]
  node [
    id 1218
    label "U:Novel-40700_00065#2"
    kind "unit"
    chunk_id "Novel-40700_00065"
    text "The speaker, reflecting to himself, questions where he obtained the substance a month ago to destroy the black retriever that fell from the hill. He later states that the dog died and that the poison is now in his pantry, and it could not have been used for cooking purposes. The Dean later asks where the drugs are, indicating a shared concern about the poison's location."
    community 14
  ]
  node [
    id 1219
    label "E:MONTH AGO"
    kind "entity"
    name "MONTH AGO"
    community 14
  ]
  node [
    id 1220
    label "E:DOG"
    kind "entity"
    name "DOG"
    community 14
  ]
  node [
    id 1221
    label "E:SUBSTANCE"
    kind "entity"
    name "SUBSTANCE"
    community 14
  ]
  node [
    id 1222
    label "C:Novel-40700_00066"
    kind "chunk"
    chunk_id "Novel-40700_00066"
  ]
  node [
    id 1223
    label "U:Novel-40700_00066#0"
    kind "unit"
    chunk_id "Novel-40700_00066"
    text "A man opens the medicine chest, pours drops from a bottle into a basin, counts three to six, then takes another bottle, and later exits with the chest into the Library. He is followed by BLORE, who stealthily enters and whispers that he has taken strychnine, empties the contents of a small paper packet into the basin, stirs it with a rolling-pin, and exclaims that he has cooked Dandy Dick. He then moves in horror and says he is only a hamatoor sportsman who cannot afford uncertainty. When the Dean returns, BLORE starts guiltily and offers to help, but the Dean orders him to remove the dreadful things and not to be seen again that night. BLORE claims the substance is only an 'orse and says he will retire from the Turf after tomorrow to reclaim 'im."
    community 24
  ]
  node [
    id 1224
    label "E:MAN"
    kind "entity"
    name "MAN"
    community 24
  ]
  node [
    id 1225
    label "E:BOTTLES"
    kind "entity"
    name "BOTTLES"
    community 24
  ]
  node [
    id 1226
    label "E:BAKING BASIN"
    kind "entity"
    name "BAKING BASIN"
    community 24
  ]
  node [
    id 1227
    label "E:THREE"
    kind "entity"
    name "THREE"
    community 24
  ]
  node [
    id 1228
    label "E:FOUR"
    kind "entity"
    name "FOUR"
    community 24
  ]
  node [
    id 1229
    label "E:FIVE"
    kind "entity"
    name "FIVE"
    community 24
  ]
  node [
    id 1230
    label "E:SIX"
    kind "entity"
    name "SIX"
    community 24
  ]
  node [
    id 1231
    label "E:TWO"
    kind "entity"
    name "TWO"
    community 24
  ]
  node [
    id 1232
    label "E:STRYCHNINE"
    kind "entity"
    name "STRYCHNINE"
    community 24
  ]
  node [
    id 1233
    label "E:HAMATOOR SPORTSMAN"
    kind "entity"
    name "HAMATOOR SPORTSMAN"
    community 24
  ]
  node [
    id 1234
    label "E:UNCERTAINTY"
    kind "entity"
    name "UNCERTAINTY"
    community 24
  ]
  node [
    id 1235
    label "E:TURF"
    kind "entity"
    name "TURF"
    community 24
  ]
  node [
    id 1236
    label "E:AFTER TOMORROW"
    kind "entity"
    name "AFTER TOMORROW"
    community 24
  ]
  node [
    id 1237
    label "E:BOTTLE"
    kind "entity"
    name "BOTTLE"
    community 24
  ]
  node [
    id 1238
    label "E:SMALL PAPER PACKET"
    kind "entity"
    name "SMALL PAPER PACKET"
    community 24
  ]
  node [
    id 1239
    label "E:HAS COOKED DANDY DICK"
    kind "entity"
    name "HAS COOKED DANDY DICK"
    community 24
  ]
  node [
    id 1240
    label "E:REMOVE THESE DREADFUL THINGS"
    kind "entity"
    name "REMOVE THESE DREADFUL THINGS"
    community 24
  ]
  node [
    id 1241
    label "E:DO NOT SEE YOU AGAIN THAT NIGHT"
    kind "entity"
    name "DO NOT SEE YOU AGAIN THAT NIGHT"
    community 24
  ]
  node [
    id 1242
    label "E:IT'S ONLY AN HORSE"
    kind "entity"
    name "IT'S ONLY AN HORSE"
    community 24
  ]
  node [
    id 1243
    label "E:HIM"
    kind "entity"
    name "HIM"
    community 24
  ]
  node [
    id 1244
    label "U:Novel-40700_00066#1"
    kind "unit"
    chunk_id "Novel-40700_00066"
    text "The man pours drops from a bottle into the basin and counts three to six, indicating a sequence of actions involving the medicine chest and the basin. BLORE enters stealthily, takes strychnine, mixes it in the basin, and claims to have cooked Dandy Dick, expressing fear and guilt when the Dean returns. The Dean orders BLORE to remove the substances and not be seen again. BLORE defends the substance as just an 'orse and promises to retire from the Turf after tomorrow to reclaim 'im."
    community 24
  ]
  node [
    id 1245
    label "C:Novel-40700_00067"
    kind "chunk"
    chunk_id "Novel-40700_00067"
  ]
  node [
    id 1246
    label "U:Novel-40700_00067#0"
    kind "unit"
    chunk_id "Novel-40700_00067"
    text "After to-morrow, the speaker will retire from the Turf to reclaim the animal."
    community 5
  ]
  node [
    id 1247
    label "E:ANIMAL"
    kind "entity"
    name "ANIMAL"
    community 7
  ]
  node [
    id 1248
    label "U:Novel-40700_00067#1"
    kind "unit"
    chunk_id "Novel-40700_00067"
    text "The Dean does not feel resignation about his humane task; the stable is small and if the animal is restive, they will be cramped for room; he also fears getting a chill from the rain."
    community 7
  ]
  node [
    id 1249
    label "E:CRAMPED FOR ROOM"
    kind "entity"
    name "CRAMPED FOR ROOM"
    community 7
  ]
  node [
    id 1250
    label "E:HUMANE TASK"
    kind "entity"
    name "HUMANE TASK"
    community 7
  ]
  node [
    id 1251
    label "U:Novel-40700_00067#2"
    kind "unit"
    chunk_id "Novel-40700_00067"
    text "The Dean is sure Mardon will lend him Sir Tristram's coat and cap; he puts on the coat which completely envelops him, and the sealskin cap which almost conceals his face."
    community 16
  ]
  node [
    id 1252
    label "E:SEALSKIN CAP"
    kind "entity"
    name "SEALSKIN CAP"
    community 16
  ]
  node [
    id 1253
    label "U:Novel-40700_00067#3"
    kind "unit"
    chunk_id "Novel-40700_00067"
    text "The Dean feels a dreadful sinking at the heart when putting on the cap; he believes that if all followers of veterinary science are as wretched as he is, they must be a noble band."
    community 5
  ]
  node [
    id 1254
    label "E:VETERINARY SCIENCE"
    kind "entity"
    name "VETERINARY SCIENCE"
    community 5
  ]
  node [
    id 1255
    label "E:WRETCHED"
    kind "entity"
    name "WRETCHED"
    community 5
  ]
  node [
    id 1256
    label "E:NOBLE BAND"
    kind "entity"
    name "NOBLE BAND"
    community 5
  ]
  node [
    id 1257
    label "E:CAP"
    kind "entity"
    name "CAP"
    community 5
  ]
  node [
    id 1258
    label "U:Novel-40700_00067#4"
    kind "unit"
    chunk_id "Novel-40700_00067"
    text "Sir Tristram enters quietly, smoking and carrying a lighted candle; he confirms the fire is still burning, blows out the candle, and says he will doze here till daybreak; he remarks that the night has been very thunderous and that he never thought there was so much thunder in these small country places."
    community 2
  ]
  node [
    id 1259
    label "E:CANDLE"
    kind "entity"
    name "CANDLE"
    community 2
  ]
  node [
    id 1260
    label "E:DAYBREAK"
    kind "entity"
    name "DAYBREAK"
    community 2
  ]
  node [
    id 1261
    label "E:SMALL COUNTRY PLACES"
    kind "entity"
    name "SMALL COUNTRY PLACES"
    community 2
  ]
  node [
    id 1262
    label "E:NIGHT"
    kind "entity"
    name "NIGHT"
    community 2
  ]
  node [
    id 1263
    label "C:Novel-40700_00068"
    kind "chunk"
    chunk_id "Novel-40700_00068"
  ]
  node [
    id 1264
    label "U:Novel-40700_00068#0"
    kind "unit"
    chunk_id "Novel-40700_00068"
    text "Georgiana, who is pale and agitated and wearing a dressing-gown, enters quickly carrying an umbrella and a lighted candle, asking which way is nearer to the stable, as she insists she must satisfy herself and must do so."
    community 7
  ]
  node [
    id 1265
    label "E:DRESSING-GOWN"
    kind "entity"
    name "DRESSING-GOWN"
    community 7
  ]
  node [
    id 1266
    label "E:LIGHTED CANDLE"
    kind "entity"
    name "LIGHTED CANDLE"
    community 7
  ]
  node [
    id 1267
    label "U:Novel-40700_00068#1"
    kind "unit"
    chunk_id "Novel-40700_00068"
    text "Georgiana shrieks with fright upon seeing Sir Tristram, holds out her umbrella, and threatens to fire, then recognizes him as Tris, exclaiming 'Tris!' and later collapses against him, who deposits her in a chair."
    community 7
  ]
  node [
    id 1268
    label "E:TRIS"
    kind "entity"
    name "TRIS"
    community 14
  ]
  node [
    id 1269
    label "U:Novel-40700_00068#2"
    kind "unit"
    chunk_id "Novel-40700_00068"
    text "Georgiana, after collapsing, says she is overtrained and will be on her legs again in a minute, opens her umbrella and hides behind it while sobbing violently."
    community 7
  ]
  node [
    id 1270
    label "E:OVERTRAINED"
    kind "entity"
    name "OVERTRAINED"
    community 7
  ]
  node [
    id 1271
    label "E:SOBING"
    kind "entity"
    name "SOBING"
    community 7
  ]
  node [
    id 1272
    label "E:MINUTE"
    kind "entity"
    name "MINUTE"
    community 7
  ]
  node [
    id 1273
    label "U:Novel-40700_00068#3"
    kind "unit"
    chunk_id "Novel-40700_00068"
    text "Sir Tristram stands over the umbrella in great concern and asks George what he is fooling about being there for, saying the cot wouldn't hold his photograph and asking where she is going."
    community 12
  ]
  node [
    id 1274
    label "E:COT"
    kind "entity"
    name "COT"
    community 12
  ]
  node [
    id 1275
    label "E:PHOTOGRAPH"
    kind "entity"
    name "PHOTOGRAPH"
    community 12
  ]
  node [
    id 1276
    label "E:WHERE SHE IS GOING"
    kind "entity"
    name "WHERE SHE IS GOING"
    community 12
  ]
  node [
    id 1277
    label "C:Novel-40700_00069"
    kind "chunk"
    chunk_id "Novel-40700_00069"
  ]
  node [
    id 1278
    label "U:Novel-40700_00069#0"
    kind "unit"
    chunk_id "Novel-40700_00069"
    text "Georgiana says the cot wouldn't hold her photograph and expresses fear of thunder in her room, which she believes sits on her particular bit of roof. She recalls dozing and having a frightful dream in which Dandy sold himself to a circus and was hooting because he had lost his tail, calling it an omen."
    community 12
  ]
  node [
    id 1279
    label "E:ROOF"
    kind "entity"
    name "ROOF"
    community 12
  ]
  node [
    id 1280
    label "E:CIRCUS"
    kind "entity"
    name "CIRCUS"
    community 12
  ]
  node [
    id 1281
    label "E:OMEN"
    kind "entity"
    name "OMEN"
    community 12
  ]
  node [
    id 1282
    label "U:Novel-40700_00069#1"
    kind "unit"
    chunk_id "Novel-40700_00069"
    text "Georgiana says she is dreadfully effeminate and that Tidd has returned to his usual self. Sir Tristram tells her not to be a man, George, and calls her tender-hearted, saying he never guessed she was so tender-hearted. Georgiana denies being tender-hearted and says she is a lonely, unlucky woman who only loves and clings to the tail end of Dandy, which she sees as an invalid part of the horse."
    community 12
  ]
  node [
    id 1283
    label "E:TIDD"
    kind "entity"
    name "TIDD"
    community 12
  ]
  node [
    id 1284
    label "E:INVALID"
    kind "entity"
    name "INVALID"
    community 12
  ]
  node [
    id 1285
    label "E:LOVE"
    kind "entity"
    name "LOVE"
    community 9
  ]
  node [
    id 1286
    label "E:CLING"
    kind "entity"
    name "CLING"
    community 12
  ]
  node [
    id 1287
    label "E:TENDER-HEARTED"
    kind "entity"
    name "TENDER-HEARTED"
    community 12
  ]
  node [
    id 1288
    label "E:LONELY"
    kind "entity"
    name "LONELY"
    community 12
  ]
  node [
    id 1289
    label "E:UNLUCKY"
    kind "entity"
    name "UNLUCKY"
    community 12
  ]
  node [
    id 1290
    label "U:Novel-40700_00069#2"
    kind "unit"
    chunk_id "Novel-40700_00069"
    text "Sir Tristram suggests swapping halves of Dandy, taking his head, and says he is not a mean cur. Georgiana refuses, saying she is like a doating mother to her share of Dandy and that it is all the dearer because it is an invalid. She then says she is off, and Sir Tristram urges her to come along, but stops and looks at her, seizing her hand to say he never guessed she was so tender-hearted."
    community 12
  ]
  node [
    id 1291
    label "E:HALF"
    kind "entity"
    name "HALF"
    community 12
  ]
  node [
    id 1292
    label "E:DOATING MOTHER"
    kind "entity"
    name "DOATING MOTHER"
    community 12
  ]
  node [
    id 1293
    label "E:OFF"
    kind "entity"
    name "OFF"
    community 12
  ]
  node [
    id 1294
    label "E:COME ALONG"
    kind "entity"
    name "COME ALONG"
    community 12
  ]
  node [
    id 1295
    label "E:SEIZE HAND"
    kind "entity"
    name "SEIZE HAND"
    community 12
  ]
  node [
    id 1296
    label "C:Novel-40700_00070"
    kind "chunk"
    chunk_id "Novel-40700_00070"
  ]
  node [
    id 1297
    label "U:Novel-40700_00070#0"
    kind "unit"
    chunk_id "Novel-40700_00070"
    text "Georgiana says she is not the one who has robbed Sir Tristram of his old friend George Tidd, Esquire, and Sir Tristram responds that he now seems to have lost contact with him forever. Sir Tristram then reveals he has an introduction to George Tidd's twin-sister, Georgiana, which shocks her. Georgiana angrily pulls her hand away and says she will nurse her half alone, then turns toward the window and stops, saying they didn't hear anything. Sir Tristram asks what is wrong, and Georgiana points to the window, saying they heard movement in the garden. Sir Tristram confirms that people are moving about the garden, not near the stables, and they are coming toward the house. They decide to leave and watch, with Sir Tristram taking the candlestick. The curtains are pushed aside and Salome and Sheba enter, both in fancy dresses. Salome lights the candles on the mantelpiece in rage, and Sheba says there will be no ball after all. Salome expresses a desire to have a brother to avenge them."
    community 16
  ]
  node [
    id 1298
    label "E:GEORGE TIDD ESQUIRE"
    kind "entity"
    name "GEORGE TIDD ESQUIRE"
    community 16
  ]
  node [
    id 1299
    label "E:TWIN-SISTER"
    kind "entity"
    name "TWIN-SISTER"
    community 16
  ]
  node [
    id 1300
    label "E:CANDLESTICK"
    kind "entity"
    name "CANDLESTICK"
    community 16
  ]
  node [
    id 1301
    label "E:MANTELPIECE"
    kind "entity"
    name "MANTELPIECE"
    community 16
  ]
  node [
    id 1302
    label "E:BALL"
    kind "entity"
    name "BALL"
    community 16
  ]
  node [
    id 1303
    label "E:FANCY DRESSES"
    kind "entity"
    name "FANCY DRESSES"
    community 16
  ]
  node [
    id 1304
    label "E:CURTAINS"
    kind "entity"
    name "CURTAINS"
    community 16
  ]
  node [
    id 1305
    label "E:BROTHER TO AVEANCE THEM"
    kind "entity"
    name "BROTHER TO AVEANCE THEM"
    community 16
  ]
  node [
    id 1306
    label "C:Novel-40700_00071"
    kind "chunk"
    chunk_id "Novel-40700_00071"
  ]
  node [
    id 1307
    label "U:Novel-40700_00071#0"
    kind "unit"
    chunk_id "Novel-40700_00071"
    text "SHEBA and SALOME express frustration over their misfortunes, with SHEBA saying she will try to borrow a brother the next day, and both lamenting their wickedness and rebelliousness, with SALOME blaming the Military and SHEBA blaming her training as a clergymen's wife and hating Nugent Darbey, wishing him to grow bald early; SALOME also mocks Gerald Tarver's pink nose, wishing it deepens to frighten cows; voices are heard from the window, and DARBEY and TARVER enter, both dressed shabbily as Cavaliers, with TARVER carrying a carriage umbrella and apologizing to Miss Jedd for the Military being summoned to St."
    community 9
  ]
  node [
    id 1308
    label "E:NUGENT DARBEDY"
    kind "entity"
    name "NUGENT DARBEDY"
    community 9
  ]
  node [
    id 1309
    label "E:ST"
    kind "entity"
    name "ST"
    community 9
  ]
  node [
    id 1310
    label "E:CARROUGE UMBRELLA"
    kind "entity"
    name "CARROUGE UMBRELLA"
    community 9
  ]
  node [
    id 1311
    label "E:CAVALIERS"
    kind "entity"
    name "CAVALIERS"
    community 9
  ]
  node [
    id 1312
    label "E:WICKEDNESS"
    kind "entity"
    name "WICKEDNESS"
    community 9
  ]
  node [
    id 1313
    label "E:REBELLIOUSNESS"
    kind "entity"
    name "REBELLIOUSNESS"
    community 9
  ]
  node [
    id 1314
    label "E:INCONVENIENCE"
    kind "entity"
    name "INCONVENIENCE"
    community 9
  ]
  node [
    id 1315
    label "E:BALDNESS"
    kind "entity"
    name "BALDNESS"
    community 9
  ]
  node [
    id 1316
    label "E:PINK NOSE"
    kind "entity"
    name "PINK NOSE"
    community 9
  ]
  node [
    id 1317
    label "E:DIGNIFIED INTERVIEW"
    kind "entity"
    name "DIGNIFIED INTERVIEW"
    community 9
  ]
  node [
    id 1318
    label "E:CURTAIN"
    kind "entity"
    name "CURTAIN"
    community 9
  ]
  node [
    id 1319
    label "E:VOICES"
    kind "entity"
    name "VOICES"
    community 9
  ]
  node [
    id 1320
    label "E:BADLY DRESSED"
    kind "entity"
    name "BADLY DRESSED"
    community 9
  ]
  node [
    id 1321
    label "E:SHABBILY DRESSED"
    kind "entity"
    name "SHABBILY DRESSED"
    community 9
  ]
  node [
    id 1322
    label "E:BROTHER"
    kind "entity"
    name "BROTHER"
    community 9
  ]
  node [
    id 1323
    label "E:NUGENT DARBEDY GROWS BALD EARLY"
    kind "entity"
    name "NUGENT DARBEDY GROWS BALD EARLY"
    community 9
  ]
  node [
    id 1324
    label "E:GERALD TARVER'S NOSE"
    kind "entity"
    name "GERALD TARVER'S NOSE"
    community 9
  ]
  node [
    id 1325
    label "E:GERALD TARVER'S NOSE DEEPENS TO FRIGHTEN COWS"
    kind "entity"
    name "GERALD TARVER'S NOSE DEEPENS TO FRIGHTEN COWS"
    community 9
  ]
  node [
    id 1326
    label "E:CARRIAGE UMBRELLA"
    kind "entity"
    name "CARRIAGE UMBRELLA"
    community 3
  ]
  node [
    id 1327
    label "E:CAVALIER"
    kind "entity"
    name "CAVALIER"
    community 3
  ]
  node [
    id 1328
    label "C:Novel-40700_00072"
    kind "chunk"
    chunk_id "Novel-40700_00072"
  ]
  node [
    id 1329
    label "U:Novel-40700_00072#0"
    kind "unit"
    chunk_id "Novel-40700_00072"
    text "The Military were summoned to St. Marvells, and it is not considered anyone's fault."
    community 10
  ]
  node [
    id 1330
    label "U:Novel-40700_00072#1"
    kind "unit"
    chunk_id "Novel-40700_00072"
    text "DARBEY questions whether officers and gentlemen should be blamed for responding to the call of duty."
    community 11
  ]
  node [
    id 1331
    label "E:OFFICERS"
    kind "entity"
    name "OFFICERS"
    community 11
  ]
  node [
    id 1332
    label "E:CALL OF DUTY"
    kind "entity"
    name "CALL OF DUTY"
    community 11
  ]
  node [
    id 1333
    label "U:Novel-40700_00072#2"
    kind "unit"
    chunk_id "Novel-40700_00072"
    text "SHEBA states that officers are blamed for subjecting two motherless girls to the shock of arriving at the Durnstone Athenaeum and finding a notice on the front door that reads: 'Ball knocked on the head--Vivat Regina'"
    community 11
  ]
  node [
    id 1334
    label "E:TWO MOTHERLESS GIRLS"
    kind "entity"
    name "TWO MOTHERLESS GIRLS"
    community 11
  ]
  node [
    id 1335
    label "E:BALL KNOWN ON THE HEAD"
    kind "entity"
    name "BALL KNOWN ON THE HEAD"
    community 11
  ]
  node [
    id 1336
    label "E:VIVAT REGINA"
    kind "entity"
    name "VIVAT REGINA"
    community 11
  ]
  node [
    id 1337
    label "U:Novel-40700_00072#3"
    kind "unit"
    chunk_id "Novel-40700_00072"
    text "SALOME states that gentlemen are blamed for inflicting upon them the unspeakable agony of being jeered at by boys."
    community 11
  ]
  node [
    id 1338
    label "E:JEERED AT"
    kind "entity"
    name "JEERED AT"
    community 11
  ]
  node [
    id 1339
    label "U:Novel-40700_00072#4"
    kind "unit"
    chunk_id "Novel-40700_00072"
    text "TARVER took the address of the boy who suggested calling again on the fifth of November, which is on the back of the admission card."
    community 3
  ]
  node [
    id 1340
    label "E:FIFTH OF NOVEMBER"
    kind "entity"
    name "FIFTH OF NOVEMBER"
    community 3
  ]
  node [
    id 1341
    label "E:ADMISSION CARD"
    kind "entity"
    name "ADMISSION CARD"
    community 3
  ]
  node [
    id 1342
    label "U:Novel-40700_00072#5"
    kind "unit"
    chunk_id "Novel-40700_00072"
    text "DARBEY says everything will be done and that they will both wait on the boy's mother for an explanation."
    community 3
  ]
  node [
    id 1343
    label "E:BOY'S MOTHER"
    kind "entity"
    name "BOY'S MOTHER"
    community 3
  ]
  node [
    id 1344
    label "E:EXPLANATION"
    kind "entity"
    name "EXPLANATION"
    community 3
  ]
  node [
    id 1345
    label "U:Novel-40700_00072#6"
    kind "unit"
    chunk_id "Novel-40700_00072"
    text "TARVER asks Miss Jedd to smile once again, describing it as a forced, hollow smile, and Salome enters."
    community 3
  ]
  node [
    id 1346
    label "E:ENTERED"
    kind "entity"
    name "ENTERED"
    community 3
  ]
  node [
    id 1347
    label "U:Novel-40700_00072#7"
    kind "unit"
    chunk_id "Novel-40700_00072"
    text "GEORGIANA enters and calls Salome and Sheba 'bad girls', then advances to TARVER and accuses him of encouraging the two children to enjoy themselves and of taking them out without their aunt."
    community 19
  ]
  node [
    id 1348
    label "E:TWO CHILDREN"
    kind "entity"
    name "TWO CHILDREN"
    community 19
  ]
  node [
    id 1349
    label "E:ENJOYING THEMSELVES"
    kind "entity"
    name "ENJOYING THEMSELVES"
    community 19
  ]
  node [
    id 1350
    label "E:TAKING THEM OUT"
    kind "entity"
    name "TAKING THEM OUT"
    community 19
  ]
  node [
    id 1351
    label "E:WITHOUT AUNT"
    kind "entity"
    name "WITHOUT AUNT"
    community 19
  ]
  node [
    id 1352
    label "U:Novel-40700_00072#8"
    kind "unit"
    chunk_id "Novel-40700_00072"
    text "SHEBA responds to GEORGIANA by saying she is not bad, but rather trustful and confiding."
    community 11
  ]
  node [
    id 1353
    label "E:TRUSTFUL"
    kind "entity"
    name "TRUSTFUL"
    community 11
  ]
  node [
    id 1354
    label "E:CONFIDING"
    kind "entity"
    name "CONFIDING"
    community 11
  ]
  node [
    id 1355
    label "C:Novel-40700_00073"
    kind "chunk"
    chunk_id "Novel-40700_00073"
  ]
  node [
    id 1356
    label "U:Novel-40700_00073#0"
    kind "unit"
    chunk_id "Novel-40700_00073"
    text "SHEBA and SALOME protest against taking the children out without their Aunt, asserting that the speaker, SHEBA, believes she cannot keep a thing quiet and that the children did not ask Papa's permission. SHEBA and SALOME express pity for Papa, with SHEBA calling him 'Poor, dear Papa'. GEORGIANA addresses TARVER as Field-Marshal, stating he is an invalid, and DARBEY responds that they are on duty, guarding the ruins of the 'Swan' Inn. GEORGIANA calls out to SIR TRISTRAM, telling him to send the outsiders into the road and let them guard their own ruins. SALOME and SHEBA shriek and throw themselves at the feet of TARVER and DARBEY, pleading to spare them. SHEBA insists that no harm shall come to their heads. SIR TRISTRAM twists TARVER's wig around his face. The gate bell rings violently. GEORGIANA, SALOME, and SHEBA ask what that is, with SALOME saying it will wake Papa and SHEBA demanding the bell be stopped. GEORGIANA runs to the door and opens it."
    community 23
  ]
  node [
    id 1357
    label "E:FIELD-MARSHAL"
    kind "entity"
    name "FIELD-MARSHAL"
    community 23
  ]
  node [
    id 1358
    label "E:SWAN INN"
    kind "entity"
    name "SWAN INN"
    community 23
  ]
  node [
    id 1359
    label "E:OUTSIDERS"
    kind "entity"
    name "OUTSIDERS"
    community 23
  ]
  node [
    id 1360
    label "E:WIG"
    kind "entity"
    name "WIG"
    community 23
  ]
  node [
    id 1361
    label "E:FEEBLE WOMAN"
    kind "entity"
    name "FEEBLE WOMAN"
    community 23
  ]
  node [
    id 1362
    label "E:KEEN SENSE OF RIGHT AND WRONG"
    kind "entity"
    name "KEEN SENSE OF RIGHT AND WRONG"
    community 23
  ]
  node [
    id 1363
    label "E:RUNNING INTO THE ROAD"
    kind "entity"
    name "RUNNING INTO THE ROAD"
    community 23
  ]
  node [
    id 1364
    label "E:HARM"
    kind "entity"
    name "HARM"
    community 23
  ]
  node [
    id 1365
    label "E:HAIR"
    kind "entity"
    name "HAIR"
    community 23
  ]
  node [
    id 1366
    label "E:WAKES"
    kind "entity"
    name "WAKES"
    community 23
  ]
  node [
    id 1367
    label "E:STOPPING BELL"
    kind "entity"
    name "STOPPING BELL"
    community 23
  ]
  node [
    id 1368
    label "E:DOOR"
    kind "entity"
    name "DOOR"
    community 23
  ]
  node [
    id 1369
    label "E:TAKING THE CHILDREN OUT WITHOUT THEIR AUNT"
    kind "entity"
    name "TAKING THE CHILDREN OUT WITHOUT THEIR AUNT"
    community 23
  ]
  node [
    id 1370
    label "E:SHE CANNOT KEEP A THING QUIET"
    kind "entity"
    name "SHE CANNOT KEEP A THING QUIET"
    community 23
  ]
  node [
    id 1371
    label "E:PAPA'S PERMISSION"
    kind "entity"
    name "PAPA'S PERMISSION"
    community 23
  ]
  node [
    id 1372
    label "E:POOR, DEAR PAPA"
    kind "entity"
    name "POOR, DEAR PAPA"
    community 23
  ]
  node [
    id 1373
    label "E:GUARDING THE RUINS OF THE SWAN INN"
    kind "entity"
    name "GUARDING THE RUINS OF THE SWAN INN"
    community 23
  ]
  node [
    id 1374
    label "E:SEND OUTSIDERS INTO THE ROAD"
    kind "entity"
    name "SEND OUTSIDERS INTO THE ROAD"
    community 23
  ]
  node [
    id 1375
    label "E:LET THEM GUARD THEIR OWN RUINS"
    kind "entity"
    name "LET THEM GUARD THEIR OWN RUINS"
    community 23
  ]
  node [
    id 1376
    label "E:THEM"
    kind "entity"
    name "THEM"
    community 23
  ]
  node [
    id 1377
    label "E:THEIR HEADS"
    kind "entity"
    name "THEIR HEADS"
    community 23
  ]
  node [
    id 1378
    label "E:TARVER'S WIG"
    kind "entity"
    name "TARVER'S WIG"
    community 23
  ]
  node [
    id 1379
    label "E:WHAT THAT IS"
    kind "entity"
    name "WHAT THAT IS"
    community 23
  ]
  node [
    id 1380
    label "E:BELL"
    kind "entity"
    name "BELL"
    community 1
  ]
  node [
    id 1381
    label "C:Novel-40700_00074"
    kind "chunk"
    chunk_id "Novel-40700_00074"
  ]
  node [
    id 1382
    label "U:Novel-40700_00074#0"
    kind "unit"
    chunk_id "Novel-40700_00074"
    text "SALOME says the bell will wake Papa; SHEBA orders to stop the bell. GEORGIANA runs to the door and opens it. SALOME tells TARVER and DARBEY to fly, and they disappear through the curtains at the window. SHEBA falls into SALOME's arms and exclaims they have saved them. GEORGIANA calls out 'Tris, your man from the stable!' SIR TRISTRAM responds 'Hatcham!' GEORGIANA calls 'Hatcham' again, and HATCHAM, carrying a basin with a bolus, runs in breathlessly, followed by BLORE. HATCHAM says the villain who set fire to the 'Swan' was administering a dose to the horse in the act. GEORGIANA asks if the villain has robbed their Dandy. SIR TRISTRAM asks where the scoundrel is. HATCHAM says the villain knocked the constable's collar and has taken him in a cart to the lock-up. GEORGIANA and SIR TRISTRAM exclaim 'Oh!' BLORE is in agony and says they have taken the Dean."
    community 25
  ]
  node [
    id 1383
    label "E:CONSTABLE"
    kind "entity"
    name "CONSTABLE"
    community 26
  ]
  node [
    id 1384
    label "E:LOCK-UP"
    kind "entity"
    name "LOCK-UP"
    community 25
  ]
  node [
    id 1385
    label "E:BASIN WITH A BOLUS"
    kind "entity"
    name "BASIN WITH A BOLUS"
    community 25
  ]
  node [
    id 1386
    label "E:CART"
    kind "entity"
    name "CART"
    community 4
  ]
  node [
    id 1387
    label "E:PRISONER'S CELL"
    kind "entity"
    name "PRISONER'S CELL"
    community 25
  ]
  node [
    id 1388
    label "E:POLICE STATION"
    kind "entity"
    name "POLICE STATION"
    community 10
  ]
  node [
    id 1389
    label "E:PLASTER WALLS"
    kind "entity"
    name "PLASTER WALLS"
    community 25
  ]
  node [
    id 1390
    label "E:OAKEN BEAMS"
    kind "entity"
    name "OAKEN BEAMS"
    community 25
  ]
  node [
    id 1391
    label "E:GOTHIC MULLIONED WINDOW"
    kind "entity"
    name "GOTHIC MULLIONED WINDOW"
    community 25
  ]
  node [
    id 1392
    label "E:MASSIVE DOOR"
    kind "entity"
    name "MASSIVE DOOR"
    community 25
  ]
  node [
    id 1393
    label "E:SMALL SLIDING WICKET"
    kind "entity"
    name "SMALL SLIDING WICKET"
    community 25
  ]
  node [
    id 1394
    label "E:IRON GRATING"
    kind "entity"
    name "IRON GRATING"
    community 25
  ]
  node [
    id 1395
    label "E:STREET"
    kind "entity"
    name "STREET"
    community 25
  ]
  node [
    id 1396
    label "E:CURTAINS AT THE WINDOW"
    kind "entity"
    name "CURTAINS AT THE WINDOW"
    community 25
  ]
  node [
    id 1397
    label "E:SALOME'S ARMS"
    kind "entity"
    name "SALOME'S ARMS"
    community 25
  ]
  node [
    id 1398
    label "E:SCOUNDREL"
    kind "entity"
    name "SCOUNDREL"
    community 25
  ]
  node [
    id 1399
    label "E:OH"
    kind "entity"
    name "OH"
    community 5
  ]
  node [
    id 1400
    label "E:THEY HAVE GOT THE DEAN"
    kind "entity"
    name "THEY HAVE GOT THE DEAN"
    community 25
  ]
  node [
    id 1401
    label "U:Novel-40700_00074#1"
    kind "unit"
    chunk_id "Novel-40700_00074"
    text "The first scene of the third act takes place in the interior of a country police station, a quaint old room with plaster walls, oaken beams, and a gothic mullioned window looking onto the street. A massive door with a small sliding wicket and an iron grating opens to a prisoner's cell."
    community 25
  ]
  node [
    id 1402
    label "E:THIRD ACT"
    kind "entity"
    name "THIRD ACT"
    community 25
  ]
  node [
    id 1403
    label "E:FIRST SCENE"
    kind "entity"
    name "FIRST SCENE"
    community 25
  ]
  node [
    id 1404
    label "E:COUNTRY POLICE STATION"
    kind "entity"
    name "COUNTRY POLICE STATION"
    community 25
  ]
  node [
    id 1405
    label "E:QUAIN OLD ROOM"
    kind "entity"
    name "QUAIN OLD ROOM"
    community 25
  ]
  node [
    id 1406
    label "C:Novel-40700_00075"
    kind "chunk"
    chunk_id "Novel-40700_00075"
  ]
  node [
    id 1407
    label "U:Novel-40700_00075#0"
    kind "unit"
    chunk_id "Novel-40700_00075"
    text "A massive door with a small sliding wicket and an iron grating opens to a prisoner's cell. The room is partly furnished as a kitchen and partly as a police station, with a copy of the Police Regulations and other official documents and implements hanging on the wall. It is the morning after the events of the previous act. Hannah, a buxom, fresh-looking young woman in a print gown, has been cooking while singing gayly."
    community 25
  ]
  node [
    id 1408
    label "E:SLIDING WICKET"
    kind "entity"
    name "SLIDING WICKET"
    community 25
  ]
  node [
    id 1409
    label "E:POLICE REGULATIONS"
    kind "entity"
    name "POLICE REGULATIONS"
    community 25
  ]
  node [
    id 1410
    label "E:OFFICIAL DOCUMENTS"
    kind "entity"
    name "OFFICIAL DOCUMENTS"
    community 25
  ]
  node [
    id 1411
    label "E:IMPLEMENTS"
    kind "entity"
    name "IMPLEMENTS"
    community 25
  ]
  node [
    id 1412
    label "E:MORNING AFTER PREVIOUS ACT"
    kind "entity"
    name "MORNING AFTER PREVIOUS ACT"
    community 25
  ]
  node [
    id 1413
    label "E:HANNAH"
    kind "entity"
    name "HANNAH"
    community -1
  ]
  node [
    id 1414
    label "E:PRINT GOWN"
    kind "entity"
    name "PRINT GOWN"
    community 25
  ]
  node [
    id 1415
    label "E:WALL"
    kind "entity"
    name "WALL"
    community 25
  ]
  node [
    id 1416
    label "U:Novel-40700_00075#1"
    kind "unit"
    chunk_id "Novel-40700_00075"
    text "Hannah, a buxom, fresh-looking young woman in a print gown, is cooking while singing gayly and opens a door, calling out to Noah with a slight dialect. Noah responds from another room in a rough, country voice. Hannah asks if Noah will have his dinner before driving the prisoner to Durnstone, and Noah agrees. Hannah remarks that Noah is in a nice temper today over something and notes that all public characters are liable to irritation."
    community 25
  ]
  node [
    id 1417
    label "E:NOAH"
    kind "entity"
    name "NOAH"
    community -1
  ]
  node [
    id 1418
    label "E:PRISONER"
    kind "entity"
    name "PRISONER"
    community 21
  ]
  node [
    id 1419
    label "E:PUBLIC CHARACTERS"
    kind "entity"
    name "PUBLIC CHARACTERS"
    community 25
  ]
  node [
    id 1420
    label "E:IRRITATION"
    kind "entity"
    name "IRRITATION"
    community 25
  ]
  node [
    id 1421
    label "E:GAZYLY"
    kind "entity"
    name "GAZYLY"
    community 25
  ]
  node [
    id 1422
    label "E:ANOTHER ROOM"
    kind "entity"
    name "ANOTHER ROOM"
    community 25
  ]
  node [
    id 1423
    label "E:NOAH WILL HAVE DINNER BEFORE DRIVING PRISONER TO DURNSTONE"
    kind "entity"
    name "NOAH WILL HAVE DINNER BEFORE DRIVING PRISONER TO DURNSTONE"
    community 25
  ]
  node [
    id 1424
    label "E:HAVE DINNER BEFORE DRIVING PRISONER TO DURNSTONE"
    kind "entity"
    name "HAVE DINNER BEFORE DRIVING PRISONER TO DURNSTONE"
    community 25
  ]
  node [
    id 1425
    label "E:SOMETHING"
    kind "entity"
    name "SOMETHING"
    community 25
  ]
  node [
    id 1426
    label "U:Novel-40700_00075#2"
    kind "unit"
    chunk_id "Novel-40700_00075"
    text "There is a knock at the outer door. Hannah opens it and sees Blore with a troubled look on his face. Blore enters and shakes hands with Hannah mournfully. Hannah asks how the Dean is, calling him the sweetest soul in the world. Blore does not respond further."
    community 0
  ]
  node [
    id 1427
    label "E:OUTER DOOR"
    kind "entity"
    name "OUTER DOOR"
    community 0
  ]
  node [
    id 1428
    label "E:TRUBLED LOOK"
    kind "entity"
    name "TRUBLED LOOK"
    community 0
  ]
  node [
    id 1429
    label "E:MOURNING"
    kind "entity"
    name "MOURNING"
    community 0
  ]
  node [
    id 1430
    label "E:HANDSHAKES"
    kind "entity"
    name "HANDSHAKES"
    community 0
  ]
  node [
    id 1431
    label "E:SWEETEST SOUL IN THE WORLD"
    kind "entity"
    name "SWEETEST SOUL IN THE WORLD"
    community 0
  ]
  node [
    id 1432
    label "C:Novel-40700_00076"
    kind "chunk"
    chunk_id "Novel-40700_00076"
  ]
  node [
    id 1433
    label "U:Novel-40700_00076#0"
    kind "unit"
    chunk_id "Novel-40700_00076"
    text "HANNAH is asked about the Dean, and BLORE expresses surprise that she does not know of his misfortune. BLORE tells HANNAH that he hasn't seen the Dean this morning. HANNAH remarks that it is kind of BLORE to visit an old friend, Edward, and expresses sadness that since she left the Deanery seven years ago, no one from her former circle has visited her after she married a policeman at Durnstone. BLORE explains that the kitchen disapproved of her marriage to a policeman, calling it a messy alliance. HANNAH questions whether Mr. Topping's appointment as Head Constable at St. Marvells is seen as a positive, to which BLORE replies that it is a rise on the scales, though significant, and that HANNAH has only been in St. Marvells for a week and must still fight her way up. HANNAH says she feels as high as ever she is likely to be. BLORE adds that Jane, Sarah, and Willis the stable boy have been so kind as to leave cards for him, knowing he was calling on them, and he gives HANNAH three very dirty pieces of paste-board as proof."
    community 21
  ]
  node [
    id 1434
    label "E:EDWARD"
    kind "entity"
    name "EDWARD"
    community 21
  ]
  node [
    id 1435
    label "E:MARRIAGE TO POLICE OFFICER"
    kind "entity"
    name "MARRIAGE TO POLICE OFFICER"
    community 21
  ]
  node [
    id 1436
    label "E:HEAD CONSTABLE"
    kind "entity"
    name "HEAD CONSTABLE"
    community 21
  ]
  node [
    id 1437
    label "E:JANE"
    kind "entity"
    name "JANE"
    community 21
  ]
  node [
    id 1438
    label "E:SARAH"
    kind "entity"
    name "SARAH"
    community 21
  ]
  node [
    id 1439
    label "E:WILLIS THE STABLE BOY"
    kind "entity"
    name "WILLIS THE STABLE BOY"
    community 21
  ]
  node [
    id 1440
    label "E:PASTEBORD"
    kind "entity"
    name "PASTEBORD"
    community 21
  ]
  node [
    id 1441
    label "E:DEAN'S MISFORTUNE"
    kind "entity"
    name "DEAN'S MISFORTUNE"
    community 21
  ]
  node [
    id 1442
    label "E:DEAN THIS MORNING"
    kind "entity"
    name "DEAN THIS MORNING"
    community 21
  ]
  node [
    id 1443
    label "E:HANNAH'S MARRIAGE TO A POLICEMAN"
    kind "entity"
    name "HANNAH'S MARRIAGE TO A POLICEMAN"
    community 21
  ]
  node [
    id 1444
    label "E:HANNAH'S APPOINTMENT AT ST. MARVELLS"
    kind "entity"
    name "HANNAH'S APPOINTMENT AT ST. MARVELLS"
    community 21
  ]
  node [
    id 1445
    label "E:ST. MARVELLS FOR A WEEK"
    kind "entity"
    name "ST. MARVELLS FOR A WEEK"
    community 21
  ]
  node [
    id 1446
    label "E:HANNAH'S CURRENT STATE"
    kind "entity"
    name "HANNAH'S CURRENT STATE"
    community 21
  ]
  node [
    id 1447
    label "C:Novel-40700_00077"
    kind "chunk"
    chunk_id "Novel-40700_00077"
  ]
  node [
    id 1448
    label "U:Novel-40700_00077#0"
    kind "unit"
    chunk_id "Novel-40700_00077"
    text "Blore expresses pride in taking the visitors in with her apron and asks when their evening is. They receive visitors on Toosdays at the side gate. Blore greets Hannah warmly, but she refuses the kiss, saying that when she was Miss Hevans there were no social barriers. Blore claims that friendship is just a name, and asks if Mr. Topping is indoors, to which Hannah nods and says he is not. Blore claims Mr. Topping took a man up last night, and recalls that when a arrest was made in St. Marvells, the prisoner was usually lodged only for the night and driven to Durnstone Police Station the next morning by the head constable. Hannah says that is the rule, but Noah is behindhand today and will not go to Durnstone until after dinner. Blore concludes that the prisoner is now on the premises, and Hannah confirms he is in their cell. Blore then asks where the cell is, and Hannah says it is the cell itself."
    community 21
  ]
  node [
    id 1449
    label "E:TOOSDAYS"
    kind "entity"
    name "TOOSDAYS"
    community 21
  ]
  node [
    id 1450
    label "E:SIDE GATE"
    kind "entity"
    name "SIDE GATE"
    community 21
  ]
  node [
    id 1451
    label "E:DURNSTONE POLICE STATION"
    kind "entity"
    name "DURNSTONE POLICE STATION"
    community 21
  ]
  node [
    id 1452
    label "E:CELL"
    kind "entity"
    name "CELL"
    community 2
  ]
  node [
    id 1453
    label "E:SOCIAL BARRIERS"
    kind "entity"
    name "SOCIAL BARRIERS"
    community 21
  ]
  node [
    id 1454
    label "E:FRIENDSHIP"
    kind "entity"
    name "FRIENDSHIP"
    community 5
  ]
  node [
    id 1455
    label "E:APRON STRINGS"
    kind "entity"
    name "APRON STRINGS"
    community 21
  ]
  node [
    id 1456
    label "E:KISS"
    kind "entity"
    name "KISS"
    community 21
  ]
  node [
    id 1457
    label "E:RULE"
    kind "entity"
    name "RULE"
    community 21
  ]
  node [
    id 1458
    label "E:BEHINDHAND"
    kind "entity"
    name "BEHINDHAND"
    community 21
  ]
  node [
    id 1459
    label "E:APRON"
    kind "entity"
    name "APRON"
    community 21
  ]
  node [
    id 1460
    label "E:VISITORS"
    kind "entity"
    name "VISITORS"
    community 21
  ]
  node [
    id 1461
    label "E:MISS HEVANS"
    kind "entity"
    name "MISS HEVANS"
    community 21
  ]
  node [
    id 1462
    label "E:NAME"
    kind "entity"
    name "NAME"
    community 21
  ]
  node [
    id 1463
    label "E:LAST NIGHT"
    kind "entity"
    name "LAST NIGHT"
    community 9
  ]
  node [
    id 1464
    label "E:GOING TO DURNSTONE"
    kind "entity"
    name "GOING TO DURNSTONE"
    community 21
  ]
  node [
    id 1465
    label "E:AFTER DINNER"
    kind "entity"
    name "AFTER DINNER"
    community 21
  ]
  node [
    id 1466
    label "E:CELL ITSELF"
    kind "entity"
    name "CELL ITSELF"
    community 21
  ]
  node [
    id 1467
    label "C:Novel-40700_00078"
    kind "chunk"
    chunk_id "Novel-40700_00078"
  ]
  node [
    id 1468
    label "U:Novel-40700_00078#0"
    kind "unit"
    chunk_id "Novel-40700_00078"
    text "Hannah says the cell is the 'Strong-box' they call it in St. Marvells. Blore reacts with horror and mentions that the prisoner is accustomed to having his shaving water at eight and his gaiters buttoned by his kind hand. Hannah asks what is wrong with Blore, and Blore explains that he has called on her to respect the prisoner. Hannah questions if the honor is a compliment to her, and Blore replies that he is killing two birds with one stone. Hannah throws the cards into Blore's hat, telling him to take them back to the Deanery with Mrs. Topping's comps. Blore agrees to return the cards to her the next day, but adds that the unfortunate man was taken in their stables last night. Hannah says she never asks Noah about Queen's business and that Noah doesn't want two women over him. Blore asks if she has seen the miserable culprit, and Hannah replies that no, she was in bed hours when Noah brought him home and takes no interest in the matter."
    community 21
  ]
  node [
    id 1469
    label "E:STRONG-BOX"
    kind "entity"
    name "STRONG-BOX"
    community 21
  ]
  node [
    id 1470
    label "E:SHAVING WATER"
    kind "entity"
    name "SHAVING WATER"
    community 21
  ]
  node [
    id 1471
    label "E:EIGHT"
    kind "entity"
    name "EIGHT"
    community 21
  ]
  node [
    id 1472
    label "E:GAITERS"
    kind "entity"
    name "GAITERS"
    community 21
  ]
  node [
    id 1473
    label "E:MISERABLE CULPRIT"
    kind "entity"
    name "MISERABLE CULPRIT"
    community 21
  ]
  node [
    id 1474
    label "E:QUEEN'S BUSINESS"
    kind "entity"
    name "QUEEN'S BUSINESS"
    community 21
  ]
  node [
    id 1475
    label "E:MRS. TOPPING"
    kind "entity"
    name "MRS. TOPPING"
    community 23
  ]
  node [
    id 1476
    label "E:LOR'"
    kind "entity"
    name "LOR'"
    community 21
  ]
  node [
    id 1477
    label "E:HOURS"
    kind "entity"
    name "HOURS"
    community 21
  ]
  node [
    id 1478
    label "E:SHAVING WATER AT EIGHT"
    kind "entity"
    name "SHAVING WATER AT EIGHT"
    community 21
  ]
  node [
    id 1479
    label "E:HANNAH TO RESPECT THE PRISONER"
    kind "entity"
    name "HANNAH TO RESPECT THE PRISONER"
    community 21
  ]
  node [
    id 1480
    label "E:COMPLIMENT TO HER"
    kind "entity"
    name "COMPLIMENT TO HER"
    community 21
  ]
  node [
    id 1481
    label "E:MY DEAR"
    kind "entity"
    name "MY DEAR"
    community 21
  ]
  node [
    id 1482
    label "E:BLORE'S HAT"
    kind "entity"
    name "BLORE'S HAT"
    community 21
  ]
  node [
    id 1483
    label "E:HANNAH THE NEXT DAY"
    kind "entity"
    name "HANNAH THE NEXT DAY"
    community 21
  ]
  node [
    id 1484
    label "E:STABLES LAST NIGHT"
    kind "entity"
    name "STABLES LAST NIGHT"
    community 21
  ]
  node [
    id 1485
    label "E:TWO WOMEN OVER HIM"
    kind "entity"
    name "TWO WOMEN OVER HIM"
    community 21
  ]
  node [
    id 1486
    label "E:MATTER"
    kind "entity"
    name "MATTER"
    community 21
  ]
  node [
    id 1487
    label "C:Novel-40700_00079"
    kind "chunk"
    chunk_id "Novel-40700_00079"
  ]
  node [
    id 1488
    label "U:Novel-40700_00079#0"
    kind "unit"
    chunk_id "Novel-40700_00079"
    text "Hannah says she was in bed hours when Noah brought someone home; she takes no interest in the matter. They believe the case involves only a poor poacher or petty larceny in St. Marvells. Hannah believes her husband Noah will never have a chance of a horrific murder in a place that favors Conservatives. Hannah kneels to look into the oven, indicating her joint is burning."
    community 10
  ]
  node [
    id 1489
    label "E:POACHER"
    kind "entity"
    name "POACHER"
    community 10
  ]
  node [
    id 1490
    label "E:PETTY LARCERY"
    kind "entity"
    name "PETTY LARCERY"
    community 10
  ]
  node [
    id 1491
    label "E:CONSERVATIVE"
    kind "entity"
    name "CONSERVATIVE"
    community 10
  ]
  node [
    id 1492
    label "E:JOINT"
    kind "entity"
    name "JOINT"
    community 10
  ]
  node [
    id 1493
    label "E:OVEN"
    kind "entity"
    name "OVEN"
    community 4
  ]
  node [
    id 1494
    label "U:Novel-40700_00079#1"
    kind "unit"
    chunk_id "Novel-40700_00079"
    text "Blore suggests that the case Hannah has now might shake old England to its foundation, possibly leading to newspaper columns with Topping's name appearing. He imagines the case could hold its own in family reading, even surpassing divorce cases. Hannah responds by saying she knows something about the arrest. Blore denies knowing anything about the arrest, stating he only made a hypothetical suggestion to encourage her hope that crime might improve their married life."
    community 10
  ]
  node [
    id 1495
    label "E:CASE"
    kind "entity"
    name "CASE"
    community 10
  ]
  node [
    id 1496
    label "E:OLD ENGLAND"
    kind "entity"
    name "OLD ENGLAND"
    community 10
  ]
  node [
    id 1497
    label "E:NEWSPAPER COLUMNS"
    kind "entity"
    name "NEWSPAPER COLUMNS"
    community 10
  ]
  node [
    id 1498
    label "E:TOPPING"
    kind "entity"
    name "TOPPING"
    community 10
  ]
  node [
    id 1499
    label "E:FAMILY READING"
    kind "entity"
    name "FAMILY READING"
    community 10
  ]
  node [
    id 1500
    label "E:DIVORCE CASES"
    kind "entity"
    name "DIVORCE CASES"
    community 10
  ]
  node [
    id 1501
    label "E:ARREST"
    kind "entity"
    name "ARREST"
    community 10
  ]
  node [
    id 1502
    label "U:Novel-40700_00079#2"
    kind "unit"
    chunk_id "Novel-40700_00079"
    text "Hannah states that the man was found trespassing in the Deanery Stables with intent to commit a crime, and he refuses to give his name or any account of himself. Blore, to himself, says he would like to know whether Dandy Dick had any of the medicine, which would help him at the races. He questions whether the horse in the stables took it."
    community 24
  ]
  node [
    id 1503
    label "E:INTENT"
    kind "entity"
    name "INTENT"
    community 24
  ]
  node [
    id 1504
    label "E:REFUSES TO GIVE NAME"
    kind "entity"
    name "REFUSES TO GIVE NAME"
    community 24
  ]
  node [
    id 1505
    label "E:MEDICINE"
    kind "entity"
    name "MEDICINE"
    community 24
  ]
  node [
    id 1506
    label "C:Novel-40700_00080"
    kind "chunk"
    chunk_id "Novel-40700_00080"
  ]
  node [
    id 1507
    label "U:Novel-40700_00080#0"
    kind "unit"
    chunk_id "Novel-40700_00080"
    text "Blore asks Hannah if the horse in the stables was taken, and Hannah is confused, asking what was taken. Blore then inquires if there is any confession, and as he bends over Hannah, Noah Topping enters. Noah is described as a dense-looking, ugly countryman with red hair, a bristling beard, and a vindictive leer, dressed in ill-fitting clothes as a rural Police Constable. Noah greets Blore by saying a friend of hers is a friend of his. Hannah quickly reassures Blore that he is an old friend of hers from the Deanery. Noah comments that Hannah is getting a lot of nice new friends this week since they moved to St. Marvells. Blore acknowledges that Hannah was a lovin' favorite with everybody. Noah then states that since her friends are his, he is taking the liberty of gradually dropping on them all."
    community 4
  ]
  node [
    id 1508
    label "E:CONFESSON"
    kind "entity"
    name "CONFESSON"
    community 4
  ]
  node [
    id 1509
    label "E:NEW FRIENDS"
    kind "entity"
    name "NEW FRIENDS"
    community 4
  ]
  node [
    id 1510
    label "E:POLICE CONSTABLE"
    kind "entity"
    name "POLICE CONSTABLE"
    community 4
  ]
  node [
    id 1511
    label "E:RED HAIR"
    kind "entity"
    name "RED HAIR"
    community 4
  ]
  node [
    id 1512
    label "E:BRISTLING BEARD"
    kind "entity"
    name "BRISTLING BEARD"
    community 4
  ]
  node [
    id 1513
    label "E:VINDICTIVE LEER"
    kind "entity"
    name "VINDICTIVE LEER"
    community 4
  ]
  node [
    id 1514
    label "E:ILL-FITTING CLOTHES"
    kind "entity"
    name "ILL-FITTING CLOTHES"
    community 4
  ]
  node [
    id 1515
    label "E:LOVIN' FAVORITE"
    kind "entity"
    name "LOVIN' FAVORITE"
    community 4
  ]
  node [
    id 1516
    label "E:DENSE-LOOKING"
    kind "entity"
    name "DENSE-LOOKING"
    community 4
  ]
  node [
    id 1517
    label "E:UGLY"
    kind "entity"
    name "UGLY"
    community 4
  ]
  node [
    id 1518
    label "E:FRIENDS"
    kind "entity"
    name "FRIENDS"
    community 4
  ]
  node [
    id 1519
    label "E:DROPPING ON THEM"
    kind "entity"
    name "DROPPING ON THEM"
    community 4
  ]
  node [
    id 1520
    label "E:WHAT WAS TAKEN"
    kind "entity"
    name "WHAT WAS TAKEN"
    community 4
  ]
  node [
    id 1521
    label "E:DENSE-LOOKING UGLY COUNTRYMAN WITH RED HAIR AND BRISTLING BEARD"
    kind "entity"
    name "DENSE-LOOKING UGLY COUNTRYMAN WITH RED HAIR AND BRISTLING BEARD"
    community 4
  ]
  node [
    id 1522
    label "E:RURAL POLICE CONSTABLE"
    kind "entity"
    name "RURAL POLICE CONSTABLE"
    community 4
  ]
  node [
    id 1523
    label "E:OLD FRIEND FROM THE DEANERY"
    kind "entity"
    name "OLD FRIEND FROM THE DEANERY"
    community 4
  ]
  node [
    id 1524
    label "E:LOT OF NICE NEW FRIENDS SINCE THEY MOVED TO ST. MARVELLS"
    kind "entity"
    name "LOT OF NICE NEW FRIENDS SINCE THEY MOVED TO ST. MARVELLS"
    community 4
  ]
  node [
    id 1525
    label "E:LOVIN' FAVORITE WITH EVERYBODY"
    kind "entity"
    name "LOVIN' FAVORITE WITH EVERYBODY"
    community 4
  ]
  node [
    id 1526
    label "E:GRADUALLY DROPPING ON HER FRIENDS"
    kind "entity"
    name "GRADUALLY DROPPING ON HER FRIENDS"
    community 4
  ]
  node [
    id 1527
    label "C:Novel-40700_00081"
    kind "chunk"
    chunk_id "Novel-40700_00081"
  ]
  node [
    id 1528
    label "U:Novel-40700_00081#0"
    kind "unit"
    chunk_id "Novel-40700_00081"
    text "Blore calls to find out if anything has been found about the ruffian who took in the stables the previous night, and claims it is his master's business, not his own. Noah responds that it is his master's business and says he will run up to the Deanery to see the Dean after taking his man to Durnstone. Blore thanks him and wishes him well, offering his hand into which Noah places his truncheon before leaving."
    community 9
  ]
  node [
    id 1529
    label "E:RUFFIAN"
    kind "entity"
    name "RUFFIAN"
    community 9
  ]
  node [
    id 1530
    label "E:TRUNCHEON"
    kind "entity"
    name "TRUNCHEON"
    community 9
  ]
  node [
    id 1531
    label "E:MASTER'S BUSINESS"
    kind "entity"
    name "MASTER'S BUSINESS"
    community 9
  ]
  node [
    id 1532
    label "E:BLORE'S HAND"
    kind "entity"
    name "BLORE'S HAND"
    community 9
  ]
  node [
    id 1533
    label "U:Novel-40700_00081#1"
    kind "unit"
    chunk_id "Novel-40700_00081"
    text "Hannah whispers that she does not believe they will ever have a large circle of friends around them. Noah responds by selecting a pair of handcuffs, examining them critically, and then turns to Hannah, telling her to brighten up because she has only a little time with him at home."
    community 2
  ]
  node [
    id 1534
    label "E:HANDCUFFS"
    kind "entity"
    name "HANDCUFFS"
    community 2
  ]
  node [
    id 1535
    label "E:TIME"
    kind "entity"
    name "TIME"
    community 2
  ]
  node [
    id 1536
    label "E:HOMES"
    kind "entity"
    name "HOMES"
    community 2
  ]
  node [
    id 1537
    label "E:HAVING FRIENDS AROUND"
    kind "entity"
    name "HAVING FRIENDS AROUND"
    community 2
  ]
  node [
    id 1538
    label "E:LITTLE TIME AT HOME"
    kind "entity"
    name "LITTLE TIME AT HOME"
    community 2
  ]
  node [
    id 1539
    label "C:Novel-40700_00082"
    kind "chunk"
    chunk_id "Novel-40700_00082"
  ]
  node [
    id 1540
    label "U:Novel-40700_00082#0"
    kind "unit"
    chunk_id "Novel-40700_00082"
    text "Noah plans to go to the stable to put old Nick in the cart, claiming he can reach the edge of the hill in half the time, and mentions he is going to get a glimpse of the racin' on his way over. He looks into the stable and sees Nick, who is sulky, and instructs Hannah to open the oven door to let the smell of cooking enter the stable, saying it is torture but his rule when dealing with stubborn creatures. Hannah refuses, but Noah insists and she opens the oven door. As Noah departs, the woful face of the Dean appears at the wicket, his head still in a fur cap."
    community 4
  ]
  node [
    id 1541
    label "E:OLD NICK"
    kind "entity"
    name "OLD NICK"
    community 4
  ]
  node [
    id 1542
    label "E:RACIN'"
    kind "entity"
    name "RACIN'"
    community 4
  ]
  node [
    id 1543
    label "E:COOKING"
    kind "entity"
    name "COOKING"
    community 4
  ]
  node [
    id 1544
    label "E:TORTURE"
    kind "entity"
    name "TORTURE"
    community 4
  ]
  node [
    id 1545
    label "E:WICKET"
    kind "entity"
    name "WICKET"
    community 26
  ]
  node [
    id 1546
    label "E:FUR CAP"
    kind "entity"
    name "FUR CAP"
    community 4
  ]
  node [
    id 1547
    label "E:OLD NICK IN THE CART"
    kind "entity"
    name "OLD NICK IN THE CART"
    community 4
  ]
  node [
    id 1548
    label "E:SULKY"
    kind "entity"
    name "SULKY"
    community 4
  ]
  node [
    id 1549
    label "E:OPENING THE OVEN"
    kind "entity"
    name "OPENING THE OVEN"
    community 4
  ]
  node [
    id 1550
    label "E:STUBBORN CREATURES"
    kind "entity"
    name "STUBBORN CREATURES"
    community 4
  ]
  node [
    id 1551
    label "U:Novel-40700_00082#1"
    kind "unit"
    chunk_id "Novel-40700_00082"
    text "Hannah shuts the oven door after Noah opens it, and expresses that she does not want to be involved in the torture of opening the oven door."
    community 4
  ]
  node [
    id 1552
    label "C:Novel-40700_00083"
    kind "chunk"
    chunk_id "Novel-40700_00083"
  ]
  node [
    id 1553
    label "U:Novel-40700_00083#0"
    kind "unit"
    chunk_id "Novel-40700_00083"
    text "Hannah shuts the oven door and declares she will not torture prisoners like in the Middling Ages, as Noah always talks about, but not in her time. She crosses close to the wicket and her face nearly touches the Dean's, causing her to cry out. The Dean appears and disappears. Hannah exclaims, 'Oh, no! Not my old master! Never the master!' She totters to the wicket and looks in. She calls out, 'Master! Look at me! It's 'Annah, your poor faithful servant, 'Annah!' The Dean's face reappears. The Dean says in a deep sad voice, 'Hannah Evans.' Hannah identifies herself as 'Annah Topping, Knee Evans, wife of the Constable who is going to take you to cruel Durnstone.' She sinks weeping upon the ground at the door and repeatedly asks, 'Oh, Mr. Dean, sir, what have you been up to? What have you been up to? What have you been up to?' The Dean responds, 'Woman, I am the victim of a misfortune only partially merited.' Hannah, on her knees, clasps her hands and asks, 'Tell me what you've done, Master dear; give it a name, for the love of goodness.' The Dean says, 'My poor Hannah, I fear I have placed myself in an equivocal position.' Hannah shrieks in despair, and the Dean commands her to be quiet."
    community 26
  ]
  node [
    id 1554
    label "E:MIDDLING AGES"
    kind "entity"
    name "MIDDLING AGES"
    community 26
  ]
  node [
    id 1555
    label "E:HANNAH EVANS"
    kind "entity"
    name "HANNAH EVANS"
    community 26
  ]
  node [
    id 1556
    label "E:ANNAH TOPPING"
    kind "entity"
    name "ANNAH TOPPING"
    community 26
  ]
  node [
    id 1557
    label "E:KNEE EVANS"
    kind "entity"
    name "KNEE EVANS"
    community 26
  ]
  node [
    id 1558
    label "E:DEAN'S"
    kind "entity"
    name "DEAN'S"
    community 26
  ]
  node [
    id 1559
    label "E:FAITHFUL SERVANT"
    kind "entity"
    name "FAITHFUL SERVANT"
    community 26
  ]
  node [
    id 1560
    label "E:EQUIVOCAL POSITION"
    kind "entity"
    name "EQUIVOCAL POSITION"
    community 26
  ]
  node [
    id 1561
    label "E:MISFORTUNE"
    kind "entity"
    name "MISFORTUNE"
    community 26
  ]
  node [
    id 1562
    label "E:PRISONERS"
    kind "entity"
    name "PRISONERS"
    community 26
  ]
  node [
    id 1563
    label "E:TORTURING"
    kind "entity"
    name "TORTURING"
    community 26
  ]
  node [
    id 1564
    label "E:OLD MASTER"
    kind "entity"
    name "OLD MASTER"
    community 26
  ]
  node [
    id 1565
    label "E:MASTER"
    kind "entity"
    name "MASTER"
    community 26
  ]
  node [
    id 1566
    label "E:WIFE"
    kind "entity"
    name "WIFE"
    community 26
  ]
  node [
    id 1567
    label "E:CRUEL DURNSTONE"
    kind "entity"
    name "CRUEL DURNSTONE"
    community 26
  ]
  node [
    id 1568
    label "E:GROUND"
    kind "entity"
    name "GROUND"
    community 26
  ]
  node [
    id 1569
    label "E:WHAT HAVE YOU BEEN UP TO"
    kind "entity"
    name "WHAT HAVE YOU BEEN UP TO"
    community 26
  ]
  node [
    id 1570
    label "E:ON HER KNEES"
    kind "entity"
    name "ON HER KNEES"
    community 26
  ]
  node [
    id 1571
    label "C:Novel-40700_00084"
    kind "chunk"
    chunk_id "Novel-40700_00084"
  ]
  node [
    id 1572
    label "U:Novel-40700_00084#0"
    kind "unit"
    chunk_id "Novel-40700_00084"
    text "Hannah shrieks in despair and asks the Dean if a change in cooking has led to his current behavior, noting that she cooked for him for seven happy years. The Dean acknowledges that she still has culinary skill, and Hannah asks if he is hungry, to which he responds that he is sorely tried by her domestic preparations. Hannah then declares that Noah cannot put the horse to under ten minutes, produces a large key to unlock the cell door, and requests that the Dean give her his patrol not to cut. The Dean says he would resent such an insinuation under other circumstances, but Hannah insists on not being resentful and urges him to shove hard. She pulls the door open enough to let the Dean enter the room, where he greets her and says he hopes she has improved. Hannah hysterically throws herself upon the Dean, and he sternly pushes her away, calling her Hannah and Mrs. Topping. Hannah responds that crime levels are all, dear sir."
    community 23
  ]
  node [
    id 1573
    label "E:STREETS DOOR"
    kind "entity"
    name "STREETS DOOR"
    community 23
  ]
  node [
    id 1574
    label "E:STRONG BOX"
    kind "entity"
    name "STRONG BOX"
    community 23
  ]
  node [
    id 1575
    label "E:DUPLIKIT KEY"
    kind "entity"
    name "DUPLIKIT KEY"
    community 23
  ]
  node [
    id 1576
    label "E:CELL DOOR"
    kind "entity"
    name "CELL DOOR"
    community 23
  ]
  node [
    id 1577
    label "E:PATROL"
    kind "entity"
    name "PATROL"
    community 23
  ]
  node [
    id 1578
    label "E:CRIME LEVELS"
    kind "entity"
    name "CRIME LEVELS"
    community 23
  ]
  node [
    id 1579
    label "E:HANNAH'S DOMESTIC PREPARATIONS"
    kind "entity"
    name "HANNAH'S DOMESTIC PREPARATIONS"
    community 23
  ]
  node [
    id 1580
    label "E:NOAH CANNOT PUT THE HORSE TO UNDER TEN MINUTES"
    kind "entity"
    name "NOAH CANNOT PUT THE HORSE TO UNDER TEN MINUTES"
    community 23
  ]
  node [
    id 1581
    label "E:DEAN TO GIVE HER PATROL NOT TO CUT"
    kind "entity"
    name "DEAN TO GIVE HER PATROL NOT TO CUT"
    community 23
  ]
  node [
    id 1582
    label "E:HANNAH'S INSINUATION"
    kind "entity"
    name "HANNAH'S INSINUATION"
    community 23
  ]
  node [
    id 1583
    label "E:DEAN TO SHOVE HARD"
    kind "entity"
    name "DEAN TO SHOVE HARD"
    community 23
  ]
  node [
    id 1584
    label "E:HANNAH'S PULL"
    kind "entity"
    name "HANNAH'S PULL"
    community 23
  ]
  node [
    id 1585
    label "E:CRIME LEVELS ARE ALL"
    kind "entity"
    name "CRIME LEVELS ARE ALL"
    community 23
  ]
  node [
    id 1586
    label "C:Novel-40700_00085"
    kind "chunk"
    chunk_id "Novel-40700_00085"
  ]
  node [
    id 1587
    label "U:Novel-40700_00085#0"
    kind "unit"
    chunk_id "Novel-40700_00085"
    text "Mrs. Topping and the Dean discuss the perception of criminality attached to the Dean, who claims he is innocent and even injured in the eyes of the law. The Dean states that admitting his temporary moral aberration would damage his dignity, which he considers a priceless possession of middle age, and would make it impossible for him to face his children who have previously regarded him as faultless."
    community 23
  ]
  node [
    id 1588
    label "E:LAW"
    kind "entity"
    name "LAW"
    community 23
  ]
  node [
    id 1589
    label "E:MORAL ABERRATION"
    kind "entity"
    name "MORAL ABERRATION"
    community 23
  ]
  node [
    id 1590
    label "E:DIGNITY"
    kind "entity"
    name "DIGNITY"
    community 23
  ]
  node [
    id 1591
    label "E:MIDDLE AGE"
    kind "entity"
    name "MIDDLE AGE"
    community 23
  ]
  node [
    id 1592
    label "E:ST."
    kind "entity"
    name "ST."
    community 23
  ]
  node [
    id 1593
    label "E:INNOCENT AND INJURED IN THE EYES OF THE LAW"
    kind "entity"
    name "INNOCENT AND INJURED IN THE EYES OF THE LAW"
    community 23
  ]
  node [
    id 1594
    label "U:Novel-40700_00085#1"
    kind "unit"
    chunk_id "Novel-40700_00085"
    text "Hannah places bread and other food items on the table, and the Dean expresses that a single word to those at the Deanery would restore him to home, family, and his accustomed diet."
    community 0
  ]
  node [
    id 1595
    label "E:HOME"
    kind "entity"
    name "HOME"
    community 0
  ]
  node [
    id 1596
    label "E:FAMILY"
    kind "entity"
    name "FAMILY"
    community 0
  ]
  node [
    id 1597
    label "E:ACCUSTOMED DIET"
    kind "entity"
    name "ACCUSTOMED DIET"
    community 0
  ]
  node [
    id 1598
    label "E:BREAD"
    kind "entity"
    name "BREAD"
    community 0
  ]
  node [
    id 1599
    label "E:OTHER THINGS"
    kind "entity"
    name "OTHER THINGS"
    community 0
  ]
  node [
    id 1600
    label "E:BREAD AND OTHER THINGS ON THE TABLE"
    kind "entity"
    name "BREAD AND OTHER THINGS ON THE TABLE"
    community 0
  ]
  node [
    id 1601
    label "C:Novel-40700_00086"
    kind "chunk"
    chunk_id "Novel-40700_00086"
  ]
  node [
    id 1602
    label "U:Novel-40700_00086#0"
    kind "unit"
    chunk_id "Novel-40700_00086"
    text "Hannah questions how the Dean could walk erect in the streets of St. Marvells with his name blazoned on the Records of a Police Station of the very humblest description, after which she expresses that it is a treat to hear him compared to the ordinary criminal class."
    community 10
  ]
  node [
    id 1603
    label "E:HUMBLEST DESCRIPTION"
    kind "entity"
    name "HUMBLEST DESCRIPTION"
    community 10
  ]
  node [
    id 1604
    label "E:ORDINARY CRIMINAL CLASS"
    kind "entity"
    name "ORDINARY CRIMINAL CLASS"
    community 10
  ]
  node [
    id 1605
    label "U:Novel-40700_00086#1"
    kind "unit"
    chunk_id "Novel-40700_00086"
    text "The Dean expresses that his only hope of avoiding a calamity of almost national importance is to have a word with the Durnstone Superintendent, and that Hannah and the Superintendent will be the sole keepers of his secret, which he hopes will bring lasting comfort to both of them."
    community 4
  ]
  node [
    id 1606
    label "E:DURNSTONE SUPERINTENDENT"
    kind "entity"
    name "DURNSTONE SUPERINTENDENT"
    community 4
  ]
  node [
    id 1607
    label "E:CALAMITY"
    kind "entity"
    name "CALAMITY"
    community 4
  ]
  node [
    id 1608
    label "E:NATIONAL IMPORTANCE"
    kind "entity"
    name "NATIONAL IMPORTANCE"
    community 4
  ]
  node [
    id 1609
    label "E:SECRET"
    kind "entity"
    name "SECRET"
    community 4
  ]
  node [
    id 1610
    label "E:LASTING COMFORT"
    kind "entity"
    name "LASTING COMFORT"
    community 4
  ]
  node [
    id 1611
    label "E:AVERTING A CALAMITY OF ALMOST NATIONAL IMPORTANCE"
    kind "entity"
    name "AVERTING A CALAMITY OF ALMOST NATIONAL IMPORTANCE"
    community 4
  ]
  node [
    id 1612
    label "E:HANNAH AND DURNSTONE SUPERINTENDENT"
    kind "entity"
    name "HANNAH AND DURNSTONE SUPERINTENDENT"
    community 4
  ]
  node [
    id 1613
    label "U:Novel-40700_00086#2"
    kind "unit"
    chunk_id "Novel-40700_00086"
    text "Hannah asks if the Dean's story is his only chance of getting off unknown, to which the Dean confirms it is the sole remaining chance of averting a calamity of almost national importance."
    community 4
  ]
  node [
    id 1614
    label "E:CHANCE"
    kind "entity"
    name "CHANCE"
    community 4
  ]
  node [
    id 1615
    label "E:GETTING OFF UNKNOWN"
    kind "entity"
    name "GETTING OFF UNKNOWN"
    community 4
  ]
  node [
    id 1616
    label "U:Novel-40700_00086#3"
    kind "unit"
    chunk_id "Novel-40700_00086"
    text "Hannah states that the Superintendent at Durnstone, John Ruggles, and the two Inspectors, Whitaker and Parker, along with their wives and families, are all chapel folk."
    community 4
  ]
  node [
    id 1617
    label "E:JOHN RUGGLES"
    kind "entity"
    name "JOHN RUGGLES"
    community 4
  ]
  node [
    id 1618
    label "E:INSPECTOR WHITAKER"
    kind "entity"
    name "INSPECTOR WHITAKER"
    community 4
  ]
  node [
    id 1619
    label "E:INSPECTOR PARKER"
    kind "entity"
    name "INSPECTOR PARKER"
    community 4
  ]
  node [
    id 1620
    label "E:WIVES AND FAMILIES"
    kind "entity"
    name "WIVES AND FAMILIES"
    community 4
  ]
  node [
    id 1621
    label "E:CHAPEL FOLK"
    kind "entity"
    name "CHAPEL FOLK"
    community 4
  ]
  node [
    id 1622
    label "C:Novel-40700_00087"
    kind "chunk"
    chunk_id "Novel-40700_00087"
  ]
  node [
    id 1623
    label "U:Novel-40700_00087#0"
    kind "unit"
    chunk_id "Novel-40700_00087"
    text "Hannah claims that the people and their families are chapel folk. The Dean is aghast and sinks into a chair with his head on the table. Hannah states she was well fed and stayed seven years at the Deanery, and has been married to Noah Topping for eight weeks, which amounts to six years and ten months of marital duty before she owes nothing to him. She insists the Dean will not be taken to Durnstone. The Dean says his duty is to inform Hannah that her reasoning shows more credit to her heart than to her head. Hannah explains that the Devil is always in a woman's heart because it is the warmest place to get to. She takes a small key from a table drawer and gives it to the Dean, saying it unlocks his handcuffs when he escapes from Noah Topping. The Dean questions how he can get free, and Hannah explains that Noah drives him to Durnstone with a horse named Old Nick in the cart. The Dean exclaims 'Old Nick!' and Hannah confirms that Old Nick is the horse."
    community 4
  ]
  node [
    id 1624
    label "E:SEVEN YEARS"
    kind "entity"
    name "SEVEN YEARS"
    community 4
  ]
  node [
    id 1625
    label "E:EIGHT WEEKS"
    kind "entity"
    name "EIGHT WEEKS"
    community 3
  ]
  node [
    id 1626
    label "E:SIX YEARS AND TEN MONTHS"
    kind "entity"
    name "SIX YEARS AND TEN MONTHS"
    community 4
  ]
  node [
    id 1627
    label "E:WOMAN'S HEART"
    kind "entity"
    name "WOMAN'S HEART"
    community 4
  ]
  node [
    id 1628
    label "E:DEVIL"
    kind "entity"
    name "DEVIL"
    community 8
  ]
  node [
    id 1629
    label "E:KEY"
    kind "entity"
    name "KEY"
    community 4
  ]
  node [
    id 1630
    label "E:TABLE DRAWER"
    kind "entity"
    name "TABLE DRAWER"
    community 4
  ]
  node [
    id 1631
    label "E:HANNAH'S STATEMENT"
    kind "entity"
    name "HANNAH'S STATEMENT"
    community 4
  ]
  node [
    id 1632
    label "E:SEVEN YEARS AT THE DEANERY"
    kind "entity"
    name "SEVEN YEARS AT THE DEANERY"
    community 4
  ]
  node [
    id 1633
    label "C:Novel-40700_00088"
    kind "chunk"
    chunk_id "Novel-40700_00088"
  ]
  node [
    id 1634
    label "U:Novel-40700_00088#0"
    kind "unit"
    chunk_id "Novel-40700_00088"
    text "Nick, a horse, was formerly a member of the Durnstone Fire Brigade and responds to the signal of a double whistle by being unable to be held. When the signal is heard, one should turn into Pear Tree Lane, blow once, and then see Noah with his nose in the air pulling fit to wrench his hands off. The person should jump out, roll clear of the wheel, stay cool and hopeful, and then blow again. After that, before the mud can be wiped from the eyes, Noah, the horse, and the cart will be well into Durnstone, and may Providence restore a young husband safe to his doating wife."
    community 6
  ]
  node [
    id 1635
    label "E:NICK"
    kind "entity"
    name "NICK"
    community 6
  ]
  node [
    id 1636
    label "E:DURNSTONE FIRE BRIGADE"
    kind "entity"
    name "DURNSTONE FIRE BRIGADE"
    community 6
  ]
  node [
    id 1637
    label "E:DOUBLE WHISTLE"
    kind "entity"
    name "DOUBLE WHISTLE"
    community 6
  ]
  node [
    id 1638
    label "E:PEAR TREE LANE"
    kind "entity"
    name "PEAR TREE LANE"
    community 6
  ]
  node [
    id 1639
    label "E:MUD"
    kind "entity"
    name "MUD"
    community 6
  ]
  node [
    id 1640
    label "E:PROVIDENCE"
    kind "entity"
    name "PROVIDENCE"
    community 6
  ]
  node [
    id 1641
    label "E:YOUNG HUSBAND"
    kind "entity"
    name "YOUNG HUSBAND"
    community 6
  ]
  node [
    id 1642
    label "E:DOATING WIFE"
    kind "entity"
    name "DOATING WIFE"
    community 6
  ]
  node [
    id 1643
    label "E:NICK TO BE UNABLE TO BE HELD"
    kind "entity"
    name "NICK TO BE UNABLE TO BE HELD"
    community 6
  ]
  node [
    id 1644
    label "E:TO SEE NOAH WITH HIS NOSE IN THE AIR PULLING FIT TO WRENCH HIS HANDS OFF"
    kind "entity"
    name "TO SEE NOAH WITH HIS NOSE IN THE AIR PULLING FIT TO WRENCH HIS HANDS OFF"
    community 6
  ]
  node [
    id 1645
    label "E:JUMP OUT"
    kind "entity"
    name "JUMP OUT"
    community 6
  ]
  node [
    id 1646
    label "E:ROLL CLEAR OF THE WHEEL"
    kind "entity"
    name "ROLL CLEAR OF THE WHEEL"
    community 6
  ]
  node [
    id 1647
    label "E:STAY COOL AND HOPEFUL"
    kind "entity"
    name "STAY COOL AND HOPEFUL"
    community 6
  ]
  node [
    id 1648
    label "E:BLOW AGAIN"
    kind "entity"
    name "BLOW AGAIN"
    community 6
  ]
  node [
    id 1649
    label "E:NOAH AND THE HORSE AND CART BEING WELL INTO DURNSTONE"
    kind "entity"
    name "NOAH AND THE HORSE AND CART BEING WELL INTO DURNSTONE"
    community 6
  ]
  node [
    id 1650
    label "E:YOUNG HUSBAND SAFE TO HIS DOATING WIFE"
    kind "entity"
    name "YOUNG HUSBAND SAFE TO HIS DOATING WIFE"
    community 6
  ]
  node [
    id 1651
    label "U:Novel-40700_00088#1"
    kind "unit"
    chunk_id "Novel-40700_00088"
    text "Hannah says that the Dean's first offence was the instruction about alighting from a vehicle in motion, and she claims he is not too old to have another start in life. She says this is his first offence, and that she wants to give him another start in life, though the Dean expresses horror and claims he has no conscience and realizes the enormity of the difficulties in alighting from a vehicle in rapid motion."
    community 6
  ]
  node [
    id 1652
    label "E:FIRST OFFENCE"
    kind "entity"
    name "FIRST OFFENCE"
    community 6
  ]
  node [
    id 1653
    label "E:ALIGHTING FROM A VEHICLE IN RAPID MOTION"
    kind "entity"
    name "ALIGHTING FROM A VEHICLE IN RAPID MOTION"
    community 6
  ]
  node [
    id 1654
    label "E:ANOTHER START IN LIFE"
    kind "entity"
    name "ANOTHER START IN LIFE"
    community 6
  ]
  node [
    id 1655
    label "E:CONSCIENCE"
    kind "entity"
    name "CONSCIENCE"
    community 6
  ]
  node [
    id 1656
    label "E:ENORMITY OF DIFFICULTIES"
    kind "entity"
    name "ENORMITY OF DIFFICULTIES"
    community 6
  ]
  node [
    id 1657
    label "E:DEAN'S FIRST OFFENCE WAS THE INSTRUCTION ABOUT ALIGHTING FROM A VEHICLE IN MOTION"
    kind "entity"
    name "DEAN'S FIRST OFFENCE WAS THE INSTRUCTION ABOUT ALIGHTING FROM A VEHICLE IN MOTION"
    community 6
  ]
  node [
    id 1658
    label "E:DEAN ANOTHER START IN LIFE"
    kind "entity"
    name "DEAN ANOTHER START IN LIFE"
    community 6
  ]
  node [
    id 1659
    label "E:INSTRUCTION ABOUT ALIGHTING FROM A VEHICLE IN MOTION"
    kind "entity"
    name "INSTRUCTION ABOUT ALIGHTING FROM A VEHICLE IN MOTION"
    community 6
  ]
  node [
    id 1660
    label "E:DIFFICULTIES IN ALIGHTING FROM A VEHICLE IN RAPID MOTION"
    kind "entity"
    name "DIFFICULTIES IN ALIGHTING FROM A VEHICLE IN RAPID MOTION"
    community 6
  ]
  node [
    id 1661
    label "C:Novel-40700_00089"
    kind "chunk"
    chunk_id "Novel-40700_00089"
  ]
  node [
    id 1662
    label "U:Novel-40700_00089#0"
    kind "unit"
    chunk_id "Novel-40700_00089"
    text "Hannah opens the oven, removes a small joint from a baking tin, and places it on the table. She says that 'unger' makes one feel conscientious. The Dean waves her away and says he has done with her. Hannah insists that he is not done with her, but with the joint, and that he will feel wickeder without nourishment. She tells him to taste her darling Noah's favorite dish. The Dean, seeing the dish, calls her Hannah Topping and expresses despair over the carving knife, declaring he will have no more women cooks at the Deanery and that this teaches him a lesson. He sits down and begins carving the joint with desperation. Hannah urges him not to stint himself, saying he cannot blow a whistle on an empty frame. She asks if her cooking carries him back, and he responds that if every mouthful could carry him back one hour, he would finish the joint. Noah, unseen by Hannah and the Dean, climbs in through the window, his eyes blazing with rage, and glares around the room. Under his breath, Noah says, 'My man o' mystery&#8212;a waited on by my nooly made wife&#8212;a heating o' my favorite meal.'"
    community 4
  ]
  node [
    id 1663
    label "E:BAKING TIN"
    kind "entity"
    name "BAKING TIN"
    community 10
  ]
  node [
    id 1664
    label "E:SMALL JOINT"
    kind "entity"
    name "SMALL JOINT"
    community 4
  ]
  node [
    id 1665
    label "E:UNGER"
    kind "entity"
    name "UNGER"
    community 4
  ]
  node [
    id 1666
    label "E:WICKEDER"
    kind "entity"
    name "WICKEDER"
    community 4
  ]
  node [
    id 1667
    label "E:NOURISHMENT"
    kind "entity"
    name "NOURISHMENT"
    community 4
  ]
  node [
    id 1668
    label "E:CARVING-KNIFE"
    kind "entity"
    name "CARVING-KNIFE"
    community 4
  ]
  node [
    id 1669
    label "E:MOUTHFUL"
    kind "entity"
    name "MOUTHFUL"
    community 4
  ]
  node [
    id 1670
    label "E:RAGE"
    kind "entity"
    name "RAGE"
    community 4
  ]
  node [
    id 1671
    label "E:MAN OF MY MYSTERY"
    kind "entity"
    name "MAN OF MY MYSTERY"
    community 4
  ]
  node [
    id 1672
    label "E:WAITED ON BY MY NOOLY MADE WIFE"
    kind "entity"
    name "WAITED ON BY MY NOOLY MADE WIFE"
    community 4
  ]
  node [
    id 1673
    label "E:HEATING OF MY FAVORITE MEAL"
    kind "entity"
    name "HEATING OF MY FAVORITE MEAL"
    community 4
  ]
  node [
    id 1674
    label "E:UNGER MAKES ONE FEEL CONSCIENTIOUS"
    kind "entity"
    name "UNGER MAKES ONE FEEL CONSCIENTIOUS"
    community 4
  ]
  node [
    id 1675
    label "E:NOAH TOPPING'S FAVORITE DISH"
    kind "entity"
    name "NOAH TOPPING'S FAVORITE DISH"
    community 4
  ]
  node [
    id 1676
    label "E:LESSON"
    kind "entity"
    name "LESSON"
    community 4
  ]
  node [
    id 1677
    label "E:EMPTY FRAME"
    kind "entity"
    name "EMPTY FRAME"
    community 4
  ]
  node [
    id 1678
    label "E:HE WOULD FINISH THE JOINT"
    kind "entity"
    name "HE WOULD FINISH THE JOINT"
    community 4
  ]
  node [
    id 1679
    label "E:MY MAN OF MY MYSTERY A WAITED ON BY MY NOOLY MADE WIFE A HEATING OF MY FAVORITE MEAL"
    kind "entity"
    name "MY MAN OF MY MYSTERY A WAITED ON BY MY NOOLY MADE WIFE A HEATING OF MY FAVORITE MEAL"
    community 4
  ]
  node [
    id 1680
    label "C:Novel-40700_00090"
    kind "chunk"
    chunk_id "Novel-40700_00090"
  ]
  node [
    id 1681
    label "U:Novel-40700_00090#0"
    kind "unit"
    chunk_id "Novel-40700_00090"
    text "Hannah turns and faces the Dean, speechless with fright, after being touched on the arm. The Dean, who is still eating, says that if his mind were calmer, this meal would be sufficient. Hannah tries to speak, then clutches her hands and sinks to her knees in front of Noah. Hannah asks Noah to bring her a little plain cold water in a simple tumbler. Noah responds grimly, folding his arms, and says 'Annah, hintrodooce me.' Hannah cries and clings to Noah's legs. The Dean calmly asks Noah if he understands that he is being offered kindnesses by his wife. Noah replies that he wants to know the name of his wife's friend, stating that a friend of her is a friend of his. Hannah exclaims 'Noahry!' Noah says she has been giving him a lot of nice new friends since they moved to St. Marvells. Hannah says she met the gentleman through the wicket in a casual way. Noah agrees, saying cooks and railins&#8212;cooks and railins&#8212;and that he might have guessed his married life would come to this. Hannah says the gentleman spoke to her just as a strange gentleman ought to speak to a lady, asking if Noah agrees. The Dean tells Hannah not to prevaricate under these circumstances, stating that such is not quite the case."
    community 26
  ]
  node [
    id 1682
    label "E:SIMPLE TUMBLER"
    kind "entity"
    name "SIMPLE TUMBLER"
    community 26
  ]
  node [
    id 1683
    label "E:COOKS"
    kind "entity"
    name "COOKS"
    community 26
  ]
  node [
    id 1684
    label "E:RAILINS"
    kind "entity"
    name "RAILINS"
    community 26
  ]
  node [
    id 1685
    label "E:WEDDED LIFE"
    kind "entity"
    name "WEDDED LIFE"
    community 26
  ]
  node [
    id 1686
    label "E:FRIEND"
    kind "entity"
    name "FRIEND"
    community 26
  ]
  node [
    id 1687
    label "E:GENTLEMAN"
    kind "entity"
    name "GENTLEMAN"
    community 26
  ]
  node [
    id 1688
    label "E:PREVARICATE"
    kind "entity"
    name "PREVARICATE"
    community 26
  ]
  node [
    id 1689
    label "E:NOAH'S LEGS"
    kind "entity"
    name "NOAH'S LEGS"
    community 26
  ]
  node [
    id 1690
    label "E:WIFE'S FRIEND"
    kind "entity"
    name "WIFE'S FRIEND"
    community 26
  ]
  node [
    id 1691
    label "E:COOKS AND RAILINS"
    kind "entity"
    name "COOKS AND RAILINS"
    community 26
  ]
  node [
    id 1692
    label "C:Novel-40700_00091"
    kind "chunk"
    chunk_id "Novel-40700_00091"
  ]
  node [
    id 1693
    label "U:Novel-40700_00091#0"
    kind "unit"
    chunk_id "Novel-40700_00091"
    text "Hannah, do not let us prevaricate; the situation is not as described. Noah advances savagely toward the Dean, but restrains himself and faces him. Noah states that it is neither the right time nor place, with people at the door and dinner on the table, to spill a strange man's blood. The Dean expresses trust that Noah's self-respect as an officer of the law will prevent such an unseemly act. Noah agrees, saying that the Dean has touched on his point of pride, emphasizing that his police station in Durnstone is more strict and rigid than any other, and that he and the Dean will go to Durnstone, where when the charges against the Dean are entered, it will be Noah Topping who will take further action. There is another knock at the door. Hannah calls Noah, and Noah responds with the charge of alienating the affections of his wife, Annah. He adds that worse still, the Dean has embezzled his mid-day meal prepared by her hands. He directs the Dean to go into the cell, stating that he has five minutes more in the home he has ruined and laid waste."
    community 23
  ]
  node [
    id 1694
    label "E:POLICE-STATION"
    kind "entity"
    name "POLICE-STATION"
    community 23
  ]
  node [
    id 1695
    label "E:ANNAH"
    kind "entity"
    name "ANNAH"
    community 23
  ]
  node [
    id 1696
    label "E:MID-DAY MEAL"
    kind "entity"
    name "MID-DAY MEAL"
    community 23
  ]
  node [
    id 1697
    label "E:CHARGES"
    kind "entity"
    name "CHARGES"
    community 23
  ]
  node [
    id 1698
    label "E:SELF-RESPECT"
    kind "entity"
    name "SELF-RESPECT"
    community 23
  ]
  node [
    id 1699
    label "E:OFFICER OF THE LAW"
    kind "entity"
    name "OFFICER OF THE LAW"
    community 23
  ]
  node [
    id 1700
    label "E:ALIENATING AFFECTIONS"
    kind "entity"
    name "ALIENATING AFFECTIONS"
    community 23
  ]
  node [
    id 1701
    label "E:EMBEZZLING"
    kind "entity"
    name "EMBEZZLING"
    community 23
  ]
  node [
    id 1702
    label "E:FIVE MINUTES"
    kind "entity"
    name "FIVE MINUTES"
    community 23
  ]
  node [
    id 1703
    label "E:HOME RUINED AND LAYED WASTE"
    kind "entity"
    name "HOME RUINED AND LAYED WASTE"
    community 23
  ]
  node [
    id 1704
    label "E:SPILLING A STRANGE MAN'S BLOOD"
    kind "entity"
    name "SPILLING A STRANGE MAN'S BLOOD"
    community 23
  ]
  node [
    id 1705
    label "E:NOAH'S SELF-RESPECT AS AN OFFICER OF THE LAW"
    kind "entity"
    name "NOAH'S SELF-RESPECT AS AN OFFICER OF THE LAW"
    community 23
  ]
  node [
    id 1706
    label "E:HIS POINT OF PRIDE"
    kind "entity"
    name "HIS POINT OF PRIDE"
    community 23
  ]
  node [
    id 1707
    label "E:CHARGES AGAINST THE DEAN"
    kind "entity"
    name "CHARGES AGAINST THE DEAN"
    community 23
  ]
  node [
    id 1708
    label "E:ALIENATING THE AFFECTIONS OF ANNAH"
    kind "entity"
    name "ALIENATING THE AFFECTIONS OF ANNAH"
    community 23
  ]
  node [
    id 1709
    label "E:EMBEZZLING THE MID-DAY MEAL PREPARED BY ANNAH"
    kind "entity"
    name "EMBEZZLING THE MID-DAY MEAL PREPARED BY ANNAH"
    community 23
  ]
  node [
    id 1710
    label "C:Novel-40700_00092"
    kind "chunk"
    chunk_id "Novel-40700_00092"
  ]
  node [
    id 1711
    label "U:Novel-40700_00092#0"
    kind "unit"
    chunk_id "Novel-40700_00092"
    text "The Dean goes to the door and turns to Noah, asking if he will at least receive his earnest assurance that the woman is extremely innocent. Noah responds by pointing to a joint on the table, and the Dean, overcome, disappears through the cell door, which Noah closes and locks. A knock at the door is repeated, and Hannah is instructed to unlock the door. Hannah weeps and says, 'Oh, Noahry, you'll never be popular in St. Marvells.' Noah insists, 'Hunlock that door!' Hannah unlocks the door and admits Georgiana and Sir Tristram, both dressed for the race-course. Georgiana exclaims, 'Dear me! Is this the Police-Station?' Hannah confirms, 'Yes, lady. Take a chair, lady, near the fire.' She then tells Sir Tristram to sit down. Georgiana says this is her first visit to a police-station and hopes it will be the last. Hannah replies, 'Oh, don't say that, ma'am. We're only auxiliary 'ere, ma'am--the Bench sets at Durnstone.' Georgiana comments that they try to make everybody feel at home, and Hannah curtseys. Sir Tristram remarks, 'It's beautifully Arcadian.' Georgiana suggests perhaps this is only a police-station for the young, to which Hannah does not respond fully."
    community 23
  ]
  node [
    id 1712
    label "E:HINNOCENT"
    kind "entity"
    name "HINNOCENT"
    community 23
  ]
  node [
    id 1713
    label "E:JOINT ON THE TABLE"
    kind "entity"
    name "JOINT ON THE TABLE"
    community 23
  ]
  node [
    id 1714
    label "E:RACE-COURSE"
    kind "entity"
    name "RACE-COURSE"
    community 3
  ]
  node [
    id 1715
    label "E:ARCADIAN"
    kind "entity"
    name "ARCADIAN"
    community 23
  ]
  node [
    id 1716
    label "E:POLICE-STATION FOR THE YOUNG"
    kind "entity"
    name "POLICE-STATION FOR THE YOUNG"
    community 23
  ]
  node [
    id 1717
    label "E:WOMAN"
    kind "entity"
    name "WOMAN"
    community 23
  ]
  node [
    id 1718
    label "E:NOAHRY"
    kind "entity"
    name "NOAHRY"
    community 23
  ]
  node [
    id 1719
    label "E:NOAH WILL NEVER BE POPULAR IN ST. MARVELLS"
    kind "entity"
    name "NOAH WILL NEVER BE POPULAR IN ST. MARVELLS"
    community 23
  ]
  node [
    id 1720
    label "E:UNLOCKING THE DOOR"
    kind "entity"
    name "UNLOCKING THE DOOR"
    community 23
  ]
  node [
    id 1721
    label "E:IS THIS THE POLICE-STATION"
    kind "entity"
    name "IS THIS THE POLICE-STATION"
    community 23
  ]
  node [
    id 1722
    label "E:IT IS A POLICE-STATION"
    kind "entity"
    name "IT IS A POLICE-STATION"
    community 23
  ]
  node [
    id 1723
    label "E:GEORGIANA TO TAKE A CHAIR"
    kind "entity"
    name "GEORGIANA TO TAKE A CHAIR"
    community 23
  ]
  node [
    id 1724
    label "E:SIR TRISTRAM TO SIT DOWN"
    kind "entity"
    name "SIR TRISTRAM TO SIT DOWN"
    community 23
  ]
  node [
    id 1725
    label "E:WE ARE ONLY AUXILIARY HERE"
    kind "entity"
    name "WE ARE ONLY AUXILIARY HERE"
    community 23
  ]
  node [
    id 1726
    label "E:IT'S BEAUTIFULLY ARCADIAN"
    kind "entity"
    name "IT'S BEAUTIFULLY ARCADIAN"
    community 23
  ]
  node [
    id 1727
    label "E:THIS MAY BE ONLY A POLICE-STATION FOR THE YOUNG"
    kind "entity"
    name "THIS MAY BE ONLY A POLICE-STATION FOR THE YOUNG"
    community 23
  ]
  node [
    id 1728
    label "C:Novel-40700_00093"
    kind "chunk"
    chunk_id "Novel-40700_00093"
  ]
  node [
    id 1729
    label "U:Novel-40700_00093#0"
    kind "unit"
    chunk_id "Novel-40700_00093"
    text "GEORGIANA asks Hannah if the police station is only for young people; Hannah replies that they serve ladies and gentlemen like themselves. Noah, who has not been noticed, gloomily surveys GEORGIANA and SIR TRISTRAM and asks Hannah to introduce him. GEORGIANA responds with surprise and greets him with 'good-morning'. Noah says that Annah is getting him many nice new friends this week since they moved to St. Marvells. Hannah warns Noah that the lady and gentlemen are strange. GEORGIANA asks Noah if he is the man in charge. Noah confirms he is and asks whether GEORGIANA is there on business or pleasure. SIR TRISTRAM questions if people come here to see him. Noah replies that people generally come to see his wife, and that the official side of the room is for business while the current side is domestic, suggesting that GEORGIANA and SIR TRISTRAM should move over. GEORGIANA and SIR TRISTRAM comply and change seats. SIR TRISTRAM introduces GEORGIANA as Mrs. Tidman, who is the sister of Dr. Jedd, the Dean of St. Marvells. Hannah gasps. GEORGIANA remarks that there's something wrong with Noah's wife. Noah confirms that his wife is profligate and that proceedings are pending."
    community 10
  ]
  node [
    id 1730
    label "E:DEAN OF ST. MARVELLS"
    kind "entity"
    name "DEAN OF ST. MARVELLS"
    community 10
  ]
  node [
    id 1731
    label "E:BUSINESS"
    kind "entity"
    name "BUSINESS"
    community 10
  ]
  node [
    id 1732
    label "E:PLEASURE"
    kind "entity"
    name "PLEASURE"
    community 10
  ]
  node [
    id 1733
    label "E:OFFICIAL SIDE"
    kind "entity"
    name "OFFICIAL SIDE"
    community 10
  ]
  node [
    id 1734
    label "E:DOMESTIC SIDE"
    kind "entity"
    name "DOMESTIC SIDE"
    community 10
  ]
  node [
    id 1735
    label "E:LADIES AND GENTLEMEN"
    kind "entity"
    name "LADIES AND GENTLEMEN"
    community 10
  ]
  node [
    id 1736
    label "E:HIS WIFE"
    kind "entity"
    name "HIS WIFE"
    community 10
  ]
  node [
    id 1737
    label "E:BUSINESS AND DOMESTIC SIDES"
    kind "entity"
    name "BUSINESS AND DOMESTIC SIDES"
    community 10
  ]
  node [
    id 1738
    label "E:PROFLIGATE"
    kind "entity"
    name "PROFLIGATE"
    community 10
  ]
  node [
    id 1739
    label "C:Novel-40700_00094"
    kind "chunk"
    chunk_id "Novel-40700_00094"
  ]
  node [
    id 1740
    label "U:Novel-40700_00094#0"
    kind "unit"
    chunk_id "Novel-40700_00094"
    text "Noah states that Georgiana's sister is profligate and that the proceedings are pending. Georgiana expresses fear at the police station, saying her flesh creeps. Sir Tristram tells Noah that his poor friend and Georgiana's brother, Dr. Jedd the Dean, has mysteriously and unaccountably disappeared. Georgiana confirms that Dr. Jedd has vanished. Noah says Dr. Jedd has absconded. Georgiana is angry that Noah uses the word 'absconded'. Noah asks if the man was respectable. Georgiana does not understand. Sir Tristram reveals that the lady is Dr. Jedd's sister. Noah says it is no good being irritable with the law and will come over officially, carrying a baking tin. Sir Tristram complains about the cooking odor. Georgiana orders Noah to take the tin away and asks what it is. Noah says the tin contains evidence against his profligate wife. Sir Tristram and Georgiana exchange looks of impatience. Georgiana expresses concern that her brother the Dean is missing. Noah confirms that he is touching the missing Dean. Georgiana says she left Dr. Jedd the previous night to retire to rest. Sir Tristram states that Dr. Jedd was not found this morning. Noah confirms that he is touching the missing Dean."
    community 10
  ]
  node [
    id 1741
    label "E:ODOR"
    kind "entity"
    name "ODOR"
    community 10
  ]
  node [
    id 1742
    label "E:MISSING DEAN"
    kind "entity"
    name "MISSING DEAN"
    community 10
  ]
  node [
    id 1743
    label "E:REST"
    kind "entity"
    name "REST"
    community 10
  ]
  node [
    id 1744
    label "E:DR. JEDD HAS DISAPPEARED"
    kind "entity"
    name "DR. JEDD HAS DISAPPEARED"
    community 10
  ]
  node [
    id 1745
    label "E:SISTER OF DR. JEDD"
    kind "entity"
    name "SISTER OF DR. JEDD"
    community 10
  ]
  node [
    id 1746
    label "E:EVIDENCE AGAINST HIS PROFLIGATE WIFE"
    kind "entity"
    name "EVIDENCE AGAINST HIS PROFLIGATE WIFE"
    community 10
  ]
  node [
    id 1747
    label "E:IMPATIENCE"
    kind "entity"
    name "IMPATIENCE"
    community 10
  ]
  node [
    id 1748
    label "C:Novel-40700_00095"
    kind "chunk"
    chunk_id "Novel-40700_00095"
  ]
  node [
    id 1749
    label "U:Novel-40700_00095#0"
    kind "unit"
    chunk_id "Novel-40700_00095"
    text "The speaker left him last night to retire to rest. This morning he is not to be found. They checked his bed, and everyone did so. Noah says it is only confusing that so many people are doing it, and that money matters are involved. Georgiana puts her handkerchief to her eyes. Sir Tristram tells Noah to get out of the way and asks if he has anything on his mind. Georgiana confirms that he did have something on his mind. Noah claims he has a theory that will remove all suspense and says he has been traveling, reading a lot, and is a shrewd experienced man, concluding that this is merely an ordinary case of suicide. Georgiana sits faintly. Sir Tristram angrily tells Noah to get out of the way and asks Georgiana if this were true, how they could break it to the girls. Noah suggests he could run up during the evening and break it to the girls."
    community 22
  ]
  node [
    id 1750
    label "E:THIS MORNING"
    kind "entity"
    name "THIS MORNING"
    community 22
  ]
  node [
    id 1751
    label "E:EVERYBODY"
    kind "entity"
    name "EVERYBODY"
    community 22
  ]
  node [
    id 1752
    label "E:MONEY MATTERS"
    kind "entity"
    name "MONEY MATTERS"
    community 22
  ]
  node [
    id 1753
    label "E:SUSPENSE"
    kind "entity"
    name "SUSPENSE"
    community 22
  ]
  node [
    id 1754
    label "E:THEORY"
    kind "entity"
    name "THEORY"
    community 22
  ]
  node [
    id 1755
    label "E:TRAVELING"
    kind "entity"
    name "TRAVELING"
    community 22
  ]
  node [
    id 1756
    label "E:READING"
    kind "entity"
    name "READING"
    community 22
  ]
  node [
    id 1757
    label "E:SHREWDED EXPERIENCED MAN"
    kind "entity"
    name "SHREWDED EXPERIENCED MAN"
    community 22
  ]
  node [
    id 1758
    label "E:SOOICE"
    kind "entity"
    name "SOOICE"
    community 22
  ]
  node [
    id 1759
    label "E:RUN UP"
    kind "entity"
    name "RUN UP"
    community 22
  ]
  node [
    id 1760
    label "E:NONE"
    kind "entity"
    name "NONE"
    community 22
  ]
  node [
    id 1761
    label "E:IF THIS WERE TRUE"
    kind "entity"
    name "IF THIS WERE TRUE"
    community 22
  ]
  node [
    id 1762
    label "E:DEAL"
    kind "entity"
    name "DEAL"
    community 22
  ]
  node [
    id 1763
    label "E:TO THE GIRLS"
    kind "entity"
    name "TO THE GIRLS"
    community 22
  ]
  node [
    id 1764
    label "C:Novel-40700_00096"
    kind "chunk"
    chunk_id "Novel-40700_00096"
  ]
  node [
    id 1765
    label "U:Novel-40700_00096#0"
    kind "unit"
    chunk_id "Novel-40700_00096"
    text "Noah is instructed by Sir Tristram to hold his tongue and take down a description of the Dean of St. Marvells, reporting his disappearance at Durnstone. Sir Tristram dictates that the missing person is The Very Reverend Augustin Jedd, Dean of St. Marvells, and specifies that the description should include physical features. Noah initially resists and says he will spell it his own way, then agrees to write it, describing the Dean as a 'ordinary sort of looking man' with no specific features. Georgiana interrupts and provides a detailed description: a little, short, thin man with black hair and a squint. Sir Tristram disputes this description, calling it incorrect, and insists on the official version."
    community 10
  ]
  node [
    id 1766
    label "E:VERY REV. AUGUSTIN JEDD"
    kind "entity"
    name "VERY REV. AUGUSTIN JEDD"
    community 10
  ]
  node [
    id 1767
    label "E:DESCRIPTION"
    kind "entity"
    name "DESCRIPTION"
    community 23
  ]
  node [
    id 1768
    label "E:BLACK HAIR"
    kind "entity"
    name "BLACK HAIR"
    community 10
  ]
  node [
    id 1769
    label "E:SQUINT"
    kind "entity"
    name "SQUINT"
    community 10
  ]
  node [
    id 1770
    label "E:SHORT"
    kind "entity"
    name "SHORT"
    community 10
  ]
  node [
    id 1771
    label "E:THIN"
    kind "entity"
    name "THIN"
    community 10
  ]
  node [
    id 1772
    label "E:ORDINARY LOOKING MAN"
    kind "entity"
    name "ORDINARY LOOKING MAN"
    community 10
  ]
  node [
    id 1773
    label "U:Novel-40700_00096#1"
    kind "unit"
    chunk_id "Novel-40700_00096"
    text "Hannah quietly speaks to Georgiana, urging her to listen, while Noah prepares to write by placing a baking-tin on the table. Georgiana turns and responds to Hannah's plea, showing excitement. Sir Tristram asks Noah if he has recorded the description, and Noah confirms he has written it in his own way."
    community 23
  ]
  node [
    id 1774
    label "E:BAKING-TIN"
    kind "entity"
    name "BAKING-TIN"
    community 23
  ]
  node [
    id 1775
    label "C:Novel-40700_00097"
    kind "chunk"
    chunk_id "Novel-40700_00097"
  ]
  node [
    id 1776
    label "U:Novel-40700_00097#0"
    kind "unit"
    chunk_id "Novel-40700_00097"
    text "Sir Tristram tells Georgiana that Gus is not there, but Georgiana insists he is and claims she knows him as his sister. She whispers to Sir Tristram that Gus is the villain who dosed Dandy Dick the previous night. Sir Tristram is startled and falls back; Hannah takes him and speaks rapidly to him. Sir Tristram asks Noah what he has written, and Noah replies that he wrote 'Hanswers to the name o' Gus'. Georgiana takes the paper and says she has changed her mind and is too busy to care about Gus this week. Noah responds that he wasted his time, and Georgiana asks if Noah is the constable who took the man from the Deanery Stables the previous night. Noah confirms this and says his cart is outside ready to take the man to Durnstone. Georgiana requests to see him, and Noah says she can see him passing out. Georgiana then speaks to herself, saying 'Oh, Gus, Gus!'"
    community 23
  ]
  node [
    id 1777
    label "E:HANSWERS TO THE NAME O' GUS"
    kind "entity"
    name "HANSWERS TO THE NAME O' GUS"
    community 23
  ]
  node [
    id 1778
    label "E:MAN FROM THE DEANERY STABLES"
    kind "entity"
    name "MAN FROM THE DEANERY STABLES"
    community 23
  ]
  node [
    id 1779
    label "E:MAN TO DURNSTONE"
    kind "entity"
    name "MAN TO DURNSTONE"
    community 23
  ]
  node [
    id 1780
    label "E:MAN PASSING OUT"
    kind "entity"
    name "MAN PASSING OUT"
    community 23
  ]
  node [
    id 1781
    label "E:WHEN GOING TO THE CELL DOOR"
    kind "entity"
    name "WHEN GOING TO THE CELL DOOR"
    community 23
  ]
  node [
    id 1782
    label "U:Novel-40700_00097#1"
    kind "unit"
    chunk_id "Novel-40700_00097"
    text "Georgiana says she has changed her mind and is too busy to bother about Gus this week, and Noah expresses frustration over having wasted his time."
    community 8
  ]
  node [
    id 1783
    label "E:GEORGIANA DID NOT WANT HIS HELP"
    kind "entity"
    name "GEORGIANA DID NOT WANT HIS HELP"
    community 8
  ]
  node [
    id 1784
    label "C:Novel-40700_00098"
    kind "chunk"
    chunk_id "Novel-40700_00098"
  ]
  node [
    id 1785
    label "U:Novel-40700_00098#0"
    kind "unit"
    chunk_id "Novel-40700_00098"
    text "Georgiana says to herself, 'Oh, Gus, Gus! NOAH,' and warns others that Noah is an awful looking creature. She then says she can stand it and loves horrors. Noah enters the cell and closes the door behind him."
    community 2
  ]
  node [
    id 1786
    label "E:HORRORS"
    kind "entity"
    name "HORRORS"
    community 2
  ]
  node [
    id 1787
    label "E:OH GUS GUS NOAH"
    kind "entity"
    name "OH GUS GUS NOAH"
    community 2
  ]
  node [
    id 1788
    label "U:Novel-40700_00098#1"
    kind "unit"
    chunk_id "Novel-40700_00098"
    text "Georgiana asks Sir Tristram what her brother's motive was for bolusing Dandy the previous night. Sir Tristram says he cannot think and that the first thing to do is to get Noah out of the hole. He states that a good woman has arranged for Noah's escape."
    community 2
  ]
  node [
    id 1789
    label "E:BOLUSING DANDY"
    kind "entity"
    name "BOLUSING DANDY"
    community 2
  ]
  node [
    id 1790
    label "E:HOLE"
    kind "entity"
    name "HOLE"
    community 2
  ]
  node [
    id 1791
    label "E:GOOD WOMAN"
    kind "entity"
    name "GOOD WOMAN"
    community 2
  ]
  node [
    id 1792
    label "E:ESCAPE"
    kind "entity"
    name "ESCAPE"
    community 2
  ]
  node [
    id 1793
    label "U:Novel-40700_00098#2"
    kind "unit"
    chunk_id "Novel-40700_00098"
    text "Georgiana expresses disbelief that she cannot trust Gus to roll out of a flying dogcart, saying it is as much as she could do. Hannah says yes, lady, he will do it and that she has prewided for everything. She warns not to betray Noah to Noah, as there is another, awfuller charge hanging over his reverend head."
    community 8
  ]
  node [
    id 1794
    label "E:FLYING DOGCART"
    kind "entity"
    name "FLYING DOGCART"
    community 8
  ]
  node [
    id 1795
    label "E:AWFUL CHARGE"
    kind "entity"
    name "AWFUL CHARGE"
    community 8
  ]
  node [
    id 1796
    label "E:REVEREND HEAD"
    kind "entity"
    name "REVEREND HEAD"
    community 8
  ]
  node [
    id 1797
    label "E:EVERYTHING"
    kind "entity"
    name "EVERYTHING"
    community 8
  ]
  node [
    id 1798
    label "U:Novel-40700_00098#3"
    kind "unit"
    chunk_id "Novel-40700_00098"
    text "Sir Tristram says there is another charge! Georgiana exclaims 'Another!' and says it is surprising that her own stock has become vicious. Hannah says hush, lady."
    community 22
  ]
  node [
    id 1799
    label "E:VIOLENT"
    kind "entity"
    name "VIOLENT"
    community 22
  ]
  node [
    id 1800
    label "E:HUSH"
    kind "entity"
    name "HUSH"
    community 22
  ]
  node [
    id 1801
    label "E:ANOTHER"
    kind "entity"
    name "ANOTHER"
    community 22
  ]
  node [
    id 1802
    label "U:Novel-40700_00098#4"
    kind "unit"
    chunk_id "Novel-40700_00098"
    text "Noah comes out of the cell with The Dean, who is in handcuffs. Georgiana and Sir Tristram see The Dean and he recoils with a groan, sinking onto a chair. Noah says 'Oop you get!' and Sir Tristram says no, no, stay, and that he is the owner of the horse stabled at the Deanery and makes no charge against the wretched person."
    community 2
  ]
  node [
    id 1803
    label "E:HORSE STABLED AT THE DEANERY"
    kind "entity"
    name "HORSE STABLED AT THE DEANERY"
    community 2
  ]
  node [
    id 1804
    label "C:Novel-40700_00099"
    kind "chunk"
    chunk_id "Novel-40700_00099"
  ]
  node [
    id 1805
    label "U:Novel-40700_00099#0"
    kind "unit"
    chunk_id "Novel-40700_00099"
    text "The owner of the horse stabled at the Deanery is the speaker, who states they make no charge against the wretched person. The Dean admits to administering a simple remedy for chills to a suffering beast and calls himself an unfortunate creature, offering to be dealt with as desired."
    community 2
  ]
  node [
    id 1806
    label "E:SIMPLE REMEDY FOR CHILLS"
    kind "entity"
    name "SIMPLE REMEDY FOR CHILLS"
    community 2
  ]
  node [
    id 1807
    label "E:SUFFERING BEAST"
    kind "entity"
    name "SUFFERING BEAST"
    community 2
  ]
  node [
    id 1808
    label "U:Novel-40700_00099#1"
    kind "unit"
    chunk_id "Novel-40700_00099"
    text "Georgiana questions whether the analysis from the chemist has returned, expressing doubt about the truth of the Dean's statement. The Dean confirms that the analysis has not yet come home."
    community 2
  ]
  node [
    id 1809
    label "E:CHEMIST"
    kind "entity"
    name "CHEMIST"
    community 2
  ]
  node [
    id 1810
    label "E:ANALYSIS"
    kind "entity"
    name "ANALYSIS"
    community 2
  ]
  node [
    id 1811
    label "E:ANALYSIS HAS NOT YET COME HOME FROM"
    kind "entity"
    name "ANALYSIS HAS NOT YET COME HOME FROM"
    community 2
  ]
  node [
    id 1812
    label "U:Novel-40700_00099#2"
    kind "unit"
    chunk_id "Novel-40700_00099"
    text "Sir Tristram orders Noah to release the man who is being held. Noah claims that the man was found trespassing in the stables of the late Dean, who has committed suicide. The Dean reacts with surprise and is interrupted by Sir Tristram, Georgiana, and Hannah."
    community 24
  ]
  node [
    id 1813
    label "E:STABLES OF THE LATE DEAN"
    kind "entity"
    name "STABLES OF THE LATE DEAN"
    community 24
  ]
  node [
    id 1814
    label "E:LATE DEAN"
    kind "entity"
    name "LATE DEAN"
    community 24
  ]
  node [
    id 1815
    label "E:SUICIDE"
    kind "entity"
    name "SUICIDE"
    community 24
  ]
  node [
    id 1816
    label "E:MAN TRESPASSING IN"
    kind "entity"
    name "MAN TRESPASSING IN"
    community 24
  ]
  node [
    id 1817
    label "U:Novel-40700_00099#3"
    kind "unit"
    chunk_id "Novel-40700_00099"
    text "Noah states that he is the only man who can withdraw one charge and that he is the only man who can withdraw the other charge. He then charges the unknown person with alienating the affections of his wife while he was putting his horse to work, and plans to drive him to Durnstone with the evidence."
    community 9
  ]
  node [
    id 1818
    label "E:UNKNOWN PERSON"
    kind "entity"
    name "UNKNOWN PERSON"
    community 9
  ]
  node [
    id 1819
    label "E:WIFE OF NOAH"
    kind "entity"
    name "WIFE OF NOAH"
    community 9
  ]
  node [
    id 1820
    label "E:EVIDENCE"
    kind "entity"
    name "EVIDENCE"
    community 9
  ]
  node [
    id 1821
    label "E:ALIENATING THE AFFECTIONS"
    kind "entity"
    name "ALIENATING THE AFFECTIONS"
    community 9
  ]
  node [
    id 1822
    label "E:ONE CHARGE"
    kind "entity"
    name "ONE CHARGE"
    community 9
  ]
  node [
    id 1823
    label "E:OTHER CHARGE"
    kind "entity"
    name "OTHER CHARGE"
    community 9
  ]
  node [
    id 1824
    label "E:ALIENATING THE AFFECTIONS OF WIFE OF NOAH"
    kind "entity"
    name "ALIENATING THE AFFECTIONS OF WIFE OF NOAH"
    community 9
  ]
  node [
    id 1825
    label "E:HORSE TO WORK"
    kind "entity"
    name "HORSE TO WORK"
    community 9
  ]
  node [
    id 1826
    label "E:UNKNOWN PERSON TO DURNSTONE WITH EVIDENCE"
    kind "entity"
    name "UNKNOWN PERSON TO DURNSTONE WITH EVIDENCE"
    community 9
  ]
  node [
    id 1827
    label "U:Novel-40700_00099#4"
    kind "unit"
    chunk_id "Novel-40700_00099"
    text "Hannah says that appearances are against them. Noah, through the door, shouts 'Woa! Steady there! Get back!' and Georgiana responds with a quiet 'Oh lady, lady'"
    community 23
  ]
  node [
    id 1828
    label "E:WHALE"
    kind "entity"
    name "WHALE"
    community 23
  ]
  node [
    id 1829
    label "E:OH LADY LADY"
    kind "entity"
    name "OH LADY LADY"
    community 23
  ]
  node [
    id 1830
    label "E:APPEARANCES ARE AGAINST THEM"
    kind "entity"
    name "APPEARANCES ARE AGAINST THEM"
    community 23
  ]
  node [
    id 1831
    label "E:WOA! STEADY THERE! GET BACK!"
    kind "entity"
    name "WOA! STEADY THERE! GET BACK!"
    community 23
  ]
  node [
    id 1832
    label "C:Novel-40700_00100"
    kind "chunk"
    chunk_id "Novel-40700_00100"
  ]
  node [
    id 1833
    label "U:Novel-40700_00100#0"
    kind "unit"
    chunk_id "Novel-40700_00100"
    text "Noah appears at the door and shouts 'Time's oop. Coom on!' The Dean confirms he has the woman's whistle and the key to his handcuffs. He asks if he may speak a few parting words in the home he has apparently wrecked, and Noah responds 'Say' em and 'a done.' The Dean then declares that he wishes to attest that the erring constable is the husband of a wife from whom it is impossible to withhold respect, if not admiration. Noah says he hears it. The Dean adds that he will reserve the confession of his weaknesses for another time and place, and gives a specific admonition to Georgetana: within an hour, the fire must be lighted in the drawing-room, the missing man's warm bath must be ready, and a change of linen must be prepared, and she must withhold her judgments."
    community 26
  ]
  node [
    id 1834
    label "E:WOMAN'S WHISTLE"
    kind "entity"
    name "WOMAN'S WHISTLE"
    community 26
  ]
  node [
    id 1835
    label "E:KEY OF HANDCUFFS"
    kind "entity"
    name "KEY OF HANDCUFFS"
    community 26
  ]
  node [
    id 1836
    label "E:JOURNEY"
    kind "entity"
    name "JOURNEY"
    community 26
  ]
  node [
    id 1837
    label "E:ERRING CONSTABLE"
    kind "entity"
    name "ERRING CONSTABLE"
    community 26
  ]
  node [
    id 1838
    label "E:DRAWING-ROOM"
    kind "entity"
    name "DRAWING-ROOM"
    community 26
  ]
  node [
    id 1839
    label "E:WARM BATH"
    kind "entity"
    name "WARM BATH"
    community 26
  ]
  node [
    id 1840
    label "E:CHANGE OF LINEN"
    kind "entity"
    name "CHANGE OF LINEN"
    community 26
  ]
  node [
    id 1841
    label "E:SANCTITY OF THE DEANERY"
    kind "entity"
    name "SANCTITY OF THE DEANERY"
    community 26
  ]
  node [
    id 1842
    label "E:TERMINATION OF WHICH IS PROBLEMATICAL"
    kind "entity"
    name "TERMINATION OF WHICH IS PROBLEMATICAL"
    community 26
  ]
  node [
    id 1843
    label "E:DOORWAY"
    kind "entity"
    name "DOORWAY"
    community 26
  ]
  node [
    id 1844
    label "E:FIRE BE LIGHTED IN THE DRAWING-ROOM"
    kind "entity"
    name "FIRE BE LIGHTED IN THE DRAWING-ROOM"
    community 26
  ]
  node [
    id 1845
    label "E:WARM BATH BE WAITING FOR ITS MASTER"
    kind "entity"
    name "WARM BATH BE WAITING FOR ITS MASTER"
    community 26
  ]
  node [
    id 1846
    label "E:CHANGE OF LINEN BE PREPARED"
    kind "entity"
    name "CHANGE OF LINEN BE PREPARED"
    community 26
  ]
  node [
    id 1847
    label "E:ANOTHER TIME AND PLACE"
    kind "entity"
    name "ANOTHER TIME AND PLACE"
    community 26
  ]
  node [
    id 1848
    label "U:Novel-40700_00100#1"
    kind "unit"
    chunk_id "Novel-40700_00100"
    text "Sir Tristram softly speaks to the Dean, saying 'Oh Jedd, Jedd--and these are what you call Principles!' and asks if he has the key of his handcuffs. The Dean confirms he has it."
    community 26
  ]
  node [
    id 1849
    label "E:PRINCIPLES"
    kind "entity"
    name "PRINCIPLES"
    community 26
  ]
  node [
    id 1850
    label "C:Novel-40700_00101"
    kind "chunk"
    chunk_id "Novel-40700_00101"
  ]
  node [
    id 1851
    label "U:Novel-40700_00101#0"
    kind "unit"
    chunk_id "Novel-40700_00101"
    text "NOAH is told not to judge and is told that this is none of his business. The DEAN says he is ready. NOAH takes the DEAN by the arm and leads him out. GEORGIANA expresses confusion about her brother. HANNAH kneels at GEORGIANA's feet and claims that she, her whistle, and Nick the fire-brigade horse will bring the Dean back safely to the Deanery, and that only the three of them will ever know of his misfortune. HANNAH hears them leaving and exclaims that they are off. NOAH, outside, tells the old girl to get up. HANNAH rushes to the door and sees that the Dean is gone, and says he is done for. GEORGIANA and SIR TRISTRAM agree that he is done for. HANNAH says the Dean can whistle himself blue, and explains that Noah put Kitty in the cart and left Old Nick at home."
    community 21
  ]
  node [
    id 1852
    label "E:NICK THE FIRE-BRIGADE HORSE"
    kind "entity"
    name "NICK THE FIRE-BRIGADE HORSE"
    community 21
  ]
  node [
    id 1853
    label "E:KITTY"
    kind "entity"
    name "KITTY"
    community 21
  ]
  node [
    id 1854
    label "E:DURNSHIRE"
    kind "entity"
    name "DURNSHIRE"
    community 21
  ]
  node [
    id 1855
    label "E:OLD GIRL"
    kind "entity"
    name "OLD GIRL"
    community 21
  ]
  node [
    id 1856
    label "U:Novel-40700_00101#1"
    kind "unit"
    chunk_id "Novel-40700_00101"
    text "SALOME and SHEBA are sitting in the Morning Room at the Deanery in a gloomy mood. SALOME says poor Papa must return soon. SHEBA agrees and says it is comforting to feel they have no cause for self-reproach. SALOME says the anxiety is terribly wearing, and SHEBA agrees."
    community 21
  ]
  node [
    id 1857
    label "C:Novel-40700_00102"
    kind "chunk"
    chunk_id "Novel-40700_00102"
  ]
  node [
    id 1858
    label "U:Novel-40700_00102#0"
    kind "unit"
    chunk_id "Novel-40700_00102"
    text "Salome and Sheba express anxiety over suspense; Sheba says if she dies from it, she wants Salome to have her workbox. Salome replies that if Papa is not home for afternoon tea, Sheba will outlive her. Then Major Tarver and Mr. Darbey appear outside, and Darbey thanks them for coming. Salome opens the window, and Tarver and Darbey enter, with Darbey supporting Tarver who looks extremely weak. Tarver apologizes for the informal way of entering. Salome says it is proper for gentlemen to intrude on two feeble women in sorrow. Sheba warns that if they take one more step, Tarver will ring for help, and Tarver sinks into a chair. Darbey stands by Tarver and says, 'The fact is.'"
    community 1
  ]
  node [
    id 1859
    label "E:WORKBOX"
    kind "entity"
    name "WORKBOX"
    community 1
  ]
  node [
    id 1860
    label "E:AFTERNOON TEA"
    kind "entity"
    name "AFTERNOON TEA"
    community 1
  ]
  node [
    id 1861
    label "E:FEWLESS"
    kind "entity"
    name "FEWLESS"
    community 1
  ]
  node [
    id 1862
    label "E:FEEBLE"
    kind "entity"
    name "FEEBLE"
    community 1
  ]
  node [
    id 1863
    label "E:TWO FEEBLE WOMEN"
    kind "entity"
    name "TWO FEEBLE WOMEN"
    community 1
  ]
  node [
    id 1864
    label "U:Novel-40700_00102#1"
    kind "unit"
    chunk_id "Novel-40700_00102"
    text "Major Tarver and Mr. Darbey enter the room, dressed for the Races, with Darbey supporting Tarver who appears weak. Tarver apologizes for the informal way of entering. Salome remarks that it is proper for gentlemen to intrude on two feeble women in sorrow. Sheba warns that if they take one more step, Tarver will ring for help, and Tarver sinks into a chair. Darbey stands by Tarver and says, 'The fact is.'"
    community 1
  ]
  node [
    id 1865
    label "C:Novel-40700_00103"
    kind "chunk"
    chunk_id "Novel-40700_00103"
  ]
  node [
    id 1866
    label "U:Novel-40700_00103#0"
    kind "unit"
    chunk_id "Novel-40700_00103"
    text "Darbey, standing by Tarver, states that Tarver is in an exceedingly critical condition and that he has failed to gain the race-course due to feeling he has incurred Miss Jedd's displeasure. He explains that he took Tarver to Dr. Middleton and described that Major Tarver loved with a passion second only to his own, specifically looking at Sheba."
    community 3
  ]
  node [
    id 1867
    label "E:DR. MIDDLETON"
    kind "entity"
    name "DR. MIDDLETON"
    community 1
  ]
  node [
    id 1868
    label "E:SECOND ONLY TO HIS OWN"
    kind "entity"
    name "SECOND ONLY TO HIS OWN"
    community 3
  ]
  node [
    id 1869
    label "U:Novel-40700_00103#1"
    kind "unit"
    chunk_id "Novel-40700_00103"
    text "Dr. Middleton conducted a searching examination of Major Tarver's tongue and diagnosed that unless Major Tarver proposed to the lady in question and was accepted, three weeks or a month at the seaside would be absolutely imperative."
    community 1
  ]
  node [
    id 1870
    label "E:LADY IN QUESTION"
    kind "entity"
    name "LADY IN QUESTION"
    community 1
  ]
  node [
    id 1871
    label "E:SEASIDE"
    kind "entity"
    name "SEASIDE"
    community 1
  ]
  node [
    id 1872
    label "E:THREE WEEKS OR A MONTH"
    kind "entity"
    name "THREE WEEKS OR A MONTH"
    community 1
  ]
  node [
    id 1873
    label "U:Novel-40700_00103#2"
    kind "unit"
    chunk_id "Novel-40700_00103"
    text "Tarver rises and approaches Salome, stating that he has loved her distractedly for upwards of eight weeks."
    community 3
  ]
  node [
    id 1874
    label "C:Novel-40700_00104"
    kind "chunk"
    chunk_id "Novel-40700_00104"
  ]
  node [
    id 1875
    label "U:Novel-40700_00104#0"
    kind "unit"
    chunk_id "Novel-40700_00104"
    text "Salome goes to Major Tarver and asks him to let her pass, holding his coat firmly. Tarver refuses unless she pushes him. Sheba asks Mr. Darbey to spare them the scene, and Darbey follows Sheba across the room. Tarver says that for a man in his condition, love is either a rapid and fatal malady or an admirable digestive, and offers that if accepted, his merry laugh will continue in the Mess Room, but if rejected, his collection of vocal music will be sold and his voice will cease. Salome questions whether it is really she who would silence the small songster. Tarver produces a doctor's certificate proving this, and both read it as they walk into the Library."
    community 1
  ]
  node [
    id 1876
    label "E:DOCTOR"
    kind "entity"
    name "DOCTOR"
    community 1
  ]
  node [
    id 1877
    label "E:MESS ROOM"
    kind "entity"
    name "MESS ROOM"
    community 1
  ]
  node [
    id 1878
    label "E:COLLECTION OF VOCAL MUSIC"
    kind "entity"
    name "COLLECTION OF VOCAL MUSIC"
    community 1
  ]
  node [
    id 1879
    label "E:CERTIFICATE"
    kind "entity"
    name "CERTIFICATE"
    community 1
  ]
  node [
    id 1880
    label "U:Novel-40700_00104#1"
    kind "unit"
    chunk_id "Novel-40700_00104"
    text "Sheba says she has never thought of marriage seriously. Darbey says people never do until they are married. Sheba mentions her age, saying it is very small and not worth mentioning. Darbey asks what her age is. Sheba replies that it is not worth mentioning. Sheba suggests they remain friends and occasionally correspond. Darbey agrees if she insists. Sheba says no, she realizes it is impracticable."
    community 5
  ]
  node [
    id 1881
    label "E:AGE"
    kind "entity"
    name "AGE"
    community 5
  ]
  node [
    id 1882
    label "E:CORRESPONDENCE"
    kind "entity"
    name "CORRESPONDENCE"
    community 5
  ]
  node [
    id 1883
    label "C:Novel-40700_00105"
    kind "chunk"
    chunk_id "Novel-40700_00105"
  ]
  node [
    id 1884
    label "U:Novel-40700_00105#0"
    kind "unit"
    chunk_id "Novel-40700_00105"
    text "SHEBA states that marriage or separation is the only option and requests time to reflect on the matter and understand herself better; DARBEY agrees to give her two or three minutes."
    community 2
  ]
  node [
    id 1885
    label "E:MARRIAGE"
    kind "entity"
    name "MARRIAGE"
    community 2
  ]
  node [
    id 1886
    label "E:SEPARATION"
    kind "entity"
    name "SEPARATION"
    community 2
  ]
  node [
    id 1887
    label "U:Novel-40700_00105#1"
    kind "unit"
    chunk_id "Novel-40700_00105"
    text "TARVER expresses excitement and relief at being accepted by someone, says he will buy gay songs, and asks when he can see the Dean; SALOME tells him Papa has been out all night."
    community 15
  ]
  node [
    id 1888
    label "E:GAY SONGS"
    kind "entity"
    name "GAY SONGS"
    community 15
  ]
  node [
    id 1889
    label "E:BEING ACCEPTED"
    kind "entity"
    name "BEING ACCEPTED"
    community 15
  ]
  node [
    id 1890
    label "E:PAPA HAS BEEN OUT ALL NIGHT"
    kind "entity"
    name "PAPA HAS BEEN OUT ALL NIGHT"
    community 15
  ]
  node [
    id 1891
    label "U:Novel-40700_00105#2"
    kind "unit"
    chunk_id "Novel-40700_00105"
    text "DARBEY and TARVER both exclaim that Papa has been out all night; SALOME calls it terrible and asks Mr. Darbey what he thinks of it; DARBEY says it is shocking but they should not condemn him without hearing him out."
    community 15
  ]
  node [
    id 1892
    label "E:TERIBLE"
    kind "entity"
    name "TERIBLE"
    community 15
  ]
  node [
    id 1893
    label "U:Novel-40700_00105#3"
    kind "unit"
    chunk_id "Novel-40700_00105"
    text "SHEBA sees Aunt Georgiana at the window and calls Mr. Darbey to wait for her as she has decided; GEORGIANA enters excitedly, waves her handkerchief, and says the course is clear, reminding to mind the gate-post."
    community 14
  ]
  node [
    id 1894
    label "E:COURSE"
    kind "entity"
    name "COURSE"
    community 14
  ]
  node [
    id 1895
    label "E:GATE-POST"
    kind "entity"
    name "GATE-POST"
    community 14
  ]
  node [
    id 1896
    label "E:DARBEY TO WAIT"
    kind "entity"
    name "DARBEY TO WAIT"
    community 14
  ]
  node [
    id 1897
    label "E:COURSE IS CLEAR"
    kind "entity"
    name "COURSE IS CLEAR"
    community 14
  ]
  node [
    id 1898
    label "C:Novel-40700_00106"
    kind "chunk"
    chunk_id "Novel-40700_00106"
  ]
  node [
    id 1899
    label "U:Novel-40700_00106#0"
    kind "unit"
    chunk_id "Novel-40700_00106"
    text "Tris waves her handkerchief and urges the group to proceed, reminding them to mind the gate-post and to hold someone up while giving him his head. Sir Tristram and Hatcham enter by the window carrying The Dean, who appears to have just survived a prolonged struggle."
    community 14
  ]
  node [
    id 1900
    label "E:GROUP"
    kind "entity"
    name "GROUP"
    community 14
  ]
  node [
    id 1901
    label "E:MIND GATE-POST"
    kind "entity"
    name "MIND GATE-POST"
    community 14
  ]
  node [
    id 1902
    label "E:HOLD SOMEONE UP"
    kind "entity"
    name "HOLD SOMEONE UP"
    community 14
  ]
  node [
    id 1903
    label "E:GIVE HIM HIS HEAD"
    kind "entity"
    name "GIVE HIM HIS HEAD"
    community 14
  ]
  node [
    id 1904
    label "E:SIR TRISTRAM AND HATCHAM"
    kind "entity"
    name "SIR TRISTRAM AND HATCHAM"
    community 14
  ]
  node [
    id 1905
    label "E:PROLONGED STRUGGLE"
    kind "entity"
    name "PROLONGED STRUGGLE"
    community 14
  ]
  node [
    id 1906
    label "U:Novel-40700_00106#1"
    kind "unit"
    chunk_id "Novel-40700_00106"
    text "Sir Tristram and Georgiana urge Hatcham to put down The Dean, who is then placed in a chair. Georgiana and Sir Tristram take hold of The Dean's hands to feel his pulse, while Hatcham places his hand on The Dean's heart."
    community 12
  ]
  node [
    id 1907
    label "E:PULSE"
    kind "entity"
    name "PULSE"
    community 12
  ]
  node [
    id 1908
    label "E:HATCHAM TO PUT DOWN THE DEAN"
    kind "entity"
    name "HATCHAM TO PUT DOWN THE DEAN"
    community 12
  ]
  node [
    id 1909
    label "E:DEAN'S HAND"
    kind "entity"
    name "DEAN'S HAND"
    community 12
  ]
  node [
    id 1910
    label "E:DEAN'S HEART"
    kind "entity"
    name "DEAN'S HEART"
    community 12
  ]
  node [
    id 1911
    label "U:Novel-40700_00106#2"
    kind "unit"
    chunk_id "Novel-40700_00106"
    text "The Dean opens his eyes and asks where he is. Georgiana responds that he lives and cheers, while Sir Tristram and Hatcham quietly respond with 'Hurrah' and instruct Hatcham to go cheer in the roadway."
    community 14
  ]
  node [
    id 1912
    label "E:ROADWAY"
    kind "entity"
    name "ROADWAY"
    community 12
  ]
  node [
    id 1913
    label "E:HURRAH"
    kind "entity"
    name "HURRAH"
    community 14
  ]
  node [
    id 1914
    label "E:WHERE HE IS"
    kind "entity"
    name "WHERE HE IS"
    community 14
  ]
  node [
    id 1915
    label "E:HE LIVES"
    kind "entity"
    name "HE LIVES"
    community 14
  ]
  node [
    id 1916
    label "E:HATCHAM TO GO TO ROADWAY"
    kind "entity"
    name "HATCHAM TO GO TO ROADWAY"
    community 14
  ]
  node [
    id 1917
    label "U:Novel-40700_00106#3"
    kind "unit"
    chunk_id "Novel-40700_00106"
    text "The Dean gradually recovers and says he feels torn to fragments. Sir Tristram acknowledges this and thanks heaven he is conscious. The Dean describes feeling as if he had been walked over carefully by a large concourse of the lower orders. Georgiana agrees with this description."
    community 14
  ]
  node [
    id 1918
    label "E:FRAGMENTS"
    kind "entity"
    name "FRAGMENTS"
    community 14
  ]
  node [
    id 1919
    label "E:LOWER ORDERS"
    kind "entity"
    name "LOWER ORDERS"
    community 14
  ]
  node [
    id 1920
    label "E:RECOVERING"
    kind "entity"
    name "RECOVERING"
    community 14
  ]
  node [
    id 1921
    label "E:TORN TO FRAGMENTS"
    kind "entity"
    name "TORN TO FRAGMENTS"
    community 14
  ]
  node [
    id 1922
    label "E:DEAN IS CONSCIOUS"
    kind "entity"
    name "DEAN IS CONSCIOUS"
    community 14
  ]
  node [
    id 1923
    label "E:WALKED OVER BY LARGE CONCOURSE OF LOWER ORDERS"
    kind "entity"
    name "WALKED OVER BY LARGE CONCOURSE OF LOWER ORDERS"
    community 14
  ]
  node [
    id 1924
    label "E:DEAN'S FEELING"
    kind "entity"
    name "DEAN'S FEELING"
    community 14
  ]
  node [
    id 1925
    label "C:Novel-40700_00107"
    kind "chunk"
    chunk_id "Novel-40700_00107"
  ]
  node [
    id 1926
    label "U:Novel-40700_00107#0"
    kind "unit"
    chunk_id "Novel-40700_00107"
    text "Georgiana says that Hatcham's memory is all right, as confirmed by his voice cheering in the distance. Sir Tristram says he will raise Hatcham's wages. The Dean asks if he has been forcibly and illegally rescued, and Sir Tristram confirms this. The Dean questions who committed the act, and Sir Tristram identifies Georgiana as the woman who did it, describing her as someone who would have been a heroine in any age. The Dean agrees to overlook the incident as a relative but vows never to allow it to happen again. Georgiana confirms that they discovered the plan of another woman failed, and that they learned the genial constable was going to watch the races at the edge of the hill, up Pear Tree Lane. They immediately went to the hill, where they found hundreds of old friends, including welshers, pick-pockets, and card-sharpers, all of whom were part of the lowest ranks of the racecourse cads. Georgiana says she felt at home among them, as much at ease as a duchess in a drawing room."
    community 6
  ]
  node [
    id 1927
    label "E:WELSHERS"
    kind "entity"
    name "WELSHERS"
    community 6
  ]
  node [
    id 1928
    label "E:PICK-POCKETS"
    kind "entity"
    name "PICK-POCKETS"
    community 6
  ]
  node [
    id 1929
    label "E:CARD-SHARPERS"
    kind "entity"
    name "CARD-SHARPERS"
    community 6
  ]
  node [
    id 1930
    label "E:GENIAL CONSTABLE"
    kind "entity"
    name "GENIAL CONSTABLE"
    community 6
  ]
  node [
    id 1931
    label "E:OLD FRIENDS"
    kind "entity"
    name "OLD FRIENDS"
    community 6
  ]
  node [
    id 1932
    label "E:DUCHESS"
    kind "entity"
    name "DUCHESS"
    community 6
  ]
  node [
    id 1933
    label "E:OTHER WOMAN"
    kind "entity"
    name "OTHER WOMAN"
    community 6
  ]
  node [
    id 1934
    label "E:EDGE OF THE HILL"
    kind "entity"
    name "EDGE OF THE HILL"
    community 6
  ]
  node [
    id 1935
    label "E:LOWEST RACE-COURSE CADS"
    kind "entity"
    name "LOWEST RACE-COURSE CADS"
    community 6
  ]
  node [
    id 1936
    label "E:DUCHESS IN A DRAWING-ROOM"
    kind "entity"
    name "DUCHESS IN A DRAWING-ROOM"
    community 6
  ]
  node [
    id 1937
    label "C:Novel-40700_00108"
    kind "chunk"
    chunk_id "Novel-40700_00108"
  ]
  node [
    id 1938
    label "U:Novel-40700_00108#0"
    kind "unit"
    chunk_id "Novel-40700_00108"
    text "Georgiana exclaims, 'A Queen in a Palace! Boadicea among the Druids!', then shouts 'Do you know me?', and is immediately recognized by someone as 'George Tidd'. Tears of joy come to her eyes, but while wiping them away, Tris empties her pockets and she loses her watch."
    community 6
  ]
  node [
    id 1939
    label "E:WATCH"
    kind "entity"
    name "WATCH"
    community 6
  ]
  node [
    id 1940
    label "U:Novel-40700_00108#1"
    kind "unit"
    chunk_id "Novel-40700_00108"
    text "Georgiana stands on a back, supported by a correct-card merchant on either side, and declares to the crowd, 'Dear friends, Brothers! I'm with you once again'. The crowd responds with shouts of honest welcome, but before she can silence them, her field glasses are lost."
    community 6
  ]
  node [
    id 1941
    label "E:CORRECT-CARD MERCHANT"
    kind "entity"
    name "CORRECT-CARD MERCHANT"
    community 6
  ]
  node [
    id 1942
    label "E:FIELD GLASSES"
    kind "entity"
    name "FIELD GLASSES"
    community 6
  ]
  node [
    id 1943
    label "E:CROWD"
    kind "entity"
    name "CROWD"
    community 6
  ]
  node [
    id 1944
    label "E:BACK"
    kind "entity"
    name "BACK"
    community 6
  ]
  node [
    id 1945
    label "E:SHOUTS OF HONEST WELCOME"
    kind "entity"
    name "SHOUTS OF HONEST WELCOME"
    community 6
  ]
  node [
    id 1946
    label "U:Novel-40700_00108#2"
    kind "unit"
    chunk_id "Novel-40700_00108"
    text "Georgiana announces that a very dear relative of hers has been caught for playing a three-card trick on his way down from town. He will be on the brow of the hill with a bobby in half an hour, and she asks who is for the rescue. A young child asks what they will get for it, and Georgiana replies that they will receive a pound each, possibly with six months added."
    community 6
  ]
  node [
    id 1947
    label "E:DEAR RELATIVE"
    kind "entity"
    name "DEAR RELATIVE"
    community 6
  ]
  node [
    id 1948
    label "E:THREE-CARD TRICK"
    kind "entity"
    name "THREE-CARD TRICK"
    community 6
  ]
  node [
    id 1949
    label "E:BROW OF THE HILL"
    kind "entity"
    name "BROW OF THE HILL"
    community 6
  ]
  node [
    id 1950
    label "E:BOBBY"
    kind "entity"
    name "BOBBY"
    community 6
  ]
  node [
    id 1951
    label "E:YOUNG CHILD"
    kind "entity"
    name "YOUNG CHILD"
    community 6
  ]
  node [
    id 1952
    label "E:POUND"
    kind "entity"
    name "POUND"
    community 6
  ]
  node [
    id 1953
    label "E:SIX MONTHS"
    kind "entity"
    name "SIX MONTHS"
    community 6
  ]
  node [
    id 1954
    label "C:Novel-40700_00109"
    kind "chunk"
    chunk_id "Novel-40700_00109"
  ]
  node [
    id 1955
    label "U:Novel-40700_00109#0"
    kind "unit"
    chunk_id "Novel-40700_00109"
    text "There was a roar of assent, and the speaker's concluding words, 'and possibly six months,' were never heard. At that moment, Tris' back could stand it no longer, and both the speaker and Tris came heavily to the ground together. The speaker then seized The Dean by the hand and dragged him up. Now you know whose hands have led you back to your own manger. The speaker then embraced The Dean and asked, 'Oh, brother, confess--isn't there something good and noble in true English sport after all?'"
    community 14
  ]
  node [
    id 1956
    label "E:ROAR OF ASSENT"
    kind "entity"
    name "ROAR OF ASSENT"
    community 14
  ]
  node [
    id 1957
    label "E:CONCLUDING WORDS"
    kind "entity"
    name "CONCLUDING WORDS"
    community 14
  ]
  node [
    id 1958
    label "E:MANGER"
    kind "entity"
    name "MANGER"
    community 14
  ]
  node [
    id 1959
    label "E:OH, BROTHER, CONFESS"
    kind "entity"
    name "OH, BROTHER, CONFESS"
    community 14
  ]
  node [
    id 1960
    label "U:Novel-40700_00109#1"
    kind "unit"
    chunk_id "Novel-40700_00109"
    text "The Dean says every abused institution has its redeeming characteristic, but questions where the money will come from to reward the dreadful persons, stating he cannot reasonably ask his girls to organize a bazaar or concert."
    community 18
  ]
  node [
    id 1961
    label "E:ABUSED INSTITUTION"
    kind "entity"
    name "ABUSED INSTITUTION"
    community 18
  ]
  node [
    id 1962
    label "E:REDEEMING CHARACTERISTIC"
    kind "entity"
    name "REDEEMING CHARACTERISTIC"
    community 18
  ]
  node [
    id 1963
    label "E:BAZAAR"
    kind "entity"
    name "BAZAAR"
    community 18
  ]
  node [
    id 1964
    label "E:CONCERT"
    kind "entity"
    name "CONCERT"
    community 18
  ]
  node [
    id 1965
    label "U:Novel-40700_00109#2"
    kind "unit"
    chunk_id "Novel-40700_00109"
    text "Georgiana says she is a rich woman and has cleared fifteen hundred over the Handicap. The Dean recoils and asks about the horse that enjoyed the shelter of the Deanery last night. Georgiana replies that the horse won in a common canter, and all the rest were nowhere, with Bonny Betsy walking in with the policeman. The Dean says five hundred pounds will go towards the Spire, and he wonders where Blore is with the good news. Sir Tristram says look at him, lively as a cricket."
    community 12
  ]
  node [
    id 1966
    label "E:FIFTEEN HUNDRED"
    kind "entity"
    name "FIFTEEN HUNDRED"
    community 12
  ]
  node [
    id 1967
    label "E:POLICEMAN"
    kind "entity"
    name "POLICEMAN"
    community 12
  ]
  node [
    id 1968
    label "U:Novel-40700_00109#3"
    kind "unit"
    chunk_id "Novel-40700_00109"
    text "Sir Tristram calls the horse Dandy Dick, and the Dean confirms it won. Georgiana says the horse won in a common canter, and all the others were nowhere, with Bonny Betsy walking in with the policeman. The Dean says five hundred pounds will go towards the Spire and wonders where Blore is with the good news. Sir Tristram says Blore is lively as a cricket."
    community 12
  ]
  node [
    id 1969
    label "C:Novel-40700_00110"
    kind "chunk"
    chunk_id "Novel-40700_00110"
  ]
  node [
    id 1970
    label "U:Novel-40700_00110#0"
    kind "unit"
    chunk_id "Novel-40700_00110"
    text "The Dean states that Sir Tristram's horse swallowed a small portion of a bolus last night, which he then removed after being surprised. Sir Tristram expresses anticipation for the analysis of the bolus every minute. The Dean reveals that the secret is with him and mentions that he seeks no acknowledgment from either Sir Tristram or himself, but urges them to remember with gratitude the book 'The Horse and its Ailments' and its humane author, John Cox."
    community 7
  ]
  node [
    id 1971
    label "E:ANALYSIS OF BOLUS"
    kind "entity"
    name "ANALYSIS OF BOLUS"
    community 7
  ]
  node [
    id 1972
    label "E:HORSE AND ITS AILMENTS"
    kind "entity"
    name "HORSE AND ITS AILMENTS"
    community 7
  ]
  node [
    id 1973
    label "E:JOHN COX"
    kind "entity"
    name "JOHN COX"
    community 7
  ]
  node [
    id 1974
    label "U:Novel-40700_00110#1"
    kind "unit"
    chunk_id "Novel-40700_00110"
    text "Georgiana expresses surprise and emotion to Sir Tristram, stating that he was the one who hauled Augustin out of the cart by his legs and who, when his cap fell off, pulled the horse's nose-bag over her brother's head to prevent recognition. Sir Tristram dismisses these actions as common courtesies of everyday life."
    community 9
  ]
  node [
    id 1975
    label "E:NOSE-BAG"
    kind "entity"
    name "NOSE-BAG"
    community 9
  ]
  node [
    id 1976
    label "E:EVERY-DAY LIFE"
    kind "entity"
    name "EVERY-DAY LIFE"
    community 9
  ]
  node [
    id 1977
    label "C:Novel-40700_00111"
    kind "chunk"
    chunk_id "Novel-40700_00111"
  ]
  node [
    id 1978
    label "U:Novel-40700_00111#0"
    kind "unit"
    chunk_id "Novel-40700_00111"
    text "Sir Tristram and Georgiana discuss everyday courtesies, with Sir Tristram noting that certain actions are common in daily life, and Georgiana agreeing that any true woman would consider such acts honorable."
    community 9
  ]
  node [
    id 1979
    label "E:COMMON COURTESIES"
    kind "entity"
    name "COMMON COURTESIES"
    community 9
  ]
  node [
    id 1980
    label "U:Novel-40700_00111#1"
    kind "unit"
    chunk_id "Novel-40700_00111"
    text "Georgiana and Sir Tristram recall a moment when Gus was embarrassed as cut chaff ran down the back of his neck, and both agree that Gus will not forget it nor will she."
    community 8
  ]
  node [
    id 1981
    label "E:CUT CHAFF"
    kind "entity"
    name "CUT CHAFF"
    community 8
  ]
  node [
    id 1982
    label "E:BACK OF NECK"
    kind "entity"
    name "BACK OF NECK"
    community 8
  ]
  node [
    id 1983
    label "U:Novel-40700_00111#2"
    kind "unit"
    chunk_id "Novel-40700_00111"
    text "Sir Tristram recalls that Georgiana gave Dandy his whisky from a soda water bottle just before the race, and calls her the Florence Nightingale of the paddock, to which Georgiana responds that any lady would do the same."
    community 12
  ]
  node [
    id 1984
    label "E:WHISKY"
    kind "entity"
    name "WHISKY"
    community 12
  ]
  node [
    id 1985
    label "E:SODA WATER BOTTLE"
    kind "entity"
    name "SODA WATER BOTTLE"
    community 12
  ]
  node [
    id 1986
    label "E:FLORENCE NIGHTINGALE"
    kind "entity"
    name "FLORENCE NIGHTINGALE"
    community 12
  ]
  node [
    id 1987
    label "E:PADDOCK"
    kind "entity"
    name "PADDOCK"
    community 12
  ]
  node [
    id 1988
    label "E:FLORENCE NIGHTINGALE OF THE PADDOCK"
    kind "entity"
    name "FLORENCE NIGHTINGALE OF THE PADDOCK"
    community 12
  ]
  node [
    id 1989
    label "U:Novel-40700_00111#3"
    kind "unit"
    chunk_id "Novel-40700_00111"
    text "Georgiana explains that she will not marry Sir Tristram because he only recently asked her, and that last night when he touched her hand, she reared, which she attributes to the fact that he had not put her brother's head in a nose-bag."
    community 9
  ]
  node [
    id 1990
    label "E:MUTUAL ESTEEM"
    kind "entity"
    name "MUTUAL ESTEEM"
    community 9
  ]
  node [
    id 1991
    label "E:HAND"
    kind "entity"
    name "HAND"
    community 9
  ]
  node [
    id 1992
    label "E:LOVE IS FOUNDED ON MUTUAL ESTEEM"
    kind "entity"
    name "LOVE IS FOUNDED ON MUTUAL ESTEEM"
    community 9
  ]
  node [
    id 1993
    label "E:HAND WAS TOUCHED"
    kind "entity"
    name "HAND WAS TOUCHED"
    community 9
  ]
  node [
    id 1994
    label "E:BROTHER'S HEAD IN"
    kind "entity"
    name "BROTHER'S HEAD IN"
    community 9
  ]
  node [
    id 1995
    label "E:BROTHER'S HEAD"
    kind "entity"
    name "BROTHER'S HEAD"
    community 9
  ]
  node [
    id 1996
    label "U:Novel-40700_00111#4"
    kind "unit"
    chunk_id "Novel-40700_00111"
    text "Sheba enters and expresses annoyance at being excluded, noting that Aunt and Sir Tristram are in the room, while Salome and Major Tarver are in the conservatory, and asks where she and Mr. Darbey are to go, calling out for Papa to come back."
    community 1
  ]
  node [
    id 1997
    label "E:CONSERVATORY"
    kind "entity"
    name "CONSERVATORY"
    community 1
  ]
  node [
    id 1998
    label "E:HOT PIPES"
    kind "entity"
    name "HOT PIPES"
    community 1
  ]
  node [
    id 1999
    label "E:AUNT AND SIR TRISTRAM ARE IN THE ROOM"
    kind "entity"
    name "AUNT AND SIR TRISTRAM ARE IN THE ROOM"
    community 1
  ]
  node [
    id 2000
    label "E:MR. DARBEY AND SHE ARE TO GO"
    kind "entity"
    name "MR. DARBEY AND SHE ARE TO GO"
    community 1
  ]
  node [
    id 2001
    label "C:Novel-40700_00112"
    kind "chunk"
    chunk_id "Novel-40700_00112"
  ]
  node [
    id 2002
    label "U:Novel-40700_00112#0"
    kind "unit"
    chunk_id "Novel-40700_00112"
    text "The Dean enters the library carrying a paper in his hand and reads it with horror, discovering that he is a debtor to Lewis Isaacs, a costumier to the Queen, with a total debt of forty pounds and nineteen shillings. He had picked up the document on the stairs, and upon reading it, expresses shock at the revelation of his financial misfortune."
    community 17
  ]
  node [
    id 2003
    label "E:COSTUMIER TO THE QUEEN"
    kind "entity"
    name "COSTUMIER TO THE QUEEN"
    community 17
  ]
  node [
    id 2004
    label "E:FOURTY POUNDS AND NINETEEN SHILLINGS"
    kind "entity"
    name "FOURTY POUNDS AND NINETEEN SHILLINGS"
    community 17
  ]
  node [
    id 2005
    label "E:FANCY MASKED BALL AT DURNSTONE"
    kind "entity"
    name "FANCY MASKED BALL AT DURNSTONE"
    community 17
  ]
  node [
    id 2006
    label "E:DEAN'S DEBT"
    kind "entity"
    name "DEAN'S DEBT"
    community 17
  ]
  node [
    id 2007
    label "E:ANAALYSIS"
    kind "entity"
    name "ANAALYSIS"
    community 17
  ]
  node [
    id 2008
    label "U:Novel-40700_00112#1"
    kind "unit"
    chunk_id "Novel-40700_00112"
    text "Salome and Sheba enter the room, rush at the Dean, and exclaim that their father has returned. Salome seizes his hands and Sheba grabs his coat-tails, turning him around violently, declaring that their parent has come back and begging him to return home."
    community 2
  ]
  node [
    id 2009
    label "E:DEAN'S HANDS"
    kind "entity"
    name "DEAN'S HANDS"
    community 2
  ]
  node [
    id 2010
    label "E:DEAN'S COAT-TAILS"
    kind "entity"
    name "DEAN'S COAT-TAILS"
    community 2
  ]
  node [
    id 2011
    label "E:DEAN HAS RETURNED"
    kind "entity"
    name "DEAN HAS RETURNED"
    community 2
  ]
  node [
    id 2012
    label "C:Novel-40700_00113"
    kind "chunk"
    chunk_id "Novel-40700_00113"
  ]
  node [
    id 2013
    label "U:Novel-40700_00113#0"
    kind "unit"
    chunk_id "Novel-40700_00113"
    text "The parent, referred to as THE DEAN, returns and asks questions about a disreputable document found in the house. The document states 'Debtor to Lewis Isaacs, Costumier to the Queen'. SHEBA and SALOME react with shock and confusion, with SHEBA sitting aghast on the table and SALOME falling distractedly to the floor. The DEAN reads the document and states that the moral is inculcated by the total of forty pounds, nineteen, calling it 'Imps of deceit'. He then mentions that there was a ball at Durnstone last night, which he claims he knows about, and is surprised that SALOME and SHEBA were not present. He asks which of his daughters was a person during the period of the French Revolution, and SHEBA points to SALOME, while the DEAN says SALOME was a flower-girl of an unknown epoch, and SALOME points to SHEBA. The DEAN then orders both daughters to go to their respective rooms."
    community 17
  ]
  node [
    id 2014
    label "E:BALL AT DURNSTONE"
    kind "entity"
    name "BALL AT DURNSTONE"
    community 17
  ]
  node [
    id 2015
    label "E:FLOWER-GIRL"
    kind "entity"
    name "FLOWER-GIRL"
    community 17
  ]
  node [
    id 2016
    label "E:RESPECTIVE ROOMS"
    kind "entity"
    name "RESPECTIVE ROOMS"
    community 17
  ]
  node [
    id 2017
    label "E:DEBTER TO LEWIS ISAACS"
    kind "entity"
    name "DEBTER TO LEWIS ISAACS"
    community 17
  ]
  node [
    id 2018
    label "U:Novel-40700_00113#1"
    kind "unit"
    chunk_id "Novel-40700_00113"
    text "The DEAN, upon returning, confronts SHEBA and SALOME with a document that lists a debt to Lewis Isaacs, a costumier to the Queen, and claims the total is forty pounds, nineteen. He accuses the daughters of deceit and references a ball at Durnstone the previous night, which he claims he knows about. He then questions which daughter was a person during the French Revolution, with SHEBA pointing to SALOME and the DEAN stating that SALOME was a flower-girl of an unknown epoch, and SALOME pointing to SHEBA in response. The DEAN then commands both daughters to go to their respective rooms."
    community 17
  ]
  node [
    id 2019
    label "C:Novel-40700_00114"
    kind "chunk"
    chunk_id "Novel-40700_00114"
  ]
  node [
    id 2020
    label "U:Novel-40700_00114#0"
    kind "unit"
    chunk_id "Novel-40700_00114"
    text "A flower-girl from an unknown epoch is introduced, with Salome pointing to Sheba. The girls are instructed to go to their respective rooms and have their blinds drawn. At seven, porridge will be brought to them. Salome says to Papa that as poor girls they can pay the bill, but the Dean insists they cannot. Sheba mentions that through the kindness of their Aunt, they might be able to cover the cost. Salome reveals they have won fifty pounds at the races. The Dean recoils and accuses both girls of being drawn into a vortex, questioning if there is any conscience or guilessness left in the house, except possibly his own. Sheba admits they always knew they were more capable than Papa gave them credit for. The Dean hands Sheba the bill, telling her to take it and never let it meet his eyes again, and announces that the scandalous costumes will be raffled for local charities. He declares that confidence, the precious pearl of domesticity, is now gone between them and chastises them by permanently withholding the reason for his absence from home the previous night."
    community 18
  ]
  node [
    id 2021
    label "E:PORRIDGE"
    kind "entity"
    name "PORRIDGE"
    community 18
  ]
  node [
    id 2022
    label "E:BLINDS"
    kind "entity"
    name "BLINDS"
    community 18
  ]
  node [
    id 2023
    label "E:CHARITIES"
    kind "entity"
    name "CHARITIES"
    community 18
  ]
  node [
    id 2024
    label "E:CONFIANCE"
    kind "entity"
    name "CONFIANCE"
    community 18
  ]
  node [
    id 2025
    label "E:ABSENCE FROM HOME"
    kind "entity"
    name "ABSENCE FROM HOME"
    community 18
  ]
  node [
    id 2026
    label "E:VORTEX"
    kind "entity"
    name "VORTEX"
    community 18
  ]
  node [
    id 2027
    label "E:GUILESSNESS"
    kind "entity"
    name "GUILESSNESS"
    community 18
  ]
  node [
    id 2028
    label "E:SCANDALOUS COSTOMES"
    kind "entity"
    name "SCANDALOUS COSTOMES"
    community 18
  ]
  node [
    id 2029
    label "E:THEIR RESPECTIVE ROOMS"
    kind "entity"
    name "THEIR RESPECTIVE ROOMS"
    community 18
  ]
  node [
    id 2030
    label "E:AT SEVEN"
    kind "entity"
    name "AT SEVEN"
    community 18
  ]
  node [
    id 2031
    label "E:NEWS OF THE WINNINGS"
    kind "entity"
    name "NEWS OF THE WINNINGS"
    community 18
  ]
  node [
    id 2032
    label "E:GUILESSNESS LEFT IN THE HOUSE"
    kind "entity"
    name "GUILESSNESS LEFT IN THE HOUSE"
    community 18
  ]
  node [
    id 2033
    label "E:BILL MEET HIS EYES"
    kind "entity"
    name "BILL MEET HIS EYES"
    community 18
  ]
  node [
    id 2034
    label "E:LOCAL CHARITIES"
    kind "entity"
    name "LOCAL CHARITIES"
    community 18
  ]
  node [
    id 2035
    label "E:REASON FOR HIS ABSENCE FROM HOME LAST NIGHT"
    kind "entity"
    name "REASON FOR HIS ABSENCE FROM HOME LAST NIGHT"
    community 18
  ]
  node [
    id 2036
    label "C:Novel-40700_00115"
    kind "chunk"
    chunk_id "Novel-40700_00115"
  ]
  node [
    id 2037
    label "U:Novel-40700_00115#0"
    kind "unit"
    chunk_id "Novel-40700_00115"
    text "SIR TRISTRAM enters quickly at the window, followed by GEORGIANA who carries a basin containing the bolus; SIR TRISTRAM has an opened letter in his hand and exclaims to Jedd that the analysis has arrived."
    community 7
  ]
  node [
    id 2038
    label "E:BASIN"
    kind "entity"
    name "BASIN"
    community 7
  ]
  node [
    id 2039
    label "E:OPENED LETTER"
    kind "entity"
    name "OPENED LETTER"
    community 7
  ]
  node [
    id 2040
    label "U:Novel-40700_00115#1"
    kind "unit"
    chunk_id "Novel-40700_00115"
    text "THE DEAN states he is absolutely indifferent, and GEORGIANA and SIR TRISTRAM respond that they are indifferent as well; THE DEAN accuses GEORGIANA of confronting him without a blush, claiming she enabled his innocent babies to discharge one of their own accounts for the first time in their lives."
    community 7
  ]
  node [
    id 2041
    label "E:INNOCENT BABIES"
    kind "entity"
    name "INNOCENT BABIES"
    community 7
  ]
  node [
    id 2042
    label "E:ACCOUNT"
    kind "entity"
    name "ACCOUNT"
    community 7
  ]
  node [
    id 2043
    label "U:Novel-40700_00115#2"
    kind "unit"
    chunk_id "Novel-40700_00115"
    text "SHEBA and SALOME appear outside the window, looking in; SIR TRISTRAM says Jedd was once his friend and is now his relative, and THE DEAN recognizes GEORGIANA as his sister."
    community 14
  ]
  node [
    id 2044
    label "U:Novel-40700_00115#3"
    kind "unit"
    chunk_id "Novel-40700_00115"
    text "SIR TRISTRAM declares that despite the family tie, he designates THE DEAN as one of the most atrocious conspirators in the history of the Turf; as the owner of one-half of Dandy Dick, SIR TRISTRAM denounces THE DEAN."
    community 24
  ]
  node [
    id 2045
    label "E:CONSPIRATOR"
    kind "entity"
    name "CONSPIRATOR"
    community 24
  ]
  node [
    id 2046
    label "U:Novel-40700_00115#4"
    kind "unit"
    chunk_id "Novel-40700_00115"
    text "GEORGIANA, as the owner of the other half of Dandy Dick, denounces THE DEAN in response."
    community 0
  ]
  node [
    id 2047
    label "C:Novel-40700_00116"
    kind "chunk"
    chunk_id "Novel-40700_00116"
  ]
  node [
    id 2048
    label "U:Novel-40700_00116#0"
    kind "unit"
    chunk_id "Novel-40700_00116"
    text "Georgiana, as the owner of the other half, denounces the Dean. Sheba and Salome enter and stand in the recess, listening. Sir Tristram states that the chief ingredient of the Dean's infernal preparation is known. The Dean claims the preparation contains nothing he would not willingly administer to his own children. Georgiana, in horror, points to the paper and says strychnine, sixteen grains. Sheba and Salome, clinging to each other in terror, exclaim oh. The Dean says strychnine and orders his devoted servant Blore to be summoned, as the innocuous mixture was compounded in his presence. Georgiana rings the bell; the girls hide behind the window curtains. The Dean claims the analysis is simply the result of over-enthusiasm by the local chemist. Georgiana calls the Dean a disgrace to the pretty little police station where he slept the previous night. Blore enters and stands unnoticed. The Dean says he will prove that in the Deanery Stables the common laws of hospitality have never been transgressed and asks for the bowl. Georgiana hands the Dean the basin from the table. He calls it a simple remedy for a chill. Georgiana and Sir Tristram both state strychnine&#8212;sixteen grains."
    community 5
  ]
  node [
    id 2049
    label "E:SIXTEEN GRAINS"
    kind "entity"
    name "SIXTEEN GRAINS"
    community 5
  ]
  node [
    id 2050
    label "E:LOCAL CHEMIST"
    kind "entity"
    name "LOCAL CHEMIST"
    community 5
  ]
  node [
    id 2051
    label "E:BOWL"
    kind "entity"
    name "BOWL"
    community 5
  ]
  node [
    id 2052
    label "E:BASEIN"
    kind "entity"
    name "BASEIN"
    community 5
  ]
  node [
    id 2053
    label "E:HOSPITALITY"
    kind "entity"
    name "HOSPITALITY"
    community 5
  ]
  node [
    id 2054
    label "E:LISTENING"
    kind "entity"
    name "LISTENING"
    community 5
  ]
  node [
    id 2055
    label "E:DEAN'S PREPARATION"
    kind "entity"
    name "DEAN'S PREPARATION"
    community 5
  ]
  node [
    id 2056
    label "E:HIS OWN CHILDREN"
    kind "entity"
    name "HIS OWN CHILDREN"
    community 5
  ]
  node [
    id 2057
    label "E:PAPER"
    kind "entity"
    name "PAPER"
    community 5
  ]
  node [
    id 2058
    label "E:STRYCHNINE, SIXTEEN GRAINS"
    kind "entity"
    name "STRYCHNINE, SIXTEEN GRAINS"
    community 5
  ]
  node [
    id 2059
    label "E:TERRIFIED"
    kind "entity"
    name "TERRIFIED"
    community 5
  ]
  node [
    id 2060
    label "E:OVER-ENTHUSIASM OF THE LOCAL CHEMIST"
    kind "entity"
    name "OVER-ENTHUSIASM OF THE LOCAL CHEMIST"
    community 5
  ]
  node [
    id 2061
    label "E:DEAN A DISGRACE TO THE POLICE STATION"
    kind "entity"
    name "DEAN A DISGRACE TO THE POLICE STATION"
    community 5
  ]
  node [
    id 2062
    label "E:BASIN FROM THE TABLE"
    kind "entity"
    name "BASIN FROM THE TABLE"
    community 5
  ]
  node [
    id 2063
    label "E:SIMPLE REMEDY FOR A CHILL"
    kind "entity"
    name "SIMPLE REMEDY FOR A CHILL"
    community 5
  ]
  node [
    id 2064
    label "E:GEORGIANA AND SIR TRISTRAM"
    kind "entity"
    name "GEORGIANA AND SIR TRISTRAM"
    community 5
  ]
  node [
    id 2065
    label "E:STRYCHNINE&#8212;SIXTEEN GRAINS"
    kind "entity"
    name "STRYCHNINE&#8212;SIXTEEN GRAINS"
    community 5
  ]
  node [
    id 2066
    label "C:Novel-40700_00117"
    kind "chunk"
    chunk_id "Novel-40700_00117"
  ]
  node [
    id 2067
    label "U:Novel-40700_00117#0"
    kind "unit"
    chunk_id "Novel-40700_00117"
    text "The Dean is suffering from the exposure of last night; he takes a bolus and opens his mouth to demonstrate. Blore rushes forward, snatches the basin from the Dean, and sinks to his knees, pleading not to hang the holdest servant in the Deanery. Blore admits that he had an honest fancy for Bonny Betsy and wanted the Dean's horse out of the way, introducing a foreign element into the strychnine dose. The Dean calls Blore a viper. Blore says it was done for the sake of the Dean. The Dean had only fifty pounds to spare for sporting purposes, and Blore thought a gentleman of his high standing ought to have a certainty. The Dean instructed Blore to back Dandy Dick on behalf of the Restoration Fund. Sir Tristram shakes Blore and asks if he did it; Blore denies doing it."
    community 20
  ]
  node [
    id 2068
    label "E:HOLDEST SERVANT IN THE DEANERY"
    kind "entity"
    name "HOLDEST SERVANT IN THE DEANERY"
    community 20
  ]
  node [
    id 2069
    label "E:ECCLESIASTICAL INTENTIONS"
    kind "entity"
    name "ECCLESIASTICAL INTENTIONS"
    community 20
  ]
  node [
    id 2070
    label "E:FOREIGN ELEMENT"
    kind "entity"
    name "FOREIGN ELEMENT"
    community 20
  ]
  node [
    id 2071
    label "E:EXPOSURE OF LAST NIGHT"
    kind "entity"
    name "EXPOSURE OF LAST NIGHT"
    community 20
  ]
  node [
    id 2072
    label "E:HANG THE HOLDEST SERVANT IN THE DEANERY"
    kind "entity"
    name "HANG THE HOLDEST SERVANT IN THE DEANERY"
    community 20
  ]
  node [
    id 2073
    label "E:VIPER"
    kind "entity"
    name "VIPER"
    community 20
  ]
  node [
    id 2074
    label "E:CERTAINTY"
    kind "entity"
    name "CERTAINTY"
    community 20
  ]
  node [
    id 2075
    label "E:ACT OF BACKING DANDY DICK"
    kind "entity"
    name "ACT OF BACKING DANDY DICK"
    community 20
  ]
  node [
    id 2076
    label "C:Novel-40700_00118"
    kind "chunk"
    chunk_id "Novel-40700_00118"
  ]
  node [
    id 2077
    label "U:Novel-40700_00118#0"
    kind "unit"
    chunk_id "Novel-40700_00118"
    text "Blore says he gave the mixture to Dandy and instead offered it to Bonny Betsy, in response to the Dean's question about why he did not give it to the Dean. The Dean calls Blore's action disobedient and declares him unworthy of the Deanery, demanding he leave for an ordinary household. Blore responds that if he leaves, he will give reasons, and wonders what people will think of both of them in old age. The Dean asks if Blore would tell the tale in St. Marvells, and Blore says not if sober, but that he might if grief drove him to drink. The Dean insists he must save Blore from intemperance and orders him to remain in service as a sad, sober, and silent man."
    community 13
  ]
  node [
    id 2078
    label "E:OLD AGE"
    kind "entity"
    name "OLD AGE"
    community 13
  ]
  node [
    id 2079
    label "E:DRINK"
    kind "entity"
    name "DRINK"
    community 13
  ]
  node [
    id 2080
    label "E:INTEMPERANCE"
    kind "entity"
    name "INTEMPERANCE"
    community 13
  ]
  node [
    id 2081
    label "E:DISOBEDIENT"
    kind "entity"
    name "DISOBEDIENT"
    community 13
  ]
  node [
    id 2082
    label "E:DEAN AND BLORE IN OLD AGE"
    kind "entity"
    name "DEAN AND BLORE IN OLD AGE"
    community 13
  ]
  node [
    id 2083
    label "E:SOBER"
    kind "entity"
    name "SOBER"
    community 13
  ]
  node [
    id 2084
    label "E:GRIEF DROVE HIM TO DRINK"
    kind "entity"
    name "GRIEF DROVE HIM TO DRINK"
    community 13
  ]
  node [
    id 2085
    label "E:SAD, SOBER AND SILENT MAN"
    kind "entity"
    name "SAD, SOBER AND SILENT MAN"
    community 13
  ]
  node [
    id 2086
    label "U:Novel-40700_00118#1"
    kind "unit"
    chunk_id "Novel-40700_00118"
    text "Salome and Sheba appear and Salome calls Papa, to which the Dean orders her to go to her rooms and says he is distracted. Salome announces Major Tarver and Mr. Darbey are present. The Dean responds that if they have lost all sense of moral rectitude and believe he is not at home, they may say so. Sheba says no, and instead claims they have discovered that the Dean, as their parent, has stooped to deception, if not to crime. The Dean staggers back in shock."
    community 1
  ]
  node [
    id 2087
    label "E:MORAL RECTITUDE"
    kind "entity"
    name "MORAL RECTITUDE"
    community 1
  ]
  node [
    id 2088
    label "E:DECEPTION"
    kind "entity"
    name "DECEPTION"
    community 8
  ]
  node [
    id 2089
    label "E:CRIME"
    kind "entity"
    name "CRIME"
    community 1
  ]
  node [
    id 2090
    label "E:HER ROOMS"
    kind "entity"
    name "HER ROOMS"
    community 1
  ]
  node [
    id 2091
    label "E:DISTRACTED"
    kind "entity"
    name "DISTRACTED"
    community 1
  ]
  node [
    id 2092
    label "E:MAJOR TARVER AND MR. DARBEY"
    kind "entity"
    name "MAJOR TARVER AND MR. DARBEY"
    community 1
  ]
  node [
    id 2093
    label "E:HE IS NOT AT HOME"
    kind "entity"
    name "HE IS NOT AT HOME"
    community 1
  ]
  node [
    id 2094
    label "E:STOOPED TO DECEPTION"
    kind "entity"
    name "STOOPED TO DECEPTION"
    community 1
  ]
  node [
    id 2095
    label "E:COMMITTED CRIME"
    kind "entity"
    name "COMMITTED CRIME"
    community 1
  ]
  node [
    id 2096
    label "E:IN SHOCK"
    kind "entity"
    name "IN SHOCK"
    community 1
  ]
  node [
    id 2097
    label "C:Novel-40700_00119"
    kind "chunk"
    chunk_id "Novel-40700_00119"
  ]
  node [
    id 2098
    label "U:Novel-40700_00119#0"
    kind "unit"
    chunk_id "Novel-40700_00119"
    text "The Dean staggers back and says that they are still young, so the sooner they are removed from any unfortunate influence the better. Salome says they have an opportunity to begin life afresh. Sheba replies that two gallant gentlemen have proposed for them. The Dean then says he is at home and asks where they are."
    community 19
  ]
  node [
    id 2099
    label "E:GALLANT GENTLEMEN"
    kind "entity"
    name "GALLANT GENTLEMEN"
    community 19
  ]
  node [
    id 2100
    label "E:UNFAVORABLE INFLUENCE"
    kind "entity"
    name "UNFAVORABLE INFLUENCE"
    community 19
  ]
  node [
    id 2101
    label "E:TO BEGIN LIFE AFRESH"
    kind "entity"
    name "TO BEGIN LIFE AFRESH"
    community 19
  ]
  node [
    id 2102
    label "E:TWO GALLANT GENTLEMEN HAVE PROPOSED FOR THEM"
    kind "entity"
    name "TWO GALLANT GENTLEMEN HAVE PROPOSED FOR THEM"
    community 19
  ]
  node [
    id 2103
    label "E:AFTER BEING ASKED WHERE THEY ARE"
    kind "entity"
    name "AFTER BEING ASKED WHERE THEY ARE"
    community 19
  ]
  node [
    id 2104
    label "U:Novel-40700_00119#1"
    kind "unit"
    chunk_id "Novel-40700_00119"
    text "Noah Topping, looking dishevelled, rushes in at the window with Hannah clinging to him. Noah glares around the room and asks if this is the Deanery. Georgiana and Sir Tristram come to him. Hannah calls Noah by name and urges him to come back. Noah claims a man has been rescued from his lawful custody while his face was unofficially held downwards in the mud, and that the villain has been traced back to the Deanery. Sir Tristram tells him to go away, and Hannah urges him to come away. Noah says the man was an unknown lover of his nooly made wife. Georgiana tells Noah he must not bring his domestic affairs here, as it is a subject for his own fireside."
    community 4
  ]
  node [
    id 2105
    label "E:LOVER"
    kind "entity"
    name "LOVER"
    community 4
  ]
  node [
    id 2106
    label "E:LAWFUL CUSTODY"
    kind "entity"
    name "LAWFUL CUSTODY"
    community 4
  ]
  node [
    id 2107
    label "E:UNOFFICIAL HOLDING DOWNWARDS IN THE MUD"
    kind "entity"
    name "UNOFFICIAL HOLDING DOWNWARDS IN THE MUD"
    community 4
  ]
  node [
    id 2108
    label "E:DOMESTIC AFFAIRS"
    kind "entity"
    name "DOMESTIC AFFAIRS"
    community 4
  ]
  node [
    id 2109
    label "E:FIRESIDE"
    kind "entity"
    name "FIRESIDE"
    community 4
  ]
  node [
    id 2110
    label "E:IF THIS IS THE DEANERY"
    kind "entity"
    name "IF THIS IS THE DEANERY"
    community 4
  ]
  node [
    id 2111
    label "E:HIS LAWFUL CUSTODY"
    kind "entity"
    name "HIS LAWFUL CUSTODY"
    community 4
  ]
  node [
    id 2112
    label "E:HIS NOOLY MADE WIFE"
    kind "entity"
    name "HIS NOOLY MADE WIFE"
    community 4
  ]
  node [
    id 2113
    label "E:DOMESTIC AFFAIRS HERE"
    kind "entity"
    name "DOMESTIC AFFAIRS HERE"
    community 4
  ]
  node [
    id 2114
    label "E:HIS OWN FIRESIDE"
    kind "entity"
    name "HIS OWN FIRESIDE"
    community 4
  ]
  node [
    id 2115
    label "U:Novel-40700_00119#2"
    kind "unit"
    chunk_id "Novel-40700_00119"
    text "The Dean appears outside the window with Salome, Sheba, Tarver and Darbey and calls Major Tarver and Mr. Darbey to come in. Noah recognizes the voice and exclaims that it is his voice."
    community 1
  ]
  node [
    id 2116
    label "E:SALOME, SHEBA, TARVER AND DARBEY"
    kind "entity"
    name "SALOME, SHEBA, TARVER AND DARBEY"
    community 1
  ]
  node [
    id 2117
    label "C:Novel-40700_00120"
    kind "chunk"
    chunk_id "Novel-40700_00120"
  ]
  node [
    id 2118
    label "U:Novel-40700_00120#0"
    kind "unit"
    chunk_id "Novel-40700_00120"
    text "The Dean enters the room followed by Salome, Tarver, Sheba, and Darby. Noah confronts the Dean, claiming he is speaking to the man he took the night before, who allegedly corrupted the affections of his wife."
    community 10
  ]
  node [
    id 2119
    label "E:DEAN OF CORRUPTING THE AFFECTIONS OF HIS WIFE"
    kind "entity"
    name "DEAN OF CORRUPTING THE AFFECTIONS OF HIS WIFE"
    community 10
  ]
  node [
    id 2120
    label "U:Novel-40700_00120#1"
    kind "unit"
    chunk_id "Novel-40700_00120"
    text "The Dean says he does not blame a man who is conscientious even in error and remarks that he recognizes Hannah Evans, who was once an excellent cook under the same roof. Hannah responds that she is now Mrs. Topping, the wife of the constable, and apologizes for her husband's ignorance."
    community 26
  ]
  node [
    id 2121
    label "E:HER HUSBAND'S IGNORANCE"
    kind "entity"
    name "HER HUSBAND'S IGNORANCE"
    community 26
  ]
  node [
    id 2122
    label "U:Novel-40700_00120#2"
    kind "unit"
    chunk_id "Novel-40700_00120"
    text "Sir Tristram asks Hatcham if the man he and the constable secured in the stable last night is the Dean. Hatcham confirms it is the Dean himself."
    community 7
  ]
  node [
    id 2123
    label "E:DEAN WAS SECURED IN THE STABLE LAST NIGHT"
    kind "entity"
    name "DEAN WAS SECURED IN THE STABLE LAST NIGHT"
    community 7
  ]
  node [
    id 2124
    label "C:Novel-40700_00121"
    kind "chunk"
    chunk_id "Novel-40700_00121"
  ]
  node [
    id 2125
    label "U:Novel-40700_00121#0"
    kind "unit"
    chunk_id "Novel-40700_00121"
    text "The Dean identifies SIR TRISTRAM as the unknown person found on his premises the previous night, stating that he is the Dean himself. The Dean withdraws any charge against this individual and attributes to him the most innocent intentions."
    community 9
  ]
  node [
    id 2126
    label "U:Novel-40700_00121#1"
    kind "unit"
    chunk_id "Novel-40700_00121"
    text "The Dean invites Hannah and her husband to dine in his kitchen, offering a hot meal with ale. Noah expresses confusion and frustration, criticizing Hannah for not thanking the Dean warmly, while Hannah responds by kissing the Dean's hands as a gesture of gratitude."
    community 25
  ]
  node [
    id 2127
    label "E:HER WORTHY HUSBAND"
    kind "entity"
    name "HER WORTHY HUSBAND"
    community 25
  ]
  node [
    id 2128
    label "E:HOT MEAL"
    kind "entity"
    name "HOT MEAL"
    community 25
  ]
  node [
    id 2129
    label "E:ALE"
    kind "entity"
    name "ALE"
    community 25
  ]
  node [
    id 2130
    label "E:HANNAH AND HER WORTHY HUSBAND"
    kind "entity"
    name "HANNAH AND HER WORTHY HUSBAND"
    community 25
  ]
  node [
    id 2131
    label "E:HOT MEAL WITH ALE"
    kind "entity"
    name "HOT MEAL WITH ALE"
    community 25
  ]
  node [
    id 2132
    label "E:HANNAH FOR NOT THANKING THE DEAN"
    kind "entity"
    name "HANNAH FOR NOT THANKING THE DEAN"
    community 25
  ]
  node [
    id 2133
    label "U:Novel-40700_00121#2"
    kind "unit"
    chunk_id "Novel-40700_00121"
    text "The Dean reflects on his personal situation, stating that his family influence is gone, his dignity is crushed, and the genial summer of the Deanery has been replaced by the winter of deceit."
    community 0
  ]
  node [
    id 2134
    label "E:FAMILY INFLUENCE"
    kind "entity"
    name "FAMILY INFLUENCE"
    community 0
  ]
  node [
    id 2135
    label "E:SUMMER"
    kind "entity"
    name "SUMMER"
    community 0
  ]
  node [
    id 2136
    label "E:WINTER"
    kind "entity"
    name "WINTER"
    community 0
  ]
  node [
    id 2137
    label "E:DECEIT"
    kind "entity"
    name "DECEIT"
    community 0
  ]
  node [
    id 2138
    label "E:WINTER OF DECEIT"
    kind "entity"
    name "WINTER OF DECEIT"
    community 0
  ]
  node [
    id 2139
    label "C:Novel-40700_00122"
    kind "chunk"
    chunk_id "Novel-40700_00122"
  ]
  node [
    id 2140
    label "U:Novel-40700_00122#0"
    kind "unit"
    chunk_id "Novel-40700_00122"
    text "Georgiana says that when Gus lays the whip on the horse called Deception, the horse takes the bit between its teeth and only the devil can stop it, and it would rather not be stopped. She asks who has been riding the horse hardest and states that the Dean has been doing so."
    community 8
  ]
  node [
    id 2141
    label "E:WHIP"
    kind "entity"
    name "WHIP"
    community 8
  ]
  node [
    id 2142
    label "E:BIT"
    kind "entity"
    name "BIT"
    community 8
  ]
  node [
    id 2143
    label "U:Novel-40700_00122#1"
    kind "unit"
    chunk_id "Novel-40700_00122"
    text "Georgiana tells the Dean that George Tidd will lend him a thousand pounds for the poor, innocent old Spire, on the condition that he admits there is no harm in their laughing at a Sporting Dean."
    community 20
  ]
  node [
    id 2144
    label "E:POOR INNOCENT OLD SPIRE"
    kind "entity"
    name "POOR INNOCENT OLD SPIRE"
    community 20
  ]
  node [
    id 2145
    label "E:LAUGHING AT A SPORTING DEAN"
    kind "entity"
    name "LAUGHING AT A SPORTING DEAN"
    community 20
  ]
  node [
    id 2146
    label "U:Novel-40700_00122#2"
    kind "unit"
    chunk_id "Novel-40700_00122"
    text "Georgiana says that her brother Gus does not want them to be merry at the Dean's expense, and both Georgiana and the Dean laugh at this."
    community 8
  ]
  node [
    id 2147
    label "E:MERRY"
    kind "entity"
    name "MERRY"
    community 8
  ]
  node [
    id 2148
    label "E:MERRY AT THE DEAN'S EXPENSE"
    kind "entity"
    name "MERRY AT THE DEAN'S EXPENSE"
    community 8
  ]
  node [
    id 2149
    label "E:THOSE WHO LAUGH OR ARE LAUGHED AT"
    kind "entity"
    name "THOSE WHO LAUGH OR ARE LAUGHED AT"
    community 8
  ]
  node [
    id 2150
    label "U:Novel-40700_00122#3"
    kind "unit"
    chunk_id "Novel-40700_00122"
    text "Sir Tristram says there is no harm in laughter for those who laugh or those who are laughed at."
    community 4
  ]
  node [
    id 2151
    label "C:Novel-40700_00123"
    kind "chunk"
    chunk_id "Novel-40700_00123"
  ]
  node [
    id 2152
    label "U:Novel-40700_00123#0"
    kind "unit"
    chunk_id "Novel-40700_00123"
    text "Georgiana states that there is no harm in laughter for those who laugh or those who are laughed at, provided that folly is the subject of laughter and not virtue, and that the laughter comes from friends, as they hope the audience will laugh at them for their efforts."
    community 4
  ]
  node [
    id 2153
    label "E:FOLLY"
    kind "entity"
    name "FOLLY"
    community 4
  ]
  node [
    id 2154
    label "E:VIRTUE"
    kind "entity"
    name "VIRTUE"
    community 4
  ]
  node [
    id 2155
    label "E:AUDIENCE"
    kind "entity"
    name "AUDIENCE"
    community 4
  ]
  node [
    id 2156
    label "E:PAINS"
    kind "entity"
    name "PAINS"
    community 4
  ]
  node [
    id 2157
    label "E:THOSE WHO LAUGH"
    kind "entity"
    name "THOSE WHO LAUGH"
    community 4
  ]
  node [
    id 2158
    label "E:THOSE WHO ARE LAUGHED AT"
    kind "entity"
    name "THOSE WHO ARE LAUGHED AT"
    community 4
  ]
  node [
    id 2159
    label "E:FOR THEIR PAINS"
    kind "entity"
    name "FOR THEIR PAINS"
    community 4
  ]
  node [
    id 2160
    label "C:Novel-40700_00124"
    kind "chunk"
    chunk_id "Novel-40700_00124"
  ]
  node [
    id 2161
    label "U:Novel-40700_00124#0"
    kind "unit"
    chunk_id "Novel-40700_00124"
    text "In the text of the play, Marvells' apostrophe is almost always omitted, while in the Introductory Note it is retained; the inconsistency has been allowed to stand in the Introductory Note, but the apostrophe has been removed in the few instances in the text."
    community 9
  ]
  node [
    id 2162
    label "E:MARVELLS"
    kind "entity"
    name "MARVELLS"
    community 9
  ]
  node [
    id 2163
    label "E:INTRODUCTORY NOTE"
    kind "entity"
    name "INTRODUCTORY NOTE"
    community 9
  ]
  node [
    id 2164
    label "E:APOSTROPHE"
    kind "entity"
    name "APOSTROPHE"
    community 9
  ]
  node [
    id 2165
    label "E:TEXT OF THE PLAY"
    kind "entity"
    name "TEXT OF THE PLAY"
    community 9
  ]
  node [
    id 2166
    label "U:Novel-40700_00124#1"
    kind "unit"
    chunk_id "Novel-40700_00124"
    text "On page 25, a bracket has been added to the beginning of the line: '_THE DEAN gives DARBEY a severe look..._'."
    community 3
  ]
  node [
    id 2167
    label "E:PAGE 25"
    kind "entity"
    name "PAGE 25"
    community 3
  ]
  node [
    id 2168
    label "E:BRACKET"
    kind "entity"
    name "BRACKET"
    community 3
  ]
  node [
    id 2169
    label "E:DEAN GIVES DARBEY A SEVERE LOOK..."
    kind "entity"
    name "DEAN GIVES DARBEY A SEVERE LOOK..."
    community 3
  ]
  node [
    id 2170
    label "U:Novel-40700_00124#2"
    kind "unit"
    chunk_id "Novel-40700_00124"
    text "On page 97, the second 'No' in 'No, Aunt, No!' has been changed to lower case."
    community 18
  ]
  node [
    id 2171
    label "E:PAGE 97"
    kind "entity"
    name "PAGE 97"
    community 18
  ]
  node [
    id 2172
    label "E:NO"
    kind "entity"
    name "NO"
    community 18
  ]
  node [
    id 2173
    label "E:LOWER CASE"
    kind "entity"
    name "LOWER CASE"
    community 18
  ]
  node [
    id 2174
    label "U:Novel-40700_00124#3"
    kind "unit"
    chunk_id "Novel-40700_00124"
    text "On page 139, the period after 'it' in 'Oh, what do you think of it. Mr. Darbey?' has been changed to a comma."
    community 5
  ]
  node [
    id 2175
    label "E:PAGE 139"
    kind "entity"
    name "PAGE 139"
    community 5
  ]
  node [
    id 2176
    label "E:WHAT DO YOU THINK OF IT"
    kind "entity"
    name "WHAT DO YOU THINK OF IT"
    community 5
  ]
  node [
    id 2177
    label "E:PERIOD"
    kind "entity"
    name "PERIOD"
    community 5
  ]
  node [
    id 2178
    label "E:COMMA"
    kind "entity"
    name "COMMA"
    community 9
  ]
  node [
    id 2179
    label "U:Novel-40700_00124#4"
    kind "unit"
    chunk_id "Novel-40700_00124"
    text "On page 141, the comma in 'We can't shout here, go and cheer...' has been changed to a semicolon."
    community 9
  ]
  node [
    id 2180
    label "E:PAGE 141"
    kind "entity"
    name "PAGE 141"
    community 9
  ]
  node [
    id 2181
    label "E:WE CAN'T SHOUT HERE"
    kind "entity"
    name "WE CAN'T SHOUT HERE"
    community 9
  ]
  node [
    id 2182
    label "E:GO AND CHEER"
    kind "entity"
    name "GO AND CHEER"
    community 9
  ]
  node [
    id 2183
    label "E:SEMICOLON"
    kind "entity"
    name "SEMICOLON"
    community 9
  ]
  node [
    id 2184
    label "U:Novel-40700_00124#5"
    kind "unit"
    chunk_id "Novel-40700_00124"
    text "On page 142, the comma in 'That's Hatcham, I'll raise his wages.' has been changed to a semicolon."
    community 9
  ]
  node [
    id 2185
    label "E:PAGE 142"
    kind "entity"
    name "PAGE 142"
    community 9
  ]
  node [
    id 2186
    label "E:THAT'S HATCHAM"
    kind "entity"
    name "THAT'S HATCHAM"
    community 9
  ]
  node [
    id 2187
    label "E:I'LL RAISE HIS WAGES"
    kind "entity"
    name "I'LL RAISE HIS WAGES"
    community 9
  ]
  node [
    id 2188
    label "U:Novel-40700_00124#6"
    kind "unit"
    chunk_id "Novel-40700_00124"
    text "On page 143, 'aint' has been changed to 'ain't'."
    community 9
  ]
  node [
    id 2189
    label "E:PAGE 143"
    kind "entity"
    name "PAGE 143"
    community 9
  ]
  node [
    id 2190
    label "E:AINT"
    kind "entity"
    name "AINT"
    community 9
  ]
  node [
    id 2191
    label "E:AIN'T"
    kind "entity"
    name "AIN'T"
    community 9
  ]
  node [
    id 2192
    label "U:Novel-40700_00124#7"
    kind "unit"
    chunk_id "Novel-40700_00124"
    text "On page 147, the comma in '...mutual esteem, last night...' has been changed to a semicolon."
    community 9
  ]
  node [
    id 2193
    label "E:PAGE 147"
    kind "entity"
    name "PAGE 147"
    community 9
  ]
  node [
    id 2194
    label "U:Novel-40700_00124#8"
    kind "unit"
    chunk_id "Novel-40700_00124"
    text "On page 154, 'I did it?' has been changed to 'I did it!'."
    community 9
  ]
  node [
    id 2195
    label "E:PAGE 154"
    kind "entity"
    name "PAGE 154"
    community 9
  ]
  node [
    id 2196
    label "E:I DID IT"
    kind "entity"
    name "I DID IT"
    community 9
  ]
  node [
    id 2197
    label "E:EXCLAMATION MARK"
    kind "entity"
    name "EXCLAMATION MARK"
    community 9
  ]
  node [
    id 2198
    label "E:I DID IT!"
    kind "entity"
    name "I DID IT!"
    community 9
  ]
  node [
    id 2199
    label "U:Novel-40700_00124#9"
    kind "unit"
    chunk_id "Novel-40700_00124"
    text "The html version of this etext attempts to reproduce the layout of the printed text, but some concessions have been made, particularly in the handling of stage directions enclosed by brackets on at least one side. Entrances were usually without brackets."
    community 9
  ]
  node [
    id 2200
    label "E:HTML VERSION"
    kind "entity"
    name "HTML VERSION"
    community 27
  ]
  node [
    id 2201
    label "E:ETEXT"
    kind "entity"
    name "ETEXT"
    community 27
  ]
  node [
    id 2202
    label "E:LAYOUT"
    kind "entity"
    name "LAYOUT"
    community 27
  ]
  node [
    id 2203
    label "E:STAGE DIRECTIONS"
    kind "entity"
    name "STAGE DIRECTIONS"
    community 27
  ]
  node [
    id 2204
    label "E:BRACKETS"
    kind "entity"
    name "BRACKETS"
    community 27
  ]
  node [
    id 2205
    label "E:ENTRANCES"
    kind "entity"
    name "ENTRANCES"
    community 27
  ]
  node [
    id 2206
    label "C:Novel-40700_00125"
    kind "chunk"
    chunk_id "Novel-40700_00125"
  ]
  node [
    id 2207
    label "U:Novel-40700_00125#0"
    kind "unit"
    chunk_id "Novel-40700_00125"
    text "Stage directions were typically not included in brackets and were typeset in the printed text either before or within dialogue. When placed after dialogue, they were flush right on the same line if space allowed, otherwise on the next line. If stage directions spanned two lines, they were indented as hanging paragraphs, with the amount of indentation varying. In the etext version, all stage directions not located before or within dialogue are moved to the next line, indented the same amount as hanging paragraphs, and formatted accordingly."
    community 27
  ]
  node [
    id 2208
    label "E:PRINTED TEXT"
    kind "entity"
    name "PRINTED TEXT"
    community 27
  ]
  node [
    id 2209
    label "E:DIALOGUE"
    kind "entity"
    name "DIALOGUE"
    community 27
  ]
  node [
    id 2210
    label "E:HANGING PARAGRAPHS"
    kind "entity"
    name "HANGING PARAGRAPHS"
    community 27
  ]
  node [
    id 2211
    label "E:INDENTATION"
    kind "entity"
    name "INDENTATION"
    community 27
  ]
  node [
    id 2212
    label "E:NEXT LINE"
    kind "entity"
    name "NEXT LINE"
    community 27
  ]
  node [
    id 2213
    label "E:NOT ENOUGH SPACE"
    kind "entity"
    name "NOT ENOUGH SPACE"
    community 27
  ]
  node [
    id 2214
    label "H:0"
    kind "community"
    community 0
    parent 1
    n_units 30
    n_entities 106
    top_entities "DANDY DICK | DEANERY | SWAN | FIFTY POUNDS | GEORGE | OLD COURT THEATRE | MORNING | ROYAL COURT THEATRE | ACT I | ACT II"
  ]
  node [
    id 2215
    label "H:1"
    kind "community"
    community 1
    parent 4
    n_units 17
    n_entities 72
    top_entities "MAJOR TARVER | DURNSTONE | MR. DARBEY | GERALD TARVER | DINNER | BELL | DR. MIDDLETON | MR. JOHN CLAYTON | HANNAH TOPPING | REGIMENTALS"
  ]
  node [
    id 2216
    label "H:2"
    kind "community"
    community 2
    parent 16
    n_units 17
    n_entities 96
    top_entities "BILLS | CELL | FOURTY POUNDS NINETEEN | PAPSEY | CHAIR | HANDCUFFS | ONE SKIRT AND BODICE | GOOD HUMOR | BILL | HORSE STABLED AT THE DEANERY"
  ]
  node [
    id 2217
    label "H:3"
    kind "community"
    community 3
    parent 0
    n_units 17
    n_entities 64
    top_entities "TARVER | DARBEY | SETTEE | MISS JEDD | BOY | MUSIC | VIOLIN | STAGE | LEATHER MUSIC ROLL | FLAMES"
  ]
  node [
    id 2218
    label "H:4"
    kind "community"
    community 4
    parent 3
    n_units 15
    n_entities 108
    top_entities "NOAH TOPPING | MR. CLAYTON | LAUGHTER | MR. PINERO | OVEN | CHAPEL FOLK | OLD NICK | CART | OLD NICK IN THE CART | NEW PLAY"
  ]
  node [
    id 2219
    label "H:5"
    kind "community"
    community 5
    parent 25
    n_units 15
    n_entities 92
    top_entities "MR. DARBEDY | SHEBA AND SALOME | TABLE | DEAR PAPA | TO-MORROW | OH | FRIENDSHIP | ACCOUNT FOR FANCY DRESSES | YOUNG GENTLEMAN | HORROR"
  ]
  node [
    id 2220
    label "H:6"
    kind "community"
    community 6
    parent 18
    n_units 15
    n_entities 71
    top_entities "RACES | GEORGE TIDD | HILL | HAMPER | PEAR TREE LANE | GENIAL CONSTABLE | DEAR RELATIVE | CRIMSON AND BLACK DIAMONDS | MENTAL DISTRACTION | BREAKFAST"
  ]
  node [
    id 2221
    label "H:7"
    kind "community"
    community 7
    parent 13
    n_units 14
    n_entities 48
    top_entities "STABLE | BOLUS | CHILL | UMBRELLA | BOOK | DEANERY OF ST. MARVELLS | ANIMAL | FIVE HUNDRED POUNDS | RAIN | HORSE AND ITS AILMENTS"
  ]
  node [
    id 2222
    label "H:8"
    kind "community"
    community 8
    parent 2
    n_units 14
    n_entities 82
    top_entities "GUS | AUGUSTIN | SPIRE | BISHOP | CANONS | DECEPTION | WORLD | WEIGHT | OLD NURSERY | RESTORATION"
  ]
  node [
    id 2223
    label "H:9"
    kind "community"
    community 9
    parent 12
    n_units 14
    n_entities 62
    top_entities "LAST NIGHT | COMMA | BROTHER | UNKNOWN PERSON | EVERY-DAY LIFE | SEMICOLON | DIGNIFIED INTERVIEW | NOSE-BAG | MUTUAL ESTEEM | MARVELLS"
  ]
  node [
    id 2224
    label "H:10"
    kind "community"
    community 10
    parent 6
    n_units 13
    n_entities 62
    top_entities "ST. MARVELLS | POLICE STATION | DR. JEDD | MRS. TIDMAN | MILITARY | CASE | THEY | VERY REV. AUGUSTIN JEDD | PROCEEDINGS | JOINT"
  ]
  node [
    id 2225
    label "H:11"
    kind "community"
    community 11
    parent 11
    n_units 13
    n_entities 52
    top_entities "GENTLEMEN | MARDON | NOTICE | CUSTARDS | PIANO | DURNSTONE ATHENAUM | BOYS | FRIGHTFULLY JOILY DINNER | OFFICERS | MR. TIDD"
  ]
  node [
    id 2226
    label "H:12"
    kind "community"
    community 12
    parent 5
    n_units 13
    n_entities 72
    top_entities "HORSE | HATCHAM | DANDY | TAIL | MR. TOPPING | THUNDER | COLD WATER | PHOTOGRAPH | INVALID | HANDICAP"
  ]
  node [
    id 2227
    label "H:13"
    kind "community"
    community 13
    parent 9
    n_units 12
    n_entities 51
    top_entities "GEORGIANA TIDMAN | SIR TRISTRAM MARDON | BONNY BETSY | JEDD | DAUGHTERS | OXFORD | ONE O'CLOCK | GRIEF | LUNCHEON | CARD"
  ]
  node [
    id 2228
    label "H:14"
    kind "community"
    community 14
    parent 15
    n_units 11
    n_entities 52
    top_entities "SPEAKER | WINDOW | TRIS | SIR TRISTRAM AND HATCHAM | BLACK RETRIEVER | POISON | PANTRY | DRUGS | COOKING PURPOSES | OLD STREETS AT OXFORD"
  ]
  node [
    id 2229
    label "H:15"
    kind "community"
    community 15
    parent 0
    n_units 10
    n_entities 51
    top_entities "PAPA | HOUSE | ARMY | ARMY NURSES | PERAMBULATOR | PAPA HAS BEEN OUT ALL NIGHT | COSTOMES | PARADE | FINAL ARRANGEMENTS | DESPOUNDENCY"
  ]
  node [
    id 2230
    label "H:16"
    kind "community"
    community 16
    parent 10
    n_units 10
    n_entities 52
    top_entities "STABLES | GARDEN | FIRE | LADY | CHILDREN | COAT | WIDOWED SISTER | OLD SPIRE | HAT | GATE-BELL"
  ]
  node [
    id 2231
    label "H:17"
    kind "community"
    community 17
    parent 26
    n_units 9
    n_entities 52
    top_entities "LEWIS ISAACS | AUNT GEORGIANA | MAN WHO BREWED HORSES | 50 POUNDS | FRENCH REVOLUTION | 40 POUNDS 19 | COSTUMIER TO THE QUEEN | QUEEN | BOW STREET | ONE GOWN"
  ]
  node [
    id 2232
    label "H:18"
    kind "community"
    community 18
    parent 7
    n_units 9
    n_entities 55
    top_entities "GIRLS | AUNT | MONEY | POOR DEAR PAPA | STEALING OUT OF THE HOUSE WITH MAJOR TARVER | MISS SALOME | AFTER BLORE'S ANNOUNCEMENT | MR. DARBEY IS THERE | NO | MARRIED"
  ]
  node [
    id 2233
    label "H:19"
    kind "community"
    community 19
    parent 0
    n_units 9
    n_entities 73
    top_entities "LIBRARY | SCENE | LIVER | SALOME AND SHEBA | UNDERTONES | CHARLES THE FIRST | CHARLES THE MARTYR | MAGNIFICENT | LOOKING MAGNIFICENT | MARTYR"
  ]
  node [
    id 2234
    label "H:20"
    kind "community"
    community 20
    parent 22
    n_units 9
    n_entities 35
    top_entities "THOUSAND POUNDS | TIMES | RESTORATION FUND | HIMSELF | SEVEN WEALTHY PEOPLE | SPORTING PAPERS | SPORTING DEAN | 1000 POUNDS | MINSTER SPIRE | FRESH AIR"
  ]
  node [
    id 2235
    label "H:21"
    kind "community"
    community 21
    parent 14
    n_units 8
    n_entities 84
    top_entities "PRISONER | POOR PAPA | CARDS | CHARACTER | DEAN'S MISFORTUNE | LED INTO IT | EDWARD BLORE | HEAD CONSTABLE | RULE | STRONG-BOX"
  ]
  node [
    id 2236
    label "H:22"
    kind "community"
    community 22
    parent 24
    n_units 8
    n_entities 40
    top_entities "PA | ILL LUCK | SAD BROKEN CREATURE | WEARY FRAGMENT | FICKERING SMILE | AUNT TIDMAN | BED | FATHER | STOCK | TELEGRAM"
  ]
  node [
    id 2237
    label "H:23"
    kind "community"
    community 23
    parent 8
    n_units 8
    n_entities 87
    top_entities "DOOR | CELL DOOR | GATE | GATE BELL | THEM | MRS. TOPPING | DIGNITY | POLICE-STATION | DESCRIPTION | BAKING-TIN"
  ]
  node [
    id 2238
    label "H:24"
    kind "community"
    community 24
    parent 23
    n_units 6
    n_entities 36
    top_entities "MAN | TRAY | ROLLING-PIN | TURF | DEANERY STABLES | MEDICINE CHEST | STRYCHNINE | BOTTLES | BAKING BASIN | THREE"
  ]
  node [
    id 2239
    label "H:25"
    kind "community"
    community 25
    parent 21
    n_units 5
    n_entities 41
    top_entities "ROOM | TARVER AND DARBEY | KITCHEN | MASSIVE DOOR | QUAIN OLD ROOM | PRISONER'S CELL | IRON GRATING | WALL | PLASTER WALLS | OAKEN BEAMS"
  ]
  node [
    id 2240
    label "H:26"
    kind "community"
    community 26
    parent 20
    n_units 5
    n_entities 45
    top_entities "CONSTABLE | WICKET | WIFE | HANNAH EVANS | KEY OF HANDCUFFS | ERRING CONSTABLE | MIDDLING AGES | ANNAH TOPPING | KNEE EVANS | EQUIVOCAL POSITION"
  ]
  node [
    id 2241
    label "H:27"
    kind "community"
    community 27
    parent 31
    n_units 1
    n_entities 12
    top_entities "STAGE DIRECTIONS | BRACKETS | HTML VERSION | ETEXT | LAYOUT | ENTRANCES | PRINTED TEXT | DIALOGUE | HANGING PARAGRAPHS | INDENTATION"
  ]
  edge [
    source 0
    target 1
    kind "from_chunk"
  ]
  edge [
    source 0
    target 7
    kind "from_chunk"
  ]
  edge [
    source 0
    target 10
    kind "from_chunk"
  ]
  edge [
    source 1
    target 2
    kind "mentions"
  ]
  edge [
    source 1
    target 3
    kind "mentions"
  ]
  edge [
    source 1
    target 4
    kind "mentions"
  ]
  edge [
    source 1
    target 5
    kind "mentions"
  ]
  edge [
    source 1
    target 6
    kind "mentions"
  ]
  edge [
    source 1
    target 2214
    kind "summarizes"
  ]
  edge [
    source 2
    target 3
    kind "relation"
    relation "is a farce written by"
    weight 1
  ]
  edge [
    source 2
    target 4
    kind "relation"
    relation "was produced at | is the swan-song of"
    weight 2
  ]
  edge [
    source 2
    target 7
    kind "mentions"
  ]
  edge [
    source 2
    target 9
    kind "relation"
    relation "is the swan-song of"
    weight 1
  ]
  edge [
    source 2
    target 6
    kind "relation"
    relation "was performing in | died while acting in"
    weight 2
  ]
  edge [
    source 2
    target 10
    kind "mentions"
  ]
  edge [
    source 2
    target 11
    kind "relation"
    relation "is considered a"
    weight 1
  ]
  edge [
    source 2
    target 13
    kind "mentions"
  ]
  edge [
    source 2
    target 34
    kind "mentions"
  ]
  edge [
    source 2
    target 35
    kind "relation"
    relation "was produced at"
    weight 1
  ]
  edge [
    source 2
    target 38
    kind "relation"
    relation "was produced on"
    weight 1
  ]
  edge [
    source 2
    target 40
    kind "relation"
    relation "received"
    weight 1
  ]
  edge [
    source 2
    target 41
    kind "relation"
    relation "became"
    weight 1
  ]
  edge [
    source 2
    target 42
    kind "mentions"
  ]
  edge [
    source 2
    target 45
    kind "relation"
    relation "was written by"
    weight 1
  ]
  edge [
    source 2
    target 46
    kind "relation"
    relation "is an"
    weight 1
  ]
  edge [
    source 2
    target 47
    kind "relation"
    relation "has three acts"
    weight 1
  ]
  edge [
    source 2
    target 72
    kind "mentions"
  ]
  edge [
    source 2
    target 73
    kind "relation"
    relation "is set in"
    weight 1
  ]
  edge [
    source 2
    target 74
    kind "relation"
    relation "is set in"
    weight 1
  ]
  edge [
    source 2
    target 75
    kind "relation"
    relation "is set in"
    weight 1
  ]
  edge [
    source 2
    target 80
    kind "mentions"
  ]
  edge [
    source 2
    target 86
    kind "relation"
    relation "was performed"
    weight 1
  ]
  edge [
    source 2
    target 84
    kind "relation"
    relation "was transferred to"
    weight 1
  ]
  edge [
    source 2
    target 88
    kind "mentions"
  ]
  edge [
    source 2
    target 89
    kind "relation"
    relation "sent a company to perform"
    weight 1
  ]
  edge [
    source 2
    target 92
    kind "relation"
    relation "was withdrawn from"
    weight 1
  ]
  edge [
    source 2
    target 93
    kind "mentions"
  ]
  edge [
    source 2
    target 94
    kind "relation"
    relation "produced"
    weight 1
  ]
  edge [
    source 2
    target 96
    kind "relation"
    relation "achieved limited success in"
    weight 1
  ]
  edge [
    source 2
    target 97
    kind "relation"
    relation "was enthusiastically received in"
    weight 1
  ]
  edge [
    source 2
    target 98
    kind "relation"
    relation "ran for an unusual time in"
    weight 1
  ]
  edge [
    source 2
    target 99
    kind "relation"
    relation "ran for an unusual time in"
    weight 1
  ]
  edge [
    source 2
    target 100
    kind "mentions"
  ]
  edge [
    source 2
    target 660
    kind "mentions"
  ]
  edge [
    source 2
    target 69
    kind "relation"
    relation "has a horse named"
    weight 1
  ]
  edge [
    source 2
    target 661
    kind "relation"
    relation "weighs"
    weight 1
  ]
  edge [
    source 2
    target 662
    kind "relation"
    relation "is ridden by"
    weight 1
  ]
  edge [
    source 2
    target 606
    kind "relation"
    relation "knew bonny betsy was strong"
    weight 1
  ]
  edge [
    source 2
    target 667
    kind "mentions"
  ]
  edge [
    source 2
    target 665
    kind "relation"
    relation "stayed with"
    weight 1
  ]
  edge [
    source 2
    target 710
    kind "mentions"
  ]
  edge [
    source 2
    target 649
    kind "relation"
    relation "is with | predicts the horse will romp in | owns half of | calls the horse"
    weight 5
  ]
  edge [
    source 2
    target 713
    kind "relation"
    relation "runs for | is the race for which dandy dick is backed"
    weight 2
  ]
  edge [
    source 2
    target 578
    kind "relation"
    relation "knows little about | exclaims the horse will dance in | asked john fielder to help with | will back | proposes to bring | decides to clap | owns half of"
    weight 7
  ]
  edge [
    source 2
    target 732
    kind "mentions"
  ]
  edge [
    source 2
    target 735
    kind "relation"
    relation "was sold at"
    weight 1
  ]
  edge [
    source 2
    target 733
    kind "relation"
    relation "sold half of"
    weight 1
  ]
  edge [
    source 2
    target 745
    kind "mentions"
  ]
  edge [
    source 2
    target 759
    kind "mentions"
  ]
  edge [
    source 2
    target 812
    kind "mentions"
  ]
  edge [
    source 2
    target 675
    kind "relation"
    relation "has not fed better at"
    weight 1
  ]
  edge [
    source 2
    target 813
    kind "relation"
    relation "will not be in"
    weight 1
  ]
  edge [
    source 2
    target 954
    kind "mentions"
  ]
  edge [
    source 2
    target 924
    kind "relation"
    relation "is brought into"
    weight 1
  ]
  edge [
    source 2
    target 961
    kind "mentions"
  ]
  edge [
    source 2
    target 962
    kind "mentions"
  ]
  edge [
    source 2
    target 1069
    kind "mentions"
  ]
  edge [
    source 2
    target 1072
    kind "mentions"
  ]
  edge [
    source 2
    target 679
    kind "relation"
    relation "is to be applied to"
    weight 1
  ]
  edge [
    source 2
    target 19
    kind "relation"
    relation "reacts with horror to | decides to place a bet on | confirms the horse won | instructed blore to back"
    weight 4
  ]
  edge [
    source 2
    target 1074
    kind "mentions"
  ]
  edge [
    source 2
    target 1075
    kind "relation"
    relation "is a moral certainty despite"
    weight 1
  ]
  edge [
    source 2
    target 1076
    kind "relation"
    relation "has a tail that comes down the hill"
    weight 1
  ]
  edge [
    source 2
    target 946
    kind "relation"
    relation "is unique in terms of"
    weight 1
  ]
  edge [
    source 2
    target 1139
    kind "mentions"
  ]
  edge [
    source 2
    target 1140
    kind "relation"
    relation "is described as"
    weight 1
  ]
  edge [
    source 2
    target 1141
    kind "relation"
    relation "has odds of"
    weight 1
  ]
  edge [
    source 2
    target 1223
    kind "mentions"
  ]
  edge [
    source 2
    target 1244
    kind "mentions"
  ]
  edge [
    source 2
    target 1502
    kind "mentions"
  ]
  edge [
    source 2
    target 54
    kind "relation"
    relation "wishes to know whether | had any of the medicine"
    weight 2
  ]
  edge [
    source 2
    target 1776
    kind "mentions"
  ]
  edge [
    source 2
    target 566
    kind "relation"
    relation "dosed"
    weight 1
  ]
  edge [
    source 2
    target 1968
    kind "mentions"
  ]
  edge [
    source 2
    target 2044
    kind "mentions"
  ]
  edge [
    source 2
    target 2046
    kind "mentions"
  ]
  edge [
    source 2
    target 2067
    kind "mentions"
  ]
  edge [
    source 3
    target 4
    kind "relation"
    relation "had comedic plays by"
    weight 1
  ]
  edge [
    source 4
    target 5
    kind "relation"
    relation "co-managed"
    weight 1
  ]
  edge [
    source 4
    target 6
    kind "relation"
    relation "co-managed"
    weight 1
  ]
  edge [
    source 4
    target 7
    kind "mentions"
  ]
  edge [
    source 5
    target 7
    kind "mentions"
  ]
  edge [
    source 6
    target 7
    kind "mentions"
  ]
  edge [
    source 7
    target 8
    kind "mentions"
  ]
  edge [
    source 7
    target 9
    kind "mentions"
  ]
  edge [
    source 7
    target 2214
    kind "summarizes"
  ]
  edge [
    source 10
    target 11
    kind "mentions"
  ]
  edge [
    source 10
    target 2214
    kind "summarizes"
  ]
  edge [
    source 12
    target 13
    kind "from_chunk"
  ]
  edge [
    source 12
    target 31
    kind "from_chunk"
  ]
  edge [
    source 13
    target 14
    kind "mentions"
  ]
  edge [
    source 13
    target 15
    kind "mentions"
  ]
  edge [
    source 13
    target 16
    kind "mentions"
  ]
  edge [
    source 13
    target 17
    kind "mentions"
  ]
  edge [
    source 13
    target 18
    kind "mentions"
  ]
  edge [
    source 13
    target 19
    kind "mentions"
  ]
  edge [
    source 13
    target 20
    kind "mentions"
  ]
  edge [
    source 13
    target 21
    kind "mentions"
  ]
  edge [
    source 13
    target 22
    kind "mentions"
  ]
  edge [
    source 13
    target 23
    kind "mentions"
  ]
  edge [
    source 13
    target 24
    kind "mentions"
  ]
  edge [
    source 13
    target 25
    kind "mentions"
  ]
  edge [
    source 13
    target 26
    kind "mentions"
  ]
  edge [
    source 13
    target 27
    kind "mentions"
  ]
  edge [
    source 13
    target 28
    kind "mentions"
  ]
  edge [
    source 13
    target 29
    kind "mentions"
  ]
  edge [
    source 13
    target 30
    kind "mentions"
  ]
  edge [
    source 13
    target 2218
    kind "summarizes"
  ]
  edge [
    source 14
    target 15
    kind "relation"
    relation "was contracted to write a successor to"
    weight 1
  ]
  edge [
    source 15
    target 25
    kind "relation"
    relation "announced dissatisfaction with"
    weight 1
  ]
  edge [
    source 15
    target 26
    kind "relation"
    relation "proposed to begin"
    weight 1
  ]
  edge [
    source 15
    target 27
    kind "relation"
    relation "developed an idea of"
    weight 1
  ]
  edge [
    source 15
    target 18
    kind "relation"
    relation "began work on"
    weight 1
  ]
  edge [
    source 15
    target 30
    kind "relation"
    relation "completed the new play"
    weight 1
  ]
  edge [
    source 16
    target 17
    kind "relation"
    relation "visited"
    weight 1
  ]
  edge [
    source 16
    target 28
    kind "relation"
    relation "was convinced by"
    weight 1
  ]
  edge [
    source 16
    target 29
    kind "relation"
    relation "returned to london with"
    weight 1
  ]
  edge [
    source 16
    target 80
    kind "mentions"
  ]
  edge [
    source 16
    target 88
    kind "mentions"
  ]
  edge [
    source 16
    target 90
    kind "relation"
    relation "set out with a company to tour"
    weight 1
  ]
  edge [
    source 16
    target 91
    kind "relation"
    relation "died during the tour at"
    weight 1
  ]
  edge [
    source 18
    target 31
    kind "mentions"
  ]
  edge [
    source 19
    target 100
    kind "mentions"
  ]
  edge [
    source 19
    target 101
    kind "relation"
    relation "performed as"
    weight 1
  ]
  edge [
    source 19
    target 103
    kind "mentions"
  ]
  edge [
    source 19
    target 104
    kind "relation"
    relation "played the role of"
    weight 1
  ]
  edge [
    source 19
    target 263
    kind "mentions"
  ]
  edge [
    source 19
    target 265
    kind "relation"
    relation "asks about | affirms | says to | takes hand of | shakes hands with | asks when he can see"
    weight 7
  ]
  edge [
    source 19
    target 329
    kind "mentions"
  ]
  edge [
    source 19
    target 264
    kind "relation"
    relation "confirms | expresses delight to | gives a severe look to | differs with | shakes hands with | offers any time | feared he would have been violently rude to | runs after | will not see"
    weight 9
  ]
  edge [
    source 19
    target 342
    kind "relation"
    relation "is described as"
    weight 1
  ]
  edge [
    source 19
    target 343
    kind "relation"
    relation "has"
    weight 1
  ]
  edge [
    source 19
    target 344
    kind "relation"
    relation "has"
    weight 1
  ]
  edge [
    source 19
    target 345
    kind "relation"
    relation "has"
    weight 1
  ]
  edge [
    source 19
    target 346
    kind "relation"
    relation "has"
    weight 1
  ]
  edge [
    source 19
    target 54
    kind "relation"
    relation "follows | takes from | thanks | enters with | asks if | is not well | orders | locks up | presented the bank-notes to | knew it would happen | hands money to | relies on | comments that | is someone who doesn't miss an opportunity | shrinks from | instructs | recoils from | wonders where | orders to be summoned | rushed forward and snatched the basin from | wanted the dean's horse out of the way | did it for the sake of | will give reasons if he leaves"
    weight 25
  ]
  edge [
    source 19
    target 349
    kind "mentions"
  ]
  edge [
    source 19
    target 60
    kind "relation"
    relation "sees | tells | reproaches | is instructed to represent | pins the chin of | has solicitude for | hands | warned | will drive with | must speak to | orders"
    weight 12
  ]
  edge [
    source 19
    target 107
    kind "relation"
    relation "sees | follows slyly | calls out | has love for | warned | must speak to | returned | orders"
    weight 9
  ]
  edge [
    source 19
    target 51
    kind "relation"
    relation "sees | invites | has dinner with"
    weight 4
  ]
  edge [
    source 19
    target 135
    kind "relation"
    relation "sees | calls | invites | has dinner with | has a feeling of positive distaste for"
    weight 5
  ]
  edge [
    source 19
    target 357
    kind "relation"
    relation "insists that | has a growing tendency to dislike"
    weight 2
  ]
  edge [
    source 19
    target 352
    kind "relation"
    relation "has dinner at"
    weight 1
  ]
  edge [
    source 19
    target 351
    kind "relation"
    relation "has dinner on"
    weight 1
  ]
  edge [
    source 19
    target 353
    kind "relation"
    relation "orders"
    weight 1
  ]
  edge [
    source 19
    target 354
    kind "relation"
    relation "orders"
    weight 1
  ]
  edge [
    source 19
    target 355
    kind "relation"
    relation "orders"
    weight 1
  ]
  edge [
    source 19
    target 356
    kind "relation"
    relation "orders"
    weight 1
  ]
  edge [
    source 19
    target 359
    kind "mentions"
  ]
  edge [
    source 19
    target 372
    kind "relation"
    relation "thanks"
    weight 1
  ]
  edge [
    source 19
    target 373
    kind "relation"
    relation "orders"
    weight 1
  ]
  edge [
    source 19
    target 374
    kind "relation"
    relation "orders"
    weight 1
  ]
  edge [
    source 19
    target 110
    kind "relation"
    relation "walks into | is present in | leaves | arrives from | returns"
    weight 6
  ]
  edge [
    source 19
    target 396
    kind "mentions"
  ]
  edge [
    source 19
    target 402
    kind "mentions"
  ]
  edge [
    source 19
    target 410
    kind "relation"
    relation "re-enters with"
    weight 1
  ]
  edge [
    source 19
    target 412
    kind "relation"
    relation "replies to"
    weight 1
  ]
  edge [
    source 19
    target 414
    kind "relation"
    relation "answers"
    weight 1
  ]
  edge [
    source 19
    target 416
    kind "relation"
    relation "tells sheba to watch"
    weight 1
  ]
  edge [
    source 19
    target 417
    kind "relation"
    relation "turns papers over"
    weight 1
  ]
  edge [
    source 19
    target 405
    kind "relation"
    relation "says | repeats | begins to arrange | has bills to settle | has bills | will pay | very little would settle | avoids shops where he owes | refers to"
    weight 9
  ]
  edge [
    source 19
    target 418
    kind "relation"
    relation "rises and walks to | recoils with a groan and sinks"
    weight 2
  ]
  edge [
    source 19
    target 419
    kind "relation"
    relation "sits and examines"
    weight 1
  ]
  edge [
    source 19
    target 425
    kind "mentions"
  ]
  edge [
    source 19
    target 227
    kind "relation"
    relation "calls | turn | dance around | cannot reasonably ask"
    weight 4
  ]
  edge [
    source 19
    target 428
    kind "mentions"
  ]
  edge [
    source 19
    target 434
    kind "mentions"
  ]
  edge [
    source 19
    target 438
    kind "relation"
    relation "says their wants are"
    weight 1
  ]
  edge [
    source 19
    target 439
    kind "relation"
    relation "asks salome"
    weight 1
  ]
  edge [
    source 19
    target 436
    kind "relation"
    relation "calls salome"
    weight 1
  ]
  edge [
    source 19
    target 442
    kind "mentions"
  ]
  edge [
    source 19
    target 454
    kind "relation"
    relation "is glad that"
    weight 1
  ]
  edge [
    source 19
    target 453
    kind "relation"
    relation "has no spare cash for"
    weight 1
  ]
  edge [
    source 19
    target 446
    kind "relation"
    relation "rises and walks to"
    weight 1
  ]
  edge [
    source 19
    target 443
    kind "relation"
    relation "declares that this must stop"
    weight 1
  ]
  edge [
    source 19
    target 459
    kind "relation"
    relation "describes the dressmaker's bill as"
    weight 1
  ]
  edge [
    source 19
    target 462
    kind "mentions"
  ]
  edge [
    source 19
    target 471
    kind "relation"
    relation "believes that"
    weight 1
  ]
  edge [
    source 19
    target 469
    kind "relation"
    relation "states the total of"
    weight 1
  ]
  edge [
    source 19
    target 470
    kind "relation"
    relation "has money under"
    weight 1
  ]
  edge [
    source 19
    target 472
    kind "mentions"
  ]
  edge [
    source 19
    target 473
    kind "relation"
    relation "points to | is anxious for | scans"
    weight 3
  ]
  edge [
    source 19
    target 482
    kind "mentions"
  ]
  edge [
    source 19
    target 496
    kind "relation"
    relation "states that if donors do not come, then"
    weight 1
  ]
  edge [
    source 19
    target 497
    kind "relation"
    relation "states that if donors do come, then"
    weight 1
  ]
  edge [
    source 19
    target 488
    kind "relation"
    relation "announces that they must also"
    weight 1
  ]
  edge [
    source 19
    target 491
    kind "relation"
    relation "reminds that to-morrow is the first day of | tells sir tristram he is here for"
    weight 2
  ]
  edge [
    source 19
    target 492
    kind "relation"
    relation "mentions that the event is called"
    weight 1
  ]
  edge [
    source 19
    target 494
    kind "relation"
    relation "receives a letter from"
    weight 1
  ]
  edge [
    source 19
    target 504
    kind "mentions"
  ]
  edge [
    source 19
    target 505
    kind "mentions"
  ]
  edge [
    source 19
    target 58
    kind "relation"
    relation "has reconciled with | is coming to live with | says is coming on this morning"
    weight 3
  ]
  edge [
    source 19
    target 506
    kind "relation"
    relation "sees georgiana as a second mother to"
    weight 1
  ]
  edge [
    source 19
    target 511
    kind "mentions"
  ]
  edge [
    source 19
    target 515
    kind "relation"
    relation "came a cropper"
    weight 1
  ]
  edge [
    source 19
    target 525
    kind "mentions"
  ]
  edge [
    source 19
    target 534
    kind "mentions"
  ]
  edge [
    source 19
    target 542
    kind "relation"
    relation "wrote"
    weight 1
  ]
  edge [
    source 19
    target 543
    kind "mentions"
  ]
  edge [
    source 19
    target 544
    kind "relation"
    relation "offers rest and forgetfulness at"
    weight 1
  ]
  edge [
    source 19
    target 548
    kind "relation"
    relation "says she is coming"
    weight 1
  ]
  edge [
    source 19
    target 549
    kind "mentions"
  ]
  edge [
    source 19
    target 561
    kind "mentions"
  ]
  edge [
    source 19
    target 571
    kind "relation"
    relation "announces that"
    weight 1
  ]
  edge [
    source 19
    target 567
    kind "relation"
    relation "asks sheba for"
    weight 1
  ]
  edge [
    source 19
    target 568
    kind "relation"
    relation "hears the gate bell"
    weight 1
  ]
  edge [
    source 19
    target 576
    kind "mentions"
  ]
  edge [
    source 19
    target 585
    kind "relation"
    relation "calls georgiana"
    weight 1
  ]
  edge [
    source 19
    target 592
    kind "mentions"
  ]
  edge [
    source 19
    target 596
    kind "relation"
    relation "objects to georgiana's illustrations"
    weight 1
  ]
  edge [
    source 19
    target 594
    kind "relation"
    relation "says the children do not follow"
    weight 1
  ]
  edge [
    source 19
    target 597
    kind "mentions"
  ]
  edge [
    source 19
    target 577
    kind "relation"
    relation "remembers having munched corn with"
    weight 1
  ]
  edge [
    source 19
    target 602
    kind "relation"
    relation "says their estrangement has been painfully prolonged"
    weight 1
  ]
  edge [
    source 19
    target 604
    kind "mentions"
  ]
  edge [
    source 19
    target 578
    kind "relation"
    relation "reproves | has a widowed sister named | is the sister of | will consider | will throw two pails of water over | reproaches | questions whether | says to | asks if | suggests a match between | whispers to | urged | gives admonition to | admonishes | agrees that he is done for | overlooks the incident as a relative | vows never to allow it to happen again | is indifferent to | confronts | recognizes as his sister | denounces | tells | requires that | laughs at | tries to silence"
    weight 26
  ]
  edge [
    source 19
    target 606
    kind "relation"
    relation "mentions | is surprised by | will lend"
    weight 3
  ]
  edge [
    source 19
    target 621
    kind "mentions"
  ]
  edge [
    source 19
    target 626
    kind "relation"
    relation "understands from letter that"
    weight 1
  ]
  edge [
    source 19
    target 627
    kind "mentions"
  ]
  edge [
    source 19
    target 628
    kind "relation"
    relation "responds with"
    weight 1
  ]
  edge [
    source 19
    target 633
    kind "mentions"
  ]
  edge [
    source 19
    target 642
    kind "relation"
    relation "feels disturbed by"
    weight 1
  ]
  edge [
    source 19
    target 634
    kind "relation"
    relation "has not met since"
    weight 2
  ]
  edge [
    source 19
    target 646
    kind "mentions"
  ]
  edge [
    source 19
    target 69
    kind "relation"
    relation "greeted"
    weight 1
  ]
  edge [
    source 19
    target 648
    kind "mentions"
  ]
  edge [
    source 19
    target 649
    kind "relation"
    relation "hits | is heartily pleased to revive acquaintance with | invites | is a dean | mentioned | mocks | suggests stowing | says good-night to | will teach | sees | says no stay | makes no charge against | asks | agrees that he is done for | carries | denounces | asks hatcham if the man secured in the stable is | identifies as"
    weight 18
  ]
  edge [
    source 19
    target 652
    kind "relation"
    relation "remembers mardon as"
    weight 1
  ]
  edge [
    source 19
    target 653
    kind "mentions"
  ]
  edge [
    source 19
    target 655
    kind "relation"
    relation "is a widower for"
    weight 1
  ]
  edge [
    source 19
    target 656
    kind "mentions"
  ]
  edge [
    source 19
    target 566
    kind "relation"
    relation "does not preach next sunday | has a bad look"
    weight 2
  ]
  edge [
    source 19
    target 667
    kind "mentions"
  ]
  edge [
    source 19
    target 668
    kind "relation"
    relation "expresses grief over"
    weight 1
  ]
  edge [
    source 19
    target 672
    kind "mentions"
  ]
  edge [
    source 19
    target 65
    kind "relation"
    relation "cannot offer hospitality at | would restore | declares he will have no more women cooks at | declares blore unworthy of"
    weight 4
  ]
  edge [
    source 19
    target 475
    kind "relation"
    relation "has a position in | could walk erect in | asks if blore would tell tale in"
    weight 3
  ]
  edge [
    source 19
    target 676
    kind "relation"
    relation "made the heaviest book on | always lost in"
    weight 2
  ]
  edge [
    source 19
    target 677
    kind "relation"
    relation "once matched a mare against"
    weight 1
  ]
  edge [
    source 19
    target 678
    kind "relation"
    relation "the mare was dreadfully beaten"
    weight 1
  ]
  edge [
    source 19
    target 683
    kind "mentions"
  ]
  edge [
    source 19
    target 686
    kind "relation"
    relation "was not in"
    weight 1
  ]
  edge [
    source 19
    target 644
    kind "relation"
    relation "was dreadfully beaten"
    weight 1
  ]
  edge [
    source 19
    target 687
    kind "mentions"
  ]
  edge [
    source 19
    target 689
    kind "mentions"
  ]
  edge [
    source 19
    target 690
    kind "relation"
    relation "denies"
    weight 1
  ]
  edge [
    source 19
    target 692
    kind "relation"
    relation "states"
    weight 1
  ]
  edge [
    source 19
    target 693
    kind "relation"
    relation "states"
    weight 1
  ]
  edge [
    source 19
    target 701
    kind "mentions"
  ]
  edge [
    source 19
    target 563
    kind "relation"
    relation "has a widowed sister"
    weight 1
  ]
  edge [
    source 19
    target 111
    kind "relation"
    relation "goes into | heard footsteps in"
    weight 2
  ]
  edge [
    source 19
    target 710
    kind "mentions"
  ]
  edge [
    source 19
    target 741
    kind "mentions"
  ]
  edge [
    source 19
    target 828
    kind "mentions"
  ]
  edge [
    source 19
    target 831
    kind "mentions"
  ]
  edge [
    source 19
    target 832
    kind "relation"
    relation "says it is useless to battle against"
    weight 1
  ]
  edge [
    source 19
    target 849
    kind "mentions"
  ]
  edge [
    source 19
    target 753
    kind "relation"
    relation "has offered | receives"
    weight 2
  ]
  edge [
    source 19
    target 855
    kind "mentions"
  ]
  edge [
    source 19
    target 884
    kind "mentions"
  ]
  edge [
    source 19
    target 476
    kind "relation"
    relation "owes"
    weight 1
  ]
  edge [
    source 19
    target 904
    kind "mentions"
  ]
  edge [
    source 19
    target 911
    kind "relation"
    relation "admits is responsible for"
    weight 1
  ]
  edge [
    source 19
    target 912
    kind "relation"
    relation "is surprised by"
    weight 1
  ]
  edge [
    source 19
    target 914
    kind "relation"
    relation "believes relief will be felt"
    weight 1
  ]
  edge [
    source 19
    target 915
    kind "relation"
    relation "explains the spire is | states the spire is"
    weight 2
  ]
  edge [
    source 19
    target 916
    kind "relation"
    relation "considers the involvement of three brewers"
    weight 1
  ]
  edge [
    source 19
    target 910
    kind "relation"
    relation "decides to enjoy"
    weight 1
  ]
  edge [
    source 19
    target 917
    kind "mentions"
  ]
  edge [
    source 19
    target 919
    kind "relation"
    relation "considers the involvement of three brewers"
    weight 1
  ]
  edge [
    source 19
    target 921
    kind "mentions"
  ]
  edge [
    source 19
    target 929
    kind "relation"
    relation "has a bright red glare"
    weight 2
  ]
  edge [
    source 19
    target 935
    kind "relation"
    relation "reminds"
    weight 2
  ]
  edge [
    source 19
    target 936
    kind "relation"
    relation "stops"
    weight 2
  ]
  edge [
    source 19
    target 938
    kind "mentions"
  ]
  edge [
    source 19
    target 940
    kind "mentions"
  ]
  edge [
    source 19
    target 954
    kind "mentions"
  ]
  edge [
    source 19
    target 959
    kind "mentions"
  ]
  edge [
    source 19
    target 651
    kind "relation"
    relation "appeals to"
    weight 1
  ]
  edge [
    source 19
    target 962
    kind "mentions"
  ]
  edge [
    source 19
    target 963
    kind "relation"
    relation "will be celebrated in"
    weight 1
  ]
  edge [
    source 19
    target 977
    kind "mentions"
  ]
  edge [
    source 19
    target 987
    kind "relation"
    relation "says he is"
    weight 1
  ]
  edge [
    source 19
    target 978
    kind "relation"
    relation "refuses to say | will not say"
    weight 2
  ]
  edge [
    source 19
    target 992
    kind "mentions"
  ]
  edge [
    source 19
    target 996
    kind "mentions"
  ]
  edge [
    source 19
    target 1027
    kind "mentions"
  ]
  edge [
    source 19
    target 540
    kind "relation"
    relation "says they are locking up | feels unable to face"
    weight 2
  ]
  edge [
    source 19
    target 1032
    kind "relation"
    relation "says the fire is"
    weight 1
  ]
  edge [
    source 19
    target 1039
    kind "mentions"
  ]
  edge [
    source 19
    target 1044
    kind "mentions"
  ]
  edge [
    source 19
    target 1048
    kind "mentions"
  ]
  edge [
    source 19
    target 1049
    kind "relation"
    relation "does not play cards"
    weight 1
  ]
  edge [
    source 19
    target 1053
    kind "mentions"
  ]
  edge [
    source 19
    target 1055
    kind "relation"
    relation "does not smoke"
    weight 1
  ]
  edge [
    source 19
    target 1054
    kind "relation"
    relation "will be seen by"
    weight 1
  ]
  edge [
    source 19
    target 122
    kind "relation"
    relation "is in a mournful state"
    weight 1
  ]
  edge [
    source 19
    target 1056
    kind "mentions"
  ]
  edge [
    source 19
    target 1057
    kind "relation"
    relation "is short of | is run low on"
    weight 2
  ]
  edge [
    source 19
    target 1059
    kind "mentions"
  ]
  edge [
    source 19
    target 1060
    kind "relation"
    relation "belongs to a group of"
    weight 1
  ]
  edge [
    source 19
    target 1061
    kind "mentions"
  ]
  edge [
    source 19
    target 1062
    kind "relation"
    relation "states that without"
    weight 1
  ]
  edge [
    source 19
    target 1066
    kind "mentions"
  ]
  edge [
    source 19
    target 1068
    kind "relation"
    relation "refuses to allow"
    weight 1
  ]
  edge [
    source 19
    target 1069
    kind "mentions"
  ]
  edge [
    source 19
    target 679
    kind "relation"
    relation "agrees to raise | considered | places a bet of | had only"
    weight 4
  ]
  edge [
    source 19
    target 1071
    kind "relation"
    relation "promises to raise"
    weight 1
  ]
  edge [
    source 19
    target 1072
    kind "mentions"
  ]
  edge [
    source 19
    target 1074
    kind "mentions"
  ]
  edge [
    source 19
    target 1080
    kind "relation"
    relation "is horrified by"
    weight 1
  ]
  edge [
    source 19
    target 1092
    kind "relation"
    relation "treats georgiana as"
    weight 1
  ]
  edge [
    source 19
    target 1093
    kind "relation"
    relation "trusts"
    weight 1
  ]
  edge [
    source 19
    target 448
    kind "relation"
    relation "will try to find words in the morning to express"
    weight 1
  ]
  edge [
    source 19
    target 1095
    kind "mentions"
  ]
  edge [
    source 19
    target 1098
    kind "mentions"
  ]
  edge [
    source 19
    target 1109
    kind "mentions"
  ]
  edge [
    source 19
    target 1110
    kind "relation"
    relation "sinks into a chair and clutches"
    weight 1
  ]
  edge [
    source 19
    target 1111
    kind "mentions"
  ]
  edge [
    source 19
    target 1114
    kind "mentions"
  ]
  edge [
    source 19
    target 1115
    kind "relation"
    relation "placed the bank-notes on"
    weight 1
  ]
  edge [
    source 19
    target 1116
    kind "relation"
    relation "intended to send the bank-notes to"
    weight 1
  ]
  edge [
    source 19
    target 761
    kind "relation"
    relation "counted the bank-notes and found they totaled"
    weight 1
  ]
  edge [
    source 19
    target 1117
    kind "mentions"
  ]
  edge [
    source 19
    target 1124
    kind "relation"
    relation "feels threatened by"
    weight 1
  ]
  edge [
    source 19
    target 725
    kind "relation"
    relation "has sporting tendencies"
    weight 1
  ]
  edge [
    source 19
    target 1122
    kind "relation"
    relation "saw only | is the principal creditor of"
    weight 2
  ]
  edge [
    source 19
    target 1127
    kind "mentions"
  ]
  edge [
    source 19
    target 1131
    kind "mentions"
  ]
  edge [
    source 19
    target 1136
    kind "relation"
    relation "called blore | called"
    weight 2
  ]
  edge [
    source 19
    target 1137
    kind "mentions"
  ]
  edge [
    source 19
    target 1083
    kind "relation"
    relation "admits to being susceptible to"
    weight 1
  ]
  edge [
    source 19
    target 1139
    kind "mentions"
  ]
  edge [
    source 19
    target 1142
    kind "relation"
    relation "is tempted by"
    weight 1
  ]
  edge [
    source 19
    target 1144
    kind "relation"
    relation "will not give"
    weight 2
  ]
  edge [
    source 19
    target 1146
    kind "relation"
    relation "remains"
    weight 2
  ]
  edge [
    source 19
    target 1149
    kind "relation"
    relation "remains"
    weight 2
  ]
  edge [
    source 19
    target 1150
    kind "mentions"
  ]
  edge [
    source 19
    target 1153
    kind "mentions"
  ]
  edge [
    source 19
    target 1154
    kind "relation"
    relation "wishes | leaves | tries to recall"
    weight 3
  ]
  edge [
    source 19
    target 1161
    kind "mentions"
  ]
  edge [
    source 19
    target 1168
    kind "relation"
    relation "is upset"
    weight 1
  ]
  edge [
    source 19
    target 1169
    kind "relation"
    relation "fears"
    weight 1
  ]
  edge [
    source 19
    target 1170
    kind "relation"
    relation "decides not to dwell on"
    weight 1
  ]
  edge [
    source 19
    target 1171
    kind "relation"
    relation "hears"
    weight 1
  ]
  edge [
    source 19
    target 1172
    kind "relation"
    relation "compares"
    weight 1
  ]
  edge [
    source 19
    target 1165
    kind "relation"
    relation "reads | takes up"
    weight 2
  ]
  edge [
    source 19
    target 1173
    kind "relation"
    relation "realizes"
    weight 1
  ]
  edge [
    source 19
    target 1175
    kind "mentions"
  ]
  edge [
    source 19
    target 1167
    kind "relation"
    relation "believes it would be humane to administer | removed"
    weight 2
  ]
  edge [
    source 19
    target 1178
    kind "mentions"
  ]
  edge [
    source 19
    target 1180
    kind "mentions"
  ]
  edge [
    source 19
    target 1181
    kind "relation"
    relation "places on table"
    weight 1
  ]
  edge [
    source 19
    target 1182
    kind "relation"
    relation "has not approached a horse medically since"
    weight 1
  ]
  edge [
    source 19
    target 1183
    kind "relation"
    relation "is concerned that the bolus will give an unfair advantage to"
    weight 1
  ]
  edge [
    source 19
    target 1184
    kind "relation"
    relation "does not desire"
    weight 1
  ]
  edge [
    source 19
    target 1185
    kind "mentions"
  ]
  edge [
    source 19
    target 1186
    kind "relation"
    relation "takes from blore | places on table"
    weight 2
  ]
  edge [
    source 19
    target 1192
    kind "mentions"
  ]
  edge [
    source 19
    target 1163
    kind "relation"
    relation "hears"
    weight 1
  ]
  edge [
    source 19
    target 1194
    kind "relation"
    relation "mixes"
    weight 1
  ]
  edge [
    source 19
    target 1188
    kind "relation"
    relation "stirs with"
    weight 1
  ]
  edge [
    source 19
    target 1196
    kind "mentions"
  ]
  edge [
    source 19
    target 1210
    kind "relation"
    relation "is walking in"
    weight 2
  ]
  edge [
    source 19
    target 1211
    kind "relation"
    relation "sees"
    weight 2
  ]
  edge [
    source 19
    target 1212
    kind "relation"
    relation "sees"
    weight 2
  ]
  edge [
    source 19
    target 1213
    kind "relation"
    relation "feels that his life is made up of"
    weight 2
  ]
  edge [
    source 19
    target 1063
    kind "relation"
    relation "mentions | says five hundred pounds will go to"
    weight 3
  ]
  edge [
    source 19
    target 1214
    kind "mentions"
  ]
  edge [
    source 19
    target 1216
    kind "relation"
    relation "avoids shops where he owes"
    weight 1
  ]
  edge [
    source 19
    target 1218
    kind "mentions"
  ]
  edge [
    source 19
    target 1205
    kind "relation"
    relation "asks where"
    weight 1
  ]
  edge [
    source 19
    target 1223
    kind "mentions"
  ]
  edge [
    source 19
    target 1240
    kind "relation"
    relation "orders"
    weight 2
  ]
  edge [
    source 19
    target 1241
    kind "relation"
    relation "orders"
    weight 2
  ]
  edge [
    source 19
    target 1244
    kind "mentions"
  ]
  edge [
    source 19
    target 1246
    kind "mentions"
  ]
  edge [
    source 19
    target 1235
    kind "relation"
    relation "will retire from"
    weight 1
  ]
  edge [
    source 19
    target 1247
    kind "relation"
    relation "wants to reclaim"
    weight 1
  ]
  edge [
    source 19
    target 1248
    kind "mentions"
  ]
  edge [
    source 19
    target 1250
    kind "relation"
    relation "does not feel resignation about"
    weight 1
  ]
  edge [
    source 19
    target 546
    kind "relation"
    relation "is small"
    weight 1
  ]
  edge [
    source 19
    target 1251
    kind "mentions"
  ]
  edge [
    source 19
    target 926
    kind "relation"
    relation "is sure mardon will lend | completely envelops"
    weight 2
  ]
  edge [
    source 19
    target 1252
    kind "relation"
    relation "is sure mardon will lend | almost conceals"
    weight 2
  ]
  edge [
    source 19
    target 1253
    kind "mentions"
  ]
  edge [
    source 19
    target 1257
    kind "relation"
    relation "feels a dreadful sinking at the heart"
    weight 1
  ]
  edge [
    source 19
    target 1382
    kind "mentions"
  ]
  edge [
    source 19
    target 1426
    kind "mentions"
  ]
  edge [
    source 19
    target 1413
    kind "relation"
    relation "asks how | is asking about | cries out at | reappears | responds | cooked for | acknowledges culinary skill of | asks if | pulls door open to let out | greets | calls | says his duty is to inform | gives to | waves away | says he has done with | insists that he is not done with | urges him not to stint himself | asks if her cooking carries him back | turns and faces | tells hannah not to prevaricate | claims that she and her whistle and nick the fire-brigade horse will bring | hears them leaving | sees that the dean is gone | says the dean can whistle himself blue | expresses gratitude to | kisses hands of"
    weight 26
  ]
  edge [
    source 19
    target 1433
    kind "mentions"
  ]
  edge [
    source 19
    target 1528
    kind "mentions"
  ]
  edge [
    source 19
    target 1540
    kind "mentions"
  ]
  edge [
    source 19
    target 1545
    kind "relation"
    relation "appears at | appears and disappears"
    weight 2
  ]
  edge [
    source 19
    target 1546
    kind "relation"
    relation "has head still in"
    weight 1
  ]
  edge [
    source 19
    target 1553
    kind "mentions"
  ]
  edge [
    source 19
    target 1555
    kind "relation"
    relation "is addressed as | recognizes"
    weight 2
  ]
  edge [
    source 19
    target 1561
    kind "relation"
    relation "says he is the victim of"
    weight 1
  ]
  edge [
    source 19
    target 1560
    kind "relation"
    relation "has placed himself in | says he fears"
    weight 2
  ]
  edge [
    source 19
    target 1572
    kind "mentions"
  ]
  edge [
    source 19
    target 1579
    kind "relation"
    relation "is sorely tried by"
    weight 1
  ]
  edge [
    source 19
    target 1582
    kind "relation"
    relation "would resent"
    weight 1
  ]
  edge [
    source 19
    target 1584
    kind "relation"
    relation "enters room after"
    weight 1
  ]
  edge [
    source 19
    target 1475
    kind "relation"
    relation "calls"
    weight 1
  ]
  edge [
    source 19
    target 1587
    kind "mentions"
  ]
  edge [
    source 19
    target 1593
    kind "relation"
    relation "claims to be"
    weight 1
  ]
  edge [
    source 19
    target 1589
    kind "relation"
    relation "feels that admitting"
    weight 1
  ]
  edge [
    source 19
    target 1590
    kind "relation"
    relation "believes would impair | experiences loss of"
    weight 2
  ]
  edge [
    source 19
    target 1594
    kind "mentions"
  ]
  edge [
    source 19
    target 1595
    kind "relation"
    relation "would return to"
    weight 1
  ]
  edge [
    source 19
    target 1596
    kind "relation"
    relation "would return to"
    weight 1
  ]
  edge [
    source 19
    target 1597
    kind "relation"
    relation "would return to"
    weight 1
  ]
  edge [
    source 19
    target 1602
    kind "mentions"
  ]
  edge [
    source 19
    target 1388
    kind "relation"
    relation "has his name blazoned on"
    weight 1
  ]
  edge [
    source 19
    target 1605
    kind "mentions"
  ]
  edge [
    source 19
    target 1611
    kind "relation"
    relation "has one great buoyant hope of | confirms that his story is the sole remaining chance of"
    weight 2
  ]
  edge [
    source 19
    target 1606
    kind "relation"
    relation "plans to have a word with"
    weight 1
  ]
  edge [
    source 19
    target 1609
    kind "relation"
    relation "wants hannah and the durnstone superintendent to be the sole keepers of"
    weight 1
  ]
  edge [
    source 19
    target 1613
    kind "mentions"
  ]
  edge [
    source 19
    target 1623
    kind "mentions"
  ]
  edge [
    source 19
    target 1631
    kind "relation"
    relation "is aghast at"
    weight 1
  ]
  edge [
    source 19
    target 1534
    kind "relation"
    relation "receives a key that unlocks | is in"
    weight 2
  ]
  edge [
    source 19
    target 1541
    kind "relation"
    relation "exclaims"
    weight 1
  ]
  edge [
    source 19
    target 1651
    kind "mentions"
  ]
  edge [
    source 19
    target 1659
    kind "relation"
    relation "expresses horror at"
    weight 1
  ]
  edge [
    source 19
    target 1655
    kind "relation"
    relation "claims he has no"
    weight 1
  ]
  edge [
    source 19
    target 1660
    kind "relation"
    relation "realizes the enormity of"
    weight 1
  ]
  edge [
    source 19
    target 1662
    kind "mentions"
  ]
  edge [
    source 19
    target 71
    kind "relation"
    relation "calls"
    weight 1
  ]
  edge [
    source 19
    target 1668
    kind "relation"
    relation "clutches"
    weight 1
  ]
  edge [
    source 19
    target 1676
    kind "relation"
    relation "says this teaches him"
    weight 1
  ]
  edge [
    source 19
    target 1492
    kind "relation"
    relation "sits down and begins carving"
    weight 1
  ]
  edge [
    source 19
    target 1678
    kind "relation"
    relation "says if every mouthful could carry him back one hour"
    weight 1
  ]
  edge [
    source 19
    target 1681
    kind "mentions"
  ]
  edge [
    source 19
    target 1417
    kind "relation"
    relation "asks noah if he objects to kindnesses from his wife | advances savagely toward | restrains himself and faces | brings with him | is told not to judge | says he is ready | takes by the arm and leads out | put kitty in the cart | left old nick at home | confronts | claims to have taken"
    weight 11
  ]
  edge [
    source 19
    target 1693
    kind "mentions"
  ]
  edge [
    source 19
    target 1705
    kind "relation"
    relation "expresses trust that"
    weight 1
  ]
  edge [
    source 19
    target 1711
    kind "mentions"
  ]
  edge [
    source 19
    target 1717
    kind "relation"
    relation "asks noah for assurance about"
    weight 1
  ]
  edge [
    source 19
    target 1576
    kind "relation"
    relation "disappears through"
    weight 1
  ]
  edge [
    source 19
    target 1740
    kind "mentions"
  ]
  edge [
    source 19
    target 1802
    kind "mentions"
  ]
  edge [
    source 19
    target 1805
    kind "mentions"
  ]
  edge [
    source 19
    target 1806
    kind "relation"
    relation "administered"
    weight 1
  ]
  edge [
    source 19
    target 1803
    kind "relation"
    relation "is the owner of"
    weight 1
  ]
  edge [
    source 19
    target 1808
    kind "mentions"
  ]
  edge [
    source 19
    target 1811
    kind "relation"
    relation "confirmed"
    weight 1
  ]
  edge [
    source 19
    target 1833
    kind "mentions"
  ]
  edge [
    source 19
    target 1834
    kind "relation"
    relation "has"
    weight 1
  ]
  edge [
    source 19
    target 1835
    kind "relation"
    relation "has"
    weight 2
  ]
  edge [
    source 19
    target 1837
    kind "relation"
    relation "wishes to attest that"
    weight 1
  ]
  edge [
    source 19
    target 1844
    kind "relation"
    relation "requests that"
    weight 1
  ]
  edge [
    source 19
    target 1845
    kind "relation"
    relation "requests that"
    weight 1
  ]
  edge [
    source 19
    target 1846
    kind "relation"
    relation "requests that"
    weight 1
  ]
  edge [
    source 19
    target 1847
    kind "relation"
    relation "reserves confession of weaknesses for"
    weight 1
  ]
  edge [
    source 19
    target 1848
    kind "mentions"
  ]
  edge [
    source 19
    target 1851
    kind "mentions"
  ]
  edge [
    source 19
    target 1887
    kind "mentions"
  ]
  edge [
    source 19
    target 1891
    kind "mentions"
  ]
  edge [
    source 19
    target 1899
    kind "mentions"
  ]
  edge [
    source 19
    target 1904
    kind "relation"
    relation "carry"
    weight 1
  ]
  edge [
    source 19
    target 1906
    kind "mentions"
  ]
  edge [
    source 19
    target 56
    kind "relation"
    relation "agrees to put down"
    weight 1
  ]
  edge [
    source 19
    target 1911
    kind "mentions"
  ]
  edge [
    source 19
    target 1914
    kind "relation"
    relation "asks"
    weight 1
  ]
  edge [
    source 19
    target 1917
    kind "mentions"
  ]
  edge [
    source 19
    target 1921
    kind "relation"
    relation "feels"
    weight 1
  ]
  edge [
    source 19
    target 1923
    kind "relation"
    relation "describes feeling as if"
    weight 1
  ]
  edge [
    source 19
    target 1926
    kind "mentions"
  ]
  edge [
    source 19
    target 1955
    kind "mentions"
  ]
  edge [
    source 19
    target 1197
    kind "relation"
    relation "seized | dragged | embraced"
    weight 3
  ]
  edge [
    source 19
    target 1960
    kind "mentions"
  ]
  edge [
    source 19
    target 1962
    kind "relation"
    relation "believes every abused institution has"
    weight 1
  ]
  edge [
    source 19
    target 423
    kind "relation"
    relation "questions the source of"
    weight 1
  ]
  edge [
    source 19
    target 1963
    kind "relation"
    relation "does not want to ask"
    weight 1
  ]
  edge [
    source 19
    target 1964
    kind "relation"
    relation "does not want to ask"
    weight 1
  ]
  edge [
    source 19
    target 1965
    kind "mentions"
  ]
  edge [
    source 19
    target 1968
    kind "mentions"
  ]
  edge [
    source 19
    target 1970
    kind "mentions"
  ]
  edge [
    source 19
    target 1972
    kind "relation"
    relation "urges to remember with gratitude"
    weight 1
  ]
  edge [
    source 19
    target 2002
    kind "mentions"
  ]
  edge [
    source 19
    target 157
    kind "relation"
    relation "is a debtor to | has a document about"
    weight 2
  ]
  edge [
    source 19
    target 2004
    kind "relation"
    relation "has a debt of"
    weight 1
  ]
  edge [
    source 19
    target 2007
    kind "relation"
    relation "reads"
    weight 1
  ]
  edge [
    source 19
    target 2008
    kind "mentions"
  ]
  edge [
    source 19
    target 2013
    kind "mentions"
  ]
  edge [
    source 19
    target 2017
    kind "relation"
    relation "reads"
    weight 1
  ]
  edge [
    source 19
    target 760
    kind "relation"
    relation "states the moral is inculcated by | states the total is"
    weight 2
  ]
  edge [
    source 19
    target 2014
    kind "relation"
    relation "mentions | claims he was present at | claims he knows about"
    weight 3
  ]
  edge [
    source 19
    target 161
    kind "relation"
    relation "asks which daughter was a person during"
    weight 2
  ]
  edge [
    source 19
    target 2015
    kind "relation"
    relation "says salome was a"
    weight 2
  ]
  edge [
    source 19
    target 2018
    kind "mentions"
  ]
  edge [
    source 19
    target 2020
    kind "mentions"
  ]
  edge [
    source 19
    target 209
    kind "relation"
    relation "insists they cannot pay | hands sheba"
    weight 2
  ]
  edge [
    source 19
    target 2031
    kind "relation"
    relation "recoils at"
    weight 1
  ]
  edge [
    source 19
    target 2026
    kind "relation"
    relation "accuses both girls of being drawn into"
    weight 1
  ]
  edge [
    source 19
    target 2032
    kind "relation"
    relation "questions if there is any"
    weight 1
  ]
  edge [
    source 19
    target 2033
    kind "relation"
    relation "tells sheba to never let"
    weight 1
  ]
  edge [
    source 19
    target 2034
    kind "relation"
    relation "announces the scandalous costumes will be raffled for"
    weight 1
  ]
  edge [
    source 19
    target 1376
    kind "relation"
    relation "declares confidence is gone between"
    weight 1
  ]
  edge [
    source 19
    target 2035
    kind "relation"
    relation "chastises both girls by withholding"
    weight 1
  ]
  edge [
    source 19
    target 2040
    kind "mentions"
  ]
  edge [
    source 19
    target 2041
    kind "relation"
    relation "claims georgiana enabled"
    weight 1
  ]
  edge [
    source 19
    target 2043
    kind "mentions"
  ]
  edge [
    source 19
    target 2044
    kind "mentions"
  ]
  edge [
    source 19
    target 2046
    kind "mentions"
  ]
  edge [
    source 19
    target 2048
    kind "mentions"
  ]
  edge [
    source 19
    target 2056
    kind "relation"
    relation "claims the preparation contains nothing he would not administer to"
    weight 1
  ]
  edge [
    source 19
    target 2060
    kind "relation"
    relation "claims the analysis resulted from"
    weight 1
  ]
  edge [
    source 19
    target 964
    kind "relation"
    relation "will prove that in the deanery stables the laws of hospitality have never been transgressed"
    weight 1
  ]
  edge [
    source 19
    target 2051
    kind "relation"
    relation "asks for"
    weight 1
  ]
  edge [
    source 19
    target 2063
    kind "relation"
    relation "calls the remedy"
    weight 1
  ]
  edge [
    source 19
    target 2067
    kind "mentions"
  ]
  edge [
    source 19
    target 2071
    kind "relation"
    relation "is suffering from"
    weight 1
  ]
  edge [
    source 19
    target 298
    kind "relation"
    relation "took a bolus and opened his mouth to demonstrate"
    weight 1
  ]
  edge [
    source 19
    target 2073
    kind "relation"
    relation "called blore"
    weight 1
  ]
  edge [
    source 19
    target 2077
    kind "mentions"
  ]
  edge [
    source 19
    target 2081
    kind "relation"
    relation "calls blore's action"
    weight 1
  ]
  edge [
    source 19
    target 2080
    kind "relation"
    relation "insists on saving blore from"
    weight 1
  ]
  edge [
    source 19
    target 2085
    kind "relation"
    relation "orders blore to remain in service as"
    weight 1
  ]
  edge [
    source 19
    target 2086
    kind "mentions"
  ]
  edge [
    source 19
    target 2090
    kind "relation"
    relation "orders salome to go to"
    weight 1
  ]
  edge [
    source 19
    target 2091
    kind "relation"
    relation "says he is"
    weight 1
  ]
  edge [
    source 19
    target 2093
    kind "relation"
    relation "allows them to declare if they have lost moral rectitude"
    weight 1
  ]
  edge [
    source 19
    target 2096
    kind "relation"
    relation "staggers back"
    weight 1
  ]
  edge [
    source 19
    target 2098
    kind "mentions"
  ]
  edge [
    source 19
    target 427
    kind "relation"
    relation "says they are still young"
    weight 1
  ]
  edge [
    source 19
    target 2103
    kind "relation"
    relation "declares he is at home"
    weight 1
  ]
  edge [
    source 19
    target 2115
    kind "mentions"
  ]
  edge [
    source 19
    target 2116
    kind "relation"
    relation "appears outside the window with"
    weight 1
  ]
  edge [
    source 19
    target 70
    kind "relation"
    relation "invites"
    weight 1
  ]
  edge [
    source 19
    target 23
    kind "relation"
    relation "recognizes the voice as"
    weight 1
  ]
  edge [
    source 19
    target 2118
    kind "mentions"
  ]
  edge [
    source 19
    target 2120
    kind "mentions"
  ]
  edge [
    source 19
    target 2122
    kind "mentions"
  ]
  edge [
    source 19
    target 2125
    kind "mentions"
  ]
  edge [
    source 19
    target 1818
    kind "relation"
    relation "withdrew charge against | has innocent intentions"
    weight 2
  ]
  edge [
    source 19
    target 2126
    kind "mentions"
  ]
  edge [
    source 19
    target 2130
    kind "relation"
    relation "invites"
    weight 1
  ]
  edge [
    source 19
    target 2131
    kind "relation"
    relation "offers"
    weight 1
  ]
  edge [
    source 19
    target 2133
    kind "mentions"
  ]
  edge [
    source 19
    target 2134
    kind "relation"
    relation "loses"
    weight 1
  ]
  edge [
    source 19
    target 2140
    kind "mentions"
  ]
  edge [
    source 19
    target 2088
    kind "relation"
    relation "has been riding hardest"
    weight 1
  ]
  edge [
    source 19
    target 2143
    kind "mentions"
  ]
  edge [
    source 19
    target 2145
    kind "relation"
    relation "admits there is no harm in"
    weight 1
  ]
  edge [
    source 19
    target 2146
    kind "mentions"
  ]
  edge [
    source 19
    target 2166
    kind "mentions"
  ]
  edge [
    source 22
    target 23
    kind "relation"
    relation "suggested the character of | proposed the character of"
    weight 2
  ]
  edge [
    source 22
    target 31
    kind "mentions"
  ]
  edge [
    source 23
    target 31
    kind "mentions"
  ]
  edge [
    source 23
    target 48
    kind "mentions"
  ]
  edge [
    source 23
    target 55
    kind "relation"
    relation "is portrayed by"
    weight 1
  ]
  edge [
    source 23
    target 1507
    kind "mentions"
  ]
  edge [
    source 23
    target 1413
    kind "relation"
    relation "enters the scene while blore is bending over hannah | has been married to | has six years and ten months of marital duty with | rushes in at the window with"
    weight 4
  ]
  edge [
    source 23
    target 1521
    kind "relation"
    relation "is described as"
    weight 1
  ]
  edge [
    source 23
    target 1522
    kind "relation"
    relation "is dressed as"
    weight 1
  ]
  edge [
    source 23
    target 54
    kind "relation"
    relation "says a friend of hers is a friend of"
    weight 1
  ]
  edge [
    source 23
    target 1524
    kind "relation"
    relation "comments that hannah is getting"
    weight 1
  ]
  edge [
    source 23
    target 1526
    kind "relation"
    relation "announces he is taking the liberty of"
    weight 1
  ]
  edge [
    source 23
    target 1623
    kind "mentions"
  ]
  edge [
    source 23
    target 1662
    kind "mentions"
  ]
  edge [
    source 23
    target 705
    kind "relation"
    relation "climbs in through"
    weight 1
  ]
  edge [
    source 23
    target 237
    kind "relation"
    relation "glares around the room"
    weight 1
  ]
  edge [
    source 23
    target 1679
    kind "relation"
    relation "says under his breath"
    weight 1
  ]
  edge [
    source 23
    target 2104
    kind "mentions"
  ]
  edge [
    source 23
    target 2110
    kind "relation"
    relation "glares around the room and asks"
    weight 1
  ]
  edge [
    source 23
    target 2111
    kind "relation"
    relation "claims a man was rescued from"
    weight 1
  ]
  edge [
    source 23
    target 65
    kind "relation"
    relation "states the villain was traced back to"
    weight 1
  ]
  edge [
    source 23
    target 2112
    kind "relation"
    relation "says the man was an unknown lover of"
    weight 1
  ]
  edge [
    source 23
    target 2115
    kind "mentions"
  ]
  edge [
    source 31
    target 32
    kind "mentions"
  ]
  edge [
    source 31
    target 2218
    kind "summarizes"
  ]
  edge [
    source 33
    target 34
    kind "from_chunk"
  ]
  edge [
    source 33
    target 42
    kind "from_chunk"
  ]
  edge [
    source 33
    target 48
    kind "from_chunk"
  ]
  edge [
    source 33
    target 72
    kind "from_chunk"
  ]
  edge [
    source 34
    target 35
    kind "mentions"
  ]
  edge [
    source 34
    target 36
    kind "mentions"
  ]
  edge [
    source 34
    target 37
    kind "mentions"
  ]
  edge [
    source 34
    target 38
    kind "mentions"
  ]
  edge [
    source 34
    target 39
    kind "mentions"
  ]
  edge [
    source 34
    target 40
    kind "mentions"
  ]
  edge [
    source 34
    target 41
    kind "mentions"
  ]
  edge [
    source 34
    target 2214
    kind "summarizes"
  ]
  edge [
    source 35
    target 42
    kind "mentions"
  ]
  edge [
    source 35
    target 43
    kind "relation"
    relation "had lessees and managers"
    weight 1
  ]
  edge [
    source 35
    target 44
    kind "relation"
    relation "had lessees and managers"
    weight 1
  ]
  edge [
    source 42
    target 43
    kind "mentions"
  ]
  edge [
    source 42
    target 44
    kind "mentions"
  ]
  edge [
    source 42
    target 45
    kind "mentions"
  ]
  edge [
    source 42
    target 46
    kind "mentions"
  ]
  edge [
    source 42
    target 47
    kind "mentions"
  ]
  edge [
    source 42
    target 2214
    kind "summarizes"
  ]
  edge [
    source 43
    target 48
    kind "mentions"
  ]
  edge [
    source 43
    target 49
    kind "relation"
    relation "is portrayed by"
    weight 1
  ]
  edge [
    source 44
    target 48
    kind "mentions"
  ]
  edge [
    source 44
    target 54
    kind "relation"
    relation "is portrayed by"
    weight 1
  ]
  edge [
    source 48
    target 49
    kind "mentions"
  ]
  edge [
    source 48
    target 50
    kind "mentions"
  ]
  edge [
    source 48
    target 51
    kind "mentions"
  ]
  edge [
    source 48
    target 52
    kind "mentions"
  ]
  edge [
    source 48
    target 53
    kind "mentions"
  ]
  edge [
    source 48
    target 54
    kind "mentions"
  ]
  edge [
    source 48
    target 55
    kind "mentions"
  ]
  edge [
    source 48
    target 56
    kind "mentions"
  ]
  edge [
    source 48
    target 57
    kind "mentions"
  ]
  edge [
    source 48
    target 58
    kind "mentions"
  ]
  edge [
    source 48
    target 59
    kind "mentions"
  ]
  edge [
    source 48
    target 60
    kind "mentions"
  ]
  edge [
    source 48
    target 61
    kind "mentions"
  ]
  edge [
    source 48
    target 62
    kind "mentions"
  ]
  edge [
    source 48
    target 63
    kind "mentions"
  ]
  edge [
    source 48
    target 64
    kind "mentions"
  ]
  edge [
    source 48
    target 65
    kind "mentions"
  ]
  edge [
    source 48
    target 66
    kind "mentions"
  ]
  edge [
    source 48
    target 67
    kind "mentions"
  ]
  edge [
    source 48
    target 68
    kind "mentions"
  ]
  edge [
    source 48
    target 69
    kind "mentions"
  ]
  edge [
    source 48
    target 70
    kind "mentions"
  ]
  edge [
    source 48
    target 71
    kind "mentions"
  ]
  edge [
    source 48
    target 2215
    kind "summarizes"
  ]
  edge [
    source 50
    target 69
    kind "relation"
    relation "is portrayed by"
    weight 1
  ]
  edge [
    source 51
    target 52
    kind "relation"
    relation "is quartered at"
    weight 1
  ]
  edge [
    source 51
    target 134
    kind "mentions"
  ]
  edge [
    source 51
    target 154
    kind "mentions"
  ]
  edge [
    source 51
    target 165
    kind "relation"
    relation "promised to get"
    weight 1
  ]
  edge [
    source 51
    target 167
    kind "relation"
    relation "requested to pay for"
    weight 1
  ]
  edge [
    source 51
    target 169
    kind "relation"
    relation "agreed to yield to"
    weight 1
  ]
  edge [
    source 51
    target 170
    kind "relation"
    relation "sent"
    weight 1
  ]
  edge [
    source 51
    target 173
    kind "mentions"
  ]
  edge [
    source 51
    target 219
    kind "mentions"
  ]
  edge [
    source 51
    target 60
    kind "relation"
    relation "asks if he means | asks if they mean | says strain on nerves is bad for | offers | meets | gasps upon seeing | responds with concern | opens the window for | sinks into a chair | apologizes for informal entry | refuses to let pass unless pushed by | is sitting with"
    weight 13
  ]
  edge [
    source 51
    target 241
    kind "mentions"
  ]
  edge [
    source 51
    target 244
    kind "mentions"
  ]
  edge [
    source 51
    target 54
    kind "relation"
    relation "enters with"
    weight 1
  ]
  edge [
    source 51
    target 248
    kind "relation"
    relation "is dressed in"
    weight 1
  ]
  edge [
    source 51
    target 251
    kind "mentions"
  ]
  edge [
    source 51
    target 252
    kind "relation"
    relation "has"
    weight 1
  ]
  edge [
    source 51
    target 253
    kind "relation"
    relation "has"
    weight 1
  ]
  edge [
    source 51
    target 254
    kind "relation"
    relation "has"
    weight 1
  ]
  edge [
    source 51
    target 255
    kind "relation"
    relation "is"
    weight 1
  ]
  edge [
    source 51
    target 256
    kind "relation"
    relation "is"
    weight 1
  ]
  edge [
    source 51
    target 257
    kind "relation"
    relation "is"
    weight 1
  ]
  edge [
    source 51
    target 283
    kind "mentions"
  ]
  edge [
    source 51
    target 303
    kind "mentions"
  ]
  edge [
    source 51
    target 265
    kind "relation"
    relation "says his liver is frightfully injurious | acknowledges he is excited and at his best"
    weight 2
  ]
  edge [
    source 51
    target 329
    kind "mentions"
  ]
  edge [
    source 51
    target 349
    kind "mentions"
  ]
  edge [
    source 51
    target 66
    kind "relation"
    relation "has ridden from"
    weight 1
  ]
  edge [
    source 51
    target 800
    kind "mentions"
  ]
  edge [
    source 51
    target 578
    kind "relation"
    relation "is not a conversational cracker"
    weight 1
  ]
  edge [
    source 51
    target 833
    kind "mentions"
  ]
  edge [
    source 51
    target 394
    kind "relation"
    relation "enters"
    weight 1
  ]
  edge [
    source 51
    target 835
    kind "mentions"
  ]
  edge [
    source 51
    target 836
    kind "relation"
    relation "asks if"
    weight 1
  ]
  edge [
    source 51
    target 838
    kind "mentions"
  ]
  edge [
    source 51
    target 839
    kind "relation"
    relation "experiences"
    weight 1
  ]
  edge [
    source 51
    target 840
    kind "mentions"
  ]
  edge [
    source 51
    target 842
    kind "relation"
    relation "would pack"
    weight 1
  ]
  edge [
    source 51
    target 843
    kind "relation"
    relation "would go to"
    weight 1
  ]
  edge [
    source 51
    target 844
    kind "mentions"
  ]
  edge [
    source 51
    target 846
    kind "relation"
    relation "will fetch"
    weight 1
  ]
  edge [
    source 51
    target 850
    kind "mentions"
  ]
  edge [
    source 51
    target 851
    kind "relation"
    relation "sings"
    weight 1
  ]
  edge [
    source 51
    target 111
    kind "relation"
    relation "sings about"
    weight 1
  ]
  edge [
    source 51
    target 852
    kind "relation"
    relation "sings to"
    weight 1
  ]
  edge [
    source 51
    target 870
    kind "mentions"
  ]
  edge [
    source 51
    target 107
    kind "relation"
    relation "responds with concern | asks mr. darbey to spare the scene"
    weight 2
  ]
  edge [
    source 51
    target 1858
    kind "mentions"
  ]
  edge [
    source 51
    target 1861
    kind "relation"
    relation "looks extremely weak | appears weak"
    weight 2
  ]
  edge [
    source 51
    target 70
    kind "relation"
    relation "supports | enters with | stands by"
    weight 3
  ]
  edge [
    source 51
    target 1864
    kind "mentions"
  ]
  edge [
    source 51
    target 1866
    kind "mentions"
  ]
  edge [
    source 51
    target 1869
    kind "mentions"
  ]
  edge [
    source 51
    target 1867
    kind "relation"
    relation "performed a searching examination on | stated that three weeks or a month at the seaside would be imperative"
    weight 2
  ]
  edge [
    source 51
    target 1875
    kind "mentions"
  ]
  edge [
    source 51
    target 1877
    kind "relation"
    relation "offers that if accepted, his merry laugh will continue in the mess room"
    weight 1
  ]
  edge [
    source 51
    target 1878
    kind "relation"
    relation "offers that if rejected, his collection of vocal music will be sold"
    weight 1
  ]
  edge [
    source 51
    target 1879
    kind "relation"
    relation "produces a doctor's certificate to prove | reads the certificate with salome"
    weight 2
  ]
  edge [
    source 51
    target 1996
    kind "mentions"
  ]
  edge [
    source 51
    target 2077
    kind "mentions"
  ]
  edge [
    source 51
    target 2086
    kind "mentions"
  ]
  edge [
    source 51
    target 2115
    kind "mentions"
  ]
  edge [
    source 54
    target 219
    kind "mentions"
  ]
  edge [
    source 54
    target 237
    kind "relation"
    relation "enters"
    weight 3
  ]
  edge [
    source 54
    target 238
    kind "relation"
    relation "says the two soldier gentlemen have just ridden up"
    weight 2
  ]
  edge [
    source 54
    target 241
    kind "mentions"
  ]
  edge [
    source 54
    target 244
    kind "mentions"
  ]
  edge [
    source 54
    target 107
    kind "relation"
    relation "offers to show them in | laughs sweetly at | shakes fingers at | is glared at by"
    weight 4
  ]
  edge [
    source 54
    target 249
    kind "relation"
    relation "says behind their backs"
    weight 1
  ]
  edge [
    source 54
    target 70
    kind "relation"
    relation "enters with"
    weight 1
  ]
  edge [
    source 54
    target 251
    kind "mentions"
  ]
  edge [
    source 54
    target 263
    kind "mentions"
  ]
  edge [
    source 54
    target 272
    kind "relation"
    relation "confirms"
    weight 1
  ]
  edge [
    source 54
    target 273
    kind "relation"
    relation "confirms"
    weight 1
  ]
  edge [
    source 54
    target 276
    kind "relation"
    relation "says"
    weight 1
  ]
  edge [
    source 54
    target 283
    kind "mentions"
  ]
  edge [
    source 54
    target 284
    kind "relation"
    relation "was told to show"
    weight 1
  ]
  edge [
    source 54
    target 60
    kind "relation"
    relation "expresses suppressed rage"
    weight 1
  ]
  edge [
    source 54
    target 298
    kind "relation"
    relation "says let 'em 'ang that on the 'atstand"
    weight 1
  ]
  edge [
    source 54
    target 318
    kind "mentions"
  ]
  edge [
    source 54
    target 191
    kind "relation"
    relation "goes out with"
    weight 1
  ]
  edge [
    source 54
    target 329
    kind "mentions"
  ]
  edge [
    source 54
    target 332
    kind "relation"
    relation "carries"
    weight 1
  ]
  edge [
    source 54
    target 333
    kind "relation"
    relation "carries"
    weight 1
  ]
  edge [
    source 54
    target 334
    kind "relation"
    relation "carries"
    weight 1
  ]
  edge [
    source 54
    target 482
    kind "mentions"
  ]
  edge [
    source 54
    target 493
    kind "relation"
    relation "brings"
    weight 1
  ]
  edge [
    source 54
    target 498
    kind "mentions"
  ]
  edge [
    source 54
    target 501
    kind "relation"
    relation "hears salome and sheba crying"
    weight 1
  ]
  edge [
    source 54
    target 502
    kind "relation"
    relation "suggests they should hang"
    weight 1
  ]
  edge [
    source 54
    target 504
    kind "mentions"
  ]
  edge [
    source 54
    target 65
    kind "relation"
    relation "prohibits servants from leaving"
    weight 1
  ]
  edge [
    source 54
    target 491
    kind "relation"
    relation "are the reason for the rule | did on his own account | did for kitchen | wishes to use this knowledge at"
    weight 4
  ]
  edge [
    source 54
    target 555
    kind "mentions"
  ]
  edge [
    source 54
    target 541
    kind "relation"
    relation "enters with"
    weight 1
  ]
  edge [
    source 54
    target 561
    kind "mentions"
  ]
  edge [
    source 54
    target 572
    kind "relation"
    relation "reports that"
    weight 1
  ]
  edge [
    source 54
    target 633
    kind "mentions"
  ]
  edge [
    source 54
    target 643
    kind "relation"
    relation "enters with"
    weight 1
  ]
  edge [
    source 54
    target 855
    kind "mentions"
  ]
  edge [
    source 54
    target 868
    kind "relation"
    relation "re-enters carrying"
    weight 1
  ]
  edge [
    source 54
    target 870
    kind "mentions"
  ]
  edge [
    source 54
    target 876
    kind "relation"
    relation "re-enters"
    weight 1
  ]
  edge [
    source 54
    target 871
    kind "relation"
    relation "carries"
    weight 1
  ]
  edge [
    source 54
    target 865
    kind "relation"
    relation "carries | hands"
    weight 2
  ]
  edge [
    source 54
    target 900
    kind "mentions"
  ]
  edge [
    source 54
    target 473
    kind "relation"
    relation "enters and cuts"
    weight 1
  ]
  edge [
    source 54
    target 860
    kind "relation"
    relation "causes music to stop"
    weight 1
  ]
  edge [
    source 54
    target 902
    kind "relation"
    relation "glare at | hush"
    weight 2
  ]
  edge [
    source 54
    target 904
    kind "mentions"
  ]
  edge [
    source 54
    target 921
    kind "mentions"
  ]
  edge [
    source 54
    target 930
    kind "relation"
    relation "announces"
    weight 2
  ]
  edge [
    source 54
    target 937
    kind "relation"
    relation "enters with"
    weight 1
  ]
  edge [
    source 54
    target 938
    kind "mentions"
  ]
  edge [
    source 54
    target 977
    kind "mentions"
  ]
  edge [
    source 54
    target 989
    kind "relation"
    relation "tells"
    weight 1
  ]
  edge [
    source 54
    target 1027
    kind "mentions"
  ]
  edge [
    source 54
    target 1034
    kind "mentions"
  ]
  edge [
    source 54
    target 66
    kind "relation"
    relation "reports that military personnel have been sent to"
    weight 1
  ]
  edge [
    source 54
    target 1044
    kind "mentions"
  ]
  edge [
    source 54
    target 578
    kind "relation"
    relation "instructs | suggests sending | says if wiser in the morning, send | recognized | describes"
    weight 6
  ]
  edge [
    source 54
    target 649
    kind "relation"
    relation "puts | says look at him | says blore is lively as a cricket | shook blore and asked if he did it"
    weight 4
  ]
  edge [
    source 54
    target 1074
    kind "mentions"
  ]
  edge [
    source 54
    target 1079
    kind "relation"
    relation "would be lost on"
    weight 1
  ]
  edge [
    source 54
    target 1095
    kind "mentions"
  ]
  edge [
    source 54
    target 1096
    kind "relation"
    relation "was at home in"
    weight 1
  ]
  edge [
    source 54
    target 475
    kind "relation"
    relation "was present at | remembers that when an arrest was made in st. marvells, the prisoner was lodged only for the night"
    weight 2
  ]
  edge [
    source 54
    target 1098
    kind "mentions"
  ]
  edge [
    source 54
    target 1099
    kind "relation"
    relation "invested savings of"
    weight 1
  ]
  edge [
    source 54
    target 1100
    kind "relation"
    relation "invested savings of"
    weight 1
  ]
  edge [
    source 54
    target 1101
    kind "relation"
    relation "was at | participated in betting"
    weight 3
  ]
  edge [
    source 54
    target 1102
    kind "mentions"
  ]
  edge [
    source 54
    target 1103
    kind "relation"
    relation "brings"
    weight 1
  ]
  edge [
    source 54
    target 288
    kind "relation"
    relation "packs"
    weight 1
  ]
  edge [
    source 54
    target 1109
    kind "mentions"
  ]
  edge [
    source 54
    target 1111
    kind "mentions"
  ]
  edge [
    source 54
    target 1114
    kind "mentions"
  ]
  edge [
    source 54
    target 1115
    kind "relation"
    relation "found bank-notes on"
    weight 1
  ]
  edge [
    source 54
    target 1131
    kind "mentions"
  ]
  edge [
    source 54
    target 1135
    kind "relation"
    relation "fear"
    weight 1
  ]
  edge [
    source 54
    target 1083
    kind "relation"
    relation "acknowledges the temptation of | is especially weak when"
    weight 2
  ]
  edge [
    source 54
    target 1137
    kind "mentions"
  ]
  edge [
    source 54
    target 1139
    kind "mentions"
  ]
  edge [
    source 54
    target 1147
    kind "relation"
    relation "whispers that the dean is"
    weight 1
  ]
  edge [
    source 54
    target 1150
    kind "mentions"
  ]
  edge [
    source 54
    target 1151
    kind "relation"
    relation "expresses surprise at"
    weight 1
  ]
  edge [
    source 54
    target 1175
    kind "mentions"
  ]
  edge [
    source 54
    target 1178
    kind "mentions"
  ]
  edge [
    source 54
    target 1180
    kind "mentions"
  ]
  edge [
    source 54
    target 1185
    kind "mentions"
  ]
  edge [
    source 54
    target 1186
    kind "relation"
    relation "enters carrying | removes"
    weight 3
  ]
  edge [
    source 54
    target 1192
    kind "mentions"
  ]
  edge [
    source 54
    target 1002
    kind "relation"
    relation "sees"
    weight 1
  ]
  edge [
    source 54
    target 1193
    kind "relation"
    relation "does not recognize the 'appy deanery when"
    weight 1
  ]
  edge [
    source 54
    target 1223
    kind "mentions"
  ]
  edge [
    source 54
    target 110
    kind "relation"
    relation "enters stealthily"
    weight 2
  ]
  edge [
    source 54
    target 1232
    kind "relation"
    relation "whispers | introduced a foreign element into"
    weight 3
  ]
  edge [
    source 54
    target 1238
    kind "relation"
    relation "empties contents of"
    weight 2
  ]
  edge [
    source 54
    target 1188
    kind "relation"
    relation "stirs with"
    weight 2
  ]
  edge [
    source 54
    target 1239
    kind "relation"
    relation "exclaims"
    weight 2
  ]
  edge [
    source 54
    target 1233
    kind "relation"
    relation "says he is"
    weight 2
  ]
  edge [
    source 54
    target 1234
    kind "relation"
    relation "cannot afford"
    weight 2
  ]
  edge [
    source 54
    target 1242
    kind "relation"
    relation "claims"
    weight 2
  ]
  edge [
    source 54
    target 1235
    kind "relation"
    relation "says he will retire from"
    weight 2
  ]
  edge [
    source 54
    target 1236
    kind "relation"
    relation "will retire after"
    weight 2
  ]
  edge [
    source 54
    target 1243
    kind "relation"
    relation "will reclaim"
    weight 2
  ]
  edge [
    source 54
    target 1244
    kind "mentions"
  ]
  edge [
    source 54
    target 1382
    kind "mentions"
  ]
  edge [
    source 54
    target 56
    kind "relation"
    relation "is followed by"
    weight 1
  ]
  edge [
    source 54
    target 1400
    kind "relation"
    relation "is in agony"
    weight 1
  ]
  edge [
    source 54
    target 1426
    kind "mentions"
  ]
  edge [
    source 54
    target 1413
    kind "relation"
    relation "sees | shakes hands with | thinks it is kind of you to visit | gives to | gives a greeting to | refuses a kiss from | nods in response to | wishes to encourage | asks if the horse in the stables was taken"
    weight 9
  ]
  edge [
    source 54
    target 1428
    kind "relation"
    relation "enters with"
    weight 1
  ]
  edge [
    source 54
    target 1433
    kind "mentions"
  ]
  edge [
    source 54
    target 1441
    kind "relation"
    relation "does not know of"
    weight 1
  ]
  edge [
    source 54
    target 1442
    kind "relation"
    relation "has not seen"
    weight 1
  ]
  edge [
    source 54
    target 1444
    kind "relation"
    relation "describes as a rise on the scales"
    weight 1
  ]
  edge [
    source 54
    target 1437
    kind "relation"
    relation "has left a card for"
    weight 1
  ]
  edge [
    source 54
    target 1438
    kind "relation"
    relation "has left a card for"
    weight 1
  ]
  edge [
    source 54
    target 1439
    kind "relation"
    relation "has left a card for"
    weight 1
  ]
  edge [
    source 54
    target 1448
    kind "mentions"
  ]
  edge [
    source 54
    target 1459
    kind "relation"
    relation "takes visitors in with pride"
    weight 1
  ]
  edge [
    source 54
    target 1460
    kind "relation"
    relation "asks when their evening is"
    weight 1
  ]
  edge [
    source 54
    target 1449
    kind "relation"
    relation "receives visitors on"
    weight 1
  ]
  edge [
    source 54
    target 1462
    kind "relation"
    relation "believes friendship is"
    weight 1
  ]
  edge [
    source 54
    target 1000
    kind "relation"
    relation "asks if mr. topping is indoors"
    weight 1
  ]
  edge [
    source 54
    target 1463
    kind "relation"
    relation "claims mr. topping took a man up"
    weight 1
  ]
  edge [
    source 54
    target 1436
    kind "relation"
    relation "believes the head constable had to drive the prisoner to durnstone police station the next morning"
    weight 1
  ]
  edge [
    source 54
    target 1418
    kind "relation"
    relation "concludes the prisoner is now on the premises | reacts with horror to | has his gaiters buttoned by"
    weight 3
  ]
  edge [
    source 54
    target 1452
    kind "relation"
    relation "asks where the cell is"
    weight 1
  ]
  edge [
    source 54
    target 1468
    kind "mentions"
  ]
  edge [
    source 54
    target 1479
    kind "relation"
    relation "has called on"
    weight 1
  ]
  edge [
    source 54
    target 1481
    kind "relation"
    relation "explains he is killing two birds with one stone"
    weight 1
  ]
  edge [
    source 54
    target 1483
    kind "relation"
    relation "agrees to return the cards to"
    weight 1
  ]
  edge [
    source 54
    target 1484
    kind "relation"
    relation "tells hannah that the unfortunate man was taken in"
    weight 1
  ]
  edge [
    source 54
    target 1494
    kind "mentions"
  ]
  edge [
    source 54
    target 1495
    kind "relation"
    relation "only made a hypothetical suggestion about"
    weight 1
  ]
  edge [
    source 54
    target 1502
    kind "mentions"
  ]
  edge [
    source 54
    target 725
    kind "relation"
    relation "took it"
    weight 1
  ]
  edge [
    source 54
    target 1507
    kind "mentions"
  ]
  edge [
    source 54
    target 1508
    kind "relation"
    relation "inquires about the existence of"
    weight 1
  ]
  edge [
    source 54
    target 1525
    kind "relation"
    relation "acknowledges that hannah was"
    weight 1
  ]
  edge [
    source 54
    target 1528
    kind "mentions"
  ]
  edge [
    source 54
    target 1529
    kind "relation"
    relation "inquires about"
    weight 1
  ]
  edge [
    source 54
    target 1531
    kind "relation"
    relation "claims is"
    weight 1
  ]
  edge [
    source 54
    target 1417
    kind "relation"
    relation "offers hand to"
    weight 1
  ]
  edge [
    source 54
    target 1965
    kind "mentions"
  ]
  edge [
    source 54
    target 1968
    kind "mentions"
  ]
  edge [
    source 54
    target 2048
    kind "mentions"
  ]
  edge [
    source 54
    target 394
    kind "relation"
    relation "enters and stands unnoticed"
    weight 1
  ]
  edge [
    source 54
    target 2067
    kind "mentions"
  ]
  edge [
    source 54
    target 2072
    kind "relation"
    relation "sank to his knees and pleaded not to"
    weight 1
  ]
  edge [
    source 54
    target 665
    kind "relation"
    relation "had an honest fancy for | offered mixture to"
    weight 2
  ]
  edge [
    source 54
    target 2074
    kind "relation"
    relation "thought a gentleman of his high standing ought to have"
    weight 1
  ]
  edge [
    source 54
    target 2075
    kind "relation"
    relation "denied doing it"
    weight 1
  ]
  edge [
    source 54
    target 2077
    kind "mentions"
  ]
  edge [
    source 54
    target 674
    kind "relation"
    relation "gave mixture to"
    weight 1
  ]
  edge [
    source 54
    target 2082
    kind "relation"
    relation "wonders what people will think of"
    weight 1
  ]
  edge [
    source 54
    target 2083
    kind "relation"
    relation "would not tell tale if"
    weight 1
  ]
  edge [
    source 54
    target 2084
    kind "relation"
    relation "might tell tale if"
    weight 1
  ]
  edge [
    source 56
    target 57
    kind "relation"
    relation "is portrayed by"
    weight 1
  ]
  edge [
    source 56
    target 940
    kind "mentions"
  ]
  edge [
    source 56
    target 952
    kind "relation"
    relation "is running the horse"
    weight 1
  ]
  edge [
    source 56
    target 998
    kind "mentions"
  ]
  edge [
    source 56
    target 649
    kind "relation"
    relation "enters and asks | enters with | will raise wages of"
    weight 4
  ]
  edge [
    source 56
    target 1012
    kind "relation"
    relation "reports"
    weight 1
  ]
  edge [
    source 56
    target 1013
    kind "relation"
    relation "says he does not close"
    weight 1
  ]
  edge [
    source 56
    target 1000
    kind "relation"
    relation "has secured | says he is going to sit with"
    weight 2
  ]
  edge [
    source 56
    target 1014
    kind "relation"
    relation "suggests the fire at the swan was not an accident but incenderism"
    weight 1
  ]
  edge [
    source 56
    target 725
    kind "relation"
    relation "suggests dandy might have been the object | was administering a dose to"
    weight 2
  ]
  edge [
    source 56
    target 674
    kind "relation"
    relation "explains that he is not going to watch alone | has one mortal fear about"
    weight 3
  ]
  edge [
    source 56
    target 1017
    kind "mentions"
  ]
  edge [
    source 56
    target 1019
    kind "mentions"
  ]
  edge [
    source 56
    target 1025
    kind "relation"
    relation "warns that"
    weight 1
  ]
  edge [
    source 56
    target 1026
    kind "relation"
    relation "suggests keeping"
    weight 1
  ]
  edge [
    source 56
    target 1382
    kind "mentions"
  ]
  edge [
    source 56
    target 578
    kind "relation"
    relation "calls out | is cheered by"
    weight 2
  ]
  edge [
    source 56
    target 546
    kind "relation"
    relation "runs in breathlessly"
    weight 1
  ]
  edge [
    source 56
    target 1385
    kind "relation"
    relation "carries"
    weight 1
  ]
  edge [
    source 56
    target 675
    kind "relation"
    relation "says the villain who set fire to"
    weight 1
  ]
  edge [
    source 56
    target 1384
    kind "relation"
    relation "says the villain knocked the constable's collar and has taken him"
    weight 1
  ]
  edge [
    source 56
    target 1899
    kind "mentions"
  ]
  edge [
    source 56
    target 1906
    kind "mentions"
  ]
  edge [
    source 56
    target 1910
    kind "relation"
    relation "places hand on"
    weight 1
  ]
  edge [
    source 56
    target 1911
    kind "mentions"
  ]
  edge [
    source 56
    target 1912
    kind "relation"
    relation "goes to | cheers loudly"
    weight 2
  ]
  edge [
    source 56
    target 1926
    kind "mentions"
  ]
  edge [
    source 56
    target 2122
    kind "mentions"
  ]
  edge [
    source 56
    target 2123
    kind "relation"
    relation "confirms"
    weight 1
  ]
  edge [
    source 58
    target 59
    kind "relation"
    relation "is portrayed by"
    weight 1
  ]
  edge [
    source 58
    target 505
    kind "mentions"
  ]
  edge [
    source 58
    target 508
    kind "relation"
    relation "will help to reduce"
    weight 1
  ]
  edge [
    source 58
    target 507
    kind "relation"
    relation "will implant"
    weight 1
  ]
  edge [
    source 58
    target 509
    kind "mentions"
  ]
  edge [
    source 58
    target 60
    kind "relation"
    relation "is surprised by"
    weight 1
  ]
  edge [
    source 58
    target 107
    kind "relation"
    relation "states they do not want"
    weight 1
  ]
  edge [
    source 58
    target 511
    kind "mentions"
  ]
  edge [
    source 58
    target 561
    kind "mentions"
  ]
  edge [
    source 58
    target 573
    kind "relation"
    relation "is described as"
    weight 1
  ]
  edge [
    source 58
    target 564
    kind "relation"
    relation "wears"
    weight 1
  ]
  edge [
    source 58
    target 565
    kind "relation"
    relation "wears"
    weight 1
  ]
  edge [
    source 58
    target 566
    kind "relation"
    relation "is addressed as"
    weight 1
  ]
  edge [
    source 58
    target 574
    kind "relation"
    relation "greets the dean as"
    weight 1
  ]
  edge [
    source 58
    target 660
    kind "mentions"
  ]
  edge [
    source 58
    target 606
    kind "relation"
    relation "is the same person as"
    weight 1
  ]
  edge [
    source 58
    target 667
    kind "mentions"
  ]
  edge [
    source 59
    target 93
    kind "mentions"
  ]
  edge [
    source 59
    target 95
    kind "relation"
    relation "played the role of"
    weight 1
  ]
  edge [
    source 60
    target 61
    kind "relation"
    relation "is portrayed by"
    weight 1
  ]
  edge [
    source 60
    target 62
    kind "relation"
    relation "is portrayed by"
    weight 1
  ]
  edge [
    source 60
    target 103
    kind "mentions"
  ]
  edge [
    source 60
    target 115
    kind "relation"
    relation "is a"
    weight 1
  ]
  edge [
    source 60
    target 131
    kind "relation"
    relation "is about"
    weight 1
  ]
  edge [
    source 60
    target 120
    kind "relation"
    relation "sits with elbows on knees"
    weight 1
  ]
  edge [
    source 60
    target 123
    kind "relation"
    relation "exclaims"
    weight 1
  ]
  edge [
    source 60
    target 125
    kind "relation"
    relation "says the terrible word is"
    weight 1
  ]
  edge [
    source 60
    target 127
    kind "relation"
    relation "asks how we got led into it"
    weight 1
  ]
  edge [
    source 60
    target 128
    kind "relation"
    relation "asks sheba to say"
    weight 1
  ]
  edge [
    source 60
    target 134
    kind "mentions"
  ]
  edge [
    source 60
    target 145
    kind "relation"
    relation "believes"
    weight 1
  ]
  edge [
    source 60
    target 147
    kind "relation"
    relation "considers"
    weight 1
  ]
  edge [
    source 60
    target 150
    kind "relation"
    relation "repents now"
    weight 1
  ]
  edge [
    source 60
    target 151
    kind "mentions"
  ]
  edge [
    source 60
    target 141
    kind "relation"
    relation "takes from her pocket"
    weight 1
  ]
  edge [
    source 60
    target 154
    kind "mentions"
  ]
  edge [
    source 60
    target 155
    kind "relation"
    relation "sealed"
    weight 1
  ]
  edge [
    source 60
    target 168
    kind "relation"
    relation "refused to permit"
    weight 1
  ]
  edge [
    source 60
    target 173
    kind "mentions"
  ]
  edge [
    source 60
    target 174
    kind "relation"
    relation "read"
    weight 1
  ]
  edge [
    source 60
    target 177
    kind "mentions"
  ]
  edge [
    source 60
    target 198
    kind "relation"
    relation "says"
    weight 1
  ]
  edge [
    source 60
    target 199
    kind "relation"
    relation "says"
    weight 1
  ]
  edge [
    source 60
    target 203
    kind "mentions"
  ]
  edge [
    source 60
    target 213
    kind "relation"
    relation "says"
    weight 1
  ]
  edge [
    source 60
    target 214
    kind "relation"
    relation "asks"
    weight 1
  ]
  edge [
    source 60
    target 216
    kind "relation"
    relation "says"
    weight 1
  ]
  edge [
    source 60
    target 208
    kind "relation"
    relation "agrees to"
    weight 1
  ]
  edge [
    source 60
    target 209
    kind "relation"
    relation "worry about"
    weight 1
  ]
  edge [
    source 60
    target 219
    kind "mentions"
  ]
  edge [
    source 60
    target 230
    kind "relation"
    relation "suggests that if"
    weight 1
  ]
  edge [
    source 60
    target 231
    kind "relation"
    relation "says they must play the piano when"
    weight 1
  ]
  edge [
    source 60
    target 221
    kind "relation"
    relation "agrees not to wrong | exclaims"
    weight 2
  ]
  edge [
    source 60
    target 232
    kind "relation"
    relation "decides to think about"
    weight 1
  ]
  edge [
    source 60
    target 234
    kind "relation"
    relation "says she will do it | says gerald tarver would die for"
    weight 2
  ]
  edge [
    source 60
    target 107
    kind "relation"
    relation "says sheba is not much younger than she is | clutches hands with | asks if sheba is all right | confirms she is all right | suggests sheba admire her voice | agrees to admire salome's voice | proposes they run away and come in unconsciously | agrees to run away and come in unconsciously | has her arm around | looks up to | is in a scene with | whispers to | links hands with | babbled for money with | has salt in her bed | agrees with | is of the same stock as | agrees to come back | corrects sheba | says salome has gotten into debt | denies having debt | now asks for both salome and herself | describes themselves as weary fragments and everything awful but chastened widows | is a courageous girl | points to"
    weight 32
  ]
  edge [
    source 60
    target 236
    kind "relation"
    relation "says she can't lengthen"
    weight 1
  ]
  edge [
    source 60
    target 241
    kind "mentions"
  ]
  edge [
    source 60
    target 244
    kind "mentions"
  ]
  edge [
    source 60
    target 246
    kind "relation"
    relation "remarks that gerald tarver dismounts well | replies that only part of gerald tarver's liver was left"
    weight 2
  ]
  edge [
    source 60
    target 158
    kind "relation"
    relation "states that gerald tarver gave part of his liver to"
    weight 1
  ]
  edge [
    source 60
    target 110
    kind "relation"
    relation "runs off through"
    weight 1
  ]
  edge [
    source 60
    target 263
    kind "mentions"
  ]
  edge [
    source 60
    target 268
    kind "relation"
    relation "has"
    weight 1
  ]
  edge [
    source 60
    target 277
    kind "relation"
    relation "is confused upon seeing | shrieks and throws themselves at | tells"
    weight 3
  ]
  edge [
    source 60
    target 280
    kind "relation"
    relation "says"
    weight 1
  ]
  edge [
    source 60
    target 283
    kind "mentions"
  ]
  edge [
    source 60
    target 299
    kind "mentions"
  ]
  edge [
    source 60
    target 301
    kind "relation"
    relation "confirms costumes arrived"
    weight 1
  ]
  edge [
    source 60
    target 302
    kind "relation"
    relation "states hamper was labeled"
    weight 1
  ]
  edge [
    source 60
    target 303
    kind "mentions"
  ]
  edge [
    source 60
    target 292
    kind "relation"
    relation "mentions"
    weight 1
  ]
  edge [
    source 60
    target 306
    kind "mentions"
  ]
  edge [
    source 60
    target 307
    kind "relation"
    relation "says has caused"
    weight 1
  ]
  edge [
    source 60
    target 265
    kind "relation"
    relation "insists will forgive | looks at | nods violently to | responds hesitantly to | admires | is in a scene with | praises | compliments | sits beside | clings to | has loved"
    weight 11
  ]
  edge [
    source 60
    target 318
    kind "mentions"
  ]
  edge [
    source 60
    target 329
    kind "mentions"
  ]
  edge [
    source 60
    target 330
    kind "relation"
    relation "fears that papa will hear"
    weight 1
  ]
  edge [
    source 60
    target 191
    kind "relation"
    relation "says to papa | says the bell will wake | says sheba will outlive | calls | says they can pay the bill"
    weight 7
  ]
  edge [
    source 60
    target 349
    kind "mentions"
  ]
  edge [
    source 60
    target 353
    kind "relation"
    relation "wants"
    weight 1
  ]
  edge [
    source 60
    target 359
    kind "mentions"
  ]
  edge [
    source 60
    target 377
    kind "relation"
    relation "explains"
    weight 1
  ]
  edge [
    source 60
    target 378
    kind "relation"
    relation "states"
    weight 1
  ]
  edge [
    source 60
    target 379
    kind "relation"
    relation "states"
    weight 1
  ]
  edge [
    source 60
    target 361
    kind "relation"
    relation "calls"
    weight 1
  ]
  edge [
    source 60
    target 370
    kind "relation"
    relation "agrees"
    weight 1
  ]
  edge [
    source 60
    target 388
    kind "mentions"
  ]
  edge [
    source 60
    target 264
    kind "relation"
    relation "is in a scene with"
    weight 1
  ]
  edge [
    source 60
    target 393
    kind "relation"
    relation "agrees with"
    weight 2
  ]
  edge [
    source 60
    target 396
    kind "mentions"
  ]
  edge [
    source 60
    target 402
    kind "mentions"
  ]
  edge [
    source 60
    target 407
    kind "relation"
    relation "responds with"
    weight 1
  ]
  edge [
    source 60
    target 411
    kind "relation"
    relation "says"
    weight 1
  ]
  edge [
    source 60
    target 415
    kind "relation"
    relation "escorts"
    weight 1
  ]
  edge [
    source 60
    target 422
    kind "mentions"
  ]
  edge [
    source 60
    target 425
    kind "mentions"
  ]
  edge [
    source 60
    target 428
    kind "mentions"
  ]
  edge [
    source 60
    target 347
    kind "relation"
    relation "says he always is"
    weight 1
  ]
  edge [
    source 60
    target 433
    kind "relation"
    relation "sits on the ground embracing"
    weight 1
  ]
  edge [
    source 60
    target 434
    kind "mentions"
  ]
  edge [
    source 60
    target 442
    kind "mentions"
  ]
  edge [
    source 60
    target 455
    kind "relation"
    relation "scrambles up from"
    weight 1
  ]
  edge [
    source 60
    target 457
    kind "relation"
    relation "says to herself"
    weight 1
  ]
  edge [
    source 60
    target 462
    kind "mentions"
  ]
  edge [
    source 60
    target 472
    kind "mentions"
  ]
  edge [
    source 60
    target 482
    kind "mentions"
  ]
  edge [
    source 60
    target 498
    kind "mentions"
  ]
  edge [
    source 60
    target 509
    kind "mentions"
  ]
  edge [
    source 60
    target 506
    kind "relation"
    relation "is one of the daughters"
    weight 1
  ]
  edge [
    source 60
    target 543
    kind "mentions"
  ]
  edge [
    source 60
    target 549
    kind "mentions"
  ]
  edge [
    source 60
    target 550
    kind "relation"
    relation "will find"
    weight 1
  ]
  edge [
    source 60
    target 551
    kind "relation"
    relation "will find | does not see"
    weight 2
  ]
  edge [
    source 60
    target 552
    kind "relation"
    relation "will find"
    weight 1
  ]
  edge [
    source 60
    target 553
    kind "relation"
    relation "will try to win back"
    weight 1
  ]
  edge [
    source 60
    target 555
    kind "mentions"
  ]
  edge [
    source 60
    target 559
    kind "relation"
    relation "says"
    weight 1
  ]
  edge [
    source 60
    target 561
    kind "mentions"
  ]
  edge [
    source 60
    target 570
    kind "relation"
    relation "has a peg missing from"
    weight 1
  ]
  edge [
    source 60
    target 586
    kind "mentions"
  ]
  edge [
    source 60
    target 613
    kind "mentions"
  ]
  edge [
    source 60
    target 614
    kind "relation"
    relation "does not see"
    weight 1
  ]
  edge [
    source 60
    target 578
    kind "relation"
    relation "sees | instructs girls to make the running | enters with | is laughing and chatting with | calls | asks if she thinks so"
    weight 6
  ]
  edge [
    source 60
    target 629
    kind "mentions"
  ]
  edge [
    source 60
    target 687
    kind "mentions"
  ]
  edge [
    source 60
    target 695
    kind "mentions"
  ]
  edge [
    source 60
    target 697
    kind "relation"
    relation "was foaled in"
    weight 1
  ]
  edge [
    source 60
    target 701
    kind "mentions"
  ]
  edge [
    source 60
    target 703
    kind "mentions"
  ]
  edge [
    source 60
    target 705
    kind "relation"
    relation "exits by | appears outside | looks in"
    weight 3
  ]
  edge [
    source 60
    target 741
    kind "mentions"
  ]
  edge [
    source 60
    target 743
    kind "relation"
    relation "entered unperceived"
    weight 1
  ]
  edge [
    source 60
    target 748
    kind "mentions"
  ]
  edge [
    source 60
    target 752
    kind "mentions"
  ]
  edge [
    source 60
    target 754
    kind "relation"
    relation "states the amount owed is forty pounds, nineteen"
    weight 1
  ]
  edge [
    source 60
    target 759
    kind "mentions"
  ]
  edge [
    source 60
    target 761
    kind "relation"
    relation "wants to win | reveals they won"
    weight 2
  ]
  edge [
    source 60
    target 765
    kind "relation"
    relation "is frightened by"
    weight 1
  ]
  edge [
    source 60
    target 766
    kind "mentions"
  ]
  edge [
    source 60
    target 122
    kind "relation"
    relation "is lounging on | is lolling on"
    weight 2
  ]
  edge [
    source 60
    target 770
    kind "mentions"
  ]
  edge [
    source 60
    target 773
    kind "relation"
    relation "asks for"
    weight 1
  ]
  edge [
    source 60
    target 787
    kind "relation"
    relation "thinks the dinner was"
    weight 1
  ]
  edge [
    source 60
    target 789
    kind "relation"
    relation "attributes the overdone mutton to"
    weight 1
  ]
  edge [
    source 60
    target 790
    kind "relation"
    relation "says the custards were"
    weight 1
  ]
  edge [
    source 60
    target 792
    kind "relation"
    relation "says the dinner was"
    weight 1
  ]
  edge [
    source 60
    target 795
    kind "mentions"
  ]
  edge [
    source 60
    target 800
    kind "mentions"
  ]
  edge [
    source 60
    target 809
    kind "mentions"
  ]
  edge [
    source 60
    target 817
    kind "mentions"
  ]
  edge [
    source 60
    target 820
    kind "mentions"
  ]
  edge [
    source 60
    target 824
    kind "mentions"
  ]
  edge [
    source 60
    target 589
    kind "relation"
    relation "would have confided in | would have taken"
    weight 2
  ]
  edge [
    source 60
    target 831
    kind "mentions"
  ]
  edge [
    source 60
    target 832
    kind "relation"
    relation "asks what"
    weight 1
  ]
  edge [
    source 60
    target 833
    kind "mentions"
  ]
  edge [
    source 60
    target 835
    kind "mentions"
  ]
  edge [
    source 60
    target 838
    kind "mentions"
  ]
  edge [
    source 60
    target 850
    kind "mentions"
  ]
  edge [
    source 60
    target 853
    kind "relation"
    relation "notices tarver is"
    weight 1
  ]
  edge [
    source 60
    target 855
    kind "mentions"
  ]
  edge [
    source 60
    target 870
    kind "mentions"
  ]
  edge [
    source 60
    target 876
    kind "relation"
    relation "asks tarver what piece he will begin with"
    weight 1
  ]
  edge [
    source 60
    target 882
    kind "mentions"
  ]
  edge [
    source 60
    target 885
    kind "mentions"
  ]
  edge [
    source 60
    target 887
    kind "relation"
    relation "hopes her ball-dress will make"
    weight 1
  ]
  edge [
    source 60
    target 904
    kind "mentions"
  ]
  edge [
    source 60
    target 917
    kind "mentions"
  ]
  edge [
    source 60
    target 921
    kind "mentions"
  ]
  edge [
    source 60
    target 938
    kind "mentions"
  ]
  edge [
    source 60
    target 940
    kind "mentions"
  ]
  edge [
    source 60
    target 962
    kind "mentions"
  ]
  edge [
    source 60
    target 977
    kind "mentions"
  ]
  edge [
    source 60
    target 985
    kind "relation"
    relation "calls out"
    weight 1
  ]
  edge [
    source 60
    target 986
    kind "relation"
    relation "advises"
    weight 1
  ]
  edge [
    source 60
    target 1297
    kind "mentions"
  ]
  edge [
    source 60
    target 1301
    kind "relation"
    relation "lights"
    weight 1
  ]
  edge [
    source 60
    target 1305
    kind "relation"
    relation "expresses desire for"
    weight 1
  ]
  edge [
    source 60
    target 1307
    kind "mentions"
  ]
  edge [
    source 60
    target 1324
    kind "relation"
    relation "mocks"
    weight 1
  ]
  edge [
    source 60
    target 1325
    kind "relation"
    relation "wishes"
    weight 1
  ]
  edge [
    source 60
    target 1317
    kind "relation"
    relation "wishes"
    weight 1
  ]
  edge [
    source 60
    target 1337
    kind "mentions"
  ]
  edge [
    source 60
    target 284
    kind "relation"
    relation "inflicted upon"
    weight 1
  ]
  edge [
    source 60
    target 650
    kind "relation"
    relation "was jeered at by"
    weight 1
  ]
  edge [
    source 60
    target 1345
    kind "mentions"
  ]
  edge [
    source 60
    target 237
    kind "relation"
    relation "entered"
    weight 1
  ]
  edge [
    source 60
    target 1347
    kind "mentions"
  ]
  edge [
    source 60
    target 1356
    kind "mentions"
  ]
  edge [
    source 60
    target 1371
    kind "relation"
    relation "says the children did not ask"
    weight 1
  ]
  edge [
    source 60
    target 1382
    kind "mentions"
  ]
  edge [
    source 60
    target 1851
    kind "mentions"
  ]
  edge [
    source 60
    target 1856
    kind "mentions"
  ]
  edge [
    source 60
    target 65
    kind "relation"
    relation "says poor papa must return soon | says anxiety is terribly wearing | says it is comforting to feel they have no cause for self-reproach"
    weight 3
  ]
  edge [
    source 60
    target 1858
    kind "mentions"
  ]
  edge [
    source 60
    target 1863
    kind "relation"
    relation "says gentlemen intrude upon"
    weight 1
  ]
  edge [
    source 60
    target 1864
    kind "mentions"
  ]
  edge [
    source 60
    target 1873
    kind "mentions"
  ]
  edge [
    source 60
    target 1875
    kind "mentions"
  ]
  edge [
    source 60
    target 1878
    kind "relation"
    relation "questions whether she would silence the small songster"
    weight 1
  ]
  edge [
    source 60
    target 1887
    kind "mentions"
  ]
  edge [
    source 60
    target 1890
    kind "relation"
    relation "tells"
    weight 1
  ]
  edge [
    source 60
    target 1891
    kind "mentions"
  ]
  edge [
    source 60
    target 1892
    kind "relation"
    relation "calls it"
    weight 1
  ]
  edge [
    source 60
    target 1996
    kind "mentions"
  ]
  edge [
    source 60
    target 1998
    kind "relation"
    relation "is sitting on"
    weight 1
  ]
  edge [
    source 60
    target 2002
    kind "mentions"
  ]
  edge [
    source 60
    target 2008
    kind "mentions"
  ]
  edge [
    source 60
    target 2009
    kind "relation"
    relation "seizes"
    weight 1
  ]
  edge [
    source 60
    target 2011
    kind "relation"
    relation "declares"
    weight 1
  ]
  edge [
    source 60
    target 2013
    kind "mentions"
  ]
  edge [
    source 60
    target 2018
    kind "mentions"
  ]
  edge [
    source 60
    target 2020
    kind "mentions"
  ]
  edge [
    source 60
    target 491
    kind "relation"
    relation "won at"
    weight 1
  ]
  edge [
    source 60
    target 2043
    kind "mentions"
  ]
  edge [
    source 60
    target 2048
    kind "mentions"
  ]
  edge [
    source 60
    target 2054
    kind "relation"
    relation "enters and stands in the recess"
    weight 1
  ]
  edge [
    source 60
    target 2077
    kind "mentions"
  ]
  edge [
    source 60
    target 2086
    kind "mentions"
  ]
  edge [
    source 60
    target 2092
    kind "relation"
    relation "announces presence of"
    weight 1
  ]
  edge [
    source 60
    target 2098
    kind "mentions"
  ]
  edge [
    source 60
    target 2101
    kind "relation"
    relation "believes they have an opportunity"
    weight 1
  ]
  edge [
    source 60
    target 2115
    kind "mentions"
  ]
  edge [
    source 60
    target 2118
    kind "mentions"
  ]
  edge [
    source 63
    target 71
    kind "relation"
    relation "is portrayed by"
    weight 1
  ]
  edge [
    source 64
    target 72
    kind "mentions"
  ]
  edge [
    source 64
    target 73
    kind "relation"
    relation "takes place at"
    weight 1
  ]
  edge [
    source 64
    target 74
    kind "relation"
    relation "takes place at"
    weight 1
  ]
  edge [
    source 65
    target 72
    kind "mentions"
  ]
  edge [
    source 65
    target 73
    kind "relation"
    relation "takes place at"
    weight 1
  ]
  edge [
    source 65
    target 74
    kind "relation"
    relation "takes place at"
    weight 1
  ]
  edge [
    source 65
    target 504
    kind "mentions"
  ]
  edge [
    source 65
    target 604
    kind "mentions"
  ]
  edge [
    source 65
    target 578
    kind "relation"
    relation "has caught the tone of | catches the tone of"
    weight 2
  ]
  edge [
    source 65
    target 672
    kind "mentions"
  ]
  edge [
    source 65
    target 766
    kind "mentions"
  ]
  edge [
    source 65
    target 767
    kind "relation"
    relation "is located at"
    weight 1
  ]
  edge [
    source 65
    target 770
    kind "mentions"
  ]
  edge [
    source 65
    target 107
    kind "relation"
    relation "says all dinners are held at | agrees that papa must return soon | agrees that anxiety is terribly wearing | says it is comforting to feel they have no cause for self-reproach"
    weight 4
  ]
  edge [
    source 65
    target 812
    kind "mentions"
  ]
  edge [
    source 65
    target 954
    kind "mentions"
  ]
  edge [
    source 65
    target 649
    kind "relation"
    relation "will lead dandy into | is staying at | will smoke in"
    weight 3
  ]
  edge [
    source 65
    target 958
    kind "relation"
    relation "leads dandy into"
    weight 2
  ]
  edge [
    source 65
    target 961
    kind "mentions"
  ]
  edge [
    source 65
    target 992
    kind "mentions"
  ]
  edge [
    source 65
    target 264
    kind "relation"
    relation "knows he is in | presumes to present himself at"
    weight 2
  ]
  edge [
    source 65
    target 996
    kind "mentions"
  ]
  edge [
    source 65
    target 998
    kind "mentions"
  ]
  edge [
    source 65
    target 680
    kind "relation"
    relation "knows he is in"
    weight 1
  ]
  edge [
    source 65
    target 1048
    kind "mentions"
  ]
  edge [
    source 65
    target 1050
    kind "mentions"
  ]
  edge [
    source 65
    target 1131
    kind "mentions"
  ]
  edge [
    source 65
    target 1134
    kind "relation"
    relation "spends more ready money"
    weight 1
  ]
  edge [
    source 65
    target 1175
    kind "mentions"
  ]
  edge [
    source 65
    target 1192
    kind "mentions"
  ]
  edge [
    source 65
    target 1426
    kind "mentions"
  ]
  edge [
    source 65
    target 1433
    kind "mentions"
  ]
  edge [
    source 65
    target 1413
    kind "relation"
    relation "was cook at"
    weight 1
  ]
  edge [
    source 65
    target 1468
    kind "mentions"
  ]
  edge [
    source 65
    target 1507
    kind "mentions"
  ]
  edge [
    source 65
    target 1528
    kind "mentions"
  ]
  edge [
    source 65
    target 1417
    kind "relation"
    relation "says will visit"
    weight 1
  ]
  edge [
    source 65
    target 1594
    kind "mentions"
  ]
  edge [
    source 65
    target 1662
    kind "mentions"
  ]
  edge [
    source 65
    target 1851
    kind "mentions"
  ]
  edge [
    source 65
    target 1856
    kind "mentions"
  ]
  edge [
    source 65
    target 1965
    kind "mentions"
  ]
  edge [
    source 65
    target 2077
    kind "mentions"
  ]
  edge [
    source 65
    target 2104
    kind "mentions"
  ]
  edge [
    source 65
    target 2133
    kind "mentions"
  ]
  edge [
    source 65
    target 2135
    kind "relation"
    relation "was once genial"
    weight 1
  ]
  edge [
    source 65
    target 2138
    kind "relation"
    relation "is now marked by"
    weight 1
  ]
  edge [
    source 66
    target 70
    kind "relation"
    relation "is from"
    weight 1
  ]
  edge [
    source 66
    target 134
    kind "mentions"
  ]
  edge [
    source 66
    target 349
    kind "mentions"
  ]
  edge [
    source 66
    target 135
    kind "relation"
    relation "has ridden from"
    weight 1
  ]
  edge [
    source 66
    target 359
    kind "mentions"
  ]
  edge [
    source 66
    target 388
    kind "mentions"
  ]
  edge [
    source 66
    target 396
    kind "mentions"
  ]
  edge [
    source 66
    target 561
    kind "mentions"
  ]
  edge [
    source 66
    target 1034
    kind "mentions"
  ]
  edge [
    source 66
    target 1416
    kind "mentions"
  ]
  edge [
    source 66
    target 1433
    kind "mentions"
  ]
  edge [
    source 66
    target 1413
    kind "relation"
    relation "married a policeman at | insists the dean will not be taken to | says the bench sets at"
    weight 3
  ]
  edge [
    source 66
    target 1528
    kind "mentions"
  ]
  edge [
    source 66
    target 1417
    kind "relation"
    relation "will take man to"
    weight 1
  ]
  edge [
    source 66
    target 1553
    kind "mentions"
  ]
  edge [
    source 66
    target 1623
    kind "mentions"
  ]
  edge [
    source 66
    target 1634
    kind "mentions"
  ]
  edge [
    source 66
    target 1693
    kind "mentions"
  ]
  edge [
    source 66
    target 1711
    kind "mentions"
  ]
  edge [
    source 66
    target 1765
    kind "mentions"
  ]
  edge [
    source 66
    target 1776
    kind "mentions"
  ]
  edge [
    source 66
    target 1817
    kind "mentions"
  ]
  edge [
    source 69
    target 633
    kind "mentions"
  ]
  edge [
    source 69
    target 643
    kind "relation"
    relation "reads"
    weight 1
  ]
  edge [
    source 69
    target 640
    kind "relation"
    relation "has a ruddy face and jovial manner"
    weight 1
  ]
  edge [
    source 69
    target 644
    kind "relation"
    relation "greets the dean as"
    weight 1
  ]
  edge [
    source 69
    target 645
    kind "relation"
    relation "calls them | called them"
    weight 2
  ]
  edge [
    source 69
    target 646
    kind "mentions"
  ]
  edge [
    source 69
    target 660
    kind "mentions"
  ]
  edge [
    source 69
    target 663
    kind "relation"
    relation "wears colors of"
    weight 1
  ]
  edge [
    source 69
    target 664
    kind "relation"
    relation "has a pink cap"
    weight 1
  ]
  edge [
    source 69
    target 665
    kind "relation"
    relation "believes bonny betsy cannot get down a steep hill with a boy on her back"
    weight 1
  ]
  edge [
    source 69
    target 695
    kind "mentions"
  ]
  edge [
    source 69
    target 700
    kind "mentions"
  ]
  edge [
    source 69
    target 578
    kind "relation"
    relation "is glad to see | was at oxford with | won't have"
    weight 3
  ]
  edge [
    source 69
    target 706
    kind "mentions"
  ]
  edge [
    source 69
    target 708
    kind "relation"
    relation "is racing"
    weight 1
  ]
  edge [
    source 70
    target 219
    kind "mentions"
  ]
  edge [
    source 70
    target 241
    kind "mentions"
  ]
  edge [
    source 70
    target 244
    kind "mentions"
  ]
  edge [
    source 70
    target 248
    kind "relation"
    relation "is dressed in"
    weight 1
  ]
  edge [
    source 70
    target 251
    kind "mentions"
  ]
  edge [
    source 70
    target 258
    kind "relation"
    relation "is"
    weight 1
  ]
  edge [
    source 70
    target 261
    kind "relation"
    relation "has"
    weight 1
  ]
  edge [
    source 70
    target 262
    kind "relation"
    relation "has"
    weight 1
  ]
  edge [
    source 70
    target 1858
    kind "mentions"
  ]
  edge [
    source 70
    target 1864
    kind "mentions"
  ]
  edge [
    source 70
    target 1996
    kind "mentions"
  ]
  edge [
    source 70
    target 2077
    kind "mentions"
  ]
  edge [
    source 70
    target 2086
    kind "mentions"
  ]
  edge [
    source 70
    target 2115
    kind "mentions"
  ]
  edge [
    source 71
    target 1662
    kind "mentions"
  ]
  edge [
    source 72
    target 73
    kind "mentions"
  ]
  edge [
    source 72
    target 74
    kind "mentions"
  ]
  edge [
    source 72
    target 75
    kind "mentions"
  ]
  edge [
    source 72
    target 76
    kind "mentions"
  ]
  edge [
    source 72
    target 77
    kind "mentions"
  ]
  edge [
    source 72
    target 78
    kind "mentions"
  ]
  edge [
    source 72
    target 2214
    kind "summarizes"
  ]
  edge [
    source 73
    target 76
    kind "relation"
    relation "takes place in"
    weight 1
  ]
  edge [
    source 74
    target 77
    kind "relation"
    relation "takes place in"
    weight 1
  ]
  edge [
    source 75
    target 78
    kind "relation"
    relation "takes place on"
    weight 1
  ]
  edge [
    source 76
    target 103
    kind "mentions"
  ]
  edge [
    source 76
    target 1074
    kind "mentions"
  ]
  edge [
    source 76
    target 1740
    kind "mentions"
  ]
  edge [
    source 76
    target 649
    kind "relation"
    relation "says dr. jedd was not found"
    weight 1
  ]
  edge [
    source 77
    target 1448
    kind "mentions"
  ]
  edge [
    source 77
    target 1749
    kind "mentions"
  ]
  edge [
    source 79
    target 80
    kind "from_chunk"
  ]
  edge [
    source 79
    target 88
    kind "from_chunk"
  ]
  edge [
    source 79
    target 93
    kind "from_chunk"
  ]
  edge [
    source 79
    target 100
    kind "from_chunk"
  ]
  edge [
    source 80
    target 81
    kind "mentions"
  ]
  edge [
    source 80
    target 82
    kind "mentions"
  ]
  edge [
    source 80
    target 83
    kind "mentions"
  ]
  edge [
    source 80
    target 84
    kind "mentions"
  ]
  edge [
    source 80
    target 85
    kind "mentions"
  ]
  edge [
    source 80
    target 86
    kind "mentions"
  ]
  edge [
    source 80
    target 87
    kind "mentions"
  ]
  edge [
    source 80
    target 2214
    kind "summarizes"
  ]
  edge [
    source 82
    target 83
    kind "relation"
    relation "was demolished on"
    weight 1
  ]
  edge [
    source 84
    target 87
    kind "relation"
    relation "ran the play for"
    weight 1
  ]
  edge [
    source 88
    target 89
    kind "mentions"
  ]
  edge [
    source 88
    target 90
    kind "mentions"
  ]
  edge [
    source 88
    target 91
    kind "mentions"
  ]
  edge [
    source 88
    target 92
    kind "mentions"
  ]
  edge [
    source 88
    target 2218
    kind "summarizes"
  ]
  edge [
    source 93
    target 94
    kind "mentions"
  ]
  edge [
    source 93
    target 95
    kind "mentions"
  ]
  edge [
    source 93
    target 96
    kind "mentions"
  ]
  edge [
    source 93
    target 97
    kind "mentions"
  ]
  edge [
    source 93
    target 98
    kind "mentions"
  ]
  edge [
    source 93
    target 99
    kind "mentions"
  ]
  edge [
    source 93
    target 2214
    kind "summarizes"
  ]
  edge [
    source 100
    target 101
    kind "mentions"
  ]
  edge [
    source 100
    target 2214
    kind "summarizes"
  ]
  edge [
    source 102
    target 103
    kind "from_chunk"
  ]
  edge [
    source 103
    target 104
    kind "mentions"
  ]
  edge [
    source 103
    target 105
    kind "mentions"
  ]
  edge [
    source 103
    target 106
    kind "mentions"
  ]
  edge [
    source 103
    target 107
    kind "mentions"
  ]
  edge [
    source 103
    target 108
    kind "mentions"
  ]
  edge [
    source 103
    target 109
    kind "mentions"
  ]
  edge [
    source 103
    target 110
    kind "mentions"
  ]
  edge [
    source 103
    target 111
    kind "mentions"
  ]
  edge [
    source 103
    target 112
    kind "mentions"
  ]
  edge [
    source 103
    target 113
    kind "mentions"
  ]
  edge [
    source 103
    target 114
    kind "mentions"
  ]
  edge [
    source 103
    target 115
    kind "mentions"
  ]
  edge [
    source 103
    target 116
    kind "mentions"
  ]
  edge [
    source 103
    target 117
    kind "mentions"
  ]
  edge [
    source 103
    target 118
    kind "mentions"
  ]
  edge [
    source 103
    target 119
    kind "mentions"
  ]
  edge [
    source 103
    target 120
    kind "mentions"
  ]
  edge [
    source 103
    target 121
    kind "mentions"
  ]
  edge [
    source 103
    target 122
    kind "mentions"
  ]
  edge [
    source 103
    target 123
    kind "mentions"
  ]
  edge [
    source 103
    target 124
    kind "mentions"
  ]
  edge [
    source 103
    target 125
    kind "mentions"
  ]
  edge [
    source 103
    target 126
    kind "mentions"
  ]
  edge [
    source 103
    target 127
    kind "mentions"
  ]
  edge [
    source 103
    target 128
    kind "mentions"
  ]
  edge [
    source 103
    target 129
    kind "mentions"
  ]
  edge [
    source 103
    target 130
    kind "mentions"
  ]
  edge [
    source 103
    target 131
    kind "mentions"
  ]
  edge [
    source 103
    target 132
    kind "mentions"
  ]
  edge [
    source 103
    target 2235
    kind "summarizes"
  ]
  edge [
    source 105
    target 106
    kind "relation"
    relation "portrayed"
    weight 1
  ]
  edge [
    source 107
    target 116
    kind "relation"
    relation "is a"
    weight 1
  ]
  edge [
    source 107
    target 132
    kind "relation"
    relation "is about"
    weight 1
  ]
  edge [
    source 107
    target 119
    kind "relation"
    relation "wears"
    weight 1
  ]
  edge [
    source 107
    target 122
    kind "relation"
    relation "lies prostrate on"
    weight 1
  ]
  edge [
    source 107
    target 124
    kind "relation"
    relation "responds with"
    weight 1
  ]
  edge [
    source 107
    target 126
    kind "relation"
    relation "says it is worse than"
    weight 1
  ]
  edge [
    source 107
    target 127
    kind "relation"
    relation "asks how they were led into it"
    weight 1
  ]
  edge [
    source 107
    target 134
    kind "mentions"
  ]
  edge [
    source 107
    target 146
    kind "relation"
    relation "accuses"
    weight 1
  ]
  edge [
    source 107
    target 148
    kind "relation"
    relation "says they are not yet wrong"
    weight 1
  ]
  edge [
    source 107
    target 149
    kind "relation"
    relation "will repent"
    weight 1
  ]
  edge [
    source 107
    target 151
    kind "mentions"
  ]
  edge [
    source 107
    target 152
    kind "relation"
    relation "would repent"
    weight 1
  ]
  edge [
    source 107
    target 154
    kind "mentions"
  ]
  edge [
    source 107
    target 173
    kind "mentions"
  ]
  edge [
    source 107
    target 175
    kind "relation"
    relation "reacted hysterically to"
    weight 1
  ]
  edge [
    source 107
    target 177
    kind "mentions"
  ]
  edge [
    source 107
    target 188
    kind "relation"
    relation "claims"
    weight 1
  ]
  edge [
    source 107
    target 197
    kind "relation"
    relation "says"
    weight 1
  ]
  edge [
    source 107
    target 200
    kind "relation"
    relation "suggests"
    weight 1
  ]
  edge [
    source 107
    target 201
    kind "relation"
    relation "suggests"
    weight 1
  ]
  edge [
    source 107
    target 202
    kind "relation"
    relation "says"
    weight 1
  ]
  edge [
    source 107
    target 203
    kind "mentions"
  ]
  edge [
    source 107
    target 215
    kind "relation"
    relation "jokes that if they were older"
    weight 1
  ]
  edge [
    source 107
    target 217
    kind "relation"
    relation "proposes"
    weight 1
  ]
  edge [
    source 107
    target 219
    kind "mentions"
  ]
  edge [
    source 107
    target 229
    kind "relation"
    relation "says they can't help that when"
    weight 1
  ]
  edge [
    source 107
    target 221
    kind "relation"
    relation "refers to | exclaims"
    weight 2
  ]
  edge [
    source 107
    target 233
    kind "relation"
    relation "says she will do it"
    weight 1
  ]
  edge [
    source 107
    target 234
    kind "relation"
    relation "says nugent darbey would die for | says she is not old enough to know better"
    weight 2
  ]
  edge [
    source 107
    target 235
    kind "relation"
    relation "asks why"
    weight 1
  ]
  edge [
    source 107
    target 240
    kind "relation"
    relation "confirms that"
    weight 2
  ]
  edge [
    source 107
    target 241
    kind "mentions"
  ]
  edge [
    source 107
    target 244
    kind "mentions"
  ]
  edge [
    source 107
    target 245
    kind "relation"
    relation "adds that they have called to inquire after"
    weight 1
  ]
  edge [
    source 107
    target 247
    kind "relation"
    relation "instructs blore to hang his h's on"
    weight 1
  ]
  edge [
    source 107
    target 246
    kind "relation"
    relation "jokes that gerald tarver left his liver in india"
    weight 1
  ]
  edge [
    source 107
    target 263
    kind "mentions"
  ]
  edge [
    source 107
    target 283
    kind "mentions"
  ]
  edge [
    source 107
    target 297
    kind "relation"
    relation "states they never imagined finding"
    weight 1
  ]
  edge [
    source 107
    target 311
    kind "mentions"
  ]
  edge [
    source 107
    target 264
    kind "relation"
    relation "thinks there is a grand future for | is in a scene with | offers to play with | asks why | accompanies | clings to | looked at"
    weight 7
  ]
  edge [
    source 107
    target 329
    kind "mentions"
  ]
  edge [
    source 107
    target 191
    kind "relation"
    relation "exclaims | compares wellington to | expresses pity for | calls out for | admits they always knew they were more capable than"
    weight 5
  ]
  edge [
    source 107
    target 347
    kind "relation"
    relation "exclaims | replies | calls"
    weight 3
  ]
  edge [
    source 107
    target 349
    kind "mentions"
  ]
  edge [
    source 107
    target 350
    kind "relation"
    relation "takes"
    weight 1
  ]
  edge [
    source 107
    target 355
    kind "relation"
    relation "wants | orders"
    weight 2
  ]
  edge [
    source 107
    target 359
    kind "mentions"
  ]
  edge [
    source 107
    target 371
    kind "relation"
    relation "orders"
    weight 1
  ]
  edge [
    source 107
    target 383
    kind "relation"
    relation "suggests"
    weight 1
  ]
  edge [
    source 107
    target 385
    kind "relation"
    relation "exclaims"
    weight 1
  ]
  edge [
    source 107
    target 388
    kind "mentions"
  ]
  edge [
    source 107
    target 265
    kind "relation"
    relation "is in a scene with"
    weight 1
  ]
  edge [
    source 107
    target 393
    kind "relation"
    relation "expresses enthusiasm about | expresses excitement about"
    weight 2
  ]
  edge [
    source 107
    target 396
    kind "mentions"
  ]
  edge [
    source 107
    target 402
    kind "mentions"
  ]
  edge [
    source 107
    target 406
    kind "relation"
    relation "exclaims"
    weight 1
  ]
  edge [
    source 107
    target 422
    kind "mentions"
  ]
  edge [
    source 107
    target 423
    kind "relation"
    relation "sees an opportunity to ask for"
    weight 1
  ]
  edge [
    source 107
    target 425
    kind "mentions"
  ]
  edge [
    source 107
    target 428
    kind "mentions"
  ]
  edge [
    source 107
    target 194
    kind "relation"
    relation "says papsey is in"
    weight 1
  ]
  edge [
    source 107
    target 432
    kind "relation"
    relation "says papsey will listen to"
    weight 1
  ]
  edge [
    source 107
    target 429
    kind "relation"
    relation "lies on | wriggles off"
    weight 2
  ]
  edge [
    source 107
    target 434
    kind "mentions"
  ]
  edge [
    source 107
    target 440
    kind "relation"
    relation "says"
    weight 1
  ]
  edge [
    source 107
    target 442
    kind "mentions"
  ]
  edge [
    source 107
    target 458
    kind "relation"
    relation "says to herself"
    weight 1
  ]
  edge [
    source 107
    target 462
    kind "mentions"
  ]
  edge [
    source 107
    target 482
    kind "mentions"
  ]
  edge [
    source 107
    target 483
    kind "relation"
    relation "questions whether"
    weight 1
  ]
  edge [
    source 107
    target 498
    kind "mentions"
  ]
  edge [
    source 107
    target 509
    kind "mentions"
  ]
  edge [
    source 107
    target 506
    kind "relation"
    relation "is one of the daughters"
    weight 1
  ]
  edge [
    source 107
    target 530
    kind "mentions"
  ]
  edge [
    source 107
    target 531
    kind "relation"
    relation "was mad due to"
    weight 1
  ]
  edge [
    source 107
    target 532
    kind "relation"
    relation "continued the career of"
    weight 1
  ]
  edge [
    source 107
    target 533
    kind "relation"
    relation "was known as"
    weight 1
  ]
  edge [
    source 107
    target 543
    kind "mentions"
  ]
  edge [
    source 107
    target 549
    kind "mentions"
  ]
  edge [
    source 107
    target 550
    kind "relation"
    relation "will find"
    weight 1
  ]
  edge [
    source 107
    target 551
    kind "relation"
    relation "will find"
    weight 1
  ]
  edge [
    source 107
    target 552
    kind "relation"
    relation "will find"
    weight 1
  ]
  edge [
    source 107
    target 553
    kind "relation"
    relation "will try to win back"
    weight 1
  ]
  edge [
    source 107
    target 555
    kind "mentions"
  ]
  edge [
    source 107
    target 558
    kind "relation"
    relation "says"
    weight 1
  ]
  edge [
    source 107
    target 557
    kind "relation"
    relation "says"
    weight 1
  ]
  edge [
    source 107
    target 561
    kind "mentions"
  ]
  edge [
    source 107
    target 586
    kind "mentions"
  ]
  edge [
    source 107
    target 578
    kind "relation"
    relation "embraces sheba | has a playful exchange with | laughs at | does not understand | likes | enters with | is laughing and chatting with | tells georgiana that salome has something to say | catches hold of | scolds them for crying and acting about forty pounds | does not think so | is not bad | is trustful and confiding"
    weight 13
  ]
  edge [
    source 107
    target 592
    kind "mentions"
  ]
  edge [
    source 107
    target 604
    kind "mentions"
  ]
  edge [
    source 107
    target 613
    kind "mentions"
  ]
  edge [
    source 107
    target 629
    kind "mentions"
  ]
  edge [
    source 107
    target 687
    kind "mentions"
  ]
  edge [
    source 107
    target 695
    kind "mentions"
  ]
  edge [
    source 107
    target 701
    kind "mentions"
  ]
  edge [
    source 107
    target 703
    kind "mentions"
  ]
  edge [
    source 107
    target 335
    kind "relation"
    relation "says that pa is like"
    weight 1
  ]
  edge [
    source 107
    target 741
    kind "mentions"
  ]
  edge [
    source 107
    target 743
    kind "relation"
    relation "entered unperceived"
    weight 1
  ]
  edge [
    source 107
    target 748
    kind "mentions"
  ]
  edge [
    source 107
    target 749
    kind "relation"
    relation "is shivering"
    weight 1
  ]
  edge [
    source 107
    target 752
    kind "mentions"
  ]
  edge [
    source 107
    target 753
    kind "relation"
    relation "heard mention of"
    weight 1
  ]
  edge [
    source 107
    target 756
    kind "relation"
    relation "thinks a thousand pounds is a large amount"
    weight 1
  ]
  edge [
    source 107
    target 556
    kind "relation"
    relation "mentions that pa told them aunt tidman has known troubles"
    weight 1
  ]
  edge [
    source 107
    target 704
    kind "relation"
    relation "says they owe forty pounds unknown to pa | says they must get"
    weight 2
  ]
  edge [
    source 107
    target 757
    kind "relation"
    relation "says they only have fifteen and threepence of their own"
    weight 1
  ]
  edge [
    source 107
    target 491
    kind "relation"
    relation "asks georgiana if she knows something about"
    weight 1
  ]
  edge [
    source 107
    target 759
    kind "mentions"
  ]
  edge [
    source 107
    target 762
    kind "relation"
    relation "asks aunt georgiana if she knows about"
    weight 1
  ]
  edge [
    source 107
    target 760
    kind "relation"
    relation "requests dandy dick to win"
    weight 1
  ]
  edge [
    source 107
    target 761
    kind "relation"
    relation "wants to win"
    weight 1
  ]
  edge [
    source 107
    target 765
    kind "relation"
    relation "is frightened by"
    weight 1
  ]
  edge [
    source 107
    target 766
    kind "mentions"
  ]
  edge [
    source 107
    target 446
    kind "relation"
    relation "is playing | sits at"
    weight 3
  ]
  edge [
    source 107
    target 770
    kind "mentions"
  ]
  edge [
    source 107
    target 773
    kind "relation"
    relation "wants"
    weight 1
  ]
  edge [
    source 107
    target 775
    kind "relation"
    relation "wants"
    weight 1
  ]
  edge [
    source 107
    target 777
    kind "relation"
    relation "says the cook never can manage"
    weight 1
  ]
  edge [
    source 107
    target 793
    kind "relation"
    relation "agrees"
    weight 1
  ]
  edge [
    source 107
    target 795
    kind "mentions"
  ]
  edge [
    source 107
    target 797
    kind "mentions"
  ]
  edge [
    source 107
    target 804
    kind "mentions"
  ]
  edge [
    source 107
    target 809
    kind "mentions"
  ]
  edge [
    source 107
    target 796
    kind "relation"
    relation "says we should congratulate ourselves on"
    weight 1
  ]
  edge [
    source 107
    target 810
    kind "relation"
    relation "says we will exit through"
    weight 1
  ]
  edge [
    source 107
    target 811
    kind "mentions"
  ]
  edge [
    source 107
    target 705
    kind "relation"
    relation "says we enter again by | appears outside | looks in"
    weight 3
  ]
  edge [
    source 107
    target 817
    kind "mentions"
  ]
  edge [
    source 107
    target 820
    kind "mentions"
  ]
  edge [
    source 107
    target 823
    kind "relation"
    relation "considers"
    weight 1
  ]
  edge [
    source 107
    target 824
    kind "mentions"
  ]
  edge [
    source 107
    target 589
    kind "relation"
    relation "thinks it is poor | says they must not spoil | sees | mentions through the kindness of"
    weight 4
  ]
  edge [
    source 107
    target 831
    kind "mentions"
  ]
  edge [
    source 107
    target 833
    kind "mentions"
  ]
  edge [
    source 107
    target 855
    kind "mentions"
  ]
  edge [
    source 107
    target 859
    kind "relation"
    relation "mentions that mr. darbey has brought"
    weight 1
  ]
  edge [
    source 107
    target 870
    kind "mentions"
  ]
  edge [
    source 107
    target 135
    kind "relation"
    relation "says never mind | follows mr. darbey across the room | has never thought of marriage seriously | says people never think of marriage seriously until they are married"
    weight 4
  ]
  edge [
    source 107
    target 879
    kind "relation"
    relation "agrees to accompany"
    weight 1
  ]
  edge [
    source 107
    target 882
    kind "mentions"
  ]
  edge [
    source 107
    target 895
    kind "mentions"
  ]
  edge [
    source 107
    target 904
    kind "mentions"
  ]
  edge [
    source 107
    target 917
    kind "mentions"
  ]
  edge [
    source 107
    target 921
    kind "mentions"
  ]
  edge [
    source 107
    target 938
    kind "mentions"
  ]
  edge [
    source 107
    target 940
    kind "mentions"
  ]
  edge [
    source 107
    target 962
    kind "mentions"
  ]
  edge [
    source 107
    target 977
    kind "mentions"
  ]
  edge [
    source 107
    target 277
    kind "relation"
    relation "tells | exclaims they have saved"
    weight 2
  ]
  edge [
    source 107
    target 984
    kind "relation"
    relation "notices"
    weight 1
  ]
  edge [
    source 107
    target 1297
    kind "mentions"
  ]
  edge [
    source 107
    target 1302
    kind "relation"
    relation "says there will be no ball"
    weight 1
  ]
  edge [
    source 107
    target 1307
    kind "mentions"
  ]
  edge [
    source 107
    target 1322
    kind "relation"
    relation "will try to borrow"
    weight 1
  ]
  edge [
    source 107
    target 1308
    kind "relation"
    relation "hates"
    weight 1
  ]
  edge [
    source 107
    target 1323
    kind "relation"
    relation "wishes"
    weight 1
  ]
  edge [
    source 107
    target 1317
    kind "relation"
    relation "wishes"
    weight 1
  ]
  edge [
    source 107
    target 1333
    kind "mentions"
  ]
  edge [
    source 107
    target 1347
    kind "mentions"
  ]
  edge [
    source 107
    target 1352
    kind "mentions"
  ]
  edge [
    source 107
    target 1356
    kind "mentions"
  ]
  edge [
    source 107
    target 1369
    kind "relation"
    relation "protests against"
    weight 1
  ]
  edge [
    source 107
    target 1370
    kind "relation"
    relation "believes"
    weight 1
  ]
  edge [
    source 107
    target 1372
    kind "relation"
    relation "calls papa"
    weight 1
  ]
  edge [
    source 107
    target 1376
    kind "relation"
    relation "pleads to spare"
    weight 1
  ]
  edge [
    source 107
    target 1377
    kind "relation"
    relation "insists no harm shall come to"
    weight 1
  ]
  edge [
    source 107
    target 1380
    kind "relation"
    relation "demands to stop | orders to stop | threatens to have major tarver ring for help"
    weight 4
  ]
  edge [
    source 107
    target 1382
    kind "mentions"
  ]
  edge [
    source 107
    target 1397
    kind "relation"
    relation "falls into"
    weight 1
  ]
  edge [
    source 107
    target 1851
    kind "mentions"
  ]
  edge [
    source 107
    target 1856
    kind "mentions"
  ]
  edge [
    source 107
    target 1858
    kind "mentions"
  ]
  edge [
    source 107
    target 1859
    kind "relation"
    relation "wants salome to have"
    weight 1
  ]
  edge [
    source 107
    target 1864
    kind "mentions"
  ]
  edge [
    source 107
    target 1866
    kind "mentions"
  ]
  edge [
    source 107
    target 1875
    kind "mentions"
  ]
  edge [
    source 107
    target 1880
    kind "mentions"
  ]
  edge [
    source 107
    target 1881
    kind "relation"
    relation "says her age is very small and not worth mentioning"
    weight 1
  ]
  edge [
    source 107
    target 1454
    kind "relation"
    relation "suggests remaining friends and occasionally corresponding | says it is impracticable to remain friends and correspond"
    weight 2
  ]
  edge [
    source 107
    target 1884
    kind "mentions"
  ]
  edge [
    source 107
    target 1535
    kind "relation"
    relation "requests"
    weight 1
  ]
  edge [
    source 107
    target 1885
    kind "relation"
    relation "considers"
    weight 1
  ]
  edge [
    source 107
    target 1886
    kind "relation"
    relation "considers"
    weight 1
  ]
  edge [
    source 107
    target 1893
    kind "mentions"
  ]
  edge [
    source 107
    target 512
    kind "relation"
    relation "sees"
    weight 1
  ]
  edge [
    source 107
    target 1896
    kind "relation"
    relation "calls"
    weight 1
  ]
  edge [
    source 107
    target 1996
    kind "mentions"
  ]
  edge [
    source 107
    target 649
    kind "relation"
    relation "sees"
    weight 1
  ]
  edge [
    source 107
    target 1999
    kind "relation"
    relation "is annoyed that"
    weight 1
  ]
  edge [
    source 107
    target 2000
    kind "relation"
    relation "asks where"
    weight 1
  ]
  edge [
    source 107
    target 2002
    kind "mentions"
  ]
  edge [
    source 107
    target 2008
    kind "mentions"
  ]
  edge [
    source 107
    target 2010
    kind "relation"
    relation "grabs"
    weight 1
  ]
  edge [
    source 107
    target 2011
    kind "relation"
    relation "declares"
    weight 1
  ]
  edge [
    source 107
    target 2013
    kind "mentions"
  ]
  edge [
    source 107
    target 2018
    kind "mentions"
  ]
  edge [
    source 107
    target 2020
    kind "mentions"
  ]
  edge [
    source 107
    target 2043
    kind "mentions"
  ]
  edge [
    source 107
    target 2048
    kind "mentions"
  ]
  edge [
    source 107
    target 2054
    kind "relation"
    relation "enters and stands in the recess"
    weight 1
  ]
  edge [
    source 107
    target 2077
    kind "mentions"
  ]
  edge [
    source 107
    target 2086
    kind "mentions"
  ]
  edge [
    source 107
    target 2094
    kind "relation"
    relation "claims the dean has"
    weight 1
  ]
  edge [
    source 107
    target 2095
    kind "relation"
    relation "claims the dean has"
    weight 1
  ]
  edge [
    source 107
    target 2098
    kind "mentions"
  ]
  edge [
    source 107
    target 2102
    kind "relation"
    relation "states that"
    weight 1
  ]
  edge [
    source 107
    target 2115
    kind "mentions"
  ]
  edge [
    source 107
    target 2118
    kind "mentions"
  ]
  edge [
    source 109
    target 1856
    kind "mentions"
  ]
  edge [
    source 110
    target 244
    kind "mentions"
  ]
  edge [
    source 110
    target 359
    kind "mentions"
  ]
  edge [
    source 110
    target 388
    kind "mentions"
  ]
  edge [
    source 110
    target 396
    kind "mentions"
  ]
  edge [
    source 110
    target 425
    kind "mentions"
  ]
  edge [
    source 110
    target 427
    kind "relation"
    relation "walk as if going out through"
    weight 1
  ]
  edge [
    source 110
    target 855
    kind "mentions"
  ]
  edge [
    source 110
    target 265
    kind "relation"
    relation "walks into"
    weight 1
  ]
  edge [
    source 110
    target 940
    kind "mentions"
  ]
  edge [
    source 110
    target 977
    kind "mentions"
  ]
  edge [
    source 110
    target 1223
    kind "mentions"
  ]
  edge [
    source 110
    target 1244
    kind "mentions"
  ]
  edge [
    source 110
    target 1875
    kind "mentions"
  ]
  edge [
    source 111
    target 701
    kind "mentions"
  ]
  edge [
    source 111
    target 850
    kind "mentions"
  ]
  edge [
    source 111
    target 855
    kind "mentions"
  ]
  edge [
    source 111
    target 1117
    kind "mentions"
  ]
  edge [
    source 111
    target 1297
    kind "mentions"
  ]
  edge [
    source 111
    target 649
    kind "relation"
    relation "sees people moving"
    weight 1
  ]
  edge [
    source 122
    target 263
    kind "mentions"
  ]
  edge [
    source 122
    target 329
    kind "mentions"
  ]
  edge [
    source 122
    target 265
    kind "relation"
    relation "sinks onto"
    weight 2
  ]
  edge [
    source 122
    target 766
    kind "mentions"
  ]
  edge [
    source 122
    target 770
    kind "mentions"
  ]
  edge [
    source 122
    target 870
    kind "mentions"
  ]
  edge [
    source 122
    target 1053
    kind "mentions"
  ]
  edge [
    source 122
    target 1258
    kind "mentions"
  ]
  edge [
    source 122
    target 649
    kind "relation"
    relation "enters quietly | is smoking"
    weight 2
  ]
  edge [
    source 133
    target 134
    kind "from_chunk"
  ]
  edge [
    source 133
    target 151
    kind "from_chunk"
  ]
  edge [
    source 134
    target 135
    kind "mentions"
  ]
  edge [
    source 134
    target 136
    kind "mentions"
  ]
  edge [
    source 134
    target 137
    kind "mentions"
  ]
  edge [
    source 134
    target 138
    kind "mentions"
  ]
  edge [
    source 134
    target 139
    kind "mentions"
  ]
  edge [
    source 134
    target 140
    kind "mentions"
  ]
  edge [
    source 134
    target 141
    kind "mentions"
  ]
  edge [
    source 134
    target 142
    kind "mentions"
  ]
  edge [
    source 134
    target 143
    kind "mentions"
  ]
  edge [
    source 134
    target 144
    kind "mentions"
  ]
  edge [
    source 134
    target 145
    kind "mentions"
  ]
  edge [
    source 134
    target 146
    kind "mentions"
  ]
  edge [
    source 134
    target 147
    kind "mentions"
  ]
  edge [
    source 134
    target 148
    kind "mentions"
  ]
  edge [
    source 134
    target 149
    kind "mentions"
  ]
  edge [
    source 134
    target 150
    kind "mentions"
  ]
  edge [
    source 134
    target 2219
    kind "summarizes"
  ]
  edge [
    source 135
    target 144
    kind "relation"
    relation "is an officer"
    weight 1
  ]
  edge [
    source 135
    target 349
    kind "mentions"
  ]
  edge [
    source 135
    target 804
    kind "mentions"
  ]
  edge [
    source 135
    target 806
    kind "relation"
    relation "was about to make"
    weight 1
  ]
  edge [
    source 135
    target 807
    kind "relation"
    relation "shied at"
    weight 1
  ]
  edge [
    source 135
    target 828
    kind "mentions"
  ]
  edge [
    source 135
    target 831
    kind "mentions"
  ]
  edge [
    source 135
    target 870
    kind "mentions"
  ]
  edge [
    source 135
    target 1875
    kind "mentions"
  ]
  edge [
    source 135
    target 1880
    kind "mentions"
  ]
  edge [
    source 135
    target 1881
    kind "relation"
    relation "asks sheba what her age is"
    weight 1
  ]
  edge [
    source 135
    target 1454
    kind "relation"
    relation "agrees to remain friends if sheba insists"
    weight 1
  ]
  edge [
    source 135
    target 2174
    kind "mentions"
  ]
  edge [
    source 135
    target 2176
    kind "relation"
    relation "followed by"
    weight 1
  ]
  edge [
    source 136
    target 137
    kind "relation"
    relation "is promoted by"
    weight 1
  ]
  edge [
    source 138
    target 1333
    kind "mentions"
  ]
  edge [
    source 138
    target 1334
    kind "relation"
    relation "arrived at"
    weight 1
  ]
  edge [
    source 138
    target 1144
    kind "relation"
    relation "had a notice on front door"
    weight 1
  ]
  edge [
    source 139
    target 797
    kind "mentions"
  ]
  edge [
    source 139
    target 798
    kind "relation"
    relation "was as lively as"
    weight 1
  ]
  edge [
    source 139
    target 799
    kind "relation"
    relation "has"
    weight 1
  ]
  edge [
    source 140
    target 142
    kind "relation"
    relation "is actually"
    weight 1
  ]
  edge [
    source 141
    target 151
    kind "mentions"
  ]
  edge [
    source 142
    target 143
    kind "relation"
    relation "calls himself"
    weight 1
  ]
  edge [
    source 149
    target 482
    kind "mentions"
  ]
  edge [
    source 149
    target 1246
    kind "mentions"
  ]
  edge [
    source 151
    target 152
    kind "mentions"
  ]
  edge [
    source 151
    target 2219
    kind "summarizes"
  ]
  edge [
    source 153
    target 154
    kind "from_chunk"
  ]
  edge [
    source 153
    target 173
    kind "from_chunk"
  ]
  edge [
    source 154
    target 155
    kind "mentions"
  ]
  edge [
    source 154
    target 156
    kind "mentions"
  ]
  edge [
    source 154
    target 157
    kind "mentions"
  ]
  edge [
    source 154
    target 158
    kind "mentions"
  ]
  edge [
    source 154
    target 159
    kind "mentions"
  ]
  edge [
    source 154
    target 160
    kind "mentions"
  ]
  edge [
    source 154
    target 161
    kind "mentions"
  ]
  edge [
    source 154
    target 162
    kind "mentions"
  ]
  edge [
    source 154
    target 163
    kind "mentions"
  ]
  edge [
    source 154
    target 164
    kind "mentions"
  ]
  edge [
    source 154
    target 165
    kind "mentions"
  ]
  edge [
    source 154
    target 166
    kind "mentions"
  ]
  edge [
    source 154
    target 167
    kind "mentions"
  ]
  edge [
    source 154
    target 168
    kind "mentions"
  ]
  edge [
    source 154
    target 169
    kind "mentions"
  ]
  edge [
    source 154
    target 170
    kind "mentions"
  ]
  edge [
    source 154
    target 171
    kind "mentions"
  ]
  edge [
    source 154
    target 172
    kind "mentions"
  ]
  edge [
    source 154
    target 2231
    kind "summarizes"
  ]
  edge [
    source 155
    target 166
    kind "relation"
    relation "were marked"
    weight 1
  ]
  edge [
    source 157
    target 158
    kind "relation"
    relation "is the costumier to"
    weight 1
  ]
  edge [
    source 157
    target 173
    kind "mentions"
  ]
  edge [
    source 157
    target 2002
    kind "mentions"
  ]
  edge [
    source 157
    target 159
    kind "relation"
    relation "is a costumier to the queen"
    weight 1
  ]
  edge [
    source 157
    target 2013
    kind "mentions"
  ]
  edge [
    source 157
    target 2018
    kind "mentions"
  ]
  edge [
    source 157
    target 2003
    kind "relation"
    relation "is a"
    weight 1
  ]
  edge [
    source 158
    target 244
    kind "mentions"
  ]
  edge [
    source 159
    target 173
    kind "mentions"
  ]
  edge [
    source 159
    target 2002
    kind "mentions"
  ]
  edge [
    source 160
    target 171
    kind "relation"
    relation "is from"
    weight 2
  ]
  edge [
    source 160
    target 163
    kind "relation"
    relation "costs"
    weight 2
  ]
  edge [
    source 160
    target 173
    kind "mentions"
  ]
  edge [
    source 161
    target 173
    kind "mentions"
  ]
  edge [
    source 161
    target 2013
    kind "mentions"
  ]
  edge [
    source 161
    target 2018
    kind "mentions"
  ]
  edge [
    source 162
    target 173
    kind "mentions"
  ]
  edge [
    source 163
    target 173
    kind "mentions"
  ]
  edge [
    source 164
    target 172
    kind "relation"
    relation "costs"
    weight 2
  ]
  edge [
    source 164
    target 173
    kind "mentions"
  ]
  edge [
    source 169
    target 921
    kind "mentions"
  ]
  edge [
    source 169
    target 578
    kind "relation"
    relation "insists she is not"
    weight 2
  ]
  edge [
    source 169
    target 938
    kind "mentions"
  ]
  edge [
    source 169
    target 1681
    kind "mentions"
  ]
  edge [
    source 171
    target 173
    kind "mentions"
  ]
  edge [
    source 172
    target 173
    kind "mentions"
  ]
  edge [
    source 173
    target 174
    kind "mentions"
  ]
  edge [
    source 173
    target 175
    kind "mentions"
  ]
  edge [
    source 173
    target 2231
    kind "summarizes"
  ]
  edge [
    source 176
    target 177
    kind "from_chunk"
  ]
  edge [
    source 176
    target 203
    kind "from_chunk"
  ]
  edge [
    source 177
    target 178
    kind "mentions"
  ]
  edge [
    source 177
    target 179
    kind "mentions"
  ]
  edge [
    source 177
    target 180
    kind "mentions"
  ]
  edge [
    source 177
    target 181
    kind "mentions"
  ]
  edge [
    source 177
    target 182
    kind "mentions"
  ]
  edge [
    source 177
    target 183
    kind "mentions"
  ]
  edge [
    source 177
    target 184
    kind "mentions"
  ]
  edge [
    source 177
    target 185
    kind "mentions"
  ]
  edge [
    source 177
    target 186
    kind "mentions"
  ]
  edge [
    source 177
    target 187
    kind "mentions"
  ]
  edge [
    source 177
    target 188
    kind "mentions"
  ]
  edge [
    source 177
    target 189
    kind "mentions"
  ]
  edge [
    source 177
    target 190
    kind "mentions"
  ]
  edge [
    source 177
    target 191
    kind "mentions"
  ]
  edge [
    source 177
    target 192
    kind "mentions"
  ]
  edge [
    source 177
    target 193
    kind "mentions"
  ]
  edge [
    source 177
    target 194
    kind "mentions"
  ]
  edge [
    source 177
    target 195
    kind "mentions"
  ]
  edge [
    source 177
    target 196
    kind "mentions"
  ]
  edge [
    source 177
    target 197
    kind "mentions"
  ]
  edge [
    source 177
    target 198
    kind "mentions"
  ]
  edge [
    source 177
    target 199
    kind "mentions"
  ]
  edge [
    source 177
    target 200
    kind "mentions"
  ]
  edge [
    source 177
    target 201
    kind "mentions"
  ]
  edge [
    source 177
    target 202
    kind "mentions"
  ]
  edge [
    source 177
    target 2216
    kind "summarizes"
  ]
  edge [
    source 178
    target 179
    kind "relation"
    relation "is for"
    weight 1
  ]
  edge [
    source 178
    target 180
    kind "relation"
    relation "costs"
    weight 1
  ]
  edge [
    source 178
    target 188
    kind "relation"
    relation "is part of"
    weight 1
  ]
  edge [
    source 181
    target 185
    kind "relation"
    relation "costs"
    weight 1
  ]
  edge [
    source 181
    target 188
    kind "relation"
    relation "is part of"
    weight 1
  ]
  edge [
    source 186
    target 187
    kind "relation"
    relation "costs"
    weight 1
  ]
  edge [
    source 186
    target 188
    kind "relation"
    relation "is part of"
    weight 1
  ]
  edge [
    source 188
    target 189
    kind "relation"
    relation "are mislaid"
    weight 1
  ]
  edge [
    source 191
    target 203
    kind "mentions"
  ]
  edge [
    source 191
    target 219
    kind "mentions"
  ]
  edge [
    source 191
    target 283
    kind "mentions"
  ]
  edge [
    source 191
    target 318
    kind "mentions"
  ]
  edge [
    source 191
    target 319
    kind "relation"
    relation "leaves at"
    weight 1
  ]
  edge [
    source 191
    target 329
    kind "mentions"
  ]
  edge [
    source 191
    target 422
    kind "mentions"
  ]
  edge [
    source 191
    target 434
    kind "mentions"
  ]
  edge [
    source 191
    target 752
    kind "mentions"
  ]
  edge [
    source 191
    target 833
    kind "mentions"
  ]
  edge [
    source 191
    target 895
    kind "mentions"
  ]
  edge [
    source 191
    target 704
    kind "relation"
    relation "is always dreadfully in the way"
    weight 1
  ]
  edge [
    source 191
    target 977
    kind "mentions"
  ]
  edge [
    source 191
    target 453
    kind "relation"
    relation "express concern for"
    weight 1
  ]
  edge [
    source 191
    target 1356
    kind "mentions"
  ]
  edge [
    source 191
    target 1382
    kind "mentions"
  ]
  edge [
    source 191
    target 1858
    kind "mentions"
  ]
  edge [
    source 191
    target 1887
    kind "mentions"
  ]
  edge [
    source 191
    target 1891
    kind "mentions"
  ]
  edge [
    source 191
    target 264
    kind "relation"
    relation "suggests not to condemn"
    weight 1
  ]
  edge [
    source 191
    target 1996
    kind "mentions"
  ]
  edge [
    source 191
    target 2008
    kind "mentions"
  ]
  edge [
    source 191
    target 2020
    kind "mentions"
  ]
  edge [
    source 191
    target 2086
    kind "mentions"
  ]
  edge [
    source 192
    target 203
    kind "mentions"
  ]
  edge [
    source 193
    target 203
    kind "mentions"
  ]
  edge [
    source 194
    target 203
    kind "mentions"
  ]
  edge [
    source 194
    target 428
    kind "mentions"
  ]
  edge [
    source 195
    target 203
    kind "mentions"
  ]
  edge [
    source 196
    target 203
    kind "mentions"
  ]
  edge [
    source 203
    target 204
    kind "mentions"
  ]
  edge [
    source 203
    target 205
    kind "mentions"
  ]
  edge [
    source 203
    target 206
    kind "mentions"
  ]
  edge [
    source 203
    target 207
    kind "mentions"
  ]
  edge [
    source 203
    target 208
    kind "mentions"
  ]
  edge [
    source 203
    target 209
    kind "mentions"
  ]
  edge [
    source 203
    target 210
    kind "mentions"
  ]
  edge [
    source 203
    target 211
    kind "mentions"
  ]
  edge [
    source 203
    target 212
    kind "mentions"
  ]
  edge [
    source 203
    target 213
    kind "mentions"
  ]
  edge [
    source 203
    target 214
    kind "mentions"
  ]
  edge [
    source 203
    target 215
    kind "mentions"
  ]
  edge [
    source 203
    target 216
    kind "mentions"
  ]
  edge [
    source 203
    target 217
    kind "mentions"
  ]
  edge [
    source 203
    target 2216
    kind "summarizes"
  ]
  edge [
    source 204
    target 1906
    kind "mentions"
  ]
  edge [
    source 209
    target 2020
    kind "mentions"
  ]
  edge [
    source 218
    target 219
    kind "from_chunk"
  ]
  edge [
    source 218
    target 241
    kind "from_chunk"
  ]
  edge [
    source 219
    target 220
    kind "mentions"
  ]
  edge [
    source 219
    target 221
    kind "mentions"
  ]
  edge [
    source 219
    target 222
    kind "mentions"
  ]
  edge [
    source 219
    target 223
    kind "mentions"
  ]
  edge [
    source 219
    target 224
    kind "mentions"
  ]
  edge [
    source 219
    target 225
    kind "mentions"
  ]
  edge [
    source 219
    target 226
    kind "mentions"
  ]
  edge [
    source 219
    target 227
    kind "mentions"
  ]
  edge [
    source 219
    target 228
    kind "mentions"
  ]
  edge [
    source 219
    target 229
    kind "mentions"
  ]
  edge [
    source 219
    target 230
    kind "mentions"
  ]
  edge [
    source 219
    target 231
    kind "mentions"
  ]
  edge [
    source 219
    target 232
    kind "mentions"
  ]
  edge [
    source 219
    target 233
    kind "mentions"
  ]
  edge [
    source 219
    target 234
    kind "mentions"
  ]
  edge [
    source 219
    target 235
    kind "mentions"
  ]
  edge [
    source 219
    target 236
    kind "mentions"
  ]
  edge [
    source 219
    target 237
    kind "mentions"
  ]
  edge [
    source 219
    target 238
    kind "mentions"
  ]
  edge [
    source 219
    target 239
    kind "mentions"
  ]
  edge [
    source 219
    target 240
    kind "mentions"
  ]
  edge [
    source 219
    target 2232
    kind "summarizes"
  ]
  edge [
    source 221
    target 422
    kind "mentions"
  ]
  edge [
    source 224
    target 653
    kind "mentions"
  ]
  edge [
    source 225
    target 241
    kind "mentions"
  ]
  edge [
    source 226
    target 241
    kind "mentions"
  ]
  edge [
    source 227
    target 239
    kind "relation"
    relation "clutch each other's hands"
    weight 2
  ]
  edge [
    source 227
    target 241
    kind "mentions"
  ]
  edge [
    source 227
    target 425
    kind "mentions"
  ]
  edge [
    source 227
    target 1749
    kind "mentions"
  ]
  edge [
    source 227
    target 1960
    kind "mentions"
  ]
  edge [
    source 227
    target 2020
    kind "mentions"
  ]
  edge [
    source 227
    target 2029
    kind "relation"
    relation "are instructed to go to"
    weight 1
  ]
  edge [
    source 227
    target 2030
    kind "relation"
    relation "have their blinds drawn"
    weight 1
  ]
  edge [
    source 228
    target 241
    kind "mentions"
  ]
  edge [
    source 237
    target 241
    kind "mentions"
  ]
  edge [
    source 237
    target 977
    kind "mentions"
  ]
  edge [
    source 237
    target 1278
    kind "mentions"
  ]
  edge [
    source 237
    target 1297
    kind "mentions"
  ]
  edge [
    source 237
    target 649
    kind "relation"
    relation "decides to leave and watch"
    weight 1
  ]
  edge [
    source 237
    target 1345
    kind "mentions"
  ]
  edge [
    source 237
    target 1347
    kind "mentions"
  ]
  edge [
    source 237
    target 578
    kind "relation"
    relation "enters | enters excitedly"
    weight 2
  ]
  edge [
    source 237
    target 1407
    kind "mentions"
  ]
  edge [
    source 237
    target 1133
    kind "relation"
    relation "is partly furnished as"
    weight 1
  ]
  edge [
    source 237
    target 1388
    kind "relation"
    relation "is partly furnished as"
    weight 1
  ]
  edge [
    source 237
    target 1412
    kind "relation"
    relation "is located at"
    weight 1
  ]
  edge [
    source 237
    target 1662
    kind "mentions"
  ]
  edge [
    source 237
    target 1893
    kind "mentions"
  ]
  edge [
    source 238
    target 241
    kind "mentions"
  ]
  edge [
    source 239
    target 241
    kind "mentions"
  ]
  edge [
    source 240
    target 241
    kind "mentions"
  ]
  edge [
    source 241
    target 242
    kind "mentions"
  ]
  edge [
    source 241
    target 2232
    kind "summarizes"
  ]
  edge [
    source 243
    target 244
    kind "from_chunk"
  ]
  edge [
    source 244
    target 245
    kind "mentions"
  ]
  edge [
    source 244
    target 246
    kind "mentions"
  ]
  edge [
    source 244
    target 247
    kind "mentions"
  ]
  edge [
    source 244
    target 248
    kind "mentions"
  ]
  edge [
    source 244
    target 249
    kind "mentions"
  ]
  edge [
    source 244
    target 2215
    kind "summarizes"
  ]
  edge [
    source 245
    target 1851
    kind "mentions"
  ]
  edge [
    source 245
    target 1856
    kind "mentions"
  ]
  edge [
    source 246
    target 800
    kind "mentions"
  ]
  edge [
    source 246
    target 801
    kind "relation"
    relation "has no liver"
    weight 1
  ]
  edge [
    source 246
    target 802
    kind "mentions"
  ]
  edge [
    source 246
    target 803
    kind "relation"
    relation "might have spoken about"
    weight 1
  ]
  edge [
    source 246
    target 1307
    kind "mentions"
  ]
  edge [
    source 248
    target 251
    kind "mentions"
  ]
  edge [
    source 250
    target 251
    kind "from_chunk"
  ]
  edge [
    source 250
    target 263
    kind "from_chunk"
  ]
  edge [
    source 251
    target 252
    kind "mentions"
  ]
  edge [
    source 251
    target 253
    kind "mentions"
  ]
  edge [
    source 251
    target 254
    kind "mentions"
  ]
  edge [
    source 251
    target 255
    kind "mentions"
  ]
  edge [
    source 251
    target 256
    kind "mentions"
  ]
  edge [
    source 251
    target 257
    kind "mentions"
  ]
  edge [
    source 251
    target 258
    kind "mentions"
  ]
  edge [
    source 251
    target 259
    kind "mentions"
  ]
  edge [
    source 251
    target 260
    kind "mentions"
  ]
  edge [
    source 251
    target 261
    kind "mentions"
  ]
  edge [
    source 251
    target 262
    kind "mentions"
  ]
  edge [
    source 251
    target 2215
    kind "summarizes"
  ]
  edge [
    source 258
    target 882
    kind "mentions"
  ]
  edge [
    source 258
    target 578
    kind "relation"
    relation "thinks george is not in a bad box"
    weight 1
  ]
  edge [
    source 258
    target 1339
    kind "mentions"
  ]
  edge [
    source 258
    target 265
    kind "relation"
    relation "took the address of"
    weight 1
  ]
  edge [
    source 258
    target 1340
    kind "relation"
    relation "suggested calling again on"
    weight 1
  ]
  edge [
    source 258
    target 1342
    kind "mentions"
  ]
  edge [
    source 263
    target 264
    kind "mentions"
  ]
  edge [
    source 263
    target 265
    kind "mentions"
  ]
  edge [
    source 263
    target 266
    kind "mentions"
  ]
  edge [
    source 263
    target 267
    kind "mentions"
  ]
  edge [
    source 263
    target 268
    kind "mentions"
  ]
  edge [
    source 263
    target 269
    kind "mentions"
  ]
  edge [
    source 263
    target 270
    kind "mentions"
  ]
  edge [
    source 263
    target 271
    kind "mentions"
  ]
  edge [
    source 263
    target 272
    kind "mentions"
  ]
  edge [
    source 263
    target 273
    kind "mentions"
  ]
  edge [
    source 263
    target 274
    kind "mentions"
  ]
  edge [
    source 263
    target 275
    kind "mentions"
  ]
  edge [
    source 263
    target 276
    kind "mentions"
  ]
  edge [
    source 263
    target 277
    kind "mentions"
  ]
  edge [
    source 263
    target 278
    kind "mentions"
  ]
  edge [
    source 263
    target 279
    kind "mentions"
  ]
  edge [
    source 263
    target 280
    kind "mentions"
  ]
  edge [
    source 263
    target 281
    kind "mentions"
  ]
  edge [
    source 263
    target 2217
    kind "summarizes"
  ]
  edge [
    source 264
    target 272
    kind "relation"
    relation "says"
    weight 1
  ]
  edge [
    source 264
    target 275
    kind "relation"
    relation "calls it"
    weight 1
  ]
  edge [
    source 264
    target 279
    kind "relation"
    relation "rises and puts"
    weight 1
  ]
  edge [
    source 264
    target 281
    kind "relation"
    relation "says"
    weight 1
  ]
  edge [
    source 264
    target 283
    kind "mentions"
  ]
  edge [
    source 264
    target 265
    kind "relation"
    relation "expresses contrition | is deeply upset to hear | says tarver's career is a burden to him | is in a scene with | glares at | says darbey always presumes with his fiddle when he is going to entertain | notes that his fiddle is never hoarse but he is sometimes | says tarver always tries to cut him out with his elderly chest c | will sing darbey off his legs | says tarver needn't bother himself | wants to garrote | has a bass string | is in an exceedingly critical condition"
    weight 13
  ]
  edge [
    source 264
    target 311
    kind "mentions"
  ]
  edge [
    source 264
    target 312
    kind "relation"
    relation "thanks on behalf of"
    weight 1
  ]
  edge [
    source 264
    target 317
    kind "relation"
    relation "believes there is a future if"
    weight 1
  ]
  edge [
    source 264
    target 323
    kind "mentions"
  ]
  edge [
    source 264
    target 326
    kind "relation"
    relation "has taken on responsibility for"
    weight 1
  ]
  edge [
    source 264
    target 327
    kind "relation"
    relation "is enjoying life when"
    weight 1
  ]
  edge [
    source 264
    target 329
    kind "mentions"
  ]
  edge [
    source 264
    target 359
    kind "mentions"
  ]
  edge [
    source 264
    target 380
    kind "relation"
    relation "agrees"
    weight 1
  ]
  edge [
    source 264
    target 362
    kind "relation"
    relation "says his idea was | suggests"
    weight 3
  ]
  edge [
    source 264
    target 384
    kind "relation"
    relation "notes"
    weight 1
  ]
  edge [
    source 264
    target 387
    kind "relation"
    relation "ends with"
    weight 1
  ]
  edge [
    source 264
    target 388
    kind "mentions"
  ]
  edge [
    source 264
    target 392
    kind "relation"
    relation "refers to"
    weight 1
  ]
  edge [
    source 264
    target 396
    kind "mentions"
  ]
  edge [
    source 264
    target 398
    kind "relation"
    relation "calls"
    weight 1
  ]
  edge [
    source 264
    target 402
    kind "mentions"
  ]
  edge [
    source 264
    target 409
    kind "relation"
    relation "calls the idea"
    weight 1
  ]
  edge [
    source 264
    target 413
    kind "relation"
    relation "asks"
    weight 1
  ]
  edge [
    source 264
    target 828
    kind "mentions"
  ]
  edge [
    source 264
    target 578
    kind "relation"
    relation "says would come out in spots like measles | recognized"
    weight 2
  ]
  edge [
    source 264
    target 844
    kind "mentions"
  ]
  edge [
    source 264
    target 849
    kind "mentions"
  ]
  edge [
    source 264
    target 855
    kind "mentions"
  ]
  edge [
    source 264
    target 857
    kind "relation"
    relation "says tarver ought to put it on the retired list"
    weight 1
  ]
  edge [
    source 264
    target 861
    kind "relation"
    relation "threw music out of the window"
    weight 1
  ]
  edge [
    source 264
    target 870
    kind "mentions"
  ]
  edge [
    source 264
    target 871
    kind "relation"
    relation "takes | opens"
    weight 2
  ]
  edge [
    source 264
    target 859
    kind "relation"
    relation "produces | tunes | returns with"
    weight 3
  ]
  edge [
    source 264
    target 860
    kind "relation"
    relation "produces"
    weight 1
  ]
  edge [
    source 264
    target 872
    kind "relation"
    relation "says his mother believes his bowing is like | explains that his mother has heard"
    weight 2
  ]
  edge [
    source 264
    target 876
    kind "relation"
    relation "begins to play"
    weight 1
  ]
  edge [
    source 264
    target 882
    kind "mentions"
  ]
  edge [
    source 264
    target 888
    kind "mentions"
  ]
  edge [
    source 264
    target 893
    kind "mentions"
  ]
  edge [
    source 264
    target 894
    kind "relation"
    relation "wonders how tarver's chest c likes"
    weight 1
  ]
  edge [
    source 264
    target 904
    kind "mentions"
  ]
  edge [
    source 264
    target 917
    kind "mentions"
  ]
  edge [
    source 264
    target 921
    kind "mentions"
  ]
  edge [
    source 264
    target 940
    kind "mentions"
  ]
  edge [
    source 264
    target 962
    kind "mentions"
  ]
  edge [
    source 264
    target 968
    kind "mentions"
  ]
  edge [
    source 264
    target 970
    kind "relation"
    relation "would have been present at"
    weight 1
  ]
  edge [
    source 264
    target 977
    kind "mentions"
  ]
  edge [
    source 264
    target 982
    kind "relation"
    relation "calls the evening"
    weight 1
  ]
  edge [
    source 264
    target 990
    kind "relation"
    relation "suggests meeting with"
    weight 1
  ]
  edge [
    source 264
    target 992
    kind "mentions"
  ]
  edge [
    source 264
    target 994
    kind "relation"
    relation "offers to get"
    weight 1
  ]
  edge [
    source 264
    target 996
    kind "mentions"
  ]
  edge [
    source 264
    target 1307
    kind "mentions"
  ]
  edge [
    source 264
    target 1326
    kind "relation"
    relation "enters with"
    weight 1
  ]
  edge [
    source 264
    target 1327
    kind "relation"
    relation "is dressed as"
    weight 1
  ]
  edge [
    source 264
    target 266
    kind "relation"
    relation "apologizes to"
    weight 1
  ]
  edge [
    source 264
    target 1330
    kind "mentions"
  ]
  edge [
    source 264
    target 1342
    kind "mentions"
  ]
  edge [
    source 264
    target 1343
    kind "relation"
    relation "says everything will be done | will wait on"
    weight 2
  ]
  edge [
    source 264
    target 1356
    kind "mentions"
  ]
  edge [
    source 264
    target 1373
    kind "relation"
    relation "states they are on duty"
    weight 1
  ]
  edge [
    source 264
    target 1382
    kind "mentions"
  ]
  edge [
    source 264
    target 1866
    kind "mentions"
  ]
  edge [
    source 264
    target 1867
    kind "relation"
    relation "took to"
    weight 1
  ]
  edge [
    source 264
    target 1868
    kind "relation"
    relation "described major tarver's love as"
    weight 1
  ]
  edge [
    source 264
    target 1884
    kind "mentions"
  ]
  edge [
    source 264
    target 1891
    kind "mentions"
  ]
  edge [
    source 264
    target 1890
    kind "relation"
    relation "says is shocking"
    weight 1
  ]
  edge [
    source 264
    target 1893
    kind "mentions"
  ]
  edge [
    source 264
    target 2118
    kind "mentions"
  ]
  edge [
    source 264
    target 2166
    kind "mentions"
  ]
  edge [
    source 265
    target 274
    kind "relation"
    relation "thinks it would be discourteous to"
    weight 1
  ]
  edge [
    source 265
    target 278
    kind "relation"
    relation "takes"
    weight 1
  ]
  edge [
    source 265
    target 270
    kind "relation"
    relation "expresses"
    weight 1
  ]
  edge [
    source 265
    target 283
    kind "mentions"
  ]
  edge [
    source 265
    target 299
    kind "mentions"
  ]
  edge [
    source 265
    target 289
    kind "relation"
    relation "planned to ride over after"
    weight 1
  ]
  edge [
    source 265
    target 290
    kind "relation"
    relation "intended to make"
    weight 1
  ]
  edge [
    source 265
    target 287
    kind "relation"
    relation "asked about | had the idea of"
    weight 2
  ]
  edge [
    source 265
    target 300
    kind "relation"
    relation "had the idea in"
    weight 1
  ]
  edge [
    source 265
    target 303
    kind "mentions"
  ]
  edge [
    source 265
    target 294
    kind "relation"
    relation "experiences alternating fits of"
    weight 1
  ]
  edge [
    source 265
    target 306
    kind "mentions"
  ]
  edge [
    source 265
    target 308
    kind "relation"
    relation "has a depression attack due to"
    weight 1
  ]
  edge [
    source 265
    target 309
    kind "relation"
    relation "experiences a severe attack of | feels"
    weight 2
  ]
  edge [
    source 265
    target 318
    kind "mentions"
  ]
  edge [
    source 265
    target 320
    kind "relation"
    relation "suggests arrival at"
    weight 1
  ]
  edge [
    source 265
    target 322
    kind "relation"
    relation "plans to be at house at"
    weight 1
  ]
  edge [
    source 265
    target 323
    kind "mentions"
  ]
  edge [
    source 265
    target 326
    kind "relation"
    relation "has a strange livah that caused"
    weight 1
  ]
  edge [
    source 265
    target 329
    kind "mentions"
  ]
  edge [
    source 265
    target 266
    kind "relation"
    relation "laughs convulsively | apologizes to | asked | was asked to smile"
    weight 4
  ]
  edge [
    source 265
    target 341
    kind "relation"
    relation "requests water with"
    weight 1
  ]
  edge [
    source 265
    target 359
    kind "mentions"
  ]
  edge [
    source 265
    target 376
    kind "relation"
    relation "asks"
    weight 1
  ]
  edge [
    source 265
    target 381
    kind "relation"
    relation "asks"
    weight 1
  ]
  edge [
    source 265
    target 382
    kind "relation"
    relation "notes"
    weight 1
  ]
  edge [
    source 265
    target 386
    kind "relation"
    relation "calls"
    weight 2
  ]
  edge [
    source 265
    target 388
    kind "mentions"
  ]
  edge [
    source 265
    target 391
    kind "relation"
    relation "is concerned about | is worried about"
    weight 2
  ]
  edge [
    source 265
    target 396
    kind "mentions"
  ]
  edge [
    source 265
    target 402
    kind "mentions"
  ]
  edge [
    source 265
    target 408
    kind "relation"
    relation "calls the idea"
    weight 1
  ]
  edge [
    source 265
    target 855
    kind "mentions"
  ]
  edge [
    source 265
    target 866
    kind "relation"
    relation "is excited when asked to sing"
    weight 1
  ]
  edge [
    source 265
    target 863
    kind "relation"
    relation "has music in"
    weight 1
  ]
  edge [
    source 265
    target 867
    kind "relation"
    relation "sings | says he has begun with | has begun with"
    weight 3
  ]
  edge [
    source 265
    target 870
    kind "mentions"
  ]
  edge [
    source 265
    target 876
    kind "relation"
    relation "re-enters triumphantly"
    weight 1
  ]
  edge [
    source 265
    target 877
    kind "relation"
    relation "tells salome his tones are like"
    weight 1
  ]
  edge [
    source 265
    target 878
    kind "relation"
    relation "says he is glad for"
    weight 1
  ]
  edge [
    source 265
    target 865
    kind "relation"
    relation "takes | opens"
    weight 2
  ]
  edge [
    source 265
    target 860
    kind "relation"
    relation "exclaims he has forgotten"
    weight 1
  ]
  edge [
    source 265
    target 882
    kind "mentions"
  ]
  edge [
    source 265
    target 888
    kind "mentions"
  ]
  edge [
    source 265
    target 893
    kind "mentions"
  ]
  edge [
    source 265
    target 904
    kind "mentions"
  ]
  edge [
    source 265
    target 917
    kind "mentions"
  ]
  edge [
    source 265
    target 921
    kind "mentions"
  ]
  edge [
    source 265
    target 940
    kind "mentions"
  ]
  edge [
    source 265
    target 962
    kind "mentions"
  ]
  edge [
    source 265
    target 956
    kind "relation"
    relation "says they are getting"
    weight 1
  ]
  edge [
    source 265
    target 977
    kind "mentions"
  ]
  edge [
    source 265
    target 988
    kind "relation"
    relation "calls the evening"
    weight 1
  ]
  edge [
    source 265
    target 1307
    kind "mentions"
  ]
  edge [
    source 265
    target 1326
    kind "relation"
    relation "enters with | is carrying"
    weight 2
  ]
  edge [
    source 265
    target 1327
    kind "relation"
    relation "is dressed as"
    weight 1
  ]
  edge [
    source 265
    target 1339
    kind "mentions"
  ]
  edge [
    source 265
    target 1345
    kind "mentions"
  ]
  edge [
    source 265
    target 1347
    kind "mentions"
  ]
  edge [
    source 265
    target 578
    kind "relation"
    relation "accuses | addresses"
    weight 2
  ]
  edge [
    source 265
    target 1348
    kind "relation"
    relation "encouraged"
    weight 1
  ]
  edge [
    source 265
    target 1351
    kind "relation"
    relation "took children out"
    weight 1
  ]
  edge [
    source 265
    target 1356
    kind "mentions"
  ]
  edge [
    source 265
    target 1357
    kind "relation"
    relation "is addressed as"
    weight 1
  ]
  edge [
    source 265
    target 1284
    kind "relation"
    relation "is described as"
    weight 1
  ]
  edge [
    source 265
    target 1382
    kind "mentions"
  ]
  edge [
    source 265
    target 1866
    kind "mentions"
  ]
  edge [
    source 265
    target 1714
    kind "relation"
    relation "failed to gain access to"
    weight 1
  ]
  edge [
    source 265
    target 1873
    kind "mentions"
  ]
  edge [
    source 265
    target 1625
    kind "relation"
    relation "loved for"
    weight 1
  ]
  edge [
    source 265
    target 1887
    kind "mentions"
  ]
  edge [
    source 265
    target 1889
    kind "relation"
    relation "expresses excitement about"
    weight 1
  ]
  edge [
    source 265
    target 1888
    kind "relation"
    relation "plans to buy"
    weight 1
  ]
  edge [
    source 265
    target 1891
    kind "mentions"
  ]
  edge [
    source 265
    target 2118
    kind "mentions"
  ]
  edge [
    source 266
    target 283
    kind "mentions"
  ]
  edge [
    source 266
    target 299
    kind "mentions"
  ]
  edge [
    source 266
    target 329
    kind "mentions"
  ]
  edge [
    source 266
    target 1307
    kind "mentions"
  ]
  edge [
    source 266
    target 1345
    kind "mentions"
  ]
  edge [
    source 266
    target 1866
    kind "mentions"
  ]
  edge [
    source 277
    target 977
    kind "mentions"
  ]
  edge [
    source 277
    target 1356
    kind "mentions"
  ]
  edge [
    source 277
    target 1382
    kind "mentions"
  ]
  edge [
    source 277
    target 1396
    kind "relation"
    relation "disappear through"
    weight 1
  ]
  edge [
    source 282
    target 283
    kind "from_chunk"
  ]
  edge [
    source 282
    target 299
    kind "from_chunk"
  ]
  edge [
    source 282
    target 303
    kind "from_chunk"
  ]
  edge [
    source 283
    target 284
    kind "mentions"
  ]
  edge [
    source 283
    target 285
    kind "mentions"
  ]
  edge [
    source 283
    target 286
    kind "mentions"
  ]
  edge [
    source 283
    target 287
    kind "mentions"
  ]
  edge [
    source 283
    target 288
    kind "mentions"
  ]
  edge [
    source 283
    target 289
    kind "mentions"
  ]
  edge [
    source 283
    target 290
    kind "mentions"
  ]
  edge [
    source 283
    target 291
    kind "mentions"
  ]
  edge [
    source 283
    target 292
    kind "mentions"
  ]
  edge [
    source 283
    target 293
    kind "mentions"
  ]
  edge [
    source 283
    target 294
    kind "mentions"
  ]
  edge [
    source 283
    target 295
    kind "mentions"
  ]
  edge [
    source 283
    target 296
    kind "mentions"
  ]
  edge [
    source 283
    target 297
    kind "mentions"
  ]
  edge [
    source 283
    target 298
    kind "mentions"
  ]
  edge [
    source 283
    target 2229
    kind "summarizes"
  ]
  edge [
    source 284
    target 770
    kind "mentions"
  ]
  edge [
    source 284
    target 578
    kind "relation"
    relation "says it is a relief to shake off"
    weight 1
  ]
  edge [
    source 284
    target 1330
    kind "mentions"
  ]
  edge [
    source 284
    target 1332
    kind "relation"
    relation "respond to"
    weight 1
  ]
  edge [
    source 284
    target 1337
    kind "mentions"
  ]
  edge [
    source 286
    target 299
    kind "mentions"
  ]
  edge [
    source 287
    target 299
    kind "mentions"
  ]
  edge [
    source 288
    target 299
    kind "mentions"
  ]
  edge [
    source 288
    target 1102
    kind "mentions"
  ]
  edge [
    source 288
    target 1105
    kind "relation"
    relation "contains"
    weight 1
  ]
  edge [
    source 288
    target 1106
    kind "relation"
    relation "contains"
    weight 1
  ]
  edge [
    source 288
    target 1108
    kind "relation"
    relation "contains"
    weight 1
  ]
  edge [
    source 288
    target 606
    kind "relation"
    relation "is labeled"
    weight 1
  ]
  edge [
    source 288
    target 728
    kind "relation"
    relation "is sent to"
    weight 1
  ]
  edge [
    source 288
    target 1109
    kind "mentions"
  ]
  edge [
    source 289
    target 299
    kind "mentions"
  ]
  edge [
    source 290
    target 299
    kind "mentions"
  ]
  edge [
    source 291
    target 299
    kind "mentions"
  ]
  edge [
    source 292
    target 303
    kind "mentions"
  ]
  edge [
    source 292
    target 359
    kind "mentions"
  ]
  edge [
    source 292
    target 388
    kind "mentions"
  ]
  edge [
    source 292
    target 396
    kind "mentions"
  ]
  edge [
    source 292
    target 800
    kind "mentions"
  ]
  edge [
    source 293
    target 303
    kind "mentions"
  ]
  edge [
    source 294
    target 303
    kind "mentions"
  ]
  edge [
    source 295
    target 303
    kind "mentions"
  ]
  edge [
    source 296
    target 303
    kind "mentions"
  ]
  edge [
    source 298
    target 2067
    kind "mentions"
  ]
  edge [
    source 299
    target 300
    kind "mentions"
  ]
  edge [
    source 299
    target 301
    kind "mentions"
  ]
  edge [
    source 299
    target 302
    kind "mentions"
  ]
  edge [
    source 299
    target 2229
    kind "summarizes"
  ]
  edge [
    source 303
    target 304
    kind "mentions"
  ]
  edge [
    source 303
    target 2229
    kind "summarizes"
  ]
  edge [
    source 305
    target 306
    kind "from_chunk"
  ]
  edge [
    source 305
    target 311
    kind "from_chunk"
  ]
  edge [
    source 305
    target 318
    kind "from_chunk"
  ]
  edge [
    source 305
    target 323
    kind "from_chunk"
  ]
  edge [
    source 306
    target 307
    kind "mentions"
  ]
  edge [
    source 306
    target 308
    kind "mentions"
  ]
  edge [
    source 306
    target 309
    kind "mentions"
  ]
  edge [
    source 306
    target 310
    kind "mentions"
  ]
  edge [
    source 306
    target 2217
    kind "summarizes"
  ]
  edge [
    source 309
    target 359
    kind "mentions"
  ]
  edge [
    source 311
    target 312
    kind "mentions"
  ]
  edge [
    source 311
    target 313
    kind "mentions"
  ]
  edge [
    source 311
    target 314
    kind "mentions"
  ]
  edge [
    source 311
    target 315
    kind "mentions"
  ]
  edge [
    source 311
    target 316
    kind "mentions"
  ]
  edge [
    source 311
    target 317
    kind "mentions"
  ]
  edge [
    source 311
    target 2229
    kind "summarizes"
  ]
  edge [
    source 312
    target 316
    kind "relation"
    relation "is described as"
    weight 1
  ]
  edge [
    source 312
    target 844
    kind "mentions"
  ]
  edge [
    source 312
    target 845
    kind "relation"
    relation "has"
    weight 1
  ]
  edge [
    source 315
    target 318
    kind "mentions"
  ]
  edge [
    source 315
    target 323
    kind "mentions"
  ]
  edge [
    source 318
    target 319
    kind "mentions"
  ]
  edge [
    source 318
    target 320
    kind "mentions"
  ]
  edge [
    source 318
    target 321
    kind "mentions"
  ]
  edge [
    source 318
    target 322
    kind "mentions"
  ]
  edge [
    source 318
    target 2229
    kind "summarizes"
  ]
  edge [
    source 319
    target 321
    kind "relation"
    relation "is quiet after"
    weight 1
  ]
  edge [
    source 321
    target 388
    kind "mentions"
  ]
  edge [
    source 321
    target 396
    kind "mentions"
  ]
  edge [
    source 321
    target 399
    kind "relation"
    relation "occurs in"
    weight 1
  ]
  edge [
    source 321
    target 809
    kind "mentions"
  ]
  edge [
    source 321
    target 977
    kind "mentions"
  ]
  edge [
    source 323
    target 324
    kind "mentions"
  ]
  edge [
    source 323
    target 325
    kind "mentions"
  ]
  edge [
    source 323
    target 326
    kind "mentions"
  ]
  edge [
    source 323
    target 327
    kind "mentions"
  ]
  edge [
    source 323
    target 2217
    kind "summarizes"
  ]
  edge [
    source 328
    target 329
    kind "from_chunk"
  ]
  edge [
    source 329
    target 330
    kind "mentions"
  ]
  edge [
    source 329
    target 331
    kind "mentions"
  ]
  edge [
    source 329
    target 332
    kind "mentions"
  ]
  edge [
    source 329
    target 333
    kind "mentions"
  ]
  edge [
    source 329
    target 334
    kind "mentions"
  ]
  edge [
    source 329
    target 335
    kind "mentions"
  ]
  edge [
    source 329
    target 336
    kind "mentions"
  ]
  edge [
    source 329
    target 337
    kind "mentions"
  ]
  edge [
    source 329
    target 338
    kind "mentions"
  ]
  edge [
    source 329
    target 339
    kind "mentions"
  ]
  edge [
    source 329
    target 340
    kind "mentions"
  ]
  edge [
    source 329
    target 341
    kind "mentions"
  ]
  edge [
    source 329
    target 342
    kind "mentions"
  ]
  edge [
    source 329
    target 343
    kind "mentions"
  ]
  edge [
    source 329
    target 344
    kind "mentions"
  ]
  edge [
    source 329
    target 345
    kind "mentions"
  ]
  edge [
    source 329
    target 346
    kind "mentions"
  ]
  edge [
    source 329
    target 347
    kind "mentions"
  ]
  edge [
    source 329
    target 2229
    kind "summarizes"
  ]
  edge [
    source 334
    target 1264
    kind "mentions"
  ]
  edge [
    source 334
    target 578
    kind "relation"
    relation "enters carrying | holds out | opens and hides behind | sobs violently"
    weight 4
  ]
  edge [
    source 334
    target 1267
    kind "mentions"
  ]
  edge [
    source 334
    target 1269
    kind "mentions"
  ]
  edge [
    source 334
    target 1273
    kind "mentions"
  ]
  edge [
    source 334
    target 649
    kind "relation"
    relation "stands over"
    weight 1
  ]
  edge [
    source 335
    target 703
    kind "mentions"
  ]
  edge [
    source 347
    target 402
    kind "mentions"
  ]
  edge [
    source 347
    target 428
    kind "mentions"
  ]
  edge [
    source 347
    target 2008
    kind "mentions"
  ]
  edge [
    source 348
    target 349
    kind "from_chunk"
  ]
  edge [
    source 349
    target 350
    kind "mentions"
  ]
  edge [
    source 349
    target 351
    kind "mentions"
  ]
  edge [
    source 349
    target 352
    kind "mentions"
  ]
  edge [
    source 349
    target 353
    kind "mentions"
  ]
  edge [
    source 349
    target 354
    kind "mentions"
  ]
  edge [
    source 349
    target 355
    kind "mentions"
  ]
  edge [
    source 349
    target 356
    kind "mentions"
  ]
  edge [
    source 349
    target 357
    kind "mentions"
  ]
  edge [
    source 349
    target 2215
    kind "summarizes"
  ]
  edge [
    source 355
    target 359
    kind "mentions"
  ]
  edge [
    source 355
    target 770
    kind "mentions"
  ]
  edge [
    source 355
    target 578
    kind "relation"
    relation "asks what was wrong with"
    weight 1
  ]
  edge [
    source 356
    target 977
    kind "mentions"
  ]
  edge [
    source 357
    target 402
    kind "mentions"
  ]
  edge [
    source 358
    target 359
    kind "from_chunk"
  ]
  edge [
    source 358
    target 388
    kind "from_chunk"
  ]
  edge [
    source 358
    target 396
    kind "from_chunk"
  ]
  edge [
    source 359
    target 360
    kind "mentions"
  ]
  edge [
    source 359
    target 361
    kind "mentions"
  ]
  edge [
    source 359
    target 362
    kind "mentions"
  ]
  edge [
    source 359
    target 363
    kind "mentions"
  ]
  edge [
    source 359
    target 364
    kind "mentions"
  ]
  edge [
    source 359
    target 365
    kind "mentions"
  ]
  edge [
    source 359
    target 366
    kind "mentions"
  ]
  edge [
    source 359
    target 367
    kind "mentions"
  ]
  edge [
    source 359
    target 368
    kind "mentions"
  ]
  edge [
    source 359
    target 369
    kind "mentions"
  ]
  edge [
    source 359
    target 370
    kind "mentions"
  ]
  edge [
    source 359
    target 371
    kind "mentions"
  ]
  edge [
    source 359
    target 372
    kind "mentions"
  ]
  edge [
    source 359
    target 373
    kind "mentions"
  ]
  edge [
    source 359
    target 374
    kind "mentions"
  ]
  edge [
    source 359
    target 375
    kind "mentions"
  ]
  edge [
    source 359
    target 376
    kind "mentions"
  ]
  edge [
    source 359
    target 377
    kind "mentions"
  ]
  edge [
    source 359
    target 378
    kind "mentions"
  ]
  edge [
    source 359
    target 379
    kind "mentions"
  ]
  edge [
    source 359
    target 380
    kind "mentions"
  ]
  edge [
    source 359
    target 381
    kind "mentions"
  ]
  edge [
    source 359
    target 382
    kind "mentions"
  ]
  edge [
    source 359
    target 383
    kind "mentions"
  ]
  edge [
    source 359
    target 384
    kind "mentions"
  ]
  edge [
    source 359
    target 385
    kind "mentions"
  ]
  edge [
    source 359
    target 386
    kind "mentions"
  ]
  edge [
    source 359
    target 387
    kind "mentions"
  ]
  edge [
    source 359
    target 2233
    kind "summarizes"
  ]
  edge [
    source 361
    target 388
    kind "mentions"
  ]
  edge [
    source 361
    target 396
    kind "mentions"
  ]
  edge [
    source 362
    target 388
    kind "mentions"
  ]
  edge [
    source 362
    target 396
    kind "mentions"
  ]
  edge [
    source 363
    target 977
    kind "mentions"
  ]
  edge [
    source 365
    target 375
    kind "relation"
    relation "speak in"
    weight 1
  ]
  edge [
    source 365
    target 388
    kind "mentions"
  ]
  edge [
    source 365
    target 396
    kind "mentions"
  ]
  edge [
    source 365
    target 400
    kind "relation"
    relation "speak in"
    weight 1
  ]
  edge [
    source 367
    target 388
    kind "mentions"
  ]
  edge [
    source 368
    target 388
    kind "mentions"
  ]
  edge [
    source 369
    target 388
    kind "mentions"
  ]
  edge [
    source 369
    target 396
    kind "mentions"
  ]
  edge [
    source 370
    target 388
    kind "mentions"
  ]
  edge [
    source 370
    target 396
    kind "mentions"
  ]
  edge [
    source 386
    target 388
    kind "mentions"
  ]
  edge [
    source 388
    target 389
    kind "mentions"
  ]
  edge [
    source 388
    target 390
    kind "mentions"
  ]
  edge [
    source 388
    target 391
    kind "mentions"
  ]
  edge [
    source 388
    target 392
    kind "mentions"
  ]
  edge [
    source 388
    target 393
    kind "mentions"
  ]
  edge [
    source 388
    target 394
    kind "mentions"
  ]
  edge [
    source 388
    target 395
    kind "mentions"
  ]
  edge [
    source 388
    target 2233
    kind "summarizes"
  ]
  edge [
    source 389
    target 396
    kind "mentions"
  ]
  edge [
    source 389
    target 770
    kind "mentions"
  ]
  edge [
    source 389
    target 838
    kind "mentions"
  ]
  edge [
    source 389
    target 839
    kind "relation"
    relation "occurs after"
    weight 1
  ]
  edge [
    source 389
    target 1416
    kind "mentions"
  ]
  edge [
    source 391
    target 396
    kind "mentions"
  ]
  edge [
    source 393
    target 396
    kind "mentions"
  ]
  edge [
    source 394
    target 395
    kind "relation"
    relation "takes place in"
    weight 1
  ]
  edge [
    source 394
    target 396
    kind "mentions"
  ]
  edge [
    source 394
    target 397
    kind "relation"
    relation "has"
    weight 1
  ]
  edge [
    source 394
    target 833
    kind "mentions"
  ]
  edge [
    source 394
    target 2048
    kind "mentions"
  ]
  edge [
    source 395
    target 396
    kind "mentions"
  ]
  edge [
    source 396
    target 397
    kind "mentions"
  ]
  edge [
    source 396
    target 398
    kind "mentions"
  ]
  edge [
    source 396
    target 399
    kind "mentions"
  ]
  edge [
    source 396
    target 400
    kind "mentions"
  ]
  edge [
    source 396
    target 2233
    kind "summarizes"
  ]
  edge [
    source 401
    target 402
    kind "from_chunk"
  ]
  edge [
    source 402
    target 403
    kind "mentions"
  ]
  edge [
    source 402
    target 404
    kind "mentions"
  ]
  edge [
    source 402
    target 405
    kind "mentions"
  ]
  edge [
    source 402
    target 406
    kind "mentions"
  ]
  edge [
    source 402
    target 407
    kind "mentions"
  ]
  edge [
    source 402
    target 408
    kind "mentions"
  ]
  edge [
    source 402
    target 409
    kind "mentions"
  ]
  edge [
    source 402
    target 410
    kind "mentions"
  ]
  edge [
    source 402
    target 411
    kind "mentions"
  ]
  edge [
    source 402
    target 412
    kind "mentions"
  ]
  edge [
    source 402
    target 413
    kind "mentions"
  ]
  edge [
    source 402
    target 414
    kind "mentions"
  ]
  edge [
    source 402
    target 415
    kind "mentions"
  ]
  edge [
    source 402
    target 416
    kind "mentions"
  ]
  edge [
    source 402
    target 417
    kind "mentions"
  ]
  edge [
    source 402
    target 418
    kind "mentions"
  ]
  edge [
    source 402
    target 419
    kind "mentions"
  ]
  edge [
    source 402
    target 2216
    kind "summarizes"
  ]
  edge [
    source 403
    target 977
    kind "mentions"
  ]
  edge [
    source 403
    target 1356
    kind "mentions"
  ]
  edge [
    source 403
    target 568
    kind "relation"
    relation "rings violently"
    weight 1
  ]
  edge [
    source 405
    target 421
    kind "mentions"
  ]
  edge [
    source 405
    target 442
    kind "mentions"
  ]
  edge [
    source 405
    target 884
    kind "mentions"
  ]
  edge [
    source 405
    target 1056
    kind "mentions"
  ]
  edge [
    source 405
    target 1196
    kind "mentions"
  ]
  edge [
    source 418
    target 421
    kind "mentions"
  ]
  edge [
    source 418
    target 428
    kind "mentions"
  ]
  edge [
    source 418
    target 1802
    kind "mentions"
  ]
  edge [
    source 420
    target 421
    kind "from_chunk"
  ]
  edge [
    source 420
    target 422
    kind "from_chunk"
  ]
  edge [
    source 420
    target 425
    kind "from_chunk"
  ]
  edge [
    source 420
    target 428
    kind "from_chunk"
  ]
  edge [
    source 420
    target 434
    kind "from_chunk"
  ]
  edge [
    source 421
    target 2216
    kind "summarizes"
  ]
  edge [
    source 422
    target 423
    kind "mentions"
  ]
  edge [
    source 422
    target 424
    kind "mentions"
  ]
  edge [
    source 422
    target 2232
    kind "summarizes"
  ]
  edge [
    source 423
    target 1074
    kind "mentions"
  ]
  edge [
    source 423
    target 1960
    kind "mentions"
  ]
  edge [
    source 425
    target 426
    kind "mentions"
  ]
  edge [
    source 425
    target 427
    kind "mentions"
  ]
  edge [
    source 425
    target 2233
    kind "summarizes"
  ]
  edge [
    source 427
    target 1347
    kind "mentions"
  ]
  edge [
    source 427
    target 578
    kind "relation"
    relation "calls"
    weight 1
  ]
  edge [
    source 427
    target 2098
    kind "mentions"
  ]
  edge [
    source 428
    target 429
    kind "mentions"
  ]
  edge [
    source 428
    target 430
    kind "mentions"
  ]
  edge [
    source 428
    target 431
    kind "mentions"
  ]
  edge [
    source 428
    target 432
    kind "mentions"
  ]
  edge [
    source 428
    target 433
    kind "mentions"
  ]
  edge [
    source 428
    target 2216
    kind "summarizes"
  ]
  edge [
    source 429
    target 442
    kind "mentions"
  ]
  edge [
    source 429
    target 1662
    kind "mentions"
  ]
  edge [
    source 429
    target 1413
    kind "relation"
    relation "places"
    weight 1
  ]
  edge [
    source 430
    target 434
    kind "mentions"
  ]
  edge [
    source 431
    target 434
    kind "mentions"
  ]
  edge [
    source 434
    target 435
    kind "mentions"
  ]
  edge [
    source 434
    target 436
    kind "mentions"
  ]
  edge [
    source 434
    target 437
    kind "mentions"
  ]
  edge [
    source 434
    target 438
    kind "mentions"
  ]
  edge [
    source 434
    target 439
    kind "mentions"
  ]
  edge [
    source 434
    target 440
    kind "mentions"
  ]
  edge [
    source 434
    target 2216
    kind "summarizes"
  ]
  edge [
    source 441
    target 442
    kind "from_chunk"
  ]
  edge [
    source 442
    target 443
    kind "mentions"
  ]
  edge [
    source 442
    target 444
    kind "mentions"
  ]
  edge [
    source 442
    target 445
    kind "mentions"
  ]
  edge [
    source 442
    target 446
    kind "mentions"
  ]
  edge [
    source 442
    target 447
    kind "mentions"
  ]
  edge [
    source 442
    target 448
    kind "mentions"
  ]
  edge [
    source 442
    target 449
    kind "mentions"
  ]
  edge [
    source 442
    target 450
    kind "mentions"
  ]
  edge [
    source 442
    target 451
    kind "mentions"
  ]
  edge [
    source 442
    target 452
    kind "mentions"
  ]
  edge [
    source 442
    target 453
    kind "mentions"
  ]
  edge [
    source 442
    target 454
    kind "mentions"
  ]
  edge [
    source 442
    target 455
    kind "mentions"
  ]
  edge [
    source 442
    target 456
    kind "mentions"
  ]
  edge [
    source 442
    target 457
    kind "mentions"
  ]
  edge [
    source 442
    target 458
    kind "mentions"
  ]
  edge [
    source 442
    target 459
    kind "mentions"
  ]
  edge [
    source 442
    target 460
    kind "mentions"
  ]
  edge [
    source 442
    target 2219
    kind "summarizes"
  ]
  edge [
    source 444
    target 460
    kind "relation"
    relation "gives an analytical record of"
    weight 1
  ]
  edge [
    source 445
    target 452
    kind "relation"
    relation "blows a rancorous blast which would bring dismay to"
    weight 1
  ]
  edge [
    source 446
    target 766
    kind "mentions"
  ]
  edge [
    source 446
    target 770
    kind "mentions"
  ]
  edge [
    source 446
    target 870
    kind "mentions"
  ]
  edge [
    source 447
    target 453
    kind "relation"
    relation "broke a reserve that existed for"
    weight 1
  ]
  edge [
    source 448
    target 1074
    kind "mentions"
  ]
  edge [
    source 453
    target 456
    kind "relation"
    relation "drop onto"
    weight 1
  ]
  edge [
    source 453
    target 482
    kind "mentions"
  ]
  edge [
    source 453
    target 489
    kind "relation"
    relation "respond with"
    weight 1
  ]
  edge [
    source 453
    target 977
    kind "mentions"
  ]
  edge [
    source 453
    target 2048
    kind "mentions"
  ]
  edge [
    source 453
    target 2059
    kind "relation"
    relation "cling to each other in terror"
    weight 1
  ]
  edge [
    source 459
    target 1891
    kind "mentions"
  ]
  edge [
    source 461
    target 462
    kind "from_chunk"
  ]
  edge [
    source 461
    target 472
    kind "from_chunk"
  ]
  edge [
    source 462
    target 463
    kind "mentions"
  ]
  edge [
    source 462
    target 464
    kind "mentions"
  ]
  edge [
    source 462
    target 465
    kind "mentions"
  ]
  edge [
    source 462
    target 466
    kind "mentions"
  ]
  edge [
    source 462
    target 467
    kind "mentions"
  ]
  edge [
    source 462
    target 468
    kind "mentions"
  ]
  edge [
    source 462
    target 469
    kind "mentions"
  ]
  edge [
    source 462
    target 470
    kind "mentions"
  ]
  edge [
    source 462
    target 471
    kind "mentions"
  ]
  edge [
    source 462
    target 2221
    kind "summarizes"
  ]
  edge [
    source 464
    target 465
    kind "relation"
    relation "grow in"
    weight 1
  ]
  edge [
    source 470
    target 1161
    kind "mentions"
  ]
  edge [
    source 472
    target 473
    kind "mentions"
  ]
  edge [
    source 472
    target 474
    kind "mentions"
  ]
  edge [
    source 472
    target 475
    kind "mentions"
  ]
  edge [
    source 472
    target 476
    kind "mentions"
  ]
  edge [
    source 472
    target 477
    kind "mentions"
  ]
  edge [
    source 472
    target 478
    kind "mentions"
  ]
  edge [
    source 472
    target 479
    kind "mentions"
  ]
  edge [
    source 472
    target 480
    kind "mentions"
  ]
  edge [
    source 472
    target 2224
    kind "summarizes"
  ]
  edge [
    source 473
    target 849
    kind "mentions"
  ]
  edge [
    source 473
    target 900
    kind "mentions"
  ]
  edge [
    source 473
    target 904
    kind "mentions"
  ]
  edge [
    source 474
    target 477
    kind "relation"
    relation "has subscribed"
    weight 1
  ]
  edge [
    source 474
    target 475
    kind "relation"
    relation "is the dean of"
    weight 2
  ]
  edge [
    source 474
    target 478
    kind "relation"
    relation "has anxiety for"
    weight 1
  ]
  edge [
    source 474
    target 1729
    kind "mentions"
  ]
  edge [
    source 474
    target 563
    kind "relation"
    relation "is the sister of"
    weight 1
  ]
  edge [
    source 474
    target 1740
    kind "mentions"
  ]
  edge [
    source 474
    target 578
    kind "relation"
    relation "says dr. jedd has vanished | says she left | to retire to rest"
    weight 3
  ]
  edge [
    source 474
    target 1417
    kind "relation"
    relation "says dr. jedd has absconded | asks if the man was respectable"
    weight 2
  ]
  edge [
    source 474
    target 2118
    kind "mentions"
  ]
  edge [
    source 475
    target 633
    kind "mentions"
  ]
  edge [
    source 475
    target 672
    kind "mentions"
  ]
  edge [
    source 475
    target 1095
    kind "mentions"
  ]
  edge [
    source 475
    target 1329
    kind "mentions"
  ]
  edge [
    source 475
    target 972
    kind "relation"
    relation "were summoned to"
    weight 1
  ]
  edge [
    source 475
    target 1433
    kind "mentions"
  ]
  edge [
    source 475
    target 1413
    kind "relation"
    relation "is now head constable at"
    weight 1
  ]
  edge [
    source 475
    target 1448
    kind "mentions"
  ]
  edge [
    source 475
    target 1468
    kind "mentions"
  ]
  edge [
    source 475
    target 1469
    kind "relation"
    relation "is located in"
    weight 1
  ]
  edge [
    source 475
    target 1488
    kind "mentions"
  ]
  edge [
    source 475
    target 1491
    kind "relation"
    relation "favors"
    weight 1
  ]
  edge [
    source 475
    target 1507
    kind "mentions"
  ]
  edge [
    source 475
    target 1602
    kind "mentions"
  ]
  edge [
    source 475
    target 1681
    kind "mentions"
  ]
  edge [
    source 475
    target 1417
    kind "relation"
    relation "says he has been given many nice new friends since moving to | has moved to"
    weight 2
  ]
  edge [
    source 475
    target 1711
    kind "mentions"
  ]
  edge [
    source 475
    target 1729
    kind "mentions"
  ]
  edge [
    source 475
    target 1765
    kind "mentions"
  ]
  edge [
    source 475
    target 1766
    kind "relation"
    relation "is the dean of"
    weight 1
  ]
  edge [
    source 475
    target 2077
    kind "mentions"
  ]
  edge [
    source 475
    target 2118
    kind "mentions"
  ]
  edge [
    source 475
    target 2120
    kind "mentions"
  ]
  edge [
    source 476
    target 849
    kind "mentions"
  ]
  edge [
    source 476
    target 753
    kind "relation"
    relation "are offered to"
    weight 1
  ]
  edge [
    source 476
    target 884
    kind "mentions"
  ]
  edge [
    source 476
    target 2067
    kind "mentions"
  ]
  edge [
    source 479
    target 480
    kind "relation"
    relation "threatens to undermine"
    weight 1
  ]
  edge [
    source 481
    target 482
    kind "from_chunk"
  ]
  edge [
    source 481
    target 498
    kind "from_chunk"
  ]
  edge [
    source 482
    target 483
    kind "mentions"
  ]
  edge [
    source 482
    target 484
    kind "mentions"
  ]
  edge [
    source 482
    target 485
    kind "mentions"
  ]
  edge [
    source 482
    target 486
    kind "mentions"
  ]
  edge [
    source 482
    target 487
    kind "mentions"
  ]
  edge [
    source 482
    target 488
    kind "mentions"
  ]
  edge [
    source 482
    target 489
    kind "mentions"
  ]
  edge [
    source 482
    target 490
    kind "mentions"
  ]
  edge [
    source 482
    target 491
    kind "mentions"
  ]
  edge [
    source 482
    target 492
    kind "mentions"
  ]
  edge [
    source 482
    target 493
    kind "mentions"
  ]
  edge [
    source 482
    target 494
    kind "mentions"
  ]
  edge [
    source 482
    target 495
    kind "mentions"
  ]
  edge [
    source 482
    target 496
    kind "mentions"
  ]
  edge [
    source 482
    target 497
    kind "mentions"
  ]
  edge [
    source 482
    target 2219
    kind "summarizes"
  ]
  edge [
    source 490
    target 494
    kind "relation"
    relation "is the secretary of"
    weight 1
  ]
  edge [
    source 491
    target 504
    kind "mentions"
  ]
  edge [
    source 491
    target 597
    kind "mentions"
  ]
  edge [
    source 491
    target 604
    kind "mentions"
  ]
  edge [
    source 491
    target 578
    kind "relation"
    relation "has dropped out of"
    weight 1
  ]
  edge [
    source 491
    target 648
    kind "mentions"
  ]
  edge [
    source 491
    target 656
    kind "mentions"
  ]
  edge [
    source 491
    target 752
    kind "mentions"
  ]
  edge [
    source 491
    target 1131
    kind "mentions"
  ]
  edge [
    source 491
    target 1502
    kind "mentions"
  ]
  edge [
    source 491
    target 1858
    kind "mentions"
  ]
  edge [
    source 491
    target 1864
    kind "mentions"
  ]
  edge [
    source 491
    target 1926
    kind "mentions"
  ]
  edge [
    source 491
    target 1930
    kind "relation"
    relation "was going to watch"
    weight 1
  ]
  edge [
    source 491
    target 2020
    kind "mentions"
  ]
  edge [
    source 498
    target 499
    kind "mentions"
  ]
  edge [
    source 498
    target 500
    kind "mentions"
  ]
  edge [
    source 498
    target 501
    kind "mentions"
  ]
  edge [
    source 498
    target 502
    kind "mentions"
  ]
  edge [
    source 498
    target 2219
    kind "summarizes"
  ]
  edge [
    source 503
    target 504
    kind "from_chunk"
  ]
  edge [
    source 503
    target 505
    kind "from_chunk"
  ]
  edge [
    source 503
    target 509
    kind "from_chunk"
  ]
  edge [
    source 504
    target 2220
    kind "summarizes"
  ]
  edge [
    source 505
    target 506
    kind "mentions"
  ]
  edge [
    source 505
    target 507
    kind "mentions"
  ]
  edge [
    source 505
    target 508
    kind "mentions"
  ]
  edge [
    source 505
    target 2227
    kind "summarizes"
  ]
  edge [
    source 506
    target 509
    kind "mentions"
  ]
  edge [
    source 509
    target 2227
    kind "summarizes"
  ]
  edge [
    source 510
    target 511
    kind "from_chunk"
  ]
  edge [
    source 510
    target 525
    kind "from_chunk"
  ]
  edge [
    source 511
    target 512
    kind "mentions"
  ]
  edge [
    source 511
    target 513
    kind "mentions"
  ]
  edge [
    source 511
    target 514
    kind "mentions"
  ]
  edge [
    source 511
    target 515
    kind "mentions"
  ]
  edge [
    source 511
    target 516
    kind "mentions"
  ]
  edge [
    source 511
    target 517
    kind "mentions"
  ]
  edge [
    source 511
    target 518
    kind "mentions"
  ]
  edge [
    source 511
    target 519
    kind "mentions"
  ]
  edge [
    source 511
    target 520
    kind "mentions"
  ]
  edge [
    source 511
    target 521
    kind "mentions"
  ]
  edge [
    source 511
    target 522
    kind "mentions"
  ]
  edge [
    source 511
    target 523
    kind "mentions"
  ]
  edge [
    source 511
    target 524
    kind "mentions"
  ]
  edge [
    source 511
    target 2231
    kind "summarizes"
  ]
  edge [
    source 512
    target 515
    kind "relation"
    relation "married | had his neck dislocated | left a widow"
    weight 3
  ]
  edge [
    source 512
    target 523
    kind "relation"
    relation "claimed that if he vexed her she could"
    weight 1
  ]
  edge [
    source 512
    target 514
    kind "relation"
    relation "did not go to her brother"
    weight 1
  ]
  edge [
    source 512
    target 525
    kind "mentions"
  ]
  edge [
    source 512
    target 528
    kind "relation"
    relation "would have gone to"
    weight 1
  ]
  edge [
    source 512
    target 759
    kind "mentions"
  ]
  edge [
    source 512
    target 1893
    kind "mentions"
  ]
  edge [
    source 514
    target 525
    kind "mentions"
  ]
  edge [
    source 514
    target 528
    kind "relation"
    relation "is a widower"
    weight 1
  ]
  edge [
    source 515
    target 519
    kind "relation"
    relation "died"
    weight 1
  ]
  edge [
    source 515
    target 521
    kind "relation"
    relation "was engaged in"
    weight 1
  ]
  edge [
    source 515
    target 516
    kind "relation"
    relation "was known as"
    weight 1
  ]
  edge [
    source 525
    target 526
    kind "mentions"
  ]
  edge [
    source 525
    target 527
    kind "mentions"
  ]
  edge [
    source 525
    target 528
    kind "mentions"
  ]
  edge [
    source 525
    target 2231
    kind "summarizes"
  ]
  edge [
    source 529
    target 530
    kind "from_chunk"
  ]
  edge [
    source 529
    target 534
    kind "from_chunk"
  ]
  edge [
    source 529
    target 543
    kind "from_chunk"
  ]
  edge [
    source 529
    target 549
    kind "from_chunk"
  ]
  edge [
    source 529
    target 555
    kind "from_chunk"
  ]
  edge [
    source 530
    target 531
    kind "mentions"
  ]
  edge [
    source 530
    target 532
    kind "mentions"
  ]
  edge [
    source 530
    target 533
    kind "mentions"
  ]
  edge [
    source 530
    target 2227
    kind "summarizes"
  ]
  edge [
    source 531
    target 2077
    kind "mentions"
  ]
  edge [
    source 534
    target 535
    kind "mentions"
  ]
  edge [
    source 534
    target 536
    kind "mentions"
  ]
  edge [
    source 534
    target 537
    kind "mentions"
  ]
  edge [
    source 534
    target 538
    kind "mentions"
  ]
  edge [
    source 534
    target 539
    kind "mentions"
  ]
  edge [
    source 534
    target 540
    kind "mentions"
  ]
  edge [
    source 534
    target 541
    kind "mentions"
  ]
  edge [
    source 534
    target 542
    kind "mentions"
  ]
  edge [
    source 534
    target 2236
    kind "summarizes"
  ]
  edge [
    source 536
    target 537
    kind "relation"
    relation "affected"
    weight 1
  ]
  edge [
    source 536
    target 538
    kind "relation"
    relation "affected"
    weight 1
  ]
  edge [
    source 536
    target 539
    kind "relation"
    relation "led to"
    weight 1
  ]
  edge [
    source 538
    target 1798
    kind "mentions"
  ]
  edge [
    source 540
    target 592
    kind "mentions"
  ]
  edge [
    source 540
    target 1027
    kind "mentions"
  ]
  edge [
    source 540
    target 1028
    kind "relation"
    relation "are exhausted from"
    weight 1
  ]
  edge [
    source 540
    target 1587
    kind "mentions"
  ]
  edge [
    source 541
    target 555
    kind "mentions"
  ]
  edge [
    source 543
    target 544
    kind "mentions"
  ]
  edge [
    source 543
    target 545
    kind "mentions"
  ]
  edge [
    source 543
    target 546
    kind "mentions"
  ]
  edge [
    source 543
    target 547
    kind "mentions"
  ]
  edge [
    source 543
    target 548
    kind "mentions"
  ]
  edge [
    source 543
    target 2221
    kind "summarizes"
  ]
  edge [
    source 544
    target 545
    kind "relation"
    relation "has"
    weight 1
  ]
  edge [
    source 544
    target 547
    kind "relation"
    relation "has a stable with"
    weight 1
  ]
  edge [
    source 546
    target 604
    kind "mentions"
  ]
  edge [
    source 546
    target 566
    kind "relation"
    relation "has provided"
    weight 1
  ]
  edge [
    source 546
    target 1019
    kind "mentions"
  ]
  edge [
    source 546
    target 1161
    kind "mentions"
  ]
  edge [
    source 546
    target 1175
    kind "mentions"
  ]
  edge [
    source 546
    target 1178
    kind "mentions"
  ]
  edge [
    source 546
    target 1196
    kind "mentions"
  ]
  edge [
    source 546
    target 1248
    kind "mentions"
  ]
  edge [
    source 546
    target 1264
    kind "mentions"
  ]
  edge [
    source 546
    target 578
    kind "relation"
    relation "asks for the nearer way to"
    weight 1
  ]
  edge [
    source 546
    target 1382
    kind "mentions"
  ]
  edge [
    source 546
    target 1540
    kind "mentions"
  ]
  edge [
    source 546
    target 1417
    kind "relation"
    relation "is going to"
    weight 1
  ]
  edge [
    source 546
    target 2122
    kind "mentions"
  ]
  edge [
    source 549
    target 550
    kind "mentions"
  ]
  edge [
    source 549
    target 551
    kind "mentions"
  ]
  edge [
    source 549
    target 552
    kind "mentions"
  ]
  edge [
    source 549
    target 553
    kind "mentions"
  ]
  edge [
    source 549
    target 554
    kind "mentions"
  ]
  edge [
    source 549
    target 2236
    kind "summarizes"
  ]
  edge [
    source 550
    target 553
    kind "relation"
    relation "is on the wan features of"
    weight 1
  ]
  edge [
    source 551
    target 613
    kind "mentions"
  ]
  edge [
    source 555
    target 556
    kind "mentions"
  ]
  edge [
    source 555
    target 557
    kind "mentions"
  ]
  edge [
    source 555
    target 558
    kind "mentions"
  ]
  edge [
    source 555
    target 559
    kind "mentions"
  ]
  edge [
    source 555
    target 2236
    kind "summarizes"
  ]
  edge [
    source 556
    target 752
    kind "mentions"
  ]
  edge [
    source 556
    target 578
    kind "relation"
    relation "confirms having many troubles"
    weight 1
  ]
  edge [
    source 560
    target 561
    kind "from_chunk"
  ]
  edge [
    source 561
    target 562
    kind "mentions"
  ]
  edge [
    source 561
    target 563
    kind "mentions"
  ]
  edge [
    source 561
    target 564
    kind "mentions"
  ]
  edge [
    source 561
    target 565
    kind "mentions"
  ]
  edge [
    source 561
    target 566
    kind "mentions"
  ]
  edge [
    source 561
    target 567
    kind "mentions"
  ]
  edge [
    source 561
    target 568
    kind "mentions"
  ]
  edge [
    source 561
    target 569
    kind "mentions"
  ]
  edge [
    source 561
    target 570
    kind "mentions"
  ]
  edge [
    source 561
    target 571
    kind "mentions"
  ]
  edge [
    source 561
    target 572
    kind "mentions"
  ]
  edge [
    source 561
    target 573
    kind "mentions"
  ]
  edge [
    source 561
    target 574
    kind "mentions"
  ]
  edge [
    source 561
    target 2227
    kind "summarizes"
  ]
  edge [
    source 563
    target 689
    kind "mentions"
  ]
  edge [
    source 563
    target 695
    kind "mentions"
  ]
  edge [
    source 563
    target 701
    kind "mentions"
  ]
  edge [
    source 563
    target 1074
    kind "mentions"
  ]
  edge [
    source 563
    target 1729
    kind "mentions"
  ]
  edge [
    source 563
    target 649
    kind "relation"
    relation "introduces"
    weight 1
  ]
  edge [
    source 566
    target 576
    kind "mentions"
  ]
  edge [
    source 566
    target 604
    kind "mentions"
  ]
  edge [
    source 566
    target 578
    kind "relation"
    relation "has run many races with | wants to avoid pitching | presses warmly to | kisses | is the sister of | has changed her mind about | cannot trust | will not forget"
    weight 8
  ]
  edge [
    source 566
    target 605
    kind "relation"
    relation "has treated harshly"
    weight 1
  ]
  edge [
    source 566
    target 612
    kind "relation"
    relation "is competing neck-and-neck with"
    weight 1
  ]
  edge [
    source 566
    target 609
    kind "relation"
    relation "has provided"
    weight 1
  ]
  edge [
    source 566
    target 607
    kind "relation"
    relation "has kept out of"
    weight 1
  ]
  edge [
    source 566
    target 656
    kind "mentions"
  ]
  edge [
    source 566
    target 1039
    kind "mentions"
  ]
  edge [
    source 566
    target 1053
    kind "mentions"
  ]
  edge [
    source 566
    target 1066
    kind "mentions"
  ]
  edge [
    source 566
    target 1074
    kind "mentions"
  ]
  edge [
    source 566
    target 1090
    kind "relation"
    relation "takes"
    weight 1
  ]
  edge [
    source 566
    target 1091
    kind "relation"
    relation "sleeps peacefully"
    weight 1
  ]
  edge [
    source 566
    target 1776
    kind "mentions"
  ]
  edge [
    source 566
    target 1782
    kind "mentions"
  ]
  edge [
    source 566
    target 1785
    kind "mentions"
  ]
  edge [
    source 566
    target 1793
    kind "mentions"
  ]
  edge [
    source 566
    target 1413
    kind "relation"
    relation "says he will do it"
    weight 1
  ]
  edge [
    source 566
    target 1980
    kind "mentions"
  ]
  edge [
    source 566
    target 1981
    kind "relation"
    relation "was embarrassed by | ran down the back of"
    weight 2
  ]
  edge [
    source 566
    target 649
    kind "relation"
    relation "will not forget"
    weight 1
  ]
  edge [
    source 566
    target 2140
    kind "mentions"
  ]
  edge [
    source 566
    target 2088
    kind "relation"
    relation "lays the whip on | takes the bit between its teeth"
    weight 2
  ]
  edge [
    source 566
    target 2146
    kind "mentions"
  ]
  edge [
    source 566
    target 2148
    kind "relation"
    relation "does not want"
    weight 1
  ]
  edge [
    source 567
    target 921
    kind "mentions"
  ]
  edge [
    source 567
    target 938
    kind "mentions"
  ]
  edge [
    source 568
    target 1356
    kind "mentions"
  ]
  edge [
    source 575
    target 576
    kind "from_chunk"
  ]
  edge [
    source 575
    target 586
    kind "from_chunk"
  ]
  edge [
    source 575
    target 592
    kind "from_chunk"
  ]
  edge [
    source 575
    target 597
    kind "from_chunk"
  ]
  edge [
    source 576
    target 577
    kind "mentions"
  ]
  edge [
    source 576
    target 578
    kind "mentions"
  ]
  edge [
    source 576
    target 579
    kind "mentions"
  ]
  edge [
    source 576
    target 580
    kind "mentions"
  ]
  edge [
    source 576
    target 581
    kind "mentions"
  ]
  edge [
    source 576
    target 582
    kind "mentions"
  ]
  edge [
    source 576
    target 583
    kind "mentions"
  ]
  edge [
    source 576
    target 584
    kind "mentions"
  ]
  edge [
    source 576
    target 585
    kind "mentions"
  ]
  edge [
    source 576
    target 2222
    kind "summarizes"
  ]
  edge [
    source 577
    target 578
    kind "relation"
    relation "refers to augustin as | remembers having munched corn with | asks augustin about feeding time | offers to make it all right with | says good night to"
    weight 5
  ]
  edge [
    source 577
    target 597
    kind "mentions"
  ]
  edge [
    source 577
    target 629
    kind "mentions"
  ]
  edge [
    source 577
    target 631
    kind "relation"
    relation "has luncheon at"
    weight 1
  ]
  edge [
    source 577
    target 710
    kind "mentions"
  ]
  edge [
    source 577
    target 732
    kind "mentions"
  ]
  edge [
    source 577
    target 1074
    kind "mentions"
  ]
  edge [
    source 577
    target 1974
    kind "mentions"
  ]
  edge [
    source 577
    target 649
    kind "relation"
    relation "hauled"
    weight 1
  ]
  edge [
    source 578
    target 582
    kind "relation"
    relation "calls augustin"
    weight 1
  ]
  edge [
    source 578
    target 583
    kind "relation"
    relation "accuses augustin of putting on too much flesh"
    weight 1
  ]
  edge [
    source 578
    target 584
    kind "relation"
    relation "suggests augustin should be given"
    weight 1
  ]
  edge [
    source 578
    target 586
    kind "mentions"
  ]
  edge [
    source 578
    target 589
    kind "relation"
    relation "tells salome to kiss | tells sheba to kiss"
    weight 2
  ]
  edge [
    source 578
    target 590
    kind "relation"
    relation "surveys the two girls critically"
    weight 1
  ]
  edge [
    source 578
    target 591
    kind "relation"
    relation "touches each girl alternately with"
    weight 1
  ]
  edge [
    source 578
    target 592
    kind "mentions"
  ]
  edge [
    source 578
    target 595
    kind "relation"
    relation "comments on sheba's stable companion"
    weight 1
  ]
  edge [
    source 578
    target 597
    kind "mentions"
  ]
  edge [
    source 578
    target 599
    kind "relation"
    relation "states their last shared corn meal was"
    weight 1
  ]
  edge [
    source 578
    target 600
    kind "relation"
    relation "says they have both run many races since then"
    weight 1
  ]
  edge [
    source 578
    target 601
    kind "relation"
    relation "states they have never met in the same events"
    weight 1
  ]
  edge [
    source 578
    target 604
    kind "mentions"
  ]
  edge [
    source 578
    target 605
    kind "relation"
    relation "has treated harshly | has been punished and pulled | remains sound in the wind"
    weight 3
  ]
  edge [
    source 578
    target 606
    kind "relation"
    relation "trusts | is known as | is a man | shouts to"
    weight 4
  ]
  edge [
    source 578
    target 613
    kind "mentions"
  ]
  edge [
    source 578
    target 618
    kind "mentions"
  ]
  edge [
    source 578
    target 619
    kind "relation"
    relation "will be known at"
    weight 1
  ]
  edge [
    source 578
    target 620
    kind "relation"
    relation "is crimson and black"
    weight 1
  ]
  edge [
    source 578
    target 621
    kind "mentions"
  ]
  edge [
    source 578
    target 624
    kind "relation"
    relation "will not have her colors seen at"
    weight 1
  ]
  edge [
    source 578
    target 627
    kind "mentions"
  ]
  edge [
    source 578
    target 623
    kind "relation"
    relation "may be weaned from"
    weight 1
  ]
  edge [
    source 578
    target 629
    kind "mentions"
  ]
  edge [
    source 578
    target 633
    kind "mentions"
  ]
  edge [
    source 578
    target 641
    kind "relation"
    relation "thinks the air is"
    weight 1
  ]
  edge [
    source 578
    target 635
    kind "relation"
    relation "plans to get"
    weight 1
  ]
  edge [
    source 578
    target 687
    kind "mentions"
  ]
  edge [
    source 578
    target 689
    kind "mentions"
  ]
  edge [
    source 578
    target 695
    kind "mentions"
  ]
  edge [
    source 578
    target 698
    kind "relation"
    relation "are the nieces of"
    weight 1
  ]
  edge [
    source 578
    target 700
    kind "mentions"
  ]
  edge [
    source 578
    target 706
    kind "mentions"
  ]
  edge [
    source 578
    target 710
    kind "mentions"
  ]
  edge [
    source 578
    target 649
    kind "relation"
    relation "refuses to allow | challenges | is a partner with | laughed at | rushes in breathlessly | takes off coat and throws over | is called a brick by | comforts | kissed | felt flattered by | paces up and down with | says good-night to | calls for | will smoke with | shrieks with fright at | threatens to fire | deposits | asks why | asks where | tells georgiana not to be a man | says he never guessed | urges georgiana to come along | seizes georgiana's hand | snatches hand away from | says she will nurse her half alone | calls | disagrees with | asks | says there is another charge | identifies as the one who committed the act | empties pockets of | will not marry | asked her only recently"
    weight 33
  ]
  edge [
    source 578
    target 727
    kind "relation"
    relation "says they are all right when"
    weight 1
  ]
  edge [
    source 578
    target 728
    kind "relation"
    relation "promises to lunch on | made for | felt at home among"
    weight 3
  ]
  edge [
    source 578
    target 711
    kind "relation"
    relation "will have"
    weight 1
  ]
  edge [
    source 578
    target 612
    kind "relation"
    relation "will have"
    weight 1
  ]
  edge [
    source 578
    target 729
    kind "relation"
    relation "dreams about"
    weight 1
  ]
  edge [
    source 578
    target 730
    kind "relation"
    relation "calls sir tristram"
    weight 1
  ]
  edge [
    source 578
    target 732
    kind "mentions"
  ]
  edge [
    source 578
    target 738
    kind "relation"
    relation "promised augustin she would not own"
    weight 1
  ]
  edge [
    source 578
    target 739
    kind "relation"
    relation "claims she does not own"
    weight 1
  ]
  edge [
    source 578
    target 740
    kind "relation"
    relation "considers half a horse better than"
    weight 1
  ]
  edge [
    source 578
    target 741
    kind "mentions"
  ]
  edge [
    source 578
    target 745
    kind "mentions"
  ]
  edge [
    source 578
    target 680
    kind "relation"
    relation "apologizes to | states that he is fit | observed"
    weight 3
  ]
  edge [
    source 578
    target 713
    kind "relation"
    relation "is willing to bet all her money on"
    weight 1
  ]
  edge [
    source 578
    target 746
    kind "relation"
    relation "will have had a bad day if not richer by | will be richer by"
    weight 2
  ]
  edge [
    source 578
    target 748
    kind "mentions"
  ]
  edge [
    source 578
    target 750
    kind "relation"
    relation "calls sheba"
    weight 1
  ]
  edge [
    source 578
    target 752
    kind "mentions"
  ]
  edge [
    source 578
    target 759
    kind "mentions"
  ]
  edge [
    source 578
    target 725
    kind "relation"
    relation "confirms dandy dick is | notices less weight will benefit | won in a common canter | says the horse won in a common canter"
    weight 4
  ]
  edge [
    source 578
    target 763
    kind "relation"
    relation "refuses to allow"
    weight 1
  ]
  edge [
    source 578
    target 764
    kind "relation"
    relation "agrees to let"
    weight 1
  ]
  edge [
    source 578
    target 766
    kind "mentions"
  ]
  edge [
    source 578
    target 768
    kind "relation"
    relation "is pouring out | is pouring"
    weight 2
  ]
  edge [
    source 578
    target 770
    kind "mentions"
  ]
  edge [
    source 578
    target 786
    kind "relation"
    relation "explains why her foot was always in the way"
    weight 1
  ]
  edge [
    source 578
    target 780
    kind "relation"
    relation "offers"
    weight 1
  ]
  edge [
    source 578
    target 788
    kind "relation"
    relation "says the dinner was"
    weight 1
  ]
  edge [
    source 578
    target 781
    kind "relation"
    relation "says the mutton was"
    weight 1
  ]
  edge [
    source 578
    target 777
    kind "relation"
    relation "says the potatoes rattled"
    weight 1
  ]
  edge [
    source 578
    target 778
    kind "relation"
    relation "notices that the dinner served one useful end"
    weight 1
  ]
  edge [
    source 578
    target 791
    kind "relation"
    relation "says the chimney needs"
    weight 1
  ]
  edge [
    source 578
    target 795
    kind "mentions"
  ]
  edge [
    source 578
    target 800
    kind "mentions"
  ]
  edge [
    source 578
    target 802
    kind "mentions"
  ]
  edge [
    source 578
    target 812
    kind "mentions"
  ]
  edge [
    source 578
    target 814
    kind "relation"
    relation "has figures to work out"
    weight 1
  ]
  edge [
    source 578
    target 815
    kind "relation"
    relation "compares feeding at"
    weight 1
  ]
  edge [
    source 578
    target 828
    kind "mentions"
  ]
  edge [
    source 578
    target 830
    kind "relation"
    relation "joins the girls as"
    weight 1
  ]
  edge [
    source 578
    target 844
    kind "mentions"
  ]
  edge [
    source 578
    target 845
    kind "relation"
    relation "asks if the colonel will send"
    weight 1
  ]
  edge [
    source 578
    target 849
    kind "mentions"
  ]
  edge [
    source 578
    target 855
    kind "mentions"
  ]
  edge [
    source 578
    target 870
    kind "mentions"
  ]
  edge [
    source 578
    target 880
    kind "mentions"
  ]
  edge [
    source 578
    target 882
    kind "mentions"
  ]
  edge [
    source 578
    target 883
    kind "relation"
    relation "describes the event as"
    weight 2
  ]
  edge [
    source 578
    target 891
    kind "mentions"
  ]
  edge [
    source 578
    target 892
    kind "relation"
    relation "decides to hedge over"
    weight 1
  ]
  edge [
    source 578
    target 898
    kind "mentions"
  ]
  edge [
    source 578
    target 899
    kind "relation"
    relation "says there's nothing like it in"
    weight 1
  ]
  edge [
    source 578
    target 904
    kind "mentions"
  ]
  edge [
    source 578
    target 917
    kind "mentions"
  ]
  edge [
    source 578
    target 907
    kind "relation"
    relation "asks about"
    weight 1
  ]
  edge [
    source 578
    target 918
    kind "relation"
    relation "questions"
    weight 1
  ]
  edge [
    source 578
    target 921
    kind "mentions"
  ]
  edge [
    source 578
    target 932
    kind "relation"
    relation "demands"
    weight 2
  ]
  edge [
    source 578
    target 933
    kind "relation"
    relation "demands"
    weight 2
  ]
  edge [
    source 578
    target 934
    kind "relation"
    relation "declares she is going to help clear"
    weight 2
  ]
  edge [
    source 578
    target 938
    kind "mentions"
  ]
  edge [
    source 578
    target 940
    kind "mentions"
  ]
  edge [
    source 578
    target 950
    kind "relation"
    relation "says a horse is"
    weight 1
  ]
  edge [
    source 578
    target 944
    kind "relation"
    relation "asks where the animal will be put"
    weight 1
  ]
  edge [
    source 578
    target 954
    kind "mentions"
  ]
  edge [
    source 578
    target 959
    kind "mentions"
  ]
  edge [
    source 578
    target 961
    kind "mentions"
  ]
  edge [
    source 578
    target 992
    kind "mentions"
  ]
  edge [
    source 578
    target 998
    kind "mentions"
  ]
  edge [
    source 578
    target 1008
    kind "relation"
    relation "noted"
    weight 1
  ]
  edge [
    source 578
    target 1010
    kind "relation"
    relation "says watching"
    weight 1
  ]
  edge [
    source 578
    target 1019
    kind "mentions"
  ]
  edge [
    source 578
    target 1027
    kind "mentions"
  ]
  edge [
    source 578
    target 1031
    kind "relation"
    relation "responds that"
    weight 1
  ]
  edge [
    source 578
    target 1039
    kind "mentions"
  ]
  edge [
    source 578
    target 1044
    kind "mentions"
  ]
  edge [
    source 578
    target 1050
    kind "mentions"
  ]
  edge [
    source 578
    target 1052
    kind "relation"
    relation "blesses the child in the cot"
    weight 1
  ]
  edge [
    source 578
    target 1053
    kind "mentions"
  ]
  edge [
    source 578
    target 1056
    kind "mentions"
  ]
  edge [
    source 578
    target 1061
    kind "mentions"
  ]
  edge [
    source 578
    target 1066
    kind "mentions"
  ]
  edge [
    source 578
    target 1067
    kind "relation"
    relation "asks gus if he will let"
    weight 1
  ]
  edge [
    source 578
    target 1069
    kind "mentions"
  ]
  edge [
    source 578
    target 679
    kind "relation"
    relation "asks if he can raise | decides to apply"
    weight 2
  ]
  edge [
    source 578
    target 1072
    kind "mentions"
  ]
  edge [
    source 578
    target 1074
    kind "mentions"
  ]
  edge [
    source 578
    target 1089
    kind "relation"
    relation "instructs gus to keep secret"
    weight 1
  ]
  edge [
    source 578
    target 1063
    kind "relation"
    relation "says she has done all she can for"
    weight 1
  ]
  edge [
    source 578
    target 1079
    kind "relation"
    relation "says blore will put money on"
    weight 1
  ]
  edge [
    source 578
    target 1095
    kind "mentions"
  ]
  edge [
    source 578
    target 1102
    kind "mentions"
  ]
  edge [
    source 578
    target 1109
    kind "mentions"
  ]
  edge [
    source 578
    target 1131
    kind "mentions"
  ]
  edge [
    source 578
    target 1264
    kind "mentions"
  ]
  edge [
    source 578
    target 1266
    kind "relation"
    relation "enters carrying"
    weight 1
  ]
  edge [
    source 578
    target 1267
    kind "mentions"
  ]
  edge [
    source 578
    target 1268
    kind "relation"
    relation "recognizes as | calls out"
    weight 2
  ]
  edge [
    source 578
    target 1269
    kind "mentions"
  ]
  edge [
    source 578
    target 1270
    kind "relation"
    relation "says she is"
    weight 1
  ]
  edge [
    source 578
    target 1272
    kind "relation"
    relation "will be on her legs again in"
    weight 1
  ]
  edge [
    source 578
    target 1273
    kind "mentions"
  ]
  edge [
    source 578
    target 1278
    kind "mentions"
  ]
  edge [
    source 578
    target 674
    kind "relation"
    relation "had a dream about | refuses to swap halves | is like a doating mother to | asks if the villain has robbed | gave"
    weight 5
  ]
  edge [
    source 578
    target 1282
    kind "mentions"
  ]
  edge [
    source 578
    target 1283
    kind "relation"
    relation "is himself again"
    weight 1
  ]
  edge [
    source 578
    target 945
    kind "relation"
    relation "loves and clings to"
    weight 1
  ]
  edge [
    source 578
    target 1290
    kind "mentions"
  ]
  edge [
    source 578
    target 1297
    kind "mentions"
  ]
  edge [
    source 578
    target 1298
    kind "relation"
    relation "is the twin-sister of"
    weight 1
  ]
  edge [
    source 578
    target 705
    kind "relation"
    relation "points to"
    weight 1
  ]
  edge [
    source 578
    target 1345
    kind "mentions"
  ]
  edge [
    source 578
    target 1347
    kind "mentions"
  ]
  edge [
    source 578
    target 1348
    kind "relation"
    relation "can keep a thing quiet"
    weight 1
  ]
  edge [
    source 578
    target 1352
    kind "mentions"
  ]
  edge [
    source 578
    target 1356
    kind "mentions"
  ]
  edge [
    source 578
    target 1374
    kind "relation"
    relation "tells sir tristram to"
    weight 1
  ]
  edge [
    source 578
    target 1375
    kind "relation"
    relation "tells sir tristram to"
    weight 1
  ]
  edge [
    source 578
    target 1379
    kind "relation"
    relation "and salome and sheba ask"
    weight 1
  ]
  edge [
    source 578
    target 1368
    kind "relation"
    relation "runs to | opens | runs to the door and opens it"
    weight 3
  ]
  edge [
    source 578
    target 1382
    kind "mentions"
  ]
  edge [
    source 578
    target 1399
    kind "relation"
    relation "exclaims"
    weight 1
  ]
  edge [
    source 578
    target 1711
    kind "mentions"
  ]
  edge [
    source 578
    target 1413
    kind "relation"
    relation "admits | comments that they try to make everybody feel at home | speaks to | turns to respond to | says hush | kneels at the feet of"
    weight 6
  ]
  edge [
    source 578
    target 1721
    kind "relation"
    relation "exclaims"
    weight 1
  ]
  edge [
    source 578
    target 1694
    kind "relation"
    relation "says she hopes it will be the last visit"
    weight 1
  ]
  edge [
    source 578
    target 1727
    kind "relation"
    relation "suggests"
    weight 1
  ]
  edge [
    source 578
    target 1729
    kind "mentions"
  ]
  edge [
    source 578
    target 1417
    kind "relation"
    relation "is greeted by | is angry at"
    weight 2
  ]
  edge [
    source 578
    target 1740
    kind "mentions"
  ]
  edge [
    source 578
    target 1738
    kind "relation"
    relation "is profligate"
    weight 1
  ]
  edge [
    source 578
    target 1193
    kind "relation"
    relation "are pending"
    weight 1
  ]
  edge [
    source 578
    target 1388
    kind "relation"
    relation "feels fear at"
    weight 1
  ]
  edge [
    source 578
    target 1663
    kind "relation"
    relation "orders to take away"
    weight 1
  ]
  edge [
    source 578
    target 1742
    kind "relation"
    relation "expresses concern about"
    weight 1
  ]
  edge [
    source 578
    target 1749
    kind "mentions"
  ]
  edge [
    source 578
    target 1760
    kind "relation"
    relation "puts her handkerchief to her eyes | sits faintly"
    weight 2
  ]
  edge [
    source 578
    target 1765
    kind "mentions"
  ]
  edge [
    source 578
    target 1766
    kind "relation"
    relation "provides a description of | has black hair and a squint | is described as short and thin"
    weight 3
  ]
  edge [
    source 578
    target 1773
    kind "mentions"
  ]
  edge [
    source 578
    target 1776
    kind "mentions"
  ]
  edge [
    source 578
    target 1780
    kind "relation"
    relation "wants to see"
    weight 1
  ]
  edge [
    source 578
    target 1782
    kind "mentions"
  ]
  edge [
    source 578
    target 1785
    kind "mentions"
  ]
  edge [
    source 578
    target 1787
    kind "relation"
    relation "says to herself"
    weight 1
  ]
  edge [
    source 578
    target 1788
    kind "mentions"
  ]
  edge [
    source 578
    target 1793
    kind "mentions"
  ]
  edge [
    source 578
    target 1794
    kind "relation"
    relation "says it is as much as she could do"
    weight 1
  ]
  edge [
    source 578
    target 1798
    kind "mentions"
  ]
  edge [
    source 578
    target 1801
    kind "relation"
    relation "exclaims"
    weight 1
  ]
  edge [
    source 578
    target 1799
    kind "relation"
    relation "says her own stock has become"
    weight 1
  ]
  edge [
    source 578
    target 1802
    kind "mentions"
  ]
  edge [
    source 578
    target 1808
    kind "mentions"
  ]
  edge [
    source 578
    target 1827
    kind "mentions"
  ]
  edge [
    source 578
    target 1829
    kind "relation"
    relation "responds with"
    weight 1
  ]
  edge [
    source 578
    target 1833
    kind "mentions"
  ]
  edge [
    source 578
    target 1841
    kind "relation"
    relation "is privileged to shelter in"
    weight 1
  ]
  edge [
    source 578
    target 1851
    kind "mentions"
  ]
  edge [
    source 578
    target 1893
    kind "mentions"
  ]
  edge [
    source 578
    target 1897
    kind "relation"
    relation "says"
    weight 1
  ]
  edge [
    source 578
    target 1895
    kind "relation"
    relation "reminds to mind"
    weight 1
  ]
  edge [
    source 578
    target 1906
    kind "mentions"
  ]
  edge [
    source 578
    target 1909
    kind "relation"
    relation "seizes"
    weight 1
  ]
  edge [
    source 578
    target 1911
    kind "mentions"
  ]
  edge [
    source 578
    target 1915
    kind "relation"
    relation "announces"
    weight 1
  ]
  edge [
    source 578
    target 1224
    kind "relation"
    relation "cheers"
    weight 1
  ]
  edge [
    source 578
    target 1917
    kind "mentions"
  ]
  edge [
    source 578
    target 1924
    kind "relation"
    relation "agrees with"
    weight 1
  ]
  edge [
    source 578
    target 1926
    kind "mentions"
  ]
  edge [
    source 578
    target 1933
    kind "relation"
    relation "discovered the plan of"
    weight 1
  ]
  edge [
    source 578
    target 1936
    kind "relation"
    relation "felt as comfortable as"
    weight 1
  ]
  edge [
    source 578
    target 1938
    kind "mentions"
  ]
  edge [
    source 578
    target 1939
    kind "relation"
    relation "loses"
    weight 1
  ]
  edge [
    source 578
    target 1940
    kind "mentions"
  ]
  edge [
    source 578
    target 1944
    kind "relation"
    relation "stands on"
    weight 1
  ]
  edge [
    source 578
    target 1941
    kind "relation"
    relation "is supported by"
    weight 1
  ]
  edge [
    source 578
    target 1943
    kind "relation"
    relation "declares to"
    weight 1
  ]
  edge [
    source 578
    target 1942
    kind "relation"
    relation "loses"
    weight 1
  ]
  edge [
    source 578
    target 1946
    kind "mentions"
  ]
  edge [
    source 578
    target 1948
    kind "relation"
    relation "announces that a relative has been caught for"
    weight 1
  ]
  edge [
    source 578
    target 1947
    kind "relation"
    relation "says a bobby will be with"
    weight 1
  ]
  edge [
    source 578
    target 1949
    kind "relation"
    relation "invites people to join in rescue"
    weight 1
  ]
  edge [
    source 578
    target 1951
    kind "relation"
    relation "asks what they will get for it"
    weight 1
  ]
  edge [
    source 578
    target 1952
    kind "relation"
    relation "offers"
    weight 1
  ]
  edge [
    source 578
    target 1953
    kind "relation"
    relation "adds possibly"
    weight 1
  ]
  edge [
    source 578
    target 1965
    kind "mentions"
  ]
  edge [
    source 578
    target 1966
    kind "relation"
    relation "cleared"
    weight 1
  ]
  edge [
    source 578
    target 1968
    kind "mentions"
  ]
  edge [
    source 578
    target 1974
    kind "mentions"
  ]
  edge [
    source 578
    target 1978
    kind "mentions"
  ]
  edge [
    source 578
    target 1980
    kind "mentions"
  ]
  edge [
    source 578
    target 1983
    kind "mentions"
  ]
  edge [
    source 578
    target 1984
    kind "relation"
    relation "gave"
    weight 1
  ]
  edge [
    source 578
    target 1989
    kind "mentions"
  ]
  edge [
    source 578
    target 1992
    kind "relation"
    relation "explains that"
    weight 1
  ]
  edge [
    source 578
    target 1993
    kind "relation"
    relation "reared when"
    weight 1
  ]
  edge [
    source 578
    target 2037
    kind "mentions"
  ]
  edge [
    source 578
    target 2038
    kind "relation"
    relation "carries"
    weight 1
  ]
  edge [
    source 578
    target 2040
    kind "mentions"
  ]
  edge [
    source 578
    target 2043
    kind "mentions"
  ]
  edge [
    source 578
    target 2046
    kind "mentions"
  ]
  edge [
    source 578
    target 2048
    kind "mentions"
  ]
  edge [
    source 578
    target 2057
    kind "relation"
    relation "points to"
    weight 1
  ]
  edge [
    source 578
    target 2058
    kind "relation"
    relation "exclaims"
    weight 1
  ]
  edge [
    source 578
    target 2061
    kind "relation"
    relation "calls"
    weight 1
  ]
  edge [
    source 578
    target 2062
    kind "relation"
    relation "hands"
    weight 1
  ]
  edge [
    source 578
    target 2067
    kind "mentions"
  ]
  edge [
    source 578
    target 2104
    kind "mentions"
  ]
  edge [
    source 578
    target 2113
    kind "relation"
    relation "tells noah he must not bring"
    weight 1
  ]
  edge [
    source 578
    target 2114
    kind "relation"
    relation "says domestic affairs are for"
    weight 1
  ]
  edge [
    source 578
    target 2118
    kind "mentions"
  ]
  edge [
    source 578
    target 2120
    kind "mentions"
  ]
  edge [
    source 578
    target 2140
    kind "mentions"
  ]
  edge [
    source 578
    target 2143
    kind "mentions"
  ]
  edge [
    source 578
    target 2146
    kind "mentions"
  ]
  edge [
    source 578
    target 2152
    kind "mentions"
  ]
  edge [
    source 581
    target 597
    kind "mentions"
  ]
  edge [
    source 586
    target 587
    kind "mentions"
  ]
  edge [
    source 586
    target 588
    kind "mentions"
  ]
  edge [
    source 586
    target 589
    kind "mentions"
  ]
  edge [
    source 586
    target 590
    kind "mentions"
  ]
  edge [
    source 586
    target 591
    kind "mentions"
  ]
  edge [
    source 586
    target 2232
    kind "summarizes"
  ]
  edge [
    source 589
    target 824
    kind "mentions"
  ]
  edge [
    source 589
    target 1347
    kind "mentions"
  ]
  edge [
    source 589
    target 1996
    kind "mentions"
  ]
  edge [
    source 589
    target 2020
    kind "mentions"
  ]
  edge [
    source 589
    target 2170
    kind "mentions"
  ]
  edge [
    source 592
    target 593
    kind "mentions"
  ]
  edge [
    source 592
    target 594
    kind "mentions"
  ]
  edge [
    source 592
    target 595
    kind "mentions"
  ]
  edge [
    source 592
    target 596
    kind "mentions"
  ]
  edge [
    source 592
    target 2230
    kind "summarizes"
  ]
  edge [
    source 597
    target 598
    kind "mentions"
  ]
  edge [
    source 597
    target 599
    kind "mentions"
  ]
  edge [
    source 597
    target 600
    kind "mentions"
  ]
  edge [
    source 597
    target 601
    kind "mentions"
  ]
  edge [
    source 597
    target 602
    kind "mentions"
  ]
  edge [
    source 597
    target 2222
    kind "summarizes"
  ]
  edge [
    source 603
    target 604
    kind "from_chunk"
  ]
  edge [
    source 603
    target 613
    kind "from_chunk"
  ]
  edge [
    source 604
    target 605
    kind "mentions"
  ]
  edge [
    source 604
    target 606
    kind "mentions"
  ]
  edge [
    source 604
    target 607
    kind "mentions"
  ]
  edge [
    source 604
    target 608
    kind "mentions"
  ]
  edge [
    source 604
    target 609
    kind "mentions"
  ]
  edge [
    source 604
    target 610
    kind "mentions"
  ]
  edge [
    source 604
    target 611
    kind "mentions"
  ]
  edge [
    source 604
    target 612
    kind "mentions"
  ]
  edge [
    source 604
    target 2222
    kind "summarizes"
  ]
  edge [
    source 606
    target 616
    kind "mentions"
  ]
  edge [
    source 606
    target 617
    kind "relation"
    relation "has colors"
    weight 1
  ]
  edge [
    source 606
    target 618
    kind "mentions"
  ]
  edge [
    source 606
    target 660
    kind "mentions"
  ]
  edge [
    source 606
    target 667
    kind "mentions"
  ]
  edge [
    source 606
    target 665
    kind "relation"
    relation "had confidence in"
    weight 1
  ]
  edge [
    source 606
    target 940
    kind "mentions"
  ]
  edge [
    source 606
    target 1102
    kind "mentions"
  ]
  edge [
    source 606
    target 1109
    kind "mentions"
  ]
  edge [
    source 606
    target 1938
    kind "mentions"
  ]
  edge [
    source 606
    target 2143
    kind "mentions"
  ]
  edge [
    source 612
    target 710
    kind "mentions"
  ]
  edge [
    source 612
    target 649
    kind "relation"
    relation "mentions"
    weight 1
  ]
  edge [
    source 612
    target 732
    kind "mentions"
  ]
  edge [
    source 613
    target 614
    kind "mentions"
  ]
  edge [
    source 613
    target 2222
    kind "summarizes"
  ]
  edge [
    source 615
    target 616
    kind "from_chunk"
  ]
  edge [
    source 615
    target 618
    kind "from_chunk"
  ]
  edge [
    source 615
    target 621
    kind "from_chunk"
  ]
  edge [
    source 615
    target 627
    kind "from_chunk"
  ]
  edge [
    source 615
    target 629
    kind "from_chunk"
  ]
  edge [
    source 616
    target 617
    kind "mentions"
  ]
  edge [
    source 616
    target 2220
    kind "summarizes"
  ]
  edge [
    source 617
    target 618
    kind "mentions"
  ]
  edge [
    source 618
    target 619
    kind "mentions"
  ]
  edge [
    source 618
    target 620
    kind "mentions"
  ]
  edge [
    source 618
    target 2220
    kind "summarizes"
  ]
  edge [
    source 621
    target 622
    kind "mentions"
  ]
  edge [
    source 621
    target 623
    kind "mentions"
  ]
  edge [
    source 621
    target 624
    kind "mentions"
  ]
  edge [
    source 621
    target 625
    kind "mentions"
  ]
  edge [
    source 621
    target 626
    kind "mentions"
  ]
  edge [
    source 621
    target 2220
    kind "summarizes"
  ]
  edge [
    source 622
    target 627
    kind "mentions"
  ]
  edge [
    source 623
    target 627
    kind "mentions"
  ]
  edge [
    source 627
    target 628
    kind "mentions"
  ]
  edge [
    source 627
    target 2220
    kind "summarizes"
  ]
  edge [
    source 629
    target 630
    kind "mentions"
  ]
  edge [
    source 629
    target 631
    kind "mentions"
  ]
  edge [
    source 629
    target 2227
    kind "summarizes"
  ]
  edge [
    source 630
    target 633
    kind "mentions"
  ]
  edge [
    source 630
    target 631
    kind "relation"
    relation "is served at"
    weight 1
  ]
  edge [
    source 631
    target 633
    kind "mentions"
  ]
  edge [
    source 632
    target 633
    kind "from_chunk"
  ]
  edge [
    source 632
    target 646
    kind "from_chunk"
  ]
  edge [
    source 633
    target 634
    kind "mentions"
  ]
  edge [
    source 633
    target 635
    kind "mentions"
  ]
  edge [
    source 633
    target 636
    kind "mentions"
  ]
  edge [
    source 633
    target 637
    kind "mentions"
  ]
  edge [
    source 633
    target 638
    kind "mentions"
  ]
  edge [
    source 633
    target 639
    kind "mentions"
  ]
  edge [
    source 633
    target 640
    kind "mentions"
  ]
  edge [
    source 633
    target 641
    kind "mentions"
  ]
  edge [
    source 633
    target 642
    kind "mentions"
  ]
  edge [
    source 633
    target 643
    kind "mentions"
  ]
  edge [
    source 633
    target 644
    kind "mentions"
  ]
  edge [
    source 633
    target 645
    kind "mentions"
  ]
  edge [
    source 633
    target 2227
    kind "summarizes"
  ]
  edge [
    source 634
    target 646
    kind "mentions"
  ]
  edge [
    source 634
    target 700
    kind "mentions"
  ]
  edge [
    source 634
    target 1161
    kind "mentions"
  ]
  edge [
    source 644
    target 683
    kind "mentions"
  ]
  edge [
    source 644
    target 2037
    kind "mentions"
  ]
  edge [
    source 644
    target 649
    kind "relation"
    relation "exclaims to | was once a friend of | is now a relative of"
    weight 3
  ]
  edge [
    source 644
    target 2043
    kind "mentions"
  ]
  edge [
    source 645
    target 646
    kind "mentions"
  ]
  edge [
    source 646
    target 2227
    kind "summarizes"
  ]
  edge [
    source 647
    target 648
    kind "from_chunk"
  ]
  edge [
    source 647
    target 653
    kind "from_chunk"
  ]
  edge [
    source 647
    target 656
    kind "from_chunk"
  ]
  edge [
    source 648
    target 649
    kind "mentions"
  ]
  edge [
    source 648
    target 650
    kind "mentions"
  ]
  edge [
    source 648
    target 651
    kind "mentions"
  ]
  edge [
    source 648
    target 652
    kind "mentions"
  ]
  edge [
    source 648
    target 2225
    kind "summarizes"
  ]
  edge [
    source 649
    target 650
    kind "relation"
    relation "is playing as"
    weight 1
  ]
  edge [
    source 649
    target 653
    kind "mentions"
  ]
  edge [
    source 649
    target 654
    kind "relation"
    relation "has lived in"
    weight 1
  ]
  edge [
    source 649
    target 656
    kind "mentions"
  ]
  edge [
    source 649
    target 657
    kind "relation"
    relation "reopened"
    weight 1
  ]
  edge [
    source 649
    target 658
    kind "relation"
    relation "refuses to hear"
    weight 1
  ]
  edge [
    source 649
    target 672
    kind "mentions"
  ]
  edge [
    source 649
    target 675
    kind "relation"
    relation "is at | is fixed at | will take dandy out of"
    weight 3
  ]
  edge [
    source 649
    target 683
    kind "mentions"
  ]
  edge [
    source 649
    target 685
    kind "relation"
    relation "is sorry for"
    weight 1
  ]
  edge [
    source 649
    target 651
    kind "relation"
    relation "is not offended by"
    weight 1
  ]
  edge [
    source 649
    target 687
    kind "mentions"
  ]
  edge [
    source 649
    target 688
    kind "relation"
    relation "is surprised to see | roars with laughter at"
    weight 2
  ]
  edge [
    source 649
    target 689
    kind "mentions"
  ]
  edge [
    source 649
    target 691
    kind "relation"
    relation "says he has been roasting"
    weight 1
  ]
  edge [
    source 649
    target 710
    kind "mentions"
  ]
  edge [
    source 649
    target 711
    kind "relation"
    relation "mentions"
    weight 1
  ]
  edge [
    source 649
    target 712
    kind "relation"
    relation "brought down with"
    weight 1
  ]
  edge [
    source 649
    target 723
    kind "relation"
    relation "says the horse is as fit as"
    weight 1
  ]
  edge [
    source 649
    target 724
    kind "relation"
    relation "says the horse shines like"
    weight 1
  ]
  edge [
    source 649
    target 720
    kind "relation"
    relation "says the horse has no excess weight"
    weight 1
  ]
  edge [
    source 649
    target 732
    kind "mentions"
  ]
  edge [
    source 649
    target 741
    kind "mentions"
  ]
  edge [
    source 649
    target 940
    kind "mentions"
  ]
  edge [
    source 649
    target 948
    kind "relation"
    relation "confirms the horse is"
    weight 1
  ]
  edge [
    source 649
    target 949
    kind "relation"
    relation "says george's tail is"
    weight 1
  ]
  edge [
    source 649
    target 954
    kind "mentions"
  ]
  edge [
    source 649
    target 959
    kind "mentions"
  ]
  edge [
    source 649
    target 961
    kind "mentions"
  ]
  edge [
    source 649
    target 962
    kind "mentions"
  ]
  edge [
    source 649
    target 992
    kind "mentions"
  ]
  edge [
    source 649
    target 998
    kind "mentions"
  ]
  edge [
    source 649
    target 1009
    kind "relation"
    relation "expresses pity about"
    weight 1
  ]
  edge [
    source 649
    target 1011
    kind "relation"
    relation "responds"
    weight 1
  ]
  edge [
    source 649
    target 1000
    kind "relation"
    relation "asks about"
    weight 1
  ]
  edge [
    source 649
    target 1015
    kind "relation"
    relation "is shocked by"
    weight 1
  ]
  edge [
    source 649
    target 1016
    kind "relation"
    relation "orders"
    weight 1
  ]
  edge [
    source 649
    target 1019
    kind "mentions"
  ]
  edge [
    source 649
    target 1039
    kind "mentions"
  ]
  edge [
    source 649
    target 1040
    kind "relation"
    relation "has toys for playing if one wakes early"
    weight 1
  ]
  edge [
    source 649
    target 1044
    kind "mentions"
  ]
  edge [
    source 649
    target 1046
    kind "relation"
    relation "is too tired for"
    weight 1
  ]
  edge [
    source 649
    target 1048
    kind "mentions"
  ]
  edge [
    source 649
    target 1050
    kind "mentions"
  ]
  edge [
    source 649
    target 1051
    kind "relation"
    relation "will take"
    weight 1
  ]
  edge [
    source 649
    target 1251
    kind "mentions"
  ]
  edge [
    source 649
    target 1258
    kind "mentions"
  ]
  edge [
    source 649
    target 1259
    kind "relation"
    relation "carries | blows out"
    weight 2
  ]
  edge [
    source 649
    target 927
    kind "relation"
    relation "confirms"
    weight 1
  ]
  edge [
    source 649
    target 1260
    kind "relation"
    relation "will doze here till"
    weight 1
  ]
  edge [
    source 649
    target 1267
    kind "mentions"
  ]
  edge [
    source 649
    target 1273
    kind "mentions"
  ]
  edge [
    source 649
    target 1275
    kind "relation"
    relation "says the cot wouldn't hold"
    weight 1
  ]
  edge [
    source 649
    target 1282
    kind "mentions"
  ]
  edge [
    source 649
    target 1290
    kind "mentions"
  ]
  edge [
    source 649
    target 674
    kind "relation"
    relation "suggests swapping halves of"
    weight 1
  ]
  edge [
    source 649
    target 1004
    kind "relation"
    relation "takes"
    weight 1
  ]
  edge [
    source 649
    target 1297
    kind "mentions"
  ]
  edge [
    source 649
    target 1298
    kind "relation"
    relation "has lost contact with"
    weight 1
  ]
  edge [
    source 649
    target 1299
    kind "relation"
    relation "has an introduction to"
    weight 1
  ]
  edge [
    source 649
    target 1304
    kind "relation"
    relation "peeps through"
    weight 1
  ]
  edge [
    source 649
    target 924
    kind "relation"
    relation "realizes people are not near"
    weight 1
  ]
  edge [
    source 649
    target 1300
    kind "relation"
    relation "takes"
    weight 1
  ]
  edge [
    source 649
    target 1356
    kind "mentions"
  ]
  edge [
    source 649
    target 1378
    kind "relation"
    relation "twists"
    weight 1
  ]
  edge [
    source 649
    target 1360
    kind "relation"
    relation "covers tarver's face with"
    weight 1
  ]
  edge [
    source 649
    target 1382
    kind "mentions"
  ]
  edge [
    source 649
    target 1398
    kind "relation"
    relation "asks where"
    weight 1
  ]
  edge [
    source 649
    target 1711
    kind "mentions"
  ]
  edge [
    source 649
    target 1413
    kind "relation"
    relation "admits"
    weight 1
  ]
  edge [
    source 649
    target 1726
    kind "relation"
    relation "remarks"
    weight 1
  ]
  edge [
    source 649
    target 1729
    kind "mentions"
  ]
  edge [
    source 649
    target 1740
    kind "mentions"
  ]
  edge [
    source 649
    target 1744
    kind "relation"
    relation "tells noah"
    weight 1
  ]
  edge [
    source 649
    target 1745
    kind "relation"
    relation "reveals that georgiana is"
    weight 1
  ]
  edge [
    source 649
    target 1417
    kind "relation"
    relation "will come over officially | tells noah to get out of the way | instructs | says the first thing to do is to get"
    weight 4
  ]
  edge [
    source 649
    target 1741
    kind "relation"
    relation "complains about"
    weight 1
  ]
  edge [
    source 649
    target 1747
    kind "relation"
    relation "and georgiana exchange looks of"
    weight 1
  ]
  edge [
    source 649
    target 1749
    kind "mentions"
  ]
  edge [
    source 649
    target 1761
    kind "relation"
    relation "asks georgiana"
    weight 1
  ]
  edge [
    source 649
    target 1765
    kind "mentions"
  ]
  edge [
    source 649
    target 1766
    kind "relation"
    relation "reports the disappearance of | dictates the description of"
    weight 2
  ]
  edge [
    source 649
    target 1773
    kind "mentions"
  ]
  edge [
    source 649
    target 1767
    kind "relation"
    relation "asks noah if he has recorded"
    weight 1
  ]
  edge [
    source 649
    target 1776
    kind "mentions"
  ]
  edge [
    source 649
    target 1788
    kind "mentions"
  ]
  edge [
    source 649
    target 1789
    kind "relation"
    relation "cannot think about"
    weight 1
  ]
  edge [
    source 649
    target 1792
    kind "relation"
    relation "states that a good woman has arranged"
    weight 1
  ]
  edge [
    source 649
    target 1798
    kind "mentions"
  ]
  edge [
    source 649
    target 1802
    kind "mentions"
  ]
  edge [
    source 649
    target 1803
    kind "relation"
    relation "is the owner of"
    weight 1
  ]
  edge [
    source 649
    target 1812
    kind "mentions"
  ]
  edge [
    source 649
    target 1833
    kind "mentions"
  ]
  edge [
    source 649
    target 1848
    kind "mentions"
  ]
  edge [
    source 649
    target 1851
    kind "mentions"
  ]
  edge [
    source 649
    target 1899
    kind "mentions"
  ]
  edge [
    source 649
    target 1906
    kind "mentions"
  ]
  edge [
    source 649
    target 1908
    kind "relation"
    relation "urges"
    weight 1
  ]
  edge [
    source 649
    target 1909
    kind "relation"
    relation "seizes"
    weight 1
  ]
  edge [
    source 649
    target 1911
    kind "mentions"
  ]
  edge [
    source 649
    target 1916
    kind "relation"
    relation "instructs"
    weight 1
  ]
  edge [
    source 649
    target 1917
    kind "mentions"
  ]
  edge [
    source 649
    target 1922
    kind "relation"
    relation "acknowledges"
    weight 1
  ]
  edge [
    source 649
    target 1926
    kind "mentions"
  ]
  edge [
    source 649
    target 1938
    kind "mentions"
  ]
  edge [
    source 649
    target 1965
    kind "mentions"
  ]
  edge [
    source 649
    target 1968
    kind "mentions"
  ]
  edge [
    source 649
    target 1970
    kind "mentions"
  ]
  edge [
    source 649
    target 1167
    kind "relation"
    relation "had his horse swallow"
    weight 1
  ]
  edge [
    source 649
    target 1971
    kind "relation"
    relation "is expecting"
    weight 1
  ]
  edge [
    source 649
    target 1974
    kind "mentions"
  ]
  edge [
    source 649
    target 1322
    kind "relation"
    relation "pulled the horse's nose-bag over"
    weight 1
  ]
  edge [
    source 649
    target 1976
    kind "relation"
    relation "dismisses as"
    weight 1
  ]
  edge [
    source 649
    target 1978
    kind "mentions"
  ]
  edge [
    source 649
    target 1980
    kind "mentions"
  ]
  edge [
    source 649
    target 1983
    kind "mentions"
  ]
  edge [
    source 649
    target 1986
    kind "relation"
    relation "compares georgiana to"
    weight 1
  ]
  edge [
    source 649
    target 1989
    kind "mentions"
  ]
  edge [
    source 649
    target 1994
    kind "relation"
    relation "did not put"
    weight 1
  ]
  edge [
    source 649
    target 1996
    kind "mentions"
  ]
  edge [
    source 649
    target 2037
    kind "mentions"
  ]
  edge [
    source 649
    target 705
    kind "relation"
    relation "enters at"
    weight 1
  ]
  edge [
    source 649
    target 2039
    kind "relation"
    relation "has in hand"
    weight 1
  ]
  edge [
    source 649
    target 2040
    kind "mentions"
  ]
  edge [
    source 649
    target 2043
    kind "mentions"
  ]
  edge [
    source 649
    target 2044
    kind "mentions"
  ]
  edge [
    source 649
    target 2045
    kind "relation"
    relation "designates as"
    weight 1
  ]
  edge [
    source 649
    target 2048
    kind "mentions"
  ]
  edge [
    source 649
    target 2055
    kind "relation"
    relation "identifies the chief ingredient of"
    weight 1
  ]
  edge [
    source 649
    target 2067
    kind "mentions"
  ]
  edge [
    source 649
    target 2104
    kind "mentions"
  ]
  edge [
    source 649
    target 2122
    kind "mentions"
  ]
  edge [
    source 649
    target 2125
    kind "mentions"
  ]
  edge [
    source 649
    target 2146
    kind "mentions"
  ]
  edge [
    source 649
    target 2149
    kind "relation"
    relation "says there is no harm in laughter for"
    weight 1
  ]
  edge [
    source 649
    target 2150
    kind "mentions"
  ]
  edge [
    source 649
    target 742
    kind "relation"
    relation "says there is no harm in"
    weight 1
  ]
  edge [
    source 650
    target 1337
    kind "mentions"
  ]
  edge [
    source 651
    target 672
    kind "mentions"
  ]
  edge [
    source 651
    target 683
    kind "mentions"
  ]
  edge [
    source 651
    target 689
    kind "mentions"
  ]
  edge [
    source 651
    target 959
    kind "mentions"
  ]
  edge [
    source 651
    target 1251
    kind "mentions"
  ]
  edge [
    source 653
    target 654
    kind "mentions"
  ]
  edge [
    source 653
    target 655
    kind "mentions"
  ]
  edge [
    source 653
    target 2232
    kind "summarizes"
  ]
  edge [
    source 656
    target 657
    kind "mentions"
  ]
  edge [
    source 656
    target 658
    kind "mentions"
  ]
  edge [
    source 656
    target 2220
    kind "summarizes"
  ]
  edge [
    source 659
    target 660
    kind "from_chunk"
  ]
  edge [
    source 659
    target 667
    kind "from_chunk"
  ]
  edge [
    source 660
    target 661
    kind "mentions"
  ]
  edge [
    source 660
    target 662
    kind "mentions"
  ]
  edge [
    source 660
    target 663
    kind "mentions"
  ]
  edge [
    source 660
    target 664
    kind "mentions"
  ]
  edge [
    source 660
    target 665
    kind "mentions"
  ]
  edge [
    source 660
    target 666
    kind "mentions"
  ]
  edge [
    source 660
    target 2227
    kind "summarizes"
  ]
  edge [
    source 665
    target 666
    kind "relation"
    relation "is a bay mare"
    weight 1
  ]
  edge [
    source 665
    target 667
    kind "mentions"
  ]
  edge [
    source 665
    target 669
    kind "relation"
    relation "performed well in"
    weight 1
  ]
  edge [
    source 665
    target 1965
    kind "mentions"
  ]
  edge [
    source 665
    target 1968
    kind "mentions"
  ]
  edge [
    source 665
    target 2067
    kind "mentions"
  ]
  edge [
    source 665
    target 2077
    kind "mentions"
  ]
  edge [
    source 667
    target 668
    kind "mentions"
  ]
  edge [
    source 667
    target 669
    kind "mentions"
  ]
  edge [
    source 667
    target 670
    kind "mentions"
  ]
  edge [
    source 667
    target 2227
    kind "summarizes"
  ]
  edge [
    source 671
    target 672
    kind "from_chunk"
  ]
  edge [
    source 672
    target 673
    kind "mentions"
  ]
  edge [
    source 672
    target 674
    kind "mentions"
  ]
  edge [
    source 672
    target 675
    kind "mentions"
  ]
  edge [
    source 672
    target 676
    kind "mentions"
  ]
  edge [
    source 672
    target 677
    kind "mentions"
  ]
  edge [
    source 672
    target 678
    kind "mentions"
  ]
  edge [
    source 672
    target 679
    kind "mentions"
  ]
  edge [
    source 672
    target 680
    kind "mentions"
  ]
  edge [
    source 672
    target 681
    kind "mentions"
  ]
  edge [
    source 672
    target 2214
    kind "summarizes"
  ]
  edge [
    source 673
    target 680
    kind "relation"
    relation "is known as"
    weight 1
  ]
  edge [
    source 674
    target 681
    kind "relation"
    relation "came out of her stable after"
    weight 1
  ]
  edge [
    source 674
    target 940
    kind "mentions"
  ]
  edge [
    source 674
    target 998
    kind "mentions"
  ]
  edge [
    source 674
    target 1017
    kind "mentions"
  ]
  edge [
    source 674
    target 1019
    kind "mentions"
  ]
  edge [
    source 674
    target 945
    kind "relation"
    relation "has not discovered | lost | is part of | is an invalid"
    weight 4
  ]
  edge [
    source 674
    target 1024
    kind "relation"
    relation "will be distressed when"
    weight 1
  ]
  edge [
    source 674
    target 725
    kind "relation"
    relation "is proud"
    weight 1
  ]
  edge [
    source 674
    target 1278
    kind "mentions"
  ]
  edge [
    source 674
    target 1280
    kind "relation"
    relation "sold himself to | was hooting"
    weight 2
  ]
  edge [
    source 674
    target 1281
    kind "relation"
    relation "was in a dream about"
    weight 1
  ]
  edge [
    source 674
    target 1282
    kind "mentions"
  ]
  edge [
    source 674
    target 1290
    kind "mentions"
  ]
  edge [
    source 674
    target 1382
    kind "mentions"
  ]
  edge [
    source 674
    target 1983
    kind "mentions"
  ]
  edge [
    source 674
    target 2077
    kind "mentions"
  ]
  edge [
    source 675
    target 710
    kind "mentions"
  ]
  edge [
    source 675
    target 812
    kind "mentions"
  ]
  edge [
    source 675
    target 954
    kind "mentions"
  ]
  edge [
    source 675
    target 957
    kind "relation"
    relation "pulls dandy out of"
    weight 2
  ]
  edge [
    source 675
    target 961
    kind "mentions"
  ]
  edge [
    source 675
    target 998
    kind "mentions"
  ]
  edge [
    source 675
    target 1382
    kind "mentions"
  ]
  edge [
    source 679
    target 1069
    kind "mentions"
  ]
  edge [
    source 679
    target 1070
    kind "relation"
    relation "is required by"
    weight 1
  ]
  edge [
    source 679
    target 1072
    kind "mentions"
  ]
  edge [
    source 679
    target 1131
    kind "mentions"
  ]
  edge [
    source 679
    target 1139
    kind "mentions"
  ]
  edge [
    source 679
    target 2067
    kind "mentions"
  ]
  edge [
    source 680
    target 700
    kind "mentions"
  ]
  edge [
    source 680
    target 745
    kind "mentions"
  ]
  edge [
    source 680
    target 998
    kind "mentions"
  ]
  edge [
    source 682
    target 683
    kind "from_chunk"
  ]
  edge [
    source 682
    target 687
    kind "from_chunk"
  ]
  edge [
    source 682
    target 689
    kind "from_chunk"
  ]
  edge [
    source 683
    target 684
    kind "mentions"
  ]
  edge [
    source 683
    target 685
    kind "mentions"
  ]
  edge [
    source 683
    target 686
    kind "mentions"
  ]
  edge [
    source 683
    target 2225
    kind "summarizes"
  ]
  edge [
    source 687
    target 688
    kind "mentions"
  ]
  edge [
    source 687
    target 2225
    kind "summarizes"
  ]
  edge [
    source 688
    target 689
    kind "mentions"
  ]
  edge [
    source 689
    target 690
    kind "mentions"
  ]
  edge [
    source 689
    target 691
    kind "mentions"
  ]
  edge [
    source 689
    target 692
    kind "mentions"
  ]
  edge [
    source 689
    target 693
    kind "mentions"
  ]
  edge [
    source 689
    target 2225
    kind "summarizes"
  ]
  edge [
    source 694
    target 695
    kind "from_chunk"
  ]
  edge [
    source 694
    target 700
    kind "from_chunk"
  ]
  edge [
    source 694
    target 701
    kind "from_chunk"
  ]
  edge [
    source 694
    target 703
    kind "from_chunk"
  ]
  edge [
    source 694
    target 706
    kind "from_chunk"
  ]
  edge [
    source 695
    target 696
    kind "mentions"
  ]
  edge [
    source 695
    target 697
    kind "mentions"
  ]
  edge [
    source 695
    target 698
    kind "mentions"
  ]
  edge [
    source 695
    target 699
    kind "mentions"
  ]
  edge [
    source 695
    target 2224
    kind "summarizes"
  ]
  edge [
    source 700
    target 2227
    kind "summarizes"
  ]
  edge [
    source 701
    target 702
    kind "mentions"
  ]
  edge [
    source 701
    target 2230
    kind "summarizes"
  ]
  edge [
    source 702
    target 1074
    kind "mentions"
  ]
  edge [
    source 702
    target 1117
    kind "mentions"
  ]
  edge [
    source 702
    target 1120
    kind "relation"
    relation "is smoking a cigarette at"
    weight 1
  ]
  edge [
    source 702
    target 1126
    kind "relation"
    relation "has feet on"
    weight 1
  ]
  edge [
    source 703
    target 704
    kind "mentions"
  ]
  edge [
    source 703
    target 705
    kind "mentions"
  ]
  edge [
    source 703
    target 2236
    kind "summarizes"
  ]
  edge [
    source 704
    target 752
    kind "mentions"
  ]
  edge [
    source 704
    target 895
    kind "mentions"
  ]
  edge [
    source 705
    target 811
    kind "mentions"
  ]
  edge [
    source 705
    target 817
    kind "mentions"
  ]
  edge [
    source 705
    target 819
    kind "relation"
    relation "can be opened with"
    weight 1
  ]
  edge [
    source 705
    target 818
    kind "relation"
    relation "has"
    weight 1
  ]
  edge [
    source 705
    target 1297
    kind "mentions"
  ]
  edge [
    source 705
    target 1662
    kind "mentions"
  ]
  edge [
    source 705
    target 1899
    kind "mentions"
  ]
  edge [
    source 705
    target 1904
    kind "relation"
    relation "enter by"
    weight 1
  ]
  edge [
    source 705
    target 2037
    kind "mentions"
  ]
  edge [
    source 705
    target 2043
    kind "mentions"
  ]
  edge [
    source 706
    target 707
    kind "mentions"
  ]
  edge [
    source 706
    target 708
    kind "mentions"
  ]
  edge [
    source 706
    target 2227
    kind "summarizes"
  ]
  edge [
    source 709
    target 710
    kind "from_chunk"
  ]
  edge [
    source 710
    target 711
    kind "mentions"
  ]
  edge [
    source 710
    target 712
    kind "mentions"
  ]
  edge [
    source 710
    target 713
    kind "mentions"
  ]
  edge [
    source 710
    target 714
    kind "mentions"
  ]
  edge [
    source 710
    target 715
    kind "mentions"
  ]
  edge [
    source 710
    target 716
    kind "mentions"
  ]
  edge [
    source 710
    target 717
    kind "mentions"
  ]
  edge [
    source 710
    target 718
    kind "mentions"
  ]
  edge [
    source 710
    target 719
    kind "mentions"
  ]
  edge [
    source 710
    target 720
    kind "mentions"
  ]
  edge [
    source 710
    target 721
    kind "mentions"
  ]
  edge [
    source 710
    target 722
    kind "mentions"
  ]
  edge [
    source 710
    target 723
    kind "mentions"
  ]
  edge [
    source 710
    target 724
    kind "mentions"
  ]
  edge [
    source 710
    target 725
    kind "mentions"
  ]
  edge [
    source 710
    target 726
    kind "mentions"
  ]
  edge [
    source 710
    target 727
    kind "mentions"
  ]
  edge [
    source 710
    target 728
    kind "mentions"
  ]
  edge [
    source 710
    target 729
    kind "mentions"
  ]
  edge [
    source 710
    target 730
    kind "mentions"
  ]
  edge [
    source 710
    target 2222
    kind "summarizes"
  ]
  edge [
    source 711
    target 732
    kind "mentions"
  ]
  edge [
    source 711
    target 1074
    kind "mentions"
  ]
  edge [
    source 713
    target 745
    kind "mentions"
  ]
  edge [
    source 725
    target 732
    kind "mentions"
  ]
  edge [
    source 725
    target 759
    kind "mentions"
  ]
  edge [
    source 725
    target 940
    kind "mentions"
  ]
  edge [
    source 725
    target 941
    kind "relation"
    relation "backed himself to win"
    weight 1
  ]
  edge [
    source 725
    target 947
    kind "relation"
    relation "threw two pails of cold water over"
    weight 1
  ]
  edge [
    source 725
    target 942
    kind "relation"
    relation "harms"
    weight 1
  ]
  edge [
    source 725
    target 951
    kind "relation"
    relation "is described as"
    weight 1
  ]
  edge [
    source 725
    target 998
    kind "mentions"
  ]
  edge [
    source 725
    target 1019
    kind "mentions"
  ]
  edge [
    source 725
    target 1021
    kind "relation"
    relation "will not understand how to hide"
    weight 1
  ]
  edge [
    source 725
    target 1117
    kind "mentions"
  ]
  edge [
    source 725
    target 924
    kind "relation"
    relation "is in"
    weight 1
  ]
  edge [
    source 725
    target 1161
    kind "mentions"
  ]
  edge [
    source 725
    target 1180
    kind "mentions"
  ]
  edge [
    source 725
    target 1223
    kind "mentions"
  ]
  edge [
    source 725
    target 1244
    kind "mentions"
  ]
  edge [
    source 725
    target 1282
    kind "mentions"
  ]
  edge [
    source 725
    target 1382
    kind "mentions"
  ]
  edge [
    source 725
    target 1502
    kind "mentions"
  ]
  edge [
    source 725
    target 1507
    kind "mentions"
  ]
  edge [
    source 725
    target 1572
    kind "mentions"
  ]
  edge [
    source 725
    target 1623
    kind "mentions"
  ]
  edge [
    source 725
    target 1413
    kind "relation"
    relation "identifies old nick as"
    weight 1
  ]
  edge [
    source 725
    target 1634
    kind "mentions"
  ]
  edge [
    source 725
    target 1817
    kind "mentions"
  ]
  edge [
    source 725
    target 1965
    kind "mentions"
  ]
  edge [
    source 725
    target 1967
    kind "relation"
    relation "walked in with"
    weight 2
  ]
  edge [
    source 725
    target 1968
    kind "mentions"
  ]
  edge [
    source 725
    target 1970
    kind "mentions"
  ]
  edge [
    source 725
    target 1974
    kind "mentions"
  ]
  edge [
    source 725
    target 2067
    kind "mentions"
  ]
  edge [
    source 725
    target 2140
    kind "mentions"
  ]
  edge [
    source 728
    target 1102
    kind "mentions"
  ]
  edge [
    source 728
    target 1109
    kind "mentions"
  ]
  edge [
    source 728
    target 1196
    kind "mentions"
  ]
  edge [
    source 728
    target 1218
    kind "mentions"
  ]
  edge [
    source 728
    target 1540
    kind "mentions"
  ]
  edge [
    source 728
    target 1417
    kind "relation"
    relation "can reach the edge of"
    weight 1
  ]
  edge [
    source 728
    target 1926
    kind "mentions"
  ]
  edge [
    source 728
    target 1927
    kind "relation"
    relation "had hundreds of old friends"
    weight 1
  ]
  edge [
    source 728
    target 1928
    kind "relation"
    relation "had hundreds of old friends"
    weight 1
  ]
  edge [
    source 728
    target 1929
    kind "relation"
    relation "had hundreds of old friends"
    weight 1
  ]
  edge [
    source 728
    target 1935
    kind "relation"
    relation "had hundreds of old friends"
    weight 1
  ]
  edge [
    source 731
    target 732
    kind "from_chunk"
  ]
  edge [
    source 731
    target 741
    kind "from_chunk"
  ]
  edge [
    source 732
    target 733
    kind "mentions"
  ]
  edge [
    source 732
    target 734
    kind "mentions"
  ]
  edge [
    source 732
    target 735
    kind "mentions"
  ]
  edge [
    source 732
    target 736
    kind "mentions"
  ]
  edge [
    source 732
    target 737
    kind "mentions"
  ]
  edge [
    source 732
    target 738
    kind "mentions"
  ]
  edge [
    source 732
    target 739
    kind "mentions"
  ]
  edge [
    source 732
    target 740
    kind "mentions"
  ]
  edge [
    source 732
    target 2214
    kind "summarizes"
  ]
  edge [
    source 733
    target 735
    kind "relation"
    relation "was the buyer at"
    weight 1
  ]
  edge [
    source 741
    target 742
    kind "mentions"
  ]
  edge [
    source 741
    target 743
    kind "mentions"
  ]
  edge [
    source 741
    target 2218
    kind "summarizes"
  ]
  edge [
    source 742
    target 2150
    kind "mentions"
  ]
  edge [
    source 742
    target 2152
    kind "mentions"
  ]
  edge [
    source 742
    target 2157
    kind "relation"
    relation "is harmless for"
    weight 1
  ]
  edge [
    source 742
    target 2158
    kind "relation"
    relation "is harmless for"
    weight 1
  ]
  edge [
    source 742
    target 2153
    kind "relation"
    relation "is the subject of"
    weight 1
  ]
  edge [
    source 742
    target 2154
    kind "relation"
    relation "is not the subject of"
    weight 1
  ]
  edge [
    source 744
    target 745
    kind "from_chunk"
  ]
  edge [
    source 744
    target 748
    kind "from_chunk"
  ]
  edge [
    source 745
    target 746
    kind "mentions"
  ]
  edge [
    source 745
    target 747
    kind "mentions"
  ]
  edge [
    source 745
    target 2214
    kind "summarizes"
  ]
  edge [
    source 746
    target 884
    kind "mentions"
  ]
  edge [
    source 748
    target 749
    kind "mentions"
  ]
  edge [
    source 748
    target 750
    kind "mentions"
  ]
  edge [
    source 748
    target 2214
    kind "summarizes"
  ]
  edge [
    source 751
    target 752
    kind "from_chunk"
  ]
  edge [
    source 752
    target 753
    kind "mentions"
  ]
  edge [
    source 752
    target 754
    kind "mentions"
  ]
  edge [
    source 752
    target 755
    kind "mentions"
  ]
  edge [
    source 752
    target 756
    kind "mentions"
  ]
  edge [
    source 752
    target 757
    kind "mentions"
  ]
  edge [
    source 752
    target 2236
    kind "summarizes"
  ]
  edge [
    source 753
    target 849
    kind "mentions"
  ]
  edge [
    source 753
    target 904
    kind "mentions"
  ]
  edge [
    source 753
    target 905
    kind "relation"
    relation "have donated"
    weight 1
  ]
  edge [
    source 753
    target 1059
    kind "mentions"
  ]
  edge [
    source 753
    target 1060
    kind "relation"
    relation "do not possess"
    weight 1
  ]
  edge [
    source 753
    target 2143
    kind "mentions"
  ]
  edge [
    source 753
    target 2144
    kind "relation"
    relation "is for"
    weight 1
  ]
  edge [
    source 757
    target 1488
    kind "mentions"
  ]
  edge [
    source 757
    target 1489
    kind "relation"
    relation "believe the case involves"
    weight 1
  ]
  edge [
    source 757
    target 1490
    kind "relation"
    relation "believe the case involves"
    weight 1
  ]
  edge [
    source 758
    target 759
    kind "from_chunk"
  ]
  edge [
    source 758
    target 766
    kind "from_chunk"
  ]
  edge [
    source 759
    target 760
    kind "mentions"
  ]
  edge [
    source 759
    target 761
    kind "mentions"
  ]
  edge [
    source 759
    target 762
    kind "mentions"
  ]
  edge [
    source 759
    target 763
    kind "mentions"
  ]
  edge [
    source 759
    target 764
    kind "mentions"
  ]
  edge [
    source 759
    target 765
    kind "mentions"
  ]
  edge [
    source 759
    target 2231
    kind "summarizes"
  ]
  edge [
    source 760
    target 2013
    kind "mentions"
  ]
  edge [
    source 760
    target 2018
    kind "mentions"
  ]
  edge [
    source 761
    target 1114
    kind "mentions"
  ]
  edge [
    source 761
    target 2020
    kind "mentions"
  ]
  edge [
    source 766
    target 767
    kind "mentions"
  ]
  edge [
    source 766
    target 768
    kind "mentions"
  ]
  edge [
    source 766
    target 2225
    kind "summarizes"
  ]
  edge [
    source 768
    target 770
    kind "mentions"
  ]
  edge [
    source 769
    target 770
    kind "from_chunk"
  ]
  edge [
    source 770
    target 771
    kind "mentions"
  ]
  edge [
    source 770
    target 772
    kind "mentions"
  ]
  edge [
    source 770
    target 773
    kind "mentions"
  ]
  edge [
    source 770
    target 774
    kind "mentions"
  ]
  edge [
    source 770
    target 775
    kind "mentions"
  ]
  edge [
    source 770
    target 776
    kind "mentions"
  ]
  edge [
    source 770
    target 777
    kind "mentions"
  ]
  edge [
    source 770
    target 778
    kind "mentions"
  ]
  edge [
    source 770
    target 779
    kind "mentions"
  ]
  edge [
    source 770
    target 780
    kind "mentions"
  ]
  edge [
    source 770
    target 781
    kind "mentions"
  ]
  edge [
    source 770
    target 782
    kind "mentions"
  ]
  edge [
    source 770
    target 783
    kind "mentions"
  ]
  edge [
    source 770
    target 784
    kind "mentions"
  ]
  edge [
    source 770
    target 785
    kind "mentions"
  ]
  edge [
    source 770
    target 786
    kind "mentions"
  ]
  edge [
    source 770
    target 787
    kind "mentions"
  ]
  edge [
    source 770
    target 788
    kind "mentions"
  ]
  edge [
    source 770
    target 789
    kind "mentions"
  ]
  edge [
    source 770
    target 790
    kind "mentions"
  ]
  edge [
    source 770
    target 791
    kind "mentions"
  ]
  edge [
    source 770
    target 792
    kind "mentions"
  ]
  edge [
    source 770
    target 793
    kind "mentions"
  ]
  edge [
    source 770
    target 2225
    kind "summarizes"
  ]
  edge [
    source 785
    target 795
    kind "mentions"
  ]
  edge [
    source 785
    target 796
    kind "relation"
    relation "was described as"
    weight 1
  ]
  edge [
    source 794
    target 795
    kind "from_chunk"
  ]
  edge [
    source 794
    target 797
    kind "from_chunk"
  ]
  edge [
    source 794
    target 800
    kind "from_chunk"
  ]
  edge [
    source 794
    target 802
    kind "from_chunk"
  ]
  edge [
    source 794
    target 804
    kind "from_chunk"
  ]
  edge [
    source 794
    target 809
    kind "from_chunk"
  ]
  edge [
    source 794
    target 811
    kind "from_chunk"
  ]
  edge [
    source 794
    target 812
    kind "from_chunk"
  ]
  edge [
    source 795
    target 796
    kind "mentions"
  ]
  edge [
    source 795
    target 2225
    kind "summarizes"
  ]
  edge [
    source 796
    target 809
    kind "mentions"
  ]
  edge [
    source 797
    target 798
    kind "mentions"
  ]
  edge [
    source 797
    target 799
    kind "mentions"
  ]
  edge [
    source 797
    target 2219
    kind "summarizes"
  ]
  edge [
    source 800
    target 801
    kind "mentions"
  ]
  edge [
    source 800
    target 2215
    kind "summarizes"
  ]
  edge [
    source 802
    target 803
    kind "mentions"
  ]
  edge [
    source 802
    target 2215
    kind "summarizes"
  ]
  edge [
    source 804
    target 805
    kind "mentions"
  ]
  edge [
    source 804
    target 806
    kind "mentions"
  ]
  edge [
    source 804
    target 807
    kind "mentions"
  ]
  edge [
    source 804
    target 808
    kind "mentions"
  ]
  edge [
    source 804
    target 2219
    kind "summarizes"
  ]
  edge [
    source 805
    target 807
    kind "relation"
    relation "handed"
    weight 1
  ]
  edge [
    source 809
    target 810
    kind "mentions"
  ]
  edge [
    source 809
    target 2225
    kind "summarizes"
  ]
  edge [
    source 811
    target 2228
    kind "summarizes"
  ]
  edge [
    source 812
    target 813
    kind "mentions"
  ]
  edge [
    source 812
    target 814
    kind "mentions"
  ]
  edge [
    source 812
    target 815
    kind "mentions"
  ]
  edge [
    source 812
    target 2214
    kind "summarizes"
  ]
  edge [
    source 814
    target 891
    kind "mentions"
  ]
  edge [
    source 816
    target 817
    kind "from_chunk"
  ]
  edge [
    source 816
    target 820
    kind "from_chunk"
  ]
  edge [
    source 816
    target 824
    kind "from_chunk"
  ]
  edge [
    source 816
    target 828
    kind "from_chunk"
  ]
  edge [
    source 816
    target 831
    kind "from_chunk"
  ]
  edge [
    source 816
    target 833
    kind "from_chunk"
  ]
  edge [
    source 816
    target 835
    kind "from_chunk"
  ]
  edge [
    source 817
    target 818
    kind "mentions"
  ]
  edge [
    source 817
    target 819
    kind "mentions"
  ]
  edge [
    source 817
    target 2228
    kind "summarizes"
  ]
  edge [
    source 820
    target 821
    kind "mentions"
  ]
  edge [
    source 820
    target 822
    kind "mentions"
  ]
  edge [
    source 820
    target 823
    kind "mentions"
  ]
  edge [
    source 820
    target 2219
    kind "summarizes"
  ]
  edge [
    source 824
    target 825
    kind "mentions"
  ]
  edge [
    source 824
    target 826
    kind "mentions"
  ]
  edge [
    source 824
    target 827
    kind "mentions"
  ]
  edge [
    source 824
    target 2232
    kind "summarizes"
  ]
  edge [
    source 828
    target 829
    kind "mentions"
  ]
  edge [
    source 828
    target 830
    kind "mentions"
  ]
  edge [
    source 828
    target 2219
    kind "summarizes"
  ]
  edge [
    source 831
    target 832
    kind "mentions"
  ]
  edge [
    source 831
    target 2219
    kind "summarizes"
  ]
  edge [
    source 833
    target 834
    kind "mentions"
  ]
  edge [
    source 833
    target 2229
    kind "summarizes"
  ]
  edge [
    source 835
    target 836
    kind "mentions"
  ]
  edge [
    source 835
    target 2215
    kind "summarizes"
  ]
  edge [
    source 837
    target 838
    kind "from_chunk"
  ]
  edge [
    source 837
    target 840
    kind "from_chunk"
  ]
  edge [
    source 837
    target 844
    kind "from_chunk"
  ]
  edge [
    source 837
    target 849
    kind "from_chunk"
  ]
  edge [
    source 837
    target 850
    kind "from_chunk"
  ]
  edge [
    source 838
    target 839
    kind "mentions"
  ]
  edge [
    source 838
    target 2215
    kind "summarizes"
  ]
  edge [
    source 840
    target 841
    kind "mentions"
  ]
  edge [
    source 840
    target 842
    kind "mentions"
  ]
  edge [
    source 840
    target 843
    kind "mentions"
  ]
  edge [
    source 840
    target 2215
    kind "summarizes"
  ]
  edge [
    source 844
    target 845
    kind "mentions"
  ]
  edge [
    source 844
    target 846
    kind "mentions"
  ]
  edge [
    source 844
    target 847
    kind "mentions"
  ]
  edge [
    source 844
    target 848
    kind "mentions"
  ]
  edge [
    source 844
    target 2229
    kind "summarizes"
  ]
  edge [
    source 845
    target 846
    kind "relation"
    relation "will be sent with"
    weight 1
  ]
  edge [
    source 846
    target 848
    kind "relation"
    relation "will arrive at"
    weight 1
  ]
  edge [
    source 849
    target 2234
    kind "summarizes"
  ]
  edge [
    source 850
    target 851
    kind "mentions"
  ]
  edge [
    source 850
    target 852
    kind "mentions"
  ]
  edge [
    source 850
    target 853
    kind "mentions"
  ]
  edge [
    source 850
    target 2215
    kind "summarizes"
  ]
  edge [
    source 852
    target 855
    kind "mentions"
  ]
  edge [
    source 854
    target 855
    kind "from_chunk"
  ]
  edge [
    source 855
    target 856
    kind "mentions"
  ]
  edge [
    source 855
    target 857
    kind "mentions"
  ]
  edge [
    source 855
    target 858
    kind "mentions"
  ]
  edge [
    source 855
    target 859
    kind "mentions"
  ]
  edge [
    source 855
    target 860
    kind "mentions"
  ]
  edge [
    source 855
    target 861
    kind "mentions"
  ]
  edge [
    source 855
    target 862
    kind "mentions"
  ]
  edge [
    source 855
    target 863
    kind "mentions"
  ]
  edge [
    source 855
    target 864
    kind "mentions"
  ]
  edge [
    source 855
    target 865
    kind "mentions"
  ]
  edge [
    source 855
    target 866
    kind "mentions"
  ]
  edge [
    source 855
    target 867
    kind "mentions"
  ]
  edge [
    source 855
    target 868
    kind "mentions"
  ]
  edge [
    source 855
    target 2233
    kind "summarizes"
  ]
  edge [
    source 856
    target 866
    kind "relation"
    relation "is compared to"
    weight 1
  ]
  edge [
    source 857
    target 893
    kind "mentions"
  ]
  edge [
    source 859
    target 870
    kind "mentions"
  ]
  edge [
    source 859
    target 992
    kind "mentions"
  ]
  edge [
    source 860
    target 870
    kind "mentions"
  ]
  edge [
    source 860
    target 900
    kind "mentions"
  ]
  edge [
    source 861
    target 977
    kind "mentions"
  ]
  edge [
    source 865
    target 870
    kind "mentions"
  ]
  edge [
    source 867
    target 870
    kind "mentions"
  ]
  edge [
    source 869
    target 870
    kind "from_chunk"
  ]
  edge [
    source 869
    target 880
    kind "from_chunk"
  ]
  edge [
    source 870
    target 871
    kind "mentions"
  ]
  edge [
    source 870
    target 872
    kind "mentions"
  ]
  edge [
    source 870
    target 873
    kind "mentions"
  ]
  edge [
    source 870
    target 874
    kind "mentions"
  ]
  edge [
    source 870
    target 875
    kind "mentions"
  ]
  edge [
    source 870
    target 876
    kind "mentions"
  ]
  edge [
    source 870
    target 877
    kind "mentions"
  ]
  edge [
    source 870
    target 878
    kind "mentions"
  ]
  edge [
    source 870
    target 879
    kind "mentions"
  ]
  edge [
    source 870
    target 2217
    kind "summarizes"
  ]
  edge [
    source 880
    target 2217
    kind "summarizes"
  ]
  edge [
    source 881
    target 882
    kind "from_chunk"
  ]
  edge [
    source 881
    target 884
    kind "from_chunk"
  ]
  edge [
    source 881
    target 885
    kind "from_chunk"
  ]
  edge [
    source 881
    target 888
    kind "from_chunk"
  ]
  edge [
    source 881
    target 891
    kind "from_chunk"
  ]
  edge [
    source 881
    target 893
    kind "from_chunk"
  ]
  edge [
    source 881
    target 895
    kind "from_chunk"
  ]
  edge [
    source 881
    target 898
    kind "from_chunk"
  ]
  edge [
    source 881
    target 900
    kind "from_chunk"
  ]
  edge [
    source 882
    target 883
    kind "mentions"
  ]
  edge [
    source 882
    target 2217
    kind "summarizes"
  ]
  edge [
    source 883
    target 898
    kind "mentions"
  ]
  edge [
    source 884
    target 2234
    kind "summarizes"
  ]
  edge [
    source 885
    target 886
    kind "mentions"
  ]
  edge [
    source 885
    target 887
    kind "mentions"
  ]
  edge [
    source 885
    target 2217
    kind "summarizes"
  ]
  edge [
    source 888
    target 889
    kind "mentions"
  ]
  edge [
    source 888
    target 890
    kind "mentions"
  ]
  edge [
    source 888
    target 2217
    kind "summarizes"
  ]
  edge [
    source 891
    target 892
    kind "mentions"
  ]
  edge [
    source 891
    target 2214
    kind "summarizes"
  ]
  edge [
    source 893
    target 894
    kind "mentions"
  ]
  edge [
    source 893
    target 2217
    kind "summarizes"
  ]
  edge [
    source 895
    target 896
    kind "mentions"
  ]
  edge [
    source 895
    target 897
    kind "mentions"
  ]
  edge [
    source 895
    target 2236
    kind "summarizes"
  ]
  edge [
    source 896
    target 1074
    kind "mentions"
  ]
  edge [
    source 896
    target 1749
    kind "mentions"
  ]
  edge [
    source 896
    target 1751
    kind "relation"
    relation "checked"
    weight 1
  ]
  edge [
    source 898
    target 899
    kind "mentions"
  ]
  edge [
    source 898
    target 2217
    kind "summarizes"
  ]
  edge [
    source 900
    target 901
    kind "mentions"
  ]
  edge [
    source 900
    target 902
    kind "mentions"
  ]
  edge [
    source 900
    target 2234
    kind "summarizes"
  ]
  edge [
    source 903
    target 904
    kind "from_chunk"
  ]
  edge [
    source 903
    target 917
    kind "from_chunk"
  ]
  edge [
    source 904
    target 905
    kind "mentions"
  ]
  edge [
    source 904
    target 906
    kind "mentions"
  ]
  edge [
    source 904
    target 907
    kind "mentions"
  ]
  edge [
    source 904
    target 908
    kind "mentions"
  ]
  edge [
    source 904
    target 909
    kind "mentions"
  ]
  edge [
    source 904
    target 910
    kind "mentions"
  ]
  edge [
    source 904
    target 911
    kind "mentions"
  ]
  edge [
    source 904
    target 912
    kind "mentions"
  ]
  edge [
    source 904
    target 913
    kind "mentions"
  ]
  edge [
    source 904
    target 914
    kind "mentions"
  ]
  edge [
    source 904
    target 915
    kind "mentions"
  ]
  edge [
    source 904
    target 916
    kind "mentions"
  ]
  edge [
    source 904
    target 2234
    kind "summarizes"
  ]
  edge [
    source 905
    target 906
    kind "relation"
    relation "include"
    weight 1
  ]
  edge [
    source 905
    target 913
    kind "relation"
    relation "have contributed to"
    weight 1
  ]
  edge [
    source 907
    target 917
    kind "mentions"
  ]
  edge [
    source 908
    target 917
    kind "mentions"
  ]
  edge [
    source 909
    target 917
    kind "mentions"
  ]
  edge [
    source 910
    target 917
    kind "mentions"
  ]
  edge [
    source 915
    target 917
    kind "mentions"
  ]
  edge [
    source 917
    target 918
    kind "mentions"
  ]
  edge [
    source 917
    target 919
    kind "mentions"
  ]
  edge [
    source 917
    target 2234
    kind "summarizes"
  ]
  edge [
    source 920
    target 921
    kind "from_chunk"
  ]
  edge [
    source 920
    target 938
    kind "from_chunk"
  ]
  edge [
    source 921
    target 922
    kind "mentions"
  ]
  edge [
    source 921
    target 923
    kind "mentions"
  ]
  edge [
    source 921
    target 924
    kind "mentions"
  ]
  edge [
    source 921
    target 925
    kind "mentions"
  ]
  edge [
    source 921
    target 926
    kind "mentions"
  ]
  edge [
    source 921
    target 927
    kind "mentions"
  ]
  edge [
    source 921
    target 928
    kind "mentions"
  ]
  edge [
    source 921
    target 929
    kind "mentions"
  ]
  edge [
    source 921
    target 930
    kind "mentions"
  ]
  edge [
    source 921
    target 931
    kind "mentions"
  ]
  edge [
    source 921
    target 932
    kind "mentions"
  ]
  edge [
    source 921
    target 933
    kind "mentions"
  ]
  edge [
    source 921
    target 934
    kind "mentions"
  ]
  edge [
    source 921
    target 935
    kind "mentions"
  ]
  edge [
    source 921
    target 936
    kind "mentions"
  ]
  edge [
    source 921
    target 937
    kind "mentions"
  ]
  edge [
    source 921
    target 2230
    kind "summarizes"
  ]
  edge [
    source 922
    target 938
    kind "mentions"
  ]
  edge [
    source 923
    target 931
    kind "relation"
    relation "rings violently"
    weight 2
  ]
  edge [
    source 923
    target 938
    kind "mentions"
  ]
  edge [
    source 924
    target 938
    kind "mentions"
  ]
  edge [
    source 924
    target 954
    kind "mentions"
  ]
  edge [
    source 924
    target 1027
    kind "mentions"
  ]
  edge [
    source 924
    target 1117
    kind "mentions"
  ]
  edge [
    source 924
    target 1297
    kind "mentions"
  ]
  edge [
    source 924
    target 1468
    kind "mentions"
  ]
  edge [
    source 924
    target 1528
    kind "mentions"
  ]
  edge [
    source 925
    target 938
    kind "mentions"
  ]
  edge [
    source 926
    target 938
    kind "mentions"
  ]
  edge [
    source 926
    target 961
    kind "mentions"
  ]
  edge [
    source 926
    target 1251
    kind "mentions"
  ]
  edge [
    source 926
    target 1623
    kind "mentions"
  ]
  edge [
    source 927
    target 938
    kind "mentions"
  ]
  edge [
    source 927
    target 940
    kind "mentions"
  ]
  edge [
    source 927
    target 998
    kind "mentions"
  ]
  edge [
    source 927
    target 1027
    kind "mentions"
  ]
  edge [
    source 927
    target 1034
    kind "mentions"
  ]
  edge [
    source 927
    target 1258
    kind "mentions"
  ]
  edge [
    source 928
    target 938
    kind "mentions"
  ]
  edge [
    source 929
    target 938
    kind "mentions"
  ]
  edge [
    source 930
    target 938
    kind "mentions"
  ]
  edge [
    source 931
    target 938
    kind "mentions"
  ]
  edge [
    source 932
    target 938
    kind "mentions"
  ]
  edge [
    source 933
    target 938
    kind "mentions"
  ]
  edge [
    source 934
    target 938
    kind "mentions"
  ]
  edge [
    source 935
    target 938
    kind "mentions"
  ]
  edge [
    source 936
    target 938
    kind "mentions"
  ]
  edge [
    source 938
    target 2230
    kind "summarizes"
  ]
  edge [
    source 939
    target 940
    kind "from_chunk"
  ]
  edge [
    source 940
    target 941
    kind "mentions"
  ]
  edge [
    source 940
    target 942
    kind "mentions"
  ]
  edge [
    source 940
    target 943
    kind "mentions"
  ]
  edge [
    source 940
    target 944
    kind "mentions"
  ]
  edge [
    source 940
    target 945
    kind "mentions"
  ]
  edge [
    source 940
    target 946
    kind "mentions"
  ]
  edge [
    source 940
    target 947
    kind "mentions"
  ]
  edge [
    source 940
    target 948
    kind "mentions"
  ]
  edge [
    source 940
    target 949
    kind "mentions"
  ]
  edge [
    source 940
    target 950
    kind "mentions"
  ]
  edge [
    source 940
    target 951
    kind "mentions"
  ]
  edge [
    source 940
    target 952
    kind "mentions"
  ]
  edge [
    source 940
    target 2226
    kind "summarizes"
  ]
  edge [
    source 941
    target 1965
    kind "mentions"
  ]
  edge [
    source 942
    target 1681
    kind "mentions"
  ]
  edge [
    source 942
    target 1413
    kind "relation"
    relation "asks for"
    weight 1
  ]
  edge [
    source 945
    target 998
    kind "mentions"
  ]
  edge [
    source 945
    target 1019
    kind "mentions"
  ]
  edge [
    source 945
    target 1278
    kind "mentions"
  ]
  edge [
    source 945
    target 1282
    kind "mentions"
  ]
  edge [
    source 946
    target 1074
    kind "mentions"
  ]
  edge [
    source 953
    target 954
    kind "from_chunk"
  ]
  edge [
    source 953
    target 959
    kind "from_chunk"
  ]
  edge [
    source 953
    target 961
    kind "from_chunk"
  ]
  edge [
    source 953
    target 962
    kind "from_chunk"
  ]
  edge [
    source 954
    target 955
    kind "mentions"
  ]
  edge [
    source 954
    target 956
    kind "mentions"
  ]
  edge [
    source 954
    target 957
    kind "mentions"
  ]
  edge [
    source 954
    target 958
    kind "mentions"
  ]
  edge [
    source 954
    target 2214
    kind "summarizes"
  ]
  edge [
    source 956
    target 962
    kind "mentions"
  ]
  edge [
    source 956
    target 968
    kind "mentions"
  ]
  edge [
    source 957
    target 961
    kind "mentions"
  ]
  edge [
    source 958
    target 961
    kind "mentions"
  ]
  edge [
    source 959
    target 960
    kind "mentions"
  ]
  edge [
    source 959
    target 2225
    kind "summarizes"
  ]
  edge [
    source 961
    target 2214
    kind "summarizes"
  ]
  edge [
    source 962
    target 963
    kind "mentions"
  ]
  edge [
    source 962
    target 964
    kind "mentions"
  ]
  edge [
    source 962
    target 965
    kind "mentions"
  ]
  edge [
    source 962
    target 966
    kind "mentions"
  ]
  edge [
    source 962
    target 2234
    kind "summarizes"
  ]
  edge [
    source 963
    target 965
    kind "relation"
    relation "will feature"
    weight 1
  ]
  edge [
    source 963
    target 966
    kind "relation"
    relation "will feature"
    weight 1
  ]
  edge [
    source 964
    target 1502
    kind "mentions"
  ]
  edge [
    source 964
    target 1224
    kind "relation"
    relation "was found trespassing in | had intent to commit a crime"
    weight 2
  ]
  edge [
    source 964
    target 1776
    kind "mentions"
  ]
  edge [
    source 964
    target 2048
    kind "mentions"
  ]
  edge [
    source 966
    target 2143
    kind "mentions"
  ]
  edge [
    source 966
    target 2146
    kind "mentions"
  ]
  edge [
    source 967
    target 968
    kind "from_chunk"
  ]
  edge [
    source 967
    target 971
    kind "from_chunk"
  ]
  edge [
    source 967
    target 977
    kind "from_chunk"
  ]
  edge [
    source 968
    target 969
    kind "mentions"
  ]
  edge [
    source 968
    target 970
    kind "mentions"
  ]
  edge [
    source 968
    target 2217
    kind "summarizes"
  ]
  edge [
    source 971
    target 972
    kind "mentions"
  ]
  edge [
    source 971
    target 973
    kind "mentions"
  ]
  edge [
    source 971
    target 974
    kind "mentions"
  ]
  edge [
    source 971
    target 975
    kind "mentions"
  ]
  edge [
    source 971
    target 976
    kind "mentions"
  ]
  edge [
    source 971
    target 2224
    kind "summarizes"
  ]
  edge [
    source 972
    target 974
    kind "relation"
    relation "exercises"
    weight 1
  ]
  edge [
    source 972
    target 976
    kind "relation"
    relation "restrains itself in"
    weight 1
  ]
  edge [
    source 972
    target 1034
    kind "mentions"
  ]
  edge [
    source 972
    target 1035
    kind "relation"
    relation "will watch"
    weight 1
  ]
  edge [
    source 972
    target 1037
    kind "relation"
    relation "will be stopped by"
    weight 1
  ]
  edge [
    source 972
    target 1307
    kind "mentions"
  ]
  edge [
    source 972
    target 1329
    kind "mentions"
  ]
  edge [
    source 975
    target 977
    kind "mentions"
  ]
  edge [
    source 977
    target 978
    kind "mentions"
  ]
  edge [
    source 977
    target 979
    kind "mentions"
  ]
  edge [
    source 977
    target 980
    kind "mentions"
  ]
  edge [
    source 977
    target 981
    kind "mentions"
  ]
  edge [
    source 977
    target 982
    kind "mentions"
  ]
  edge [
    source 977
    target 983
    kind "mentions"
  ]
  edge [
    source 977
    target 984
    kind "mentions"
  ]
  edge [
    source 977
    target 985
    kind "mentions"
  ]
  edge [
    source 977
    target 986
    kind "mentions"
  ]
  edge [
    source 977
    target 987
    kind "mentions"
  ]
  edge [
    source 977
    target 988
    kind "mentions"
  ]
  edge [
    source 977
    target 989
    kind "mentions"
  ]
  edge [
    source 977
    target 990
    kind "mentions"
  ]
  edge [
    source 977
    target 2233
    kind "summarizes"
  ]
  edge [
    source 978
    target 992
    kind "mentions"
  ]
  edge [
    source 991
    target 992
    kind "from_chunk"
  ]
  edge [
    source 991
    target 996
    kind "from_chunk"
  ]
  edge [
    source 992
    target 993
    kind "mentions"
  ]
  edge [
    source 992
    target 994
    kind "mentions"
  ]
  edge [
    source 992
    target 995
    kind "mentions"
  ]
  edge [
    source 992
    target 2233
    kind "summarizes"
  ]
  edge [
    source 995
    target 1161
    kind "mentions"
  ]
  edge [
    source 995
    target 1175
    kind "mentions"
  ]
  edge [
    source 995
    target 1176
    kind "relation"
    relation "is suffering from"
    weight 1
  ]
  edge [
    source 995
    target 1167
    kind "relation"
    relation "is given as a precaution against"
    weight 1
  ]
  edge [
    source 995
    target 1178
    kind "mentions"
  ]
  edge [
    source 995
    target 1248
    kind "mentions"
  ]
  edge [
    source 995
    target 1162
    kind "relation"
    relation "causes"
    weight 1
  ]
  edge [
    source 995
    target 2048
    kind "mentions"
  ]
  edge [
    source 996
    target 2214
    kind "summarizes"
  ]
  edge [
    source 997
    target 998
    kind "from_chunk"
  ]
  edge [
    source 997
    target 1017
    kind "from_chunk"
  ]
  edge [
    source 998
    target 999
    kind "mentions"
  ]
  edge [
    source 998
    target 1000
    kind "mentions"
  ]
  edge [
    source 998
    target 1001
    kind "mentions"
  ]
  edge [
    source 998
    target 1002
    kind "mentions"
  ]
  edge [
    source 998
    target 1003
    kind "mentions"
  ]
  edge [
    source 998
    target 1004
    kind "mentions"
  ]
  edge [
    source 998
    target 1005
    kind "mentions"
  ]
  edge [
    source 998
    target 1006
    kind "mentions"
  ]
  edge [
    source 998
    target 1007
    kind "mentions"
  ]
  edge [
    source 998
    target 1008
    kind "mentions"
  ]
  edge [
    source 998
    target 1009
    kind "mentions"
  ]
  edge [
    source 998
    target 1010
    kind "mentions"
  ]
  edge [
    source 998
    target 1011
    kind "mentions"
  ]
  edge [
    source 998
    target 1012
    kind "mentions"
  ]
  edge [
    source 998
    target 1013
    kind "mentions"
  ]
  edge [
    source 998
    target 1014
    kind "mentions"
  ]
  edge [
    source 998
    target 1015
    kind "mentions"
  ]
  edge [
    source 998
    target 1016
    kind "mentions"
  ]
  edge [
    source 998
    target 2226
    kind "summarizes"
  ]
  edge [
    source 1000
    target 1448
    kind "mentions"
  ]
  edge [
    source 1000
    target 1528
    kind "mentions"
  ]
  edge [
    source 1002
    target 1192
    kind "mentions"
  ]
  edge [
    source 1004
    target 1290
    kind "mentions"
  ]
  edge [
    source 1007
    target 1017
    kind "mentions"
  ]
  edge [
    source 1017
    target 2226
    kind "summarizes"
  ]
  edge [
    source 1018
    target 1019
    kind "from_chunk"
  ]
  edge [
    source 1018
    target 1027
    kind "from_chunk"
  ]
  edge [
    source 1019
    target 1020
    kind "mentions"
  ]
  edge [
    source 1019
    target 1021
    kind "mentions"
  ]
  edge [
    source 1019
    target 1022
    kind "mentions"
  ]
  edge [
    source 1019
    target 1023
    kind "mentions"
  ]
  edge [
    source 1019
    target 1024
    kind "mentions"
  ]
  edge [
    source 1019
    target 1025
    kind "mentions"
  ]
  edge [
    source 1019
    target 1026
    kind "mentions"
  ]
  edge [
    source 1019
    target 2226
    kind "summarizes"
  ]
  edge [
    source 1021
    target 1023
    kind "relation"
    relation "can conceal"
    weight 1
  ]
  edge [
    source 1027
    target 1028
    kind "mentions"
  ]
  edge [
    source 1027
    target 1029
    kind "mentions"
  ]
  edge [
    source 1027
    target 1030
    kind "mentions"
  ]
  edge [
    source 1027
    target 1031
    kind "mentions"
  ]
  edge [
    source 1027
    target 1032
    kind "mentions"
  ]
  edge [
    source 1027
    target 2230
    kind "summarizes"
  ]
  edge [
    source 1029
    target 1153
    kind "mentions"
  ]
  edge [
    source 1033
    target 1034
    kind "from_chunk"
  ]
  edge [
    source 1033
    target 1039
    kind "from_chunk"
  ]
  edge [
    source 1033
    target 1044
    kind "from_chunk"
  ]
  edge [
    source 1034
    target 1035
    kind "mentions"
  ]
  edge [
    source 1034
    target 1036
    kind "mentions"
  ]
  edge [
    source 1034
    target 1037
    kind "mentions"
  ]
  edge [
    source 1034
    target 1038
    kind "mentions"
  ]
  edge [
    source 1034
    target 2224
    kind "summarizes"
  ]
  edge [
    source 1035
    target 1356
    kind "mentions"
  ]
  edge [
    source 1036
    target 1037
    kind "relation"
    relation "will be prevented by"
    weight 1
  ]
  edge [
    source 1039
    target 1040
    kind "mentions"
  ]
  edge [
    source 1039
    target 1041
    kind "mentions"
  ]
  edge [
    source 1039
    target 1042
    kind "mentions"
  ]
  edge [
    source 1039
    target 1043
    kind "mentions"
  ]
  edge [
    source 1039
    target 2222
    kind "summarizes"
  ]
  edge [
    source 1040
    target 1041
    kind "relation"
    relation "has"
    weight 1
  ]
  edge [
    source 1044
    target 1045
    kind "mentions"
  ]
  edge [
    source 1044
    target 1046
    kind "mentions"
  ]
  edge [
    source 1044
    target 2230
    kind "summarizes"
  ]
  edge [
    source 1045
    target 1117
    kind "mentions"
  ]
  edge [
    source 1045
    target 1125
    kind "relation"
    relation "is in"
    weight 1
  ]
  edge [
    source 1047
    target 1048
    kind "from_chunk"
  ]
  edge [
    source 1047
    target 1050
    kind "from_chunk"
  ]
  edge [
    source 1047
    target 1053
    kind "from_chunk"
  ]
  edge [
    source 1047
    target 1056
    kind "from_chunk"
  ]
  edge [
    source 1048
    target 1049
    kind "mentions"
  ]
  edge [
    source 1048
    target 2235
    kind "summarizes"
  ]
  edge [
    source 1049
    target 1433
    kind "mentions"
  ]
  edge [
    source 1049
    target 1468
    kind "mentions"
  ]
  edge [
    source 1050
    target 1051
    kind "mentions"
  ]
  edge [
    source 1050
    target 1052
    kind "mentions"
  ]
  edge [
    source 1050
    target 2214
    kind "summarizes"
  ]
  edge [
    source 1053
    target 1054
    kind "mentions"
  ]
  edge [
    source 1053
    target 1055
    kind "mentions"
  ]
  edge [
    source 1053
    target 2216
    kind "summarizes"
  ]
  edge [
    source 1054
    target 1056
    kind "mentions"
  ]
  edge [
    source 1055
    target 1258
    kind "mentions"
  ]
  edge [
    source 1056
    target 1057
    kind "mentions"
  ]
  edge [
    source 1056
    target 2216
    kind "summarizes"
  ]
  edge [
    source 1058
    target 1059
    kind "from_chunk"
  ]
  edge [
    source 1058
    target 1061
    kind "from_chunk"
  ]
  edge [
    source 1058
    target 1066
    kind "from_chunk"
  ]
  edge [
    source 1058
    target 1069
    kind "from_chunk"
  ]
  edge [
    source 1058
    target 1072
    kind "from_chunk"
  ]
  edge [
    source 1059
    target 1060
    kind "mentions"
  ]
  edge [
    source 1059
    target 2234
    kind "summarizes"
  ]
  edge [
    source 1061
    target 1062
    kind "mentions"
  ]
  edge [
    source 1061
    target 1063
    kind "mentions"
  ]
  edge [
    source 1061
    target 1064
    kind "mentions"
  ]
  edge [
    source 1061
    target 1065
    kind "mentions"
  ]
  edge [
    source 1061
    target 2222
    kind "summarizes"
  ]
  edge [
    source 1062
    target 1065
    kind "relation"
    relation "must be commenced immediately to prevent"
    weight 1
  ]
  edge [
    source 1063
    target 1066
    kind "mentions"
  ]
  edge [
    source 1063
    target 1074
    kind "mentions"
  ]
  edge [
    source 1063
    target 1089
    kind "relation"
    relation "would shorten the price if they found out"
    weight 1
  ]
  edge [
    source 1063
    target 1161
    kind "mentions"
  ]
  edge [
    source 1063
    target 1196
    kind "mentions"
  ]
  edge [
    source 1063
    target 1965
    kind "mentions"
  ]
  edge [
    source 1063
    target 1968
    kind "mentions"
  ]
  edge [
    source 1063
    target 2067
    kind "mentions"
  ]
  edge [
    source 1064
    target 1066
    kind "mentions"
  ]
  edge [
    source 1066
    target 1067
    kind "mentions"
  ]
  edge [
    source 1066
    target 1068
    kind "mentions"
  ]
  edge [
    source 1066
    target 2222
    kind "summarizes"
  ]
  edge [
    source 1069
    target 1070
    kind "mentions"
  ]
  edge [
    source 1069
    target 1071
    kind "mentions"
  ]
  edge [
    source 1069
    target 2214
    kind "summarizes"
  ]
  edge [
    source 1072
    target 2214
    kind "summarizes"
  ]
  edge [
    source 1073
    target 1074
    kind "from_chunk"
  ]
  edge [
    source 1074
    target 1075
    kind "mentions"
  ]
  edge [
    source 1074
    target 1076
    kind "mentions"
  ]
  edge [
    source 1074
    target 1077
    kind "mentions"
  ]
  edge [
    source 1074
    target 1078
    kind "mentions"
  ]
  edge [
    source 1074
    target 1079
    kind "mentions"
  ]
  edge [
    source 1074
    target 1080
    kind "mentions"
  ]
  edge [
    source 1074
    target 1081
    kind "mentions"
  ]
  edge [
    source 1074
    target 1082
    kind "mentions"
  ]
  edge [
    source 1074
    target 1083
    kind "mentions"
  ]
  edge [
    source 1074
    target 1084
    kind "mentions"
  ]
  edge [
    source 1074
    target 1085
    kind "mentions"
  ]
  edge [
    source 1074
    target 1086
    kind "mentions"
  ]
  edge [
    source 1074
    target 1087
    kind "mentions"
  ]
  edge [
    source 1074
    target 1088
    kind "mentions"
  ]
  edge [
    source 1074
    target 1089
    kind "mentions"
  ]
  edge [
    source 1074
    target 1090
    kind "mentions"
  ]
  edge [
    source 1074
    target 1091
    kind "mentions"
  ]
  edge [
    source 1074
    target 1092
    kind "mentions"
  ]
  edge [
    source 1074
    target 1093
    kind "mentions"
  ]
  edge [
    source 1074
    target 2222
    kind "summarizes"
  ]
  edge [
    source 1083
    target 1131
    kind "mentions"
  ]
  edge [
    source 1083
    target 1137
    kind "mentions"
  ]
  edge [
    source 1094
    target 1095
    kind "from_chunk"
  ]
  edge [
    source 1094
    target 1098
    kind "from_chunk"
  ]
  edge [
    source 1094
    target 1102
    kind "from_chunk"
  ]
  edge [
    source 1094
    target 1109
    kind "from_chunk"
  ]
  edge [
    source 1094
    target 1111
    kind "from_chunk"
  ]
  edge [
    source 1095
    target 1096
    kind "mentions"
  ]
  edge [
    source 1095
    target 1097
    kind "mentions"
  ]
  edge [
    source 1095
    target 2224
    kind "summarizes"
  ]
  edge [
    source 1097
    target 1131
    kind "mentions"
  ]
  edge [
    source 1098
    target 1099
    kind "mentions"
  ]
  edge [
    source 1098
    target 1100
    kind "mentions"
  ]
  edge [
    source 1098
    target 1101
    kind "mentions"
  ]
  edge [
    source 1098
    target 2214
    kind "summarizes"
  ]
  edge [
    source 1101
    target 1131
    kind "mentions"
  ]
  edge [
    source 1101
    target 1134
    kind "relation"
    relation "is a wicious institution"
    weight 1
  ]
  edge [
    source 1102
    target 1103
    kind "mentions"
  ]
  edge [
    source 1102
    target 1104
    kind "mentions"
  ]
  edge [
    source 1102
    target 1105
    kind "mentions"
  ]
  edge [
    source 1102
    target 1106
    kind "mentions"
  ]
  edge [
    source 1102
    target 1107
    kind "mentions"
  ]
  edge [
    source 1102
    target 1108
    kind "mentions"
  ]
  edge [
    source 1102
    target 2220
    kind "summarizes"
  ]
  edge [
    source 1103
    target 1109
    kind "mentions"
  ]
  edge [
    source 1107
    target 1109
    kind "mentions"
  ]
  edge [
    source 1109
    target 1110
    kind "mentions"
  ]
  edge [
    source 1109
    target 2220
    kind "summarizes"
  ]
  edge [
    source 1111
    target 1112
    kind "mentions"
  ]
  edge [
    source 1111
    target 2220
    kind "summarizes"
  ]
  edge [
    source 1113
    target 1114
    kind "from_chunk"
  ]
  edge [
    source 1113
    target 1117
    kind "from_chunk"
  ]
  edge [
    source 1113
    target 1127
    kind "from_chunk"
  ]
  edge [
    source 1114
    target 1115
    kind "mentions"
  ]
  edge [
    source 1114
    target 1116
    kind "mentions"
  ]
  edge [
    source 1114
    target 2231
    kind "summarizes"
  ]
  edge [
    source 1117
    target 1118
    kind "mentions"
  ]
  edge [
    source 1117
    target 1119
    kind "mentions"
  ]
  edge [
    source 1117
    target 1120
    kind "mentions"
  ]
  edge [
    source 1117
    target 1121
    kind "mentions"
  ]
  edge [
    source 1117
    target 1122
    kind "mentions"
  ]
  edge [
    source 1117
    target 1123
    kind "mentions"
  ]
  edge [
    source 1117
    target 1124
    kind "mentions"
  ]
  edge [
    source 1117
    target 1125
    kind "mentions"
  ]
  edge [
    source 1117
    target 1126
    kind "mentions"
  ]
  edge [
    source 1117
    target 2230
    kind "summarizes"
  ]
  edge [
    source 1122
    target 1123
    kind "relation"
    relation "is against"
    weight 1
  ]
  edge [
    source 1122
    target 1127
    kind "mentions"
  ]
  edge [
    source 1122
    target 1129
    kind "relation"
    relation "is the most conspicuous object in"
    weight 1
  ]
  edge [
    source 1127
    target 1128
    kind "mentions"
  ]
  edge [
    source 1127
    target 1129
    kind "mentions"
  ]
  edge [
    source 1127
    target 2230
    kind "summarizes"
  ]
  edge [
    source 1130
    target 1131
    kind "from_chunk"
  ]
  edge [
    source 1130
    target 1137
    kind "from_chunk"
  ]
  edge [
    source 1131
    target 1132
    kind "mentions"
  ]
  edge [
    source 1131
    target 1133
    kind "mentions"
  ]
  edge [
    source 1131
    target 1134
    kind "mentions"
  ]
  edge [
    source 1131
    target 1135
    kind "mentions"
  ]
  edge [
    source 1131
    target 1136
    kind "mentions"
  ]
  edge [
    source 1131
    target 2214
    kind "summarizes"
  ]
  edge [
    source 1133
    target 1180
    kind "mentions"
  ]
  edge [
    source 1133
    target 1407
    kind "mentions"
  ]
  edge [
    source 1133
    target 1433
    kind "mentions"
  ]
  edge [
    source 1133
    target 1443
    kind "relation"
    relation "disapproved of"
    weight 1
  ]
  edge [
    source 1133
    target 2126
    kind "mentions"
  ]
  edge [
    source 1136
    target 1137
    kind "mentions"
  ]
  edge [
    source 1137
    target 2214
    kind "summarizes"
  ]
  edge [
    source 1138
    target 1139
    kind "from_chunk"
  ]
  edge [
    source 1138
    target 1150
    kind "from_chunk"
  ]
  edge [
    source 1139
    target 1140
    kind "mentions"
  ]
  edge [
    source 1139
    target 1141
    kind "mentions"
  ]
  edge [
    source 1139
    target 1142
    kind "mentions"
  ]
  edge [
    source 1139
    target 1143
    kind "mentions"
  ]
  edge [
    source 1139
    target 1144
    kind "mentions"
  ]
  edge [
    source 1139
    target 1145
    kind "mentions"
  ]
  edge [
    source 1139
    target 1146
    kind "mentions"
  ]
  edge [
    source 1139
    target 1147
    kind "mentions"
  ]
  edge [
    source 1139
    target 1148
    kind "mentions"
  ]
  edge [
    source 1139
    target 1149
    kind "mentions"
  ]
  edge [
    source 1139
    target 2214
    kind "summarizes"
  ]
  edge [
    source 1144
    target 1150
    kind "mentions"
  ]
  edge [
    source 1144
    target 1333
    kind "mentions"
  ]
  edge [
    source 1144
    target 1335
    kind "relation"
    relation "read"
    weight 1
  ]
  edge [
    source 1144
    target 1336
    kind "relation"
    relation "contained"
    weight 1
  ]
  edge [
    source 1145
    target 1148
    kind "relation"
    relation "are kept secret"
    weight 2
  ]
  edge [
    source 1145
    target 1150
    kind "mentions"
  ]
  edge [
    source 1146
    target 1150
    kind "mentions"
  ]
  edge [
    source 1148
    target 1150
    kind "mentions"
  ]
  edge [
    source 1149
    target 1150
    kind "mentions"
  ]
  edge [
    source 1150
    target 1151
    kind "mentions"
  ]
  edge [
    source 1150
    target 2214
    kind "summarizes"
  ]
  edge [
    source 1152
    target 1153
    kind "from_chunk"
  ]
  edge [
    source 1152
    target 1161
    kind "from_chunk"
  ]
  edge [
    source 1153
    target 1154
    kind "mentions"
  ]
  edge [
    source 1153
    target 1155
    kind "mentions"
  ]
  edge [
    source 1153
    target 1156
    kind "mentions"
  ]
  edge [
    source 1153
    target 1157
    kind "mentions"
  ]
  edge [
    source 1153
    target 1158
    kind "mentions"
  ]
  edge [
    source 1153
    target 1159
    kind "mentions"
  ]
  edge [
    source 1153
    target 1160
    kind "mentions"
  ]
  edge [
    source 1153
    target 2235
    kind "summarizes"
  ]
  edge [
    source 1154
    target 1159
    kind "relation"
    relation "says has been pattern and example"
    weight 1
  ]
  edge [
    source 1154
    target 1160
    kind "relation"
    relation "exclaims"
    weight 1
  ]
  edge [
    source 1155
    target 1161
    kind "mentions"
  ]
  edge [
    source 1155
    target 1448
    kind "mentions"
  ]
  edge [
    source 1161
    target 1162
    kind "mentions"
  ]
  edge [
    source 1161
    target 1163
    kind "mentions"
  ]
  edge [
    source 1161
    target 1164
    kind "mentions"
  ]
  edge [
    source 1161
    target 1165
    kind "mentions"
  ]
  edge [
    source 1161
    target 1166
    kind "mentions"
  ]
  edge [
    source 1161
    target 1167
    kind "mentions"
  ]
  edge [
    source 1161
    target 1168
    kind "mentions"
  ]
  edge [
    source 1161
    target 1169
    kind "mentions"
  ]
  edge [
    source 1161
    target 1170
    kind "mentions"
  ]
  edge [
    source 1161
    target 1171
    kind "mentions"
  ]
  edge [
    source 1161
    target 1172
    kind "mentions"
  ]
  edge [
    source 1161
    target 1173
    kind "mentions"
  ]
  edge [
    source 1161
    target 2221
    kind "summarizes"
  ]
  edge [
    source 1162
    target 1248
    kind "mentions"
  ]
  edge [
    source 1163
    target 1192
    kind "mentions"
  ]
  edge [
    source 1163
    target 1258
    kind "mentions"
  ]
  edge [
    source 1163
    target 1278
    kind "mentions"
  ]
  edge [
    source 1163
    target 1279
    kind "relation"
    relation "sits on"
    weight 1
  ]
  edge [
    source 1164
    target 1165
    kind "relation"
    relation "was used to treat"
    weight 1
  ]
  edge [
    source 1165
    target 1166
    kind "relation"
    relation "contains"
    weight 1
  ]
  edge [
    source 1165
    target 1180
    kind "mentions"
  ]
  edge [
    source 1165
    target 1185
    kind "mentions"
  ]
  edge [
    source 1167
    target 1175
    kind "mentions"
  ]
  edge [
    source 1167
    target 1178
    kind "mentions"
  ]
  edge [
    source 1167
    target 1180
    kind "mentions"
  ]
  edge [
    source 1167
    target 1970
    kind "mentions"
  ]
  edge [
    source 1167
    target 2037
    kind "mentions"
  ]
  edge [
    source 1167
    target 2038
    kind "relation"
    relation "contains"
    weight 1
  ]
  edge [
    source 1174
    target 1175
    kind "from_chunk"
  ]
  edge [
    source 1174
    target 1178
    kind "from_chunk"
  ]
  edge [
    source 1175
    target 1176
    kind "mentions"
  ]
  edge [
    source 1175
    target 1177
    kind "mentions"
  ]
  edge [
    source 1175
    target 2221
    kind "summarizes"
  ]
  edge [
    source 1178
    target 2221
    kind "summarizes"
  ]
  edge [
    source 1179
    target 1180
    kind "from_chunk"
  ]
  edge [
    source 1179
    target 1185
    kind "from_chunk"
  ]
  edge [
    source 1179
    target 1192
    kind "from_chunk"
  ]
  edge [
    source 1180
    target 1181
    kind "mentions"
  ]
  edge [
    source 1180
    target 1182
    kind "mentions"
  ]
  edge [
    source 1180
    target 1183
    kind "mentions"
  ]
  edge [
    source 1180
    target 1184
    kind "mentions"
  ]
  edge [
    source 1180
    target 2221
    kind "summarizes"
  ]
  edge [
    source 1181
    target 1223
    kind "mentions"
  ]
  edge [
    source 1181
    target 1224
    kind "relation"
    relation "opens"
    weight 1
  ]
  edge [
    source 1181
    target 1244
    kind "mentions"
  ]
  edge [
    source 1185
    target 1186
    kind "mentions"
  ]
  edge [
    source 1185
    target 1187
    kind "mentions"
  ]
  edge [
    source 1185
    target 1188
    kind "mentions"
  ]
  edge [
    source 1185
    target 1189
    kind "mentions"
  ]
  edge [
    source 1185
    target 1190
    kind "mentions"
  ]
  edge [
    source 1185
    target 1191
    kind "mentions"
  ]
  edge [
    source 1185
    target 2238
    kind "summarizes"
  ]
  edge [
    source 1186
    target 1187
    kind "relation"
    relation "contains"
    weight 1
  ]
  edge [
    source 1186
    target 1188
    kind "relation"
    relation "contains"
    weight 1
  ]
  edge [
    source 1186
    target 1189
    kind "relation"
    relation "contains"
    weight 1
  ]
  edge [
    source 1186
    target 1190
    kind "relation"
    relation "contains"
    weight 1
  ]
  edge [
    source 1186
    target 1191
    kind "relation"
    relation "contains"
    weight 1
  ]
  edge [
    source 1186
    target 1223
    kind "mentions"
  ]
  edge [
    source 1186
    target 1244
    kind "mentions"
  ]
  edge [
    source 1188
    target 1192
    kind "mentions"
  ]
  edge [
    source 1188
    target 1223
    kind "mentions"
  ]
  edge [
    source 1188
    target 1244
    kind "mentions"
  ]
  edge [
    source 1192
    target 1193
    kind "mentions"
  ]
  edge [
    source 1192
    target 1194
    kind "mentions"
  ]
  edge [
    source 1192
    target 2226
    kind "summarizes"
  ]
  edge [
    source 1193
    target 1740
    kind "mentions"
  ]
  edge [
    source 1195
    target 1196
    kind "from_chunk"
  ]
  edge [
    source 1195
    target 1214
    kind "from_chunk"
  ]
  edge [
    source 1195
    target 1218
    kind "from_chunk"
  ]
  edge [
    source 1196
    target 1197
    kind "mentions"
  ]
  edge [
    source 1196
    target 1198
    kind "mentions"
  ]
  edge [
    source 1196
    target 1199
    kind "mentions"
  ]
  edge [
    source 1196
    target 1200
    kind "mentions"
  ]
  edge [
    source 1196
    target 1201
    kind "mentions"
  ]
  edge [
    source 1196
    target 1202
    kind "mentions"
  ]
  edge [
    source 1196
    target 1203
    kind "mentions"
  ]
  edge [
    source 1196
    target 1204
    kind "mentions"
  ]
  edge [
    source 1196
    target 1205
    kind "mentions"
  ]
  edge [
    source 1196
    target 1206
    kind "mentions"
  ]
  edge [
    source 1196
    target 1207
    kind "mentions"
  ]
  edge [
    source 1196
    target 1208
    kind "mentions"
  ]
  edge [
    source 1196
    target 1209
    kind "mentions"
  ]
  edge [
    source 1196
    target 1210
    kind "mentions"
  ]
  edge [
    source 1196
    target 1211
    kind "mentions"
  ]
  edge [
    source 1196
    target 1212
    kind "mentions"
  ]
  edge [
    source 1196
    target 1213
    kind "mentions"
  ]
  edge [
    source 1196
    target 2228
    kind "summarizes"
  ]
  edge [
    source 1197
    target 1199
    kind "relation"
    relation "is a promising youth at"
    weight 1
  ]
  edge [
    source 1197
    target 1200
    kind "relation"
    relation "has a concern about"
    weight 1
  ]
  edge [
    source 1197
    target 1206
    kind "relation"
    relation "believes that"
    weight 1
  ]
  edge [
    source 1197
    target 1203
    kind "relation"
    relation "recalls obtaining"
    weight 1
  ]
  edge [
    source 1197
    target 1204
    kind "relation"
    relation "realizes the poison is located in | realizes the poison is in"
    weight 2
  ]
  edge [
    source 1197
    target 1207
    kind "relation"
    relation "thinks the poison could not have been used for | believes the poison could not have been used for"
    weight 2
  ]
  edge [
    source 1197
    target 1208
    kind "relation"
    relation "plans to carry out"
    weight 1
  ]
  edge [
    source 1197
    target 1209
    kind "relation"
    relation "steals out of the room"
    weight 1
  ]
  edge [
    source 1197
    target 1218
    kind "mentions"
  ]
  edge [
    source 1197
    target 1221
    kind "relation"
    relation "questions where he obtained"
    weight 1
  ]
  edge [
    source 1197
    target 1202
    kind "relation"
    relation "had a substance to destroy | realizes the dog died"
    weight 2
  ]
  edge [
    source 1197
    target 1749
    kind "mentions"
  ]
  edge [
    source 1197
    target 1805
    kind "mentions"
  ]
  edge [
    source 1197
    target 1955
    kind "mentions"
  ]
  edge [
    source 1197
    target 1957
    kind "relation"
    relation "had concluding words"
    weight 1
  ]
  edge [
    source 1197
    target 1268
    kind "relation"
    relation "came to the ground with"
    weight 1
  ]
  edge [
    source 1197
    target 1958
    kind "relation"
    relation "led back to"
    weight 1
  ]
  edge [
    source 1197
    target 1959
    kind "relation"
    relation "asked"
    weight 1
  ]
  edge [
    source 1202
    target 1218
    kind "mentions"
  ]
  edge [
    source 1203
    target 1218
    kind "mentions"
  ]
  edge [
    source 1204
    target 1218
    kind "mentions"
  ]
  edge [
    source 1205
    target 1218
    kind "mentions"
  ]
  edge [
    source 1207
    target 1218
    kind "mentions"
  ]
  edge [
    source 1210
    target 1214
    kind "mentions"
  ]
  edge [
    source 1211
    target 1214
    kind "mentions"
  ]
  edge [
    source 1212
    target 1214
    kind "mentions"
  ]
  edge [
    source 1213
    target 1214
    kind "mentions"
  ]
  edge [
    source 1214
    target 1215
    kind "mentions"
  ]
  edge [
    source 1214
    target 1216
    kind "mentions"
  ]
  edge [
    source 1214
    target 1217
    kind "mentions"
  ]
  edge [
    source 1214
    target 2228
    kind "summarizes"
  ]
  edge [
    source 1218
    target 1219
    kind "mentions"
  ]
  edge [
    source 1218
    target 1220
    kind "mentions"
  ]
  edge [
    source 1218
    target 1221
    kind "mentions"
  ]
  edge [
    source 1218
    target 2228
    kind "summarizes"
  ]
  edge [
    source 1222
    target 1223
    kind "from_chunk"
  ]
  edge [
    source 1222
    target 1244
    kind "from_chunk"
  ]
  edge [
    source 1223
    target 1224
    kind "mentions"
  ]
  edge [
    source 1223
    target 1225
    kind "mentions"
  ]
  edge [
    source 1223
    target 1226
    kind "mentions"
  ]
  edge [
    source 1223
    target 1227
    kind "mentions"
  ]
  edge [
    source 1223
    target 1228
    kind "mentions"
  ]
  edge [
    source 1223
    target 1229
    kind "mentions"
  ]
  edge [
    source 1223
    target 1230
    kind "mentions"
  ]
  edge [
    source 1223
    target 1231
    kind "mentions"
  ]
  edge [
    source 1223
    target 1232
    kind "mentions"
  ]
  edge [
    source 1223
    target 1233
    kind "mentions"
  ]
  edge [
    source 1223
    target 1234
    kind "mentions"
  ]
  edge [
    source 1223
    target 1235
    kind "mentions"
  ]
  edge [
    source 1223
    target 1236
    kind "mentions"
  ]
  edge [
    source 1223
    target 1237
    kind "mentions"
  ]
  edge [
    source 1223
    target 1238
    kind "mentions"
  ]
  edge [
    source 1223
    target 1239
    kind "mentions"
  ]
  edge [
    source 1223
    target 1240
    kind "mentions"
  ]
  edge [
    source 1223
    target 1241
    kind "mentions"
  ]
  edge [
    source 1223
    target 1242
    kind "mentions"
  ]
  edge [
    source 1223
    target 1243
    kind "mentions"
  ]
  edge [
    source 1223
    target 2238
    kind "summarizes"
  ]
  edge [
    source 1224
    target 1225
    kind "relation"
    relation "pours drops from"
    weight 2
  ]
  edge [
    source 1224
    target 1226
    kind "relation"
    relation "pours into"
    weight 2
  ]
  edge [
    source 1224
    target 1227
    kind "relation"
    relation "counts"
    weight 2
  ]
  edge [
    source 1224
    target 1228
    kind "relation"
    relation "counts"
    weight 2
  ]
  edge [
    source 1224
    target 1229
    kind "relation"
    relation "counts"
    weight 2
  ]
  edge [
    source 1224
    target 1230
    kind "relation"
    relation "counts"
    weight 2
  ]
  edge [
    source 1224
    target 1237
    kind "relation"
    relation "takes another"
    weight 1
  ]
  edge [
    source 1224
    target 1244
    kind "mentions"
  ]
  edge [
    source 1224
    target 1502
    kind "mentions"
  ]
  edge [
    source 1224
    target 1413
    kind "relation"
    relation "refuses to give his name | refuses to give any account of himself"
    weight 2
  ]
  edge [
    source 1224
    target 1812
    kind "mentions"
  ]
  edge [
    source 1224
    target 1813
    kind "relation"
    relation "was trespassing in"
    weight 1
  ]
  edge [
    source 1224
    target 1814
    kind "relation"
    relation "committed suicide"
    weight 1
  ]
  edge [
    source 1224
    target 1911
    kind "mentions"
  ]
  edge [
    source 1225
    target 1244
    kind "mentions"
  ]
  edge [
    source 1226
    target 1244
    kind "mentions"
  ]
  edge [
    source 1227
    target 1244
    kind "mentions"
  ]
  edge [
    source 1228
    target 1244
    kind "mentions"
  ]
  edge [
    source 1229
    target 1244
    kind "mentions"
  ]
  edge [
    source 1230
    target 1244
    kind "mentions"
  ]
  edge [
    source 1231
    target 1244
    kind "mentions"
  ]
  edge [
    source 1232
    target 1244
    kind "mentions"
  ]
  edge [
    source 1232
    target 2048
    kind "mentions"
  ]
  edge [
    source 1232
    target 2067
    kind "mentions"
  ]
  edge [
    source 1233
    target 1244
    kind "mentions"
  ]
  edge [
    source 1234
    target 1244
    kind "mentions"
  ]
  edge [
    source 1235
    target 1244
    kind "mentions"
  ]
  edge [
    source 1235
    target 1246
    kind "mentions"
  ]
  edge [
    source 1235
    target 2044
    kind "mentions"
  ]
  edge [
    source 1235
    target 2045
    kind "relation"
    relation "is among the most atrocious in history of"
    weight 1
  ]
  edge [
    source 1236
    target 1244
    kind "mentions"
  ]
  edge [
    source 1238
    target 1244
    kind "mentions"
  ]
  edge [
    source 1239
    target 1244
    kind "mentions"
  ]
  edge [
    source 1240
    target 1244
    kind "mentions"
  ]
  edge [
    source 1241
    target 1244
    kind "mentions"
  ]
  edge [
    source 1242
    target 1244
    kind "mentions"
  ]
  edge [
    source 1243
    target 1244
    kind "mentions"
  ]
  edge [
    source 1244
    target 2238
    kind "summarizes"
  ]
  edge [
    source 1245
    target 1246
    kind "from_chunk"
  ]
  edge [
    source 1245
    target 1248
    kind "from_chunk"
  ]
  edge [
    source 1245
    target 1251
    kind "from_chunk"
  ]
  edge [
    source 1245
    target 1253
    kind "from_chunk"
  ]
  edge [
    source 1245
    target 1258
    kind "from_chunk"
  ]
  edge [
    source 1246
    target 1247
    kind "mentions"
  ]
  edge [
    source 1246
    target 2219
    kind "summarizes"
  ]
  edge [
    source 1247
    target 1248
    kind "mentions"
  ]
  edge [
    source 1247
    target 1249
    kind "relation"
    relation "if restive causes"
    weight 1
  ]
  edge [
    source 1248
    target 1249
    kind "mentions"
  ]
  edge [
    source 1248
    target 1250
    kind "mentions"
  ]
  edge [
    source 1248
    target 2221
    kind "summarizes"
  ]
  edge [
    source 1251
    target 1252
    kind "mentions"
  ]
  edge [
    source 1251
    target 2230
    kind "summarizes"
  ]
  edge [
    source 1253
    target 1254
    kind "mentions"
  ]
  edge [
    source 1253
    target 1255
    kind "mentions"
  ]
  edge [
    source 1253
    target 1256
    kind "mentions"
  ]
  edge [
    source 1253
    target 1257
    kind "mentions"
  ]
  edge [
    source 1253
    target 2219
    kind "summarizes"
  ]
  edge [
    source 1254
    target 1255
    kind "relation"
    relation "is followed by people who are"
    weight 1
  ]
  edge [
    source 1255
    target 1256
    kind "relation"
    relation "makes"
    weight 1
  ]
  edge [
    source 1258
    target 1259
    kind "mentions"
  ]
  edge [
    source 1258
    target 1260
    kind "mentions"
  ]
  edge [
    source 1258
    target 1261
    kind "mentions"
  ]
  edge [
    source 1258
    target 1262
    kind "mentions"
  ]
  edge [
    source 1258
    target 2216
    kind "summarizes"
  ]
  edge [
    source 1261
    target 1262
    kind "relation"
    relation "has much thunder"
    weight 1
  ]
  edge [
    source 1263
    target 1264
    kind "from_chunk"
  ]
  edge [
    source 1263
    target 1267
    kind "from_chunk"
  ]
  edge [
    source 1263
    target 1269
    kind "from_chunk"
  ]
  edge [
    source 1263
    target 1273
    kind "from_chunk"
  ]
  edge [
    source 1264
    target 1265
    kind "mentions"
  ]
  edge [
    source 1264
    target 1266
    kind "mentions"
  ]
  edge [
    source 1264
    target 2221
    kind "summarizes"
  ]
  edge [
    source 1267
    target 1268
    kind "mentions"
  ]
  edge [
    source 1267
    target 2221
    kind "summarizes"
  ]
  edge [
    source 1268
    target 1382
    kind "mentions"
  ]
  edge [
    source 1268
    target 1893
    kind "mentions"
  ]
  edge [
    source 1268
    target 1899
    kind "mentions"
  ]
  edge [
    source 1268
    target 1900
    kind "relation"
    relation "waves handkerchief to"
    weight 1
  ]
  edge [
    source 1268
    target 1901
    kind "relation"
    relation "reminds group to"
    weight 1
  ]
  edge [
    source 1268
    target 1902
    kind "relation"
    relation "urges group to"
    weight 1
  ]
  edge [
    source 1268
    target 1903
    kind "relation"
    relation "instructs group to"
    weight 1
  ]
  edge [
    source 1268
    target 1955
    kind "mentions"
  ]
  edge [
    source 1269
    target 1270
    kind "mentions"
  ]
  edge [
    source 1269
    target 1271
    kind "mentions"
  ]
  edge [
    source 1269
    target 1272
    kind "mentions"
  ]
  edge [
    source 1269
    target 2221
    kind "summarizes"
  ]
  edge [
    source 1273
    target 1274
    kind "mentions"
  ]
  edge [
    source 1273
    target 1275
    kind "mentions"
  ]
  edge [
    source 1273
    target 1276
    kind "mentions"
  ]
  edge [
    source 1273
    target 2226
    kind "summarizes"
  ]
  edge [
    source 1274
    target 1278
    kind "mentions"
  ]
  edge [
    source 1274
    target 1275
    kind "relation"
    relation "wouldn't hold"
    weight 1
  ]
  edge [
    source 1275
    target 1278
    kind "mentions"
  ]
  edge [
    source 1277
    target 1278
    kind "from_chunk"
  ]
  edge [
    source 1277
    target 1282
    kind "from_chunk"
  ]
  edge [
    source 1277
    target 1290
    kind "from_chunk"
  ]
  edge [
    source 1278
    target 1279
    kind "mentions"
  ]
  edge [
    source 1278
    target 1280
    kind "mentions"
  ]
  edge [
    source 1278
    target 1281
    kind "mentions"
  ]
  edge [
    source 1278
    target 2226
    kind "summarizes"
  ]
  edge [
    source 1282
    target 1283
    kind "mentions"
  ]
  edge [
    source 1282
    target 1284
    kind "mentions"
  ]
  edge [
    source 1282
    target 1285
    kind "mentions"
  ]
  edge [
    source 1282
    target 1286
    kind "mentions"
  ]
  edge [
    source 1282
    target 1287
    kind "mentions"
  ]
  edge [
    source 1282
    target 1288
    kind "mentions"
  ]
  edge [
    source 1282
    target 1289
    kind "mentions"
  ]
  edge [
    source 1282
    target 2226
    kind "summarizes"
  ]
  edge [
    source 1284
    target 1290
    kind "mentions"
  ]
  edge [
    source 1284
    target 1356
    kind "mentions"
  ]
  edge [
    source 1285
    target 1989
    kind "mentions"
  ]
  edge [
    source 1290
    target 1291
    kind "mentions"
  ]
  edge [
    source 1290
    target 1292
    kind "mentions"
  ]
  edge [
    source 1290
    target 1293
    kind "mentions"
  ]
  edge [
    source 1290
    target 1294
    kind "mentions"
  ]
  edge [
    source 1290
    target 1295
    kind "mentions"
  ]
  edge [
    source 1290
    target 2226
    kind "summarizes"
  ]
  edge [
    source 1296
    target 1297
    kind "from_chunk"
  ]
  edge [
    source 1297
    target 1298
    kind "mentions"
  ]
  edge [
    source 1297
    target 1299
    kind "mentions"
  ]
  edge [
    source 1297
    target 1300
    kind "mentions"
  ]
  edge [
    source 1297
    target 1301
    kind "mentions"
  ]
  edge [
    source 1297
    target 1302
    kind "mentions"
  ]
  edge [
    source 1297
    target 1303
    kind "mentions"
  ]
  edge [
    source 1297
    target 1304
    kind "mentions"
  ]
  edge [
    source 1297
    target 1305
    kind "mentions"
  ]
  edge [
    source 1297
    target 2230
    kind "summarizes"
  ]
  edge [
    source 1306
    target 1307
    kind "from_chunk"
  ]
  edge [
    source 1307
    target 1308
    kind "mentions"
  ]
  edge [
    source 1307
    target 1309
    kind "mentions"
  ]
  edge [
    source 1307
    target 1310
    kind "mentions"
  ]
  edge [
    source 1307
    target 1311
    kind "mentions"
  ]
  edge [
    source 1307
    target 1312
    kind "mentions"
  ]
  edge [
    source 1307
    target 1313
    kind "mentions"
  ]
  edge [
    source 1307
    target 1314
    kind "mentions"
  ]
  edge [
    source 1307
    target 1315
    kind "mentions"
  ]
  edge [
    source 1307
    target 1316
    kind "mentions"
  ]
  edge [
    source 1307
    target 1317
    kind "mentions"
  ]
  edge [
    source 1307
    target 1318
    kind "mentions"
  ]
  edge [
    source 1307
    target 1319
    kind "mentions"
  ]
  edge [
    source 1307
    target 1320
    kind "mentions"
  ]
  edge [
    source 1307
    target 1321
    kind "mentions"
  ]
  edge [
    source 1307
    target 1322
    kind "mentions"
  ]
  edge [
    source 1307
    target 1323
    kind "mentions"
  ]
  edge [
    source 1307
    target 1324
    kind "mentions"
  ]
  edge [
    source 1307
    target 1325
    kind "mentions"
  ]
  edge [
    source 1307
    target 1326
    kind "mentions"
  ]
  edge [
    source 1307
    target 1327
    kind "mentions"
  ]
  edge [
    source 1307
    target 2223
    kind "summarizes"
  ]
  edge [
    source 1322
    target 1974
    kind "mentions"
  ]
  edge [
    source 1322
    target 1989
    kind "mentions"
  ]
  edge [
    source 1328
    target 1329
    kind "from_chunk"
  ]
  edge [
    source 1328
    target 1330
    kind "from_chunk"
  ]
  edge [
    source 1328
    target 1333
    kind "from_chunk"
  ]
  edge [
    source 1328
    target 1337
    kind "from_chunk"
  ]
  edge [
    source 1328
    target 1339
    kind "from_chunk"
  ]
  edge [
    source 1328
    target 1342
    kind "from_chunk"
  ]
  edge [
    source 1328
    target 1345
    kind "from_chunk"
  ]
  edge [
    source 1328
    target 1347
    kind "from_chunk"
  ]
  edge [
    source 1328
    target 1352
    kind "from_chunk"
  ]
  edge [
    source 1329
    target 2224
    kind "summarizes"
  ]
  edge [
    source 1330
    target 1331
    kind "mentions"
  ]
  edge [
    source 1330
    target 1332
    kind "mentions"
  ]
  edge [
    source 1330
    target 2225
    kind "summarizes"
  ]
  edge [
    source 1331
    target 1332
    kind "relation"
    relation "respond to"
    weight 1
  ]
  edge [
    source 1331
    target 1333
    kind "mentions"
  ]
  edge [
    source 1331
    target 1334
    kind "relation"
    relation "subjected"
    weight 1
  ]
  edge [
    source 1333
    target 1334
    kind "mentions"
  ]
  edge [
    source 1333
    target 1335
    kind "mentions"
  ]
  edge [
    source 1333
    target 1336
    kind "mentions"
  ]
  edge [
    source 1333
    target 2225
    kind "summarizes"
  ]
  edge [
    source 1337
    target 1338
    kind "mentions"
  ]
  edge [
    source 1337
    target 2225
    kind "summarizes"
  ]
  edge [
    source 1339
    target 1340
    kind "mentions"
  ]
  edge [
    source 1339
    target 1341
    kind "mentions"
  ]
  edge [
    source 1339
    target 2217
    kind "summarizes"
  ]
  edge [
    source 1340
    target 1341
    kind "relation"
    relation "is on the back of"
    weight 1
  ]
  edge [
    source 1342
    target 1343
    kind "mentions"
  ]
  edge [
    source 1342
    target 1344
    kind "mentions"
  ]
  edge [
    source 1342
    target 2217
    kind "summarizes"
  ]
  edge [
    source 1343
    target 1344
    kind "relation"
    relation "will provide"
    weight 1
  ]
  edge [
    source 1345
    target 1346
    kind "mentions"
  ]
  edge [
    source 1345
    target 2217
    kind "summarizes"
  ]
  edge [
    source 1347
    target 1348
    kind "mentions"
  ]
  edge [
    source 1347
    target 1349
    kind "mentions"
  ]
  edge [
    source 1347
    target 1350
    kind "mentions"
  ]
  edge [
    source 1347
    target 1351
    kind "mentions"
  ]
  edge [
    source 1347
    target 2233
    kind "summarizes"
  ]
  edge [
    source 1352
    target 1353
    kind "mentions"
  ]
  edge [
    source 1352
    target 1354
    kind "mentions"
  ]
  edge [
    source 1352
    target 2225
    kind "summarizes"
  ]
  edge [
    source 1355
    target 1356
    kind "from_chunk"
  ]
  edge [
    source 1356
    target 1357
    kind "mentions"
  ]
  edge [
    source 1356
    target 1358
    kind "mentions"
  ]
  edge [
    source 1356
    target 1359
    kind "mentions"
  ]
  edge [
    source 1356
    target 1360
    kind "mentions"
  ]
  edge [
    source 1356
    target 1361
    kind "mentions"
  ]
  edge [
    source 1356
    target 1362
    kind "mentions"
  ]
  edge [
    source 1356
    target 1363
    kind "mentions"
  ]
  edge [
    source 1356
    target 1364
    kind "mentions"
  ]
  edge [
    source 1356
    target 1365
    kind "mentions"
  ]
  edge [
    source 1356
    target 1366
    kind "mentions"
  ]
  edge [
    source 1356
    target 1367
    kind "mentions"
  ]
  edge [
    source 1356
    target 1368
    kind "mentions"
  ]
  edge [
    source 1356
    target 1369
    kind "mentions"
  ]
  edge [
    source 1356
    target 1370
    kind "mentions"
  ]
  edge [
    source 1356
    target 1371
    kind "mentions"
  ]
  edge [
    source 1356
    target 1372
    kind "mentions"
  ]
  edge [
    source 1356
    target 1373
    kind "mentions"
  ]
  edge [
    source 1356
    target 1374
    kind "mentions"
  ]
  edge [
    source 1356
    target 1375
    kind "mentions"
  ]
  edge [
    source 1356
    target 1376
    kind "mentions"
  ]
  edge [
    source 1356
    target 1377
    kind "mentions"
  ]
  edge [
    source 1356
    target 1378
    kind "mentions"
  ]
  edge [
    source 1356
    target 1379
    kind "mentions"
  ]
  edge [
    source 1356
    target 1380
    kind "mentions"
  ]
  edge [
    source 1356
    target 2237
    kind "summarizes"
  ]
  edge [
    source 1368
    target 1382
    kind "mentions"
  ]
  edge [
    source 1368
    target 1693
    kind "mentions"
  ]
  edge [
    source 1368
    target 1711
    kind "mentions"
  ]
  edge [
    source 1368
    target 1413
    kind "relation"
    relation "is instructed to unlock | unlocks"
    weight 2
  ]
  edge [
    source 1368
    target 1827
    kind "mentions"
  ]
  edge [
    source 1368
    target 1417
    kind "relation"
    relation "shouts through"
    weight 1
  ]
  edge [
    source 1376
    target 2020
    kind "mentions"
  ]
  edge [
    source 1380
    target 1382
    kind "mentions"
  ]
  edge [
    source 1380
    target 1858
    kind "mentions"
  ]
  edge [
    source 1380
    target 1864
    kind "mentions"
  ]
  edge [
    source 1381
    target 1382
    kind "from_chunk"
  ]
  edge [
    source 1381
    target 1401
    kind "from_chunk"
  ]
  edge [
    source 1382
    target 1383
    kind "mentions"
  ]
  edge [
    source 1382
    target 1384
    kind "mentions"
  ]
  edge [
    source 1382
    target 1385
    kind "mentions"
  ]
  edge [
    source 1382
    target 1386
    kind "mentions"
  ]
  edge [
    source 1382
    target 1387
    kind "mentions"
  ]
  edge [
    source 1382
    target 1388
    kind "mentions"
  ]
  edge [
    source 1382
    target 1389
    kind "mentions"
  ]
  edge [
    source 1382
    target 1390
    kind "mentions"
  ]
  edge [
    source 1382
    target 1391
    kind "mentions"
  ]
  edge [
    source 1382
    target 1392
    kind "mentions"
  ]
  edge [
    source 1382
    target 1393
    kind "mentions"
  ]
  edge [
    source 1382
    target 1394
    kind "mentions"
  ]
  edge [
    source 1382
    target 1395
    kind "mentions"
  ]
  edge [
    source 1382
    target 1396
    kind "mentions"
  ]
  edge [
    source 1382
    target 1397
    kind "mentions"
  ]
  edge [
    source 1382
    target 1398
    kind "mentions"
  ]
  edge [
    source 1382
    target 1399
    kind "mentions"
  ]
  edge [
    source 1382
    target 1400
    kind "mentions"
  ]
  edge [
    source 1382
    target 2239
    kind "summarizes"
  ]
  edge [
    source 1383
    target 1553
    kind "mentions"
  ]
  edge [
    source 1383
    target 1413
    kind "relation"
    relation "is wife of | is now married to"
    weight 2
  ]
  edge [
    source 1383
    target 2120
    kind "mentions"
  ]
  edge [
    source 1383
    target 2122
    kind "mentions"
  ]
  edge [
    source 1386
    target 1540
    kind "mentions"
  ]
  edge [
    source 1386
    target 1623
    kind "mentions"
  ]
  edge [
    source 1386
    target 1634
    kind "mentions"
  ]
  edge [
    source 1387
    target 1401
    kind "mentions"
  ]
  edge [
    source 1387
    target 1392
    kind "relation"
    relation "opens to"
    weight 2
  ]
  edge [
    source 1387
    target 1407
    kind "mentions"
  ]
  edge [
    source 1388
    target 1407
    kind "mentions"
  ]
  edge [
    source 1388
    target 1602
    kind "mentions"
  ]
  edge [
    source 1388
    target 1729
    kind "mentions"
  ]
  edge [
    source 1388
    target 1735
    kind "relation"
    relation "serves"
    weight 1
  ]
  edge [
    source 1388
    target 1417
    kind "relation"
    relation "is in charge of"
    weight 1
  ]
  edge [
    source 1388
    target 1740
    kind "mentions"
  ]
  edge [
    source 1388
    target 2048
    kind "mentions"
  ]
  edge [
    source 1389
    target 1401
    kind "mentions"
  ]
  edge [
    source 1389
    target 1405
    kind "relation"
    relation "has"
    weight 1
  ]
  edge [
    source 1390
    target 1401
    kind "mentions"
  ]
  edge [
    source 1390
    target 1405
    kind "relation"
    relation "has"
    weight 1
  ]
  edge [
    source 1391
    target 1401
    kind "mentions"
  ]
  edge [
    source 1391
    target 1405
    kind "relation"
    relation "has"
    weight 1
  ]
  edge [
    source 1392
    target 1401
    kind "mentions"
  ]
  edge [
    source 1392
    target 1393
    kind "relation"
    relation "has"
    weight 1
  ]
  edge [
    source 1392
    target 1394
    kind "relation"
    relation "has"
    weight 2
  ]
  edge [
    source 1392
    target 1407
    kind "mentions"
  ]
  edge [
    source 1392
    target 1408
    kind "relation"
    relation "has"
    weight 1
  ]
  edge [
    source 1393
    target 1401
    kind "mentions"
  ]
  edge [
    source 1394
    target 1401
    kind "mentions"
  ]
  edge [
    source 1394
    target 1407
    kind "mentions"
  ]
  edge [
    source 1395
    target 1401
    kind "mentions"
  ]
  edge [
    source 1399
    target 2174
    kind "mentions"
  ]
  edge [
    source 1399
    target 2176
    kind "relation"
    relation "followed by"
    weight 1
  ]
  edge [
    source 1401
    target 1402
    kind "mentions"
  ]
  edge [
    source 1401
    target 1403
    kind "mentions"
  ]
  edge [
    source 1401
    target 1404
    kind "mentions"
  ]
  edge [
    source 1401
    target 1405
    kind "mentions"
  ]
  edge [
    source 1401
    target 2239
    kind "summarizes"
  ]
  edge [
    source 1403
    target 1404
    kind "relation"
    relation "takes place in"
    weight 1
  ]
  edge [
    source 1404
    target 1405
    kind "relation"
    relation "has a"
    weight 1
  ]
  edge [
    source 1406
    target 1407
    kind "from_chunk"
  ]
  edge [
    source 1406
    target 1416
    kind "from_chunk"
  ]
  edge [
    source 1406
    target 1426
    kind "from_chunk"
  ]
  edge [
    source 1407
    target 1408
    kind "mentions"
  ]
  edge [
    source 1407
    target 1409
    kind "mentions"
  ]
  edge [
    source 1407
    target 1410
    kind "mentions"
  ]
  edge [
    source 1407
    target 1411
    kind "mentions"
  ]
  edge [
    source 1407
    target 1412
    kind "mentions"
  ]
  edge [
    source 1407
    target 1413
    kind "mentions"
  ]
  edge [
    source 1407
    target 1414
    kind "mentions"
  ]
  edge [
    source 1407
    target 1415
    kind "mentions"
  ]
  edge [
    source 1407
    target 2239
    kind "summarizes"
  ]
  edge [
    source 1409
    target 1415
    kind "relation"
    relation "has hung on it"
    weight 1
  ]
  edge [
    source 1410
    target 1415
    kind "relation"
    relation "has hung on it"
    weight 1
  ]
  edge [
    source 1411
    target 1415
    kind "relation"
    relation "has hung on it"
    weight 1
  ]
  edge [
    source 1412
    target 1416
    kind "mentions"
  ]
  edge [
    source 1413
    target 1416
    kind "mentions"
  ]
  edge [
    source 1413
    target 1421
    kind "relation"
    relation "is cooking while singing"
    weight 1
  ]
  edge [
    source 1413
    target 1417
    kind "relation"
    relation "calls out to | brought the prisoner home | was in bed hours when | brought someone home | tells to brighten up | clutches her hands and sinks to her knees | asks to be introduced by | warns not to betray"
    weight 8
  ]
  edge [
    source 1413
    target 1423
    kind "relation"
    relation "asks if"
    weight 1
  ]
  edge [
    source 1413
    target 1426
    kind "mentions"
  ]
  edge [
    source 1413
    target 1427
    kind "relation"
    relation "is knocked at"
    weight 1
  ]
  edge [
    source 1413
    target 1431
    kind "relation"
    relation "calls the dean"
    weight 1
  ]
  edge [
    source 1413
    target 1433
    kind "mentions"
  ]
  edge [
    source 1413
    target 1445
    kind "relation"
    relation "has only been in"
    weight 1
  ]
  edge [
    source 1413
    target 1446
    kind "relation"
    relation "feels as high as ever she is likely to be"
    weight 1
  ]
  edge [
    source 1413
    target 1448
    kind "mentions"
  ]
  edge [
    source 1413
    target 1461
    kind "relation"
    relation "remembers no social barriers when she was"
    weight 1
  ]
  edge [
    source 1413
    target 1457
    kind "relation"
    relation "says the rule is that the prisoner is lodged only for the night"
    weight 1
  ]
  edge [
    source 1413
    target 1464
    kind "relation"
    relation "says noah is behindhand today"
    weight 1
  ]
  edge [
    source 1413
    target 1465
    kind "relation"
    relation "says noah will not go to durnstone until"
    weight 1
  ]
  edge [
    source 1413
    target 1452
    kind "relation"
    relation "confirms the prisoner is in"
    weight 1
  ]
  edge [
    source 1413
    target 1466
    kind "relation"
    relation "says the cell is"
    weight 1
  ]
  edge [
    source 1413
    target 1468
    kind "mentions"
  ]
  edge [
    source 1413
    target 1469
    kind "relation"
    relation "says the cell is called"
    weight 1
  ]
  edge [
    source 1413
    target 1480
    kind "relation"
    relation "questions if the honor is"
    weight 1
  ]
  edge [
    source 1413
    target 1482
    kind "relation"
    relation "throws the cards into"
    weight 1
  ]
  edge [
    source 1413
    target 1474
    kind "relation"
    relation "says she never asks noah about"
    weight 1
  ]
  edge [
    source 1413
    target 1477
    kind "relation"
    relation "was in bed during"
    weight 1
  ]
  edge [
    source 1413
    target 1486
    kind "relation"
    relation "takes no interest in"
    weight 1
  ]
  edge [
    source 1413
    target 1488
    kind "mentions"
  ]
  edge [
    source 1413
    target 1493
    kind "relation"
    relation "has a burning joint | refuses to open | shuts | opens"
    weight 5
  ]
  edge [
    source 1413
    target 1494
    kind "mentions"
  ]
  edge [
    source 1413
    target 1501
    kind "relation"
    relation "knows something about"
    weight 1
  ]
  edge [
    source 1413
    target 1502
    kind "mentions"
  ]
  edge [
    source 1413
    target 1507
    kind "mentions"
  ]
  edge [
    source 1413
    target 1520
    kind "relation"
    relation "is confused about"
    weight 1
  ]
  edge [
    source 1413
    target 1523
    kind "relation"
    relation "reassures blore that he is"
    weight 1
  ]
  edge [
    source 1413
    target 1528
    kind "mentions"
  ]
  edge [
    source 1413
    target 1533
    kind "mentions"
  ]
  edge [
    source 1413
    target 1537
    kind "relation"
    relation "expresses concern about"
    weight 1
  ]
  edge [
    source 1413
    target 1540
    kind "mentions"
  ]
  edge [
    source 1413
    target 1551
    kind "mentions"
  ]
  edge [
    source 1413
    target 1544
    kind "relation"
    relation "does not want to experience"
    weight 1
  ]
  edge [
    source 1413
    target 1553
    kind "mentions"
  ]
  edge [
    source 1413
    target 1562
    kind "relation"
    relation "declares she will not torture"
    weight 1
  ]
  edge [
    source 1413
    target 1564
    kind "relation"
    relation "exclaims she is not"
    weight 1
  ]
  edge [
    source 1413
    target 1556
    kind "relation"
    relation "calls herself"
    weight 1
  ]
  edge [
    source 1413
    target 1557
    kind "relation"
    relation "identifies herself as"
    weight 1
  ]
  edge [
    source 1413
    target 1568
    kind "relation"
    relation "sinks weeping upon"
    weight 1
  ]
  edge [
    source 1413
    target 1569
    kind "relation"
    relation "repeatedly asks"
    weight 1
  ]
  edge [
    source 1413
    target 1570
    kind "relation"
    relation "claps her hands"
    weight 1
  ]
  edge [
    source 1413
    target 1572
    kind "mentions"
  ]
  edge [
    source 1413
    target 1580
    kind "relation"
    relation "states that"
    weight 1
  ]
  edge [
    source 1413
    target 1575
    kind "relation"
    relation "produces"
    weight 1
  ]
  edge [
    source 1413
    target 1576
    kind "relation"
    relation "unlocks"
    weight 1
  ]
  edge [
    source 1413
    target 1581
    kind "relation"
    relation "requests"
    weight 1
  ]
  edge [
    source 1413
    target 1583
    kind "relation"
    relation "urges"
    weight 1
  ]
  edge [
    source 1413
    target 1585
    kind "relation"
    relation "states that"
    weight 1
  ]
  edge [
    source 1413
    target 1594
    kind "mentions"
  ]
  edge [
    source 1413
    target 1600
    kind "relation"
    relation "placed"
    weight 1
  ]
  edge [
    source 1413
    target 1602
    kind "mentions"
  ]
  edge [
    source 1413
    target 1604
    kind "relation"
    relation "considers the dean's situation a treat compared to"
    weight 1
  ]
  edge [
    source 1413
    target 1605
    kind "mentions"
  ]
  edge [
    source 1413
    target 1613
    kind "mentions"
  ]
  edge [
    source 1413
    target 1615
    kind "relation"
    relation "asks if the dean's story is his only chance of"
    weight 1
  ]
  edge [
    source 1413
    target 1616
    kind "mentions"
  ]
  edge [
    source 1413
    target 1621
    kind "relation"
    relation "states that john ruggles and the two inspectors are | claims"
    weight 2
  ]
  edge [
    source 1413
    target 1623
    kind "mentions"
  ]
  edge [
    source 1413
    target 1632
    kind "relation"
    relation "was well fed and stayed"
    weight 1
  ]
  edge [
    source 1413
    target 1627
    kind "relation"
    relation "explains the devil is always in"
    weight 1
  ]
  edge [
    source 1413
    target 1630
    kind "relation"
    relation "takes from"
    weight 1
  ]
  edge [
    source 1413
    target 1547
    kind "relation"
    relation "says noah drives the dean to durnstone with"
    weight 1
  ]
  edge [
    source 1413
    target 1651
    kind "mentions"
  ]
  edge [
    source 1413
    target 1657
    kind "relation"
    relation "says"
    weight 1
  ]
  edge [
    source 1413
    target 1658
    kind "relation"
    relation "wants to give"
    weight 1
  ]
  edge [
    source 1413
    target 1662
    kind "mentions"
  ]
  edge [
    source 1413
    target 1664
    kind "relation"
    relation "removes"
    weight 1
  ]
  edge [
    source 1413
    target 1674
    kind "relation"
    relation "says that"
    weight 1
  ]
  edge [
    source 1413
    target 1492
    kind "relation"
    relation "insists that he is not done with"
    weight 1
  ]
  edge [
    source 1413
    target 1667
    kind "relation"
    relation "says he will feel wickeder without"
    weight 1
  ]
  edge [
    source 1413
    target 1675
    kind "relation"
    relation "tells him to taste"
    weight 1
  ]
  edge [
    source 1413
    target 1677
    kind "relation"
    relation "says he cannot blow a whistle on"
    weight 1
  ]
  edge [
    source 1413
    target 1681
    kind "mentions"
  ]
  edge [
    source 1413
    target 1682
    kind "relation"
    relation "asks for"
    weight 1
  ]
  edge [
    source 1413
    target 1689
    kind "relation"
    relation "cries and clings to"
    weight 1
  ]
  edge [
    source 1413
    target 1545
    kind "relation"
    relation "met the gentleman through"
    weight 1
  ]
  edge [
    source 1413
    target 1687
    kind "relation"
    relation "says the gentleman spoke to her as a strange gentleman should to a lady"
    weight 1
  ]
  edge [
    source 1413
    target 1693
    kind "mentions"
  ]
  edge [
    source 1413
    target 1711
    kind "mentions"
  ]
  edge [
    source 1413
    target 1718
    kind "relation"
    relation "weeps"
    weight 1
  ]
  edge [
    source 1413
    target 1719
    kind "relation"
    relation "says"
    weight 1
  ]
  edge [
    source 1413
    target 1722
    kind "relation"
    relation "confirms"
    weight 1
  ]
  edge [
    source 1413
    target 1723
    kind "relation"
    relation "invites"
    weight 1
  ]
  edge [
    source 1413
    target 1724
    kind "relation"
    relation "invites"
    weight 1
  ]
  edge [
    source 1413
    target 1725
    kind "relation"
    relation "replies"
    weight 1
  ]
  edge [
    source 1413
    target 1729
    kind "mentions"
  ]
  edge [
    source 1413
    target 1765
    kind "mentions"
  ]
  edge [
    source 1413
    target 1773
    kind "mentions"
  ]
  edge [
    source 1413
    target 1776
    kind "mentions"
  ]
  edge [
    source 1413
    target 1793
    kind "mentions"
  ]
  edge [
    source 1413
    target 1797
    kind "relation"
    relation "has prewided for"
    weight 1
  ]
  edge [
    source 1413
    target 1796
    kind "relation"
    relation "says there is an awfuller charge over"
    weight 1
  ]
  edge [
    source 1413
    target 1798
    kind "mentions"
  ]
  edge [
    source 1413
    target 1827
    kind "mentions"
  ]
  edge [
    source 1413
    target 1830
    kind "relation"
    relation "says"
    weight 1
  ]
  edge [
    source 1413
    target 1851
    kind "mentions"
  ]
  edge [
    source 1413
    target 1441
    kind "relation"
    relation "says only the three of them will ever know of"
    weight 1
  ]
  edge [
    source 1413
    target 2104
    kind "mentions"
  ]
  edge [
    source 1413
    target 2118
    kind "mentions"
  ]
  edge [
    source 1413
    target 2120
    kind "mentions"
  ]
  edge [
    source 1413
    target 2121
    kind "relation"
    relation "apologizes for"
    weight 1
  ]
  edge [
    source 1413
    target 2126
    kind "mentions"
  ]
  edge [
    source 1414
    target 1416
    kind "mentions"
  ]
  edge [
    source 1416
    target 1417
    kind "mentions"
  ]
  edge [
    source 1416
    target 1418
    kind "mentions"
  ]
  edge [
    source 1416
    target 1419
    kind "mentions"
  ]
  edge [
    source 1416
    target 1420
    kind "mentions"
  ]
  edge [
    source 1416
    target 1421
    kind "mentions"
  ]
  edge [
    source 1416
    target 1422
    kind "mentions"
  ]
  edge [
    source 1416
    target 1423
    kind "mentions"
  ]
  edge [
    source 1416
    target 1424
    kind "mentions"
  ]
  edge [
    source 1416
    target 1425
    kind "mentions"
  ]
  edge [
    source 1416
    target 2239
    kind "summarizes"
  ]
  edge [
    source 1417
    target 1422
    kind "relation"
    relation "responds from"
    weight 1
  ]
  edge [
    source 1417
    target 1424
    kind "relation"
    relation "agrees to"
    weight 1
  ]
  edge [
    source 1417
    target 1425
    kind "relation"
    relation "is in a nice temper over"
    weight 1
  ]
  edge [
    source 1417
    target 1448
    kind "mentions"
  ]
  edge [
    source 1417
    target 1468
    kind "mentions"
  ]
  edge [
    source 1417
    target 1485
    kind "relation"
    relation "does not want"
    weight 1
  ]
  edge [
    source 1417
    target 1488
    kind "mentions"
  ]
  edge [
    source 1417
    target 1528
    kind "mentions"
  ]
  edge [
    source 1417
    target 1532
    kind "relation"
    relation "places truncheon in"
    weight 1
  ]
  edge [
    source 1417
    target 1533
    kind "mentions"
  ]
  edge [
    source 1417
    target 1534
    kind "relation"
    relation "selects | examines critically"
    weight 2
  ]
  edge [
    source 1417
    target 1538
    kind "relation"
    relation "states has only"
    weight 1
  ]
  edge [
    source 1417
    target 1540
    kind "mentions"
  ]
  edge [
    source 1417
    target 1547
    kind "relation"
    relation "puts"
    weight 1
  ]
  edge [
    source 1417
    target 1542
    kind "relation"
    relation "is going to get a glimpse of"
    weight 1
  ]
  edge [
    source 1417
    target 1541
    kind "relation"
    relation "sees"
    weight 1
  ]
  edge [
    source 1417
    target 1493
    kind "relation"
    relation "tells hannah to open"
    weight 1
  ]
  edge [
    source 1417
    target 1549
    kind "relation"
    relation "says is torture"
    weight 1
  ]
  edge [
    source 1417
    target 1550
    kind "relation"
    relation "has a rule for"
    weight 1
  ]
  edge [
    source 1417
    target 1553
    kind "mentions"
  ]
  edge [
    source 1417
    target 1554
    kind "relation"
    relation "talks about"
    weight 1
  ]
  edge [
    source 1417
    target 1572
    kind "mentions"
  ]
  edge [
    source 1417
    target 1634
    kind "mentions"
  ]
  edge [
    source 1417
    target 1681
    kind "mentions"
  ]
  edge [
    source 1417
    target 1690
    kind "relation"
    relation "wants to know the name of | states that a friend of her is a friend of"
    weight 2
  ]
  edge [
    source 1417
    target 1691
    kind "relation"
    relation "agrees with cooks and railins"
    weight 1
  ]
  edge [
    source 1417
    target 1685
    kind "relation"
    relation "says he might have guessed his married life would come to"
    weight 1
  ]
  edge [
    source 1417
    target 1693
    kind "mentions"
  ]
  edge [
    source 1417
    target 1704
    kind "relation"
    relation "states that it is neither the right time nor place"
    weight 1
  ]
  edge [
    source 1417
    target 1706
    kind "relation"
    relation "agrees that the dean has touched on"
    weight 1
  ]
  edge [
    source 1417
    target 1694
    kind "relation"
    relation "emphasizes that his police station in durnstone is more strict and rigid than any other"
    weight 1
  ]
  edge [
    source 1417
    target 1707
    kind "relation"
    relation "will take further action"
    weight 1
  ]
  edge [
    source 1417
    target 1708
    kind "relation"
    relation "makes the charge of"
    weight 1
  ]
  edge [
    source 1417
    target 1709
    kind "relation"
    relation "accuses the dean of"
    weight 1
  ]
  edge [
    source 1417
    target 1452
    kind "relation"
    relation "directs the dean to go into | enters | closes the door behind him | comes out of"
    weight 4
  ]
  edge [
    source 1417
    target 1703
    kind "relation"
    relation "states that the dean has five minutes more in"
    weight 1
  ]
  edge [
    source 1417
    target 1711
    kind "mentions"
  ]
  edge [
    source 1417
    target 1713
    kind "relation"
    relation "points to"
    weight 1
  ]
  edge [
    source 1417
    target 1576
    kind "relation"
    relation "closes and locks"
    weight 1
  ]
  edge [
    source 1417
    target 1720
    kind "relation"
    relation "insists on"
    weight 1
  ]
  edge [
    source 1417
    target 1729
    kind "mentions"
  ]
  edge [
    source 1417
    target 1736
    kind "relation"
    relation "says people generally come to see | has proceedings pending against"
    weight 2
  ]
  edge [
    source 1417
    target 1737
    kind "relation"
    relation "separates the room into"
    weight 1
  ]
  edge [
    source 1417
    target 1738
    kind "relation"
    relation "has a wife who is"
    weight 1
  ]
  edge [
    source 1417
    target 1740
    kind "mentions"
  ]
  edge [
    source 1417
    target 1663
    kind "relation"
    relation "carries"
    weight 1
  ]
  edge [
    source 1417
    target 1746
    kind "relation"
    relation "says the baking tin contains"
    weight 1
  ]
  edge [
    source 1417
    target 1742
    kind "relation"
    relation "confirms he is touching"
    weight 1
  ]
  edge [
    source 1417
    target 1749
    kind "mentions"
  ]
  edge [
    source 1417
    target 1760
    kind "relation"
    relation "has a theory that removes suspense"
    weight 1
  ]
  edge [
    source 1417
    target 1762
    kind "relation"
    relation "has been traveling and reading"
    weight 1
  ]
  edge [
    source 1417
    target 1758
    kind "relation"
    relation "concludes this is an ordinary case of"
    weight 1
  ]
  edge [
    source 1417
    target 1763
    kind "relation"
    relation "suggests he could run up during the evening"
    weight 1
  ]
  edge [
    source 1417
    target 1765
    kind "mentions"
  ]
  edge [
    source 1417
    target 1766
    kind "relation"
    relation "writes a description of"
    weight 1
  ]
  edge [
    source 1417
    target 1772
    kind "relation"
    relation "describes the dean as"
    weight 1
  ]
  edge [
    source 1417
    target 1773
    kind "mentions"
  ]
  edge [
    source 1417
    target 1774
    kind "relation"
    relation "prepares to write by placing"
    weight 1
  ]
  edge [
    source 1417
    target 1776
    kind "mentions"
  ]
  edge [
    source 1417
    target 1778
    kind "relation"
    relation "is the constable who took"
    weight 1
  ]
  edge [
    source 1417
    target 1779
    kind "relation"
    relation "has a cart ready to take"
    weight 1
  ]
  edge [
    source 1417
    target 1781
    kind "relation"
    relation "has a baking-tin under his arm"
    weight 1
  ]
  edge [
    source 1417
    target 1782
    kind "mentions"
  ]
  edge [
    source 1417
    target 1783
    kind "relation"
    relation "feels frustrated because"
    weight 1
  ]
  edge [
    source 1417
    target 1785
    kind "mentions"
  ]
  edge [
    source 1417
    target 1788
    kind "mentions"
  ]
  edge [
    source 1417
    target 1793
    kind "mentions"
  ]
  edge [
    source 1417
    target 1802
    kind "mentions"
  ]
  edge [
    source 1417
    target 1812
    kind "mentions"
  ]
  edge [
    source 1417
    target 1816
    kind "relation"
    relation "found"
    weight 1
  ]
  edge [
    source 1417
    target 1817
    kind "mentions"
  ]
  edge [
    source 1417
    target 1822
    kind "relation"
    relation "is the only man who can withdraw"
    weight 1
  ]
  edge [
    source 1417
    target 1823
    kind "relation"
    relation "is the only man who can withdraw"
    weight 1
  ]
  edge [
    source 1417
    target 1825
    kind "relation"
    relation "is putting"
    weight 1
  ]
  edge [
    source 1417
    target 1826
    kind "relation"
    relation "plans to drive"
    weight 1
  ]
  edge [
    source 1417
    target 1827
    kind "mentions"
  ]
  edge [
    source 1417
    target 1831
    kind "relation"
    relation "says"
    weight 1
  ]
  edge [
    source 1417
    target 1833
    kind "mentions"
  ]
  edge [
    source 1417
    target 1843
    kind "relation"
    relation "appears at"
    weight 1
  ]
  edge [
    source 1417
    target 1851
    kind "mentions"
  ]
  edge [
    source 1417
    target 1855
    kind "relation"
    relation "tells to get up"
    weight 1
  ]
  edge [
    source 1417
    target 2118
    kind "mentions"
  ]
  edge [
    source 1417
    target 2119
    kind "relation"
    relation "accuses"
    weight 1
  ]
  edge [
    source 1417
    target 2126
    kind "mentions"
  ]
  edge [
    source 1417
    target 2132
    kind "relation"
    relation "criticizes"
    weight 1
  ]
  edge [
    source 1418
    target 1448
    kind "mentions"
  ]
  edge [
    source 1418
    target 1468
    kind "mentions"
  ]
  edge [
    source 1418
    target 1478
    kind "relation"
    relation "is accustomed to"
    weight 1
  ]
  edge [
    source 1419
    target 1420
    kind "relation"
    relation "are liable to"
    weight 1
  ]
  edge [
    source 1426
    target 1427
    kind "mentions"
  ]
  edge [
    source 1426
    target 1428
    kind "mentions"
  ]
  edge [
    source 1426
    target 1429
    kind "mentions"
  ]
  edge [
    source 1426
    target 1430
    kind "mentions"
  ]
  edge [
    source 1426
    target 1431
    kind "mentions"
  ]
  edge [
    source 1426
    target 2214
    kind "summarizes"
  ]
  edge [
    source 1432
    target 1433
    kind "from_chunk"
  ]
  edge [
    source 1433
    target 1434
    kind "mentions"
  ]
  edge [
    source 1433
    target 1435
    kind "mentions"
  ]
  edge [
    source 1433
    target 1436
    kind "mentions"
  ]
  edge [
    source 1433
    target 1437
    kind "mentions"
  ]
  edge [
    source 1433
    target 1438
    kind "mentions"
  ]
  edge [
    source 1433
    target 1439
    kind "mentions"
  ]
  edge [
    source 1433
    target 1440
    kind "mentions"
  ]
  edge [
    source 1433
    target 1441
    kind "mentions"
  ]
  edge [
    source 1433
    target 1442
    kind "mentions"
  ]
  edge [
    source 1433
    target 1443
    kind "mentions"
  ]
  edge [
    source 1433
    target 1444
    kind "mentions"
  ]
  edge [
    source 1433
    target 1445
    kind "mentions"
  ]
  edge [
    source 1433
    target 1446
    kind "mentions"
  ]
  edge [
    source 1433
    target 2235
    kind "summarizes"
  ]
  edge [
    source 1434
    target 1468
    kind "mentions"
  ]
  edge [
    source 1436
    target 1448
    kind "mentions"
  ]
  edge [
    source 1441
    target 1851
    kind "mentions"
  ]
  edge [
    source 1447
    target 1448
    kind "from_chunk"
  ]
  edge [
    source 1448
    target 1449
    kind "mentions"
  ]
  edge [
    source 1448
    target 1450
    kind "mentions"
  ]
  edge [
    source 1448
    target 1451
    kind "mentions"
  ]
  edge [
    source 1448
    target 1452
    kind "mentions"
  ]
  edge [
    source 1448
    target 1453
    kind "mentions"
  ]
  edge [
    source 1448
    target 1454
    kind "mentions"
  ]
  edge [
    source 1448
    target 1455
    kind "mentions"
  ]
  edge [
    source 1448
    target 1456
    kind "mentions"
  ]
  edge [
    source 1448
    target 1457
    kind "mentions"
  ]
  edge [
    source 1448
    target 1458
    kind "mentions"
  ]
  edge [
    source 1448
    target 1459
    kind "mentions"
  ]
  edge [
    source 1448
    target 1460
    kind "mentions"
  ]
  edge [
    source 1448
    target 1461
    kind "mentions"
  ]
  edge [
    source 1448
    target 1462
    kind "mentions"
  ]
  edge [
    source 1448
    target 1463
    kind "mentions"
  ]
  edge [
    source 1448
    target 1464
    kind "mentions"
  ]
  edge [
    source 1448
    target 1465
    kind "mentions"
  ]
  edge [
    source 1448
    target 1466
    kind "mentions"
  ]
  edge [
    source 1448
    target 2235
    kind "summarizes"
  ]
  edge [
    source 1452
    target 1693
    kind "mentions"
  ]
  edge [
    source 1452
    target 1785
    kind "mentions"
  ]
  edge [
    source 1452
    target 1802
    kind "mentions"
  ]
  edge [
    source 1454
    target 1880
    kind "mentions"
  ]
  edge [
    source 1457
    target 1540
    kind "mentions"
  ]
  edge [
    source 1463
    target 1528
    kind "mentions"
  ]
  edge [
    source 1463
    target 1749
    kind "mentions"
  ]
  edge [
    source 1463
    target 1989
    kind "mentions"
  ]
  edge [
    source 1463
    target 2122
    kind "mentions"
  ]
  edge [
    source 1463
    target 2125
    kind "mentions"
  ]
  edge [
    source 1463
    target 2192
    kind "mentions"
  ]
  edge [
    source 1463
    target 1990
    kind "relation"
    relation "followed by"
    weight 1
  ]
  edge [
    source 1467
    target 1468
    kind "from_chunk"
  ]
  edge [
    source 1468
    target 1469
    kind "mentions"
  ]
  edge [
    source 1468
    target 1470
    kind "mentions"
  ]
  edge [
    source 1468
    target 1471
    kind "mentions"
  ]
  edge [
    source 1468
    target 1472
    kind "mentions"
  ]
  edge [
    source 1468
    target 1473
    kind "mentions"
  ]
  edge [
    source 1468
    target 1474
    kind "mentions"
  ]
  edge [
    source 1468
    target 1475
    kind "mentions"
  ]
  edge [
    source 1468
    target 1476
    kind "mentions"
  ]
  edge [
    source 1468
    target 1477
    kind "mentions"
  ]
  edge [
    source 1468
    target 1478
    kind "mentions"
  ]
  edge [
    source 1468
    target 1479
    kind "mentions"
  ]
  edge [
    source 1468
    target 1480
    kind "mentions"
  ]
  edge [
    source 1468
    target 1481
    kind "mentions"
  ]
  edge [
    source 1468
    target 1482
    kind "mentions"
  ]
  edge [
    source 1468
    target 1483
    kind "mentions"
  ]
  edge [
    source 1468
    target 1484
    kind "mentions"
  ]
  edge [
    source 1468
    target 1485
    kind "mentions"
  ]
  edge [
    source 1468
    target 1486
    kind "mentions"
  ]
  edge [
    source 1468
    target 2235
    kind "summarizes"
  ]
  edge [
    source 1475
    target 1572
    kind "mentions"
  ]
  edge [
    source 1475
    target 1587
    kind "mentions"
  ]
  edge [
    source 1487
    target 1488
    kind "from_chunk"
  ]
  edge [
    source 1487
    target 1494
    kind "from_chunk"
  ]
  edge [
    source 1487
    target 1502
    kind "from_chunk"
  ]
  edge [
    source 1488
    target 1489
    kind "mentions"
  ]
  edge [
    source 1488
    target 1490
    kind "mentions"
  ]
  edge [
    source 1488
    target 1491
    kind "mentions"
  ]
  edge [
    source 1488
    target 1492
    kind "mentions"
  ]
  edge [
    source 1488
    target 1493
    kind "mentions"
  ]
  edge [
    source 1488
    target 2224
    kind "summarizes"
  ]
  edge [
    source 1492
    target 1662
    kind "mentions"
  ]
  edge [
    source 1493
    target 1540
    kind "mentions"
  ]
  edge [
    source 1493
    target 1551
    kind "mentions"
  ]
  edge [
    source 1493
    target 1553
    kind "mentions"
  ]
  edge [
    source 1493
    target 1662
    kind "mentions"
  ]
  edge [
    source 1494
    target 1495
    kind "mentions"
  ]
  edge [
    source 1494
    target 1496
    kind "mentions"
  ]
  edge [
    source 1494
    target 1497
    kind "mentions"
  ]
  edge [
    source 1494
    target 1498
    kind "mentions"
  ]
  edge [
    source 1494
    target 1499
    kind "mentions"
  ]
  edge [
    source 1494
    target 1500
    kind "mentions"
  ]
  edge [
    source 1494
    target 1501
    kind "mentions"
  ]
  edge [
    source 1494
    target 2224
    kind "summarizes"
  ]
  edge [
    source 1495
    target 1496
    kind "relation"
    relation "might shake"
    weight 1
  ]
  edge [
    source 1495
    target 1497
    kind "relation"
    relation "could lead to"
    weight 1
  ]
  edge [
    source 1495
    target 1499
    kind "relation"
    relation "could hold its own in"
    weight 1
  ]
  edge [
    source 1495
    target 1500
    kind "relation"
    relation "could surpass"
    weight 1
  ]
  edge [
    source 1497
    target 1498
    kind "relation"
    relation "feature"
    weight 1
  ]
  edge [
    source 1502
    target 1503
    kind "mentions"
  ]
  edge [
    source 1502
    target 1504
    kind "mentions"
  ]
  edge [
    source 1502
    target 1505
    kind "mentions"
  ]
  edge [
    source 1502
    target 2238
    kind "summarizes"
  ]
  edge [
    source 1506
    target 1507
    kind "from_chunk"
  ]
  edge [
    source 1507
    target 1508
    kind "mentions"
  ]
  edge [
    source 1507
    target 1509
    kind "mentions"
  ]
  edge [
    source 1507
    target 1510
    kind "mentions"
  ]
  edge [
    source 1507
    target 1511
    kind "mentions"
  ]
  edge [
    source 1507
    target 1512
    kind "mentions"
  ]
  edge [
    source 1507
    target 1513
    kind "mentions"
  ]
  edge [
    source 1507
    target 1514
    kind "mentions"
  ]
  edge [
    source 1507
    target 1515
    kind "mentions"
  ]
  edge [
    source 1507
    target 1516
    kind "mentions"
  ]
  edge [
    source 1507
    target 1517
    kind "mentions"
  ]
  edge [
    source 1507
    target 1518
    kind "mentions"
  ]
  edge [
    source 1507
    target 1519
    kind "mentions"
  ]
  edge [
    source 1507
    target 1520
    kind "mentions"
  ]
  edge [
    source 1507
    target 1521
    kind "mentions"
  ]
  edge [
    source 1507
    target 1522
    kind "mentions"
  ]
  edge [
    source 1507
    target 1523
    kind "mentions"
  ]
  edge [
    source 1507
    target 1524
    kind "mentions"
  ]
  edge [
    source 1507
    target 1525
    kind "mentions"
  ]
  edge [
    source 1507
    target 1526
    kind "mentions"
  ]
  edge [
    source 1507
    target 2218
    kind "summarizes"
  ]
  edge [
    source 1518
    target 2152
    kind "mentions"
  ]
  edge [
    source 1518
    target 2155
    kind "relation"
    relation "laugh at"
    weight 1
  ]
  edge [
    source 1527
    target 1528
    kind "from_chunk"
  ]
  edge [
    source 1527
    target 1533
    kind "from_chunk"
  ]
  edge [
    source 1528
    target 1529
    kind "mentions"
  ]
  edge [
    source 1528
    target 1530
    kind "mentions"
  ]
  edge [
    source 1528
    target 1531
    kind "mentions"
  ]
  edge [
    source 1528
    target 1532
    kind "mentions"
  ]
  edge [
    source 1528
    target 2223
    kind "summarizes"
  ]
  edge [
    source 1533
    target 1534
    kind "mentions"
  ]
  edge [
    source 1533
    target 1535
    kind "mentions"
  ]
  edge [
    source 1533
    target 1536
    kind "mentions"
  ]
  edge [
    source 1533
    target 1537
    kind "mentions"
  ]
  edge [
    source 1533
    target 1538
    kind "mentions"
  ]
  edge [
    source 1533
    target 2216
    kind "summarizes"
  ]
  edge [
    source 1534
    target 1623
    kind "mentions"
  ]
  edge [
    source 1534
    target 1802
    kind "mentions"
  ]
  edge [
    source 1535
    target 1884
    kind "mentions"
  ]
  edge [
    source 1539
    target 1540
    kind "from_chunk"
  ]
  edge [
    source 1539
    target 1551
    kind "from_chunk"
  ]
  edge [
    source 1540
    target 1541
    kind "mentions"
  ]
  edge [
    source 1540
    target 1542
    kind "mentions"
  ]
  edge [
    source 1540
    target 1543
    kind "mentions"
  ]
  edge [
    source 1540
    target 1544
    kind "mentions"
  ]
  edge [
    source 1540
    target 1545
    kind "mentions"
  ]
  edge [
    source 1540
    target 1546
    kind "mentions"
  ]
  edge [
    source 1540
    target 1547
    kind "mentions"
  ]
  edge [
    source 1540
    target 1548
    kind "mentions"
  ]
  edge [
    source 1540
    target 1549
    kind "mentions"
  ]
  edge [
    source 1540
    target 1550
    kind "mentions"
  ]
  edge [
    source 1540
    target 2218
    kind "summarizes"
  ]
  edge [
    source 1541
    target 1548
    kind "relation"
    relation "is"
    weight 1
  ]
  edge [
    source 1541
    target 1623
    kind "mentions"
  ]
  edge [
    source 1541
    target 1851
    kind "mentions"
  ]
  edge [
    source 1543
    target 1662
    kind "mentions"
  ]
  edge [
    source 1544
    target 1551
    kind "mentions"
  ]
  edge [
    source 1545
    target 1553
    kind "mentions"
  ]
  edge [
    source 1545
    target 1681
    kind "mentions"
  ]
  edge [
    source 1547
    target 1623
    kind "mentions"
  ]
  edge [
    source 1551
    target 2218
    kind "summarizes"
  ]
  edge [
    source 1552
    target 1553
    kind "from_chunk"
  ]
  edge [
    source 1553
    target 1554
    kind "mentions"
  ]
  edge [
    source 1553
    target 1555
    kind "mentions"
  ]
  edge [
    source 1553
    target 1556
    kind "mentions"
  ]
  edge [
    source 1553
    target 1557
    kind "mentions"
  ]
  edge [
    source 1553
    target 1558
    kind "mentions"
  ]
  edge [
    source 1553
    target 1559
    kind "mentions"
  ]
  edge [
    source 1553
    target 1560
    kind "mentions"
  ]
  edge [
    source 1553
    target 1561
    kind "mentions"
  ]
  edge [
    source 1553
    target 1562
    kind "mentions"
  ]
  edge [
    source 1553
    target 1563
    kind "mentions"
  ]
  edge [
    source 1553
    target 1564
    kind "mentions"
  ]
  edge [
    source 1553
    target 1565
    kind "mentions"
  ]
  edge [
    source 1553
    target 1566
    kind "mentions"
  ]
  edge [
    source 1553
    target 1567
    kind "mentions"
  ]
  edge [
    source 1553
    target 1568
    kind "mentions"
  ]
  edge [
    source 1553
    target 1569
    kind "mentions"
  ]
  edge [
    source 1553
    target 1570
    kind "mentions"
  ]
  edge [
    source 1553
    target 2240
    kind "summarizes"
  ]
  edge [
    source 1555
    target 2120
    kind "mentions"
  ]
  edge [
    source 1566
    target 1740
    kind "mentions"
  ]
  edge [
    source 1566
    target 1833
    kind "mentions"
  ]
  edge [
    source 1566
    target 1837
    kind "relation"
    relation "is the husband of"
    weight 1
  ]
  edge [
    source 1571
    target 1572
    kind "from_chunk"
  ]
  edge [
    source 1572
    target 1573
    kind "mentions"
  ]
  edge [
    source 1572
    target 1574
    kind "mentions"
  ]
  edge [
    source 1572
    target 1575
    kind "mentions"
  ]
  edge [
    source 1572
    target 1576
    kind "mentions"
  ]
  edge [
    source 1572
    target 1577
    kind "mentions"
  ]
  edge [
    source 1572
    target 1578
    kind "mentions"
  ]
  edge [
    source 1572
    target 1579
    kind "mentions"
  ]
  edge [
    source 1572
    target 1580
    kind "mentions"
  ]
  edge [
    source 1572
    target 1581
    kind "mentions"
  ]
  edge [
    source 1572
    target 1582
    kind "mentions"
  ]
  edge [
    source 1572
    target 1583
    kind "mentions"
  ]
  edge [
    source 1572
    target 1584
    kind "mentions"
  ]
  edge [
    source 1572
    target 1585
    kind "mentions"
  ]
  edge [
    source 1572
    target 2237
    kind "summarizes"
  ]
  edge [
    source 1576
    target 1711
    kind "mentions"
  ]
  edge [
    source 1576
    target 1776
    kind "mentions"
  ]
  edge [
    source 1586
    target 1587
    kind "from_chunk"
  ]
  edge [
    source 1586
    target 1594
    kind "from_chunk"
  ]
  edge [
    source 1587
    target 1588
    kind "mentions"
  ]
  edge [
    source 1587
    target 1589
    kind "mentions"
  ]
  edge [
    source 1587
    target 1590
    kind "mentions"
  ]
  edge [
    source 1587
    target 1591
    kind "mentions"
  ]
  edge [
    source 1587
    target 1592
    kind "mentions"
  ]
  edge [
    source 1587
    target 1593
    kind "mentions"
  ]
  edge [
    source 1587
    target 2237
    kind "summarizes"
  ]
  edge [
    source 1590
    target 1591
    kind "relation"
    relation "is considered a priceless possession of"
    weight 1
  ]
  edge [
    source 1590
    target 2133
    kind "mentions"
  ]
  edge [
    source 1594
    target 1595
    kind "mentions"
  ]
  edge [
    source 1594
    target 1596
    kind "mentions"
  ]
  edge [
    source 1594
    target 1597
    kind "mentions"
  ]
  edge [
    source 1594
    target 1598
    kind "mentions"
  ]
  edge [
    source 1594
    target 1599
    kind "mentions"
  ]
  edge [
    source 1594
    target 1600
    kind "mentions"
  ]
  edge [
    source 1594
    target 2214
    kind "summarizes"
  ]
  edge [
    source 1601
    target 1602
    kind "from_chunk"
  ]
  edge [
    source 1601
    target 1605
    kind "from_chunk"
  ]
  edge [
    source 1601
    target 1613
    kind "from_chunk"
  ]
  edge [
    source 1601
    target 1616
    kind "from_chunk"
  ]
  edge [
    source 1602
    target 1603
    kind "mentions"
  ]
  edge [
    source 1602
    target 1604
    kind "mentions"
  ]
  edge [
    source 1602
    target 2224
    kind "summarizes"
  ]
  edge [
    source 1605
    target 1606
    kind "mentions"
  ]
  edge [
    source 1605
    target 1607
    kind "mentions"
  ]
  edge [
    source 1605
    target 1608
    kind "mentions"
  ]
  edge [
    source 1605
    target 1609
    kind "mentions"
  ]
  edge [
    source 1605
    target 1610
    kind "mentions"
  ]
  edge [
    source 1605
    target 1611
    kind "mentions"
  ]
  edge [
    source 1605
    target 1612
    kind "mentions"
  ]
  edge [
    source 1605
    target 2218
    kind "summarizes"
  ]
  edge [
    source 1606
    target 1616
    kind "mentions"
  ]
  edge [
    source 1607
    target 1613
    kind "mentions"
  ]
  edge [
    source 1608
    target 1613
    kind "mentions"
  ]
  edge [
    source 1609
    target 1612
    kind "relation"
    relation "will bring lasting comfort to"
    weight 1
  ]
  edge [
    source 1611
    target 1613
    kind "mentions"
  ]
  edge [
    source 1613
    target 1614
    kind "mentions"
  ]
  edge [
    source 1613
    target 1615
    kind "mentions"
  ]
  edge [
    source 1613
    target 2218
    kind "summarizes"
  ]
  edge [
    source 1616
    target 1617
    kind "mentions"
  ]
  edge [
    source 1616
    target 1618
    kind "mentions"
  ]
  edge [
    source 1616
    target 1619
    kind "mentions"
  ]
  edge [
    source 1616
    target 1620
    kind "mentions"
  ]
  edge [
    source 1616
    target 1621
    kind "mentions"
  ]
  edge [
    source 1616
    target 2218
    kind "summarizes"
  ]
  edge [
    source 1617
    target 1621
    kind "relation"
    relation "is a chapel folk"
    weight 1
  ]
  edge [
    source 1618
    target 1621
    kind "relation"
    relation "is a chapel folk"
    weight 1
  ]
  edge [
    source 1619
    target 1621
    kind "relation"
    relation "is a chapel folk"
    weight 1
  ]
  edge [
    source 1620
    target 1621
    kind "relation"
    relation "are chapel folk"
    weight 1
  ]
  edge [
    source 1621
    target 1623
    kind "mentions"
  ]
  edge [
    source 1622
    target 1623
    kind "from_chunk"
  ]
  edge [
    source 1623
    target 1624
    kind "mentions"
  ]
  edge [
    source 1623
    target 1625
    kind "mentions"
  ]
  edge [
    source 1623
    target 1626
    kind "mentions"
  ]
  edge [
    source 1623
    target 1627
    kind "mentions"
  ]
  edge [
    source 1623
    target 1628
    kind "mentions"
  ]
  edge [
    source 1623
    target 1629
    kind "mentions"
  ]
  edge [
    source 1623
    target 1630
    kind "mentions"
  ]
  edge [
    source 1623
    target 1631
    kind "mentions"
  ]
  edge [
    source 1623
    target 1632
    kind "mentions"
  ]
  edge [
    source 1623
    target 2218
    kind "summarizes"
  ]
  edge [
    source 1625
    target 1873
    kind "mentions"
  ]
  edge [
    source 1628
    target 2140
    kind "mentions"
  ]
  edge [
    source 1633
    target 1634
    kind "from_chunk"
  ]
  edge [
    source 1633
    target 1651
    kind "from_chunk"
  ]
  edge [
    source 1634
    target 1635
    kind "mentions"
  ]
  edge [
    source 1634
    target 1636
    kind "mentions"
  ]
  edge [
    source 1634
    target 1637
    kind "mentions"
  ]
  edge [
    source 1634
    target 1638
    kind "mentions"
  ]
  edge [
    source 1634
    target 1639
    kind "mentions"
  ]
  edge [
    source 1634
    target 1640
    kind "mentions"
  ]
  edge [
    source 1634
    target 1641
    kind "mentions"
  ]
  edge [
    source 1634
    target 1642
    kind "mentions"
  ]
  edge [
    source 1634
    target 1643
    kind "mentions"
  ]
  edge [
    source 1634
    target 1644
    kind "mentions"
  ]
  edge [
    source 1634
    target 1645
    kind "mentions"
  ]
  edge [
    source 1634
    target 1646
    kind "mentions"
  ]
  edge [
    source 1634
    target 1647
    kind "mentions"
  ]
  edge [
    source 1634
    target 1648
    kind "mentions"
  ]
  edge [
    source 1634
    target 1649
    kind "mentions"
  ]
  edge [
    source 1634
    target 1650
    kind "mentions"
  ]
  edge [
    source 1634
    target 2220
    kind "summarizes"
  ]
  edge [
    source 1635
    target 1636
    kind "relation"
    relation "was formerly a member of"
    weight 1
  ]
  edge [
    source 1637
    target 1643
    kind "relation"
    relation "causes"
    weight 1
  ]
  edge [
    source 1638
    target 1644
    kind "relation"
    relation "is where one turns into"
    weight 1
  ]
  edge [
    source 1638
    target 1926
    kind "mentions"
  ]
  edge [
    source 1638
    target 1930
    kind "relation"
    relation "was bound to go to"
    weight 1
  ]
  edge [
    source 1640
    target 1650
    kind "relation"
    relation "may restore"
    weight 1
  ]
  edge [
    source 1645
    target 1646
    kind "relation"
    relation "followed by"
    weight 1
  ]
  edge [
    source 1646
    target 1647
    kind "relation"
    relation "followed by"
    weight 1
  ]
  edge [
    source 1647
    target 1648
    kind "relation"
    relation "followed by"
    weight 1
  ]
  edge [
    source 1648
    target 1649
    kind "relation"
    relation "leads to"
    weight 1
  ]
  edge [
    source 1651
    target 1652
    kind "mentions"
  ]
  edge [
    source 1651
    target 1653
    kind "mentions"
  ]
  edge [
    source 1651
    target 1654
    kind "mentions"
  ]
  edge [
    source 1651
    target 1655
    kind "mentions"
  ]
  edge [
    source 1651
    target 1656
    kind "mentions"
  ]
  edge [
    source 1651
    target 1657
    kind "mentions"
  ]
  edge [
    source 1651
    target 1658
    kind "mentions"
  ]
  edge [
    source 1651
    target 1659
    kind "mentions"
  ]
  edge [
    source 1651
    target 1660
    kind "mentions"
  ]
  edge [
    source 1651
    target 2220
    kind "summarizes"
  ]
  edge [
    source 1661
    target 1662
    kind "from_chunk"
  ]
  edge [
    source 1662
    target 1663
    kind "mentions"
  ]
  edge [
    source 1662
    target 1664
    kind "mentions"
  ]
  edge [
    source 1662
    target 1665
    kind "mentions"
  ]
  edge [
    source 1662
    target 1666
    kind "mentions"
  ]
  edge [
    source 1662
    target 1667
    kind "mentions"
  ]
  edge [
    source 1662
    target 1668
    kind "mentions"
  ]
  edge [
    source 1662
    target 1669
    kind "mentions"
  ]
  edge [
    source 1662
    target 1670
    kind "mentions"
  ]
  edge [
    source 1662
    target 1671
    kind "mentions"
  ]
  edge [
    source 1662
    target 1672
    kind "mentions"
  ]
  edge [
    source 1662
    target 1673
    kind "mentions"
  ]
  edge [
    source 1662
    target 1674
    kind "mentions"
  ]
  edge [
    source 1662
    target 1675
    kind "mentions"
  ]
  edge [
    source 1662
    target 1676
    kind "mentions"
  ]
  edge [
    source 1662
    target 1677
    kind "mentions"
  ]
  edge [
    source 1662
    target 1678
    kind "mentions"
  ]
  edge [
    source 1662
    target 1679
    kind "mentions"
  ]
  edge [
    source 1662
    target 2218
    kind "summarizes"
  ]
  edge [
    source 1663
    target 1740
    kind "mentions"
  ]
  edge [
    source 1680
    target 1681
    kind "from_chunk"
  ]
  edge [
    source 1681
    target 1682
    kind "mentions"
  ]
  edge [
    source 1681
    target 1683
    kind "mentions"
  ]
  edge [
    source 1681
    target 1684
    kind "mentions"
  ]
  edge [
    source 1681
    target 1685
    kind "mentions"
  ]
  edge [
    source 1681
    target 1686
    kind "mentions"
  ]
  edge [
    source 1681
    target 1687
    kind "mentions"
  ]
  edge [
    source 1681
    target 1688
    kind "mentions"
  ]
  edge [
    source 1681
    target 1689
    kind "mentions"
  ]
  edge [
    source 1681
    target 1690
    kind "mentions"
  ]
  edge [
    source 1681
    target 1691
    kind "mentions"
  ]
  edge [
    source 1681
    target 2240
    kind "summarizes"
  ]
  edge [
    source 1692
    target 1693
    kind "from_chunk"
  ]
  edge [
    source 1693
    target 1694
    kind "mentions"
  ]
  edge [
    source 1693
    target 1695
    kind "mentions"
  ]
  edge [
    source 1693
    target 1696
    kind "mentions"
  ]
  edge [
    source 1693
    target 1697
    kind "mentions"
  ]
  edge [
    source 1693
    target 1698
    kind "mentions"
  ]
  edge [
    source 1693
    target 1699
    kind "mentions"
  ]
  edge [
    source 1693
    target 1700
    kind "mentions"
  ]
  edge [
    source 1693
    target 1701
    kind "mentions"
  ]
  edge [
    source 1693
    target 1702
    kind "mentions"
  ]
  edge [
    source 1693
    target 1703
    kind "mentions"
  ]
  edge [
    source 1693
    target 1704
    kind "mentions"
  ]
  edge [
    source 1693
    target 1705
    kind "mentions"
  ]
  edge [
    source 1693
    target 1706
    kind "mentions"
  ]
  edge [
    source 1693
    target 1707
    kind "mentions"
  ]
  edge [
    source 1693
    target 1708
    kind "mentions"
  ]
  edge [
    source 1693
    target 1709
    kind "mentions"
  ]
  edge [
    source 1693
    target 2237
    kind "summarizes"
  ]
  edge [
    source 1694
    target 1711
    kind "mentions"
  ]
  edge [
    source 1695
    target 1729
    kind "mentions"
  ]
  edge [
    source 1710
    target 1711
    kind "from_chunk"
  ]
  edge [
    source 1711
    target 1712
    kind "mentions"
  ]
  edge [
    source 1711
    target 1713
    kind "mentions"
  ]
  edge [
    source 1711
    target 1714
    kind "mentions"
  ]
  edge [
    source 1711
    target 1715
    kind "mentions"
  ]
  edge [
    source 1711
    target 1716
    kind "mentions"
  ]
  edge [
    source 1711
    target 1717
    kind "mentions"
  ]
  edge [
    source 1711
    target 1718
    kind "mentions"
  ]
  edge [
    source 1711
    target 1719
    kind "mentions"
  ]
  edge [
    source 1711
    target 1720
    kind "mentions"
  ]
  edge [
    source 1711
    target 1721
    kind "mentions"
  ]
  edge [
    source 1711
    target 1722
    kind "mentions"
  ]
  edge [
    source 1711
    target 1723
    kind "mentions"
  ]
  edge [
    source 1711
    target 1724
    kind "mentions"
  ]
  edge [
    source 1711
    target 1725
    kind "mentions"
  ]
  edge [
    source 1711
    target 1726
    kind "mentions"
  ]
  edge [
    source 1711
    target 1727
    kind "mentions"
  ]
  edge [
    source 1711
    target 2237
    kind "summarizes"
  ]
  edge [
    source 1714
    target 1866
    kind "mentions"
  ]
  edge [
    source 1728
    target 1729
    kind "from_chunk"
  ]
  edge [
    source 1729
    target 1730
    kind "mentions"
  ]
  edge [
    source 1729
    target 1731
    kind "mentions"
  ]
  edge [
    source 1729
    target 1732
    kind "mentions"
  ]
  edge [
    source 1729
    target 1733
    kind "mentions"
  ]
  edge [
    source 1729
    target 1734
    kind "mentions"
  ]
  edge [
    source 1729
    target 1735
    kind "mentions"
  ]
  edge [
    source 1729
    target 1736
    kind "mentions"
  ]
  edge [
    source 1729
    target 1737
    kind "mentions"
  ]
  edge [
    source 1729
    target 1738
    kind "mentions"
  ]
  edge [
    source 1729
    target 2224
    kind "summarizes"
  ]
  edge [
    source 1730
    target 1765
    kind "mentions"
  ]
  edge [
    source 1738
    target 1740
    kind "mentions"
  ]
  edge [
    source 1739
    target 1740
    kind "from_chunk"
  ]
  edge [
    source 1740
    target 1741
    kind "mentions"
  ]
  edge [
    source 1740
    target 1742
    kind "mentions"
  ]
  edge [
    source 1740
    target 1743
    kind "mentions"
  ]
  edge [
    source 1740
    target 1744
    kind "mentions"
  ]
  edge [
    source 1740
    target 1745
    kind "mentions"
  ]
  edge [
    source 1740
    target 1746
    kind "mentions"
  ]
  edge [
    source 1740
    target 1747
    kind "mentions"
  ]
  edge [
    source 1740
    target 2224
    kind "summarizes"
  ]
  edge [
    source 1748
    target 1749
    kind "from_chunk"
  ]
  edge [
    source 1749
    target 1750
    kind "mentions"
  ]
  edge [
    source 1749
    target 1751
    kind "mentions"
  ]
  edge [
    source 1749
    target 1752
    kind "mentions"
  ]
  edge [
    source 1749
    target 1753
    kind "mentions"
  ]
  edge [
    source 1749
    target 1754
    kind "mentions"
  ]
  edge [
    source 1749
    target 1755
    kind "mentions"
  ]
  edge [
    source 1749
    target 1756
    kind "mentions"
  ]
  edge [
    source 1749
    target 1757
    kind "mentions"
  ]
  edge [
    source 1749
    target 1758
    kind "mentions"
  ]
  edge [
    source 1749
    target 1759
    kind "mentions"
  ]
  edge [
    source 1749
    target 1760
    kind "mentions"
  ]
  edge [
    source 1749
    target 1761
    kind "mentions"
  ]
  edge [
    source 1749
    target 1762
    kind "mentions"
  ]
  edge [
    source 1749
    target 1763
    kind "mentions"
  ]
  edge [
    source 1749
    target 2236
    kind "summarizes"
  ]
  edge [
    source 1751
    target 1752
    kind "relation"
    relation "are involved"
    weight 1
  ]
  edge [
    source 1764
    target 1765
    kind "from_chunk"
  ]
  edge [
    source 1764
    target 1773
    kind "from_chunk"
  ]
  edge [
    source 1765
    target 1766
    kind "mentions"
  ]
  edge [
    source 1765
    target 1767
    kind "mentions"
  ]
  edge [
    source 1765
    target 1768
    kind "mentions"
  ]
  edge [
    source 1765
    target 1769
    kind "mentions"
  ]
  edge [
    source 1765
    target 1770
    kind "mentions"
  ]
  edge [
    source 1765
    target 1771
    kind "mentions"
  ]
  edge [
    source 1765
    target 1772
    kind "mentions"
  ]
  edge [
    source 1765
    target 2224
    kind "summarizes"
  ]
  edge [
    source 1767
    target 1773
    kind "mentions"
  ]
  edge [
    source 1773
    target 1774
    kind "mentions"
  ]
  edge [
    source 1773
    target 2237
    kind "summarizes"
  ]
  edge [
    source 1774
    target 1776
    kind "mentions"
  ]
  edge [
    source 1775
    target 1776
    kind "from_chunk"
  ]
  edge [
    source 1775
    target 1782
    kind "from_chunk"
  ]
  edge [
    source 1776
    target 1777
    kind "mentions"
  ]
  edge [
    source 1776
    target 1778
    kind "mentions"
  ]
  edge [
    source 1776
    target 1779
    kind "mentions"
  ]
  edge [
    source 1776
    target 1780
    kind "mentions"
  ]
  edge [
    source 1776
    target 1781
    kind "mentions"
  ]
  edge [
    source 1776
    target 2237
    kind "summarizes"
  ]
  edge [
    source 1782
    target 1783
    kind "mentions"
  ]
  edge [
    source 1782
    target 2222
    kind "summarizes"
  ]
  edge [
    source 1784
    target 1785
    kind "from_chunk"
  ]
  edge [
    source 1784
    target 1788
    kind "from_chunk"
  ]
  edge [
    source 1784
    target 1793
    kind "from_chunk"
  ]
  edge [
    source 1784
    target 1798
    kind "from_chunk"
  ]
  edge [
    source 1784
    target 1802
    kind "from_chunk"
  ]
  edge [
    source 1785
    target 1786
    kind "mentions"
  ]
  edge [
    source 1785
    target 1787
    kind "mentions"
  ]
  edge [
    source 1785
    target 2216
    kind "summarizes"
  ]
  edge [
    source 1788
    target 1789
    kind "mentions"
  ]
  edge [
    source 1788
    target 1790
    kind "mentions"
  ]
  edge [
    source 1788
    target 1791
    kind "mentions"
  ]
  edge [
    source 1788
    target 1792
    kind "mentions"
  ]
  edge [
    source 1788
    target 2216
    kind "summarizes"
  ]
  edge [
    source 1793
    target 1794
    kind "mentions"
  ]
  edge [
    source 1793
    target 1795
    kind "mentions"
  ]
  edge [
    source 1793
    target 1796
    kind "mentions"
  ]
  edge [
    source 1793
    target 1797
    kind "mentions"
  ]
  edge [
    source 1793
    target 2222
    kind "summarizes"
  ]
  edge [
    source 1798
    target 1799
    kind "mentions"
  ]
  edge [
    source 1798
    target 1800
    kind "mentions"
  ]
  edge [
    source 1798
    target 1801
    kind "mentions"
  ]
  edge [
    source 1798
    target 2236
    kind "summarizes"
  ]
  edge [
    source 1802
    target 1803
    kind "mentions"
  ]
  edge [
    source 1802
    target 2216
    kind "summarizes"
  ]
  edge [
    source 1803
    target 1805
    kind "mentions"
  ]
  edge [
    source 1804
    target 1805
    kind "from_chunk"
  ]
  edge [
    source 1804
    target 1808
    kind "from_chunk"
  ]
  edge [
    source 1804
    target 1812
    kind "from_chunk"
  ]
  edge [
    source 1804
    target 1817
    kind "from_chunk"
  ]
  edge [
    source 1804
    target 1827
    kind "from_chunk"
  ]
  edge [
    source 1805
    target 1806
    kind "mentions"
  ]
  edge [
    source 1805
    target 1807
    kind "mentions"
  ]
  edge [
    source 1805
    target 2216
    kind "summarizes"
  ]
  edge [
    source 1806
    target 1807
    kind "relation"
    relation "was given to"
    weight 1
  ]
  edge [
    source 1808
    target 1809
    kind "mentions"
  ]
  edge [
    source 1808
    target 1810
    kind "mentions"
  ]
  edge [
    source 1808
    target 1811
    kind "mentions"
  ]
  edge [
    source 1808
    target 2216
    kind "summarizes"
  ]
  edge [
    source 1809
    target 1810
    kind "relation"
    relation "has not yet come home from"
    weight 1
  ]
  edge [
    source 1812
    target 1813
    kind "mentions"
  ]
  edge [
    source 1812
    target 1814
    kind "mentions"
  ]
  edge [
    source 1812
    target 1815
    kind "mentions"
  ]
  edge [
    source 1812
    target 1816
    kind "mentions"
  ]
  edge [
    source 1812
    target 2238
    kind "summarizes"
  ]
  edge [
    source 1817
    target 1818
    kind "mentions"
  ]
  edge [
    source 1817
    target 1819
    kind "mentions"
  ]
  edge [
    source 1817
    target 1820
    kind "mentions"
  ]
  edge [
    source 1817
    target 1821
    kind "mentions"
  ]
  edge [
    source 1817
    target 1822
    kind "mentions"
  ]
  edge [
    source 1817
    target 1823
    kind "mentions"
  ]
  edge [
    source 1817
    target 1824
    kind "mentions"
  ]
  edge [
    source 1817
    target 1825
    kind "mentions"
  ]
  edge [
    source 1817
    target 1826
    kind "mentions"
  ]
  edge [
    source 1817
    target 2223
    kind "summarizes"
  ]
  edge [
    source 1818
    target 1824
    kind "relation"
    relation "is charged with"
    weight 1
  ]
  edge [
    source 1818
    target 2125
    kind "mentions"
  ]
  edge [
    source 1827
    target 1828
    kind "mentions"
  ]
  edge [
    source 1827
    target 1829
    kind "mentions"
  ]
  edge [
    source 1827
    target 1830
    kind "mentions"
  ]
  edge [
    source 1827
    target 1831
    kind "mentions"
  ]
  edge [
    source 1827
    target 2237
    kind "summarizes"
  ]
  edge [
    source 1832
    target 1833
    kind "from_chunk"
  ]
  edge [
    source 1832
    target 1848
    kind "from_chunk"
  ]
  edge [
    source 1833
    target 1834
    kind "mentions"
  ]
  edge [
    source 1833
    target 1835
    kind "mentions"
  ]
  edge [
    source 1833
    target 1836
    kind "mentions"
  ]
  edge [
    source 1833
    target 1837
    kind "mentions"
  ]
  edge [
    source 1833
    target 1838
    kind "mentions"
  ]
  edge [
    source 1833
    target 1839
    kind "mentions"
  ]
  edge [
    source 1833
    target 1840
    kind "mentions"
  ]
  edge [
    source 1833
    target 1841
    kind "mentions"
  ]
  edge [
    source 1833
    target 1842
    kind "mentions"
  ]
  edge [
    source 1833
    target 1843
    kind "mentions"
  ]
  edge [
    source 1833
    target 1844
    kind "mentions"
  ]
  edge [
    source 1833
    target 1845
    kind "mentions"
  ]
  edge [
    source 1833
    target 1846
    kind "mentions"
  ]
  edge [
    source 1833
    target 1847
    kind "mentions"
  ]
  edge [
    source 1833
    target 2240
    kind "summarizes"
  ]
  edge [
    source 1835
    target 1848
    kind "mentions"
  ]
  edge [
    source 1838
    target 1926
    kind "mentions"
  ]
  edge [
    source 1848
    target 1849
    kind "mentions"
  ]
  edge [
    source 1848
    target 2240
    kind "summarizes"
  ]
  edge [
    source 1850
    target 1851
    kind "from_chunk"
  ]
  edge [
    source 1850
    target 1856
    kind "from_chunk"
  ]
  edge [
    source 1851
    target 1852
    kind "mentions"
  ]
  edge [
    source 1851
    target 1853
    kind "mentions"
  ]
  edge [
    source 1851
    target 1854
    kind "mentions"
  ]
  edge [
    source 1851
    target 1855
    kind "mentions"
  ]
  edge [
    source 1851
    target 2235
    kind "summarizes"
  ]
  edge [
    source 1856
    target 2235
    kind "summarizes"
  ]
  edge [
    source 1857
    target 1858
    kind "from_chunk"
  ]
  edge [
    source 1857
    target 1864
    kind "from_chunk"
  ]
  edge [
    source 1858
    target 1859
    kind "mentions"
  ]
  edge [
    source 1858
    target 1860
    kind "mentions"
  ]
  edge [
    source 1858
    target 1861
    kind "mentions"
  ]
  edge [
    source 1858
    target 1862
    kind "mentions"
  ]
  edge [
    source 1858
    target 1863
    kind "mentions"
  ]
  edge [
    source 1858
    target 2215
    kind "summarizes"
  ]
  edge [
    source 1861
    target 1864
    kind "mentions"
  ]
  edge [
    source 1864
    target 2215
    kind "summarizes"
  ]
  edge [
    source 1865
    target 1866
    kind "from_chunk"
  ]
  edge [
    source 1865
    target 1869
    kind "from_chunk"
  ]
  edge [
    source 1865
    target 1873
    kind "from_chunk"
  ]
  edge [
    source 1866
    target 1867
    kind "mentions"
  ]
  edge [
    source 1866
    target 1868
    kind "mentions"
  ]
  edge [
    source 1866
    target 2217
    kind "summarizes"
  ]
  edge [
    source 1867
    target 1869
    kind "mentions"
  ]
  edge [
    source 1867
    target 1870
    kind "relation"
    relation "diagnosed that unless proposed to and accepted"
    weight 1
  ]
  edge [
    source 1869
    target 1870
    kind "mentions"
  ]
  edge [
    source 1869
    target 1871
    kind "mentions"
  ]
  edge [
    source 1869
    target 1872
    kind "mentions"
  ]
  edge [
    source 1869
    target 2215
    kind "summarizes"
  ]
  edge [
    source 1873
    target 2217
    kind "summarizes"
  ]
  edge [
    source 1874
    target 1875
    kind "from_chunk"
  ]
  edge [
    source 1874
    target 1880
    kind "from_chunk"
  ]
  edge [
    source 1875
    target 1876
    kind "mentions"
  ]
  edge [
    source 1875
    target 1877
    kind "mentions"
  ]
  edge [
    source 1875
    target 1878
    kind "mentions"
  ]
  edge [
    source 1875
    target 1879
    kind "mentions"
  ]
  edge [
    source 1875
    target 2215
    kind "summarizes"
  ]
  edge [
    source 1880
    target 1881
    kind "mentions"
  ]
  edge [
    source 1880
    target 1882
    kind "mentions"
  ]
  edge [
    source 1880
    target 2219
    kind "summarizes"
  ]
  edge [
    source 1883
    target 1884
    kind "from_chunk"
  ]
  edge [
    source 1883
    target 1887
    kind "from_chunk"
  ]
  edge [
    source 1883
    target 1891
    kind "from_chunk"
  ]
  edge [
    source 1883
    target 1893
    kind "from_chunk"
  ]
  edge [
    source 1884
    target 1885
    kind "mentions"
  ]
  edge [
    source 1884
    target 1886
    kind "mentions"
  ]
  edge [
    source 1884
    target 2216
    kind "summarizes"
  ]
  edge [
    source 1887
    target 1888
    kind "mentions"
  ]
  edge [
    source 1887
    target 1889
    kind "mentions"
  ]
  edge [
    source 1887
    target 1890
    kind "mentions"
  ]
  edge [
    source 1887
    target 2229
    kind "summarizes"
  ]
  edge [
    source 1890
    target 1891
    kind "mentions"
  ]
  edge [
    source 1891
    target 1892
    kind "mentions"
  ]
  edge [
    source 1891
    target 2229
    kind "summarizes"
  ]
  edge [
    source 1893
    target 1894
    kind "mentions"
  ]
  edge [
    source 1893
    target 1895
    kind "mentions"
  ]
  edge [
    source 1893
    target 1896
    kind "mentions"
  ]
  edge [
    source 1893
    target 1897
    kind "mentions"
  ]
  edge [
    source 1893
    target 2228
    kind "summarizes"
  ]
  edge [
    source 1895
    target 1899
    kind "mentions"
  ]
  edge [
    source 1898
    target 1899
    kind "from_chunk"
  ]
  edge [
    source 1898
    target 1906
    kind "from_chunk"
  ]
  edge [
    source 1898
    target 1911
    kind "from_chunk"
  ]
  edge [
    source 1898
    target 1917
    kind "from_chunk"
  ]
  edge [
    source 1899
    target 1900
    kind "mentions"
  ]
  edge [
    source 1899
    target 1901
    kind "mentions"
  ]
  edge [
    source 1899
    target 1902
    kind "mentions"
  ]
  edge [
    source 1899
    target 1903
    kind "mentions"
  ]
  edge [
    source 1899
    target 1904
    kind "mentions"
  ]
  edge [
    source 1899
    target 1905
    kind "mentions"
  ]
  edge [
    source 1899
    target 2228
    kind "summarizes"
  ]
  edge [
    source 1904
    target 1905
    kind "relation"
    relation "appear to have recently engaged in"
    weight 1
  ]
  edge [
    source 1904
    target 1911
    kind "mentions"
  ]
  edge [
    source 1904
    target 1913
    kind "relation"
    relation "respond quietly with"
    weight 1
  ]
  edge [
    source 1906
    target 1907
    kind "mentions"
  ]
  edge [
    source 1906
    target 1908
    kind "mentions"
  ]
  edge [
    source 1906
    target 1909
    kind "mentions"
  ]
  edge [
    source 1906
    target 1910
    kind "mentions"
  ]
  edge [
    source 1906
    target 2226
    kind "summarizes"
  ]
  edge [
    source 1911
    target 1912
    kind "mentions"
  ]
  edge [
    source 1911
    target 1913
    kind "mentions"
  ]
  edge [
    source 1911
    target 1914
    kind "mentions"
  ]
  edge [
    source 1911
    target 1915
    kind "mentions"
  ]
  edge [
    source 1911
    target 1916
    kind "mentions"
  ]
  edge [
    source 1911
    target 2228
    kind "summarizes"
  ]
  edge [
    source 1917
    target 1918
    kind "mentions"
  ]
  edge [
    source 1917
    target 1919
    kind "mentions"
  ]
  edge [
    source 1917
    target 1920
    kind "mentions"
  ]
  edge [
    source 1917
    target 1921
    kind "mentions"
  ]
  edge [
    source 1917
    target 1922
    kind "mentions"
  ]
  edge [
    source 1917
    target 1923
    kind "mentions"
  ]
  edge [
    source 1917
    target 1924
    kind "mentions"
  ]
  edge [
    source 1917
    target 2228
    kind "summarizes"
  ]
  edge [
    source 1925
    target 1926
    kind "from_chunk"
  ]
  edge [
    source 1926
    target 1927
    kind "mentions"
  ]
  edge [
    source 1926
    target 1928
    kind "mentions"
  ]
  edge [
    source 1926
    target 1929
    kind "mentions"
  ]
  edge [
    source 1926
    target 1930
    kind "mentions"
  ]
  edge [
    source 1926
    target 1931
    kind "mentions"
  ]
  edge [
    source 1926
    target 1932
    kind "mentions"
  ]
  edge [
    source 1926
    target 1933
    kind "mentions"
  ]
  edge [
    source 1926
    target 1934
    kind "mentions"
  ]
  edge [
    source 1926
    target 1935
    kind "mentions"
  ]
  edge [
    source 1926
    target 1936
    kind "mentions"
  ]
  edge [
    source 1926
    target 2220
    kind "summarizes"
  ]
  edge [
    source 1930
    target 1934
    kind "relation"
    relation "was bound to go to"
    weight 1
  ]
  edge [
    source 1937
    target 1938
    kind "from_chunk"
  ]
  edge [
    source 1937
    target 1940
    kind "from_chunk"
  ]
  edge [
    source 1937
    target 1946
    kind "from_chunk"
  ]
  edge [
    source 1938
    target 1939
    kind "mentions"
  ]
  edge [
    source 1938
    target 2220
    kind "summarizes"
  ]
  edge [
    source 1940
    target 1941
    kind "mentions"
  ]
  edge [
    source 1940
    target 1942
    kind "mentions"
  ]
  edge [
    source 1940
    target 1943
    kind "mentions"
  ]
  edge [
    source 1940
    target 1944
    kind "mentions"
  ]
  edge [
    source 1940
    target 1945
    kind "mentions"
  ]
  edge [
    source 1940
    target 2220
    kind "summarizes"
  ]
  edge [
    source 1943
    target 1945
    kind "relation"
    relation "responds with"
    weight 1
  ]
  edge [
    source 1946
    target 1947
    kind "mentions"
  ]
  edge [
    source 1946
    target 1948
    kind "mentions"
  ]
  edge [
    source 1946
    target 1949
    kind "mentions"
  ]
  edge [
    source 1946
    target 1950
    kind "mentions"
  ]
  edge [
    source 1946
    target 1951
    kind "mentions"
  ]
  edge [
    source 1946
    target 1952
    kind "mentions"
  ]
  edge [
    source 1946
    target 1953
    kind "mentions"
  ]
  edge [
    source 1946
    target 2220
    kind "summarizes"
  ]
  edge [
    source 1947
    target 1948
    kind "relation"
    relation "is accused of"
    weight 1
  ]
  edge [
    source 1947
    target 1949
    kind "relation"
    relation "will be at"
    weight 1
  ]
  edge [
    source 1954
    target 1955
    kind "from_chunk"
  ]
  edge [
    source 1954
    target 1960
    kind "from_chunk"
  ]
  edge [
    source 1954
    target 1965
    kind "from_chunk"
  ]
  edge [
    source 1954
    target 1968
    kind "from_chunk"
  ]
  edge [
    source 1955
    target 1956
    kind "mentions"
  ]
  edge [
    source 1955
    target 1957
    kind "mentions"
  ]
  edge [
    source 1955
    target 1958
    kind "mentions"
  ]
  edge [
    source 1955
    target 1959
    kind "mentions"
  ]
  edge [
    source 1955
    target 2228
    kind "summarizes"
  ]
  edge [
    source 1960
    target 1961
    kind "mentions"
  ]
  edge [
    source 1960
    target 1962
    kind "mentions"
  ]
  edge [
    source 1960
    target 1963
    kind "mentions"
  ]
  edge [
    source 1960
    target 1964
    kind "mentions"
  ]
  edge [
    source 1960
    target 2232
    kind "summarizes"
  ]
  edge [
    source 1965
    target 1966
    kind "mentions"
  ]
  edge [
    source 1965
    target 1967
    kind "mentions"
  ]
  edge [
    source 1965
    target 2226
    kind "summarizes"
  ]
  edge [
    source 1967
    target 1968
    kind "mentions"
  ]
  edge [
    source 1968
    target 2226
    kind "summarizes"
  ]
  edge [
    source 1969
    target 1970
    kind "from_chunk"
  ]
  edge [
    source 1969
    target 1974
    kind "from_chunk"
  ]
  edge [
    source 1970
    target 1971
    kind "mentions"
  ]
  edge [
    source 1970
    target 1972
    kind "mentions"
  ]
  edge [
    source 1970
    target 1973
    kind "mentions"
  ]
  edge [
    source 1970
    target 2221
    kind "summarizes"
  ]
  edge [
    source 1972
    target 1973
    kind "relation"
    relation "has humane author"
    weight 1
  ]
  edge [
    source 1974
    target 1975
    kind "mentions"
  ]
  edge [
    source 1974
    target 1976
    kind "mentions"
  ]
  edge [
    source 1974
    target 2223
    kind "summarizes"
  ]
  edge [
    source 1975
    target 1989
    kind "mentions"
  ]
  edge [
    source 1975
    target 1995
    kind "relation"
    relation "was not placed in"
    weight 1
  ]
  edge [
    source 1976
    target 1978
    kind "mentions"
  ]
  edge [
    source 1976
    target 1979
    kind "relation"
    relation "are part of"
    weight 1
  ]
  edge [
    source 1977
    target 1978
    kind "from_chunk"
  ]
  edge [
    source 1977
    target 1980
    kind "from_chunk"
  ]
  edge [
    source 1977
    target 1983
    kind "from_chunk"
  ]
  edge [
    source 1977
    target 1989
    kind "from_chunk"
  ]
  edge [
    source 1977
    target 1996
    kind "from_chunk"
  ]
  edge [
    source 1978
    target 1979
    kind "mentions"
  ]
  edge [
    source 1978
    target 2223
    kind "summarizes"
  ]
  edge [
    source 1980
    target 1981
    kind "mentions"
  ]
  edge [
    source 1980
    target 1982
    kind "mentions"
  ]
  edge [
    source 1980
    target 2222
    kind "summarizes"
  ]
  edge [
    source 1983
    target 1984
    kind "mentions"
  ]
  edge [
    source 1983
    target 1985
    kind "mentions"
  ]
  edge [
    source 1983
    target 1986
    kind "mentions"
  ]
  edge [
    source 1983
    target 1987
    kind "mentions"
  ]
  edge [
    source 1983
    target 1988
    kind "mentions"
  ]
  edge [
    source 1983
    target 2226
    kind "summarizes"
  ]
  edge [
    source 1984
    target 1985
    kind "relation"
    relation "was given from"
    weight 1
  ]
  edge [
    source 1986
    target 1988
    kind "relation"
    relation "is described as"
    weight 1
  ]
  edge [
    source 1989
    target 1990
    kind "mentions"
  ]
  edge [
    source 1989
    target 1991
    kind "mentions"
  ]
  edge [
    source 1989
    target 1992
    kind "mentions"
  ]
  edge [
    source 1989
    target 1993
    kind "mentions"
  ]
  edge [
    source 1989
    target 1994
    kind "mentions"
  ]
  edge [
    source 1989
    target 1995
    kind "mentions"
  ]
  edge [
    source 1989
    target 2223
    kind "summarizes"
  ]
  edge [
    source 1990
    target 2192
    kind "mentions"
  ]
  edge [
    source 1996
    target 1997
    kind "mentions"
  ]
  edge [
    source 1996
    target 1998
    kind "mentions"
  ]
  edge [
    source 1996
    target 1999
    kind "mentions"
  ]
  edge [
    source 1996
    target 2000
    kind "mentions"
  ]
  edge [
    source 1996
    target 2215
    kind "summarizes"
  ]
  edge [
    source 2001
    target 2002
    kind "from_chunk"
  ]
  edge [
    source 2001
    target 2008
    kind "from_chunk"
  ]
  edge [
    source 2002
    target 2003
    kind "mentions"
  ]
  edge [
    source 2002
    target 2004
    kind "mentions"
  ]
  edge [
    source 2002
    target 2005
    kind "mentions"
  ]
  edge [
    source 2002
    target 2006
    kind "mentions"
  ]
  edge [
    source 2002
    target 2007
    kind "mentions"
  ]
  edge [
    source 2002
    target 2231
    kind "summarizes"
  ]
  edge [
    source 2003
    target 2013
    kind "mentions"
  ]
  edge [
    source 2003
    target 2017
    kind "relation"
    relation "is a document stating"
    weight 1
  ]
  edge [
    source 2003
    target 2018
    kind "mentions"
  ]
  edge [
    source 2005
    target 2006
    kind "relation"
    relation "led to"
    weight 1
  ]
  edge [
    source 2008
    target 2009
    kind "mentions"
  ]
  edge [
    source 2008
    target 2010
    kind "mentions"
  ]
  edge [
    source 2008
    target 2011
    kind "mentions"
  ]
  edge [
    source 2008
    target 2216
    kind "summarizes"
  ]
  edge [
    source 2012
    target 2013
    kind "from_chunk"
  ]
  edge [
    source 2012
    target 2018
    kind "from_chunk"
  ]
  edge [
    source 2013
    target 2014
    kind "mentions"
  ]
  edge [
    source 2013
    target 2015
    kind "mentions"
  ]
  edge [
    source 2013
    target 2016
    kind "mentions"
  ]
  edge [
    source 2013
    target 2017
    kind "mentions"
  ]
  edge [
    source 2013
    target 2231
    kind "summarizes"
  ]
  edge [
    source 2014
    target 2018
    kind "mentions"
  ]
  edge [
    source 2015
    target 2018
    kind "mentions"
  ]
  edge [
    source 2016
    target 2018
    kind "mentions"
  ]
  edge [
    source 2018
    target 2231
    kind "summarizes"
  ]
  edge [
    source 2019
    target 2020
    kind "from_chunk"
  ]
  edge [
    source 2020
    target 2021
    kind "mentions"
  ]
  edge [
    source 2020
    target 2022
    kind "mentions"
  ]
  edge [
    source 2020
    target 2023
    kind "mentions"
  ]
  edge [
    source 2020
    target 2024
    kind "mentions"
  ]
  edge [
    source 2020
    target 2025
    kind "mentions"
  ]
  edge [
    source 2020
    target 2026
    kind "mentions"
  ]
  edge [
    source 2020
    target 2027
    kind "mentions"
  ]
  edge [
    source 2020
    target 2028
    kind "mentions"
  ]
  edge [
    source 2020
    target 2029
    kind "mentions"
  ]
  edge [
    source 2020
    target 2030
    kind "mentions"
  ]
  edge [
    source 2020
    target 2031
    kind "mentions"
  ]
  edge [
    source 2020
    target 2032
    kind "mentions"
  ]
  edge [
    source 2020
    target 2033
    kind "mentions"
  ]
  edge [
    source 2020
    target 2034
    kind "mentions"
  ]
  edge [
    source 2020
    target 2035
    kind "mentions"
  ]
  edge [
    source 2020
    target 2232
    kind "summarizes"
  ]
  edge [
    source 2036
    target 2037
    kind "from_chunk"
  ]
  edge [
    source 2036
    target 2040
    kind "from_chunk"
  ]
  edge [
    source 2036
    target 2043
    kind "from_chunk"
  ]
  edge [
    source 2036
    target 2044
    kind "from_chunk"
  ]
  edge [
    source 2036
    target 2046
    kind "from_chunk"
  ]
  edge [
    source 2037
    target 2038
    kind "mentions"
  ]
  edge [
    source 2037
    target 2039
    kind "mentions"
  ]
  edge [
    source 2037
    target 2221
    kind "summarizes"
  ]
  edge [
    source 2040
    target 2041
    kind "mentions"
  ]
  edge [
    source 2040
    target 2042
    kind "mentions"
  ]
  edge [
    source 2040
    target 2221
    kind "summarizes"
  ]
  edge [
    source 2041
    target 2042
    kind "relation"
    relation "discharged | did so for the first time in their lives"
    weight 2
  ]
  edge [
    source 2043
    target 2228
    kind "summarizes"
  ]
  edge [
    source 2044
    target 2045
    kind "mentions"
  ]
  edge [
    source 2044
    target 2238
    kind "summarizes"
  ]
  edge [
    source 2046
    target 2214
    kind "summarizes"
  ]
  edge [
    source 2047
    target 2048
    kind "from_chunk"
  ]
  edge [
    source 2048
    target 2049
    kind "mentions"
  ]
  edge [
    source 2048
    target 2050
    kind "mentions"
  ]
  edge [
    source 2048
    target 2051
    kind "mentions"
  ]
  edge [
    source 2048
    target 2052
    kind "mentions"
  ]
  edge [
    source 2048
    target 2053
    kind "mentions"
  ]
  edge [
    source 2048
    target 2054
    kind "mentions"
  ]
  edge [
    source 2048
    target 2055
    kind "mentions"
  ]
  edge [
    source 2048
    target 2056
    kind "mentions"
  ]
  edge [
    source 2048
    target 2057
    kind "mentions"
  ]
  edge [
    source 2048
    target 2058
    kind "mentions"
  ]
  edge [
    source 2048
    target 2059
    kind "mentions"
  ]
  edge [
    source 2048
    target 2060
    kind "mentions"
  ]
  edge [
    source 2048
    target 2061
    kind "mentions"
  ]
  edge [
    source 2048
    target 2062
    kind "mentions"
  ]
  edge [
    source 2048
    target 2063
    kind "mentions"
  ]
  edge [
    source 2048
    target 2064
    kind "mentions"
  ]
  edge [
    source 2048
    target 2065
    kind "mentions"
  ]
  edge [
    source 2048
    target 2219
    kind "summarizes"
  ]
  edge [
    source 2064
    target 2065
    kind "relation"
    relation "state"
    weight 1
  ]
  edge [
    source 2066
    target 2067
    kind "from_chunk"
  ]
  edge [
    source 2067
    target 2068
    kind "mentions"
  ]
  edge [
    source 2067
    target 2069
    kind "mentions"
  ]
  edge [
    source 2067
    target 2070
    kind "mentions"
  ]
  edge [
    source 2067
    target 2071
    kind "mentions"
  ]
  edge [
    source 2067
    target 2072
    kind "mentions"
  ]
  edge [
    source 2067
    target 2073
    kind "mentions"
  ]
  edge [
    source 2067
    target 2074
    kind "mentions"
  ]
  edge [
    source 2067
    target 2075
    kind "mentions"
  ]
  edge [
    source 2067
    target 2234
    kind "summarizes"
  ]
  edge [
    source 2076
    target 2077
    kind "from_chunk"
  ]
  edge [
    source 2076
    target 2086
    kind "from_chunk"
  ]
  edge [
    source 2077
    target 2078
    kind "mentions"
  ]
  edge [
    source 2077
    target 2079
    kind "mentions"
  ]
  edge [
    source 2077
    target 2080
    kind "mentions"
  ]
  edge [
    source 2077
    target 2081
    kind "mentions"
  ]
  edge [
    source 2077
    target 2082
    kind "mentions"
  ]
  edge [
    source 2077
    target 2083
    kind "mentions"
  ]
  edge [
    source 2077
    target 2084
    kind "mentions"
  ]
  edge [
    source 2077
    target 2085
    kind "mentions"
  ]
  edge [
    source 2077
    target 2227
    kind "summarizes"
  ]
  edge [
    source 2086
    target 2087
    kind "mentions"
  ]
  edge [
    source 2086
    target 2088
    kind "mentions"
  ]
  edge [
    source 2086
    target 2089
    kind "mentions"
  ]
  edge [
    source 2086
    target 2090
    kind "mentions"
  ]
  edge [
    source 2086
    target 2091
    kind "mentions"
  ]
  edge [
    source 2086
    target 2092
    kind "mentions"
  ]
  edge [
    source 2086
    target 2093
    kind "mentions"
  ]
  edge [
    source 2086
    target 2094
    kind "mentions"
  ]
  edge [
    source 2086
    target 2095
    kind "mentions"
  ]
  edge [
    source 2086
    target 2096
    kind "mentions"
  ]
  edge [
    source 2086
    target 2215
    kind "summarizes"
  ]
  edge [
    source 2088
    target 2140
    kind "mentions"
  ]
  edge [
    source 2097
    target 2098
    kind "from_chunk"
  ]
  edge [
    source 2097
    target 2104
    kind "from_chunk"
  ]
  edge [
    source 2097
    target 2115
    kind "from_chunk"
  ]
  edge [
    source 2098
    target 2099
    kind "mentions"
  ]
  edge [
    source 2098
    target 2100
    kind "mentions"
  ]
  edge [
    source 2098
    target 2101
    kind "mentions"
  ]
  edge [
    source 2098
    target 2102
    kind "mentions"
  ]
  edge [
    source 2098
    target 2103
    kind "mentions"
  ]
  edge [
    source 2098
    target 2233
    kind "summarizes"
  ]
  edge [
    source 2104
    target 2105
    kind "mentions"
  ]
  edge [
    source 2104
    target 2106
    kind "mentions"
  ]
  edge [
    source 2104
    target 2107
    kind "mentions"
  ]
  edge [
    source 2104
    target 2108
    kind "mentions"
  ]
  edge [
    source 2104
    target 2109
    kind "mentions"
  ]
  edge [
    source 2104
    target 2110
    kind "mentions"
  ]
  edge [
    source 2104
    target 2111
    kind "mentions"
  ]
  edge [
    source 2104
    target 2112
    kind "mentions"
  ]
  edge [
    source 2104
    target 2113
    kind "mentions"
  ]
  edge [
    source 2104
    target 2114
    kind "mentions"
  ]
  edge [
    source 2104
    target 2218
    kind "summarizes"
  ]
  edge [
    source 2115
    target 2116
    kind "mentions"
  ]
  edge [
    source 2115
    target 2215
    kind "summarizes"
  ]
  edge [
    source 2117
    target 2118
    kind "from_chunk"
  ]
  edge [
    source 2117
    target 2120
    kind "from_chunk"
  ]
  edge [
    source 2117
    target 2122
    kind "from_chunk"
  ]
  edge [
    source 2118
    target 2119
    kind "mentions"
  ]
  edge [
    source 2118
    target 2224
    kind "summarizes"
  ]
  edge [
    source 2120
    target 2121
    kind "mentions"
  ]
  edge [
    source 2120
    target 2240
    kind "summarizes"
  ]
  edge [
    source 2122
    target 2123
    kind "mentions"
  ]
  edge [
    source 2122
    target 2221
    kind "summarizes"
  ]
  edge [
    source 2124
    target 2125
    kind "from_chunk"
  ]
  edge [
    source 2124
    target 2126
    kind "from_chunk"
  ]
  edge [
    source 2124
    target 2133
    kind "from_chunk"
  ]
  edge [
    source 2125
    target 2223
    kind "summarizes"
  ]
  edge [
    source 2126
    target 2127
    kind "mentions"
  ]
  edge [
    source 2126
    target 2128
    kind "mentions"
  ]
  edge [
    source 2126
    target 2129
    kind "mentions"
  ]
  edge [
    source 2126
    target 2130
    kind "mentions"
  ]
  edge [
    source 2126
    target 2131
    kind "mentions"
  ]
  edge [
    source 2126
    target 2132
    kind "mentions"
  ]
  edge [
    source 2126
    target 2239
    kind "summarizes"
  ]
  edge [
    source 2133
    target 2134
    kind "mentions"
  ]
  edge [
    source 2133
    target 2135
    kind "mentions"
  ]
  edge [
    source 2133
    target 2136
    kind "mentions"
  ]
  edge [
    source 2133
    target 2137
    kind "mentions"
  ]
  edge [
    source 2133
    target 2138
    kind "mentions"
  ]
  edge [
    source 2133
    target 2214
    kind "summarizes"
  ]
  edge [
    source 2139
    target 2140
    kind "from_chunk"
  ]
  edge [
    source 2139
    target 2143
    kind "from_chunk"
  ]
  edge [
    source 2139
    target 2146
    kind "from_chunk"
  ]
  edge [
    source 2139
    target 2150
    kind "from_chunk"
  ]
  edge [
    source 2140
    target 2141
    kind "mentions"
  ]
  edge [
    source 2140
    target 2142
    kind "mentions"
  ]
  edge [
    source 2140
    target 2222
    kind "summarizes"
  ]
  edge [
    source 2143
    target 2144
    kind "mentions"
  ]
  edge [
    source 2143
    target 2145
    kind "mentions"
  ]
  edge [
    source 2143
    target 2234
    kind "summarizes"
  ]
  edge [
    source 2146
    target 2147
    kind "mentions"
  ]
  edge [
    source 2146
    target 2148
    kind "mentions"
  ]
  edge [
    source 2146
    target 2149
    kind "mentions"
  ]
  edge [
    source 2146
    target 2222
    kind "summarizes"
  ]
  edge [
    source 2150
    target 2218
    kind "summarizes"
  ]
  edge [
    source 2151
    target 2152
    kind "from_chunk"
  ]
  edge [
    source 2152
    target 2153
    kind "mentions"
  ]
  edge [
    source 2152
    target 2154
    kind "mentions"
  ]
  edge [
    source 2152
    target 2155
    kind "mentions"
  ]
  edge [
    source 2152
    target 2156
    kind "mentions"
  ]
  edge [
    source 2152
    target 2157
    kind "mentions"
  ]
  edge [
    source 2152
    target 2158
    kind "mentions"
  ]
  edge [
    source 2152
    target 2159
    kind "mentions"
  ]
  edge [
    source 2152
    target 2218
    kind "summarizes"
  ]
  edge [
    source 2155
    target 2159
    kind "relation"
    relation "is expected to laugh at"
    weight 1
  ]
  edge [
    source 2160
    target 2161
    kind "from_chunk"
  ]
  edge [
    source 2160
    target 2166
    kind "from_chunk"
  ]
  edge [
    source 2160
    target 2170
    kind "from_chunk"
  ]
  edge [
    source 2160
    target 2174
    kind "from_chunk"
  ]
  edge [
    source 2160
    target 2179
    kind "from_chunk"
  ]
  edge [
    source 2160
    target 2184
    kind "from_chunk"
  ]
  edge [
    source 2160
    target 2188
    kind "from_chunk"
  ]
  edge [
    source 2160
    target 2192
    kind "from_chunk"
  ]
  edge [
    source 2160
    target 2194
    kind "from_chunk"
  ]
  edge [
    source 2160
    target 2199
    kind "from_chunk"
  ]
  edge [
    source 2161
    target 2162
    kind "mentions"
  ]
  edge [
    source 2161
    target 2163
    kind "mentions"
  ]
  edge [
    source 2161
    target 2164
    kind "mentions"
  ]
  edge [
    source 2161
    target 2165
    kind "mentions"
  ]
  edge [
    source 2161
    target 2223
    kind "summarizes"
  ]
  edge [
    source 2162
    target 2163
    kind "relation"
    relation "has an apostrophe in"
    weight 1
  ]
  edge [
    source 2162
    target 2165
    kind "relation"
    relation "lacks apostrophe in"
    weight 1
  ]
  edge [
    source 2164
    target 2165
    kind "relation"
    relation "was removed in"
    weight 1
  ]
  edge [
    source 2166
    target 2167
    kind "mentions"
  ]
  edge [
    source 2166
    target 2168
    kind "mentions"
  ]
  edge [
    source 2166
    target 2169
    kind "mentions"
  ]
  edge [
    source 2166
    target 2217
    kind "summarizes"
  ]
  edge [
    source 2167
    target 2168
    kind "relation"
    relation "has"
    weight 1
  ]
  edge [
    source 2168
    target 2169
    kind "relation"
    relation "was added to"
    weight 1
  ]
  edge [
    source 2170
    target 2171
    kind "mentions"
  ]
  edge [
    source 2170
    target 2172
    kind "mentions"
  ]
  edge [
    source 2170
    target 2173
    kind "mentions"
  ]
  edge [
    source 2170
    target 2232
    kind "summarizes"
  ]
  edge [
    source 2171
    target 2172
    kind "relation"
    relation "has changed"
    weight 1
  ]
  edge [
    source 2172
    target 2173
    kind "relation"
    relation "was changed to"
    weight 1
  ]
  edge [
    source 2174
    target 2175
    kind "mentions"
  ]
  edge [
    source 2174
    target 2176
    kind "mentions"
  ]
  edge [
    source 2174
    target 2177
    kind "mentions"
  ]
  edge [
    source 2174
    target 2178
    kind "mentions"
  ]
  edge [
    source 2174
    target 2219
    kind "summarizes"
  ]
  edge [
    source 2175
    target 2177
    kind "relation"
    relation "has changed"
    weight 1
  ]
  edge [
    source 2177
    target 2178
    kind "relation"
    relation "was changed to"
    weight 1
  ]
  edge [
    source 2178
    target 2179
    kind "mentions"
  ]
  edge [
    source 2178
    target 2180
    kind "relation"
    relation "has changed"
    weight 1
  ]
  edge [
    source 2178
    target 2183
    kind "relation"
    relation "was changed to"
    weight 3
  ]
  edge [
    source 2178
    target 2184
    kind "mentions"
  ]
  edge [
    source 2178
    target 2185
    kind "relation"
    relation "has changed"
    weight 1
  ]
  edge [
    source 2178
    target 2192
    kind "mentions"
  ]
  edge [
    source 2178
    target 2193
    kind "relation"
    relation "has changed"
    weight 1
  ]
  edge [
    source 2179
    target 2180
    kind "mentions"
  ]
  edge [
    source 2179
    target 2181
    kind "mentions"
  ]
  edge [
    source 2179
    target 2182
    kind "mentions"
  ]
  edge [
    source 2179
    target 2183
    kind "mentions"
  ]
  edge [
    source 2179
    target 2223
    kind "summarizes"
  ]
  edge [
    source 2181
    target 2182
    kind "relation"
    relation "followed by"
    weight 1
  ]
  edge [
    source 2183
    target 2184
    kind "mentions"
  ]
  edge [
    source 2183
    target 2192
    kind "mentions"
  ]
  edge [
    source 2184
    target 2185
    kind "mentions"
  ]
  edge [
    source 2184
    target 2186
    kind "mentions"
  ]
  edge [
    source 2184
    target 2187
    kind "mentions"
  ]
  edge [
    source 2184
    target 2223
    kind "summarizes"
  ]
  edge [
    source 2186
    target 2187
    kind "relation"
    relation "followed by"
    weight 1
  ]
  edge [
    source 2188
    target 2189
    kind "mentions"
  ]
  edge [
    source 2188
    target 2190
    kind "mentions"
  ]
  edge [
    source 2188
    target 2191
    kind "mentions"
  ]
  edge [
    source 2188
    target 2223
    kind "summarizes"
  ]
  edge [
    source 2190
    target 2191
    kind "relation"
    relation "was changed to"
    weight 1
  ]
  edge [
    source 2192
    target 2193
    kind "mentions"
  ]
  edge [
    source 2192
    target 2223
    kind "summarizes"
  ]
  edge [
    source 2194
    target 2195
    kind "mentions"
  ]
  edge [
    source 2194
    target 2196
    kind "mentions"
  ]
  edge [
    source 2194
    target 2197
    kind "mentions"
  ]
  edge [
    source 2194
    target 2198
    kind "mentions"
  ]
  edge [
    source 2194
    target 2223
    kind "summarizes"
  ]
  edge [
    source 2196
    target 2198
    kind "relation"
    relation "was changed to"
    weight 1
  ]
  edge [
    source 2199
    target 2200
    kind "mentions"
  ]
  edge [
    source 2199
    target 2201
    kind "mentions"
  ]
  edge [
    source 2199
    target 2202
    kind "mentions"
  ]
  edge [
    source 2199
    target 2203
    kind "mentions"
  ]
  edge [
    source 2199
    target 2204
    kind "mentions"
  ]
  edge [
    source 2199
    target 2205
    kind "mentions"
  ]
  edge [
    source 2199
    target 2223
    kind "summarizes"
  ]
  edge [
    source 2200
    target 2202
    kind "relation"
    relation "attempts to reproduce"
    weight 1
  ]
  edge [
    source 2200
    target 2203
    kind "relation"
    relation "makes concessions in"
    weight 1
  ]
  edge [
    source 2201
    target 2207
    kind "mentions"
  ]
  edge [
    source 2203
    target 2204
    kind "relation"
    relation "are enclosed by | were not included in"
    weight 2
  ]
  edge [
    source 2203
    target 2207
    kind "mentions"
  ]
  edge [
    source 2203
    target 2208
    kind "relation"
    relation "were typeset in"
    weight 1
  ]
  edge [
    source 2203
    target 2209
    kind "relation"
    relation "appeared before or within | were flush right on the same line as"
    weight 2
  ]
  edge [
    source 2203
    target 2213
    kind "relation"
    relation "were placed on the next line if"
    weight 1
  ]
  edge [
    source 2203
    target 2210
    kind "relation"
    relation "were indented as | were indented the same amount as"
    weight 2
  ]
  edge [
    source 2203
    target 2211
    kind "relation"
    relation "had varying amounts of"
    weight 1
  ]
  edge [
    source 2203
    target 2212
    kind "relation"
    relation "were moved to"
    weight 1
  ]
  edge [
    source 2204
    target 2205
    kind "relation"
    relation "are usually without"
    weight 1
  ]
  edge [
    source 2204
    target 2207
    kind "mentions"
  ]
  edge [
    source 2206
    target 2207
    kind "from_chunk"
  ]
  edge [
    source 2207
    target 2208
    kind "mentions"
  ]
  edge [
    source 2207
    target 2209
    kind "mentions"
  ]
  edge [
    source 2207
    target 2210
    kind "mentions"
  ]
  edge [
    source 2207
    target 2211
    kind "mentions"
  ]
  edge [
    source 2207
    target 2212
    kind "mentions"
  ]
  edge [
    source 2207
    target 2213
    kind "mentions"
  ]
  edge [
    source 2207
    target 2241
    kind "summarizes"
  ]
]
