graph [
  node [
    id 0
    label "C:Novel-4128_00000"
    kind "chunk"
    chunk_id "Novel-4128_00000"
  ]
  node [
    id 1
    label "U:Novel-4128_00000#0"
    kind "unit"
    chunk_id "Novel-4128_00000"
    text "On June 1st, Samuel Pepys, along with Sir W. Pen and Mr. Gauden, traveled by water to Woolwich, where they visited ships to give orders and take notice of their readiness to sail, then proceeded to Deptford and performed similar actions there. After dining at Woolwich with Captain Poole at the tavern, they walked to Redriffe, stopping at a half-way house where they saw an abundance of new cakes prepared for Whitsuntide and enjoyed themselves. They returned by water and conducted office business, including securing Lord Braybrooke's imprest of L1000 and Mr. Creed's imprest of L10,000 against the voyage, with the bills signed."
    community 8
  ]
  node [
    id 2
    label "E:SAMUEL PEPYS"
    kind "entity"
    name "SAMUEL PEPYS"
    community 8
  ]
  node [
    id 3
    label "E:SIR W. PEN"
    kind "entity"
    name "SIR W. PEN"
    community 17
  ]
  node [
    id 4
    label "E:MR. GAUDEN"
    kind "entity"
    name "MR. GAUDEN"
    community 8
  ]
  node [
    id 5
    label "E:WOOLWICH"
    kind "entity"
    name "WOOLWICH"
    community 8
  ]
  node [
    id 6
    label "E:DEPTFORD"
    kind "entity"
    name "DEPTFORD"
    community 8
  ]
  node [
    id 7
    label "E:REDRIFFE"
    kind "entity"
    name "REDRIFFE"
    community 8
  ]
  node [
    id 8
    label "E:CAPTAIN POOLE"
    kind "entity"
    name "CAPTAIN POOLE"
    community 8
  ]
  node [
    id 9
    label "E:PEPSYAN LIBRARY"
    kind "entity"
    name "PEPSYAN LIBRARY"
    community 8
  ]
  node [
    id 10
    label "E:MAGDALENE COLLEGE"
    kind "entity"
    name "MAGDALENE COLLEGE"
    community 8
  ]
  node [
    id 11
    label "E:CAMBRIDGE"
    kind "entity"
    name "CAMBRIDGE"
    community 8
  ]
  node [
    id 12
    label "E:LORD BRAYBROOKE"
    kind "entity"
    name "LORD BRAYBROOKE"
    community 8
  ]
  node [
    id 13
    label "E:MR. CREED"
    kind "entity"
    name "MR. CREED"
    community 9
  ]
  node [
    id 14
    label "E:WHITSUNTIDE"
    kind "entity"
    name "WHITSUNTIDE"
    community 8
  ]
  node [
    id 15
    label "E:NEW CAKES"
    kind "entity"
    name "NEW CAKES"
    community 8
  ]
  node [
    id 16
    label "E:OFFICE BUSINESSES"
    kind "entity"
    name "OFFICE BUSINESSES"
    community 8
  ]
  node [
    id 17
    label "E:L1000"
    kind "entity"
    name "L1000"
    community 8
  ]
  node [
    id 18
    label "E:L10000"
    kind "entity"
    name "L10000"
    community 5
  ]
  node [
    id 19
    label "E:LORD BRAYBROOKE'S IMPREST OF L1000"
    kind "entity"
    name "LORD BRAYBROOKE'S IMPREST OF L1000"
    community 8
  ]
  node [
    id 20
    label "E:MR. CREED'S L10000"
    kind "entity"
    name "MR. CREED'S L10000"
    community 8
  ]
  node [
    id 21
    label "E:THIS VOYAGE"
    kind "entity"
    name "THIS VOYAGE"
    community 8
  ]
  node [
    id 22
    label "C:Novel-4128_00001"
    kind "chunk"
    chunk_id "Novel-4128_00001"
  ]
  node [
    id 23
    label "U:Novel-4128_00001#0"
    kind "unit"
    chunk_id "Novel-4128_00001"
    text "Creed's of L10,000 signed their bills against this voyage. After writing letters and reading some things, the narrator went to bed. On the 2nd (Whitsunday), the barber finished with the narrator, who then went to church and heard a good sermon by Mr. Mills, suitable for the day. After dinner, the narrator went to church again, and upon returning home found Greatorex, whom he had expected at dinner, came to see him. The narrator and Greatorex spent an hour or two in his chamber drinking wine and eating anchovies, discussing various mathematical topics, including how levers work and that gain in strength is lost in time. It rained very hard, as it has done recently, leading to concerns about a possible famine, and as a result, Greatorex stayed longer than the narrator desired. At night, after prayers, the narrator went to bed. On the 3rd, the narrator went to the Wardrobe, where he discussed with his Lord the business of the Wardrobe in the event that Mr. Townsend died, and was told that the Lord intended to join him and Mr. Townsend."
    community 5
  ]
  node [
    id 24
    label "E:CREED'S"
    kind "entity"
    name "CREED'S"
    community 5
  ]
  node [
    id 25
    label "E:VOYAGE"
    kind "entity"
    name "VOYAGE"
    community 5
  ]
  node [
    id 26
    label "E:LETTERS"
    kind "entity"
    name "LETTERS"
    community 5
  ]
  node [
    id 27
    label "E:READING"
    kind "entity"
    name "READING"
    community 5
  ]
  node [
    id 28
    label "E:NARRATOR"
    kind "entity"
    name "NARRATOR"
    community -1
  ]
  node [
    id 29
    label "E:BARBER"
    kind "entity"
    name "BARBER"
    community 5
  ]
  node [
    id 30
    label "E:CHURCH"
    kind "entity"
    name "CHURCH"
    community 15
  ]
  node [
    id 31
    label "E:MR. MILLS"
    kind "entity"
    name "MR. MILLS"
    community 17
  ]
  node [
    id 32
    label "E:SERMON"
    kind "entity"
    name "SERMON"
    community 18
  ]
  node [
    id 33
    label "E:DINNER"
    kind "entity"
    name "DINNER"
    community 15
  ]
  node [
    id 34
    label "E:GREATOREX"
    kind "entity"
    name "GREATOREX"
    community 5
  ]
  node [
    id 35
    label "E:WINE"
    kind "entity"
    name "WINE"
    community 16
  ]
  node [
    id 36
    label "E:ANCHOVIES"
    kind "entity"
    name "ANCHOVIES"
    community 5
  ]
  node [
    id 37
    label "E:MATHEMATICS"
    kind "entity"
    name "MATHEMATICS"
    community 5
  ]
  node [
    id 38
    label "E:LEVERS"
    kind "entity"
    name "LEVERS"
    community 5
  ]
  node [
    id 39
    label "E:STRENGTH"
    kind "entity"
    name "STRENGTH"
    community 5
  ]
  node [
    id 40
    label "E:TIME"
    kind "entity"
    name "TIME"
    community 5
  ]
  node [
    id 41
    label "E:RAIN"
    kind "entity"
    name "RAIN"
    community 5
  ]
  node [
    id 42
    label "E:FAMINE"
    kind "entity"
    name "FAMINE"
    community 5
  ]
  node [
    id 43
    label "E:MR. TOWNSEND"
    kind "entity"
    name "MR. TOWNSEND"
    community 9
  ]
  node [
    id 44
    label "E:WARDROBE"
    kind "entity"
    name "WARDROBE"
    community -1
  ]
  node [
    id 45
    label "E:LORD"
    kind "entity"
    name "LORD"
    community 9
  ]
  node [
    id 46
    label "E:JOINT"
    kind "entity"
    name "JOINT"
    community 5
  ]
  node [
    id 47
    label "E:MR."
    kind "entity"
    name "MR."
    community 0
  ]
  node [
    id 48
    label "E:AFTER WRITING LETTERS AND READING THINGS"
    kind "entity"
    name "AFTER WRITING LETTERS AND READING THINGS"
    community 5
  ]
  node [
    id 49
    label "E:2ND (WHITSUNDAY)"
    kind "entity"
    name "2ND (WHITSUNDAY)"
    community 5
  ]
  node [
    id 50
    label "E:AFTER CHURCH"
    kind "entity"
    name "AFTER CHURCH"
    community 5
  ]
  node [
    id 51
    label "E:AFTER DINNER"
    kind "entity"
    name "AFTER DINNER"
    community 5
  ]
  node [
    id 52
    label "E:UPON RETURNING HOME"
    kind "entity"
    name "UPON RETURNING HOME"
    community 5
  ]
  node [
    id 53
    label "E:OF LATE"
    kind "entity"
    name "OF LATE"
    community 5
  ]
  node [
    id 54
    label "E:3RD"
    kind "entity"
    name "3RD"
    community 5
  ]
  node [
    id 55
    label "C:Novel-4128_00002"
    kind "chunk"
    chunk_id "Novel-4128_00002"
  ]
  node [
    id 56
    label "U:Novel-4128_00002#0"
    kind "unit"
    chunk_id "Novel-4128_00002"
    text "Townsend expressed his intention to join the speaker and Mr. Moore in a business venture, stating that he is going to sea and has placed great confidence in someone, which the speaker finds proud. The speaker shares with Townsend that since God has blessed him with something, he wishes to spend part of it for his father and has chosen Mr. Young's position in the Wardrobe, requesting that Mr. Young arrange it in his absence if the position becomes available. Townsend freely promises to do so, saying he will do it at the least. The speaker then sees Townsend off in a barge to Whitehall and returns home with Mr. Creed. At home, the speaker's father, father Bowyer, mother, and four daughters arrive, along with a young gentleman and his sister, their friends, and they stay all afternoon, during which the speaker drinks a great deal of wine and is very merry. Later, the speaker is called to the office and stays there a little before returning home and taking Mr. with him."
    community 15
  ]
  node [
    id 57
    label "E:TOWNSEND"
    kind "entity"
    name "TOWNSEND"
    community 15
  ]
  node [
    id 58
    label "E:MR. MOORE"
    kind "entity"
    name "MR. MOORE"
    community 12
  ]
  node [
    id 59
    label "E:SPEAKER"
    kind "entity"
    name "SPEAKER"
    community -1
  ]
  node [
    id 60
    label "E:MR. YOUNG"
    kind "entity"
    name "MR. YOUNG"
    community 15
  ]
  node [
    id 61
    label "E:MY LORD"
    kind "entity"
    name "MY LORD"
    community 9
  ]
  node [
    id 62
    label "E:WHITEHALL"
    kind "entity"
    name "WHITEHALL"
    community 12
  ]
  node [
    id 63
    label "E:FATHER BOWYER"
    kind "entity"
    name "FATHER BOWYER"
    community 15
  ]
  node [
    id 64
    label "E:MOTHER"
    kind "entity"
    name "MOTHER"
    community 4
  ]
  node [
    id 65
    label "E:FOUR DAUGHTERS"
    kind "entity"
    name "FOUR DAUGHTERS"
    community 15
  ]
  node [
    id 66
    label "E:YOUNG GENTLEMAN"
    kind "entity"
    name "YOUNG GENTLEMAN"
    community 15
  ]
  node [
    id 67
    label "E:SISTER"
    kind "entity"
    name "SISTER"
    community 11
  ]
  node [
    id 68
    label "E:OFFICE"
    kind "entity"
    name "OFFICE"
    community -1
  ]
  node [
    id 69
    label "E:SPEAKER AND MR. MOORE"
    kind "entity"
    name "SPEAKER AND MR. MOORE"
    community 15
  ]
  node [
    id 70
    label "E:SOMEONE"
    kind "entity"
    name "SOMEONE"
    community 15
  ]
  node [
    id 71
    label "E:HIS FATHER"
    kind "entity"
    name "HIS FATHER"
    community 19
  ]
  node [
    id 72
    label "E:MR. YOUNG'S POSITION IN THE WARDROBE"
    kind "entity"
    name "MR. YOUNG'S POSITION IN THE WARDROBE"
    community 15
  ]
  node [
    id 73
    label "E:MR. YOUNG TO ARRANGE THE POSITION IN HIS ABSENCE"
    kind "entity"
    name "MR. YOUNG TO ARRANGE THE POSITION IN HIS ABSENCE"
    community 15
  ]
  node [
    id 74
    label "E:ARRANGEMENT"
    kind "entity"
    name "ARRANGEMENT"
    community 15
  ]
  node [
    id 75
    label "E:TOWNSEND IN A BARGE TO WHITEHALL"
    kind "entity"
    name "TOWNSEND IN A BARGE TO WHITEHALL"
    community 15
  ]
  node [
    id 76
    label "E:FATHER BOWYER, MOTHER, FOUR DAUGHTERS, YOUNG GENTLEMAN, SISTER"
    kind "entity"
    name "FATHER BOWYER, MOTHER, FOUR DAUGHTERS, YOUNG GENTLEMAN, SISTER"
    community 15
  ]
  node [
    id 77
    label "U:Novel-4128_00002#1"
    kind "unit"
    chunk_id "Novel-4128_00002"
    text "The speaker returns home and takes Mr. with him, concluding the account."
    community 0
  ]
  node [
    id 78
    label "C:Novel-4128_00003"
    kind "chunk"
    chunk_id "Novel-4128_00003"
  ]
  node [
    id 79
    label "U:Novel-4128_00003#0"
    kind "unit"
    chunk_id "Novel-4128_00003"
    text "The narrator is called to the office, stays a little, then returns home, takes Mr. Creed, and goes to the Towre to speak about ammunition for ships for my Lord. The narrator and Mr. Creed walk quite round the Towre, which the narrator had never done before, then return home. After a walk with his wife on the leads, the narrator and his wife go to bed."
    community 2
  ]
  node [
    id 80
    label "E:TOWRE"
    kind "entity"
    name "TOWRE"
    community 2
  ]
  node [
    id 81
    label "E:AMMUNITION FOR SHIPS"
    kind "entity"
    name "AMMUNITION FOR SHIPS"
    community 2
  ]
  node [
    id 82
    label "E:HOME"
    kind "entity"
    name "HOME"
    community 12
  ]
  node [
    id 83
    label "E:LEADS"
    kind "entity"
    name "LEADS"
    community 2
  ]
  node [
    id 84
    label "E:WIFE"
    kind "entity"
    name "WIFE"
    community -1
  ]
  node [
    id 85
    label "E:BED"
    kind "entity"
    name "BED"
    community 2
  ]
  node [
    id 86
    label "U:Novel-4128_00003#1"
    kind "unit"
    chunk_id "Novel-4128_00003"
    text "This morning, the narrator and Dr. Peirce go to the Beare at the Bridge foot, intending to meet my Lord Hinchinbroke and his brother who are setting forth for France; however, they do not arrive, so they go to the Wardrobe and learn that my Lord Abbot Montagu is not in Paris and has decided that my Lord wishes for them to stay a little longer before traveling to France."
    community 9
  ]
  node [
    id 87
    label "E:DR. PEIRCE"
    kind "entity"
    name "DR. PEIRCE"
    community 9
  ]
  node [
    id 88
    label "E:BEARE AT THE BRIDGE FOOT"
    kind "entity"
    name "BEARE AT THE BRIDGE FOOT"
    community 9
  ]
  node [
    id 89
    label "E:MY LORD HINCHINBROKE"
    kind "entity"
    name "MY LORD HINCHINBROKE"
    community 9
  ]
  node [
    id 90
    label "E:HIS BROTHER"
    kind "entity"
    name "HIS BROTHER"
    community 16
  ]
  node [
    id 91
    label "E:FRANCE"
    kind "entity"
    name "FRANCE"
    community 19
  ]
  node [
    id 92
    label "E:MY LORD ABBOT MONTAGU"
    kind "entity"
    name "MY LORD ABBOT MONTAGU"
    community 9
  ]
  node [
    id 93
    label "E:PARIS"
    kind "entity"
    name "PARIS"
    community 9
  ]
  node [
    id 94
    label "E:STAY A LITTLE LONGER"
    kind "entity"
    name "STAY A LITTLE LONGER"
    community 9
  ]
  node [
    id 95
    label "U:Novel-4128_00003#2"
    kind "unit"
    chunk_id "Novel-4128_00003"
    text "This morning, the Comptroller comes to invite the narrator to see a house or two near the office, which he would take for himself or Mr. Turner, and then have Mr. Turner's lodgings and himself the narrator's and Mr. Davis's. The houses do not appeal to them, so the plan is currently stopped. Then the Comptroller and the narrator go by water to the bridge, walk over the Bank-side to the Temple, and then the narrator goes to his father's house where he meets his cozen J."
    community 6
  ]
  node [
    id 96
    label "E:COMPTROLLER"
    kind "entity"
    name "COMPTROLLER"
    community 6
  ]
  node [
    id 97
    label "E:HOUSE OR TWO"
    kind "entity"
    name "HOUSE OR TWO"
    community 6
  ]
  node [
    id 98
    label "E:MR. TURNER"
    kind "entity"
    name "MR. TURNER"
    community 21
  ]
  node [
    id 99
    label "E:MR. DAVIS"
    kind "entity"
    name "MR. DAVIS"
    community 6
  ]
  node [
    id 100
    label "E:BY WATER"
    kind "entity"
    name "BY WATER"
    community 6
  ]
  node [
    id 101
    label "E:BRIDGE"
    kind "entity"
    name "BRIDGE"
    community 0
  ]
  node [
    id 102
    label "E:BANK-SIDE"
    kind "entity"
    name "BANK-SIDE"
    community 6
  ]
  node [
    id 103
    label "E:TEMPLE"
    kind "entity"
    name "TEMPLE"
    community 17
  ]
  node [
    id 104
    label "E:FATHER'S HOUSE"
    kind "entity"
    name "FATHER'S HOUSE"
    community 4
  ]
  node [
    id 105
    label "E:COZEN J"
    kind "entity"
    name "COZEN J"
    community 6
  ]
  node [
    id 106
    label "E:MR. TURNER'S LODGINGS"
    kind "entity"
    name "MR. TURNER'S LODGINGS"
    community 6
  ]
  node [
    id 107
    label "E:NARRATOR'S LODGINGS"
    kind "entity"
    name "NARRATOR'S LODGINGS"
    community 6
  ]
  node [
    id 108
    label "E:MR. DAVIS'S LODGINGS"
    kind "entity"
    name "MR. DAVIS'S LODGINGS"
    community 6
  ]
  node [
    id 109
    label "C:Novel-4128_00004"
    kind "chunk"
    chunk_id "Novel-4128_00004"
  ]
  node [
    id 110
    label "U:Novel-4128_00004#0"
    kind "unit"
    chunk_id "Novel-4128_00004"
    text "Holcroft took the narrator, his father, and his brother Tom to the Bear tavern and gave them wine. His cousin was to go into the country the next day. They then went to my Lord Crew's for dinner, where they had a good discussion about young noblemen and gentlemen considering a career at sea, which Holcroft considered as honourable as land war. He described a historical instance from Queen Elizabeth's time when a young nobleman waited with a trencher at the back of another until he reached adulthood. He cited the example of the young Lord of Kent, who waited upon my Lord Bedford at table when a letter arrived stating that the Earldom of Kent had passed to his servant, the young Lord; upon receiving the news, my Lord Bedford rose from table, made the young Lord sit in his place, and took a lower seat himself, as was customary by place of seating. After dinner, they went to the Theatre and saw 'Harry the 4th,' a good play. The narrator then crossed the water, walked over the fields to Southwark, returned home, and played his lute. That night, he went to bed."
    community 10
  ]
  node [
    id 111
    label "E:HOLCROFT"
    kind "entity"
    name "HOLCROFT"
    community 10
  ]
  node [
    id 112
    label "E:FATHER"
    kind "entity"
    name "FATHER"
    community -1
  ]
  node [
    id 113
    label "E:BROTHER TOM"
    kind "entity"
    name "BROTHER TOM"
    community 13
  ]
  node [
    id 114
    label "E:BEAR TAVERN"
    kind "entity"
    name "BEAR TAVERN"
    community 10
  ]
  node [
    id 115
    label "E:COUNCIL"
    kind "entity"
    name "COUNCIL"
    community 10
  ]
  node [
    id 116
    label "E:MY LORD CREW"
    kind "entity"
    name "MY LORD CREW"
    community 10
  ]
  node [
    id 117
    label "E:YOUNG NOBLEMAN"
    kind "entity"
    name "YOUNG NOBLEMAN"
    community 10
  ]
  node [
    id 118
    label "E:QUEEN ELIZABETH'S TIME"
    kind "entity"
    name "QUEEN ELIZABETH'S TIME"
    community 10
  ]
  node [
    id 119
    label "E:YOUNG LORD OF KENT"
    kind "entity"
    name "YOUNG LORD OF KENT"
    community 10
  ]
  node [
    id 120
    label "E:MY LORD BEDFORD"
    kind "entity"
    name "MY LORD BEDFORD"
    community 10
  ]
  node [
    id 121
    label "E:EARLDOM OF KENT"
    kind "entity"
    name "EARLDOM OF KENT"
    community 10
  ]
  node [
    id 122
    label "E:THEATRE"
    kind "entity"
    name "THEATRE"
    community 16
  ]
  node [
    id 123
    label "E:HARRY THE 4TH"
    kind "entity"
    name "HARRY THE 4TH"
    community 10
  ]
  node [
    id 124
    label "E:SOUTHWARK"
    kind "entity"
    name "SOUTHWARK"
    community 10
  ]
  node [
    id 125
    label "E:LUTE"
    kind "entity"
    name "LUTE"
    community 10
  ]
  node [
    id 126
    label "E:L4"
    kind "entity"
    name "L4"
    community 10
  ]
  node [
    id 127
    label "E:LACE"
    kind "entity"
    name "LACE"
    community 10
  ]
  node [
    id 128
    label "E:COUNCIL TO GO INTO THE COUNTRY"
    kind "entity"
    name "COUNCIL TO GO INTO THE COUNTRY"
    community 10
  ]
  node [
    id 129
    label "E:NARRATOR AND FATHER"
    kind "entity"
    name "NARRATOR AND FATHER"
    community 10
  ]
  node [
    id 130
    label "E:YOUNG NOBLEMEN GOING TO SEA"
    kind "entity"
    name "YOUNG NOBLEMEN GOING TO SEA"
    community 10
  ]
  node [
    id 131
    label "E:LAND WAR"
    kind "entity"
    name "LAND WAR"
    community 10
  ]
  node [
    id 132
    label "E:YOUNG NOBLEMAN WAITING WITH TRENCHER"
    kind "entity"
    name "YOUNG NOBLEMAN WAITING WITH TRENCHER"
    community 10
  ]
  node [
    id 133
    label "E:LETTER ARRIVED"
    kind "entity"
    name "LETTER ARRIVED"
    community 10
  ]
  node [
    id 134
    label "E:BY PLACE OF SEATING"
    kind "entity"
    name "BY PLACE OF SEATING"
    community 10
  ]
  node [
    id 135
    label "E:NIGHT"
    kind "entity"
    name "NIGHT"
    community 7
  ]
  node [
    id 136
    label "E:TO LAY OUT ON LACE AND OTHER THINGS"
    kind "entity"
    name "TO LAY OUT ON LACE AND OTHER THINGS"
    community 10
  ]
  node [
    id 137
    label "U:Novel-4128_00004#1"
    kind "unit"
    chunk_id "Novel-4128_00004"
    text "The narrator gave his wife L4 to spend on lace and other personal items for herself."
    community 10
  ]
  node [
    id 138
    label "E:OTHER THINGS"
    kind "entity"
    name "OTHER THINGS"
    community 10
  ]
  node [
    id 139
    label "E:LACE AND OTHER THINGS"
    kind "entity"
    name "LACE AND OTHER THINGS"
    community 10
  ]
  node [
    id 140
    label "C:Novel-4128_00005"
    kind "chunk"
    chunk_id "Novel-4128_00005"
  ]
  node [
    id 141
    label "U:Novel-4128_00005#0"
    kind "unit"
    chunk_id "Novel-4128_00005"
    text "This morning, the speaker gave his wife L4 to lay out upon lace and other things for herself. He then went to Wardrobe and traveled to Whitehall and Westminster, where he dined with his Lord and Ned Dickering at his lodgings. After dinner, he went to the office, where he and another person sat and conducted business. Sir W. Pen and the speaker then went home with Sir R. Slingsby to play bowls at his ally, where they had good sport. Afterwards, they went indoors to drink and talk. The speaker and Sir William then returned home; due to the hot weather, he took his flageolette and played in the garden, where Sir W. Pen came out in his shirt and joined him in the leads. They stayed there talking, singing, drinking large drafts of claret, and eating botargo and bread and butter until 12 at night under moonshine, and then went to bed, feeling very drunk."
    community 2
  ]
  node [
    id 142
    label "E:WESTMINSTER"
    kind "entity"
    name "WESTMINSTER"
    community 0
  ]
  node [
    id 143
    label "E:HIS LORD"
    kind "entity"
    name "HIS LORD"
    community 5
  ]
  node [
    id 144
    label "E:NED DICKERING"
    kind "entity"
    name "NED DICKERING"
    community 2
  ]
  node [
    id 145
    label "E:SIR R. SLINGSBY"
    kind "entity"
    name "SIR R. SLINGSBY"
    community 9
  ]
  node [
    id 146
    label "E:ALLY"
    kind "entity"
    name "ALLY"
    community 2
  ]
  node [
    id 147
    label "E:BOTARGO"
    kind "entity"
    name "BOTARGO"
    community 2
  ]
  node [
    id 148
    label "E:CLARET"
    kind "entity"
    name "CLARET"
    community 2
  ]
  node [
    id 149
    label "E:BREAD AND BUTTER"
    kind "entity"
    name "BREAD AND BUTTER"
    community 2
  ]
  node [
    id 150
    label "E:MOONSHINE"
    kind "entity"
    name "MOONSHINE"
    community 2
  ]
  node [
    id 151
    label "E:HOT WEATHER"
    kind "entity"
    name "HOT WEATHER"
    community 8
  ]
  node [
    id 152
    label "E:FLAGEOLETTE"
    kind "entity"
    name "FLAGEOLETTE"
    community 2
  ]
  node [
    id 153
    label "E:GARDEN"
    kind "entity"
    name "GARDEN"
    community 11
  ]
  node [
    id 154
    label "E:12 AT NIGHT"
    kind "entity"
    name "12 AT NIGHT"
    community 2
  ]
  node [
    id 155
    label "E:DEBAUCH"
    kind "entity"
    name "DEBAUCH"
    community 2
  ]
  node [
    id 156
    label "E:ALL NIGHT"
    kind "entity"
    name "ALL NIGHT"
    community 2
  ]
  node [
    id 157
    label "E:ALL THIS MORNING"
    kind "entity"
    name "ALL THIS MORNING"
    community 2
  ]
  node [
    id 158
    label "U:Novel-4128_00005#1"
    kind "unit"
    chunk_id "Novel-4128_00005"
    text "The speaker's head ached all night and all morning following the previous night's debauch."
    community 2
  ]
  node [
    id 159
    label "E:HEADACHE"
    kind "entity"
    name "HEADACHE"
    community 2
  ]
  node [
    id 160
    label "C:Novel-4128_00006"
    kind "chunk"
    chunk_id "Novel-4128_00006"
  ]
  node [
    id 161
    label "U:Novel-4128_00006#0"
    kind "unit"
    chunk_id "Novel-4128_00006"
    text "The narrator's head had been aching all night and all morning due to the previous night's debauch. Called by Lieutenant Lambert, who had been promoted to Captain of the Norwich, the narrator and he traveled by water to Greenwich, where they observed and discussed ship-related topics, with Lambert answering all the narrator's questions, which were of good use. At Greenwich, they ate, drank, and heard music at the Globe, where they saw a woman with a rod in her hand keeping time to the music, which the narrator found simple. They returned by water, visiting Captain Lambert's house, which was described as very handsome and neat with a fine view from the top. Then they went to the office, sat a little, and later the narrator and Captain Lambert went to Bridewell to see Mr. Holland, where his wife, a plain dowdy, and his mother were also present. The narrator paid Mrs. Holland the money due to her husband. Two young gentlewomen came to see Mr. Holland, one of whom played the viallin well, but the narrator noted that these ignorant people cried her up for it. They were very merry, the narrator stayed and supped there, then returned home and to bed. The weather was very hot, and that night the narrator removed his wastecoat."
    community 7
  ]
  node [
    id 162
    label "E:LIEUTENANT LAMBERT"
    kind "entity"
    name "LIEUTENANT LAMBERT"
    community 7
  ]
  node [
    id 163
    label "E:CAPTAIN LAMBERT"
    kind "entity"
    name "CAPTAIN LAMBERT"
    community 7
  ]
  node [
    id 164
    label "E:NORWICH"
    kind "entity"
    name "NORWICH"
    community 7
  ]
  node [
    id 165
    label "E:GREENWICH"
    kind "entity"
    name "GREENWICH"
    community 7
  ]
  node [
    id 166
    label "E:GLOBE"
    kind "entity"
    name "GLOBE"
    community 7
  ]
  node [
    id 167
    label "E:WOMAN WITH ROD"
    kind "entity"
    name "WOMAN WITH ROD"
    community 7
  ]
  node [
    id 168
    label "E:MUSIC"
    kind "entity"
    name "MUSIC"
    community 7
  ]
  node [
    id 169
    label "E:CAPTAIN LAMBERT'S HOUSE"
    kind "entity"
    name "CAPTAIN LAMBERT'S HOUSE"
    community 7
  ]
  node [
    id 170
    label "E:BRIDWELL"
    kind "entity"
    name "BRIDWELL"
    community 7
  ]
  node [
    id 171
    label "E:MR. HOLLAND"
    kind "entity"
    name "MR. HOLLAND"
    community 7
  ]
  node [
    id 172
    label "E:MRS. HOLLAND"
    kind "entity"
    name "MRS. HOLLAND"
    community 7
  ]
  node [
    id 173
    label "E:YOUNG GENTLEWOMEN"
    kind "entity"
    name "YOUNG GENTLEWOMEN"
    community 7
  ]
  node [
    id 174
    label "E:VIALLIN"
    kind "entity"
    name "VIALLIN"
    community 7
  ]
  node [
    id 175
    label "E:WASTECOAT"
    kind "entity"
    name "WASTECOAT"
    community 7
  ]
  node [
    id 176
    label "E:WEATHER"
    kind "entity"
    name "WEATHER"
    community 7
  ]
  node [
    id 177
    label "E:6TH"
    kind "entity"
    name "6TH"
    community 7
  ]
  node [
    id 178
    label "E:7TH"
    kind "entity"
    name "7TH"
    community 7
  ]
  node [
    id 179
    label "E:LAST NIGHT'S DEBAUCH"
    kind "entity"
    name "LAST NIGHT'S DEBAUCH"
    community 7
  ]
  node [
    id 180
    label "E:CAPTAIN OF NORWICH"
    kind "entity"
    name "CAPTAIN OF NORWICH"
    community 7
  ]
  node [
    id 181
    label "E:SHIPS"
    kind "entity"
    name "SHIPS"
    community 7
  ]
  node [
    id 182
    label "E:THINGS OF A SHIP"
    kind "entity"
    name "THINGS OF A SHIP"
    community 7
  ]
  node [
    id 183
    label "E:WOMAN WITH ROD KEEPING TIME TO MUSIC"
    kind "entity"
    name "WOMAN WITH ROD KEEPING TIME TO MUSIC"
    community 7
  ]
  node [
    id 184
    label "E:HANDSOME AND NEAT WITH FINE PROSPECT"
    kind "entity"
    name "HANDSOME AND NEAT WITH FINE PROSPECT"
    community 7
  ]
  node [
    id 185
    label "E:ONE YOUNG GENTLEWOMAN"
    kind "entity"
    name "ONE YOUNG GENTLEWOMAN"
    community 7
  ]
  node [
    id 186
    label "E:IGNORANT PEOPLE"
    kind "entity"
    name "IGNORANT PEOPLE"
    community 7
  ]
  node [
    id 187
    label "E:YOUNG GENTLEWOMAN"
    kind "entity"
    name "YOUNG GENTLEWOMAN"
    community 7
  ]
  node [
    id 188
    label "E:VERY HOT"
    kind "entity"
    name "VERY HOT"
    community 7
  ]
  node [
    id 189
    label "U:Novel-4128_00006#1"
    kind "unit"
    chunk_id "Novel-4128_00006"
    text "The narrator's head had been aching all night and all morning due to the previous night's debauch. Called by Lieutenant Lambert, who had been promoted to Captain of the Norwich, the narrator and he traveled by water to Greenwich, where they observed and discussed ship-related topics, with Lambert answering all the narrator's questions, which were of good use. At Greenwich, they ate, drank, and heard music at the Globe, where they saw a woman with a rod in her hand keeping time to the music, which the narrator found simple. They returned by water, visiting Captain Lambert's house, which was described as very handsome and neat with a fine view from the top. Then they went to the office, sat a little, and later the narrator and Captain Lambert went to Bridewell to see Mr. Holland, where his wife, a plain dowdy, and his mother were also present. The narrator paid Mrs. Holland the money due to her husband. Two young gentlewomen came to see Mr. Holland, one of whom played the viallin well, but the narrator noted that these ignorant people cried her up for it. They were very merry, the narrator stayed and supped there, then returned home and to bed. The weather was very hot, and that night the narrator removed his wastecoat."
    community 7
  ]
  node [
    id 190
    label "C:Novel-4128_00007"
    kind "chunk"
    chunk_id "Novel-4128_00007"
  ]
  node [
    id 191
    label "U:Novel-4128_00007#0"
    kind "unit"
    chunk_id "Novel-4128_00007"
    text "The weather was very hot, so that night the person left off their wastecoat. They went to my Lord's at Whitehall but did not find him, so they went to the Wardrobe and dined with my Lady, who treated them very kindly. After dinner, they went to the office and stayed there until late at night. Then they returned home and went to Sir William Batten's, who had arrived that day from Chatham with my Lady, who was and had been much troubled with toothache. They stayed there until late and then returned home to bed."
    community 7
  ]
  node [
    id 192
    label "E:MY LADY"
    kind "entity"
    name "MY LADY"
    community 1
  ]
  node [
    id 193
    label "E:SIR WILLIAM BATTEN"
    kind "entity"
    name "SIR WILLIAM BATTEN"
    community 7
  ]
  node [
    id 194
    label "E:CHATHAM"
    kind "entity"
    name "CHATHAM"
    community 7
  ]
  node [
    id 195
    label "E:TOOTHACHE"
    kind "entity"
    name "TOOTHACHE"
    community 1
  ]
  node [
    id 196
    label "E:PERSON"
    kind "entity"
    name "PERSON"
    community 9
  ]
  node [
    id 197
    label "E:SIR WILLIAM BATTEN'S"
    kind "entity"
    name "SIR WILLIAM BATTEN'S"
    community 9
  ]
  node [
    id 198
    label "U:Novel-4128_00007#1"
    kind "unit"
    chunk_id "Novel-4128_00007"
    text "On the 8th, the person went to Whitehall to see my Lord, who told them that he would have them go to Mr. Townsend, whom he had ordered to reveal to them the whole mystery of the Wardrobe, and only them, and that he would make them deputy with him in case he should die during his absence, which the person found glad. Then they went to the Cook's with Mr. Shepley and Mr. Creed, dined together, and then went to the Theatre where they saw Bartholomew Faire, which was the first time it had been performed in recent times. The play was most admirable and well acted, but too much prophane and abusive. Afterward, meeting Mr. Creed at the door, they went to the tobacco shop under Temple Bar gate, and went up to the top of the house where they sat drinking Lambeth ale for a long time."
    community 9
  ]
  node [
    id 199
    label "E:8TH"
    kind "entity"
    name "8TH"
    community 12
  ]
  node [
    id 200
    label "E:DEPUTY"
    kind "entity"
    name "DEPUTY"
    community 9
  ]
  node [
    id 201
    label "E:BARTHOLOMEW FAIRE"
    kind "entity"
    name "BARTHOLOMEW FAIRE"
    community 9
  ]
  node [
    id 202
    label "E:COOK'S"
    kind "entity"
    name "COOK'S"
    community 9
  ]
  node [
    id 203
    label "E:MR. SHEPLEY"
    kind "entity"
    name "MR. SHEPLEY"
    community 9
  ]
  node [
    id 204
    label "E:TEMPLE BAR GATE"
    kind "entity"
    name "TEMPLE BAR GATE"
    community 9
  ]
  node [
    id 205
    label "E:LAMBETH ALE"
    kind "entity"
    name "LAMBETH ALE"
    community 5
  ]
  node [
    id 206
    label "E:GLAD"
    kind "entity"
    name "GLAD"
    community 9
  ]
  node [
    id 207
    label "E:RECENT TIMES"
    kind "entity"
    name "RECENT TIMES"
    community 9
  ]
  node [
    id 208
    label "E:ADMIRABLE"
    kind "entity"
    name "ADMIRABLE"
    community 9
  ]
  node [
    id 209
    label "E:WELL ACTED"
    kind "entity"
    name "WELL ACTED"
    community 9
  ]
  node [
    id 210
    label "E:TOO MUCH PROPHANE AND ABUSIVE"
    kind "entity"
    name "TOO MUCH PROPHANE AND ABUSIVE"
    community 9
  ]
  node [
    id 211
    label "E:TOBACCO SHOP UNDER TEMPLE BAR GATE"
    kind "entity"
    name "TOBACCO SHOP UNDER TEMPLE BAR GATE"
    community 9
  ]
  node [
    id 212
    label "E:TOP OF THE HOUSE"
    kind "entity"
    name "TOP OF THE HOUSE"
    community 9
  ]
  node [
    id 213
    label "C:Novel-4128_00008"
    kind "chunk"
    chunk_id "Novel-4128_00008"
  ]
  node [
    id 214
    label "U:Novel-4128_00008#0"
    kind "unit"
    chunk_id "Novel-4128_00008"
    text "The narrator went home and visited Mr. Rawlinson for advice regarding a letter from his uncle Robert, who offered to purchase land and join it with some of his own, stating that the arrangement would be convenient for the narrator's estate, which the narrator finds very pleasing; the narrator is advised to fully give up control of their money to Mr. Rawlinson and allow him to manage it as he sees fit, a decision the narrator agrees to."
    community 3
  ]
  node [
    id 215
    label "E:MR. RAWLINSON"
    kind "entity"
    name "MR. RAWLINSON"
    community 3
  ]
  node [
    id 216
    label "E:UNCLE ROBERT"
    kind "entity"
    name "UNCLE ROBERT"
    community 3
  ]
  node [
    id 217
    label "E:LAND PURCHASE"
    kind "entity"
    name "LAND PURCHASE"
    community 3
  ]
  node [
    id 218
    label "E:MR. RAWLINSON'S ESTATE"
    kind "entity"
    name "MR. RAWLINSON'S ESTATE"
    community 3
  ]
  node [
    id 219
    label "E:MONEY DISPOSAL"
    kind "entity"
    name "MONEY DISPOSAL"
    community 3
  ]
  node [
    id 220
    label "E:CONVENIENCE"
    kind "entity"
    name "CONVENIENCE"
    community 3
  ]
  node [
    id 221
    label "E:ESTATE"
    kind "entity"
    name "ESTATE"
    community 13
  ]
  node [
    id 222
    label "E:GIVE UP FULL CONTROL OF MONEY"
    kind "entity"
    name "GIVE UP FULL CONTROL OF MONEY"
    community 3
  ]
  node [
    id 223
    label "E:CONVENIENCE FOR HIS ESTATE"
    kind "entity"
    name "CONVENIENCE FOR HIS ESTATE"
    community 3
  ]
  node [
    id 224
    label "E:GIVE UP DISPOSAL OF MONEY TO MR. RAWLINSON"
    kind "entity"
    name "GIVE UP DISPOSAL OF MONEY TO MR. RAWLINSON"
    community 3
  ]
  node [
    id 225
    label "U:Novel-4128_00008#1"
    kind "unit"
    chunk_id "Novel-4128_00008"
    text "On the 9th day (Lord's day), the narrator's wife wore a black silk gown laced with black gimp lace according to current fashion, and appeared very pretty. She and the narrator walked to my Lady's at the Wardrobe, where they dined and were greatly admired. After dinner, the narrator left his wife there and walked to Whitehall, where he visited Mr. Pierce's home and sat with his wife for a while, who remained very pretty, until Mr. Pierce arrived, after which the narrator and Mr. Pierce went on together."
    community 19
  ]
  node [
    id 226
    label "E:BLACK SILK GOWN"
    kind "entity"
    name "BLACK SILK GOWN"
    community 19
  ]
  node [
    id 227
    label "E:BLACK GIMP LACE"
    kind "entity"
    name "BLACK GIMP LACE"
    community 19
  ]
  node [
    id 228
    label "E:FASHION"
    kind "entity"
    name "FASHION"
    community 19
  ]
  node [
    id 229
    label "E:MY LADY'S AT THE WARDROBE"
    kind "entity"
    name "MY LADY'S AT THE WARDROBE"
    community 19
  ]
  node [
    id 230
    label "E:MR. PIERCE"
    kind "entity"
    name "MR. PIERCE"
    community 19
  ]
  node [
    id 231
    label "E:MR. PIERCE'S WIFE"
    kind "entity"
    name "MR. PIERCE'S WIFE"
    community 19
  ]
  node [
    id 232
    label "E:NARRATOR AND WIFE"
    kind "entity"
    name "NARRATOR AND WIFE"
    community 19
  ]
  node [
    id 233
    label "E:DURING VISIT"
    kind "entity"
    name "DURING VISIT"
    community 19
  ]
  node [
    id 234
    label "E:NARRATOR AND MR. PIERCE"
    kind "entity"
    name "NARRATOR AND MR. PIERCE"
    community 19
  ]
  node [
    id 235
    label "E:AFTER MR. PIERCE ARRIVED"
    kind "entity"
    name "AFTER MR. PIERCE ARRIVED"
    community 19
  ]
  node [
    id 236
    label "C:Novel-4128_00009"
    kind "chunk"
    chunk_id "Novel-4128_00009"
  ]
  node [
    id 237
    label "U:Novel-4128_00009#0"
    kind "unit"
    chunk_id "Novel-4128_00009"
    text "Symons, the dancing master, went to sea with my Lord, visited the Swan tavern where they drank, then went to White Hall where they met Dean Fuller and walked for a long time; during this time they discussed the Bishop of Galloway's practice of admitting anyone into orders, including Roundtree, a simple mechanique formerly a parson in the fleet; Symons said he would complain about this practice. Later, they obtained a sculler, landed him at Worcester House, and then with W. Howe, who arrived at White Hall, went to the Wardrobe where Symons met Mr. Townsend, who expressed willingness to share information beneficial to my Lord's business. Symons then went to Jane Shore's tower, where he and W. Howe sang, then took his wife and walked home to bed. After returning home, a messenger from my Lord instructed him to come to my Lord the next morning."
    community 9
  ]
  node [
    id 238
    label "E:SYMONS"
    kind "entity"
    name "SYMONS"
    community 9
  ]
  node [
    id 239
    label "E:SWAN TAVERN"
    kind "entity"
    name "SWAN TAVERN"
    community 9
  ]
  node [
    id 240
    label "E:WHITE HALL"
    kind "entity"
    name "WHITE HALL"
    community 0
  ]
  node [
    id 241
    label "E:DEAN FULLER"
    kind "entity"
    name "DEAN FULLER"
    community 9
  ]
  node [
    id 242
    label "E:BISHOP OF GALLOWAY"
    kind "entity"
    name "BISHOP OF GALLOWAY"
    community 9
  ]
  node [
    id 243
    label "E:ROUNDTREE"
    kind "entity"
    name "ROUNDTREE"
    community 9
  ]
  node [
    id 244
    label "E:SIMPLE MECHANIQUE"
    kind "entity"
    name "SIMPLE MECHANIQUE"
    community 9
  ]
  node [
    id 245
    label "E:WORCESTER HOUSE"
    kind "entity"
    name "WORCESTER HOUSE"
    community 9
  ]
  node [
    id 246
    label "E:W. HOWE"
    kind "entity"
    name "W. HOWE"
    community 9
  ]
  node [
    id 247
    label "E:JANE SHORE'S TOWER"
    kind "entity"
    name "JANE SHORE'S TOWER"
    community 9
  ]
  node [
    id 248
    label "E:KING"
    kind "entity"
    name "KING"
    community -1
  ]
  node [
    id 249
    label "E:EMBASSADOR"
    kind "entity"
    name "EMBASSADOR"
    community 9
  ]
  node [
    id 250
    label "E:KATHERINE OF BRAGANZA"
    kind "entity"
    name "KATHERINE OF BRAGANZA"
    community 9
  ]
  node [
    id 251
    label "E:JOHN IV. OF PORTUGAL"
    kind "entity"
    name "JOHN IV. OF PORTUGAL"
    community 9
  ]
  node [
    id 252
    label "E:CHARLES II."
    kind "entity"
    name "CHARLES II."
    community 9
  ]
  node [
    id 253
    label "E:21ST MAY 1662"
    kind "entity"
    name "21ST MAY 1662"
    community 9
  ]
  node [
    id 254
    label "E:PARSON"
    kind "entity"
    name "PARSON"
    community 18
  ]
  node [
    id 255
    label "E:WALKING HOME"
    kind "entity"
    name "WALKING HOME"
    community 9
  ]
  node [
    id 256
    label "E:1638"
    kind "entity"
    name "1638"
    community 9
  ]
  node [
    id 257
    label "U:Novel-4128_00009#1"
    kind "unit"
    chunk_id "Novel-4128_00009"
    text "On the 10th, Symons went early to my Lord's residence, where my Lord privately informed him that the King had appointed him Embassador in the bringing over of the Queen, Katherine of Braganza, daughter of John IV. of Portugal, who was born in 1638 and married to Charles II. on May 21st, 1662."
    community 9
  ]
  node [
    id 258
    label "E:10TH"
    kind "entity"
    name "10TH"
    community 9
  ]
  node [
    id 259
    label "C:Novel-4128_00010"
    kind "chunk"
    chunk_id "Novel-4128_00010"
  ]
  node [
    id 260
    label "U:Novel-4128_00010#0"
    kind "unit"
    chunk_id "Novel-4128_00010"
    text "A woman born in Portugal in 1638 married Charles II on May 21st, 1662. After the king's death, she lived at Somerset House for some time before returning to Portugal, where she became Regent in 1704 upon her brother Don Pedro's retirement. She died on December 31st, 1705."
    community 14
  ]
  node [
    id 261
    label "E:PORTUGAL"
    kind "entity"
    name "PORTUGAL"
    community 14
  ]
  node [
    id 262
    label "E:CHARLES II"
    kind "entity"
    name "CHARLES II"
    community 14
  ]
  node [
    id 263
    label "E:MAY 21ST 1662"
    kind "entity"
    name "MAY 21ST 1662"
    community 14
  ]
  node [
    id 264
    label "E:SOMERSET HOUSE"
    kind "entity"
    name "SOMERSET HOUSE"
    community 14
  ]
  node [
    id 265
    label "E:1704"
    kind "entity"
    name "1704"
    community 14
  ]
  node [
    id 266
    label "E:DON PEDRO"
    kind "entity"
    name "DON PEDRO"
    community 14
  ]
  node [
    id 267
    label "E:DECEMBER 31ST 1705"
    kind "entity"
    name "DECEMBER 31ST 1705"
    community 14
  ]
  node [
    id 268
    label "E:WOMAN"
    kind "entity"
    name "WOMAN"
    community 14
  ]
  node [
    id 269
    label "U:Novel-4128_00010#1"
    kind "unit"
    chunk_id "Novel-4128_00010"
    text "A man is to go to Algier to settle business and organize the fleet there, then return to Lisbon with three ships to meet a following fleet. He entrusted the management of all preparations during his absence to the speaker, who will receive orders from his Lord Chancellor and Mr. Edward Montagu. The speaker expresses great joy at this arrangement, hoping for honor and personal benefit."
    community 8
  ]
  node [
    id 270
    label "E:ALGIER"
    kind "entity"
    name "ALGIER"
    community 8
  ]
  node [
    id 271
    label "E:LISBON"
    kind "entity"
    name "LISBON"
    community 8
  ]
  node [
    id 272
    label "E:THREE SHIPS"
    kind "entity"
    name "THREE SHIPS"
    community 8
  ]
  node [
    id 273
    label "E:FLEET"
    kind "entity"
    name "FLEET"
    community 8
  ]
  node [
    id 274
    label "E:LORD CHANCELLOR"
    kind "entity"
    name "LORD CHANCELLOR"
    community 20
  ]
  node [
    id 275
    label "E:EDWARD MONTAGU"
    kind "entity"
    name "EDWARD MONTAGU"
    community 8
  ]
  node [
    id 276
    label "E:HONOUR"
    kind "entity"
    name "HONOUR"
    community 8
  ]
  node [
    id 277
    label "E:PROFIT TO MYSELF"
    kind "entity"
    name "PROFIT TO MYSELF"
    community 8
  ]
  node [
    id 278
    label "E:MAN"
    kind "entity"
    name "MAN"
    community 8
  ]
  node [
    id 279
    label "E:HIS LORD'S HONOUR"
    kind "entity"
    name "HIS LORD'S HONOUR"
    community 8
  ]
  node [
    id 280
    label "U:Novel-4128_00010#2"
    kind "unit"
    chunk_id "Novel-4128_00010"
    text "Mr. Shepley Walden, a Parliament-man for Huntingdon, Rolt, Mackworth, and Alderman Backwell, is taken to a house nearby to drink Lambeth ale. The speaker returns to the Wardrobe and finds his Lord going to Trinity House on the solemn day of choosing Master, and his Lord is chosen, so he dines there that day."
    community 5
  ]
  node [
    id 281
    label "E:MR. SHEPLEY WALDEN"
    kind "entity"
    name "MR. SHEPLEY WALDEN"
    community 5
  ]
  node [
    id 282
    label "E:PARLIAMENT-MAN FOR HUNTINGDON"
    kind "entity"
    name "PARLIAMENT-MAN FOR HUNTINGDON"
    community 5
  ]
  node [
    id 283
    label "E:ROLT"
    kind "entity"
    name "ROLT"
    community 5
  ]
  node [
    id 284
    label "E:MACKWORTH"
    kind "entity"
    name "MACKWORTH"
    community 5
  ]
  node [
    id 285
    label "E:ALDERMAN BACKWELL"
    kind "entity"
    name "ALDERMAN BACKWELL"
    community 9
  ]
  node [
    id 286
    label "E:HOUSE HARD BY"
    kind "entity"
    name "HOUSE HARD BY"
    community 5
  ]
  node [
    id 287
    label "E:TRINITY HOUSE"
    kind "entity"
    name "TRINITY HOUSE"
    community 5
  ]
  node [
    id 288
    label "E:MASTER"
    kind "entity"
    name "MASTER"
    community 5
  ]
  node [
    id 289
    label "E:DINE"
    kind "entity"
    name "DINE"
    community 5
  ]
  node [
    id 290
    label "E:HUNTINGDON"
    kind "entity"
    name "HUNTINGDON"
    community 5
  ]
  node [
    id 291
    label "E:BACKWELL"
    kind "entity"
    name "BACKWELL"
    community 5
  ]
  node [
    id 292
    label "C:Novel-4128_00011"
    kind "chunk"
    chunk_id "Novel-4128_00011"
  ]
  node [
    id 293
    label "U:Novel-4128_00011#0"
    kind "unit"
    chunk_id "Novel-4128_00011"
    text "The narrator stayed and dined with Lady, then after being set, some persons of condition arrived, and the children and the narrator rose to dine by themselves, all the children and the narrator, and were very merry; the children were very fond of the narrator. Then the narrator went to the office and sat there for a while. Later, the narrator returned home and went to bed in Sir R. Slingsby's lodgings in the dining room, lying on one green bed, as the narrator's house was now in its last stage of painting and whiting."
    community 16
  ]
  node [
    id 294
    label "E:LADY"
    kind "entity"
    name "LADY"
    community 14
  ]
  node [
    id 295
    label "E:CHILDREN"
    kind "entity"
    name "CHILDREN"
    community 0
  ]
  node [
    id 296
    label "E:GREEN BED"
    kind "entity"
    name "GREEN BED"
    community 16
  ]
  node [
    id 297
    label "E:HOUSE"
    kind "entity"
    name "HOUSE"
    community -1
  ]
  node [
    id 298
    label "E:PAINTING"
    kind "entity"
    name "PAINTING"
    community 16
  ]
  node [
    id 299
    label "E:WHITING"
    kind "entity"
    name "WHITING"
    community 16
  ]
  node [
    id 300
    label "E:11TH"
    kind "entity"
    name "11TH"
    community 16
  ]
  node [
    id 301
    label "E:DINING ROOM"
    kind "entity"
    name "DINING ROOM"
    community 16
  ]
  node [
    id 302
    label "E:LODGINGS"
    kind "entity"
    name "LODGINGS"
    community 16
  ]
  node [
    id 303
    label "E:SIR R. SLINGSBY'S LODGINGS"
    kind "entity"
    name "SIR R. SLINGSBY'S LODGINGS"
    community 16
  ]
  node [
    id 304
    label "E:PAINTING AND WHITING"
    kind "entity"
    name "PAINTING AND WHITING"
    community 16
  ]
  node [
    id 305
    label "U:Novel-4128_00011#1"
    kind "unit"
    chunk_id "Novel-4128_00011"
    text "At the office this morning, Sir G. Carteret was present with the narrator; they agreed to write a letter to the Duke of York to inform him of the sad condition of the office due to lack of money, explaining that men are unable to serve them without funds, and that the office's credit is so low that no one will sell them anything without their personal security being given for the items."
    community 17
  ]
  node [
    id 306
    label "E:SIR G. CARTERET"
    kind "entity"
    name "SIR G. CARTERET"
    community 12
  ]
  node [
    id 307
    label "E:DUKE OF YORK"
    kind "entity"
    name "DUKE OF YORK"
    community 17
  ]
  node [
    id 308
    label "E:MONEY"
    kind "entity"
    name "MONEY"
    community 4
  ]
  node [
    id 309
    label "E:CREDIT"
    kind "entity"
    name "CREDIT"
    community 17
  ]
  node [
    id 310
    label "E:PERSONAL SECURITY"
    kind "entity"
    name "PERSONAL SECURITY"
    community 1
  ]
  node [
    id 311
    label "E:LETTER"
    kind "entity"
    name "LETTER"
    community 15
  ]
  node [
    id 312
    label "E:LACK OF MONEY"
    kind "entity"
    name "LACK OF MONEY"
    community 17
  ]
  node [
    id 313
    label "E:MEN"
    kind "entity"
    name "MEN"
    community 17
  ]
  node [
    id 314
    label "E:NO ONE WILL SELL TO THEM WITHOUT PERSONAL SECURITY"
    kind "entity"
    name "NO ONE WILL SELL TO THEM WITHOUT PERSONAL SECURITY"
    community 17
  ]
  node [
    id 315
    label "U:Novel-4128_00011#2"
    kind "unit"
    chunk_id "Novel-4128_00011"
    text "All afternoon the narrator was abroad attending several business matters, and at night returned home and went to bed."
    community 2
  ]
  node [
    id 316
    label "E:BUSINESS"
    kind "entity"
    name "BUSINESS"
    community 2
  ]
  node [
    id 317
    label "E:AFTERNOON"
    kind "entity"
    name "AFTERNOON"
    community 2
  ]
  node [
    id 318
    label "U:Novel-4128_00011#3"
    kind "unit"
    chunk_id "Novel-4128_00011"
    text "On the 12th, Wednesday, a day observed as both a fast and a feast because the Bishops were not ready to keep the fast due to foul weather before fair weather arrived, so they were forced to keep it between the two conditions."
    community 21
  ]
  node [
    id 319
    label "E:12TH"
    kind "entity"
    name "12TH"
    community 21
  ]
  node [
    id 320
    label "E:WEDNESDAY"
    kind "entity"
    name "WEDNESDAY"
    community 21
  ]
  node [
    id 321
    label "E:BISHOPS"
    kind "entity"
    name "BISHOPS"
    community 21
  ]
  node [
    id 322
    label "E:FAST"
    kind "entity"
    name "FAST"
    community 21
  ]
  node [
    id 323
    label "E:FEAST"
    kind "entity"
    name "FEAST"
    community 21
  ]
  node [
    id 324
    label "E:FOUL WEATHER"
    kind "entity"
    name "FOUL WEATHER"
    community 21
  ]
  node [
    id 325
    label "E:FAIR WEATHER"
    kind "entity"
    name "FAIR WEATHER"
    community 21
  ]
  node [
    id 326
    label "E:FAST AND FEAST"
    kind "entity"
    name "FAST AND FEAST"
    community 21
  ]
  node [
    id 327
    label "C:Novel-4128_00012"
    kind "chunk"
    chunk_id "Novel-4128_00012"
  ]
  node [
    id 328
    label "U:Novel-4128_00012#0"
    kind "unit"
    chunk_id "Novel-4128_00012"
    text "A Form of Prayer was published for use in London on the 12th and in the country on the 19th of June, designated as special days for a general fast to avert sickness, dearth, and scarcity caused by late immoderate rain and flooding, and for thanksgiving for a blessed change in weather, with a request for the continuation of this favorable weather for comfort, and for a blessing upon the High Court of Parliament now assembled by his Majesty's authority. A sermon was preached before the Commons by Thomas Greenfield, the preacher of Lincoln's Inn. The Lords taxed themselves for the poor, with an earl paying 30s. and a baron paying 20s. Those who were absent from prayers were to pay a forfeit."
    community 5
  ]
  node [
    id 329
    label "E:FORM OF PRAYER"
    kind "entity"
    name "FORM OF PRAYER"
    community 5
  ]
  node [
    id 330
    label "E:LONDON"
    kind "entity"
    name "LONDON"
    community 5
  ]
  node [
    id 331
    label "E:12TH OF JUNE"
    kind "entity"
    name "12TH OF JUNE"
    community 5
  ]
  node [
    id 332
    label "E:COUNTRY"
    kind "entity"
    name "COUNTRY"
    community 3
  ]
  node [
    id 333
    label "E:19TH OF JUNE"
    kind "entity"
    name "19TH OF JUNE"
    community 5
  ]
  node [
    id 334
    label "E:GENERAL FAST"
    kind "entity"
    name "GENERAL FAST"
    community 5
  ]
  node [
    id 335
    label "E:SICKNESSES AND DISEASES"
    kind "entity"
    name "SICKNESSES AND DISEASES"
    community 5
  ]
  node [
    id 336
    label "E:DEARTH AND SCARCITY"
    kind "entity"
    name "DEARTH AND SCARCITY"
    community 5
  ]
  node [
    id 337
    label "E:LATE IMMODERATE RAIN AND WATER"
    kind "entity"
    name "LATE IMMODERATE RAIN AND WATER"
    community 5
  ]
  node [
    id 338
    label "E:THANKSGIVING"
    kind "entity"
    name "THANKSGIVING"
    community 5
  ]
  node [
    id 339
    label "E:BLESSED CHANGE OF WEATHER"
    kind "entity"
    name "BLESSED CHANGE OF WEATHER"
    community 5
  ]
  node [
    id 340
    label "E:CONTINUANCE OF WEATHER"
    kind "entity"
    name "CONTINUANCE OF WEATHER"
    community 5
  ]
  node [
    id 341
    label "E:HIGH COURT OF PARLIAMENT"
    kind "entity"
    name "HIGH COURT OF PARLIAMENT"
    community 5
  ]
  node [
    id 342
    label "E:HIS MAJESTY'S AUTHORITY"
    kind "entity"
    name "HIS MAJESTY'S AUTHORITY"
    community 5
  ]
  node [
    id 343
    label "E:THOMAS GREENFIELD"
    kind "entity"
    name "THOMAS GREENFIELD"
    community 5
  ]
  node [
    id 344
    label "E:LINCOLN'S INN"
    kind "entity"
    name "LINCOLN'S INN"
    community 5
  ]
  node [
    id 345
    label "E:LORDS"
    kind "entity"
    name "LORDS"
    community 5
  ]
  node [
    id 346
    label "E:EARL"
    kind "entity"
    name "EARL"
    community 5
  ]
  node [
    id 347
    label "E:30S"
    kind "entity"
    name "30S"
    community 5
  ]
  node [
    id 348
    label "E:BARON"
    kind "entity"
    name "BARON"
    community 5
  ]
  node [
    id 349
    label "E:20S"
    kind "entity"
    name "20S"
    community 5
  ]
  node [
    id 350
    label "E:ABSENT FROM PRAYERS"
    kind "entity"
    name "ABSENT FROM PRAYERS"
    community 5
  ]
  node [
    id 351
    label "E:FORFEIT"
    kind "entity"
    name "FORFEIT"
    community 5
  ]
  node [
    id 352
    label "E:COMFORT"
    kind "entity"
    name "COMFORT"
    community 5
  ]
  node [
    id 353
    label "E:BLESSED HIGH COURT OF PARLIAMENT"
    kind "entity"
    name "BLESSED HIGH COURT OF PARLIAMENT"
    community 5
  ]
  node [
    id 354
    label "E:COMMONS"
    kind "entity"
    name "COMMONS"
    community 5
  ]
  node [
    id 355
    label "E:POOR"
    kind "entity"
    name "POOR"
    community 5
  ]
  node [
    id 356
    label "U:Novel-4128_00012#1"
    kind "unit"
    chunk_id "Novel-4128_00012"
    text "The narrator went to Whitehall, where they met Captain Rolt and Ferrers, and then went to Lambeth to drink their morning draft. At the Three Mariners, a place known for its ale, they stayed awhile and were very merry. Then, lacking a boat, they found Captain Bun going down the river and joined him in his boat, which carried a lady with him; they were landed at Westminster and the narrator at the Bridge."
    community 0
  ]
  node [
    id 357
    label "E:CAPTAIN ROLT"
    kind "entity"
    name "CAPTAIN ROLT"
    community 9
  ]
  node [
    id 358
    label "E:FERRERS"
    kind "entity"
    name "FERRERS"
    community 0
  ]
  node [
    id 359
    label "E:LAMBETH"
    kind "entity"
    name "LAMBETH"
    community 0
  ]
  node [
    id 360
    label "E:THREE MARINERS"
    kind "entity"
    name "THREE MARINERS"
    community 0
  ]
  node [
    id 361
    label "E:ALE"
    kind "entity"
    name "ALE"
    community 0
  ]
  node [
    id 362
    label "E:MORNING DRAFT"
    kind "entity"
    name "MORNING DRAFT"
    community 10
  ]
  node [
    id 363
    label "E:CAPTAIN BUN"
    kind "entity"
    name "CAPTAIN BUN"
    community 0
  ]
  node [
    id 364
    label "E:CAPTAIN BUN'S BOAT"
    kind "entity"
    name "CAPTAIN BUN'S BOAT"
    community 0
  ]
  node [
    id 365
    label "C:Novel-4128_00013"
    kind "chunk"
    chunk_id "Novel-4128_00013"
  ]
  node [
    id 366
    label "U:Novel-4128_00013#0"
    kind "unit"
    chunk_id "Novel-4128_00013"
    text "At home all day with workmen, the narrator wrote a letter resolved of yesterday to the Duke. Then went to White Hall, where they met the Lord, who instructed him to lay out L300 in cloth for presents among the Turks, which made the narrator very glad. After supper, went to Sir R. Slingsby, who with his brother and the narrator visited the Lord at the Wardrobe, staying a long time; the Lord stayed out late and left, and later the Lord came in, and the narrator stayed with him a good while, then went to bed with Mr. Moore in his chamber."
    community 9
  ]
  node [
    id 367
    label "E:WORKMEN"
    kind "entity"
    name "WORKMEN"
    community 12
  ]
  node [
    id 368
    label "E:DUKE"
    kind "entity"
    name "DUKE"
    community 17
  ]
  node [
    id 369
    label "E:L300"
    kind "entity"
    name "L300"
    community 9
  ]
  node [
    id 370
    label "E:CLOTH"
    kind "entity"
    name "CLOTH"
    community 9
  ]
  node [
    id 371
    label "E:BARBARY"
    kind "entity"
    name "BARBARY"
    community 9
  ]
  node [
    id 372
    label "E:TURKS"
    kind "entity"
    name "TURKS"
    community 9
  ]
  node [
    id 373
    label "E:SUPPER"
    kind "entity"
    name "SUPPER"
    community 1
  ]
  node [
    id 374
    label "E:MR. SHAW"
    kind "entity"
    name "MR. SHAW"
    community 9
  ]
  node [
    id 375
    label "E:L300 IN CLOTH"
    kind "entity"
    name "L300 IN CLOTH"
    community 9
  ]
  node [
    id 376
    label "E:GETTING SOMETHING"
    kind "entity"
    name "GETTING SOMETHING"
    community 9
  ]
  node [
    id 377
    label "E:THEIR FRIENDS"
    kind "entity"
    name "THEIR FRIENDS"
    community 9
  ]
  node [
    id 378
    label "E:LATER"
    kind "entity"
    name "LATER"
    community 9
  ]
  node [
    id 379
    label "U:Novel-4128_00013#1"
    kind "unit"
    chunk_id "Novel-4128_00013"
    text "On the 13th, the narrator went up and down to Alderman Backwell's, but found his servants not up, so went home, put on a gray cloth suit and white coat made from one of his wife's pettycoates, the first time wearing it, and dressed in riding garb to speak with Mr. Shaw at the Alderman's, who offered L300 if the Lord agreed to buy the cloth with, which pleased the narrator. Then went to the Wardrobe and got the Lord to order Mr. Creed to imprest the amount to be paid by Alderman Backwell."
    community 9
  ]
  node [
    id 380
    label "E:13TH"
    kind "entity"
    name "13TH"
    community 21
  ]
  node [
    id 381
    label "E:SERVANTS"
    kind "entity"
    name "SERVANTS"
    community 11
  ]
  node [
    id 382
    label "E:GRAY CLOTH SUIT"
    kind "entity"
    name "GRAY CLOTH SUIT"
    community 9
  ]
  node [
    id 383
    label "E:WHITE COAT"
    kind "entity"
    name "WHITE COAT"
    community 9
  ]
  node [
    id 384
    label "E:WIFE'S PETTYCOATES"
    kind "entity"
    name "WIFE'S PETTYCOATES"
    community 9
  ]
  node [
    id 385
    label "E:RIDING GARB"
    kind "entity"
    name "RIDING GARB"
    community 9
  ]
  node [
    id 386
    label "E:IMPREST"
    kind "entity"
    name "IMPREST"
    community 9
  ]
  node [
    id 387
    label "E:PAYMENT"
    kind "entity"
    name "PAYMENT"
    community 9
  ]
  node [
    id 388
    label "E:ALDERMAN BACKWELL'S"
    kind "entity"
    name "ALDERMAN BACKWELL'S"
    community 9
  ]
  node [
    id 389
    label "E:MR. SHAW'S OFFER"
    kind "entity"
    name "MR. SHAW'S OFFER"
    community 9
  ]
  node [
    id 390
    label "C:Novel-4128_00014"
    kind "chunk"
    chunk_id "Novel-4128_00014"
  ]
  node [
    id 391
    label "U:Novel-4128_00014#0"
    kind "unit"
    chunk_id "Novel-4128_00014"
    text "Creed was told by Alderman Backwell to be paid. My Lord traveled to Whitehall by water, took leave of the King, and arrived at his lodgings where he met Sir R. Slingsby at the garden stairs. Sir R. Slingsby took his leave of my Lord, who thanked him for his kindness, a gesture that pleased Sir Robert. My Lord then went with Creed in a barge to Deptford, where they boarded a Dutch yacht and stayed for a while. W. Howe did not arrive with my Lord's things, which made my Lord very angry. Later, W. Howe arrived, and they set sail. Afterward, my Lord and Creed dined together and were very merry. After dinner, Creed went below and sang, then took leave of W. Howe, Captain Rolt, and other friends. He then went up and took leave of my Lord, who gave him his hand and parted with great respect. Creed then went with Captain Ferrers to their wherry, and my Lord gave five fully charged guns, the greatest respect he could show, which made Creed proud."
    community 9
  ]
  node [
    id 392
    label "E:CREED"
    kind "entity"
    name "CREED"
    community 9
  ]
  node [
    id 393
    label "E:GARDEN STAIRS"
    kind "entity"
    name "GARDEN STAIRS"
    community 9
  ]
  node [
    id 394
    label "E:DUTCH YACHT"
    kind "entity"
    name "DUTCH YACHT"
    community 9
  ]
  node [
    id 395
    label "E:CAPTAIN FERRERS"
    kind "entity"
    name "CAPTAIN FERRERS"
    community 10
  ]
  node [
    id 396
    label "E:FIVE GUNS"
    kind "entity"
    name "FIVE GUNS"
    community 9
  ]
  node [
    id 397
    label "E:WHERRY"
    kind "entity"
    name "WHERRY"
    community 7
  ]
  node [
    id 398
    label "E:HIS LODGINGS"
    kind "entity"
    name "HIS LODGINGS"
    community 9
  ]
  node [
    id 399
    label "E:MY LORD'S THINGS"
    kind "entity"
    name "MY LORD'S THINGS"
    community 9
  ]
  node [
    id 400
    label "E:W. HOWE DID NOT ARRIVE"
    kind "entity"
    name "W. HOWE DID NOT ARRIVE"
    community 9
  ]
  node [
    id 401
    label "E:OTHER FRIENDS"
    kind "entity"
    name "OTHER FRIENDS"
    community 9
  ]
  node [
    id 402
    label "C:Novel-4128_00015"
    kind "chunk"
    chunk_id "Novel-4128_00015"
  ]
  node [
    id 403
    label "U:Novel-4128_00015#0"
    kind "unit"
    chunk_id "Novel-4128_00015"
    text "The narrator left Erith with a sad and merry heart, hoping to reach the Downs tomorrow early, and traveled toward London by boat. They pulled off their stockings and bathed their legs for a long time in the river, a practice they had not done in some years. After reaching Greenwich, they intended to board the King's yacht, but the King was already on board, so they passed by. At Woolwich, they went ashore with Captain Poole of Jamaica, young Mr. Kennersley, and many others, and then went to a tavern where they drank a great deal of wine and beer. They parted from the group and returned home with Mr. Falconer, who gave them cherries and good wine. Later, they returned to the boat, where young Poole took them on board the Charity and served them wine, which the narrator consumed fully. They then returned to their wherry, where they fell asleep until nearly reaching the Tower. At the Tower, the narrator parted from the Captain and returned home, where they drank enough wine to be drunk and went to bed."
    community 7
  ]
  node [
    id 404
    label "E:ERITH"
    kind "entity"
    name "ERITH"
    community 7
  ]
  node [
    id 405
    label "E:DOWNS"
    kind "entity"
    name "DOWNS"
    community 7
  ]
  node [
    id 406
    label "E:KING'S YACHT"
    kind "entity"
    name "KING'S YACHT"
    community 7
  ]
  node [
    id 407
    label "E:YOUNG MR. KENNERSLEY"
    kind "entity"
    name "YOUNG MR. KENNERSLEY"
    community 7
  ]
  node [
    id 408
    label "E:TAVERN"
    kind "entity"
    name "TAVERN"
    community 19
  ]
  node [
    id 409
    label "E:BEER"
    kind "entity"
    name "BEER"
    community 7
  ]
  node [
    id 410
    label "E:MR. FALCONER"
    kind "entity"
    name "MR. FALCONER"
    community 7
  ]
  node [
    id 411
    label "E:CHARITY"
    kind "entity"
    name "CHARITY"
    community 7
  ]
  node [
    id 412
    label "E:TOWER"
    kind "entity"
    name "TOWER"
    community 7
  ]
  node [
    id 413
    label "E:RIVER"
    kind "entity"
    name "RIVER"
    community 7
  ]
  node [
    id 414
    label "E:SOME YEARS BEFORE"
    kind "entity"
    name "SOME YEARS BEFORE"
    community 7
  ]
  node [
    id 415
    label "E:CHERRIES"
    kind "entity"
    name "CHERRIES"
    community 7
  ]
  node [
    id 416
    label "E:GOOD WINE"
    kind "entity"
    name "GOOD WINE"
    community 7
  ]
  node [
    id 417
    label "E:BOAT"
    kind "entity"
    name "BOAT"
    community 7
  ]
  node [
    id 418
    label "E:YOUNG POOLE"
    kind "entity"
    name "YOUNG POOLE"
    community 7
  ]
  node [
    id 419
    label "E:CAPTAIN"
    kind "entity"
    name "CAPTAIN"
    community 6
  ]
  node [
    id 420
    label "E:HEAD"
    kind "entity"
    name "HEAD"
    community 7
  ]
  node [
    id 421
    label "E:MR. EDWARD MONTAGU"
    kind "entity"
    name "MR. EDWARD MONTAGU"
    community 7
  ]
  node [
    id 422
    label "E:MR. EDWARD MONTAGU'S FAMILY"
    kind "entity"
    name "MR. EDWARD MONTAGU'S FAMILY"
    community 7
  ]
  node [
    id 423
    label "E:SHIP"
    kind "entity"
    name "SHIP"
    community 7
  ]
  node [
    id 424
    label "E:TRIANGLE VIRGINAL"
    kind "entity"
    name "TRIANGLE VIRGINAL"
    community 7
  ]
  node [
    id 425
    label "U:Novel-4128_00015#1"
    kind "unit"
    chunk_id "Novel-4128_00015"
    text "On the 14th, the narrator went to Whitehall to Mr. Edward Montagu's house, where they found Mr. Edward Montagu and his family staying due to the Lord's absence. The narrator sent a ship and a triangle virginall to the house by the Lord's order. The word 'shipp' was omitted in the original text."
    community 7
  ]
  node [
    id 426
    label "E:14TH"
    kind "entity"
    name "14TH"
    community 3
  ]
  node [
    id 427
    label "C:Novel-4128_00016"
    kind "chunk"
    chunk_id "Novel-4128_00016"
  ]
  node [
    id 428
    label "U:Novel-4128_00016#0"
    kind "unit"
    chunk_id "Novel-4128_00016"
    text "After playing the fool in the water the previous day, the narrator got a great cold and experienced great pain, so he went home by coach to bed and did not go to the office. By keeping himself warm, he broke wind and found some relief. He then ate supper and went to bed again."
    community 1
  ]
  node [
    id 429
    label "E:GREAT COLD"
    kind "entity"
    name "GREAT COLD"
    community 1
  ]
  node [
    id 430
    label "E:PLAYING THE FOOL IN THE WATER"
    kind "entity"
    name "PLAYING THE FOOL IN THE WATER"
    community 1
  ]
  node [
    id 431
    label "E:COACH"
    kind "entity"
    name "COACH"
    community 10
  ]
  node [
    id 432
    label "E:BREAKING WIND"
    kind "entity"
    name "BREAKING WIND"
    community 1
  ]
  node [
    id 433
    label "E:KEEPING HIMSELF WARM"
    kind "entity"
    name "KEEPING HIMSELF WARM"
    community 1
  ]
  node [
    id 434
    label "U:Novel-4128_00016#1"
    kind "unit"
    chunk_id "Novel-4128_00016"
    text "On the 15th, the narrator's father came and drank his morning draft with him, sat with him until he was ready, and they discussed the business of the cloth. Later, the narrator left his father to dine with his Lady, who, after her Lord left, returned to her poor housekeeping. Then he went to his father's house, where his father informed him of his actions, and they decided to buy two pieces of scarlet, two of purple, two of black, and L50 in linen."
    community 10
  ]
  node [
    id 435
    label "E:BUSINESS OF THE CLOTH"
    kind "entity"
    name "BUSINESS OF THE CLOTH"
    community 10
  ]
  node [
    id 436
    label "E:15TH"
    kind "entity"
    name "15TH"
    community 17
  ]
  node [
    id 437
    label "E:TWO PIECES OF SCARLET"
    kind "entity"
    name "TWO PIECES OF SCARLET"
    community 10
  ]
  node [
    id 438
    label "E:TWO PIECES OF PURPLE"
    kind "entity"
    name "TWO PIECES OF PURPLE"
    community 10
  ]
  node [
    id 439
    label "E:TWO PIECES OF BLACK"
    kind "entity"
    name "TWO PIECES OF BLACK"
    community 10
  ]
  node [
    id 440
    label "E:L50 IN LINEN"
    kind "entity"
    name "L50 IN LINEN"
    community 10
  ]
  node [
    id 441
    label "E:POOR HOUSEKEEPING"
    kind "entity"
    name "POOR HOUSEKEEPING"
    community 10
  ]
  node [
    id 442
    label "C:Novel-4128_00017"
    kind "chunk"
    chunk_id "Novel-4128_00017"
  ]
  node [
    id 443
    label "U:Novel-4128_00017#0"
    kind "unit"
    chunk_id "Novel-4128_00017"
    text "The narrator took L300 home from Alderman Backwell's, wrote to their Lord to inform him of the action, and planned to go to bed. However, the purser of the King's yacht arrived and agreed to stowage for the items, after which the narrator went to bed and instructed Will to fetch the items from the carrier's hither, which were brought to the house around 12 o'clock and left there all night. On the 16th (Lord's day), the purser did not arrive in the morning, and the narrator learned that the Duke had gone the previous night, leaving them in a great loss of what to do. That day, despite it being the Lord's day, the narrator stayed at home and sent Will to inquire about the situation. They considered continuing their original plan to send the items by carrier to Deal on Wednesday next, or sending them by sea via a special vessel, but had not yet reached a decision and were in great mental trouble over the matter. In the afternoon, while Will was away, the narrator spent time reading 'The Spanish Gypsey,' a play they considered not very good though it was much commended."
    community 9
  ]
  node [
    id 444
    label "E:PURSER OF THE KING'S YACHT"
    kind "entity"
    name "PURSER OF THE KING'S YACHT"
    community 9
  ]
  node [
    id 445
    label "E:DEAL"
    kind "entity"
    name "DEAL"
    community 9
  ]
  node [
    id 446
    label "E:WILL"
    kind "entity"
    name "WILL"
    community 11
  ]
  node [
    id 447
    label "E:CARRIER"
    kind "entity"
    name "CARRIER"
    community 9
  ]
  node [
    id 448
    label "E:16TH"
    kind "entity"
    name "16TH"
    community 0
  ]
  node [
    id 449
    label "E:LORD'S DAY"
    kind "entity"
    name "LORD'S DAY"
    community 15
  ]
  node [
    id 450
    label "E:12 O'CLOCK"
    kind "entity"
    name "12 O'CLOCK"
    community 4
  ]
  node [
    id 451
    label "E:SPANISH GYPSEY"
    kind "entity"
    name "SPANISH GYPSEY"
    community 11
  ]
  node [
    id 452
    label "E:AFTER WRITING TO LORD"
    kind "entity"
    name "AFTER WRITING TO LORD"
    community 9
  ]
  node [
    id 453
    label "E:L300 FROM CARRIER'S HITHER"
    kind "entity"
    name "L300 FROM CARRIER'S HITHER"
    community 9
  ]
  node [
    id 454
    label "E:NARRATOR'S HOUSE"
    kind "entity"
    name "NARRATOR'S HOUSE"
    community 9
  ]
  node [
    id 455
    label "E:AT NARRATOR'S HOUSE"
    kind "entity"
    name "AT NARRATOR'S HOUSE"
    community 9
  ]
  node [
    id 456
    label "E:DUKE OF YORK WENT THE PREVIOUS NIGHT"
    kind "entity"
    name "DUKE OF YORK WENT THE PREVIOUS NIGHT"
    community 9
  ]
  node [
    id 457
    label "E:WHAT TO DO"
    kind "entity"
    name "WHAT TO DO"
    community 9
  ]
  node [
    id 458
    label "E:ON 16TH"
    kind "entity"
    name "ON 16TH"
    community 9
  ]
  node [
    id 459
    label "E:ABOUT WHAT TO DO"
    kind "entity"
    name "ABOUT WHAT TO DO"
    community 9
  ]
  node [
    id 460
    label "E:DEAL ON WEDNESDAY NEXT"
    kind "entity"
    name "DEAL ON WEDNESDAY NEXT"
    community 9
  ]
  node [
    id 461
    label "E:SPECIAL VESSEL"
    kind "entity"
    name "SPECIAL VESSEL"
    community 9
  ]
  node [
    id 462
    label "U:Novel-4128_00017#1"
    kind "unit"
    chunk_id "Novel-4128_00017"
    text "The narrator read 'The Spanish Gypsey,' a play that was commended much but considered not very good, during the afternoon while Will was away."
    community 11
  ]
  node [
    id 463
    label "C:Novel-4128_00018"
    kind "chunk"
    chunk_id "Novel-4128_00018"
  ]
  node [
    id 464
    label "U:Novel-4128_00018#0"
    kind "unit"
    chunk_id "Novel-4128_00018"
    text "The speaker resolved to hire a Margate Hoy who was to leave the next morning, and sent the items with him, placing them on board around 12 at night, hoping the wind in the Downs would serve well the following night so the items could be delivered."
    community 7
  ]
  node [
    id 465
    label "E:MARGATE HOY"
    kind "entity"
    name "MARGATE HOY"
    community 7
  ]
  node [
    id 466
    label "E:12"
    kind "entity"
    name "12"
    community 7
  ]
  node [
    id 467
    label "E:WIND"
    kind "entity"
    name "WIND"
    community 7
  ]
  node [
    id 468
    label "E:NEXT MORNING"
    kind "entity"
    name "NEXT MORNING"
    community 7
  ]
  node [
    id 469
    label "E:ITEMS"
    kind "entity"
    name "ITEMS"
    community 7
  ]
  node [
    id 470
    label "E:DELIVERY OF ITEMS"
    kind "entity"
    name "DELIVERY OF ITEMS"
    community 7
  ]
  node [
    id 471
    label "U:Novel-4128_00018#1"
    kind "unit"
    chunk_id "Novel-4128_00018"
    text "On the 17th, the speaker was visited in the morning by their old friend Mr. Ch. Carter, who stayed and went to Westminster with them, and they parted there; the speaker then went to the Wardrobe and dined with my Lady, returned home to their painters who were painting the stairs, went to the office, and at night all went to Sir W. Pen's where they sat and drank until 11 at night before returning home and to bed."
    community 0
  ]
  node [
    id 472
    label "E:MR. CH. CARTER"
    kind "entity"
    name "MR. CH. CARTER"
    community 0
  ]
  node [
    id 473
    label "E:17TH"
    kind "entity"
    name "17TH"
    community 0
  ]
  node [
    id 474
    label "E:PAINTERS"
    kind "entity"
    name "PAINTERS"
    community 0
  ]
  node [
    id 475
    label "E:STAIRS"
    kind "entity"
    name "STAIRS"
    community 0
  ]
  node [
    id 476
    label "E:11 AT NIGHT"
    kind "entity"
    name "11 AT NIGHT"
    community 0
  ]
  node [
    id 477
    label "U:Novel-4128_00018#2"
    kind "unit"
    chunk_id "Novel-4128_00018"
    text "The passage ends on the 18th, with no further details provided."
    community 0
  ]
  node [
    id 478
    label "E:18TH"
    kind "entity"
    name "18TH"
    community 0
  ]
  node [
    id 479
    label "C:Novel-4128_00019"
    kind "chunk"
    chunk_id "Novel-4128_00019"
  ]
  node [
    id 480
    label "U:Novel-4128_00019#0"
    kind "unit"
    chunk_id "Novel-4128_00019"
    text "On the 18th, Pen's and drank until 11 at night, then went home and to bed. All morning at home, the narrator was vexed by the delay of the painters. In the afternoon, the narrator and his wife went by water to Captain Lambert's, where they enjoyed his turret-garden and saw the fine needleworks of his wife, which the narrator considered the best he had ever seen. They then had a pleasant treat with good musique played on the harpsicon and stayed until 8 at night. A little witty child in the house would not let them go and began crying by the water-side. Afterward, they returned home, where the narrator met Jack Cole, who stayed with him for a good while and remained in the old good humour from their school days. The narrator is glad to see him. After Jack Cole left, the narrator went to bed. On the 19th, almost all morning at home, the narrator saw that his stairs were finished by the painters, which pleased him well. Then he went with Mr."
    community 0
  ]
  node [
    id 481
    label "E:PEN'S"
    kind "entity"
    name "PEN'S"
    community 0
  ]
  node [
    id 482
    label "E:CAPTAIN LAMBERT'S"
    kind "entity"
    name "CAPTAIN LAMBERT'S"
    community 0
  ]
  node [
    id 483
    label "E:TURRET-GARDEN"
    kind "entity"
    name "TURRET-GARDEN"
    community 0
  ]
  node [
    id 484
    label "E:NEEDLE-WORKS"
    kind "entity"
    name "NEEDLE-WORKS"
    community 0
  ]
  node [
    id 485
    label "E:HARPSICON"
    kind "entity"
    name "HARPSICON"
    community 0
  ]
  node [
    id 486
    label "E:MUSIQUE"
    kind "entity"
    name "MUSIQUE"
    community 20
  ]
  node [
    id 487
    label "E:8 AT NIGHT"
    kind "entity"
    name "8 AT NIGHT"
    community 0
  ]
  node [
    id 488
    label "E:WITTY CHILD"
    kind "entity"
    name "WITTY CHILD"
    community 0
  ]
  node [
    id 489
    label "E:JACK COLE"
    kind "entity"
    name "JACK COLE"
    community 0
  ]
  node [
    id 490
    label "E:19TH"
    kind "entity"
    name "19TH"
    community 0
  ]
  node [
    id 491
    label "E:WIFE OF CAPTAIN LAMBERT"
    kind "entity"
    name "WIFE OF CAPTAIN LAMBERT"
    community 0
  ]
  node [
    id 492
    label "E:WATER-SIDE"
    kind "entity"
    name "WATER-SIDE"
    community 0
  ]
  node [
    id 493
    label "E:OLD GOOD HUMOUR"
    kind "entity"
    name "OLD GOOD HUMOUR"
    community 0
  ]
  node [
    id 494
    label "U:Novel-4128_00019#1"
    kind "unit"
    chunk_id "Novel-4128_00019"
    text "The narrator, on the 19th, saw that his stairs were finished by the painters, which pleased him well, and then went with Mr."
    community 0
  ]
  node [
    id 495
    label "C:Novel-4128_00020"
    kind "chunk"
    chunk_id "Novel-4128_00020"
  ]
  node [
    id 496
    label "U:Novel-4128_00020#0"
    kind "unit"
    chunk_id "Novel-4128_00020"
    text "Mr. Moore goes to Westminster Hall during term, then travels by water to the Wardrobe where he spends the afternoon, and returns home. That night, he visits the Exchange to speak with his uncle Wight about his intention to purchase something at Brampton, then returns home and goes to bed. He is grateful to God for being well again from his previous pain and hopes to be free from the pain of dirt and trouble in his house, which he now finds very wearying. He notes that he has become the most negligent man in the world regarding news, to the point that he neither knows nor asks others about current events."
    community 12
  ]
  node [
    id 497
    label "E:WESTMINSTER HALL"
    kind "entity"
    name "WESTMINSTER HALL"
    community 12
  ]
  node [
    id 498
    label "E:EXCHANGE"
    kind "entity"
    name "EXCHANGE"
    community 12
  ]
  node [
    id 499
    label "E:UNCLE WIGHT"
    kind "entity"
    name "UNCLE WIGHT"
    community 3
  ]
  node [
    id 500
    label "E:BRAMPTON"
    kind "entity"
    name "BRAMPTON"
    community 11
  ]
  node [
    id 501
    label "E:PAIN"
    kind "entity"
    name "PAIN"
    community 17
  ]
  node [
    id 502
    label "E:DIRT AND TROUBLE"
    kind "entity"
    name "DIRT AND TROUBLE"
    community 12
  ]
  node [
    id 503
    label "E:NEWS"
    kind "entity"
    name "NEWS"
    community 12
  ]
  node [
    id 504
    label "E:SAMSON IN PAUL'S CHURCHYARD"
    kind "entity"
    name "SAMSON IN PAUL'S CHURCHYARD"
    community 12
  ]
  node [
    id 505
    label "E:GAMMON OF BACON"
    kind "entity"
    name "GAMMON OF BACON"
    community 12
  ]
  node [
    id 506
    label "E:GREEN SAY"
    kind "entity"
    name "GREEN SAY"
    community 12
  ]
  node [
    id 507
    label "E:PARLER"
    kind "entity"
    name "PARLER"
    community 12
  ]
  node [
    id 508
    label "E:DIRT AND TROUBLE IN HIS HOUSE"
    kind "entity"
    name "DIRT AND TROUBLE IN HIS HOUSE"
    community 12
  ]
  node [
    id 509
    label "E:WORKMEN COMPLETING WORK"
    kind "entity"
    name "WORKMEN COMPLETING WORK"
    community 12
  ]
  node [
    id 510
    label "E:CURTAINS IN PARLER"
    kind "entity"
    name "CURTAINS IN PARLER"
    community 12
  ]
  node [
    id 511
    label "U:Novel-4128_00020#1"
    kind "unit"
    chunk_id "Novel-4128_00020"
    text "On the 20th, Mr. Moore spends most of the day at home supervising his workmen, who finish their work that night to his great satisfaction. On the 21st, he goes to his father's house, meets him, and they go to the Samson in Paul's Churchyard where they drink their morning draft, eat gammon of bacon, and then part ways after buying green say for curtains in his parlour."
    community 12
  ]
  node [
    id 512
    label "E:20TH"
    kind "entity"
    name "20TH"
    community 11
  ]
  node [
    id 513
    label "E:21ST"
    kind "entity"
    name "21ST"
    community 12
  ]
  node [
    id 514
    label "E:PARLOR"
    kind "entity"
    name "PARLOR"
    community 12
  ]
  node [
    id 515
    label "E:CURTAINS IN PARLOUR"
    kind "entity"
    name "CURTAINS IN PARLOUR"
    community 12
  ]
  node [
    id 516
    label "C:Novel-4128_00021"
    kind "chunk"
    chunk_id "Novel-4128_00021"
  ]
  node [
    id 517
    label "U:Novel-4128_00021#0"
    kind "unit"
    chunk_id "Novel-4128_00021"
    text "Saye clothe serge for curtains in my parler. At home, the speaker meets with his uncle Wight at the Exchequer, then returns with him to dinner where, with Mr. Norbury present and his aunt out of town, they discuss Mr. Norbury's wife's house and land at Brampton, which the speaker finds too expensive to buy. In the afternoon, the speaker goes to the office and is pleased that his house has begun to be clean after all the dirt."
    community 12
  ]
  node [
    id 518
    label "E:SAYE"
    kind "entity"
    name "SAYE"
    community 12
  ]
  node [
    id 519
    label "E:SERGE"
    kind "entity"
    name "SERGE"
    community 12
  ]
  node [
    id 520
    label "E:CURTAINS"
    kind "entity"
    name "CURTAINS"
    community 12
  ]
  node [
    id 521
    label "E:EXCHEQUER"
    kind "entity"
    name "EXCHEQUER"
    community 12
  ]
  node [
    id 522
    label "E:MR. NORBURY"
    kind "entity"
    name "MR. NORBURY"
    community 12
  ]
  node [
    id 523
    label "E:LAND"
    kind "entity"
    name "LAND"
    community 2
  ]
  node [
    id 524
    label "E:22ND"
    kind "entity"
    name "22ND"
    community 19
  ]
  node [
    id 525
    label "E:HOUSE CLEANING"
    kind "entity"
    name "HOUSE CLEANING"
    community 14
  ]
  node [
    id 526
    label "E:ALL THE DIRT"
    kind "entity"
    name "ALL THE DIRT"
    community 12
  ]
  node [
    id 527
    label "U:Novel-4128_00021#1"
    kind "unit"
    chunk_id "Novel-4128_00021"
    text "On the 22nd, the speaker is abroad all morning handling various business matters. At noon, the speaker dines with Lord Crew, who greatly favors him and his lady. Afterward, the speaker goes to the Theatre to see 'The Alchymist,' a comedy by Ben Jonson first printed in 1612, which is described as a most incomparable play. Then the speaker meets with little Luellin and Blirton, who take him to a friend of theirs, Mr. Hodges, in Lincoln's Inn Fields, where they drink large amounts of Rhenish wine and are very merry. The speaker returns home and finds his house now very clean, which brings great contentment."
    community 14
  ]
  node [
    id 528
    label "E:ABROAD"
    kind "entity"
    name "ABROAD"
    community 14
  ]
  node [
    id 529
    label "E:BUSINESSES"
    kind "entity"
    name "BUSINESSES"
    community 14
  ]
  node [
    id 530
    label "E:LORD CREW"
    kind "entity"
    name "LORD CREW"
    community 14
  ]
  node [
    id 531
    label "E:LORD CREW'S LADY"
    kind "entity"
    name "LORD CREW'S LADY"
    community 14
  ]
  node [
    id 532
    label "E:ALCHYMIST"
    kind "entity"
    name "ALCHYMIST"
    community 14
  ]
  node [
    id 533
    label "E:BEN JONSON"
    kind "entity"
    name "BEN JONSON"
    community 14
  ]
  node [
    id 534
    label "E:1612"
    kind "entity"
    name "1612"
    community 14
  ]
  node [
    id 535
    label "E:LITTLE LUELLIN"
    kind "entity"
    name "LITTLE LUELLIN"
    community 14
  ]
  node [
    id 536
    label "E:BLIRTON"
    kind "entity"
    name "BLIRTON"
    community 14
  ]
  node [
    id 537
    label "E:MR. HODGES"
    kind "entity"
    name "MR. HODGES"
    community 14
  ]
  node [
    id 538
    label "E:LINCOLN'S INN FIELDS"
    kind "entity"
    name "LINCOLN'S INN FIELDS"
    community 14
  ]
  node [
    id 539
    label "E:RHENISH WINE"
    kind "entity"
    name "RHENISH WINE"
    community 14
  ]
  node [
    id 540
    label "E:MERRY"
    kind "entity"
    name "MERRY"
    community 14
  ]
  node [
    id 541
    label "U:Novel-4128_00021#2"
    kind "unit"
    chunk_id "Novel-4128_00021"
    text "On the 23rd, which is Lord's day, the speaker goes to church in the morning. Because his wife is not well, the speaker goes with Sir W. Batten home to dinner, with his lady being out of town, where there is Sir W."
    community 15
  ]
  node [
    id 542
    label "E:23RD"
    kind "entity"
    name "23RD"
    community 4
  ]
  node [
    id 543
    label "E:SIR W. BATTEN"
    kind "entity"
    name "SIR W. BATTEN"
    community 17
  ]
  node [
    id 544
    label "E:SIR W."
    kind "entity"
    name "SIR W."
    community 15
  ]
  node [
    id 545
    label "E:WIFE NOT WELL"
    kind "entity"
    name "WIFE NOT WELL"
    community 15
  ]
  node [
    id 546
    label "C:Novel-4128_00022"
    kind "chunk"
    chunk_id "Novel-4128_00022"
  ]
  node [
    id 547
    label "U:Novel-4128_00022#0"
    kind "unit"
    chunk_id "Novel-4128_00022"
    text "At Batten home for dinner, my Lady was out of town, and the guests included Sir W. Pen, Captain Allen and his daughter Rebecca, Mr. Hempson and his wife. After dinner, everyone went to church where they heard a good sermon by a stranger. Then, the narrator and the young company walked first to Graye's Inn Walks, where there were many gallants, and among the ladies, the narrator considered Mrs. Frances Butler, sister of Monsieur L'Impertinent, to be the greatest beauty. Later, they went to Islington to a great house where the narrator entertained the guests as well as he could, and then returned home with them to the narrator's own home and to bed."
    community 15
  ]
  node [
    id 548
    label "E:BATTEN"
    kind "entity"
    name "BATTEN"
    community 15
  ]
  node [
    id 549
    label "E:CAPTAIN ALLEN"
    kind "entity"
    name "CAPTAIN ALLEN"
    community 15
  ]
  node [
    id 550
    label "E:REBECCA"
    kind "entity"
    name "REBECCA"
    community 15
  ]
  node [
    id 551
    label "E:MR. HEMPSON"
    kind "entity"
    name "MR. HEMPSON"
    community 15
  ]
  node [
    id 552
    label "E:MR. HEMPSON'S WIFE"
    kind "entity"
    name "MR. HEMPSON'S WIFE"
    community 15
  ]
  node [
    id 553
    label "E:GRAYE'S INN WALKS"
    kind "entity"
    name "GRAYE'S INN WALKS"
    community 15
  ]
  node [
    id 554
    label "E:MRS. FRANCES BUTLER"
    kind "entity"
    name "MRS. FRANCES BUTLER"
    community 15
  ]
  node [
    id 555
    label "E:MONSIEUR L'IMPERTINENT"
    kind "entity"
    name "MONSIEUR L'IMPERTINENT"
    community 15
  ]
  node [
    id 556
    label "E:ISLINGTON"
    kind "entity"
    name "ISLINGTON"
    community 15
  ]
  node [
    id 557
    label "E:GREAT HOUSE"
    kind "entity"
    name "GREAT HOUSE"
    community 15
  ]
  node [
    id 558
    label "E:KATE JOYCE"
    kind "entity"
    name "KATE JOYCE"
    community 15
  ]
  node [
    id 559
    label "E:PALL"
    kind "entity"
    name "PALL"
    community 3
  ]
  node [
    id 560
    label "E:DR."
    kind "entity"
    name "DR."
    community 15
  ]
  node [
    id 561
    label "E:YOUNG COMPANY"
    kind "entity"
    name "YOUNG COMPANY"
    community 15
  ]
  node [
    id 562
    label "E:LADIES AT GRAYE'S INN WALKS"
    kind "entity"
    name "LADIES AT GRAYE'S INN WALKS"
    community 15
  ]
  node [
    id 563
    label "E:ENTERTAINMENT"
    kind "entity"
    name "ENTERTAINMENT"
    community 15
  ]
  node [
    id 564
    label "U:Novel-4128_00022#1"
    kind "unit"
    chunk_id "Novel-4128_00022"
    text "On the 24th, Midsummer-day, the day was kept as a holiday, and no one went to the office. The day began at home, and in the afternoon, the narrator's father came to see the house, which was now completed and very neat."
    community 6
  ]
  node [
    id 565
    label "E:24TH"
    kind "entity"
    name "24TH"
    community 6
  ]
  node [
    id 566
    label "E:MIDSUMMER-DAY"
    kind "entity"
    name "MIDSUMMER-DAY"
    community 6
  ]
  node [
    id 567
    label "E:DAY"
    kind "entity"
    name "DAY"
    community 2
  ]
  node [
    id 568
    label "U:Novel-4128_00022#2"
    kind "unit"
    chunk_id "Novel-4128_00022"
    text "Pall attended a child's christening of Kate Joyce's and stayed out all night at the narrator's father's house because she was not well."
    community 3
  ]
  node [
    id 569
    label "E:PALL'S STATE"
    kind "entity"
    name "PALL'S STATE"
    community 3
  ]
  node [
    id 570
    label "E:KATE JOYCE'S CHRISTENING"
    kind "entity"
    name "KATE JOYCE'S CHRISTENING"
    community 3
  ]
  node [
    id 571
    label "C:Novel-4128_00023"
    kind "chunk"
    chunk_id "Novel-4128_00023"
  ]
  node [
    id 572
    label "U:Novel-4128_00023#0"
    kind "unit"
    chunk_id "Novel-4128_00023"
    text "At noon, the narrator's father visited the house, which was now finished and very neat. The father, the narrator, and Dr. Williams (who had come to see the narrator's wife, whose swollen belly is now considered dangerous as she believes it to be) went to the ordinary opposite the Exchange, where they dined and had a major argument with the house master when the bill was presented, as he charged extremely high prices for everything."
    community 9
  ]
  node [
    id 573
    label "E:DR. WILLIAMS"
    kind "entity"
    name "DR. WILLIAMS"
    community 11
  ]
  node [
    id 574
    label "E:SWOLLEN BELLY"
    kind "entity"
    name "SWOLLEN BELLY"
    community 9
  ]
  node [
    id 575
    label "E:ORDINARY OPPOSITE THE EXCHANGE"
    kind "entity"
    name "ORDINARY OPPOSITE THE EXCHANGE"
    community 9
  ]
  node [
    id 576
    label "E:HOUSE MASTER"
    kind "entity"
    name "HOUSE MASTER"
    community 9
  ]
  node [
    id 577
    label "E:RECKONING"
    kind "entity"
    name "RECKONING"
    community 9
  ]
  node [
    id 578
    label "E:HIGH PRICING"
    kind "entity"
    name "HIGH PRICING"
    community 9
  ]
  node [
    id 579
    label "E:EVERYTHING"
    kind "entity"
    name "EVERYTHING"
    community 9
  ]
  node [
    id 580
    label "E:WHICH IS NOW CONSIDERED DANGEROUS"
    kind "entity"
    name "WHICH IS NOW CONSIDERED DANGEROUS"
    community 9
  ]
  node [
    id 581
    label "U:Novel-4128_00023#1"
    kind "unit"
    chunk_id "Novel-4128_00023"
    text "The narrator returned home and then went to Sir W. Batten's, where they sat for a while before returning home."
    community 17
  ]
  node [
    id 582
    label "E:SIR W. BATTEN'S"
    kind "entity"
    name "SIR W. BATTEN'S"
    community 8
  ]
  node [
    id 583
    label "U:Novel-4128_00023#2"
    kind "unit"
    chunk_id "Novel-4128_00023"
    text "On the 25th, the narrator got up early to organize papers received from his Lord, so that now there is nothing left in the house that is his own, which he had previously kept."
    community 11
  ]
  node [
    id 584
    label "E:25TH"
    kind "entity"
    name "25TH"
    community 11
  ]
  node [
    id 585
    label "E:PAPERS"
    kind "entity"
    name "PAPERS"
    community 11
  ]
  node [
    id 586
    label "E:OWN PROPERTY"
    kind "entity"
    name "OWN PROPERTY"
    community 11
  ]
  node [
    id 587
    label "U:Novel-4128_00023#3"
    kind "unit"
    chunk_id "Novel-4128_00023"
    text "This morning, Mr. Goodgroome (Theodore Goodgroome, Pepys's singing master, possibly related to John Goodgroome, a Gentleman of the Chapel Royal) came to the narrator, recommended by Mr. Mage, and they agreed to give him 20s. as entrance and 20s. a month to teach the narrator to sing, after which they began, and the narrator hopes to have made some progress. His first song was 'La cruda la bella'."
    community 8
  ]
  node [
    id 588
    label "E:MR. GOODGROOME"
    kind "entity"
    name "MR. GOODGROOME"
    community 8
  ]
  node [
    id 589
    label "E:THEODORE GOODGROOME"
    kind "entity"
    name "THEODORE GOODGROOME"
    community 8
  ]
  node [
    id 590
    label "E:MR. MAGE"
    kind "entity"
    name "MR. MAGE"
    community 8
  ]
  node [
    id 591
    label "E:SINGING"
    kind "entity"
    name "SINGING"
    community 8
  ]
  node [
    id 592
    label "E:SINGING MASTER"
    kind "entity"
    name "SINGING MASTER"
    community 18
  ]
  node [
    id 593
    label "E:LA CRUDA LA BELLA"
    kind "entity"
    name "LA CRUDA LA BELLA"
    community 8
  ]
  node [
    id 594
    label "E:20S AS ENTRANCE"
    kind "entity"
    name "20S AS ENTRANCE"
    community 8
  ]
  node [
    id 595
    label "E:20S PER MONTH FOR SINGING LESSONS"
    kind "entity"
    name "20S PER MONTH FOR SINGING LESSONS"
    community 8
  ]
  node [
    id 596
    label "U:Novel-4128_00023#4"
    kind "unit"
    chunk_id "Novel-4128_00023"
    text "The narrator's brother Tom arrived, with whom the narrator reconciled with his father and the two drapers regarding the cloths that had been sent to sea recently."
    community 13
  ]
  node [
    id 597
    label "E:TOM"
    kind "entity"
    name "TOM"
    community 13
  ]
  node [
    id 598
    label "E:TWO DRAPERS"
    kind "entity"
    name "TWO DRAPERS"
    community 13
  ]
  node [
    id 599
    label "E:CLOTHS"
    kind "entity"
    name "CLOTHS"
    community 13
  ]
  node [
    id 600
    label "E:SEA"
    kind "entity"
    name "SEA"
    community 13
  ]
  node [
    id 601
    label "C:Novel-4128_00024"
    kind "chunk"
    chunk_id "Novel-4128_00024"
  ]
  node [
    id 602
    label "U:Novel-4128_00024#0"
    kind "unit"
    chunk_id "Novel-4128_00024"
    text "In the afternoon, Captain Allen, his daughter Rebecca, and Mr. Hempson came to the house, and later Sir Williams arrived and sat with the narrator until late evening, when a gallant collation was served for them. At night, the narrator went to bed."
    community 15
  ]
  node [
    id 603
    label "E:SIR WILLIAMS"
    kind "entity"
    name "SIR WILLIAMS"
    community 8
  ]
  node [
    id 604
    label "E:GALLANT COLLATION"
    kind "entity"
    name "GALLANT COLLATION"
    community 15
  ]
  node [
    id 605
    label "U:Novel-4128_00024#1"
    kind "unit"
    chunk_id "Novel-4128_00024"
    text "On the 26th, the narrator went to Westminster for various business matters, then dined with Lady at the Wardrobe, taking Dean Fuller with them, after which they returned home. Upon arriving home, the narrator learned that their father had gone to find them about special business. The narrator then took a coach to their father's place and received a letter from their aunt stating that their uncle Robert was suffering from dizziness in his head, and that they wished their father to come down to manage his affairs, suggesting that he is very ill. As a result, their father decided to go the next day. The narrator returned by water to the office and stayed there until night, then went home to music and then to bed."
    community 3
  ]
  node [
    id 606
    label "E:26TH"
    kind "entity"
    name "26TH"
    community 3
  ]
  node [
    id 607
    label "E:DIZZINESS IN HEAD"
    kind "entity"
    name "DIZZINESS IN HEAD"
    community 3
  ]
  node [
    id 608
    label "E:27TH"
    kind "entity"
    name "27TH"
    community 0
  ]
  node [
    id 609
    label "E:AUNT"
    kind "entity"
    name "AUNT"
    community 2
  ]
  node [
    id 610
    label "E:FATHER TO COME DOWN"
    kind "entity"
    name "FATHER TO COME DOWN"
    community 3
  ]
  node [
    id 611
    label "E:NEXT DAY"
    kind "entity"
    name "NEXT DAY"
    community 3
  ]
  node [
    id 612
    label "E:WATER"
    kind "entity"
    name "WATER"
    community 10
  ]
  node [
    id 613
    label "U:Novel-4128_00024#2"
    kind "unit"
    chunk_id "Novel-4128_00024"
    text "On the 27th, the narrator went to their father's house and accompanied him to Mr. (the rest of the name is missing)."
    community 0
  ]
  node [
    id 614
    label "C:Novel-4128_00025"
    kind "chunk"
    chunk_id "Novel-4128_00025"
  ]
  node [
    id 615
    label "U:Novel-4128_00025#0"
    kind "unit"
    chunk_id "Novel-4128_00025"
    text "On the 27th, the narrator told his father that he would have him speak to his uncle Robert about the purchase of land, offering to pay L600 ready money and L150 per annum to make up L50 per annum, even though the narrator has only L500 ready money, to appear as a greater saver. The father is going that morning to visit his uncle due to a letter from the narrator's aunt stating that the uncle is not well and needs the father's help. At noon, the narrator returned home and then joined with Lady Batten, Mrs. Rebecca Allen, Mrs. Thompson, and others, taking two coaches to see the play 'Bartholomew Fayre', which was performed very well, and then returned home. Afterward, they stayed at Sir W. Batten's late and then returned home to bed. That day, Mr. Holden sent the narrator a beaver, which cost L4 5s. (a hat in January 28th, 1660-61 cost only 35s.)."
    community 2
  ]
  node [
    id 616
    label "E:L600"
    kind "entity"
    name "L600"
    community 2
  ]
  node [
    id 617
    label "E:L150"
    kind "entity"
    name "L150"
    community 2
  ]
  node [
    id 618
    label "E:L50"
    kind "entity"
    name "L50"
    community 2
  ]
  node [
    id 619
    label "E:L500"
    kind "entity"
    name "L500"
    community 2
  ]
  node [
    id 620
    label "E:LADY BATTEN"
    kind "entity"
    name "LADY BATTEN"
    community 3
  ]
  node [
    id 621
    label "E:MRS. REBECCA ALLEN"
    kind "entity"
    name "MRS. REBECCA ALLEN"
    community 2
  ]
  node [
    id 622
    label "E:MRS. THOMPSON"
    kind "entity"
    name "MRS. THOMPSON"
    community 2
  ]
  node [
    id 623
    label "E:MR. HOLDEN"
    kind "entity"
    name "MR. HOLDEN"
    community 2
  ]
  node [
    id 624
    label "E:BEAVER"
    kind "entity"
    name "BEAVER"
    community 2
  ]
  node [
    id 625
    label "E:L4 5S"
    kind "entity"
    name "L4 5S"
    community 2
  ]
  node [
    id 626
    label "E:HAT"
    kind "entity"
    name "HAT"
    community 2
  ]
  node [
    id 627
    label "E:1660-61"
    kind "entity"
    name "1660-61"
    community 2
  ]
  node [
    id 628
    label "E:APRIL 30TH 1661"
    kind "entity"
    name "APRIL 30TH 1661"
    community 2
  ]
  node [
    id 629
    label "E:APRIL 19TH 1662"
    kind "entity"
    name "APRIL 19TH 1662"
    community 2
  ]
  node [
    id 630
    label "E:APRIL 26TH 1662"
    kind "entity"
    name "APRIL 26TH 1662"
    community 2
  ]
  node [
    id 631
    label "E:L150 PER ANNUM"
    kind "entity"
    name "L150 PER ANNUM"
    community 2
  ]
  node [
    id 632
    label "E:L50 PER ANNUM"
    kind "entity"
    name "L50 PER ANNUM"
    community 2
  ]
  node [
    id 633
    label "E:L500 READY MONEY"
    kind "entity"
    name "L500 READY MONEY"
    community 2
  ]
  node [
    id 634
    label "E:TWO COACHES"
    kind "entity"
    name "TWO COACHES"
    community 2
  ]
  node [
    id 635
    label "E:35S"
    kind "entity"
    name "35S"
    community 2
  ]
  node [
    id 636
    label "E:BEAVER BEING STOLEN"
    kind "entity"
    name "BEAVER BEING STOLEN"
    community 2
  ]
  node [
    id 637
    label "U:Novel-4128_00025#1"
    kind "unit"
    chunk_id "Novel-4128_00025"
    text "The passage ends on the 28th, indicating the next day's entry begins there."
    community 15
  ]
  node [
    id 638
    label "E:28TH"
    kind "entity"
    name "28TH"
    community 15
  ]
  node [
    id 639
    label "C:Novel-4128_00026"
    kind "chunk"
    chunk_id "Novel-4128_00026"
  ]
  node [
    id 640
    label "U:Novel-4128_00026#0"
    kind "unit"
    chunk_id "Novel-4128_00026"
    text "All morning at home, the narrator practised singing, which is now their great trade, and at noon attended to their Lady and dined with her. Later, they returned to the office and worked there until 7 p.m. Then, with Sir W. Pen, they went by coach to Moorefields, where they walked, stood, and watched the wrestling match between northern and western countrymen, which the narrator had never seen in such quantity before. Afterward, they returned home and set up their bed in the room they called the Nursery, where they lay; the narrator is very pleased with the room."
    community 17
  ]
  node [
    id 641
    label "E:MOOREFIELDS"
    kind "entity"
    name "MOOREFIELDS"
    community 17
  ]
  node [
    id 642
    label "E:NORTHERN COUNTRYMEN"
    kind "entity"
    name "NORTHERN COUNTRYMEN"
    community 17
  ]
  node [
    id 643
    label "E:WESTERN COUNTRYMEN"
    kind "entity"
    name "WESTERN COUNTRYMEN"
    community 17
  ]
  node [
    id 644
    label "E:NURSERY"
    kind "entity"
    name "NURSERY"
    community 17
  ]
  node [
    id 645
    label "E:7 P.M."
    kind "entity"
    name "7 P.M."
    community 17
  ]
  node [
    id 646
    label "E:WRESTLING"
    kind "entity"
    name "WRESTLING"
    community 17
  ]
  node [
    id 647
    label "E:DELAY"
    kind "entity"
    name "DELAY"
    community 17
  ]
  node [
    id 648
    label "E:BELL AT THE MAYPOLE"
    kind "entity"
    name "BELL AT THE MAYPOLE"
    community 17
  ]
  node [
    id 649
    label "E:STRAND"
    kind "entity"
    name "STRAND"
    community 17
  ]
  node [
    id 650
    label "E:MR. CHETWIND"
    kind "entity"
    name "MR. CHETWIND"
    community 17
  ]
  node [
    id 651
    label "E:GREGORY"
    kind "entity"
    name "GREGORY"
    community 17
  ]
  node [
    id 652
    label "E:HARTLIBB"
    kind "entity"
    name "HARTLIBB"
    community 17
  ]
  node [
    id 653
    label "E:MR. KIPPS"
    kind "entity"
    name "MR. KIPPS"
    community 17
  ]
  node [
    id 654
    label "E:OLD CLUB"
    kind "entity"
    name "OLD CLUB"
    community 17
  ]
  node [
    id 655
    label "E:ALL MORNING"
    kind "entity"
    name "ALL MORNING"
    community 17
  ]
  node [
    id 656
    label "E:DELAY OF SHIPS"
    kind "entity"
    name "DELAY OF SHIPS"
    community 17
  ]
  node [
    id 657
    label "E:AFTER DEPTFORD"
    kind "entity"
    name "AFTER DEPTFORD"
    community 17
  ]
  node [
    id 658
    label "E:END"
    kind "entity"
    name "END"
    community 17
  ]
  node [
    id 659
    label "U:Novel-4128_00026#1"
    kind "unit"
    chunk_id "Novel-4128_00026"
    text "On the 29th, by a letter from the Duke complaining of the delay of ships that were to be ready, Sir Williams and the narrator went to Deptford, where they investigated the delays and were satisfied with the findings. After returning home, the narrator stayed until the afternoon, then walked to the Bell at the Maypole in the Strand, where Mr. Chetwind, Gregory, Hartlibb, and Mr. Kipps, members of their old club, came to meet them. They stayed, drank, and talked until late, after which the narrator walked home and to bed."
    community 17
  ]
  node [
    id 660
    label "E:29TH"
    kind "entity"
    name "29TH"
    community 13
  ]
  node [
    id 661
    label "E:LATE"
    kind "entity"
    name "LATE"
    community 17
  ]
  node [
    id 662
    label "C:Novel-4128_00027"
    kind "chunk"
    chunk_id "Novel-4128_00027"
  ]
  node [
    id 663
    label "U:Novel-4128_00027#0"
    kind "unit"
    chunk_id "Novel-4128_00027"
    text "Mr. Chetwind, who previously was consumptive, has become very fat and sallow due to chewing tobacco, and in conversation he commended 'Hooker's Ecclesiastical Polity' as the best book and the only one that made him a Christian, which prompts the speaker to purchase it shortly."
    community 17
  ]
  node [
    id 664
    label "E:CHWING TOBACCO"
    kind "entity"
    name "CHWING TOBACCO"
    community 17
  ]
  node [
    id 665
    label "E:CONSUMPTIVE"
    kind "entity"
    name "CONSUMPTIVE"
    community 17
  ]
  node [
    id 666
    label "E:HOOKER'S ECCLESIASTICAL POLITY"
    kind "entity"
    name "HOOKER'S ECCLESIASTICAL POLITY"
    community 17
  ]
  node [
    id 667
    label "E:CHRISTIAN"
    kind "entity"
    name "CHRISTIAN"
    community 17
  ]
  node [
    id 668
    label "U:Novel-4128_00027#1"
    kind "unit"
    chunk_id "Novel-4128_00027"
    text "On the 30th (Lord's day), the speaker went to church, where they observed that the trade of briefs had become a regular Sunday practice, leading them to decide to stop giving money to it. Historical records from an old account-book of St. Olave's church, starting in 1642, show that on June 30, 1661, money collected for several inhabitants of the parish of St. Dunstan in the West, who had lost property in a fire, amounted to 'xxs. viiid.' This practice of levying briefs had occurred fourteen weeks prior to this, and briefs were abolished in 1828."
    community 15
  ]
  node [
    id 669
    label "E:30TH"
    kind "entity"
    name "30TH"
    community 13
  ]
  node [
    id 670
    label "E:TRADE OF BRIEFS"
    kind "entity"
    name "TRADE OF BRIEFS"
    community 15
  ]
  node [
    id 671
    label "E:ST. OLAVE'S CHURCH"
    kind "entity"
    name "ST. OLAVE'S CHURCH"
    community 15
  ]
  node [
    id 672
    label "E:1642"
    kind "entity"
    name "1642"
    community 15
  ]
  node [
    id 673
    label "E:1661"
    kind "entity"
    name "1661"
    community 15
  ]
  node [
    id 674
    label "E:JUNE 30"
    kind "entity"
    name "JUNE 30"
    community 15
  ]
  node [
    id 675
    label "E:XXS. VIID"
    kind "entity"
    name "XXS. VIID"
    community 15
  ]
  node [
    id 676
    label "E:ST. DUNSTAN IN THE WEST"
    kind "entity"
    name "ST. DUNSTAN IN THE WEST"
    community 15
  ]
  node [
    id 677
    label "E:FIRE"
    kind "entity"
    name "FIRE"
    community 15
  ]
  node [
    id 678
    label "E:1828"
    kind "entity"
    name "1828"
    community 15
  ]
  node [
    id 679
    label "U:Novel-4128_00027#2"
    kind "unit"
    chunk_id "Novel-4128_00027"
    text "The speaker attended a good sermon at church and then returned home for dinner, where he was alone with his wife."
    community 18
  ]
  node [
    id 680
    label "C:Novel-4128_00028"
    kind "chunk"
    chunk_id "Novel-4128_00028"
  ]
  node [
    id 681
    label "U:Novel-4128_00028#0"
    kind "unit"
    chunk_id "Novel-4128_00028"
    text "In 1828, briefs were abolished."
    community 15
  ]
  node [
    id 682
    label "E:BRIEFS"
    kind "entity"
    name "BRIEFS"
    community 15
  ]
  node [
    id 683
    label "U:Novel-4128_00028#1"
    kind "unit"
    chunk_id "Novel-4128_00028"
    text "After a good sermon, the speaker and his wife went home to dinner, then after dinner, Sir Williams and the speaker went by water to Whitehall, where they walked up and down and met the Duke of York as ordered by him the previous day to report on the failure to send out ships, which they attributed to the wind being against them and preventing the ships from leaving the river."
    community 7
  ]
  node [
    id 684
    label "U:Novel-4128_00028#2"
    kind "unit"
    chunk_id "Novel-4128_00028"
    text "After meeting the Duke of York, the speaker went to Graye's Inn Walk alone and enjoyed seeing the fine ladies walking there, humming the trillo, which he now regularly does after learning to sing, and found that it came upon him naturally."
    community 7
  ]
  node [
    id 685
    label "E:GRAYE'S INN WALK"
    kind "entity"
    name "GRAYE'S INN WALK"
    community 7
  ]
  node [
    id 686
    label "E:FINE LADIES"
    kind "entity"
    name "FINE LADIES"
    community 7
  ]
  node [
    id 687
    label "E:TRILLO"
    kind "entity"
    name "TRILLO"
    community 7
  ]
  node [
    id 688
    label "U:Novel-4128_00028#3"
    kind "unit"
    chunk_id "Novel-4128_00028"
    text "The speaker returned home very weary and to bed, where he found his wife not sick but still out of order, and expressed concern that she might become sick."
    community 2
  ]
  node [
    id 689
    label "E:OUT OF ORDER"
    kind "entity"
    name "OUT OF ORDER"
    community 2
  ]
  node [
    id 690
    label "E:SICK"
    kind "entity"
    name "SICK"
    community 2
  ]
  node [
    id 691
    label "U:Novel-4128_00028#4"
    kind "unit"
    chunk_id "Novel-4128_00028"
    text "That day, the Portuguese Ambassador came to Whitehall to take leave of the King, as he was now going to end his mission with the Queen and send her over."
    community 12
  ]
  node [
    id 692
    label "E:PORTUGUESE EMBASSADOR"
    kind "entity"
    name "PORTUGUESE EMBASSADOR"
    community 12
  ]
  node [
    id 693
    label "E:QUEEN"
    kind "entity"
    name "QUEEN"
    community 12
  ]
  node [
    id 694
    label "U:Novel-4128_00028#5"
    kind "unit"
    chunk_id "Novel-4128_00028"
    text "The weather was very fair and pleasant but very hot."
    community 7
  ]
  node [
    id 695
    label "E:FAIR AND PLEASANT"
    kind "entity"
    name "FAIR AND PLEASANT"
    community 7
  ]
  node [
    id 696
    label "U:Novel-4128_00028#6"
    kind "unit"
    chunk_id "Novel-4128_00028"
    text "The speaker's father went to Brampton to see his uncle Robert, not knowing whether to find him dead or alive."
    community 3
  ]
  node [
    id 697
    label "E:SPEAKER'S FATHER"
    kind "entity"
    name "SPEAKER'S FATHER"
    community 3
  ]
  node [
    id 698
    label "E:DEAD OR ALIVE"
    kind "entity"
    name "DEAD OR ALIVE"
    community 3
  ]
  node [
    id 699
    label "C:Novel-4128_00029"
    kind "chunk"
    chunk_id "Novel-4128_00029"
  ]
  node [
    id 700
    label "U:Novel-4128_00029#0"
    kind "unit"
    chunk_id "Novel-4128_00029"
    text "In July 1661, Samuel Pepys went to the city to buy several items for his house, including a chest of drawers for his chamber and an Indian gown for himself. The chest of drawers cost 33s and the Indian gown cost 34s. He dined at home with Theodore Goodgroome, his singing master, and then went to their singing lesson. After that, he went to the office and returned home."
    community 8
  ]
  node [
    id 701
    label "E:CITY"
    kind "entity"
    name "CITY"
    community 8
  ]
  node [
    id 702
    label "E:CHEST OF DRAWERS"
    kind "entity"
    name "CHEST OF DRAWERS"
    community 8
  ]
  node [
    id 703
    label "E:INDIAN GOWN"
    kind "entity"
    name "INDIAN GOWN"
    community 8
  ]
  node [
    id 704
    label "E:1661-07"
    kind "entity"
    name "1661-07"
    community 8
  ]
  node [
    id 705
    label "E:33S"
    kind "entity"
    name "33S"
    community 8
  ]
  node [
    id 706
    label "E:34S"
    kind "entity"
    name "34S"
    community 8
  ]
  node [
    id 707
    label "U:Novel-4128_00029#1"
    kind "unit"
    chunk_id "Novel-4128_00029"
    text "Samuel Pepys' father went to Brampton to see his uncle Robert, not knowing whether to find him dead or alive. Samuel Pepys has recently been under great expense in clothes and other things, but hopes to recover this summer by preparing items to send with the next fleet to the Queen. He is in good health but very prone to catching colds, so in the current hot weather he wears a cloth over his belly."
    community 8
  ]
  node [
    id 708
    label "E:HEALTH"
    kind "entity"
    name "HEALTH"
    community 12
  ]
  node [
    id 709
    label "E:COLD"
    kind "entity"
    name "COLD"
    community 8
  ]
  node [
    id 710
    label "E:SUMMER"
    kind "entity"
    name "SUMMER"
    community 8
  ]
  node [
    id 711
    label "E:EXPENSE"
    kind "entity"
    name "EXPENSE"
    community 8
  ]
  node [
    id 712
    label "E:CLOTHES"
    kind "entity"
    name "CLOTHES"
    community 8
  ]
  node [
    id 713
    label "E:PREPARING ITEMS"
    kind "entity"
    name "PREPARING ITEMS"
    community 8
  ]
  node [
    id 714
    label "E:NEXT FLEET"
    kind "entity"
    name "NEXT FLEET"
    community 8
  ]
  node [
    id 715
    label "E:BELLY"
    kind "entity"
    name "BELLY"
    community 8
  ]
  node [
    id 716
    label "C:Novel-4128_00030"
    kind "chunk"
    chunk_id "Novel-4128_00030"
  ]
  node [
    id 717
    label "U:Novel-4128_00030#0"
    kind "unit"
    chunk_id "Novel-4128_00030"
    text "During Term time, the narrator walked up and down Westminster Hall and spoke with several people, including his cozen Roger Pepys, who was going to the Parliament House. The narrator inquired whether he had heard from his father since he went to Brampton, and replied that his father had written the day before stating that his uncle was sometimes stupid and like a man who is drunk, and at other times speechless. After singing with his master, the narrator took a coach to Sir William Davenant's Opera, which had begun on the fourth day and was the first time he had seen it. The second part of 'The Siege of Rhodes' was performed, and the group waited a long time for the King and Queen of Bohemia. A board broke over their heads, causing dust to fall into the ladies' necks and the men's hair, which was considered good sport. When the King arrived, the scene opened, which was very fine and magnificent and well acted, except for the Eunuch, who was so out of place that he was hissed off the stage. The narrator then returned home and wrote letters to his Lord at sea before going to bed."
    community 18
  ]
  node [
    id 718
    label "E:ROGER PEPYS"
    kind "entity"
    name "ROGER PEPYS"
    community 18
  ]
  node [
    id 719
    label "E:TERM TIME"
    kind "entity"
    name "TERM TIME"
    community 18
  ]
  node [
    id 720
    label "E:PARLIAMENT HOUSE"
    kind "entity"
    name "PARLIAMENT HOUSE"
    community 18
  ]
  node [
    id 721
    label "E:UNCLE"
    kind "entity"
    name "UNCLE"
    community 11
  ]
  node [
    id 722
    label "E:DRUNK"
    kind "entity"
    name "DRUNK"
    community 18
  ]
  node [
    id 723
    label "E:SPEECHLESS"
    kind "entity"
    name "SPEECHLESS"
    community 18
  ]
  node [
    id 724
    label "E:SIR WILLIAM DAVENANT"
    kind "entity"
    name "SIR WILLIAM DAVENANT"
    community 17
  ]
  node [
    id 725
    label "E:OPERA"
    kind "entity"
    name "OPERA"
    community 17
  ]
  node [
    id 726
    label "E:FOURTH DAY"
    kind "entity"
    name "FOURTH DAY"
    community 18
  ]
  node [
    id 727
    label "E:SIEGE OF RHODES"
    kind "entity"
    name "SIEGE OF RHODES"
    community 18
  ]
  node [
    id 728
    label "E:KING OF BOHEMIA"
    kind "entity"
    name "KING OF BOHEMIA"
    community 18
  ]
  node [
    id 729
    label "E:QUEEN OF BOHEMIA"
    kind "entity"
    name "QUEEN OF BOHEMIA"
    community 10
  ]
  node [
    id 730
    label "E:BOARD"
    kind "entity"
    name "BOARD"
    community 18
  ]
  node [
    id 731
    label "E:DUST"
    kind "entity"
    name "DUST"
    community 18
  ]
  node [
    id 732
    label "E:LADIES"
    kind "entity"
    name "LADIES"
    community 4
  ]
  node [
    id 733
    label "E:HAIR"
    kind "entity"
    name "HAIR"
    community 18
  ]
  node [
    id 734
    label "E:EUNUCH"
    kind "entity"
    name "EUNUCH"
    community 18
  ]
  node [
    id 735
    label "E:LORD AT SEA"
    kind "entity"
    name "LORD AT SEA"
    community 18
  ]
  node [
    id 736
    label "E:SIR WILLIAM DAVENANT'S OPERA"
    kind "entity"
    name "SIR WILLIAM DAVENANT'S OPERA"
    community 18
  ]
  node [
    id 737
    label "E:HEADS"
    kind "entity"
    name "HEADS"
    community 18
  ]
  node [
    id 738
    label "E:LADIES' NECKS"
    kind "entity"
    name "LADIES' NECKS"
    community 18
  ]
  node [
    id 739
    label "E:MEN'S HAIR"
    kind "entity"
    name "MEN'S HAIR"
    community 18
  ]
  node [
    id 740
    label "U:Novel-4128_00030#1"
    kind "unit"
    chunk_id "Novel-4128_00030"
    text "On the third day, the narrator went to Westminster to Mr. [name missing]."
    community 0
  ]
  node [
    id 741
    label "C:Novel-4128_00031"
    kind "chunk"
    chunk_id "Novel-4128_00031"
  ]
  node [
    id 742
    label "U:Novel-4128_00031#0"
    kind "unit"
    chunk_id "Novel-4128_00031"
    text "The narrator wrote letters to his Lord while at sea and then went to bed. On the third day, he went to Westminster to discuss business with Mr. Edward Montagu and then to the Wardrobe, where he dined with my Lady, who is mourning her brother, Mr. Saml. Crew, who died the previous day of spotted fever. Afterward, he returned home through Duck Lane to look for Spanish books but found none that pleased him. He then went to the office, and after completing his tasks, visited Sir W. Batten with the Comptroller, where they sat late talking and disputing with Mr. Mills, the parson of their parish. That day, my Lady Batten and the narrator's wife attended the burial of a daughter of Sir John Lawson and received rings for themselves and their husbands. The narrator returned home and went to bed. On the fourth day, he spent the morning at home, then in the afternoon went to the Theatre where he saw 'Claracilla' for the first time, which was well acted. He noted that the theatre, which used to be crowded, is now empty since the Opera began and will remain so for a while. He visited his father and learned that his uncle Robert&#8212;Robert Pepys of Brampton, who died the next day&#8212;continues to have fits of stupefaction for 10 or 12 hours each day."
    community 1
  ]
  node [
    id 743
    label "E:MR. SAML. CREW"
    kind "entity"
    name "MR. SAML. CREW"
    community 1
  ]
  node [
    id 744
    label "E:SPOTTED FEVER"
    kind "entity"
    name "SPOTTED FEVER"
    community 1
  ]
  node [
    id 745
    label "E:DUCK LANE"
    kind "entity"
    name "DUCK LANE"
    community 1
  ]
  node [
    id 746
    label "E:SPANISH BOOKS"
    kind "entity"
    name "SPANISH BOOKS"
    community 1
  ]
  node [
    id 747
    label "E:PARISH"
    kind "entity"
    name "PARISH"
    community 1
  ]
  node [
    id 748
    label "E:SIR JOHN LAWSON"
    kind "entity"
    name "SIR JOHN LAWSON"
    community 1
  ]
  node [
    id 749
    label "E:RINGS"
    kind "entity"
    name "RINGS"
    community 1
  ]
  node [
    id 750
    label "E:FITS OF STUPIFICATION"
    kind "entity"
    name "FITS OF STUPIFICATION"
    community 1
  ]
  node [
    id 751
    label "E:ROBERT PEPYS"
    kind "entity"
    name "ROBERT PEPYS"
    community 1
  ]
  node [
    id 752
    label "E:CLARACILLA"
    kind "entity"
    name "CLARACILLA"
    community 1
  ]
  node [
    id 753
    label "E:WRITING LETTERS TO MY LORD"
    kind "entity"
    name "WRITING LETTERS TO MY LORD"
    community 1
  ]
  node [
    id 754
    label "E:MY LADY BATTEN"
    kind "entity"
    name "MY LADY BATTEN"
    community 1
  ]
  node [
    id 755
    label "E:SIR JOHN LAWSON'S DAUGHTER"
    kind "entity"
    name "SIR JOHN LAWSON'S DAUGHTER"
    community 1
  ]
  node [
    id 756
    label "E:HUSBAND"
    kind "entity"
    name "HUSBAND"
    community 5
  ]
  node [
    id 757
    label "E:PREVIOUSLY"
    kind "entity"
    name "PREVIOUSLY"
    community 1
  ]
  node [
    id 758
    label "E:OPERA BEGAN"
    kind "entity"
    name "OPERA BEGAN"
    community 1
  ]
  node [
    id 759
    label "E:WHILE"
    kind "entity"
    name "WHILE"
    community 4
  ]
  node [
    id 760
    label "E:10 OR 12 HOURS DAILY"
    kind "entity"
    name "10 OR 12 HOURS DAILY"
    community 1
  ]
  node [
    id 761
    label "E:FOLLOWING DAY"
    kind "entity"
    name "FOLLOWING DAY"
    community 1
  ]
  node [
    id 762
    label "U:Novel-4128_00031#1"
    kind "unit"
    chunk_id "Novel-4128_00031"
    text "The narrator's uncle Robert, Robert Pepys of Brampton, continues to suffer from daily fits of stupefaction lasting 10 or 12 hours."
    community 1
  ]
  node [
    id 763
    label "E:FITS OF STUPEFICATION"
    kind "entity"
    name "FITS OF STUPEFICATION"
    community 1
  ]
  node [
    id 764
    label "E:10 OR 12 HOURS"
    kind "entity"
    name "10 OR 12 HOURS"
    community 1
  ]
  node [
    id 765
    label "C:Novel-4128_00032"
    kind "chunk"
    chunk_id "Novel-4128_00032"
  ]
  node [
    id 766
    label "U:Novel-4128_00032#0"
    kind "unit"
    chunk_id "Novel-4128_00032"
    text "From thence to the Exchange at night, the narrator went with his uncle Wight to the Mitre, where they were merry. The narrator notes that his uncle takes it very ill that his father went out of town to Brampton without telling him, and although the narrator tried to ease the matter, could not. Mr. Batersby, the apothecary, was present and advised that if his uncle had emerods&#8212;haemorrhoids or piles&#8212;and they were now stopped, bleeding behind by leeches would cure him; however, the narrator is resolved not to interfere with this treatment. The narrator returned home and went to bed."
    community 3
  ]
  node [
    id 767
    label "E:MITRE"
    kind "entity"
    name "MITRE"
    community 13
  ]
  node [
    id 768
    label "E:MR. BATERSBY"
    kind "entity"
    name "MR. BATERSBY"
    community 3
  ]
  node [
    id 769
    label "E:EMERODS"
    kind "entity"
    name "EMERODS"
    community 3
  ]
  node [
    id 770
    label "E:HAEMORRHOIDS OR PILES"
    kind "entity"
    name "HAEMORRHOIDS OR PILES"
    community 3
  ]
  node [
    id 771
    label "E:ST."
    kind "entity"
    name "ST."
    community 3
  ]
  node [
    id 772
    label "E:UNCLE WIGHT'S DISPLEASURE"
    kind "entity"
    name "UNCLE WIGHT'S DISPLEASURE"
    community 3
  ]
  node [
    id 773
    label "E:EMERODS CAN BE CURED BY BLEEDING BEHIND WITH LEECHES"
    kind "entity"
    name "EMERODS CAN BE CURED BY BLEEDING BEHIND WITH LEECHES"
    community 3
  ]
  node [
    id 774
    label "E:UNCLE WIGHT'S TREATMENT"
    kind "entity"
    name "UNCLE WIGHT'S TREATMENT"
    community 3
  ]
  node [
    id 775
    label "U:Novel-4128_00032#1"
    kind "unit"
    chunk_id "Novel-4128_00032"
    text "On the 5th, the narrator went to the office in the afternoon, then all went to Sir W. Batten's, where they had a venison pasty and were very merry. Afterward, they returned home and went to bed."
    community 8
  ]
  node [
    id 776
    label "E:5TH"
    kind "entity"
    name "5TH"
    community 5
  ]
  node [
    id 777
    label "E:VENISON PASTY"
    kind "entity"
    name "VENISON PASTY"
    community 8
  ]
  node [
    id 778
    label "E:ALL"
    kind "entity"
    name "ALL"
    community 8
  ]
  node [
    id 779
    label "U:Novel-4128_00032#2"
    kind "unit"
    chunk_id "Novel-4128_00032"
    text "On the 6th, the narrator was woken by a messenger with news that his uncle Robert had died the previous day. The narrator rose feeling sorry in some respects and glad in others. He made himself ready, went to tell his uncle Wight, his Lady, and some others, and then bought a pair of boots in St."
    community 3
  ]
  node [
    id 780
    label "E:MESSANGER"
    kind "entity"
    name "MESSANGER"
    community 3
  ]
  node [
    id 781
    label "E:UNCLE ROBERT'S DEATH"
    kind "entity"
    name "UNCLE ROBERT'S DEATH"
    community 3
  ]
  node [
    id 782
    label "C:Novel-4128_00033"
    kind "chunk"
    chunk_id "Novel-4128_00033"
  ]
  node [
    id 783
    label "U:Novel-4128_00033#0"
    kind "unit"
    chunk_id "Novel-4128_00033"
    text "Martin, along with a messenger, set out from the Post House at about eleven and twelve o'clock, rode to Brampton and arrived well by nine o'clock, where he found his father in good health. In the hall, his uncle's corpse was initially placed on joint-stools in the chimney, but it began to smell, so Martin had it moved to the yard overnight and watched it by two men. Martin found his aunt in bed in a very unpleasant condition, which made him sick to see. That night, Martin and his father lay together and expressed a strong desire to see the will, but only asked to view it the next day. On the 7th (Lord's day), in the morning, Martin and his father walked in the garden and read the will, where although his father gave Martin nothing at present until his own death or only very little, Martin was glad to see that he had provided well for the family and for his relatives. After reading the will, they went about preparing items such as ribbands and gloves for the burial."
    community 11
  ]
  node [
    id 784
    label "E:MARTIN"
    kind "entity"
    name "MARTIN"
    community 11
  ]
  node [
    id 785
    label "E:MESSENGER"
    kind "entity"
    name "MESSENGER"
    community 11
  ]
  node [
    id 786
    label "E:POST HOUSE"
    kind "entity"
    name "POST HOUSE"
    community 11
  ]
  node [
    id 787
    label "E:JOINT-STOOLS"
    kind "entity"
    name "JOINT-STOOLS"
    community 11
  ]
  node [
    id 788
    label "E:CHIMNEY"
    kind "entity"
    name "CHIMNEY"
    community 11
  ]
  node [
    id 789
    label "E:HALL"
    kind "entity"
    name "HALL"
    community 11
  ]
  node [
    id 790
    label "E:YARD"
    kind "entity"
    name "YARD"
    community 11
  ]
  node [
    id 791
    label "E:RIBBANDS"
    kind "entity"
    name "RIBBANDS"
    community 11
  ]
  node [
    id 792
    label "E:GOVES"
    kind "entity"
    name "GOVES"
    community 11
  ]
  node [
    id 793
    label "E:BURIAL"
    kind "entity"
    name "BURIAL"
    community 21
  ]
  node [
    id 794
    label "E:GOOD HEALTH"
    kind "entity"
    name "GOOD HEALTH"
    community 11
  ]
  node [
    id 795
    label "E:TWO MEN"
    kind "entity"
    name "TWO MEN"
    community 11
  ]
  node [
    id 796
    label "E:NASTY UGLY PICKLE"
    kind "entity"
    name "NASTY UGLY PICKLE"
    community 2
  ]
  node [
    id 797
    label "E:FAMILY"
    kind "entity"
    name "FAMILY"
    community 11
  ]
  node [
    id 798
    label "E:RELATIVES"
    kind "entity"
    name "RELATIVES"
    community 11
  ]
  node [
    id 799
    label "E:WALKED IN THE GARDEN"
    kind "entity"
    name "WALKED IN THE GARDEN"
    community 11
  ]
  node [
    id 800
    label "E:READ THE WILL"
    kind "entity"
    name "READ THE WILL"
    community 11
  ]
  node [
    id 801
    label "U:Novel-4128_00033#1"
    kind "unit"
    chunk_id "Novel-4128_00033"
    text "Martin and his father read the will in the garden on the 7th (Lord's day), where although his father gave Martin nothing at present until his own death or only very little, Martin was glad to see that he had done well for the family and for his relatives. After reading the will, they prepared ribbands and gloves for the burial."
    community 11
  ]
  node [
    id 802
    label "C:Novel-4128_00034"
    kind "chunk"
    chunk_id "Novel-4128_00034"
  ]
  node [
    id 803
    label "U:Novel-4128_00034#0"
    kind "unit"
    chunk_id "Novel-4128_00034"
    text "After the burial preparations were completed, the group went about gathering ribbands and gloves for the burial, which was carried out in the afternoon on a Sunday when people from far and near came in, causing great disorder. Despite this, they managed to serve wine and other items, and then carried the deceased to the church where Mr. Taylor buried him and Mr. Turner delivered a funeral sermon that did not mention the deceased specifically but highlighted his honesty, which was sufficient to make a good sermon."
    community 21
  ]
  node [
    id 804
    label "E:BURIAL PREPARATIONS"
    kind "entity"
    name "BURIAL PREPARATIONS"
    community 21
  ]
  node [
    id 805
    label "E:GLOVES"
    kind "entity"
    name "GLOVES"
    community 21
  ]
  node [
    id 806
    label "E:SUNDAY"
    kind "entity"
    name "SUNDAY"
    community 21
  ]
  node [
    id 807
    label "E:DISORDER"
    kind "entity"
    name "DISORDER"
    community 21
  ]
  node [
    id 808
    label "E:MR. TAYLOR"
    kind "entity"
    name "MR. TAYLOR"
    community 21
  ]
  node [
    id 809
    label "E:FUNERAL SERMON"
    kind "entity"
    name "FUNERAL SERMON"
    community 21
  ]
  node [
    id 810
    label "E:HONESTY"
    kind "entity"
    name "HONESTY"
    community 21
  ]
  node [
    id 811
    label "E:DECEASED"
    kind "entity"
    name "DECEASED"
    community 21
  ]
  node [
    id 812
    label "E:BASE UGLY HUMOURS"
    kind "entity"
    name "BASE UGLY HUMOURS"
    community 21
  ]
  node [
    id 813
    label "E:TOM TRICE"
    kind "entity"
    name "TOM TRICE"
    community 4
  ]
  node [
    id 814
    label "E:CAVEAT"
    kind "entity"
    name "CAVEAT"
    community 4
  ]
  node [
    id 815
    label "E:UNCLE'S PAPERS"
    kind "entity"
    name "UNCLE'S PAPERS"
    community 21
  ]
  node [
    id 816
    label "E:UNCLE'S CLOTHES"
    kind "entity"
    name "UNCLE'S CLOTHES"
    community 21
  ]
  node [
    id 817
    label "E:WORK"
    kind "entity"
    name "WORK"
    community 21
  ]
  node [
    id 818
    label "E:SUPPING"
    kind "entity"
    name "SUPPING"
    community 21
  ]
  node [
    id 819
    label "E:9TH"
    kind "entity"
    name "9TH"
    community 21
  ]
  node [
    id 820
    label "E:LOTH"
    kind "entity"
    name "LOTH"
    community 21
  ]
  node [
    id 821
    label "E:ATTENDANCE"
    kind "entity"
    name "ATTENDANCE"
    community 21
  ]
  node [
    id 822
    label "E:GROUP"
    kind "entity"
    name "GROUP"
    community 16
  ]
  node [
    id 823
    label "E:GOOD SERMON"
    kind "entity"
    name "GOOD SERMON"
    community 21
  ]
  node [
    id 824
    label "E:I"
    kind "entity"
    name "I"
    community 10
  ]
  node [
    id 825
    label "E:ALL THIS WEEK"
    kind "entity"
    name "ALL THIS WEEK"
    community 21
  ]
  node [
    id 826
    label "E:AUNT'S BASE UGLY HUMOURS"
    kind "entity"
    name "AUNT'S BASE UGLY HUMOURS"
    community 10
  ]
  node [
    id 827
    label "E:US"
    kind "entity"
    name "US"
    community 4
  ]
  node [
    id 828
    label "E:REASON"
    kind "entity"
    name "REASON"
    community 4
  ]
  node [
    id 829
    label "E:TOM TRICE'S CAVEAT"
    kind "entity"
    name "TOM TRICE'S CAVEAT"
    community 4
  ]
  node [
    id 830
    label "U:Novel-4128_00034#1"
    kind "unit"
    chunk_id "Novel-4128_00034"
    text "The family received news that Tom Trice had filed a caveat on their behalf in support of his mother, to whom the uncle had not given anything, and the reason given for this action was expressed in the caveat, which caused concern for the family."
    community 4
  ]
  node [
    id 831
    label "E:GAVE NOTHING"
    kind "entity"
    name "GAVE NOTHING"
    community 4
  ]
  node [
    id 832
    label "E:CONCERN"
    kind "entity"
    name "CONCERN"
    community 4
  ]
  node [
    id 833
    label "C:Novel-4128_00035"
    kind "chunk"
    chunk_id "Novel-4128_00035"
  ]
  node [
    id 834
    label "U:Novel-4128_00035#0"
    kind "unit"
    chunk_id "Novel-4128_00035"
    text "The estate does not appear as expected by the speaker and all the world believes it does; the papers are in confusion and poorly sorted, which frustrates the speaker and causes mental strain. The surrenders of his copyhold land are missing, which means the land will go to the heir at law instead of the speaker's family. The speaker is also troubled by the bad quality of the drink, the poor meat, the gnats biting at night, disappointment in getting home this week, and the effort of sorting the papers, leading to near mental breakdown. Despite receiving advice from Mr. Philips, the speaker and family remain unsettled. On the 14th (Lord's day), the speaker is at home with Robert Barnwell, dines, and in the evening walks with his father around Portholme, viewing the fields, which is pleasant. They then go to Hinchingbroke, which is now covered in dirt due to my Lord's building, which will eventually make it very magnificent."
    community 13
  ]
  node [
    id 835
    label "E:ALL THE WORLD"
    kind "entity"
    name "ALL THE WORLD"
    community 13
  ]
  node [
    id 836
    label "E:COPYHOLD LAND"
    kind "entity"
    name "COPYHOLD LAND"
    community 13
  ]
  node [
    id 837
    label "E:HEIR AT LAW"
    kind "entity"
    name "HEIR AT LAW"
    community 13
  ]
  node [
    id 838
    label "E:BAD DRINK"
    kind "entity"
    name "BAD DRINK"
    community 13
  ]
  node [
    id 839
    label "E:POOR MEAT"
    kind "entity"
    name "POOR MEAT"
    community 13
  ]
  node [
    id 840
    label "E:GNATS"
    kind "entity"
    name "GNATS"
    community 13
  ]
  node [
    id 841
    label "E:GETTING HOME THIS WEEK"
    kind "entity"
    name "GETTING HOME THIS WEEK"
    community 13
  ]
  node [
    id 842
    label "E:SORTING THE PAPERS"
    kind "entity"
    name "SORTING THE PAPERS"
    community 13
  ]
  node [
    id 843
    label "E:MR. PHILIPS"
    kind "entity"
    name "MR. PHILIPS"
    community 13
  ]
  node [
    id 844
    label "E:14TH LORD'S DAY"
    kind "entity"
    name "14TH LORD'S DAY"
    community 13
  ]
  node [
    id 845
    label "E:ROBERT BARNWELL"
    kind "entity"
    name "ROBERT BARNWELL"
    community 13
  ]
  node [
    id 846
    label "E:PORTHOLME"
    kind "entity"
    name "PORTHOLME"
    community 13
  ]
  node [
    id 847
    label "E:HINCHINGBROKE"
    kind "entity"
    name "HINCHINGBROKE"
    community 13
  ]
  node [
    id 848
    label "E:BUILDING"
    kind "entity"
    name "BUILDING"
    community 13
  ]
  node [
    id 849
    label "E:MAGNIFICENT"
    kind "entity"
    name "MAGNIFICENT"
    community 13
  ]
  node [
    id 850
    label "E:EXPECTED BY THE SPEAKER"
    kind "entity"
    name "EXPECTED BY THE SPEAKER"
    community 13
  ]
  node [
    id 851
    label "E:MISSING SURRENDERS OF COPYHOLD LAND"
    kind "entity"
    name "MISSING SURRENDERS OF COPYHOLD LAND"
    community 13
  ]
  node [
    id 852
    label "E:SPEAKER AND FAMILY"
    kind "entity"
    name "SPEAKER AND FAMILY"
    community 13
  ]
  node [
    id 853
    label "E:SPEAKER IS AT HOME WITH ROBERT BARNWELL"
    kind "entity"
    name "SPEAKER IS AT HOME WITH ROBERT BARNWELL"
    community 13
  ]
  node [
    id 854
    label "E:SPEAKER AND HIS FATHER"
    kind "entity"
    name "SPEAKER AND HIS FATHER"
    community 13
  ]
  node [
    id 855
    label "E:FIELDS OF PORTHOLME"
    kind "entity"
    name "FIELDS OF PORTHOLME"
    community 13
  ]
  node [
    id 856
    label "E:MY LORD'S BUILDING"
    kind "entity"
    name "MY LORD'S BUILDING"
    community 13
  ]
  node [
    id 857
    label "E:HINCHINGBROKE BE MAGNIFICENT"
    kind "entity"
    name "HINCHINGBROKE BE MAGNIFICENT"
    community 13
  ]
  node [
    id 858
    label "U:Novel-4128_00035#1"
    kind "unit"
    chunk_id "Novel-4128_00035"
    text "On the 14th (Lord's day), the speaker and his father walk around Portholme and view the fields, which is a pleasant activity. They then travel to Hinchingbroke, which is currently in dirt because of my Lord's building, which will eventually transform it into a magnificent place."
    community 13
  ]
  node [
    id 859
    label "E:FIELDS"
    kind "entity"
    name "FIELDS"
    community 13
  ]
  node [
    id 860
    label "C:Novel-4128_00036"
    kind "chunk"
    chunk_id "Novel-4128_00036"
  ]
  node [
    id 861
    label "U:Novel-4128_00036#0"
    kind "unit"
    chunk_id "Novel-4128_00036"
    text "In the morning of the 15th, the narrator rose at three o'clock, rode to Cambridge and arrived by seven o'clock. After being trimmed, he went to Christ College where he found his brother John already in bed at eight o'clock, which annoyed him. He then went to King's College chapel, where he saw the scholars in surplices attending service with organs, a scene different from what it was during his time. Later, he met Dr. Fairbrother at the chapel and went to the Rose tavern, where he called for wine and met Mr. Turner of their office, sent for his wife, and they were very merry as they were settling their son in Cambridge. He also sent for Mr. Sanchy of Magdalen, and with him and other gentlemen who were friends of Sanchy, they were very merry, and the narrator treated them well. At noon, he took horse again, said goodbye to his cousin Angier, and rode to Impington, where he found his old uncle Talbot Pepys, who was seventy-eight years old at the time, born in 1583, educated at Trinity Hall, Cambridge, and called to the bar at the Middle Temple in 1605, and was a Member of Parliament."
    community 18
  ]
  node [
    id 862
    label "E:THREE O'CLOCK"
    kind "entity"
    name "THREE O'CLOCK"
    community 18
  ]
  node [
    id 863
    label "E:SEVEN O'CLOCK"
    kind "entity"
    name "SEVEN O'CLOCK"
    community 18
  ]
  node [
    id 864
    label "E:CHRIST COLLEGE"
    kind "entity"
    name "CHRIST COLLEGE"
    community 18
  ]
  node [
    id 865
    label "E:BROTHER JOHN"
    kind "entity"
    name "BROTHER JOHN"
    community 18
  ]
  node [
    id 866
    label "E:KING'S COLLEGE CHAPEL"
    kind "entity"
    name "KING'S COLLEGE CHAPEL"
    community 18
  ]
  node [
    id 867
    label "E:SCHOLARS"
    kind "entity"
    name "SCHOLARS"
    community 18
  ]
  node [
    id 868
    label "E:ORGANS"
    kind "entity"
    name "ORGANS"
    community 18
  ]
  node [
    id 869
    label "E:DR. FAIRBROTHER"
    kind "entity"
    name "DR. FAIRBROTHER"
    community 18
  ]
  node [
    id 870
    label "E:ROSE TAVERN"
    kind "entity"
    name "ROSE TAVERN"
    community 18
  ]
  node [
    id 871
    label "E:MR. TURNER'S WIFE"
    kind "entity"
    name "MR. TURNER'S WIFE"
    community 18
  ]
  node [
    id 872
    label "E:MR. SANCHY"
    kind "entity"
    name "MR. SANCHY"
    community 18
  ]
  node [
    id 873
    label "E:MAGDALEN"
    kind "entity"
    name "MAGDALEN"
    community 18
  ]
  node [
    id 874
    label "E:COUNCIL OF GENTLEMEN"
    kind "entity"
    name "COUNCIL OF GENTLEMEN"
    community 18
  ]
  node [
    id 875
    label "E:ANGIER"
    kind "entity"
    name "ANGIER"
    community 18
  ]
  node [
    id 876
    label "E:IMPINGTON"
    kind "entity"
    name "IMPINGTON"
    community 18
  ]
  node [
    id 877
    label "E:TALBOT PEPS"
    kind "entity"
    name "TALBOT PEPS"
    community 18
  ]
  node [
    id 878
    label "E:1583"
    kind "entity"
    name "1583"
    community 18
  ]
  node [
    id 879
    label "E:SEVENTY-EIGHT"
    kind "entity"
    name "SEVENTY-EIGHT"
    community 18
  ]
  node [
    id 880
    label "E:TRINITY HALL"
    kind "entity"
    name "TRINITY HALL"
    community 18
  ]
  node [
    id 881
    label "E:MIDDLE TEMPLE"
    kind "entity"
    name "MIDDLE TEMPLE"
    community 18
  ]
  node [
    id 882
    label "E:1605"
    kind "entity"
    name "1605"
    community 18
  ]
  node [
    id 883
    label "E:MEMBER OF PARLIAMENT"
    kind "entity"
    name "MEMBER OF PARLIAMENT"
    community 18
  ]
  node [
    id 884
    label "E:EIGHT O'CLOCK"
    kind "entity"
    name "EIGHT O'CLOCK"
    community 18
  ]
  node [
    id 885
    label "E:SERVICE"
    kind "entity"
    name "SERVICE"
    community 18
  ]
  node [
    id 886
    label "E:MR. TURNER AND HIS WIFE"
    kind "entity"
    name "MR. TURNER AND HIS WIFE"
    community 18
  ]
  node [
    id 887
    label "E:MR. SANCHY AND OTHER GENTLEMEN"
    kind "entity"
    name "MR. SANCHY AND OTHER GENTLEMEN"
    community 18
  ]
  node [
    id 888
    label "E:NOON"
    kind "entity"
    name "NOON"
    community 12
  ]
  node [
    id 889
    label "C:Novel-4128_00037"
    kind "chunk"
    chunk_id "Novel-4128_00037"
  ]
  node [
    id 890
    label "U:Novel-4128_00037#0"
    kind "unit"
    chunk_id "Novel-4128_00037"
    text "He was M.P. for Cambridge in 1625 and Recorder of Cambridge from 1624 to 1660, when he was succeeded by his son Roger. He died of the plague in March 1666 at the age of eighty-three."
    community 8
  ]
  node [
    id 891
    label "E:1625"
    kind "entity"
    name "1625"
    community 8
  ]
  node [
    id 892
    label "E:1624"
    kind "entity"
    name "1624"
    community 8
  ]
  node [
    id 893
    label "E:1660"
    kind "entity"
    name "1660"
    community 8
  ]
  node [
    id 894
    label "E:ROGER"
    kind "entity"
    name "ROGER"
    community 8
  ]
  node [
    id 895
    label "E:PLAGUE"
    kind "entity"
    name "PLAGUE"
    community 8
  ]
  node [
    id 896
    label "E:MARCH"
    kind "entity"
    name "MARCH"
    community 8
  ]
  node [
    id 897
    label "E:1666"
    kind "entity"
    name "1666"
    community 8
  ]
  node [
    id 898
    label "E:EIGHTY-THREE"
    kind "entity"
    name "EIGHTY-THREE"
    community 8
  ]
  node [
    id 899
    label "U:Novel-4128_00037#1"
    kind "unit"
    chunk_id "Novel-4128_00037"
    text "He sat alone, appearing like a man out of the world; he can hardly see, but sees other things quite clearly. With Dr. John Pepys and him, the will was read over and their advice was sought, and they confirmed the will's sufficiency and advised on its other parts."
    community 11
  ]
  node [
    id 900
    label "E:DR. JOHN PEPYS"
    kind "entity"
    name "DR. JOHN PEPYS"
    community 11
  ]
  node [
    id 901
    label "E:SEEING"
    kind "entity"
    name "SEEING"
    community 11
  ]
  node [
    id 902
    label "E:CLARITY"
    kind "entity"
    name "CLARITY"
    community 11
  ]
  node [
    id 903
    label "E:ADVICE"
    kind "entity"
    name "ADVICE"
    community 11
  ]
  node [
    id 904
    label "E:SUFFICIENCY"
    kind "entity"
    name "SUFFICIENCY"
    community 11
  ]
  node [
    id 905
    label "E:OTHER PARTS"
    kind "entity"
    name "OTHER PARTS"
    community 11
  ]
  node [
    id 906
    label "U:Novel-4128_00037#2"
    kind "unit"
    chunk_id "Novel-4128_00037"
    text "After reading the will, he rode to Gravely with difficulty to inquire about a surrender of his uncle's property in the hands of copyholders, but heard of none, which caused him great mental distress. He then rode home to Brampton with a sad heart, but made himself as cheerful as possible for his father before going to bed. On the 16th, 17th, 18th, and 19th."
    community 0
  ]
  node [
    id 907
    label "E:GRAVELY"
    kind "entity"
    name "GRAVELY"
    community 0
  ]
  node [
    id 908
    label "E:COPYHOLDERS"
    kind "entity"
    name "COPYHOLDERS"
    community 0
  ]
  node [
    id 909
    label "E:SURRENDER"
    kind "entity"
    name "SURRENDER"
    community 2
  ]
  node [
    id 910
    label "E:MENTAL DISTRESS"
    kind "entity"
    name "MENTAL DISTRESS"
    community 0
  ]
  node [
    id 911
    label "C:Novel-4128_00038"
    kind "chunk"
    chunk_id "Novel-4128_00038"
  ]
  node [
    id 912
    label "U:Novel-4128_00038#0"
    kind "unit"
    chunk_id "Novel-4128_00038"
    text "On the 16th, 17th, 18th, and 19th, the speaker and their father spent the days organizing affairs, allowing the crop to grow on the ground, agreeing with Stankes to manage their business during their absence, and felt most content in appointing Stankes as their bayly. They rode to Offord and Sturtlow and walked about their lands in the evening, discussing matters with their father. Mr. Moore from London was advised by the speaker to provide guidance, stating that since the three witnesses of the will are all legatees, they would not act against the will. That night, Serjeant Bernard arrived home in the country. The speaker and their family had daily reports from Jane Perkin and the maid about their aunt's base and hypocritical behavior."
    community 0
  ]
  node [
    id 913
    label "E:STANKES"
    kind "entity"
    name "STANKES"
    community 4
  ]
  node [
    id 914
    label "E:BAYLY"
    kind "entity"
    name "BAYLY"
    community 0
  ]
  node [
    id 915
    label "E:OFFORD"
    kind "entity"
    name "OFFORD"
    community 0
  ]
  node [
    id 916
    label "E:STURTLOW"
    kind "entity"
    name "STURTLOW"
    community 2
  ]
  node [
    id 917
    label "E:THREE WITNESSES OF THE WILL"
    kind "entity"
    name "THREE WITNESSES OF THE WILL"
    community 0
  ]
  node [
    id 918
    label "E:LEGATEES"
    kind "entity"
    name "LEGATEES"
    community 0
  ]
  node [
    id 919
    label "E:SERJEANT BERNARD"
    kind "entity"
    name "SERJEANT BERNARD"
    community 0
  ]
  node [
    id 920
    label "E:JANE PERKIN"
    kind "entity"
    name "JANE PERKIN"
    community 0
  ]
  node [
    id 921
    label "E:MAID"
    kind "entity"
    name "MAID"
    community 0
  ]
  node [
    id 922
    label "E:SPENDING TIME ORGANIZING AFFAIRS"
    kind "entity"
    name "SPENDING TIME ORGANIZING AFFAIRS"
    community 0
  ]
  node [
    id 923
    label "E:ALLOWING CROP TO GROW"
    kind "entity"
    name "ALLOWING CROP TO GROW"
    community 0
  ]
  node [
    id 924
    label "E:AGREEING WITH STANKES TO MANAGE BUSINESS"
    kind "entity"
    name "AGREEING WITH STANKES TO MANAGE BUSINESS"
    community 0
  ]
  node [
    id 925
    label "E:APPOINTING STANKES AS BAYLY"
    kind "entity"
    name "APPOINTING STANKES AS BAYLY"
    community 0
  ]
  node [
    id 926
    label "E:THAT NIGHT"
    kind "entity"
    name "THAT NIGHT"
    community 0
  ]
  node [
    id 927
    label "E:BASE AND HYPOCRITICAL TRICKS"
    kind "entity"
    name "BASE AND HYPOCRITICAL TRICKS"
    community 0
  ]
  node [
    id 928
    label "E:AUNT'S BASE AND HYPOCRITICAL TRICKS"
    kind "entity"
    name "AUNT'S BASE AND HYPOCRITICAL TRICKS"
    community 0
  ]
  node [
    id 929
    label "U:Novel-4128_00038#1"
    kind "unit"
    chunk_id "Novel-4128_00038"
    text "On the 20th, the speaker traveled to Huntingdon to meet Sir Robert Bernard, where they sat down together and discussed matters. The speaker showed Sir Robert the will, and he spoke with them in a fair manner, but no agreement was reached until Tom Trice arrived."
    community 4
  ]
  node [
    id 930
    label "E:SIR ROBERT BERNARD"
    kind "entity"
    name "SIR ROBERT BERNARD"
    community 4
  ]
  node [
    id 931
    label "E:JASPAR TRICE"
    kind "entity"
    name "JASPAR TRICE"
    community 4
  ]
  node [
    id 932
    label "E:AFTER NO AGREEMENT WAS REACHED"
    kind "entity"
    name "AFTER NO AGREEMENT WAS REACHED"
    community 4
  ]
  node [
    id 933
    label "C:Novel-4128_00039"
    kind "chunk"
    chunk_id "Novel-4128_00039"
  ]
  node [
    id 934
    label "U:Novel-4128_00039#0"
    kind "unit"
    chunk_id "Novel-4128_00039"
    text "Sir Robert and the narrator discussed the money due to them upon surrender from Piggott, amounting to L164, which he stated would be included with debts to the heir at law, a situation that deeply saddened the narrator. The narrator stayed with Sir Robert Bernard and his wife, Lady Digby, a very good woman, and dined with them. After dinner, the narrator went into town and spent the afternoon with Mr. Phillips, Dr. Symcottes, Mr. Vinter, Robert Ethell, and many other friends, and later with Mr. Davenport, Phillips, Jaspar Trice, and others at Mother-----, where they sat over against the Crown, drank ale, and were very merry until 9 p.m. The narrator then walked home and encountered Tom Trice, who had come with his father to Goody Gorum's; the narrator found them there and met Jaspar Trice and Mr. Greene, with whom they had a calm conversation that reached no conclusion, and then parted. The narrator returned home and went to bed, now feeling much better in their left hand, which had recently been stung and severely swollen."
    community 4
  ]
  node [
    id 935
    label "E:SIR ROBERT"
    kind "entity"
    name "SIR ROBERT"
    community 4
  ]
  node [
    id 936
    label "E:PIGGOTT"
    kind "entity"
    name "PIGGOTT"
    community 4
  ]
  node [
    id 937
    label "E:L164"
    kind "entity"
    name "L164"
    community 4
  ]
  node [
    id 938
    label "E:LADY DIGBY"
    kind "entity"
    name "LADY DIGBY"
    community 4
  ]
  node [
    id 939
    label "E:MR. PHILLIPS"
    kind "entity"
    name "MR. PHILLIPS"
    community 5
  ]
  node [
    id 940
    label "E:DR. SYMCOTTES"
    kind "entity"
    name "DR. SYMCOTTES"
    community 4
  ]
  node [
    id 941
    label "E:MR. VINTER"
    kind "entity"
    name "MR. VINTER"
    community 4
  ]
  node [
    id 942
    label "E:ROBERT ETHELL"
    kind "entity"
    name "ROBERT ETHELL"
    community 4
  ]
  node [
    id 943
    label "E:MR. DAVENPORT"
    kind "entity"
    name "MR. DAVENPORT"
    community 4
  ]
  node [
    id 944
    label "E:MOTHER-----"
    kind "entity"
    name "MOTHER-----"
    community 4
  ]
  node [
    id 945
    label "E:CROWN"
    kind "entity"
    name "CROWN"
    community 4
  ]
  node [
    id 946
    label "E:9 PM"
    kind "entity"
    name "9 PM"
    community 4
  ]
  node [
    id 947
    label "E:GOODY GORUM'S"
    kind "entity"
    name "GOODY GORUM'S"
    community 5
  ]
  node [
    id 948
    label "E:MR. GREENE"
    kind "entity"
    name "MR. GREENE"
    community 2
  ]
  node [
    id 949
    label "E:LEFT HAND"
    kind "entity"
    name "LEFT HAND"
    community 4
  ]
  node [
    id 950
    label "E:STUNG"
    kind "entity"
    name "STUNG"
    community 4
  ]
  node [
    id 951
    label "E:SWELLED"
    kind "entity"
    name "SWELLED"
    community 4
  ]
  node [
    id 952
    label "E:21ST LORD'S DAY"
    kind "entity"
    name "21ST LORD'S DAY"
    community 4
  ]
  node [
    id 953
    label "E:MONEY DUE TO US"
    kind "entity"
    name "MONEY DUE TO US"
    community 4
  ]
  node [
    id 954
    label "E:DEBTS TO HEIR AT LAW"
    kind "entity"
    name "DEBTS TO HEIR AT LAW"
    community 4
  ]
  node [
    id 955
    label "E:NARRATOR'S FATHER"
    kind "entity"
    name "NARRATOR'S FATHER"
    community 4
  ]
  node [
    id 956
    label "E:RECENTLY"
    kind "entity"
    name "RECENTLY"
    community 4
  ]
  node [
    id 957
    label "E:GOING TOMORROW"
    kind "entity"
    name "GOING TOMORROW"
    community 4
  ]
  node [
    id 958
    label "U:Novel-4128_00039#1"
    kind "unit"
    chunk_id "Novel-4128_00039"
    text "On the 21st (Lord's day), the narrator spent the morning at home organizing papers in preparation for the next day's journey and doing other related tasks. The narrator had a good dinner with Stankes and his wife."
    community 4
  ]
  node [
    id 959
    label "C:Novel-4128_00040"
    kind "chunk"
    chunk_id "Novel-4128_00040"
  ]
  node [
    id 960
    label "U:Novel-4128_00040#0"
    kind "unit"
    chunk_id "Novel-4128_00040"
    text "The narrator had a good dinner with Stankes and his wife. In the afternoon, the narrator returned to business, and in the evening, the two Trices, Mr. Greene, and Mr. Philips arrived, leading to an argument that ended with an agreement: for giving my aunt L10, she will quit the house, and for other matters, they will be left to the law, which pleased everyone, and thus they broke up, feeling pretty well satisfied. Later, Mr. Barnwell and J. Bowles arrived and supped with them; after supper, they parted, and the narrator took leave of them, put things in the best order possible for the next day, and went to bed. Old William Luffe visited in the afternoon, paid his bond of L20, and the narrator gave him in the presence of Mr. Philips, R. Barnwell, and Mr. Pigott the uncle's surrender of Sturtlow to the narrator, which William acknowledged as having been delivered by the uncle during his lifetime."
    community 2
  ]
  node [
    id 961
    label "E:WIFE OF STANKES"
    kind "entity"
    name "WIFE OF STANKES"
    community 2
  ]
  node [
    id 962
    label "E:TWO TRICES"
    kind "entity"
    name "TWO TRICES"
    community 2
  ]
  node [
    id 963
    label "E:L10"
    kind "entity"
    name "L10"
    community 2
  ]
  node [
    id 964
    label "E:LAW"
    kind "entity"
    name "LAW"
    community 2
  ]
  node [
    id 965
    label "E:MR. BARNWELL"
    kind "entity"
    name "MR. BARNWELL"
    community 2
  ]
  node [
    id 966
    label "E:J. BOWLES"
    kind "entity"
    name "J. BOWLES"
    community 2
  ]
  node [
    id 967
    label "E:OLD WILLIAM LUFFE"
    kind "entity"
    name "OLD WILLIAM LUFFE"
    community 2
  ]
  node [
    id 968
    label "E:L20"
    kind "entity"
    name "L20"
    community 2
  ]
  node [
    id 969
    label "E:R. BARNWELL"
    kind "entity"
    name "R. BARNWELL"
    community 2
  ]
  node [
    id 970
    label "E:MR. PIGOTT"
    kind "entity"
    name "MR. PIGOTT"
    community 2
  ]
  node [
    id 971
    label "E:BIGGLESWORTH"
    kind "entity"
    name "BIGGLESWORTH"
    community 2
  ]
  node [
    id 972
    label "E:THREAD STOCKINGS"
    kind "entity"
    name "THREAD STOCKINGS"
    community 2
  ]
  node [
    id 973
    label "E:COARSE WOOLLEN STOCKINGS"
    kind "entity"
    name "COARSE WOOLLEN STOCKINGS"
    community 2
  ]
  node [
    id 974
    label "E:COLD DAY"
    kind "entity"
    name "COLD DAY"
    community 2
  ]
  node [
    id 975
    label "E:FOUR O'CLOCK"
    kind "entity"
    name "FOUR O'CLOCK"
    community 2
  ]
  node [
    id 976
    label "E:OTHER MATTERS"
    kind "entity"
    name "OTHER MATTERS"
    community 2
  ]
  node [
    id 977
    label "E:EVERYONE"
    kind "entity"
    name "EVERYONE"
    community 10
  ]
  node [
    id 978
    label "E:TO-MORROW"
    kind "entity"
    name "TO-MORROW"
    community 2
  ]
  node [
    id 979
    label "E:SURRENDER OF STURTLOW"
    kind "entity"
    name "SURRENDER OF STURTLOW"
    community 2
  ]
  node [
    id 980
    label "E:UNCLE DID DELIVER STURTLOW"
    kind "entity"
    name "UNCLE DID DELIVER STURTLOW"
    community 2
  ]
  node [
    id 981
    label "E:AFTER SUPPER"
    kind "entity"
    name "AFTER SUPPER"
    community 2
  ]
  node [
    id 982
    label "E:BY FOUR"
    kind "entity"
    name "BY FOUR"
    community 2
  ]
  node [
    id 983
    label "E:TO BUY STOCKINGS"
    kind "entity"
    name "TO BUY STOCKINGS"
    community 2
  ]
  node [
    id 984
    label "U:Novel-4128_00040#1"
    kind "unit"
    chunk_id "Novel-4128_00040"
    text "The narrator went to London by four o'clock, but the day was very cold. Because the narrator had only worn thread stockings under his boots, he had to buy a pair of coarse woollen stockings at Bigglesworth and put them on."
    community 2
  ]
  node [
    id 985
    label "E:NARRATOR TO WEAR THREAD STOCKINGS"
    kind "entity"
    name "NARRATOR TO WEAR THREAD STOCKINGS"
    community 2
  ]
  node [
    id 986
    label "C:Novel-4128_00041"
    kind "chunk"
    chunk_id "Novel-4128_00041"
  ]
  node [
    id 987
    label "U:Novel-4128_00041#0"
    kind "unit"
    chunk_id "Novel-4128_00041"
    text "The narrator walks alone from Hatfield to the Vineyard after a good dinner at my Lord of Salisbury's Inn, where he meets Mr. Looker, the gardener and a friend of Mr. Eglin, who shows him the house, the chappell with brave pictures, and the gardens, which are exceptionally beautiful with large gooseberries as big as nutmegs. After returning to the inn, the narrator drinks with Mr. Looker and then rides to London, where he sets Mr. Looker up at Smithfield. He then visits his uncle Fenner, his mother, and his Lady, and returns home, finding everything as expected. The narrator is very weary and goes to bed."
    community 4
  ]
  node [
    id 988
    label "E:HATFIELD"
    kind "entity"
    name "HATFIELD"
    community 5
  ]
  node [
    id 989
    label "E:MY LORD OF SALISBURY'S INN"
    kind "entity"
    name "MY LORD OF SALISBURY'S INN"
    community 4
  ]
  node [
    id 990
    label "E:VINEYARD"
    kind "entity"
    name "VINEYARD"
    community 4
  ]
  node [
    id 991
    label "E:MR. LOOKER"
    kind "entity"
    name "MR. LOOKER"
    community 4
  ]
  node [
    id 992
    label "E:MR. EGLIN"
    kind "entity"
    name "MR. EGLIN"
    community 4
  ]
  node [
    id 993
    label "E:CHAPPELL"
    kind "entity"
    name "CHAPPELL"
    community 4
  ]
  node [
    id 994
    label "E:BRAVE PICTURES"
    kind "entity"
    name "BRAVE PICTURES"
    community 4
  ]
  node [
    id 995
    label "E:GARDENS"
    kind "entity"
    name "GARDENS"
    community 4
  ]
  node [
    id 996
    label "E:GOOSEBERRIES"
    kind "entity"
    name "GOOSEBERRIES"
    community 4
  ]
  node [
    id 997
    label "E:NUTMEGS"
    kind "entity"
    name "NUTMEGS"
    community 4
  ]
  node [
    id 998
    label "E:SMITHFIELD"
    kind "entity"
    name "SMITHFIELD"
    community 4
  ]
  node [
    id 999
    label "E:UNCLE FENNER"
    kind "entity"
    name "UNCLE FENNER"
    community 13
  ]
  node [
    id 1000
    label "E:MRS. MICHELL"
    kind "entity"
    name "MRS. MICHELL"
    community 4
  ]
  node [
    id 1001
    label "E:BRENOALT"
    kind "entity"
    name "BRENOALT"
    community 4
  ]
  node [
    id 1002
    label "E:EXPECTED"
    kind "entity"
    name "EXPECTED"
    community 4
  ]
  node [
    id 1003
    label "E:WEARY"
    kind "entity"
    name "WEARY"
    community 4
  ]
  node [
    id 1004
    label "E:MOURNING"
    kind "entity"
    name "MOURNING"
    community 19
  ]
  node [
    id 1005
    label "U:Novel-4128_00041#1"
    kind "unit"
    chunk_id "Novel-4128_00041"
    text "The narrator sat before Mrs. Michell at the theatre and found the play 'Brenoralt' to be good in content but poorly performed."
    community 4
  ]
  node [
    id 1006
    label "C:Novel-4128_00042"
    kind "chunk"
    chunk_id "Novel-4128_00042"
  ]
  node [
    id 1007
    label "U:Novel-4128_00042#0"
    kind "unit"
    chunk_id "Novel-4128_00042"
    text "The narrator sat before Mrs. Palmer, the King's mistress, and was pleased by focusing on her, though he found the play ill acted. He then went to his father's house, where he met his uncle Thomas and discussed his uncle's will, satisfying him as much as he could."
    community 1
  ]
  node [
    id 1008
    label "E:MRS. PALMER"
    kind "entity"
    name "MRS. PALMER"
    community 1
  ]
  node [
    id 1009
    label "E:KING'S MISTRESS"
    kind "entity"
    name "KING'S MISTRESS"
    community 1
  ]
  node [
    id 1010
    label "E:UNCLE THOMAS"
    kind "entity"
    name "UNCLE THOMAS"
    community 3
  ]
  node [
    id 1011
    label "E:UNCLE'S WILL"
    kind "entity"
    name "UNCLE'S WILL"
    community 4
  ]
  node [
    id 1012
    label "E:FOCUSING ON HER"
    kind "entity"
    name "FOCUSING ON HER"
    community 1
  ]
  node [
    id 1013
    label "U:Novel-4128_00042#1"
    kind "unit"
    chunk_id "Novel-4128_00042"
    text "The narrator visited his uncle Wight's house but found him outside; he saw his aunt and stayed with her for a while before returning home and going to bed. He is troubled by hearing that Pall has become proud and idle, and decides not to keep her."
    community 3
  ]
  node [
    id 1014
    label "E:UNCLE WIGHT WAS OUT OF DOORS"
    kind "entity"
    name "UNCLE WIGHT WAS OUT OF DOORS"
    community 3
  ]
  node [
    id 1015
    label "E:PALL'S PRIDE AND IDLENESS"
    kind "entity"
    name "PALL'S PRIDE AND IDLENESS"
    community 3
  ]
  node [
    id 1016
    label "U:Novel-4128_00042#2"
    kind "unit"
    chunk_id "Novel-4128_00042"
    text "On the 24th, the narrator's wife in bed informed him that their silver tankard had been stolen, which vexed him due to the negligence of his people for leaving the door open. The narrator and his wife traveled by water to Whitehall, where he left her to her business and went to his cousin Thomas Pepys, discussing their business related to his uncle's will. Pepys provided no information about the estate and only stated that he believes his uncle left little money, though more than the amount found, which is about L500."
    community 2
  ]
  node [
    id 1017
    label "E:SILVER TANKARD"
    kind "entity"
    name "SILVER TANKARD"
    community 2
  ]
  node [
    id 1018
    label "E:NEGLECT"
    kind "entity"
    name "NEGLECT"
    community 2
  ]
  node [
    id 1019
    label "E:DOOR"
    kind "entity"
    name "DOOR"
    community 2
  ]
  node [
    id 1020
    label "E:COUSIN THOMAS PEPYS"
    kind "entity"
    name "COUSIN THOMAS PEPYS"
    community 2
  ]
  node [
    id 1021
    label "E:NEGLIGENCE OF HIS PEOPLE FOR LEAVING THE DOOR OPEN"
    kind "entity"
    name "NEGLIGENCE OF HIS PEOPLE FOR LEAVING THE DOOR OPEN"
    community 2
  ]
  node [
    id 1022
    label "E:WIFE TO HER BUSINESS"
    kind "entity"
    name "WIFE TO HER BUSINESS"
    community 2
  ]
  node [
    id 1023
    label "E:UNCLE'S ESTATE"
    kind "entity"
    name "UNCLE'S ESTATE"
    community 2
  ]
  node [
    id 1024
    label "E:UNCLE LEFT LITTLE MONEY"
    kind "entity"
    name "UNCLE LEFT LITTLE MONEY"
    community 2
  ]
  node [
    id 1025
    label "C:Novel-4128_00043"
    kind "chunk"
    chunk_id "Novel-4128_00043"
  ]
  node [
    id 1026
    label "U:Novel-4128_00043#0"
    kind "unit"
    chunk_id "Novel-4128_00043"
    text "Sir G. Lane arrived by chance, saw a bill on the door offering to hire the house, and walked with the narrator's cousin and the narrator throughout the place, which they found very pretty. Sir G. Lane intended to withdraw the agreement for the house, which originally included a fine of L400 and annual rent of L46 to the narrator. The narrator and his cousin then went to the wardrobe but arrived too late, and dined with the servants. Later, they visited my Lady, who showed the narrator and his wife the greatest favor, which the narrator found deeply satisfying."
    community 11
  ]
  node [
    id 1027
    label "E:SIR G. LANE"
    kind "entity"
    name "SIR G. LANE"
    community 11
  ]
  node [
    id 1028
    label "E:COUSIN"
    kind "entity"
    name "COUSIN"
    community 11
  ]
  node [
    id 1029
    label "E:L400"
    kind "entity"
    name "L400"
    community 11
  ]
  node [
    id 1030
    label "E:L46"
    kind "entity"
    name "L46"
    community 11
  ]
  node [
    id 1031
    label "E:FAVOR"
    kind "entity"
    name "FAVOR"
    community 11
  ]
  node [
    id 1032
    label "E:PLEASURE"
    kind "entity"
    name "PLEASURE"
    community 13
  ]
  node [
    id 1033
    label "E:ESTEEM"
    kind "entity"
    name "ESTEEM"
    community 11
  ]
  node [
    id 1034
    label "E:JOURNALS"
    kind "entity"
    name "JOURNALS"
    community 11
  ]
  node [
    id 1035
    label "E:JOURNEY"
    kind "entity"
    name "JOURNEY"
    community 11
  ]
  node [
    id 1036
    label "E:MONEYS"
    kind "entity"
    name "MONEYS"
    community 11
  ]
  node [
    id 1037
    label "E:MAN WILL"
    kind "entity"
    name "MAN WILL"
    community 11
  ]
  node [
    id 1038
    label "E:CLOCK"
    kind "entity"
    name "CLOCK"
    community 11
  ]
  node [
    id 1039
    label "E:TANKARD"
    kind "entity"
    name "TANKARD"
    community 11
  ]
  node [
    id 1040
    label "E:L200"
    kind "entity"
    name "L200"
    community 5
  ]
  node [
    id 1041
    label "E:MAN WILL LOST CLOCK"
    kind "entity"
    name "MAN WILL LOST CLOCK"
    community 11
  ]
  node [
    id 1042
    label "E:BOX OF PAPERS"
    kind "entity"
    name "BOX OF PAPERS"
    community 11
  ]
  node [
    id 1043
    label "U:Novel-4128_00043#1"
    kind "unit"
    chunk_id "Novel-4128_00043"
    text "On the 25th, the narrator received a box of papers from Brampton containing all of his uncle's papers, which provided sufficient work for him."
    community 11
  ]
  node [
    id 1044
    label "C:Novel-4128_00044"
    kind "chunk"
    chunk_id "Novel-4128_00044"
  ]
  node [
    id 1045
    label "U:Novel-4128_00044#0"
    kind "unit"
    chunk_id "Novel-4128_00044"
    text "At noon, the narrator went to the Exchange, where he met his uncle Wight, who was discontented about his father, possibly because the father feels unacquainted with things or feels abandoned, and the narrator is troubled by this; he did not stay long to talk with his uncle. Then he went to his mother's house, where he found his wife, his aunt Bell, and Mrs. Ramsey, and heard a great deal of gossip among the older women and his mother, who believed something unfortunate had befallen her, which made the narrator angry, but he did not speak about it at the time. He then left with Mr. Moore and went to the Theatre, where they saw 'The Jovial Crew' for the first time, which the narrator found merry and innocent, and well performed. Afterward, he returned home and wrote to his father before going to bed, reflecting on the worries about the difficulties they would face before knowing what would remain of their expectations."
    community 12
  ]
  node [
    id 1046
    label "E:AUNT BELL"
    kind "entity"
    name "AUNT BELL"
    community 13
  ]
  node [
    id 1047
    label "E:MRS. RAMSEY"
    kind "entity"
    name "MRS. RAMSEY"
    community 12
  ]
  node [
    id 1048
    label "E:JOVIAL CREW"
    kind "entity"
    name "JOVIAL CREW"
    community 12
  ]
  node [
    id 1049
    label "E:MOTHER'S"
    kind "entity"
    name "MOTHER'S"
    community 12
  ]
  node [
    id 1050
    label "E:OLD WOMEN"
    kind "entity"
    name "OLD WOMEN"
    community 12
  ]
  node [
    id 1051
    label "E:MOTHER'S GOSIP"
    kind "entity"
    name "MOTHER'S GOSIP"
    community 12
  ]
  node [
    id 1052
    label "E:DIFFICULTIES BEFORE KNOWING WHAT REMAINS OF EXPECTATIONS"
    kind "entity"
    name "DIFFICULTIES BEFORE KNOWING WHAT REMAINS OF EXPECTATIONS"
    community 12
  ]
  node [
    id 1053
    label "U:Novel-4128_00044#1"
    kind "unit"
    chunk_id "Novel-4128_00044"
    text "On the 26th, the narrator was at home all morning and while walking met with Mr. [name missing or incomplete]."
    community 12
  ]
  node [
    id 1054
    label "C:Novel-4128_00045"
    kind "chunk"
    chunk_id "Novel-4128_00045"
  ]
  node [
    id 1055
    label "U:Novel-4128_00045#0"
    kind "unit"
    chunk_id "Novel-4128_00045"
    text "On the 26th, the narrator was at home all morning and met Mr. Hill of Cambridge at Pope's Head Alley with some women, who took them to a tavern where Mr. Hill served wine and claimed that the previous day's events had changed the state of England's Church, stating that the King would have to favor Presbytery or the City would leave him. The narrator does not heed Mr. Hill's claims but notes that Parliament is in great disorder. At noon, the narrator met Mr. Moore and they went to an ordinary to dine, where they read the narrator's uncle's will and the narrator received Mr. Moore's opinion on it, which brought more anticipated trouble. In the afternoon, the narrator returned to the office and stayed there until night. The narrator had vowed at the beginning of the week to drink no wine because it was unfit for managing business, but broke this vow that day against his will and is troubled by it, hoping God will forgive him."
    community 16
  ]
  node [
    id 1056
    label "E:MR. HILL OF CAMBRIDGE"
    kind "entity"
    name "MR. HILL OF CAMBRIDGE"
    community 16
  ]
  node [
    id 1057
    label "E:POPE'S HEAD ALLEY"
    kind "entity"
    name "POPE'S HEAD ALLEY"
    community 16
  ]
  node [
    id 1058
    label "E:STATE OF ENGLAND"
    kind "entity"
    name "STATE OF ENGLAND"
    community 16
  ]
  node [
    id 1059
    label "E:PRESBYTERY"
    kind "entity"
    name "PRESBYTERY"
    community 16
  ]
  node [
    id 1060
    label "E:PARLIAMENT"
    kind "entity"
    name "PARLIAMENT"
    community 21
  ]
  node [
    id 1061
    label "E:GREAT DISORDER"
    kind "entity"
    name "GREAT DISORDER"
    community 16
  ]
  node [
    id 1062
    label "E:VOW"
    kind "entity"
    name "VOW"
    community 16
  ]
  node [
    id 1063
    label "E:TRUBLE"
    kind "entity"
    name "TRUBLE"
    community 18
  ]
  node [
    id 1064
    label "E:GOD"
    kind "entity"
    name "GOD"
    community 16
  ]
  node [
    id 1065
    label "E:STATE OF ENGLAND CHURCH"
    kind "entity"
    name "STATE OF ENGLAND CHURCH"
    community 16
  ]
  node [
    id 1066
    label "E:KING MUST FAVOR PRESBYTERY OR CITY WOULD LEAVE HIM"
    kind "entity"
    name "KING MUST FAVOR PRESBYTERY OR CITY WOULD LEAVE HIM"
    community 16
  ]
  node [
    id 1067
    label "E:PARLIAMENT IS IN GREAT DISORDER"
    kind "entity"
    name "PARLIAMENT IS IN GREAT DISORDER"
    community 16
  ]
  node [
    id 1068
    label "E:BREAKING VOW"
    kind "entity"
    name "BREAKING VOW"
    community 16
  ]
  node [
    id 1069
    label "U:Novel-4128_00045#1"
    kind "unit"
    chunk_id "Novel-4128_00045"
    text "On the 27th, the narrator went to Westminster, where they met Mr. [name not provided], and the visit began."
    community 0
  ]
  node [
    id 1070
    label "C:Novel-4128_00046"
    kind "chunk"
    chunk_id "Novel-4128_00046"
  ]
  node [
    id 1071
    label "U:Novel-4128_00046#0"
    kind "unit"
    chunk_id "Novel-4128_00046"
    text "At Mr. Montagu's chamber in Westminster, a Frenchman who is a friend of Monsieur Eschar played the guitar extremely well, though the speaker considers it merely a bawble. At Westminster Hall, it was expected that Parliament would be adjourned for two or three months, but it is now delayed by a day or two. In the lobby, the speaker spoke with Mr. George Montagu, advised him about a ship to carry my Lord Hinchingbroke and the other young gentlemen to France, and learned that they have decided to go in a hired vessel from Rye, not in a man of war. Mr. George Montagu stated that my Lord Chancellor is much envied, and that many great men, including the Duke of Buckingham and my Lord of Bristoll, are trying to undermine him, but he believes it will not succeed because the King, although not fond of him as a companion, cannot function without him due to his policy and service. At the Wardrobe, the speaker met his wife, as it was my Lord of Sandwich's birthday, and they had many friends there."
    community 21
  ]
  node [
    id 1072
    label "E:MR. MONTAGU"
    kind "entity"
    name "MR. MONTAGU"
    community 21
  ]
  node [
    id 1073
    label "E:FRENCHMAN"
    kind "entity"
    name "FRENCHMAN"
    community 21
  ]
  node [
    id 1074
    label "E:MONSEIGNEUR ESCAR"
    kind "entity"
    name "MONSEIGNEUR ESCAR"
    community 21
  ]
  node [
    id 1075
    label "E:GUITAR"
    kind "entity"
    name "GUITAR"
    community 21
  ]
  node [
    id 1076
    label "E:ADJOURNMENT"
    kind "entity"
    name "ADJOURNMENT"
    community 21
  ]
  node [
    id 1077
    label "E:MR. GEORGE MONTAGU"
    kind "entity"
    name "MR. GEORGE MONTAGU"
    community 21
  ]
  node [
    id 1078
    label "E:MY LORD HINCHINGBROKE"
    kind "entity"
    name "MY LORD HINCHINGBROKE"
    community 21
  ]
  node [
    id 1079
    label "E:YOUNG GENTLEMEN"
    kind "entity"
    name "YOUNG GENTLEMEN"
    community 21
  ]
  node [
    id 1080
    label "E:HIRED VESSEL"
    kind "entity"
    name "HIRED VESSEL"
    community 21
  ]
  node [
    id 1081
    label "E:RYE"
    kind "entity"
    name "RYE"
    community 21
  ]
  node [
    id 1082
    label "E:MAN OF WAR"
    kind "entity"
    name "MAN OF WAR"
    community 21
  ]
  node [
    id 1083
    label "E:MY LORD CHANCELLOR"
    kind "entity"
    name "MY LORD CHANCELLOR"
    community 21
  ]
  node [
    id 1084
    label "E:DUKE OF BUCKINGHAM"
    kind "entity"
    name "DUKE OF BUCKINGHAM"
    community 21
  ]
  node [
    id 1085
    label "E:MY LORD OF BRISTOLL"
    kind "entity"
    name "MY LORD OF BRISTOLL"
    community 21
  ]
  node [
    id 1086
    label "E:MY LORD OF SANDWICH"
    kind "entity"
    name "MY LORD OF SANDWICH"
    community 20
  ]
  node [
    id 1087
    label "E:MR. MONTAGU'S CHAMBER"
    kind "entity"
    name "MR. MONTAGU'S CHAMBER"
    community 21
  ]
  node [
    id 1088
    label "E:TWO OR THREE MONTHS"
    kind "entity"
    name "TWO OR THREE MONTHS"
    community 21
  ]
  node [
    id 1089
    label "E:DAY OR TWO"
    kind "entity"
    name "DAY OR TWO"
    community 21
  ]
  node [
    id 1090
    label "E:HI RED VESSEL FROM RYE"
    kind "entity"
    name "HI RED VESSEL FROM RYE"
    community 21
  ]
  node [
    id 1091
    label "E:MANY GREAT MEN"
    kind "entity"
    name "MANY GREAT MEN"
    community 21
  ]
  node [
    id 1092
    label "E:YOUNG GALLANTS WHO CAN ANSWER HIM IN PLEASURES"
    kind "entity"
    name "YOUNG GALLANTS WHO CAN ANSWER HIM IN PLEASURES"
    community 21
  ]
  node [
    id 1093
    label "E:SPEAKER AND WIFE"
    kind "entity"
    name "SPEAKER AND WIFE"
    community 21
  ]
  node [
    id 1094
    label "U:Novel-4128_00046#1"
    kind "unit"
    chunk_id "Novel-4128_00046"
    text "The speaker met his wife at the Wardrobe, where it was my Lord of Sandwich's birthday, and they had many friends present."
    community 20
  ]
  node [
    id 1095
    label "E:FRIENDS"
    kind "entity"
    name "FRIENDS"
    community 20
  ]
  node [
    id 1096
    label "E:WIFE AT WARDROBE"
    kind "entity"
    name "WIFE AT WARDROBE"
    community 20
  ]
  node [
    id 1097
    label "C:Novel-4128_00047"
    kind "chunk"
    chunk_id "Novel-4128_00047"
  ]
  node [
    id 1098
    label "U:Novel-4128_00047#0"
    kind "unit"
    chunk_id "Novel-4128_00047"
    text "Townsend and his wife, Captain Ferrers' lady, Captain Isham, and Mr. Pargiter, the merchant, were very merry and had a good venison pasty. After dinner, Townsend and two others went to a tavern near by where Captain Cooke gave them a song or two, and it is noted that he has the best manner of singing in the world. Later, Townsend and his wife went with his Lady Jem and Pall by water through the bridge, showed them the ships with great pleasure, and then took them to his house to show it to them, as his Lady's mother had recently been alone to see it and his wife had been absent in the country. They treated them well and were very merry. Afterward, they returned through the bridge and set them safely at home. Then Townsend and his wife returned by coach home, and after that, wrote a letter to his father at Brampton, who is there alone and has not been heard from since Townsend left him, which troubles him. That evening, Townsend and his wife went to church, where Mrs. Ramsay came to see them. They sent her to church and went too, returned for dinner, and she dined with them and was welcomed."
    community 15
  ]
  node [
    id 1099
    label "E:HIS WIFE"
    kind "entity"
    name "HIS WIFE"
    community 15
  ]
  node [
    id 1100
    label "E:CAPTAIN FERRERS' LADY"
    kind "entity"
    name "CAPTAIN FERRERS' LADY"
    community 15
  ]
  node [
    id 1101
    label "E:CAPTAIN ISHAM"
    kind "entity"
    name "CAPTAIN ISHAM"
    community 14
  ]
  node [
    id 1102
    label "E:MR. PARGITER"
    kind "entity"
    name "MR. PARGITER"
    community 15
  ]
  node [
    id 1103
    label "E:MERCHANT"
    kind "entity"
    name "MERCHANT"
    community 15
  ]
  node [
    id 1104
    label "E:CAPTAIN COOKE"
    kind "entity"
    name "CAPTAIN COOKE"
    community 15
  ]
  node [
    id 1105
    label "E:MRS. RAMSAY"
    kind "entity"
    name "MRS. RAMSAY"
    community 15
  ]
  node [
    id 1106
    label "E:LADY JEM"
    kind "entity"
    name "LADY JEM"
    community 15
  ]
  node [
    id 1107
    label "E:SONG OR TWO"
    kind "entity"
    name "SONG OR TWO"
    community 15
  ]
  node [
    id 1108
    label "E:IN THE WORLD"
    kind "entity"
    name "IN THE WORLD"
    community 15
  ]
  node [
    id 1109
    label "E:HIS LADY AND PALL TO HIS HOUSE"
    kind "entity"
    name "HIS LADY AND PALL TO HIS HOUSE"
    community 15
  ]
  node [
    id 1110
    label "E:HIS LADY'S MOTHER"
    kind "entity"
    name "HIS LADY'S MOTHER"
    community 15
  ]
  node [
    id 1111
    label "E:THEY WELL"
    kind "entity"
    name "THEY WELL"
    community 15
  ]
  node [
    id 1112
    label "E:HIS FATHER AT BRAMPTON"
    kind "entity"
    name "HIS FATHER AT BRAMPTON"
    community 15
  ]
  node [
    id 1113
    label "E:TOWNSEND LEFT HIM"
    kind "entity"
    name "TOWNSEND LEFT HIM"
    community 15
  ]
  node [
    id 1114
    label "E:TOWNSEND AND HIS WIFE"
    kind "entity"
    name "TOWNSEND AND HIS WIFE"
    community 15
  ]
  node [
    id 1115
    label "E:MRS. RAMSAY TO CHURCH"
    kind "entity"
    name "MRS. RAMSAY TO CHURCH"
    community 15
  ]
  node [
    id 1116
    label "U:Novel-4128_00047#1"
    kind "unit"
    chunk_id "Novel-4128_00047"
    text "On the 28th (Lord's day), Townsend and his wife went to church where Mrs. Ramsay came to see them. They sent her to church and went too, returned for dinner, and she dined with them and was welcomed."
    community 15
  ]
  node [
    id 1117
    label "C:Novel-4128_00048"
    kind "chunk"
    chunk_id "Novel-4128_00048"
  ]
  node [
    id 1118
    label "U:Novel-4128_00048#0"
    kind "unit"
    chunk_id "Novel-4128_00048"
    text "In the afternoon, the narrator went to church, then came home with Sir W. Pen, who drank with them before leaving. The narrator's wife followed Sir W. Pen to see his daughter, who recently arrived from Ireland. The narrator stayed at home reading a book; later, the wife returned and told him that although he expected her to be a great beauty, she is a very plain girl. That evening, the wife gave the narrator all his linen, which he had previously put up and now intends to keep in his own custody. They had supper and went to bed."
    community 13
  ]
  node [
    id 1119
    label "E:DAUGHTER OF SIR W. PEN"
    kind "entity"
    name "DAUGHTER OF SIR W. PEN"
    community 13
  ]
  node [
    id 1120
    label "E:IRELAND"
    kind "entity"
    name "IRELAND"
    community 13
  ]
  node [
    id 1121
    label "E:BOOK"
    kind "entity"
    name "BOOK"
    community 13
  ]
  node [
    id 1122
    label "E:LINEN"
    kind "entity"
    name "LINEN"
    community 13
  ]
  node [
    id 1123
    label "E:SIR R. FORD"
    kind "entity"
    name "SIR R. FORD"
    community 6
  ]
  node [
    id 1124
    label "E:TRADE"
    kind "entity"
    name "TRADE"
    community 13
  ]
  node [
    id 1125
    label "E:AFTER DRINKING"
    kind "entity"
    name "AFTER DRINKING"
    community 13
  ]
  node [
    id 1126
    label "U:Novel-4128_00048#1"
    kind "unit"
    chunk_id "Novel-4128_00048"
    text "On the 29th morning, the narrator and Sir R. Slingsby went to see Sir R. Ford's house, and they found it would be very convenient to add it to the office if Sir R. Ford could part with it. Afterward, they sat down and did business in the office. They returned home for dinner, and the narrator's brother Tom dined with him. After dinner, Tom and the narrator had a long conversation in the narrator's chamber, during which the narrator learned that unless his father forbears making profit from his London house and leaves it to Tom, he has no intention of setting up the trade elsewhere, and the narrator does not know what to do with his father."
    community 13
  ]
  node [
    id 1127
    label "E:CONVERSATION"
    kind "entity"
    name "CONVERSATION"
    community 13
  ]
  node [
    id 1128
    label "E:SIR R. FORD'S HOUSE"
    kind "entity"
    name "SIR R. FORD'S HOUSE"
    community 6
  ]
  node [
    id 1129
    label "E:HOUSE IN LONDON"
    kind "entity"
    name "HOUSE IN LONDON"
    community 13
  ]
  node [
    id 1130
    label "C:Novel-4128_00049"
    kind "chunk"
    chunk_id "Novel-4128_00049"
  ]
  node [
    id 1131
    label "U:Novel-4128_00049#0"
    kind "unit"
    chunk_id "Novel-4128_00049"
    text "After this, the speaker went with someone to their mother and told her how things fall short of expectations, which the speaker did even though it is true, in order to make her stop spending, as the speaker finds she is now very free with money, using what is left from their uncle's inheritance to support her spending, which causes the speaker much concern."
    community 4
  ]
  node [
    id 1132
    label "E:EXPECTATIONS"
    kind "entity"
    name "EXPECTATIONS"
    community 1
  ]
  node [
    id 1133
    label "E:SPEAKING MASTER"
    kind "entity"
    name "SPEAKING MASTER"
    community 4
  ]
  node [
    id 1134
    label "E:INHERITANCE"
    kind "entity"
    name "INHERITANCE"
    community 4
  ]
  node [
    id 1135
    label "E:SPENDING"
    kind "entity"
    name "SPENDING"
    community 4
  ]
  node [
    id 1136
    label "E:MOTHER IS VERY FREE WITH SPENDING"
    kind "entity"
    name "MOTHER IS VERY FREE WITH SPENDING"
    community 4
  ]
  node [
    id 1137
    label "E:MONEY FROM INHERITANCE"
    kind "entity"
    name "MONEY FROM INHERITANCE"
    community 4
  ]
  node [
    id 1138
    label "E:MOTHER'S SPENDING"
    kind "entity"
    name "MOTHER'S SPENDING"
    community 4
  ]
  node [
    id 1139
    label "U:Novel-4128_00049#1"
    kind "unit"
    chunk_id "Novel-4128_00049"
    text "The speaker learns that their aunt Fenner is extremely ill and that their mother is being sent for to go to her, and also that their cousin Charles Glassecocke, although very ill himself, has gone to the country to visit his brother John Glassecocke, who is dying there."
    community 3
  ]
  node [
    id 1140
    label "E:AUNT FENNER"
    kind "entity"
    name "AUNT FENNER"
    community 0
  ]
  node [
    id 1141
    label "E:COZEN CHARLES GLASSECOCKE"
    kind "entity"
    name "COZEN CHARLES GLASSECOCKE"
    community 3
  ]
  node [
    id 1142
    label "E:JOHN GLASSECOCKE"
    kind "entity"
    name "JOHN GLASSECOCKE"
    community 3
  ]
  node [
    id 1143
    label "E:ILLNESS"
    kind "entity"
    name "ILLNESS"
    community 3
  ]
  node [
    id 1144
    label "E:DYING"
    kind "entity"
    name "DYING"
    community 3
  ]
  node [
    id 1145
    label "E:CHARLES GLASSECOCKE"
    kind "entity"
    name "CHARLES GLASSECOCKE"
    community 3
  ]
  node [
    id 1146
    label "U:Novel-4128_00049#2"
    kind "unit"
    chunk_id "Novel-4128_00049"
    text "After singing with their singing-master, the speaker went to White Hall and Westminster Hall, where they found the King expected to come and adjourn the Parliament, and the two Houses were in disagreement about the Lords challenging their privilege against house searches, which caused them to deny passing the House of Commons' Bill for searching pamphlets and seditious books."
    community 5
  ]
  node [
    id 1147
    label "E:SINGING-MASTER"
    kind "entity"
    name "SINGING-MASTER"
    community 5
  ]
  node [
    id 1148
    label "E:HOUSE OF COMMONS"
    kind "entity"
    name "HOUSE OF COMMONS"
    community 5
  ]
  node [
    id 1149
    label "E:SEARCHING FOR PAMPHLETS"
    kind "entity"
    name "SEARCHING FOR PAMPHLETS"
    community 5
  ]
  node [
    id 1150
    label "E:SEDITIOUS BOOKS"
    kind "entity"
    name "SEDITIOUS BOOKS"
    community 5
  ]
  node [
    id 1151
    label "E:BILL"
    kind "entity"
    name "BILL"
    community 5
  ]
  node [
    id 1152
    label "E:PRIVILEGE"
    kind "entity"
    name "PRIVILEGE"
    community 5
  ]
  node [
    id 1153
    label "E:HOUSE SEARCHES"
    kind "entity"
    name "HOUSE SEARCHES"
    community 5
  ]
  node [
    id 1154
    label "E:WHITE HALL AND WESTMINSTER HALL"
    kind "entity"
    name "WHITE HALL AND WESTMINSTER HALL"
    community 5
  ]
  node [
    id 1155
    label "E:PRIVILEGE AGAINST HOUSE SEARCHES"
    kind "entity"
    name "PRIVILEGE AGAINST HOUSE SEARCHES"
    community 5
  ]
  node [
    id 1156
    label "E:BILL FOR SEARCHING PAMPHLETS AND SEDITIOUS BOOKS"
    kind "entity"
    name "BILL FOR SEARCHING PAMPHLETS AND SEDITIOUS BOOKS"
    community 5
  ]
  node [
    id 1157
    label "E:SEARCHING PAMPHLETS AND SEDITIOUS BOOKS"
    kind "entity"
    name "SEARCHING PAMPHLETS AND SEDITIOUS BOOKS"
    community 5
  ]
  node [
    id 1158
    label "U:Novel-4128_00049#3"
    kind "unit"
    chunk_id "Novel-4128_00049"
    text "The speaker then traveled by water to the Wardrobe, where they met the King on the way in his barge as he was going to adjourn the House, dined with their Lady, and met Dr."
    community 14
  ]
  node [
    id 1159
    label "E:BARGE"
    kind "entity"
    name "BARGE"
    community 14
  ]
  node [
    id 1160
    label "C:Novel-4128_00050"
    kind "chunk"
    chunk_id "Novel-4128_00050"
  ]
  node [
    id 1161
    label "U:Novel-4128_00050#0"
    kind "unit"
    chunk_id "Novel-4128_00050"
    text "Thomas Pepys is described as a silly talking fellow but very good-natured. After returning home, the narrator met about business in Tangier in the afternoon. Later, at home, the narrator found Mr. Moore and they walked into the City, where they parted. The narrator then went to Fleet Street to find when the Assizes begin at Cambridge and Huntingdon in order to meet Roger Pepys for counsel. At Fleet Street, the narrator met Mr. Salisbury, who has become a very skilled limner and earns a great deal of money in less than two years. The narrator took Mr. Salisbury to Hercules Pillars to drink, where Mr. Whore, a former friend of Mr. Salisbury, arrived and was a very ingenious fellow. The narrator sat with them for a while and then returned home to write letters to his Lord and to his father, after which he went to bed."
    community 8
  ]
  node [
    id 1162
    label "E:THOMAS PEPYS"
    kind "entity"
    name "THOMAS PEPYS"
    community 8
  ]
  node [
    id 1163
    label "E:TANGIER"
    kind "entity"
    name "TANGIER"
    community 8
  ]
  node [
    id 1164
    label "E:FLEET STREET"
    kind "entity"
    name "FLEET STREET"
    community 8
  ]
  node [
    id 1165
    label "E:ASSIZES"
    kind "entity"
    name "ASSIZES"
    community 8
  ]
  node [
    id 1166
    label "E:MR. SALISBURY"
    kind "entity"
    name "MR. SALISBURY"
    community 8
  ]
  node [
    id 1167
    label "E:HERCULES PILLARS"
    kind "entity"
    name "HERCULES PILLARS"
    community 8
  ]
  node [
    id 1168
    label "E:MR. WHORE"
    kind "entity"
    name "MR. WHORE"
    community 8
  ]
  node [
    id 1169
    label "E:L40"
    kind "entity"
    name "L40"
    community 8
  ]
  node [
    id 1170
    label "E:SILLY TALKING FELLOW BUT VERY GOOD-NATURED"
    kind "entity"
    name "SILLY TALKING FELLOW BUT VERY GOOD-NATURED"
    community 8
  ]
  node [
    id 1171
    label "E:CAMBRIDGE AND HUNTINGDON"
    kind "entity"
    name "CAMBRIDGE AND HUNTINGDON"
    community 8
  ]
  node [
    id 1172
    label "E:EXCELLENT LIMNER"
    kind "entity"
    name "EXCELLENT LIMNER"
    community 8
  ]
  node [
    id 1173
    label "E:GREAT DEAL OF MONEY"
    kind "entity"
    name "GREAT DEAL OF MONEY"
    community 8
  ]
  node [
    id 1174
    label "E:VERY INGENIOUS"
    kind "entity"
    name "VERY INGENIOUS"
    community 8
  ]
  node [
    id 1175
    label "E:MR. SALISBURY AND MR. WHORE"
    kind "entity"
    name "MR. SALISBURY AND MR. WHORE"
    community 8
  ]
  node [
    id 1176
    label "U:Novel-4128_00050#1"
    kind "unit"
    chunk_id "Novel-4128_00050"
    text "On August 1st, the singing-master came to the narrator this morning, and then the narrator went to the office all morning. In the afternoon, the narrator went to the Theatre and saw 'The Tamer Tamed' well done. Afterward, the narrator returned home and prepared to go to Walthamstow the next day. That night, the narrator was forced to borrow L40 from Sir W. Batten."
    community 8
  ]
  node [
    id 1177
    label "E:AUGUST 1ST"
    kind "entity"
    name "AUGUST 1ST"
    community 8
  ]
  node [
    id 1178
    label "E:TAMER TAMED"
    kind "entity"
    name "TAMER TAMED"
    community 8
  ]
  node [
    id 1179
    label "E:WALTHAMSTOW"
    kind "entity"
    name "WALTHAMSTOW"
    community 8
  ]
  node [
    id 1180
    label "C:Novel-4128_00051"
    kind "chunk"
    chunk_id "Novel-4128_00051"
  ]
  node [
    id 1181
    label "U:Novel-4128_00051#0"
    kind "unit"
    chunk_id "Novel-4128_00051"
    text "On August 1st, 1661, Sir Williams, Samuel Pepys, his wife, and Mrs. Margarett Pen (whom Pepys had not seen since she arrived from Ireland) traveled by coach to Walthamstow to gossip with Mrs. Browne, where Pepys gave her six silver spoons&#8212;excluding the porringer&#8212;as a gift for her boy. They ate a venison pasty brought hot from London and enjoyed themselves. Pepys heard that the nurse's husband had spoken negatively about Lady Batten, claiming she was a man's whore, and noted that Lady Batten is known to have left her estate to that man. Pepys attempted to reconcile the matter that day but failed, and he believes the story to be true. Later that night, Pepys returned home."
    community 8
  ]
  node [
    id 1182
    label "E:SAMUEL PEPYS'S WIFE"
    kind "entity"
    name "SAMUEL PEPYS'S WIFE"
    community 8
  ]
  node [
    id 1183
    label "E:MRS. MARGARETT PEN"
    kind "entity"
    name "MRS. MARGARETT PEN"
    community 8
  ]
  node [
    id 1184
    label "E:MRS. BROWNE"
    kind "entity"
    name "MRS. BROWNE"
    community 8
  ]
  node [
    id 1185
    label "E:SIX SILVER SPOONS"
    kind "entity"
    name "SIX SILVER SPOONS"
    community 8
  ]
  node [
    id 1186
    label "E:PORRINGER OF SILVER"
    kind "entity"
    name "PORRINGER OF SILVER"
    community 8
  ]
  node [
    id 1187
    label "E:NURSE'S HUSBAND"
    kind "entity"
    name "NURSE'S HUSBAND"
    community 8
  ]
  node [
    id 1188
    label "E:WARE"
    kind "entity"
    name "WARE"
    community 8
  ]
  node [
    id 1189
    label "E:FELLMONGER"
    kind "entity"
    name "FELLMONGER"
    community 8
  ]
  node [
    id 1190
    label "E:QUAKER"
    kind "entity"
    name "QUAKER"
    community 8
  ]
  node [
    id 1191
    label "E:LADY BATTEN AND A MAN"
    kind "entity"
    name "LADY BATTEN AND A MAN"
    community 8
  ]
  node [
    id 1192
    label "E:STORY IS TRUE"
    kind "entity"
    name "STORY IS TRUE"
    community 8
  ]
  node [
    id 1193
    label "E:HIDES"
    kind "entity"
    name "HIDES"
    community 8
  ]
  node [
    id 1194
    label "E:ALL HIS LIFE-TIME"
    kind "entity"
    name "ALL HIS LIFE-TIME"
    community 8
  ]
  node [
    id 1195
    label "E:WITHIN THE LAST TWO YEARS"
    kind "entity"
    name "WITHIN THE LAST TWO YEARS"
    community 8
  ]
  node [
    id 1196
    label "U:Novel-4128_00051#1"
    kind "unit"
    chunk_id "Novel-4128_00051"
    text "On August 2nd, 1661, Samuel Pepys worked at the office all morning. At noon, Dr. Thomas Pepys dined with him. After dinner, his brother Tom visited. Samuel Pepys then prepared himself to ride to Cambridge. He set out that night and rode to Ware, where he had a long conversation with a Quaker fellmonger who described his life as wicked until recently."
    community 8
  ]
  node [
    id 1197
    label "E:AUGUST 2ND, 1661"
    kind "entity"
    name "AUGUST 2ND, 1661"
    community 8
  ]
  node [
    id 1198
    label "E:DR. THOMAS PEPYS"
    kind "entity"
    name "DR. THOMAS PEPYS"
    community 8
  ]
  node [
    id 1199
    label "C:Novel-4128_00052"
    kind "chunk"
    chunk_id "Novel-4128_00052"
  ]
  node [
    id 1200
    label "U:Novel-4128_00052#0"
    kind "unit"
    chunk_id "Novel-4128_00052"
    text "The narrator got up early the next morning, went to Barkway, stayed there and drank, met a letter-carrier from Cambridge, rode with him to Cambridge, and arrived there with a tired horse and being very wet from rain."
    community 5
  ]
  node [
    id 1201
    label "E:BARKWAY"
    kind "entity"
    name "BARKWAY"
    community 5
  ]
  node [
    id 1202
    label "E:LETTER-CARRIER FROM CAMBRIDGE"
    kind "entity"
    name "LETTER-CARRIER FROM CAMBRIDGE"
    community 5
  ]
  node [
    id 1203
    label "E:HORSE"
    kind "entity"
    name "HORSE"
    community 5
  ]
  node [
    id 1204
    label "U:Novel-4128_00052#1"
    kind "unit"
    chunk_id "Novel-4128_00052"
    text "The narrator went to Castle Hill where the judges were holding the Assizes, stayed until Roger Pepys rose, then went with him and his brother the Doctor and Claxton to Trinity Hall, where they dined."
    community 18
  ]
  node [
    id 1205
    label "E:CASTLE HILL"
    kind "entity"
    name "CASTLE HILL"
    community 18
  ]
  node [
    id 1206
    label "E:JUDGES"
    kind "entity"
    name "JUDGES"
    community 18
  ]
  node [
    id 1207
    label "E:DOCTOR"
    kind "entity"
    name "DOCTOR"
    community 18
  ]
  node [
    id 1208
    label "E:CLAXTON"
    kind "entity"
    name "CLAXTON"
    community 18
  ]
  node [
    id 1209
    label "E:ROGER PEPYS ROSE"
    kind "entity"
    name "ROGER PEPYS ROSE"
    community 18
  ]
  node [
    id 1210
    label "U:Novel-4128_00052#2"
    kind "unit"
    chunk_id "Novel-4128_00052"
    text "After dining, the narrator parted from Roger Pepys and went to the Rose, where he sat with Mr. Pechell, Sanchy, and others, drank until night, and was very merry, though they told him that the old doctors in the University were highly regarded for finding them there, despite being better scholars than themselves; the narrator expressed sorrow, especially over Dr. Gunning."
    community 7
  ]
  node [
    id 1211
    label "E:ROSE"
    kind "entity"
    name "ROSE"
    community 7
  ]
  node [
    id 1212
    label "E:MR. PECHELL"
    kind "entity"
    name "MR. PECHELL"
    community 7
  ]
  node [
    id 1213
    label "E:SANCHY"
    kind "entity"
    name "SANCHY"
    community 7
  ]
  node [
    id 1214
    label "E:OLD DOCTORS"
    kind "entity"
    name "OLD DOCTORS"
    community 7
  ]
  node [
    id 1215
    label "E:UNIVERSITY"
    kind "entity"
    name "UNIVERSITY"
    community 7
  ]
  node [
    id 1216
    label "E:BETTER SCHOLARS"
    kind "entity"
    name "BETTER SCHOLARS"
    community 7
  ]
  node [
    id 1217
    label "E:DR. GUNNING"
    kind "entity"
    name "DR. GUNNING"
    community 7
  ]
  node [
    id 1218
    label "E:THESE DOCTORS"
    kind "entity"
    name "THESE DOCTORS"
    community 7
  ]
  node [
    id 1219
    label "U:Novel-4128_00052#3"
    kind "unit"
    chunk_id "Novel-4128_00052"
    text "At night, the narrator took horse and rode with Roger Pepys and his two brothers to Impington, where they were led with great respect to the best chamber in the house and slept there."
    community 18
  ]
  node [
    id 1220
    label "E:TWO BROTHERS"
    kind "entity"
    name "TWO BROTHERS"
    community 18
  ]
  node [
    id 1221
    label "E:BEST CHAMBER"
    kind "entity"
    name "BEST CHAMBER"
    community 18
  ]
  node [
    id 1222
    label "C:Novel-4128_00053"
    kind "chunk"
    chunk_id "Novel-4128_00053"
  ]
  node [
    id 1223
    label "U:Novel-4128_00053#0"
    kind "unit"
    chunk_id "Novel-4128_00053"
    text "On the 4th day (Lord's day), the narrator got up and walked into the orchard with his cozen Roger, where they plucked some fruit and discussed the business the narrator came for&#8212;his uncle's will&#8212;receiving good satisfaction but being warned that he would face a great deal of trouble. His uncle Talbot accompanied them to church, where they had a good plain sermon, and upon arrival, the country people rose with great reverence. The parson began the service by saying 'Right worshipfull and dearly beloved' to them. After church, they had dinner, which was very good, then attended church again, returned home, walked up and down, and then had supper. After supper, they discussed publique matters, during which Roger Pepys, whom the narrator found to be a very sober man and now honors more than ever, described how the young men in Parliament had poorly carried out their duties by opposing all initiatives proposed by serious men."
    community 18
  ]
  node [
    id 1224
    label "E:4TH LORDS DAY"
    kind "entity"
    name "4TH LORDS DAY"
    community 18
  ]
  node [
    id 1225
    label "E:COZEN ROGER"
    kind "entity"
    name "COZEN ROGER"
    community 18
  ]
  node [
    id 1226
    label "E:UNCLE TALBOT"
    kind "entity"
    name "UNCLE TALBOT"
    community 18
  ]
  node [
    id 1227
    label "E:ORCHARD"
    kind "entity"
    name "ORCHARD"
    community 18
  ]
  node [
    id 1228
    label "E:FRUIT"
    kind "entity"
    name "FRUIT"
    community 21
  ]
  node [
    id 1229
    label "E:COUNTRY PEOPLE"
    kind "entity"
    name "COUNTRY PEOPLE"
    community 18
  ]
  node [
    id 1230
    label "E:PUBLIQUE MATTERS"
    kind "entity"
    name "PUBLIQUE MATTERS"
    community 18
  ]
  node [
    id 1231
    label "E:YOUNG MEN"
    kind "entity"
    name "YOUNG MEN"
    community 18
  ]
  node [
    id 1232
    label "E:SERIOUS MEN"
    kind "entity"
    name "SERIOUS MEN"
    community 18
  ]
  node [
    id 1233
    label "E:RIGHT WORSHIPFULL AND DEARLY BELOVED"
    kind "entity"
    name "RIGHT WORSHIPFULL AND DEARLY BELOVED"
    community 18
  ]
  node [
    id 1234
    label "E:POORLY"
    kind "entity"
    name "POORLY"
    community 18
  ]
  node [
    id 1235
    label "U:Novel-4128_00053#1"
    kind "unit"
    chunk_id "Novel-4128_00053"
    text "Roger Pepys, a man the narrator now honors more than ever, described how the young men in Parliament had poorly carried out their duties by opposing all initiatives proposed by serious men."
    community 18
  ]
  node [
    id 1236
    label "E:INITIATIVES"
    kind "entity"
    name "INITIATIVES"
    community 18
  ]
  node [
    id 1237
    label "C:Novel-4128_00054"
    kind "chunk"
    chunk_id "Novel-4128_00054"
  ]
  node [
    id 1238
    label "U:Novel-4128_00054#0"
    kind "unit"
    chunk_id "Novel-4128_00054"
    text "The speaker hears that some people are the most profane swearers he has ever encountered, which makes him believe they will cause conflict and bring about war if possible. He then goes to bed."
    community 2
  ]
  node [
    id 1239
    label "E:PROPHANE SWERING FELLOWS"
    kind "entity"
    name "PROPHANE SWERING FELLOWS"
    community 2
  ]
  node [
    id 1240
    label "E:WAR"
    kind "entity"
    name "WAR"
    community 2
  ]
  node [
    id 1241
    label "U:Novel-4128_00054#1"
    kind "unit"
    chunk_id "Novel-4128_00054"
    text "On the 5th, the speaker goes early to Huntingdon but stays a long time at Stanton due to rain. There, he borrows a coat from a man for 6d., and then rides the entire way without any coat. He stays briefly at Huntingdon, but the judges have not arrived there."
    community 5
  ]
  node [
    id 1242
    label "E:STANTON"
    kind "entity"
    name "STANTON"
    community 5
  ]
  node [
    id 1243
    label "E:COAT"
    kind "entity"
    name "COAT"
    community 5
  ]
  node [
    id 1244
    label "E:6D"
    kind "entity"
    name "6D"
    community 5
  ]
  node [
    id 1245
    label "E:SPEAKER TO STAY AT STANTON"
    kind "entity"
    name "SPEAKER TO STAY AT STANTON"
    community 5
  ]
  node [
    id 1246
    label "U:Novel-4128_00054#2"
    kind "unit"
    chunk_id "Novel-4128_00054"
    text "The speaker goes to Brampton, where he finds his father very well and learns that his aunt has left the house, which he is glad about despite the cost of L10. He dines there and after dinner rides to Yelling to visit his cousin Nightingale, who has a nice house and shares information about his business, helping him understand how to get a surrender for Graveley lands."
    community 2
  ]
  node [
    id 1247
    label "E:YELLING"
    kind "entity"
    name "YELLING"
    community 2
  ]
  node [
    id 1248
    label "E:COZEN NIGHTINGALE"
    kind "entity"
    name "COZEN NIGHTINGALE"
    community 2
  ]
  node [
    id 1249
    label "E:GRAVELEY LANDS"
    kind "entity"
    name "GRAVELEY LANDS"
    community 2
  ]
  node [
    id 1250
    label "E:ALEHOUSE"
    kind "entity"
    name "ALEHOUSE"
    community 19
  ]
  node [
    id 1251
    label "E:DISCOURSE"
    kind "entity"
    name "DISCOURSE"
    community 2
  ]
  node [
    id 1252
    label "E:VERY WELL"
    kind "entity"
    name "VERY WELL"
    community 2
  ]
  node [
    id 1253
    label "E:AUNT LEAVING HOUSE"
    kind "entity"
    name "AUNT LEAVING HOUSE"
    community 2
  ]
  node [
    id 1254
    label "E:HOW TO GET A SURRENDER FOR GRAVELEY LANDS"
    kind "entity"
    name "HOW TO GET A SURRENDER FOR GRAVELEY LANDS"
    community 2
  ]
  node [
    id 1255
    label "U:Novel-4128_00054#3"
    kind "unit"
    chunk_id "Novel-4128_00054"
    text "The speaker goes to Graveley, where at an alehouse he meets Chancler and Jackson&#8212;one of his tenants for Cotton closes&#8212;and has a long discussion with the other, which greatly satisfies him. He then returns to Brampton and goes to bed after supper, feeling very quiet and content in the house."
    community 2
  ]
  node [
    id 1256
    label "E:GRAVELEY"
    kind "entity"
    name "GRAVELEY"
    community 2
  ]
  node [
    id 1257
    label "E:CHANCLER"
    kind "entity"
    name "CHANCLER"
    community 2
  ]
  node [
    id 1258
    label "E:JACKSON"
    kind "entity"
    name "JACKSON"
    community 2
  ]
  node [
    id 1259
    label "E:COTTON CLOSES"
    kind "entity"
    name "COTTON CLOSES"
    community 2
  ]
  node [
    id 1260
    label "E:SATISFACTION"
    kind "entity"
    name "SATISFACTION"
    community 6
  ]
  node [
    id 1261
    label "C:Novel-4128_00055"
    kind "chunk"
    chunk_id "Novel-4128_00055"
  ]
  node [
    id 1262
    label "U:Novel-4128_00055#0"
    kind "unit"
    chunk_id "Novel-4128_00055"
    text "On the 6th, the narrator went early to Mr. Phillips, but lost his labour because Mr. Phillips had been lying at Huntingdon the previous night. The narrator then returned, took horse, and rode to Huntingdon, where they stayed with Thos. Trice and Mr. Phillips drinking until noon. Afternoon, Tom Trice and the narrator went to Brampton, where the narrator went to Goody Gorum's and then returned home to his father, who noticed that the narrator had been drinking, a behavior he had never seen or heard of before. The narrator ate a bit of dinner and went with his father to Goody Gorum's, where they talked with Tom Trice. Then the narrator took horse for London, facing difficult roads, and after much difficulty arrived at Baldwick, where he had a good supper alone. The landlady was a pretty woman, but the narrator did not take notice of her because her husband was present. Before supper, the narrator visited the church, which was very handsome, and observed that Quakers continue to exist and are growing rather than decreasing in all places he has visited. The narrator went to bed on the 6th."
    community 5
  ]
  node [
    id 1263
    label "E:THOS. TRICE"
    kind "entity"
    name "THOS. TRICE"
    community 5
  ]
  node [
    id 1264
    label "E:GOODY GORUM"
    kind "entity"
    name "GOODY GORUM"
    community 5
  ]
  node [
    id 1265
    label "E:BALDWICK"
    kind "entity"
    name "BALDWICK"
    community 5
  ]
  node [
    id 1266
    label "E:LANDLADY"
    kind "entity"
    name "LANDLADY"
    community 5
  ]
  node [
    id 1267
    label "E:QUAKERS"
    kind "entity"
    name "QUAKERS"
    community 5
  ]
  node [
    id 1268
    label "E:NARRATOR HAD BEEN DRINKING"
    kind "entity"
    name "NARRATOR HAD BEEN DRINKING"
    community 5
  ]
  node [
    id 1269
    label "E:NARRATOR DRINKING"
    kind "entity"
    name "NARRATOR DRINKING"
    community 5
  ]
  node [
    id 1270
    label "E:EVERYWHERE"
    kind "entity"
    name "EVERYWHERE"
    community 5
  ]
  node [
    id 1271
    label "U:Novel-4128_00055#1"
    kind "unit"
    chunk_id "Novel-4128_00055"
    text "On the 7th, the narrator did not go out or mention any further events, and the day is not described in detail."
    community 7
  ]
  node [
    id 1272
    label "C:Novel-4128_00056"
    kind "chunk"
    chunk_id "Novel-4128_00056"
  ]
  node [
    id 1273
    label "U:Novel-4128_00056#0"
    kind "unit"
    chunk_id "Novel-4128_00056"
    text "On the 7th, the narrator was called up at three o'clock and was on horseback by four. While eating breakfast, they saw a man riding who had ridden with them the previous night on the road. The man was carrying venison in his pan-yards to London, and the narrator called him in, shared breakfast with him, and they traveled together all the way. At Hatfield, they bayted and walked into the great house through all the courts. The narrator wanted to steal a pretty dog that followed them but could not, which troubled them. They got to London by horseback after much difficulty, where they found everything well at home and at their father's and their Lady's, but no news about their Lord who was missing. At their Lady's, the narrator met Mr. Moore, who informed them that the next day was a Seal day at the Privy Seal and that, as it was their month, they were to wait upon their Lord Roberts, Lord Privy Seal, at the Seal."
    community 12
  ]
  node [
    id 1274
    label "E:3 O'CLOCK"
    kind "entity"
    name "3 O'CLOCK"
    community 12
  ]
  node [
    id 1275
    label "E:4 O'CLOCK"
    kind "entity"
    name "4 O'CLOCK"
    community 12
  ]
  node [
    id 1276
    label "E:HORSEBACK"
    kind "entity"
    name "HORSEBACK"
    community 12
  ]
  node [
    id 1277
    label "E:MAN RIDING"
    kind "entity"
    name "MAN RIDING"
    community 12
  ]
  node [
    id 1278
    label "E:VENISON"
    kind "entity"
    name "VENISON"
    community 12
  ]
  node [
    id 1279
    label "E:PAN-YARDS"
    kind "entity"
    name "PAN-YARDS"
    community 12
  ]
  node [
    id 1280
    label "E:COURTS"
    kind "entity"
    name "COURTS"
    community 12
  ]
  node [
    id 1281
    label "E:PRETTY DOG"
    kind "entity"
    name "PRETTY DOG"
    community 1
  ]
  node [
    id 1282
    label "E:LORD ROBERTS"
    kind "entity"
    name "LORD ROBERTS"
    community 12
  ]
  node [
    id 1283
    label "E:LORD PRIVY SEAL"
    kind "entity"
    name "LORD PRIVY SEAL"
    community 12
  ]
  node [
    id 1284
    label "E:SEAL DAY"
    kind "entity"
    name "SEAL DAY"
    community 12
  ]
  node [
    id 1285
    label "E:EARLY IN THE MORNING"
    kind "entity"
    name "EARLY IN THE MORNING"
    community 12
  ]
  node [
    id 1286
    label "E:ALL MERRY AND WELL"
    kind "entity"
    name "ALL MERRY AND WELL"
    community 12
  ]
  node [
    id 1287
    label "E:NOT BEING ABLE TO STEAL PRETTY DOG"
    kind "entity"
    name "NOT BEING ABLE TO STEAL PRETTY DOG"
    community 12
  ]
  node [
    id 1288
    label "E:EVERYTHING WELL AT HOME"
    kind "entity"
    name "EVERYTHING WELL AT HOME"
    community 12
  ]
  node [
    id 1289
    label "E:EVERYTHING WELL AT FATHER'S"
    kind "entity"
    name "EVERYTHING WELL AT FATHER'S"
    community 12
  ]
  node [
    id 1290
    label "E:EVERYTHING WELL AT LADY'S"
    kind "entity"
    name "EVERYTHING WELL AT LADY'S"
    community 12
  ]
  node [
    id 1291
    label "E:NARRATOR IS TO WAIT UPON LORD ROBERTS"
    kind "entity"
    name "NARRATOR IS TO WAIT UPON LORD ROBERTS"
    community 12
  ]
  node [
    id 1292
    label "U:Novel-4128_00056#1"
    kind "unit"
    chunk_id "Novel-4128_00056"
    text "On the 8th, early in the morning, the narrator went to Whitehall but did not see their Lord Privy Seal all morning. At noon, Mr. Moore and the narrator went to the Wardrobe for dinner, where their Lady and everyone were merry and well."
    community 12
  ]
  node [
    id 1293
    label "C:Novel-4128_00057"
    kind "chunk"
    chunk_id "Novel-4128_00057"
  ]
  node [
    id 1294
    label "U:Novel-4128_00057#0"
    kind "unit"
    chunk_id "Novel-4128_00057"
    text "At noon, Mr. Moore and the narrator went to the Wardrobe for dinner, where my Lady and all were merry and well. Later, they returned to the Privy Seal, but my Lord did not arrive all afternoon, which made the narrator mad and gave rise to gossip about his delay in business and his severity and ill treatment of the Clerks of the Privy Seal."
    community 9
  ]
  node [
    id 1295
    label "E:PRIVY SEAL"
    kind "entity"
    name "PRIVY SEAL"
    community 20
  ]
  node [
    id 1296
    label "E:CLERKS OF THE PRIVY SEAL"
    kind "entity"
    name "CLERKS OF THE PRIVY SEAL"
    community 9
  ]
  node [
    id 1297
    label "E:MY LORD DID NOT ARRIVE AT PRIVY SEAL"
    kind "entity"
    name "MY LORD DID NOT ARRIVE AT PRIVY SEAL"
    community 9
  ]
  node [
    id 1298
    label "U:Novel-4128_00057#1"
    kind "unit"
    chunk_id "Novel-4128_00057"
    text "In the evening, the narrator took Mons. Eschar, Mr. Moore, and Dr. Pierce's brother (the soldier) to the tavern next to the Savoy, where they stayed and drank. There, the narrator met Mr. Mage and discussed music; Mons. Eschar spoke strongly against English music and in praise of French music, which made the narrator mad, and so Mons. Eschar left."
    community 20
  ]
  node [
    id 1299
    label "E:MONS. ESCAR"
    kind "entity"
    name "MONS. ESCAR"
    community 20
  ]
  node [
    id 1300
    label "E:DR. PIERCE'S BROTHER"
    kind "entity"
    name "DR. PIERCE'S BROTHER"
    community 20
  ]
  node [
    id 1301
    label "E:TAVERN NEXT TO SAVOY"
    kind "entity"
    name "TAVERN NEXT TO SAVOY"
    community 20
  ]
  node [
    id 1302
    label "E:ENGLISH MUSIC"
    kind "entity"
    name "ENGLISH MUSIC"
    community 20
  ]
  node [
    id 1303
    label "E:FRENCH MUSIC"
    kind "entity"
    name "FRENCH MUSIC"
    community 20
  ]
  node [
    id 1304
    label "U:Novel-4128_00057#2"
    kind "unit"
    chunk_id "Novel-4128_00057"
    text "On the 9th, the narrator went to the office where a son-in-law of Mr. Pierce informed him that the purser's father was dying and requested that the narrator come to him before he died. The narrator went to the purser's house and found him not as ill as expected. The narrator promised to be a friend to the purser's wife and family if he died, which was the purser's only request. The narrator believes the purser will recover. Later, the narrator returned to the office and found Sir G."
    community 21
  ]
  node [
    id 1305
    label "E:SON-IN-LAW OF MR. PIERCE"
    kind "entity"
    name "SON-IN-LAW OF MR. PIERCE"
    community 21
  ]
  node [
    id 1306
    label "E:PURSER"
    kind "entity"
    name "PURSER"
    community 21
  ]
  node [
    id 1307
    label "E:PURSER'S FATHER"
    kind "entity"
    name "PURSER'S FATHER"
    community 21
  ]
  node [
    id 1308
    label "E:SIR G."
    kind "entity"
    name "SIR G."
    community 21
  ]
  node [
    id 1309
    label "E:WIFE OF PURSER"
    kind "entity"
    name "WIFE OF PURSER"
    community 21
  ]
  node [
    id 1310
    label "E:FAMILY OF PURSER"
    kind "entity"
    name "FAMILY OF PURSER"
    community 21
  ]
  node [
    id 1311
    label "E:PURSER'S FATHER IS DYING"
    kind "entity"
    name "PURSER'S FATHER IS DYING"
    community 21
  ]
  node [
    id 1312
    label "E:PURSER'S HOUSE"
    kind "entity"
    name "PURSER'S HOUSE"
    community 21
  ]
  node [
    id 1313
    label "C:Novel-4128_00058"
    kind "chunk"
    chunk_id "Novel-4128_00058"
  ]
  node [
    id 1314
    label "U:Novel-4128_00058#0"
    kind "unit"
    chunk_id "Novel-4128_00058"
    text "At noon, the narrator went out to the office to see if Sir G. Carteret would invite him to dinner at Deptford, but Sir G. Carteret did not send for him, which caused a little trouble. The narrator later dined at home and received news from Mr. Hater that his wife was falling into labour, so Mr. Hater came for the narrator's wife, who went with him. The narrator then went to White Hall, where after four o'clock, the Lord Privy Seal arrived and they went to his chamber over the gate. The Lord Privy Seal asked the narrator what deputation he had from the Lord, and the narrator replied that he had none, but that he was sworn as the Lord's deputy by both Secretaries, which satisfied the Lord Privy Seal. The Lord Privy Seal then had Mr. Moore read over all the bills as is the custom, and everything ended very well. The narrator concludes that the Lyon is not as fierce as he is portrayed."
    community 12
  ]
  node [
    id 1315
    label "E:MR. HATER"
    kind "entity"
    name "MR. HATER"
    community 12
  ]
  node [
    id 1316
    label "E:WIFE OF MR. HATER"
    kind "entity"
    name "WIFE OF MR. HATER"
    community 12
  ]
  node [
    id 1317
    label "E:DEPUTATION"
    kind "entity"
    name "DEPUTATION"
    community 12
  ]
  node [
    id 1318
    label "E:SECRETARIES"
    kind "entity"
    name "SECRETARIES"
    community 12
  ]
  node [
    id 1319
    label "E:LYON"
    kind "entity"
    name "LYON"
    community 20
  ]
  node [
    id 1320
    label "E:BILLS"
    kind "entity"
    name "BILLS"
    community 6
  ]
  node [
    id 1321
    label "C:Novel-4128_00059"
    kind "chunk"
    chunk_id "Novel-4128_00059"
  ]
  node [
    id 1322
    label "U:Novel-4128_00059#0"
    kind "unit"
    chunk_id "Novel-4128_00059"
    text "The narrator believes that Lyon is not as fierce as he is portrayed. Mons. Eschar, who had been waiting all afternoon at the Privy Seal for the warrant for L5,000 for my Lord of Sandwich's preparation for Portugal, and the narrator took some wine and went to visit la belle Pierce, who is very pregnant and a pretty lady, and Mrs. Clifford, where they stayed and were extremely merry."
    community 20
  ]
  node [
    id 1323
    label "E:WARRANT FOR L5000"
    kind "entity"
    name "WARRANT FOR L5000"
    community 20
  ]
  node [
    id 1324
    label "E:PREPARATION FOR PORTUGAL"
    kind "entity"
    name "PREPARATION FOR PORTUGAL"
    community 20
  ]
  node [
    id 1325
    label "E:LA BELLE PIERCE"
    kind "entity"
    name "LA BELLE PIERCE"
    community 20
  ]
  node [
    id 1326
    label "E:MRS. CLIFFORD"
    kind "entity"
    name "MRS. CLIFFORD"
    community 20
  ]
  node [
    id 1327
    label "U:Novel-4128_00059#1"
    kind "unit"
    chunk_id "Novel-4128_00059"
    text "The narrator took a coach to his father's house, where he found his father having returned from Brampton as expected, and in good health. After discussing business and as it was very late, the narrator took another coach home, where he heard from his wife that Mrs. Hater is not yet delivered and continues in labor."
    community 10
  ]
  node [
    id 1328
    label "E:MRS. HATER"
    kind "entity"
    name "MRS. HATER"
    community 10
  ]
  node [
    id 1329
    label "E:AFTER RETURNING FROM BRAMPTON"
    kind "entity"
    name "AFTER RETURNING FROM BRAMPTON"
    community 10
  ]
  node [
    id 1330
    label "E:MRS. HATER CONTINUES IN PAINS"
    kind "entity"
    name "MRS. HATER CONTINUES IN PAINS"
    community 10
  ]
  node [
    id 1331
    label "U:Novel-4128_00059#2"
    kind "unit"
    chunk_id "Novel-4128_00059"
    text "This morning, the narrator's wife hired a maid for a chamber maid position. The maid is very ugly, so the narrator cannot care for her, but otherwise she seems very good. The narrator plans for her to come about three weeks hence when his wife returns from Brampton, and she will go with his father."
    community 0
  ]
  node [
    id 1332
    label "E:THREE WEEKS HENCE"
    kind "entity"
    name "THREE WEEKS HENCE"
    community 0
  ]
  node [
    id 1333
    label "E:MAID TO COME ABOUT THREE WEEKS HENCE"
    kind "entity"
    name "MAID TO COME ABOUT THREE WEEKS HENCE"
    community 0
  ]
  node [
    id 1334
    label "E:MAID TO GO WITH FATHER"
    kind "entity"
    name "MAID TO GO WITH FATHER"
    community 0
  ]
  node [
    id 1335
    label "E:WHEN WIFE RETURNS FROM BRAMPTON"
    kind "entity"
    name "WHEN WIFE RETURNS FROM BRAMPTON"
    community 0
  ]
  node [
    id 1336
    label "C:Novel-4128_00060"
    kind "chunk"
    chunk_id "Novel-4128_00060"
  ]
  node [
    id 1337
    label "U:Novel-4128_00060#0"
    kind "unit"
    chunk_id "Novel-4128_00060"
    text "My father came to my house, and together we found my uncle Wight at the Coffee House, where he agreed to meet my uncle Thomas the following week to read over the Captain's will together for their satisfaction."
    community 3
  ]
  node [
    id 1338
    label "E:MY FATHER"
    kind "entity"
    name "MY FATHER"
    community 3
  ]
  node [
    id 1339
    label "E:MY HOUSE"
    kind "entity"
    name "MY HOUSE"
    community 3
  ]
  node [
    id 1340
    label "E:COFFEE HOUSE"
    kind "entity"
    name "COFFEE HOUSE"
    community 3
  ]
  node [
    id 1341
    label "E:CAPTAIN'S WILL"
    kind "entity"
    name "CAPTAIN'S WILL"
    community 3
  ]
  node [
    id 1342
    label "E:NEXT WEEK"
    kind "entity"
    name "NEXT WEEK"
    community 3
  ]
  node [
    id 1343
    label "U:Novel-4128_00060#1"
    kind "unit"
    chunk_id "Novel-4128_00060"
    text "After speaking with my uncle Wight, I went to my Lady's house, dined with her, and afterward took the two young gentlemen and two ladies, along with Captain Ferrers, to the Theatre to see 'The merry Devill of Edmunton,' a play I had never seen before, which pleased me well."
    community 10
  ]
  node [
    id 1344
    label "E:MY LADY'S"
    kind "entity"
    name "MY LADY'S"
    community 10
  ]
  node [
    id 1345
    label "E:TWO YOUNG GENTLEMEN"
    kind "entity"
    name "TWO YOUNG GENTLEMEN"
    community 10
  ]
  node [
    id 1346
    label "E:TWO LADIES"
    kind "entity"
    name "TWO LADIES"
    community 10
  ]
  node [
    id 1347
    label "E:MERRY DEVILL OF EDMUNTON"
    kind "entity"
    name "MERRY DEVILL OF EDMUNTON"
    community 10
  ]
  node [
    id 1348
    label "E:ME"
    kind "entity"
    name "ME"
    community 10
  ]
  node [
    id 1349
    label "U:Novel-4128_00060#2"
    kind "unit"
    chunk_id "Novel-4128_00060"
    text "After the play, I took everyone home by coach to my house, where I gave them fruit to eat and wine, and then returned home by water."
    community 10
  ]
  node [
    id 1350
    label "U:Novel-4128_00060#3"
    kind "unit"
    chunk_id "Novel-4128_00060"
    text "On the 11th, which was Lord's day, the group attended our own church in the forenoon and then went to Clerkenwell Church in the afternoon to see a comedy called 'Fayre Botelers,' which was first printed in 1608 and attributed to T. B., possibly Tony or Anthony Brewer, though it has been falsely attributed to Shakespeare and Drayton."
    community 16
  ]
  node [
    id 1351
    label "E:OUR OWN CHURCH"
    kind "entity"
    name "OUR OWN CHURCH"
    community 16
  ]
  node [
    id 1352
    label "E:CLERKENWELL CHURCH"
    kind "entity"
    name "CLERKENWELL CHURCH"
    community 16
  ]
  node [
    id 1353
    label "E:FAYRE BOTELERS"
    kind "entity"
    name "FAYRE BOTELERS"
    community 16
  ]
  node [
    id 1354
    label "E:1608"
    kind "entity"
    name "1608"
    community 16
  ]
  node [
    id 1355
    label "E:T. B."
    kind "entity"
    name "T. B."
    community 16
  ]
  node [
    id 1356
    label "E:SHAKESPEARE"
    kind "entity"
    name "SHAKESPEARE"
    community 17
  ]
  node [
    id 1357
    label "E:DRAYTON"
    kind "entity"
    name "DRAYTON"
    community 16
  ]
  node [
    id 1358
    label "C:Novel-4128_00061"
    kind "chunk"
    chunk_id "Novel-4128_00061"
  ]
  node [
    id 1359
    label "U:Novel-4128_00061#0"
    kind "unit"
    chunk_id "Novel-4128_00061"
    text "Frances Butler and her sister sat in a pew during church, but the pew became too full, so the narrator went to the next pew and had a full view of them. After Colonel Dillon returned from Ireland and began courting them, the narrator no longer trusts them and believes they are not honest."
    community 13
  ]
  node [
    id 1360
    label "E:FRANCES BUTLER"
    kind "entity"
    name "FRANCES BUTLER"
    community 13
  ]
  node [
    id 1361
    label "E:HER SISTER"
    kind "entity"
    name "HER SISTER"
    community 13
  ]
  node [
    id 1362
    label "E:COLONEL DILLON"
    kind "entity"
    name "COLONEL DILLON"
    community 13
  ]
  node [
    id 1363
    label "E:PEW"
    kind "entity"
    name "PEW"
    community 13
  ]
  node [
    id 1364
    label "U:Novel-4128_00061#1"
    kind "unit"
    chunk_id "Novel-4128_00061"
    text "The narrator went to Graye's-Inn, where they stayed for a while and met Ned Pickering, who informed them that the King had a great hunting match involving a stagg, during which the King tired all the horses and only two or three were able to keep pace with him."
    community 10
  ]
  node [
    id 1365
    label "E:NED PICKERING"
    kind "entity"
    name "NED PICKERING"
    community 10
  ]
  node [
    id 1366
    label "E:STAGG"
    kind "entity"
    name "STAGG"
    community 10
  ]
  node [
    id 1367
    label "E:GRAYE'S-INN"
    kind "entity"
    name "GRAYE'S-INN"
    community 10
  ]
  node [
    id 1368
    label "E:HORSES"
    kind "entity"
    name "HORSES"
    community 10
  ]
  node [
    id 1369
    label "U:Novel-4128_00061#2"
    kind "unit"
    chunk_id "Novel-4128_00061"
    text "The narrator went to their father's house for supper and then returned home. On the 12th, the narrator was at the office in the morning, at home in the afternoon, and learned that my Lord Hinchingbroke had fallen ill, which the narrator fears was caused by the fruit given to him on Saturday last at the narrator's house. In the evening, the narrator went to my Lord Hinchingbroke's place and found him very ill, in great fear of the smallpox."
    community 21
  ]
  node [
    id 1370
    label "E:SMALLPOX"
    kind "entity"
    name "SMALLPOX"
    community 21
  ]
  node [
    id 1371
    label "E:MY LORD HINCHINGBROKE'S PLACE"
    kind "entity"
    name "MY LORD HINCHINGBROKE'S PLACE"
    community 21
  ]
  node [
    id 1372
    label "E:MY LORD HINCHINGBROKE'S ILLNESS"
    kind "entity"
    name "MY LORD HINCHINGBROKE'S ILLNESS"
    community 21
  ]
  node [
    id 1373
    label "C:Novel-4128_00062"
    kind "chunk"
    chunk_id "Novel-4128_00062"
  ]
  node [
    id 1374
    label "U:Novel-4128_00062#0"
    kind "unit"
    chunk_id "Novel-4128_00062"
    text "The narrator supped with his Lady and consulted about Lord Hinchinabroke's sickness, concluding it is best to let him remain where he is. The narrator then went home, feeling troubled by both Lord Hinchinabroke's illness and Lord Sandwich's sickness, who is now confirmed to be ill at Alicante and whose family would be in a dire condition if he should die."
    community 14
  ]
  node [
    id 1375
    label "E:LORD HINCHINABROKE"
    kind "entity"
    name "LORD HINCHINABROKE"
    community 14
  ]
  node [
    id 1376
    label "E:LORD SANDWICH"
    kind "entity"
    name "LORD SANDWICH"
    community 14
  ]
  node [
    id 1377
    label "E:ALICANTE"
    kind "entity"
    name "ALICANTE"
    community 14
  ]
  node [
    id 1378
    label "E:SMALL-POX"
    kind "entity"
    name "SMALL-POX"
    community 14
  ]
  node [
    id 1379
    label "E:SIR H. WRIGHT"
    kind "entity"
    name "SIR H. WRIGHT"
    community 14
  ]
  node [
    id 1380
    label "E:YOUNG LORD"
    kind "entity"
    name "YOUNG LORD"
    community 14
  ]
  node [
    id 1381
    label "E:LORD HINCHINABROKE'S SICKNESS"
    kind "entity"
    name "LORD HINCHINABROKE'S SICKNESS"
    community 14
  ]
  node [
    id 1382
    label "E:LORD SANDWICH'S SICKNESS"
    kind "entity"
    name "LORD SANDWICH'S SICKNESS"
    community 14
  ]
  node [
    id 1383
    label "E:DIRE CONDITION"
    kind "entity"
    name "DIRE CONDITION"
    community 14
  ]
  node [
    id 1384
    label "U:Novel-4128_00062#1"
    kind "unit"
    chunk_id "Novel-4128_00062"
    text "The narrator dined with Lord Crew, who is currently at Sir H. Wright's while his new house is being prepared, and also feels troubled by the current illnesses."
    community 14
  ]
  node [
    id 1385
    label "E:NEW HOUSE"
    kind "entity"
    name "NEW HOUSE"
    community 14
  ]
  node [
    id 1386
    label "E:SIR H. WRIGHT'S"
    kind "entity"
    name "SIR H. WRIGHT'S"
    community 14
  ]
  node [
    id 1387
    label "E:ILLNESSES"
    kind "entity"
    name "ILLNESSES"
    community 14
  ]
  node [
    id 1388
    label "U:Novel-4128_00062#2"
    kind "unit"
    chunk_id "Novel-4128_00062"
    text "In the morning, the narrator went to the Privy Seal, then to the Wardrobe for dinner, where he met his wife and found the young Lord very ill. His Lady intends to send her three sons&#8212;Sidney, Oliver, and John&#8212;to the narrator's house to avoid the small-pox."
    community 14
  ]
  node [
    id 1389
    label "E:SIDNEY"
    kind "entity"
    name "SIDNEY"
    community 14
  ]
  node [
    id 1390
    label "E:OLIVER"
    kind "entity"
    name "OLIVER"
    community 14
  ]
  node [
    id 1391
    label "E:JOHN"
    kind "entity"
    name "JOHN"
    community 14
  ]
  node [
    id 1392
    label "E:YOUNG LORD IS VERY ILL"
    kind "entity"
    name "YOUNG LORD IS VERY ILL"
    community 14
  ]
  node [
    id 1393
    label "U:Novel-4128_00062#3"
    kind "unit"
    chunk_id "Novel-4128_00062"
    text "After dinner, the narrator went to his father's house, where he found him inside, and went up to him. There, the narrator found his father settling papers for his removal, and took some old papers of difference between himself and his wife and removed them."
    community 19
  ]
  node [
    id 1394
    label "E:REMOVAL"
    kind "entity"
    name "REMOVAL"
    community 19
  ]
  node [
    id 1395
    label "C:Novel-4128_00063"
    kind "chunk"
    chunk_id "Novel-4128_00063"
  ]
  node [
    id 1396
    label "U:Novel-4128_00063#0"
    kind "unit"
    chunk_id "Novel-4128_00063"
    text "After Pall's presence, the narrator spoke to their father about not keeping a woman longer due to certain reasons, which troubled both of them and nearly led to a confrontation between the mother and the narrator, who has become a very simple woman. Mrs. Cordery later visits to take leave of the father, believing he is going to the country soon and requests that the narrator and father come to see her before he leaves. The narrator and father then go to Mr. Rawlinson's, where the uncle Thomas and his two sons arrive, followed by uncle Wight, who was appointed by all of them. There, the will is read and the narrator explains their thoughts regarding kindness to uncle Thomas if he behaves peacefully, otherwise if he continues to hold his caveat against them. Uncle Thomas promises to withdraw his caveat and appears very content with the current situation. Later, after drinking, they pay all expenses and part ways. The narrator returns home and finds the Lady's three sons there, which makes them glad they are able to assist the Lady and her Lord in this matter, though they remain deeply troubled about Lord of Sandwich's health, which they fear."
    community 3
  ]
  node [
    id 1397
    label "E:MRS. CORDERY"
    kind "entity"
    name "MRS. CORDERY"
    community 3
  ]
  node [
    id 1398
    label "E:LORD OF SANDWICH"
    kind "entity"
    name "LORD OF SANDWICH"
    community 3
  ]
  node [
    id 1399
    label "E:THREE SONS"
    kind "entity"
    name "THREE SONS"
    community 3
  ]
  node [
    id 1400
    label "E:VERY SIMPLE WOMAN"
    kind "entity"
    name "VERY SIMPLE WOMAN"
    community 4
  ]
  node [
    id 1401
    label "E:NARRATOR AND HIMSELF TO COME AND SEE HER"
    kind "entity"
    name "NARRATOR AND HIMSELF TO COME AND SEE HER"
    community 3
  ]
  node [
    id 1402
    label "E:MR. RAWLINSON'S"
    kind "entity"
    name "MR. RAWLINSON'S"
    community 3
  ]
  node [
    id 1403
    label "E:TWO SONS"
    kind "entity"
    name "TWO SONS"
    community 3
  ]
  node [
    id 1404
    label "E:ALL OF THEM"
    kind "entity"
    name "ALL OF THEM"
    community 3
  ]
  node [
    id 1405
    label "E:THEY"
    kind "entity"
    name "THEY"
    community 11
  ]
  node [
    id 1406
    label "E:THINGS AS THEY ARE"
    kind "entity"
    name "THINGS AS THEY ARE"
    community 3
  ]
  node [
    id 1407
    label "E:KINDNESS TO UNCLE THOMAS"
    kind "entity"
    name "KINDNESS TO UNCLE THOMAS"
    community 3
  ]
  node [
    id 1408
    label "E:HIS CAVEAT"
    kind "entity"
    name "HIS CAVEAT"
    community 3
  ]
  node [
    id 1409
    label "E:CURRENT SITUATION"
    kind "entity"
    name "CURRENT SITUATION"
    community 3
  ]
  node [
    id 1410
    label "E:LADY AND HER LORD"
    kind "entity"
    name "LADY AND HER LORD"
    community 3
  ]
  node [
    id 1411
    label "E:LORD OF SANDICH'S HEALTH"
    kind "entity"
    name "LORD OF SANDICH'S HEALTH"
    community 3
  ]
  node [
    id 1412
    label "U:Novel-4128_00063#1"
    kind "unit"
    chunk_id "Novel-4128_00063"
    text "The narrator is afraid of Lord of Sandwich's health."
    community 3
  ]
  node [
    id 1413
    label "E:LORD OF SANDICH"
    kind "entity"
    name "LORD OF SANDICH"
    community 3
  ]
  node [
    id 1414
    label "C:Novel-4128_00064"
    kind "chunk"
    chunk_id "Novel-4128_00064"
  ]
  node [
    id 1415
    label "U:Novel-4128_00064#0"
    kind "unit"
    chunk_id "Novel-4128_00064"
    text "This morning, Sir W. Batten, Sir W. Pen, and the narrator waited upon the Duke of York in his chamber to report the Navy's financial condition and the fact that their bills are offered on the Exchange at a 20 in 100 loss. The Duke was deeply troubled and promised to speak to the King and Council about it this morning. Afterward, the narrator dined with his Lady and found Lord Hinchingbroke somewhat better. Later, Captain Ferrers and the narrator went to the Theatre to see 'The Alchymist'; after the play, Sir W. Pen took Captain Ferrers to Paul's and set him down, then carried the narrator home. The narrator and Sir W. Pen then went to the Dolphin, but did not find Sir W. Batten there, so they carried a bottle of wine to his house, sat and talked, and then returned home. At home, the narrator found a letter from Mr. Creed dated July 15th of the previous year, which informed him that his Lord is free from pain caused by wind entering the muscles of his right side and his fever, and is now hopeful to go aboard in a day or two, which brings the narrator great comfort."
    community 17
  ]
  node [
    id 1416
    label "E:NAVY"
    kind "entity"
    name "NAVY"
    community 17
  ]
  node [
    id 1417
    label "E:20 IN 100 LOSS"
    kind "entity"
    name "20 IN 100 LOSS"
    community 17
  ]
  node [
    id 1418
    label "E:LORD HINCHINGBROKE"
    kind "entity"
    name "LORD HINCHINGBROKE"
    community 17
  ]
  node [
    id 1419
    label "E:PAUL'S"
    kind "entity"
    name "PAUL'S"
    community 17
  ]
  node [
    id 1420
    label "E:DOLPHIN"
    kind "entity"
    name "DOLPHIN"
    community 17
  ]
  node [
    id 1421
    label "E:JULY 15TH"
    kind "entity"
    name "JULY 15TH"
    community 17
  ]
  node [
    id 1422
    label "E:WIND IN MUSCLES OF RIGHT SIDE"
    kind "entity"
    name "WIND IN MUSCLES OF RIGHT SIDE"
    community 17
  ]
  node [
    id 1423
    label "E:FEVER"
    kind "entity"
    name "FEVER"
    community 0
  ]
  node [
    id 1424
    label "E:ABOARD"
    kind "entity"
    name "ABOARD"
    community 17
  ]
  node [
    id 1425
    label "E:GREAT COMFORT"
    kind "entity"
    name "GREAT COMFORT"
    community 17
  ]
  node [
    id 1426
    label "E:THEIR BILLS"
    kind "entity"
    name "THEIR BILLS"
    community 17
  ]
  node [
    id 1427
    label "E:NAVY'S FINANCIAL CONDITION"
    kind "entity"
    name "NAVY'S FINANCIAL CONDITION"
    community 17
  ]
  node [
    id 1428
    label "E:KING AND COUNCIL"
    kind "entity"
    name "KING AND COUNCIL"
    community 17
  ]
  node [
    id 1429
    label "E:WITH HIM"
    kind "entity"
    name "WITH HIM"
    community 17
  ]
  node [
    id 1430
    label "E:SIR W. BATTEN'S HOUSE"
    kind "entity"
    name "SIR W. BATTEN'S HOUSE"
    community 17
  ]
  node [
    id 1431
    label "E:LORD IS RID OF PAIN"
    kind "entity"
    name "LORD IS RID OF PAIN"
    community 17
  ]
  node [
    id 1432
    label "E:IN A DAY OR TWO"
    kind "entity"
    name "IN A DAY OR TWO"
    community 17
  ]
  node [
    id 1433
    label "E:LORD'S RECOVERY"
    kind "entity"
    name "LORD'S RECOVERY"
    community 17
  ]
  node [
    id 1434
    label "U:Novel-4128_00064#1"
    kind "unit"
    chunk_id "Novel-4128_00064"
    text "On the 15th, the narrator went to the Privy Seal and Whitehall, traveling up and down, and at noon met Sir W. at some point during the day."
    community 12
  ]
  node [
    id 1435
    label "C:Novel-4128_00065"
    kind "chunk"
    chunk_id "Novel-4128_00065"
  ]
  node [
    id 1436
    label "U:Novel-4128_00065#0"
    kind "unit"
    chunk_id "Novel-4128_00065"
    text "On the 15th, Sir W. Pen took the author to Paul's, then the author walked to the Wardrobe and dined with his Lady, where he told her about his Lord's sickness and recovery; she had heard nothing about the sickness but was glad about the recovery, though doubtful about the recovery. The author found his Lord Hinchingbroke improving, with the worst of his condition past. Afterward, the author went to the Opera, which began that day with 'The Witts,' a play never previously performed with scenes; the King, Duke, and Duchess attended and dined that day with Sir H. Finch, reader at the Temple, in great state. The author considered the play to be excellent and the scenes admirable. Later, the author was overtaken by Sir W. Pen in his coach, who had been with my Lady Batten and others at the Theatre that afternoon. The author then followed Sir W. Pen to the Dolphin, where Sir W. Batten was, and they sat there awhile before returning home after managing to fuddle Mr. Falconer of Woolwich."
    community 17
  ]
  node [
    id 1437
    label "E:SICKNESS"
    kind "entity"
    name "SICKNESS"
    community 17
  ]
  node [
    id 1438
    label "E:RECOVERY"
    kind "entity"
    name "RECOVERY"
    community 17
  ]
  node [
    id 1439
    label "E:WITTS"
    kind "entity"
    name "WITTS"
    community 17
  ]
  node [
    id 1440
    label "E:DUCHESS"
    kind "entity"
    name "DUCHESS"
    community 16
  ]
  node [
    id 1441
    label "E:SIR H. FINCH"
    kind "entity"
    name "SIR H. FINCH"
    community 17
  ]
  node [
    id 1442
    label "E:PLAY"
    kind "entity"
    name "PLAY"
    community 16
  ]
  node [
    id 1443
    label "E:SCENES"
    kind "entity"
    name "SCENES"
    community 17
  ]
  node [
    id 1444
    label "E:AUTHOR"
    kind "entity"
    name "AUTHOR"
    community 17
  ]
  node [
    id 1445
    label "E:WORST"
    kind "entity"
    name "WORST"
    community 17
  ]
  node [
    id 1446
    label "U:Novel-4128_00065#1"
    kind "unit"
    chunk_id "Novel-4128_00065"
    text "On the 16th, the author did not mention any specific events or activities."
    community 0
  ]
  node [
    id 1447
    label "C:Novel-4128_00066"
    kind "chunk"
    chunk_id "Novel-4128_00066"
  ]
  node [
    id 1448
    label "U:Novel-4128_00066#0"
    kind "unit"
    chunk_id "Novel-4128_00066"
    text "Falconer of Woolwich returned home on the 16th. Throughout the morning at the office, little work was done because all clerks had gone to the burial of Tom Whitton, a very ingenious and promising young clerk of the Controller. A widespread fever affecting both city and country, rare and not previously heard of except during plague times, had claimed the lives of Tom Fuller, Dr. Nichols, Dean of Paul's, and Lord General Monk was very dangerously ill. That evening, Falconer dined at home with the children and his father, and after dinner, he and his father went out for business. They met Dr. John Williams at an alehouse in Shoe Lane, where they stayed until past nine in the evening, discussing country business; Falconer found Dr. Williams well informed about Gravely and expects him to be of great use. Falconer returned home after the visit. On the 17th, he attended the Privy Seal where a seal was presented that morning, then met Ned Pickering and walked with him into St."
    community 0
  ]
  node [
    id 1449
    label "E:FALCONER OF WOOLWICH"
    kind "entity"
    name "FALCONER OF WOOLWICH"
    community 0
  ]
  node [
    id 1450
    label "E:TOM WHITTON"
    kind "entity"
    name "TOM WHITTON"
    community 0
  ]
  node [
    id 1451
    label "E:CONTROLLER"
    kind "entity"
    name "CONTROLLER"
    community 0
  ]
  node [
    id 1452
    label "E:CLERKS"
    kind "entity"
    name "CLERKS"
    community 0
  ]
  node [
    id 1453
    label "E:TOM FULLER"
    kind "entity"
    name "TOM FULLER"
    community 0
  ]
  node [
    id 1454
    label "E:DR. NICHOLS"
    kind "entity"
    name "DR. NICHOLS"
    community 0
  ]
  node [
    id 1455
    label "E:DEAN OF PAUL'S"
    kind "entity"
    name "DEAN OF PAUL'S"
    community 0
  ]
  node [
    id 1456
    label "E:LORD GENERAL MONK"
    kind "entity"
    name "LORD GENERAL MONK"
    community 0
  ]
  node [
    id 1457
    label "E:SHOE LANE"
    kind "entity"
    name "SHOE LANE"
    community 0
  ]
  node [
    id 1458
    label "E:DR. JOHN WILLIAMS"
    kind "entity"
    name "DR. JOHN WILLIAMS"
    community 0
  ]
  node [
    id 1459
    label "E:ST"
    kind "entity"
    name "ST"
    community 0
  ]
  node [
    id 1460
    label "E:CITY AND COUNTRY"
    kind "entity"
    name "CITY AND COUNTRY"
    community 0
  ]
  node [
    id 1461
    label "E:PLAGUE TIME"
    kind "entity"
    name "PLAGUE TIME"
    community 0
  ]
  node [
    id 1462
    label "U:Novel-4128_00066#1"
    kind "unit"
    chunk_id "Novel-4128_00066"
    text "Falconer of Woolwich visited an alehouse in Shoe Lane on the 16th, where he stayed until past nine in the evening, discussing country business with Dr. John Williams, who was found to be well informed about Gravely and is expected to be of great use to him."
    community 0
  ]
  node [
    id 1463
    label "C:Novel-4128_00067"
    kind "chunk"
    chunk_id "Novel-4128_00067"
  ]
  node [
    id 1464
    label "U:Novel-4128_00067#0"
    kind "unit"
    chunk_id "Novel-4128_00067"
    text "Ned Pickering was met and walked into St. James's Park, where significant and noble changes were observed. During their conversation, Ned expressed strong complaints about the lewdness and beggary of the Court, which the narrator finds regrettable and fears will lead to further ruin. Afterward, Ned and the narrator went to the Wardrobe for dinner. Following dinner, Captain Ferrers and the narrator attended the Opera and saw 'The Witts' again, which the narrator enjoyed greatly. The Queen of Bohemia was present, brought by my Lord Craven. Later, Captain Ferrers, the narrator, and another person went to the Devil tavern and drank, then returned home by coach. The narrator felt troubled by their inability to focus on business and instead being deeply drawn to plays. The narrator had sent a vessel about a month prior with goods belonging to my Lord to Lynn, but had been unable to hear about its status until now, when it was reported to have arrived in Soale Bay, though the purpose of this is unclear."
    community 10
  ]
  node [
    id 1465
    label "E:ST. JAMES'S PARK"
    kind "entity"
    name "ST. JAMES'S PARK"
    community 10
  ]
  node [
    id 1466
    label "E:LEWDNESS"
    kind "entity"
    name "LEWDNESS"
    community 10
  ]
  node [
    id 1467
    label "E:BEGGARY"
    kind "entity"
    name "BEGGARY"
    community 10
  ]
  node [
    id 1468
    label "E:COURT"
    kind "entity"
    name "COURT"
    community 6
  ]
  node [
    id 1469
    label "E:MY LORD CRAVEN"
    kind "entity"
    name "MY LORD CRAVEN"
    community 10
  ]
  node [
    id 1470
    label "E:DEVIL TAVERN"
    kind "entity"
    name "DEVIL TAVERN"
    community 10
  ]
  node [
    id 1471
    label "E:PLAYS"
    kind "entity"
    name "PLAYS"
    community 1
  ]
  node [
    id 1472
    label "E:VESSEL"
    kind "entity"
    name "VESSEL"
    community 10
  ]
  node [
    id 1473
    label "E:LYNN"
    kind "entity"
    name "LYNN"
    community 10
  ]
  node [
    id 1474
    label "E:SOALE BAY"
    kind "entity"
    name "SOALE BAY"
    community 10
  ]
  node [
    id 1475
    label "E:COMPLAINTS ABOUT THE COURT"
    kind "entity"
    name "COMPLAINTS ABOUT THE COURT"
    community 10
  ]
  node [
    id 1476
    label "E:ALL TO RUIN"
    kind "entity"
    name "ALL TO RUIN"
    community 10
  ]
  node [
    id 1477
    label "E:ATTENDED THE OPERA"
    kind "entity"
    name "ATTENDED THE OPERA"
    community 10
  ]
  node [
    id 1478
    label "E:EVENT"
    kind "entity"
    name "EVENT"
    community 10
  ]
  node [
    id 1479
    label "E:NARRATOR AND ANOTHER"
    kind "entity"
    name "NARRATOR AND ANOTHER"
    community 10
  ]
  node [
    id 1480
    label "E:WENT TO THE DEVIL TAVERN"
    kind "entity"
    name "WENT TO THE DEVIL TAVERN"
    community 10
  ]
  node [
    id 1481
    label "E:NARRATOR AND CAPTAIN FERRERS"
    kind "entity"
    name "NARRATOR AND CAPTAIN FERRERS"
    community 10
  ]
  node [
    id 1482
    label "E:INABILITY TO RECALL BUSINESS"
    kind "entity"
    name "INABILITY TO RECALL BUSINESS"
    community 10
  ]
  node [
    id 1483
    label "E:THINGS OF MY LORD'S"
    kind "entity"
    name "THINGS OF MY LORD'S"
    community 10
  ]
  node [
    id 1484
    label "E:LYN"
    kind "entity"
    name "LYN"
    community 10
  ]
  node [
    id 1485
    label "U:Novel-4128_00067#1"
    kind "unit"
    chunk_id "Novel-4128_00067"
    text "On the 18th, the narrator attended their own church in the morning and then returned home for dinner. At dinner, the narrator's father and Dr. Tom Pepys came to dine and were very merry. After dinner, the narrator took their wife and Mr. [name missing] to [location missing]."
    community 0
  ]
  node [
    id 1486
    label "E:OWN CHURCH"
    kind "entity"
    name "OWN CHURCH"
    community 0
  ]
  node [
    id 1487
    label "E:DR. TOM PEPYS"
    kind "entity"
    name "DR. TOM PEPYS"
    community 0
  ]
  node [
    id 1488
    label "U:Novel-4128_00067#2"
    kind "unit"
    chunk_id "Novel-4128_00067"
    text "The narrator had been in a prolonged state of uncertainty regarding the status of a vessel sent about a month ago with goods belonging to my Lord to Lynn, and only now learned that it had arrived in Soale Bay, though the purpose of this arrival is unknown."
    community 10
  ]
  node [
    id 1489
    label "E:ABOUT A MONTH AGO"
    kind "entity"
    name "ABOUT A MONTH AGO"
    community 10
  ]
  node [
    id 1490
    label "E:PURPOSE"
    kind "entity"
    name "PURPOSE"
    community 10
  ]
  node [
    id 1491
    label "E:ARRIVAL IN SOALE BAY"
    kind "entity"
    name "ARRIVAL IN SOALE BAY"
    community 10
  ]
  node [
    id 1492
    label "C:Novel-4128_00068"
    kind "chunk"
    chunk_id "Novel-4128_00068"
  ]
  node [
    id 1493
    label "U:Novel-4128_00068#0"
    kind "unit"
    chunk_id "Novel-4128_00068"
    text "Tom Pepys came to dine and they were very merry. After dinner, the narrator took his wife and Mr. Sidney to visit my Lord Hinchingbroke at my Lady's house, where Hinchingbroke was recovering and now sits up and walks about his chamber. The narrator then went to White Hall and heard that my Lord General Monk remained very ill. He then visited la belle Pierce and sat with her, then walked in St. James's Park where he saw a great variety of fowl that he had never seen before, and returned home. In the evening, he read in 'Hooker's Ecclesiastical Polity,' a book given to him by Mr. Moore on Wednesday, which was very handsomely bound, and he intended to read it with great pains and love for Moore's sake. He then had supper and went to bed."
    community 0
  ]
  node [
    id 1494
    label "E:TOM PEPYS"
    kind "entity"
    name "TOM PEPYS"
    community 0
  ]
  node [
    id 1495
    label "E:MR. SIDNEY"
    kind "entity"
    name "MR. SIDNEY"
    community 0
  ]
  node [
    id 1496
    label "E:MY LORD GENERAL MONK"
    kind "entity"
    name "MY LORD GENERAL MONK"
    community 0
  ]
  node [
    id 1497
    label "E:MY LADY SANDWICH"
    kind "entity"
    name "MY LADY SANDWICH"
    community 0
  ]
  node [
    id 1498
    label "E:MRS."
    kind "entity"
    name "MRS."
    community 0
  ]
  node [
    id 1499
    label "U:Novel-4128_00068#1"
    kind "unit"
    chunk_id "Novel-4128_00068"
    text "The narrator, on the 19th, was at the office all morning, then at noon the children were sent for by their mother, my Lady Sandwich, for dinner. The narrator went with them by coach to my father's house, dined there, and then accompanied them to see Mrs."
    community 0
  ]
  node [
    id 1500
    label "C:Novel-4128_00069"
    kind "chunk"
    chunk_id "Novel-4128_00069"
  ]
  node [
    id 1501
    label "U:Novel-4128_00069#0"
    kind "unit"
    chunk_id "Novel-4128_00069"
    text "Cordery, who is invited by the speaker before their father goes into the country, would have also gone but is instead sent to the Privy Seal, where they find a document belonging to their Lord Chancellor, which was likely one of the large grants Clarendon obtained quietly or without scandal from the king, including lands and manors, and a warrant in the Chancellor's own handwriting authorizing Sir Stephen Fox to pay L20,000&#8212;approximately 10 million dollars in 2000&#8212;to the Chancellor, of which no one could have been aware."
    community 20
  ]
  node [
    id 1502
    label "E:CORDERY"
    kind "entity"
    name "CORDERY"
    community 20
  ]
  node [
    id 1503
    label "E:LARGE GRANTS"
    kind "entity"
    name "LARGE GRANTS"
    community 20
  ]
  node [
    id 1504
    label "E:LANDS AND MANORS"
    kind "entity"
    name "LANDS AND MANORS"
    community 20
  ]
  node [
    id 1505
    label "E:SIR STEPHEN FOX"
    kind "entity"
    name "SIR STEPHEN FOX"
    community 20
  ]
  node [
    id 1506
    label "E:L20000"
    kind "entity"
    name "L20000"
    community 20
  ]
  node [
    id 1507
    label "E:10 MILLION DOLLARS"
    kind "entity"
    name "10 MILLION DOLLARS"
    community 20
  ]
  node [
    id 1508
    label "E:2000"
    kind "entity"
    name "2000"
    community 20
  ]
  node [
    id 1509
    label "E:WARRANT"
    kind "entity"
    name "WARRANT"
    community 20
  ]
  node [
    id 1510
    label "E:NO ONE COULD HAVE NOTICED"
    kind "entity"
    name "NO ONE COULD HAVE NOTICED"
    community 20
  ]
  node [
    id 1511
    label "C:Novel-4128_00070"
    kind "chunk"
    chunk_id "Novel-4128_00070"
  ]
  node [
    id 1512
    label "U:Novel-4128_00070#0"
    kind "unit"
    chunk_id "Novel-4128_00070"
    text "In 1662, he received L5,000 from the money voted to the king by the Parliament of Ireland, as mentioned in his vindication against the impeachment of the Commons. In February 1664, Pepys recorded that another sum of L20,000 was given to the Chancellor to clear the mortgage on Clarendon Park, and it was believed this sum was paid from money received from France through the sale of Dunkirk."
    community 20
  ]
  node [
    id 1513
    label "E:1662"
    kind "entity"
    name "1662"
    community 20
  ]
  node [
    id 1514
    label "E:L5000"
    kind "entity"
    name "L5000"
    community 20
  ]
  node [
    id 1515
    label "E:PARLIAMENT OF IRELAND"
    kind "entity"
    name "PARLIAMENT OF IRELAND"
    community 20
  ]
  node [
    id 1516
    label "E:VINDICATION"
    kind "entity"
    name "VINDICATION"
    community 20
  ]
  node [
    id 1517
    label "E:PEPYS"
    kind "entity"
    name "PEPYS"
    community 20
  ]
  node [
    id 1518
    label "E:1664"
    kind "entity"
    name "1664"
    community 20
  ]
  node [
    id 1519
    label "E:CHANCELLOR"
    kind "entity"
    name "CHANCELLOR"
    community 20
  ]
  node [
    id 1520
    label "E:CLARENDON PARK"
    kind "entity"
    name "CLARENDON PARK"
    community 20
  ]
  node [
    id 1521
    label "E:MORTGAGE"
    kind "entity"
    name "MORTGAGE"
    community 20
  ]
  node [
    id 1522
    label "E:SALE OF DUNKIRK"
    kind "entity"
    name "SALE OF DUNKIRK"
    community 20
  ]
  node [
    id 1523
    label "E:MORTGAGE ON CLARENDON PARK"
    kind "entity"
    name "MORTGAGE ON CLARENDON PARK"
    community 20
  ]
  node [
    id 1524
    label "E:MONEY FROM FRANCE"
    kind "entity"
    name "MONEY FROM FRANCE"
    community 20
  ]
  node [
    id 1525
    label "U:Novel-4128_00070#1"
    kind "unit"
    chunk_id "Novel-4128_00070"
    text "He went to Worcester House where several Lords were meeting in Council. While waiting there, the King arrived in a plain common riding-suit and velvet cap, appearing ordinary to someone unfamiliar with him. After waiting, Mr. Moore and he hired a coach and went to Chelsy, where they sat at an alehouse, drank, and waited until the Lord Privy Seal arrived at his house. They then went to the Lord Privy Seal and examined and sealed the document. Upon returning, they found their coach had gone, so they walked home on foot to save money."
    community 10
  ]
  node [
    id 1526
    label "E:SEVERAL LORDS"
    kind "entity"
    name "SEVERAL LORDS"
    community 10
  ]
  node [
    id 1527
    label "E:PLAIN COMMON RIDING-SUIT"
    kind "entity"
    name "PLAIN COMMON RIDING-SUIT"
    community 10
  ]
  node [
    id 1528
    label "E:VELVET CAP"
    kind "entity"
    name "VELVET CAP"
    community 10
  ]
  node [
    id 1529
    label "E:CHELSY"
    kind "entity"
    name "CHELSY"
    community 10
  ]
  node [
    id 1530
    label "E:DOCUMENT"
    kind "entity"
    name "DOCUMENT"
    community 10
  ]
  node [
    id 1531
    label "E:WALKED HOME"
    kind "entity"
    name "WALKED HOME"
    community 10
  ]
  node [
    id 1532
    label "E:SAVED MONEY"
    kind "entity"
    name "SAVED MONEY"
    community 10
  ]
  node [
    id 1533
    label "E:SEVERAL LORDS MET IN COUNCIL"
    kind "entity"
    name "SEVERAL LORDS MET IN COUNCIL"
    community 10
  ]
  node [
    id 1534
    label "E:PLAIN COMMON RIDING-SUIT AND VELVET CAP"
    kind "entity"
    name "PLAIN COMMON RIDING-SUIT AND VELVET CAP"
    community 10
  ]
  node [
    id 1535
    label "E:SOMEONE UNFAMILIAR WITH HIM"
    kind "entity"
    name "SOMEONE UNFAMILIAR WITH HIM"
    community 10
  ]
  node [
    id 1536
    label "E:HE AND MR. MOORE"
    kind "entity"
    name "HE AND MR. MOORE"
    community 10
  ]
  node [
    id 1537
    label "E:LORD PRIVY SEAL ARRIVED"
    kind "entity"
    name "LORD PRIVY SEAL ARRIVED"
    community 10
  ]
  node [
    id 1538
    label "E:LORD PRIVY SEAL'S HOUSE"
    kind "entity"
    name "LORD PRIVY SEAL'S HOUSE"
    community 10
  ]
  node [
    id 1539
    label "E:ON RETURN"
    kind "entity"
    name "ON RETURN"
    community 10
  ]
  node [
    id 1540
    label "E:TO SAVE MONEY"
    kind "entity"
    name "TO SAVE MONEY"
    community 10
  ]
  node [
    id 1541
    label "C:Novel-4128_00071"
    kind "chunk"
    chunk_id "Novel-4128_00071"
  ]
  node [
    id 1542
    label "U:Novel-4128_00071#0"
    kind "unit"
    chunk_id "Novel-4128_00071"
    text "A companion who walked with the narrator began to whistle near the Neate houses, which caused suspicion; it was later revealed that the person who answered was Mr. Marsh (the Lutenist) and his wife. The group then walked to Westminster together, where they drank at the narrator's expense and sang a song about Mr. Marsh, whose voice is now completely lost. After returning home, the narrator found that his Lady kept the children at home and did not allow them to come to the house anymore, which troubled him. On the 20th, the narrator went to the office in the morning and spent the entire afternoon at home organizing papers. On the same day, an agreement was reached with Sir R. Ford to add his house to the office to enlarge their quarters. On the 21st, the narrator went to his father in the morning, and after a draft, both went to Dr. Williams, who was not available, so they visited Mrs. Terry, a daughter of Mr. Whately, who had recently proposed her sister as a potential wife for the narrator's brother Tom. The group discussed the proposal and agreed to visit her mother that afternoon, and in the meantime, they went to Will."
    community 11
  ]
  node [
    id 1543
    label "E:COMPANION"
    kind "entity"
    name "COMPANION"
    community 11
  ]
  node [
    id 1544
    label "E:NEATE HOUSES"
    kind "entity"
    name "NEATE HOUSES"
    community 11
  ]
  node [
    id 1545
    label "E:MR. MARSH"
    kind "entity"
    name "MR. MARSH"
    community 11
  ]
  node [
    id 1546
    label "E:LUTENIST"
    kind "entity"
    name "LUTENIST"
    community 11
  ]
  node [
    id 1547
    label "E:MR. MARSH'S WIFE"
    kind "entity"
    name "MR. MARSH'S WIFE"
    community 11
  ]
  node [
    id 1548
    label "E:QUARTERS"
    kind "entity"
    name "QUARTERS"
    community 11
  ]
  node [
    id 1549
    label "E:MRS. TERRY"
    kind "entity"
    name "MRS. TERRY"
    community 11
  ]
  node [
    id 1550
    label "E:MR. WHATELY"
    kind "entity"
    name "MR. WHATELY"
    community 11
  ]
  node [
    id 1551
    label "E:VOICE"
    kind "entity"
    name "VOICE"
    community 11
  ]
  node [
    id 1552
    label "E:OFFICE VISIT"
    kind "entity"
    name "OFFICE VISIT"
    community 11
  ]
  node [
    id 1553
    label "E:PAPER ORGANIZATION"
    kind "entity"
    name "PAPER ORGANIZATION"
    community 11
  ]
  node [
    id 1554
    label "E:AGREEMENT WITH SIR R. FORD"
    kind "entity"
    name "AGREEMENT WITH SIR R. FORD"
    community 11
  ]
  node [
    id 1555
    label "E:MRS. TERRY'S MOTHER"
    kind "entity"
    name "MRS. TERRY'S MOTHER"
    community 11
  ]
  node [
    id 1556
    label "U:Novel-4128_00071#1"
    kind "unit"
    chunk_id "Novel-4128_00071"
    text "The narrator and his father visited Dr. Williams in the morning, but since Dr. Williams was not available, they went to Mrs. Terry, a daughter of Mr. Whately, who had proposed her sister as a potential wife for the narrator's brother Tom. They discussed the proposal and agreed to visit her mother later that day, and in the meantime, they went to Will."
    community 11
  ]
  node [
    id 1557
    label "C:Novel-4128_00072"
    kind "chunk"
    chunk_id "Novel-4128_00072"
  ]
  node [
    id 1558
    label "U:Novel-4128_00072#0"
    kind "unit"
    chunk_id "Novel-4128_00072"
    text "Joyce and the narrator went to an alehouse and drank for a long time, as Joyce was very angry that his father Fenner gave him and his brother only minimal mourning, similar to what his father gave the narrator and his aunt at their mother's death. Joyce is described as a troublesome person whose company always tires the narrator."
    community 19
  ]
  node [
    id 1559
    label "E:JOYCE"
    kind "entity"
    name "JOYCE"
    community 19
  ]
  node [
    id 1560
    label "E:FENNER"
    kind "entity"
    name "FENNER"
    community 19
  ]
  node [
    id 1561
    label "E:MOTHER'S DEATH"
    kind "entity"
    name "MOTHER'S DEATH"
    community 19
  ]
  node [
    id 1562
    label "E:MOURING"
    kind "entity"
    name "MOURING"
    community 19
  ]
  node [
    id 1563
    label "E:TRUBLEOUS PERSON"
    kind "entity"
    name "TRUBLEOUS PERSON"
    community 19
  ]
  node [
    id 1564
    label "E:COMPANY"
    kind "entity"
    name "COMPANY"
    community 19
  ]
  node [
    id 1565
    label "E:JOYCE AND HIS BROTHER"
    kind "entity"
    name "JOYCE AND HIS BROTHER"
    community 19
  ]
  node [
    id 1566
    label "E:NARRATOR AND AUNT"
    kind "entity"
    name "NARRATOR AND AUNT"
    community 19
  ]
  node [
    id 1567
    label "U:Novel-4128_00072#1"
    kind "unit"
    chunk_id "Novel-4128_00072"
    text "From the alehouse, the narrator went to Mrs. Whately's around two o'clock, but since she was going to dinner, they went to Whitehall and stayed there until past three. There, the narrator learned from Mr. Moore that my Lady Sandwich gave birth yesterday to a young lady and is very well."
    community 12
  ]
  node [
    id 1568
    label "E:MRS. WHATELY"
    kind "entity"
    name "MRS. WHATELY"
    community 5
  ]
  node [
    id 1569
    label "E:YOUNG LADY"
    kind "entity"
    name "YOUNG LADY"
    community 0
  ]
  node [
    id 1570
    label "E:BIRTH"
    kind "entity"
    name "BIRTH"
    community 12
  ]
  node [
    id 1571
    label "E:MRS. WHATELY'S"
    kind "entity"
    name "MRS. WHATELY'S"
    community 12
  ]
  node [
    id 1572
    label "E:2 O'CLOCK"
    kind "entity"
    name "2 O'CLOCK"
    community 5
  ]
  node [
    id 1573
    label "E:NARRATOR AND MRS. WHATELY"
    kind "entity"
    name "NARRATOR AND MRS. WHATELY"
    community 12
  ]
  node [
    id 1574
    label "U:Novel-4128_00072#2"
    kind "unit"
    chunk_id "Novel-4128_00072"
    text "The narrator returned to Mrs. Whately's, where they were well received. Mrs. Whately is eager for the match to proceed, but fears her daughter is too young and the portion is not big enough. She offers L200 down as a deposit. The girl is well favored, very young, modest, and the narrator believes she will do well for his brother. They parted, with the narrator to wait for a response from Hatfield, where the girl's husband is staying. Both the narrator and the couple are very desirous of the match."
    community 5
  ]
  node [
    id 1575
    label "E:DAUGHTER"
    kind "entity"
    name "DAUGHTER"
    community 5
  ]
  node [
    id 1576
    label "E:PORTION"
    kind "entity"
    name "PORTION"
    community 5
  ]
  node [
    id 1577
    label "E:GIRL"
    kind "entity"
    name "GIRL"
    community 5
  ]
  node [
    id 1578
    label "E:MATCH"
    kind "entity"
    name "MATCH"
    community 5
  ]
  node [
    id 1579
    label "E:DESIRIOUS"
    kind "entity"
    name "DESIRIOUS"
    community 5
  ]
  node [
    id 1580
    label "E:BROTHER"
    kind "entity"
    name "BROTHER"
    community 5
  ]
  node [
    id 1581
    label "E:HUSBAND AND HIS FAMILY"
    kind "entity"
    name "HUSBAND AND HIS FAMILY"
    community 5
  ]
  node [
    id 1582
    label "U:Novel-4128_00072#3"
    kind "unit"
    chunk_id "Novel-4128_00072"
    text "The narrator returned home to his father's house and went to the Wardrobe, where he supped with the ladies. He heard that their mother is well and that the young child is also well, and then returned home."
    community 4
  ]
  node [
    id 1583
    label "E:YOUNG CHILD"
    kind "entity"
    name "YOUNG CHILD"
    community 4
  ]
  node [
    id 1584
    label "C:Novel-4128_00073"
    kind "chunk"
    chunk_id "Novel-4128_00073"
  ]
  node [
    id 1585
    label "U:Novel-4128_00073#0"
    kind "unit"
    chunk_id "Novel-4128_00073"
    text "On the 22nd, the narrator went to the Privy Seal, was sealed there, and returned home at noon. He took his wife by coach to his uncle Fenner's, where there was a great deal of company but poor entertainment, and the house was so hot that his uncle Wight, his father, and he had to go out and stay at an alehouse to cool off. Afterward, they returned to church, where his father's family was in mourning and showing him great honour, which the world believed was due to his father's will. The narrator stayed out of the sermon and then, with his aunt Wight, his wife, Pall, and himself, went by coach to her house, where they supped on a Westphalia ham before returning home and going to bed."
    community 19
  ]
  node [
    id 1586
    label "E:SESSIONS"
    kind "entity"
    name "SESSIONS"
    community 19
  ]
  node [
    id 1587
    label "E:FATHER'S FAMILY"
    kind "entity"
    name "FATHER'S FAMILY"
    community 19
  ]
  node [
    id 1588
    label "E:WORLD BELIEVED"
    kind "entity"
    name "WORLD BELIEVED"
    community 19
  ]
  node [
    id 1589
    label "E:WESTPHALIA HAM"
    kind "entity"
    name "WESTPHALIA HAM"
    community 19
  ]
  node [
    id 1590
    label "E:AUNT WIGHT"
    kind "entity"
    name "AUNT WIGHT"
    community 13
  ]
  node [
    id 1591
    label "E:SUPPED"
    kind "entity"
    name "SUPPED"
    community 19
  ]
  node [
    id 1592
    label "E:NARRATOR WENT TO THE PRIVY SEAL"
    kind "entity"
    name "NARRATOR WENT TO THE PRIVY SEAL"
    community 19
  ]
  node [
    id 1593
    label "E:UNCLE FENNER'S"
    kind "entity"
    name "UNCLE FENNER'S"
    community 19
  ]
  node [
    id 1594
    label "E:UNCLE WIGHT AND HIS FATHER AND THE NARRATOR HAD TO GO OUT"
    kind "entity"
    name "UNCLE WIGHT AND HIS FATHER AND THE NARRATOR HAD TO GO OUT"
    community 19
  ]
  node [
    id 1595
    label "E:NARRATOR AND HIS FATHER"
    kind "entity"
    name "NARRATOR AND HIS FATHER"
    community 19
  ]
  node [
    id 1596
    label "E:ALEHOUSE TO COOL OFF"
    kind "entity"
    name "ALEHOUSE TO COOL OFF"
    community 19
  ]
  node [
    id 1597
    label "E:WORLD"
    kind "entity"
    name "WORLD"
    community 19
  ]
  node [
    id 1598
    label "E:HIS FATHER GAVE THE MOURNING"
    kind "entity"
    name "HIS FATHER GAVE THE MOURNING"
    community 19
  ]
  node [
    id 1599
    label "E:HER HOUSE"
    kind "entity"
    name "HER HOUSE"
    community 19
  ]
  node [
    id 1600
    label "U:Novel-4128_00073#1"
    kind "unit"
    chunk_id "Novel-4128_00073"
    text "On the 23rd, the narrator went to his father's house and found him and his mother in a state of discontent, which troubled him greatly. He observed that his mother had become very simple and unquiet. He then went to Dr. Williams, who was found within, and they sat and talked for a while. From there, they went to Tom Trice's alehouse near, where they sat and talked, and found him fair. They examined his uncle's will before him and Dr. Williams, had them sign a copy, and then gave T. the signed copy."
    community 4
  ]
  node [
    id 1601
    label "E:DISCONTENT"
    kind "entity"
    name "DISCONTENT"
    community 4
  ]
  node [
    id 1602
    label "E:SIMPLE"
    kind "entity"
    name "SIMPLE"
    community 4
  ]
  node [
    id 1603
    label "E:UNQUITE"
    kind "entity"
    name "UNQUITE"
    community 4
  ]
  node [
    id 1604
    label "E:COPY"
    kind "entity"
    name "COPY"
    community 4
  ]
  node [
    id 1605
    label "E:T"
    kind "entity"
    name "T"
    community 4
  ]
  node [
    id 1606
    label "E:NARRATOR WENT TO HIS FATHER'S HOUSE"
    kind "entity"
    name "NARRATOR WENT TO HIS FATHER'S HOUSE"
    community 4
  ]
  node [
    id 1607
    label "E:HIS FATHER'S HOUSE"
    kind "entity"
    name "HIS FATHER'S HOUSE"
    community 4
  ]
  node [
    id 1608
    label "E:STATE OF DISCONTENT"
    kind "entity"
    name "STATE OF DISCONTENT"
    community 4
  ]
  node [
    id 1609
    label "E:HIS MOTHER"
    kind "entity"
    name "HIS MOTHER"
    community 4
  ]
  node [
    id 1610
    label "E:VERY SIMPLE AND UNQUIET"
    kind "entity"
    name "VERY SIMPLE AND UNQUIET"
    community 4
  ]
  node [
    id 1611
    label "E:NARRATOR AND DR. WILLIAMS"
    kind "entity"
    name "NARRATOR AND DR. WILLIAMS"
    community 4
  ]
  node [
    id 1612
    label "E:TOM TRICE'S ALEHOUSE"
    kind "entity"
    name "TOM TRICE'S ALEHOUSE"
    community 4
  ]
  node [
    id 1613
    label "E:COPY OF THE WILL"
    kind "entity"
    name "COPY OF THE WILL"
    community 4
  ]
  node [
    id 1614
    label "C:Novel-4128_00074"
    kind "chunk"
    chunk_id "Novel-4128_00074"
  ]
  node [
    id 1615
    label "U:Novel-4128_00074#0"
    kind "unit"
    chunk_id "Novel-4128_00074"
    text "Williams had them sign a copy, and gave T. Trice the original to prove it; he then took the narrator's father and the narrator to a judge of the Court, where they were sworn in, and later returned to the alehouse, drank, and parted. Dr. Williams and the narrator went to a cook's where they ate mutton, and then the narrator went to W. Joyce's, where by appointment his wife was, and he took her to the Opera and showed her 'The Witts,' which he had seen twice before and was highly pleased with. Then, with his wife, they went to the Wardrobe to see his Lady, and returned home."
    community 4
  ]
  node [
    id 1616
    label "E:WILLIAMS"
    kind "entity"
    name "WILLIAMS"
    community 4
  ]
  node [
    id 1617
    label "E:T. TRICE"
    kind "entity"
    name "T. TRICE"
    community 4
  ]
  node [
    id 1618
    label "E:JUDGE OF THE COURT"
    kind "entity"
    name "JUDGE OF THE COURT"
    community 4
  ]
  node [
    id 1619
    label "E:MUTTON"
    kind "entity"
    name "MUTTON"
    community 4
  ]
  node [
    id 1620
    label "E:W. JOYCE"
    kind "entity"
    name "W. JOYCE"
    community 4
  ]
  node [
    id 1621
    label "E:ORIGINAL"
    kind "entity"
    name "ORIGINAL"
    community 4
  ]
  node [
    id 1622
    label "E:NARRATOR AND HIS WIFE"
    kind "entity"
    name "NARRATOR AND HIS WIFE"
    community 16
  ]
  node [
    id 1623
    label "U:Novel-4128_00074#1"
    kind "unit"
    chunk_id "Novel-4128_00074"
    text "On the 24th, the narrator spent the morning at the office doing business; later, they were called to Sir W. Batten's to see a strange creature brought by Captain Holmes from Guiny, which is a large baboon that resembles a man in many ways, and the narrator believes it may be a monster born from a man and a she-baboon; he thinks it already understands much English and believes it could be taught to speak or make signs. The Comptroller and the narrator then went to Sir Rd. Ford's to view his house again, and reached a complete agreement to give him L200 per annum for it. They returned home and there met Captain."
    community 6
  ]
  node [
    id 1624
    label "E:CAPTAIN HOLMES"
    kind "entity"
    name "CAPTAIN HOLMES"
    community 6
  ]
  node [
    id 1625
    label "E:GUINY"
    kind "entity"
    name "GUINY"
    community 6
  ]
  node [
    id 1626
    label "E:BABOON"
    kind "entity"
    name "BABOON"
    community 6
  ]
  node [
    id 1627
    label "E:STRANGE CREATURE"
    kind "entity"
    name "STRANGE CREATURE"
    community 6
  ]
  node [
    id 1628
    label "E:SIR RD. FORD"
    kind "entity"
    name "SIR RD. FORD"
    community 6
  ]
  node [
    id 1629
    label "E:L200 PER ANNUM"
    kind "entity"
    name "L200 PER ANNUM"
    community 6
  ]
  node [
    id 1630
    label "E:BABOON IS A MONSTER FROM A MAN AND A SHE-BABOON"
    kind "entity"
    name "BABOON IS A MONSTER FROM A MAN AND A SHE-BABOON"
    community 6
  ]
  node [
    id 1631
    label "E:NARRATOR AND THE COMPTROLLER"
    kind "entity"
    name "NARRATOR AND THE COMPTROLLER"
    community 6
  ]
  node [
    id 1632
    label "C:Novel-4128_00075"
    kind "chunk"
    chunk_id "Novel-4128_00075"
  ]
  node [
    id 1633
    label "U:Novel-4128_00075#0"
    kind "unit"
    chunk_id "Novel-4128_00075"
    text "Capt. Isham came to inquire for the author, stating he was leaving for Portugal and that the author's letters to his Lord were not ready. The author took Capt. Isham to the Mitre, where he was given a glass of sack, and then went to the Opera to see 'Hamlet, Prince of Denmark,' where Betterton's performance of the prince's part was described as beyond imagination. After the performance, the author met Mr. Spong and took him to the Sampson in Paul's churchyard, where they stayed until late, and due to heavy rain, they had to go home wet and then to bed."
    community 17
  ]
  node [
    id 1634
    label "E:CAPT. ISHAM"
    kind "entity"
    name "CAPT. ISHAM"
    community 17
  ]
  node [
    id 1635
    label "E:SACK"
    kind "entity"
    name "SACK"
    community 17
  ]
  node [
    id 1636
    label "E:HAMLET PRINCE OF DENMARK"
    kind "entity"
    name "HAMLET PRINCE OF DENMARK"
    community 17
  ]
  node [
    id 1637
    label "E:BETTERTON"
    kind "entity"
    name "BETTERTON"
    community 17
  ]
  node [
    id 1638
    label "E:BLACKFRIARS"
    kind "entity"
    name "BLACKFRIARS"
    community 17
  ]
  node [
    id 1639
    label "E:MR. SPONG"
    kind "entity"
    name "MR. SPONG"
    community 17
  ]
  node [
    id 1640
    label "E:SAMPSON"
    kind "entity"
    name "SAMPSON"
    community 17
  ]
  node [
    id 1641
    label "E:PAUL'S CHURCHYARD"
    kind "entity"
    name "PAUL'S CHURCHYARD"
    community 17
  ]
  node [
    id 1642
    label "E:25TH LORD'S DAY"
    kind "entity"
    name "25TH LORD'S DAY"
    community 17
  ]
  node [
    id 1643
    label "E:RESTITUTION"
    kind "entity"
    name "RESTITUTION"
    community 17
  ]
  node [
    id 1644
    label "E:BEYOND IMAGINATION"
    kind "entity"
    name "BEYOND IMAGINATION"
    community 17
  ]
  node [
    id 1645
    label "U:Novel-4128_00075#1"
    kind "unit"
    chunk_id "Novel-4128_00075"
    text "Sir William Davenant introduced the use of scenery in theater, and Betterton was taught by Davenant how to act the part of Hamlet, which was originally instructed by Shakespeare through Taylor of the Blackfriars."
    community 17
  ]
  node [
    id 1646
    label "E:HAMLET"
    kind "entity"
    name "HAMLET"
    community 17
  ]
  node [
    id 1647
    label "E:TAYLOR"
    kind "entity"
    name "TAYLOR"
    community 17
  ]
  node [
    id 1648
    label "E:DAVENANT"
    kind "entity"
    name "DAVENANT"
    community 17
  ]
  node [
    id 1649
    label "C:Novel-4128_00076"
    kind "chunk"
    chunk_id "Novel-4128_00076"
  ]
  node [
    id 1650
    label "U:Novel-4128_00076#0"
    kind "unit"
    chunk_id "Novel-4128_00076"
    text "Mills discusses the necessity of restitution. At home, he finds his Lady Batten and her daughter looking askew at his wife because she does not conform to them or show solicitude for their acquaintance, a situation which Mills is not troubled by. Later, his father arrives, intending to go into the country the next day; after conversation, Mills and his father call Pall to them, and in great anger, Mills tells his father before him that he will no longer keep Pall, and his father states he will have nothing to do with her. Eventually, after calming Pall's high spirit, Mills convinces his father to allow her to go into the country with his mother and father to stay there temporarily and observe her behavior. Following this, Mills and his father go to his uncle Wight's, where they sup, and Wight takes his leave. Mills then walks with his father as far as Paul's, where they part, and returns home, feeling some relief after ending the trouble caused by Pall, who has been a significant source of distress for him."
    community 3
  ]
  node [
    id 1651
    label "E:MILLS"
    kind "entity"
    name "MILLS"
    community 3
  ]
  node [
    id 1652
    label "E:HER DAUGHTER"
    kind "entity"
    name "HER DAUGHTER"
    community 3
  ]
  node [
    id 1653
    label "E:MILLS' WIFE"
    kind "entity"
    name "MILLS' WIFE"
    community 3
  ]
  node [
    id 1654
    label "E:MILLS' FATHER"
    kind "entity"
    name "MILLS' FATHER"
    community 3
  ]
  node [
    id 1655
    label "E:MILLS' MOTHER"
    kind "entity"
    name "MILLS' MOTHER"
    community 3
  ]
  node [
    id 1656
    label "E:JANE"
    kind "entity"
    name "JANE"
    community 3
  ]
  node [
    id 1657
    label "E:MILLS' MAID"
    kind "entity"
    name "MILLS' MAID"
    community 3
  ]
  node [
    id 1658
    label "E:THREE YEARS"
    kind "entity"
    name "THREE YEARS"
    community 3
  ]
  node [
    id 1659
    label "E:MORNING"
    kind "entity"
    name "MORNING"
    community 3
  ]
  node [
    id 1660
    label "E:MILLS' HOME"
    kind "entity"
    name "MILLS' HOME"
    community 3
  ]
  node [
    id 1661
    label "E:NECESSITY OF RESTITUTION"
    kind "entity"
    name "NECESSITY OF RESTITUTION"
    community 3
  ]
  node [
    id 1662
    label "E:LADY BATTEN AND HER DAUGHTER"
    kind "entity"
    name "LADY BATTEN AND HER DAUGHTER"
    community 3
  ]
  node [
    id 1663
    label "E:LADY BATTEN AND HER DAUGHTER LOOKING ASKEW"
    kind "entity"
    name "LADY BATTEN AND HER DAUGHTER LOOKING ASKEW"
    community 3
  ]
  node [
    id 1664
    label "E:MILLS AND HIS FATHER"
    kind "entity"
    name "MILLS AND HIS FATHER"
    community 3
  ]
  node [
    id 1665
    label "E:PALL TO GO INTO THE COUNTRY"
    kind "entity"
    name "PALL TO GO INTO THE COUNTRY"
    community 3
  ]
  node [
    id 1666
    label "E:MILLS' MOTHER AND MILLS' FATHER"
    kind "entity"
    name "MILLS' MOTHER AND MILLS' FATHER"
    community 3
  ]
  node [
    id 1667
    label "E:UNCLE WIGHT'S"
    kind "entity"
    name "UNCLE WIGHT'S"
    community 3
  ]
  node [
    id 1668
    label "E:HER MOTHER"
    kind "entity"
    name "HER MOTHER"
    community 3
  ]
  node [
    id 1669
    label "E:MILLS' MORNINGS"
    kind "entity"
    name "MILLS' MORNINGS"
    community 3
  ]
  node [
    id 1670
    label "U:Novel-4128_00076#1"
    kind "unit"
    chunk_id "Novel-4128_00076"
    text "This morning, before going out, Mills reconciles with his maid Jane, who has served him for three years and is now going into the country to visit her mother."
    community 3
  ]
  node [
    id 1671
    label "C:Novel-4128_00077"
    kind "chunk"
    chunk_id "Novel-4128_00077"
  ]
  node [
    id 1672
    label "U:Novel-4128_00077#0"
    kind "unit"
    chunk_id "Novel-4128_00077"
    text "The poor girl cried, and the narrator could hardly forbear weeping because although she had become lazy and spoilt due to Pall's arrival, she would be the only one to please them better in all things and was so harmless, and thus the narrator felt deep sorrow at her departure. The narrator paid her wages and gave her 2s. 6d. extra, then said goodbye, with a mind full of trouble over her leaving."
    community 3
  ]
  node [
    id 1673
    label "E:POOR GIRL"
    kind "entity"
    name "POOR GIRL"
    community 3
  ]
  node [
    id 1674
    label "E:2S 6D"
    kind "entity"
    name "2S 6D"
    community 3
  ]
  node [
    id 1675
    label "E:WAGES"
    kind "entity"
    name "WAGES"
    community 3
  ]
  node [
    id 1676
    label "E:HARMLESS"
    kind "entity"
    name "HARMLESS"
    community 3
  ]
  node [
    id 1677
    label "E:MIND FULL OF TROUBLE"
    kind "entity"
    name "MIND FULL OF TROUBLE"
    community 3
  ]
  node [
    id 1678
    label "E:GOING"
    kind "entity"
    name "GOING"
    community 3
  ]
  node [
    id 1679
    label "U:Novel-4128_00077#1"
    kind "unit"
    chunk_id "Novel-4128_00077"
    text "The narrator went to his father, where he and his father and Thomas settled accounts and reviewed the financial records, and found that his father had only L45 in his own money and owed about the same amount, so the narrator concluded that if his father had died before Uncle Robert, my mother would have been left in a very difficult situation."
    community 4
  ]
  node [
    id 1680
    label "E:THOMAS"
    kind "entity"
    name "THOMAS"
    community 4
  ]
  node [
    id 1681
    label "E:L45"
    kind "entity"
    name "L45"
    community 4
  ]
  node [
    id 1682
    label "E:CONDITION"
    kind "entity"
    name "CONDITION"
    community 4
  ]
  node [
    id 1683
    label "E:ACCOUNTS"
    kind "entity"
    name "ACCOUNTS"
    community 4
  ]
  node [
    id 1684
    label "E:MOTHER WOULD HAVE BEEN LEFT IN A VERY DIFFICULT SITUATION"
    kind "entity"
    name "MOTHER WOULD HAVE BEEN LEFT IN A VERY DIFFICULT SITUATION"
    community 4
  ]
  node [
    id 1685
    label "U:Novel-4128_00077#2"
    kind "unit"
    chunk_id "Novel-4128_00077"
    text "The narrator went to Tom Trice to have the will probated and had it done according to his wishes, which gave both his father and himself good content."
    community 4
  ]
  node [
    id 1686
    label "E:PROBATE"
    kind "entity"
    name "PROBATE"
    community 4
  ]
  node [
    id 1687
    label "E:GOOD CONTENT"
    kind "entity"
    name "GOOD CONTENT"
    community 4
  ]
  node [
    id 1688
    label "U:Novel-4128_00077#3"
    kind "unit"
    chunk_id "Novel-4128_00077"
    text "The narrator went to his Lady at the Wardrobe and then to the Theatre, where he saw the play 'Antipodes,' which was full of mirth but contained no great matter beyond that."
    community 16
  ]
  node [
    id 1689
    label "E:LADY AT THE WARDBROOKE"
    kind "entity"
    name "LADY AT THE WARDBROOKE"
    community 16
  ]
  node [
    id 1690
    label "E:ANTIPODES"
    kind "entity"
    name "ANTIPODES"
    community 16
  ]
  node [
    id 1691
    label "E:MIRTH"
    kind "entity"
    name "MIRTH"
    community 16
  ]
  node [
    id 1692
    label "E:NO GREAT MATTER"
    kind "entity"
    name "NO GREAT MATTER"
    community 16
  ]
  node [
    id 1693
    label "U:Novel-4128_00077#4"
    kind "unit"
    chunk_id "Novel-4128_00077"
    text "The narrator met Mr. Bostock at the Theatre, who was formerly a clerk of Mr. Phelps, and went to the Devil tavern with him, where they drank and then left."
    community 10
  ]
  node [
    id 1694
    label "E:MR. BOSTOCK"
    kind "entity"
    name "MR. BOSTOCK"
    community 10
  ]
  node [
    id 1695
    label "E:MR. PHELPS"
    kind "entity"
    name "MR. PHELPS"
    community 10
  ]
  node [
    id 1696
    label "E:DRANK"
    kind "entity"
    name "DRANK"
    community 10
  ]
  node [
    id 1697
    label "C:Novel-4128_00078"
    kind "chunk"
    chunk_id "Novel-4128_00078"
  ]
  node [
    id 1698
    label "U:Novel-4128_00078#0"
    kind "unit"
    chunk_id "Novel-4128_00078"
    text "The narrator went to the Devil tavern, drank there, and then went to his uncle Fenner's, where his father was at an alehouse. The narrator, his father, and Tom discussed a proposal for Tom to marry a broker's daughter with a large portion, but the narrator fears the match will not succeed and that the father will try his best. After leaving, they met a mother and son, friends of the father's man Ned, who were angry at the father for putting Ned away, which troubled both the narrator and the father, though they believe everything will be well. The narrator received news that his uncle Thomas and his son Thomas had gone into the country without giving notice, which surprised them but they do not fear it."
    community 14
  ]
  node [
    id 1699
    label "E:BROKER'S DAUGHTER"
    kind "entity"
    name "BROKER'S DAUGHTER"
    community 14
  ]
  node [
    id 1700
    label "E:NED"
    kind "entity"
    name "NED"
    community 14
  ]
  node [
    id 1701
    label "E:MOTHER AND SON"
    kind "entity"
    name "MOTHER AND SON"
    community 14
  ]
  node [
    id 1702
    label "E:SON THOMAS"
    kind "entity"
    name "SON THOMAS"
    community 14
  ]
  node [
    id 1703
    label "E:LET BLOOD"
    kind "entity"
    name "LET BLOOD"
    community 14
  ]
  node [
    id 1704
    label "E:22ND JULY LAST"
    kind "entity"
    name "22ND JULY LAST"
    community 14
  ]
  node [
    id 1705
    label "E:CRANE TAVERN"
    kind "entity"
    name "CRANE TAVERN"
    community 14
  ]
  node [
    id 1706
    label "E:STOCKS"
    kind "entity"
    name "STOCKS"
    community 14
  ]
  node [
    id 1707
    label "E:MR. FANSHAW"
    kind "entity"
    name "MR. FANSHAW"
    community 14
  ]
  node [
    id 1708
    label "E:DISCUSSED A PROPOSAL FOR TOM TO MARRY A BROKER'S DAUGHTER WITH A LARGE PORTION"
    kind "entity"
    name "DISCUSSED A PROPOSAL FOR TOM TO MARRY A BROKER'S DAUGHTER WITH A LARGE PORTION"
    community 14
  ]
  node [
    id 1709
    label "E:WERE TROUBLED BY THE ANGER OF THE MOTHER AND SON"
    kind "entity"
    name "WERE TROUBLED BY THE ANGER OF THE MOTHER AND SON"
    community 14
  ]
  node [
    id 1710
    label "E:WENT INTO THE COUNTRY WITHOUT GIVING NOTICE"
    kind "entity"
    name "WENT INTO THE COUNTRY WITHOUT GIVING NOTICE"
    community 14
  ]
  node [
    id 1711
    label "E:UNCLE THOMAS AND HIS SON THOMAS"
    kind "entity"
    name "UNCLE THOMAS AND HIS SON THOMAS"
    community 14
  ]
  node [
    id 1712
    label "U:Novel-4128_00078#1"
    kind "unit"
    chunk_id "Novel-4128_00078"
    text "The letter from Lord Sandwich, dated the 22nd July last, confirms that he was ill with fever and had been twice let blood while staying in Alicante, which supports the narrator's belief that he is still unwell."
    community 14
  ]
  node [
    id 1713
    label "E:LORD SANDWICH'S LETTER"
    kind "entity"
    name "LORD SANDWICH'S LETTER"
    community 14
  ]
  node [
    id 1714
    label "U:Novel-4128_00078#2"
    kind "unit"
    chunk_id "Novel-4128_00078"
    text "The narrator visited the Crane tavern at the Stocks by appointment and met Mr. Fanshaw, who is going to Portugal the next day, and Captain Isham, who is also going toward Portugal, and they took leave of each other."
    community 14
  ]
  node [
    id 1715
    label "C:Novel-4128_00079"
    kind "chunk"
    chunk_id "Novel-4128_00079"
  ]
  node [
    id 1716
    label "U:Novel-4128_00079#0"
    kind "unit"
    chunk_id "Novel-4128_00079"
    text "Fanshaw is going tomorrow and Captain Isham is heading toward their voyage to Portugal. The group drank a great deal of wine, with Mr. Fanshaw drinking so much that he could hardly move. They then took leave of each other. On the 27th, the narrator went to the Wardrobe, where they took leave of my Lord Hinchingbroke and his brother, who left by coach toward Rye on their way to France, and they prayed that God bless them. The narrator was then called to my Lady's bedside, where they discussed for an hour Mr. Edward Montagu's decision to dispose of L5000 for my Lord's departure to Portugal, and their concerns that he would not do so to my Lord's honour or profit, and the narrator was to investigate further. Afterward, the narrator went to the office and sat until noon. Then, the narrator and his wife traveled by coach to their cozen Thos. Pepys, the Executor, for dinner, where ladies, the narrator's father and mother were present, and they enjoyed themselves, though the narrator thought the dinners were poor, despite a poor venison pasty being served. The narrator and his wife then went to the Theatre and saw 'The Joviall Crew,' where the King, Duke, Duchess, and Madame Palmer were present, and the narrator's wife, to her great content, saw them all throughout the play, which was full of mirth."
    community 16
  ]
  node [
    id 1717
    label "E:FANSHAW"
    kind "entity"
    name "FANSHAW"
    community 16
  ]
  node [
    id 1718
    label "E:PORTUGAL DEPARTURE"
    kind "entity"
    name "PORTUGAL DEPARTURE"
    community 16
  ]
  node [
    id 1719
    label "E:NARRATOR TO ENQUIRE"
    kind "entity"
    name "NARRATOR TO ENQUIRE"
    community 16
  ]
  node [
    id 1720
    label "E:NARRATOR'S WIFE"
    kind "entity"
    name "NARRATOR'S WIFE"
    community 16
  ]
  node [
    id 1721
    label "E:THOS. PEPYS"
    kind "entity"
    name "THOS. PEPYS"
    community 16
  ]
  node [
    id 1722
    label "E:EXECUTOR"
    kind "entity"
    name "EXECUTOR"
    community 16
  ]
  node [
    id 1723
    label "E:NARRATOR'S MOTHER"
    kind "entity"
    name "NARRATOR'S MOTHER"
    community 16
  ]
  node [
    id 1724
    label "E:JOVIALL CREW"
    kind "entity"
    name "JOVIALL CREW"
    community 16
  ]
  node [
    id 1725
    label "E:MADAME PALMER"
    kind "entity"
    name "MADAME PALMER"
    community 16
  ]
  node [
    id 1726
    label "E:TOMORROW"
    kind "entity"
    name "TOMORROW"
    community 16
  ]
  node [
    id 1727
    label "E:COULD HARDLY MOVE"
    kind "entity"
    name "COULD HARDLY MOVE"
    community 14
  ]
  node [
    id 1728
    label "E:EACH OTHER"
    kind "entity"
    name "EACH OTHER"
    community 16
  ]
  node [
    id 1729
    label "E:THEY TOOK LEAVE OF MY LORD HINCHINGBROKE AND HIS BROTHER"
    kind "entity"
    name "THEY TOOK LEAVE OF MY LORD HINCHINGBROKE AND HIS BROTHER"
    community 0
  ]
  node [
    id 1730
    label "E:MY LORD HINCHINGBROKE AND HIS BROTHER"
    kind "entity"
    name "MY LORD HINCHINGBROKE AND HIS BROTHER"
    community 16
  ]
  node [
    id 1731
    label "E:NARRATOR AND MY LADY"
    kind "entity"
    name "NARRATOR AND MY LADY"
    community 16
  ]
  node [
    id 1732
    label "E:MR. EDWARD MONTAGU'S DISPOSAL OF L5000 FOR MY LORD'S DEPARTURE TO PORTUGAL"
    kind "entity"
    name "MR. EDWARD MONTAGU'S DISPOSAL OF L5000 FOR MY LORD'S DEPARTURE TO PORTUGAL"
    community 16
  ]
  node [
    id 1733
    label "E:MR. EDWARD MONTAGU WOULD NOT ACT TO MY LORD'S HONOUR OR PROFIT"
    kind "entity"
    name "MR. EDWARD MONTAGU WOULD NOT ACT TO MY LORD'S HONOUR OR PROFIT"
    community 16
  ]
  node [
    id 1734
    label "E:MR. EDWARD MONTAGU'S ACTION"
    kind "entity"
    name "MR. EDWARD MONTAGU'S ACTION"
    community 16
  ]
  node [
    id 1735
    label "E:THOS. PEPYS, THE EXECUTOR"
    kind "entity"
    name "THOS. PEPYS, THE EXECUTOR"
    community 16
  ]
  node [
    id 1736
    label "E:LADIES, THE NARRATOR'S FATHER AND MOTHER"
    kind "entity"
    name "LADIES, THE NARRATOR'S FATHER AND MOTHER"
    community 16
  ]
  node [
    id 1737
    label "E:POOR FOR SUCH GUESTS"
    kind "entity"
    name "POOR FOR SUCH GUESTS"
    community 16
  ]
  node [
    id 1738
    label "E:POOR VENISON PASTY"
    kind "entity"
    name "POOR VENISON PASTY"
    community 15
  ]
  node [
    id 1739
    label "E:KING, DUKE, DUCHESS, AND MADAME PALMER"
    kind "entity"
    name "KING, DUKE, DUCHESS, AND MADAME PALMER"
    community 16
  ]
  node [
    id 1740
    label "U:Novel-4128_00079#1"
    kind "unit"
    chunk_id "Novel-4128_00079"
    text "The narrator and his wife attended a performance of 'The Joviall Crew' at the Theatre, where the King, Duke, Duchess, and Madame Palmer were present, and the narrator's wife enjoyed seeing them throughout the play, which was full of mirth."
    community 16
  ]
  node [
    id 1741
    label "C:Novel-4128_00080"
    kind "chunk"
    chunk_id "Novel-4128_00080"
  ]
  node [
    id 1742
    label "U:Novel-4128_00080#0"
    kind "unit"
    chunk_id "Novel-4128_00080"
    text "The narrator went to his father's house, stayed to talk a while, and then returned home by foot in the moonlight. On the way home, his wife told him a sad story about her brother Balty, asking him to help him, but the narrator fears getting involved because he does not want to be tied to him again. He went to bed, during which his wife continued to tell him Balty's situation, crying, which troubled the narrator."
    community 4
  ]
  node [
    id 1743
    label "E:BALTY"
    kind "entity"
    name "BALTY"
    community 4
  ]
  node [
    id 1744
    label "E:HER BROTHER"
    kind "entity"
    name "HER BROTHER"
    community 4
  ]
  node [
    id 1745
    label "E:HIM"
    kind "entity"
    name "HIM"
    community 4
  ]
  node [
    id 1746
    label "E:HIS CASE"
    kind "entity"
    name "HIS CASE"
    community 4
  ]
  node [
    id 1747
    label "E:TEARS"
    kind "entity"
    name "TEARS"
    community 4
  ]
  node [
    id 1748
    label "E:FEAR"
    kind "entity"
    name "FEAR"
    community 4
  ]
  node [
    id 1749
    label "E:HANDS"
    kind "entity"
    name "HANDS"
    community 4
  ]
  node [
    id 1750
    label "E:WIFE'S STORY"
    kind "entity"
    name "WIFE'S STORY"
    community 4
  ]
  node [
    id 1751
    label "E:BALTY'S CASE"
    kind "entity"
    name "BALTY'S CASE"
    community 4
  ]
  node [
    id 1752
    label "U:Novel-4128_00080#1"
    kind "unit"
    chunk_id "Novel-4128_00080"
    text "On the 28th, the narrator spent the morning at home organizing papers. At noon, he went to the Exchange where he met Dr. Williams by appointment. With Dr. Williams, he visited an attorney, a friend of Dr. Williams, to discuss the bond of his aunt Pepys for L200, and Dr. Williams stated absolutely that they would not be forced to pay interest on the money. The narrator doubted this very much. He spent the afternoon drinking with Dr. Williams and returned home. That day, he forged a letter to Sir W. Pen, pretending it was from the thief who stole his tankard, only to mock and laugh at Sir W. Pen."
    community 11
  ]
  node [
    id 1753
    label "E:ATTORNEY"
    kind "entity"
    name "ATTORNEY"
    community 11
  ]
  node [
    id 1754
    label "E:AUNT PEPYS"
    kind "entity"
    name "AUNT PEPYS"
    community 11
  ]
  node [
    id 1755
    label "E:INTEREST"
    kind "entity"
    name "INTEREST"
    community 11
  ]
  node [
    id 1756
    label "E:DRINKING"
    kind "entity"
    name "DRINKING"
    community 6
  ]
  node [
    id 1757
    label "E:FORGED LETTER"
    kind "entity"
    name "FORGED LETTER"
    community 11
  ]
  node [
    id 1758
    label "E:THIEF"
    kind "entity"
    name "THIEF"
    community 11
  ]
  node [
    id 1759
    label "E:ABUSE"
    kind "entity"
    name "ABUSE"
    community 11
  ]
  node [
    id 1760
    label "E:LAUGH"
    kind "entity"
    name "LAUGH"
    community 11
  ]
  node [
    id 1761
    label "E:MOCKED"
    kind "entity"
    name "MOCKED"
    community 11
  ]
  node [
    id 1762
    label "E:WE WILL NOT BE FORCED TO PAY INTEREST"
    kind "entity"
    name "WE WILL NOT BE FORCED TO PAY INTEREST"
    community 11
  ]
  node [
    id 1763
    label "U:Novel-4128_00080#2"
    kind "unit"
    chunk_id "Novel-4128_00080"
    text "The passage ends on the 29th, with no further details provided."
    community 13
  ]
  node [
    id 1764
    label "C:Novel-4128_00081"
    kind "chunk"
    chunk_id "Novel-4128_00081"
  ]
  node [
    id 1765
    label "U:Novel-4128_00081#0"
    kind "unit"
    chunk_id "Novel-4128_00081"
    text "The narrator mentions that a thief stole a tankard and then abused and laughed at the owner, as if the pen was a metaphor for the thief's actions. At the office all morning, the narrator's father, mother, and aunt Bell came to dine with him for the first time at his house, and they were very merry. After dinner, the two women visited aunt Wight and my father went about other business, while the narrator went to a bookseller and stayed there until four o'clock. At four, by appointment, the narrator met his father at his uncle Fenner's house, where they went to an alehouse. Mr. Evans, the tailor, whose daughter the narrator and his father had considered for Tom's wife, arrived. The father and narrator sat and discussed the marriage proposal; he stated that he has no objection to the plan, but that the estate God has blessed him with is too great to give away since there is only a trade and house in present possession. They ended the conversation on friendly terms. After parting, the narrator and his father walked a little way, then at Holborn they said goodbye, with the father going to Brampton the next morning to settle matters for his mother's arrival. The narrator returned home."
    community 13
  ]
  node [
    id 1766
    label "E:PEN"
    kind "entity"
    name "PEN"
    community 13
  ]
  node [
    id 1767
    label "E:MR. EVANS"
    kind "entity"
    name "MR. EVANS"
    community 13
  ]
  node [
    id 1768
    label "E:TAILOR"
    kind "entity"
    name "TAILOR"
    community 13
  ]
  node [
    id 1769
    label "E:HOLBORN"
    kind "entity"
    name "HOLBORN"
    community 13
  ]
  node [
    id 1770
    label "E:THIEF'S ACTIONS"
    kind "entity"
    name "THIEF'S ACTIONS"
    community 13
  ]
  node [
    id 1771
    label "E:BOOKSELLER"
    kind "entity"
    name "BOOKSELLER"
    community 13
  ]
  node [
    id 1772
    label "E:TOM'S POTENTIAL WIFE"
    kind "entity"
    name "TOM'S POTENTIAL WIFE"
    community 13
  ]
  node [
    id 1773
    label "E:MARRIAGE PROPOSAL"
    kind "entity"
    name "MARRIAGE PROPOSAL"
    community 13
  ]
  node [
    id 1774
    label "E:TRADE AND HOUSE"
    kind "entity"
    name "TRADE AND HOUSE"
    community 13
  ]
  node [
    id 1775
    label "U:Novel-4128_00081#1"
    kind "unit"
    chunk_id "Novel-4128_00081"
    text "The passage describes the narrator's day on the 29th and 30th, including events at the office, a dinner with family, visits to relatives, a meeting with Mr. Evans about Tom's marriage, and a farewell with his father at Holborn. The father is to travel to Brampton the next morning to settle affairs for his mother's arrival."
    community 13
  ]
  node [
    id 1776
    label "E:DINNER WITH FAMILY"
    kind "entity"
    name "DINNER WITH FAMILY"
    community 13
  ]
  node [
    id 1777
    label "E:VISIT TO BOOKSELLER"
    kind "entity"
    name "VISIT TO BOOKSELLER"
    community 13
  ]
  node [
    id 1778
    label "E:MEETING WITH MR. EVANS"
    kind "entity"
    name "MEETING WITH MR. EVANS"
    community 13
  ]
  node [
    id 1779
    label "E:FATHER'S LEAVE TO BRAMPTON"
    kind "entity"
    name "FATHER'S LEAVE TO BRAMPTON"
    community 13
  ]
  node [
    id 1780
    label "E:NARRATOR'S RETURN HOME"
    kind "entity"
    name "NARRATOR'S RETURN HOME"
    community 13
  ]
  node [
    id 1781
    label "C:Novel-4128_00082"
    kind "chunk"
    chunk_id "Novel-4128_00082"
  ]
  node [
    id 1782
    label "U:Novel-4128_00082#0"
    kind "unit"
    chunk_id "Novel-4128_00082"
    text "On the 30th, at noon, the narrator and his wife met at the Wardrobe, dined with the children, and then went to my Lady's bedside where they talked and laughed for a while. Afterward, the narrator and his wife went to Drury Lane for a French comedy, which was poorly performed and unpleasant in every aspect, causing the narrator to feel sick in mind throughout the experience. At Drury Lane, the wife met a son of my Lord Somersett, whom she knew from France; the narrator did not show him much favor to avoid further acquaintance. Due to the lack of pleasantness, only the farce's foolishness remained, and they returned home."
    community 19
  ]
  node [
    id 1783
    label "E:DRURY LANE"
    kind "entity"
    name "DRURY LANE"
    community 19
  ]
  node [
    id 1784
    label "E:FRENCH COMEDY"
    kind "entity"
    name "FRENCH COMEDY"
    community 19
  ]
  node [
    id 1785
    label "E:POOR PERFORMANCE"
    kind "entity"
    name "POOR PERFORMANCE"
    community 19
  ]
  node [
    id 1786
    label "E:NASTY AND OUT OF ORDER"
    kind "entity"
    name "NASTY AND OUT OF ORDER"
    community 19
  ]
  node [
    id 1787
    label "E:SON OF MY LORD SOMERSETT"
    kind "entity"
    name "SON OF MY LORD SOMERSETT"
    community 19
  ]
  node [
    id 1788
    label "E:LUDGATE"
    kind "entity"
    name "LUDGATE"
    community 19
  ]
  node [
    id 1789
    label "E:BARTHOLOMEW FAIR"
    kind "entity"
    name "BARTHOLOMEW FAIR"
    community 19
  ]
  node [
    id 1790
    label "E:SLUT"
    kind "entity"
    name "SLUT"
    community 19
  ]
  node [
    id 1791
    label "E:WHORES"
    kind "entity"
    name "WHORES"
    community 19
  ]
  node [
    id 1792
    label "E:LUELLIN"
    kind "entity"
    name "LUELLIN"
    community 19
  ]
  node [
    id 1793
    label "E:JEMIMAH"
    kind "entity"
    name "JEMIMAH"
    community 19
  ]
  node [
    id 1794
    label "E:PAULINA"
    kind "entity"
    name "PAULINA"
    community 19
  ]
  node [
    id 1795
    label "E:MR"
    kind "entity"
    name "MR"
    community 19
  ]
  node [
    id 1796
    label "E:MY LADY'S BEDSIDE"
    kind "entity"
    name "MY LADY'S BEDSIDE"
    community 19
  ]
  node [
    id 1797
    label "E:GOOD WHILE"
    kind "entity"
    name "GOOD WHILE"
    community 19
  ]
  node [
    id 1798
    label "E:NARRATOR AND LUELLIN"
    kind "entity"
    name "NARRATOR AND LUELLIN"
    community 19
  ]
  node [
    id 1799
    label "U:Novel-4128_00082#1"
    kind "unit"
    chunk_id "Novel-4128_00082"
    text "On the 31st, the narrator spent the morning at home and in the office. At noon, Luellin arrived and they went to the tavern, then to Bartholomew Fair. On Luellin's suggestion, they visited a pitiful alehouse where two whores were brought, but the narrator strongly disapproved and experienced great discomfort, taking significant effort to leave and avoid being seen. After leaving, Luellin and the narrator walked toward Ludgate and parted. The narrator then returned alone to the fair, where he met his Ladies Jemimah and Paulina, and Mr."
    community 19
  ]
  node [
    id 1800
    label "E:31ST"
    kind "entity"
    name "31ST"
    community 19
  ]
  node [
    id 1801
    label "C:Novel-4128_00083"
    kind "chunk"
    chunk_id "Novel-4128_00083"
  ]
  node [
    id 1802
    label "U:Novel-4128_00083#0"
    kind "unit"
    chunk_id "Novel-4128_00083"
    text "At the fair, the narrator met with Ladies Jemimah and Paulina, Mr. Pickering, and Madamoiselle, who watched the monkeys dance, an event the narrator found impressive but disturbing due to the company's unclean nature. Afterward, they went to Christ's Hospitall, where Mr. Pickering bought them fairings and the narrator gave each lady a bauble, a small glass globe with hanging items, which pleased them greatly. The group then returned home by coach, where the narrator was called up to my Lady, and stayed to talk with her for what the narrator believes was a full hour. During this conversation, my Lady recounted with great innocence how Mrs. Crispe had told her that she intended, through a lady staying at her house, to have the King serve as godfather to the young lady currently in childbed; my Lady described the revelation with such sincerity and honesty that she reportedly sweated while telling it, which the narrator found deeply pleasurable due to the simplicity and harmlessness of the lady's character. The group then went to supper and returned home."
    community 1
  ]
  node [
    id 1803
    label "E:LADIES JEMIMAH AND PAULINA"
    kind "entity"
    name "LADIES JEMIMAH AND PAULINA"
    community 1
  ]
  node [
    id 1804
    label "E:MR. PICKERING"
    kind "entity"
    name "MR. PICKERING"
    community 1
  ]
  node [
    id 1805
    label "E:MADAMOISELLE"
    kind "entity"
    name "MADAMOISELLE"
    community 1
  ]
  node [
    id 1806
    label "E:FAIR"
    kind "entity"
    name "FAIR"
    community 1
  ]
  node [
    id 1807
    label "E:MONKEYS DANCE"
    kind "entity"
    name "MONKEYS DANCE"
    community 1
  ]
  node [
    id 1808
    label "E:CHRIST'S HOSPITAL"
    kind "entity"
    name "CHRIST'S HOSPITAL"
    community 1
  ]
  node [
    id 1809
    label "E:FAIRINGS"
    kind "entity"
    name "FAIRINGS"
    community 1
  ]
  node [
    id 1810
    label "E:BAUBLE"
    kind "entity"
    name "BAUBLE"
    community 1
  ]
  node [
    id 1811
    label "E:GLASS GLOBE WITH HANGING ITEMS"
    kind "entity"
    name "GLASS GLOBE WITH HANGING ITEMS"
    community 1
  ]
  node [
    id 1812
    label "E:MRS. CRISPE"
    kind "entity"
    name "MRS. CRISPE"
    community 1
  ]
  node [
    id 1813
    label "E:YOUNG LADY IN CHILDBED"
    kind "entity"
    name "YOUNG LADY IN CHILDBED"
    community 1
  ]
  node [
    id 1814
    label "U:Novel-4128_00083#1"
    kind "unit"
    chunk_id "Novel-4128_00083"
    text "The narrator and the ladies returned home by coach, where they were called up to my Lady, and the narrator stayed to talk with her for what the narrator believes was a full hour. During this time, my Lady recounted how Mrs. Crispe had told her that she intended, through a lady staying at her house, to have the King serve as godfather to the young lady currently in childbed; the narrator found the story's innocence and the lady's honesty deeply moving, as she reportedly sweated while telling it."
    community 1
  ]
  node [
    id 1815
    label "C:Novel-4128_00084"
    kind "chunk"
    chunk_id "Novel-4128_00084"
  ]
  node [
    id 1816
    label "U:Novel-4128_00084#0"
    kind "unit"
    chunk_id "Novel-4128_00084"
    text "Mr. Moore, who cannot easily part from the narrator, leads him to Fenchurch Street to the Mitre, where they drink a glass of wine and then part, with the narrator returning home and to bed. Thus ends the month. The narrator's maid Jane has recently left, and Pall is now left to manage all the household work until another maid arrives, which will not happen until Jane goes away to the country with the narrator's mother. The narrator and his wife are in good health. My Lord Sandwich is in the Straits and has recently recovered from a serious illness in Alicante. The narrator's father has gone to settle at Brampton, and the narrator is under significant business and trouble in settling the family estate to their satisfaction. The narrator admits he has recently become too much involved in seeing plays, expense, and pleasure, which causes him to forget his business duties, and he is working hard to correct this. There is no income coming in, so he has had to borrow a great deal for his own expenses and to help his father with household arrangements. The narrator has concerns about his brother Tom, who is now responsible for managing his father's trade, and fears that Tom will fail due to lack of intelligence and care."
    community 13
  ]
  node [
    id 1817
    label "E:FENCHURCH STREET"
    kind "entity"
    name "FENCHURCH STREET"
    community 13
  ]
  node [
    id 1818
    label "E:MONTH"
    kind "entity"
    name "MONTH"
    community 13
  ]
  node [
    id 1819
    label "E:MAID JANE"
    kind "entity"
    name "MAID JANE"
    community 13
  ]
  node [
    id 1820
    label "E:MY LORD SANDWICH"
    kind "entity"
    name "MY LORD SANDWICH"
    community 13
  ]
  node [
    id 1821
    label "E:STRAITS"
    kind "entity"
    name "STRAITS"
    community 13
  ]
  node [
    id 1822
    label "E:BORROWING"
    kind "entity"
    name "BORROWING"
    community 13
  ]
  node [
    id 1823
    label "E:MR. MOORE AND THE NARRATOR"
    kind "entity"
    name "MR. MOORE AND THE NARRATOR"
    community 16
  ]
  node [
    id 1824
    label "E:NARRATOR RETURNING HOME AND TO BED"
    kind "entity"
    name "NARRATOR RETURNING HOME AND TO BED"
    community 13
  ]
  node [
    id 1825
    label "E:HOUSEHOLD WORK"
    kind "entity"
    name "HOUSEHOLD WORK"
    community 13
  ]
  node [
    id 1826
    label "E:ANOTHER MAID ARRIVES"
    kind "entity"
    name "ANOTHER MAID ARRIVES"
    community 13
  ]
  node [
    id 1827
    label "E:ANOTHER MAID"
    kind "entity"
    name "ANOTHER MAID"
    community 13
  ]
  node [
    id 1828
    label "E:MAID JANE GOES TO THE COUNTRY WITH THE NARRATOR'S MOTHER"
    kind "entity"
    name "MAID JANE GOES TO THE COUNTRY WITH THE NARRATOR'S MOTHER"
    community 13
  ]
  node [
    id 1829
    label "E:SERIOUS ILLNESS IN ALICANTE"
    kind "entity"
    name "SERIOUS ILLNESS IN ALICANTE"
    community 13
  ]
  node [
    id 1830
    label "E:SETTLING THE ESTATE"
    kind "entity"
    name "SETTLING THE ESTATE"
    community 13
  ]
  node [
    id 1831
    label "E:SEEING PLAYS"
    kind "entity"
    name "SEEING PLAYS"
    community 13
  ]
  node [
    id 1832
    label "E:SEEING PLAYS AND EXPENSE"
    kind "entity"
    name "SEEING PLAYS AND EXPENSE"
    community 13
  ]
  node [
    id 1833
    label "E:FORGETTING HIS BUSINESS"
    kind "entity"
    name "FORGETTING HIS BUSINESS"
    community 13
  ]
  node [
    id 1834
    label "E:HIS OWN EXPENSES"
    kind "entity"
    name "HIS OWN EXPENSES"
    community 13
  ]
  node [
    id 1835
    label "E:FATHER'S TRADE"
    kind "entity"
    name "FATHER'S TRADE"
    community 13
  ]
  node [
    id 1836
    label "E:BROTHER TOM WILL FAIL"
    kind "entity"
    name "BROTHER TOM WILL FAIL"
    community 13
  ]
  node [
    id 1837
    label "E:LACK OF BRAINS AND CARE"
    kind "entity"
    name "LACK OF BRAINS AND CARE"
    community 13
  ]
  node [
    id 1838
    label "U:Novel-4128_00084#1"
    kind "unit"
    chunk_id "Novel-4128_00084"
    text "The narrator has concerns about his brother Tom, who is now responsible for managing his father's trade, and fears that Tom will fail due to lack of intelligence and care."
    community 13
  ]
  node [
    id 1839
    label "C:Novel-4128_00085"
    kind "chunk"
    chunk_id "Novel-4128_00085"
  ]
  node [
    id 1840
    label "U:Novel-4128_00085#0"
    kind "unit"
    chunk_id "Novel-4128_00085"
    text "At Court, there is great ill condition due to emulacion, poverty, and vices such as drinking, swearing, and loose amours, leading to widespread confusion and no content or satisfaction among any group of people. The Clergy are extremely high in status, causing public protest against their practices. The Benevolence, a voluntary contribution by subjects to the sovereign, amounts to L33,743 and is seen as insufficient and a source of widespread discontent, so it had better never have been established. The author intends to subscribe L20 to the Benevolence. At the Office, operations are quiet due to lack of money, with bills being offered for sale at a 10 per cent loss on the Exchange. The Office is in the process of acquiring Sir R. Ford's house, but difficulties in dividing ownership and the personal obligation to pay L200 per annum for rent make it unlikely the acquisition will happen. The season is very sickly with widespread outbreaks of strange and fatal fevers."
    community 6
  ]
  node [
    id 1841
    label "E:EMULACION"
    kind "entity"
    name "EMULACION"
    community 6
  ]
  node [
    id 1842
    label "E:POVERTY"
    kind "entity"
    name "POVERTY"
    community 6
  ]
  node [
    id 1843
    label "E:SWORING"
    kind "entity"
    name "SWORING"
    community 6
  ]
  node [
    id 1844
    label "E:LOOSE AMOURS"
    kind "entity"
    name "LOOSE AMOURS"
    community 6
  ]
  node [
    id 1845
    label "E:CONFUSION"
    kind "entity"
    name "CONFUSION"
    community 6
  ]
  node [
    id 1846
    label "E:CLERGY"
    kind "entity"
    name "CLERGY"
    community 6
  ]
  node [
    id 1847
    label "E:CONTENT"
    kind "entity"
    name "CONTENT"
    community 6
  ]
  node [
    id 1848
    label "E:BENEVOLENCE"
    kind "entity"
    name "BENEVOLENCE"
    community 6
  ]
  node [
    id 1849
    label "E:L33743"
    kind "entity"
    name "L33743"
    community 6
  ]
  node [
    id 1850
    label "E:MAY 31ST 1661"
    kind "entity"
    name "MAY 31ST 1661"
    community 6
  ]
  node [
    id 1851
    label "E:SUBSCRIPTION"
    kind "entity"
    name "SUBSCRIPTION"
    community 6
  ]
  node [
    id 1852
    label "E:10 PER CENT LOSS"
    kind "entity"
    name "10 PER CENT LOSS"
    community 6
  ]
  node [
    id 1853
    label "E:DIVIDING OF IT"
    kind "entity"
    name "DIVIDING OF IT"
    community 6
  ]
  node [
    id 1854
    label "E:PERSONAL OBLIGATION"
    kind "entity"
    name "PERSONAL OBLIGATION"
    community 6
  ]
  node [
    id 1855
    label "E:FEVERS"
    kind "entity"
    name "FEVERS"
    community 6
  ]
  node [
    id 1856
    label "E:STRANGE AND FATAL FEVERS"
    kind "entity"
    name "STRANGE AND FATAL FEVERS"
    community 6
  ]
  node [
    id 1857
    label "E:ALL PEOPLE"
    kind "entity"
    name "ALL PEOPLE"
    community 6
  ]
  node [
    id 1858
    label "E:CLERGY PRACTICE"
    kind "entity"
    name "CLERGY PRACTICE"
    community 6
  ]
  node [
    id 1859
    label "E:ANYONE"
    kind "entity"
    name "ANYONE"
    community 6
  ]
  node [
    id 1860
    label "E:ANY GROUP OF PEOPLE"
    kind "entity"
    name "ANY GROUP OF PEOPLE"
    community 6
  ]
  node [
    id 1861
    label "E:WIDESPREAD DISCONTENT"
    kind "entity"
    name "WIDESPREAD DISCONTENT"
    community 6
  ]
  node [
    id 1862
    label "E:QUIET OPERATIONS"
    kind "entity"
    name "QUIET OPERATIONS"
    community 6
  ]
  node [
    id 1863
    label "E:10 PER CENT LOSS ON EXCHANGE"
    kind "entity"
    name "10 PER CENT LOSS ON EXCHANGE"
    community 6
  ]
  node [
    id 1864
    label "E:PLEASING ONE ANOTHER"
    kind "entity"
    name "PLEASING ONE ANOTHER"
    community 6
  ]
  node [
    id 1865
    label "E:SEASON"
    kind "entity"
    name "SEASON"
    community 6
  ]
  node [
    id 1866
    label "U:Novel-4128_00085#1"
    kind "unit"
    chunk_id "Novel-4128_00085"
    text "The Benevolence, a voluntary contribution by subjects to the sovereign, was established on May 31st, 1661, with the clergy contributing L33,743, which is considered inadequate and a cause of widespread discontent."
    community 6
  ]
  node [
    id 1867
    label "U:Novel-4128_00085#2"
    kind "unit"
    chunk_id "Novel-4128_00085"
    text "The Office is currently experiencing financial difficulties, with bills being sold at a 10 per cent loss on the Exchange, and is planning to acquire Sir R. Ford's house, but faces significant challenges in dividing ownership and in personally paying L200 per annum for rent, making the acquisition unlikely to happen."
    community 6
  ]
  node [
    id 1868
    label "E:DIVIDING OF IT AND PERSONAL OBLIGATION"
    kind "entity"
    name "DIVIDING OF IT AND PERSONAL OBLIGATION"
    community 6
  ]
  node [
    id 1869
    label "U:Novel-4128_00085#3"
    kind "unit"
    chunk_id "Novel-4128_00085"
    text "The season is very sickly with widespread outbreaks of strange and fatal fevers affecting people everywhere."
    community 6
  ]
  node [
    id 1870
    label "C:Novel-4128_00086"
    kind "chunk"
    chunk_id "Novel-4128_00086"
  ]
  node [
    id 1871
    label "U:Novel-4128_00086#0"
    kind "unit"
    chunk_id "Novel-4128_00086"
    text "A season of strange and fatal fevers spread widely, causing illness everywhere."
    community 6
  ]
  node [
    id 1872
    label "U:Novel-4128_00086#1"
    kind "unit"
    chunk_id "Novel-4128_00086"
    text "A great baboon is described as being very much like a man in most aspects."
    community 6
  ]
  node [
    id 1873
    label "U:Novel-4128_00086#2"
    kind "unit"
    chunk_id "Novel-4128_00086"
    text "A play was not considered very good, although it was highly commended."
    community 16
  ]
  node [
    id 1874
    label "E:COMMENDATION"
    kind "entity"
    name "COMMENDATION"
    community 16
  ]
  node [
    id 1875
    label "U:Novel-4128_00086#3"
    kind "unit"
    chunk_id "Novel-4128_00086"
    text "A smell began to be detected, and as a result, the corpse was set forth."
    community 6
  ]
  node [
    id 1876
    label "E:SMELL"
    kind "entity"
    name "SMELL"
    community 6
  ]
  node [
    id 1877
    label "E:CORPSE"
    kind "entity"
    name "CORPSE"
    community 6
  ]
  node [
    id 1878
    label "E:SET FORTH"
    kind "entity"
    name "SET FORTH"
    community 6
  ]
  node [
    id 1879
    label "U:Novel-4128_00086#4"
    kind "unit"
    chunk_id "Novel-4128_00086"
    text "Bleeding behind using leeches will cure a person who is ill."
    community 6
  ]
  node [
    id 1880
    label "E:BLEEDING BEHIND"
    kind "entity"
    name "BLEEDING BEHIND"
    community 6
  ]
  node [
    id 1881
    label "E:LEECHES"
    kind "entity"
    name "LEECHES"
    community 6
  ]
  node [
    id 1882
    label "E:CURE"
    kind "entity"
    name "CURE"
    community 6
  ]
  node [
    id 1883
    label "U:Novel-4128_00086#5"
    kind "unit"
    chunk_id "Novel-4128_00086"
    text "Chewing tobacco caused a person to become very fat and sallow."
    community 6
  ]
  node [
    id 1884
    label "E:TOBACCO"
    kind "entity"
    name "TOBACCO"
    community 6
  ]
  node [
    id 1885
    label "E:FAT"
    kind "entity"
    name "FAT"
    community 6
  ]
  node [
    id 1886
    label "E:SALOW"
    kind "entity"
    name "SALOW"
    community 6
  ]
  node [
    id 1887
    label "U:Novel-4128_00086#6"
    kind "unit"
    chunk_id "Novel-4128_00086"
    text "The speaker could not recall their business."
    community 2
  ]
  node [
    id 1888
    label "U:Novel-4128_00086#7"
    kind "unit"
    chunk_id "Novel-4128_00086"
    text "The speaker dared not take notice of a woman because her husband was present."
    community 5
  ]
  node [
    id 1889
    label "U:Novel-4128_00086#8"
    kind "unit"
    chunk_id "Novel-4128_00086"
    text "A person wore a white coat made from one of the speaker's wife's pettycoats."
    community 9
  ]
  node [
    id 1890
    label "E:PETTYCOAT"
    kind "entity"
    name "PETTYCOAT"
    community 9
  ]
  node [
    id 1891
    label "U:Novel-4128_00086#9"
    kind "unit"
    chunk_id "Novel-4128_00086"
    text "The family was in mourning and showed the greatest honour to a deceased person."
    community 11
  ]
  node [
    id 1892
    label "E:DECEASED PERSON"
    kind "entity"
    name "DECEASED PERSON"
    community 11
  ]
  node [
    id 1893
    label "U:Novel-4128_00086#10"
    kind "unit"
    chunk_id "Novel-4128_00086"
    text "The speaker feared they would not be able to wipe their hands of a person again."
    community 4
  ]
  node [
    id 1894
    label "U:Novel-4128_00086#11"
    kind "unit"
    chunk_id "Novel-4128_00086"
    text "The speaker found their wife not sick, but still out of order."
    community 2
  ]
  node [
    id 1895
    label "U:Novel-4128_00086#12"
    kind "unit"
    chunk_id "Novel-4128_00086"
    text "The speaker found their brother John not as ill as they had thought, despite believing he had been ill."
    community 18
  ]
  node [
    id 1896
    label "E:ILL"
    kind "entity"
    name "ILL"
    community 18
  ]
  node [
    id 1897
    label "U:Novel-4128_00086#13"
    kind "unit"
    chunk_id "Novel-4128_00086"
    text "The speaker found their brother John at eight o'clock in bed, which annoyed them."
    community 18
  ]
  node [
    id 1898
    label "E:VEEXED"
    kind "entity"
    name "VEEXED"
    community 18
  ]
  node [
    id 1899
    label "U:Novel-4128_00086#14"
    kind "unit"
    chunk_id "Novel-4128_00086"
    text "The speaker expressed shock at how ignorant people praised a woman for something."
    community 7
  ]
  node [
    id 1900
    label "E:PRAYED"
    kind "entity"
    name "PRAYED"
    community 7
  ]
  node [
    id 1901
    label "C:Novel-4128_00087"
    kind "chunk"
    chunk_id "Novel-4128_00087"
  ]
  node [
    id 1902
    label "U:Novel-4128_00087#0"
    kind "unit"
    chunk_id "Novel-4128_00087"
    text "Samuel Pepys expressed frustration that ignorant people cried up a certain person for something, and noted that he was greedy to see a will but did not ask to see it until the next day."
    community 1
  ]
  node [
    id 1903
    label "E:SAMUEL PEPSY"
    kind "entity"
    name "SAMUEL PEPSY"
    community 1
  ]
  node [
    id 1904
    label "U:Novel-4128_00087#1"
    kind "unit"
    chunk_id "Novel-4128_00087"
    text "Samuel Pepys found his company ever wearying and mentioned that he broke wind, which brought him some ease."
    community 1
  ]
  node [
    id 1905
    label "E:EASE"
    kind "entity"
    name "EASE"
    community 1
  ]
  node [
    id 1906
    label "E:WEARYING"
    kind "entity"
    name "WEARYING"
    community 1
  ]
  node [
    id 1907
    label "U:Novel-4128_00087#2"
    kind "unit"
    chunk_id "Novel-4128_00087"
    text "Samuel Pepys wished he could have stolen a pretty dog that followed him."
    community 1
  ]
  node [
    id 1908
    label "U:Novel-4128_00087#3"
    kind "unit"
    chunk_id "Novel-4128_00087"
    text "King, Duke, Duchess, and Madame Palmer were present, and Samuel Pepys remarked that Lady Batten was such a man's whore."
    community 16
  ]
  node [
    id 1909
    label "U:Novel-4128_00087#4"
    kind "unit"
    chunk_id "Novel-4128_00087"
    text "Samuel Pepys recently became overly interested in plays and spending money."
    community 1
  ]
  node [
    id 1910
    label "U:Novel-4128_00087#5"
    kind "unit"
    chunk_id "Novel-4128_00087"
    text "Samuel Pepys looked askew at his wife because she did not conform to the expectations of the court figures."
    community 1
  ]
  node [
    id 1911
    label "E:COURT FIGURES"
    kind "entity"
    name "COURT FIGURES"
    community 1
  ]
  node [
    id 1912
    label "U:Novel-4128_00087#6"
    kind "unit"
    chunk_id "Novel-4128_00087"
    text "No one would sell anything to Samuel Pepys without his personal security being given."
    community 1
  ]
  node [
    id 1913
    label "E:SELLING"
    kind "entity"
    name "SELLING"
    community 1
  ]
  node [
    id 1914
    label "U:Novel-4128_00087#7"
    kind "unit"
    chunk_id "Novel-4128_00087"
    text "Quakers continue to exist and are growing rather than decreasing."
    community 5
  ]
  node [
    id 1915
    label "E:GROWING"
    kind "entity"
    name "GROWING"
    community 5
  ]
  node [
    id 1916
    label "U:Novel-4128_00087#8"
    kind "unit"
    chunk_id "Novel-4128_00087"
    text "Samuel Pepys sat before Mrs. Palmer, the King's mistress, and was filled with impressions."
    community 1
  ]
  node [
    id 1917
    label "U:Novel-4128_00087#9"
    kind "unit"
    chunk_id "Novel-4128_00087"
    text "The children and Samuel Pepys rose and dined by themselves."
    community 1
  ]
  node [
    id 1918
    label "E:DINING"
    kind "entity"
    name "DINING"
    community 1
  ]
  node [
    id 1919
    label "U:Novel-4128_00087#10"
    kind "unit"
    chunk_id "Novel-4128_00087"
    text "Samuel Pepys felt sorry in some respects but glad in others due to his expectations."
    community 1
  ]
  node [
    id 1920
    label "E:SORRY"
    kind "entity"
    name "SORRY"
    community 1
  ]
  node [
    id 1921
    label "U:Novel-4128_00087#11"
    kind "unit"
    chunk_id "Novel-4128_00087"
    text "The Alchymist, a comedy by Ben Jonson, was mentioned."
    community 14
  ]
  node [
    id 1922
    label "E:COMEDY"
    kind "entity"
    name "COMEDY"
    community 14
  ]
  node [
    id 1923
    label "U:Novel-4128_00087#12"
    kind "unit"
    chunk_id "Novel-4128_00087"
    text "The Lords taxed themselves for the poor, with an earl being specifically mentioned."
    community 5
  ]
  node [
    id 1924
    label "E:TAXING"
    kind "entity"
    name "TAXING"
    community 5
  ]
  node [
    id 1925
    label "U:Novel-4128_00087#13"
    kind "unit"
    chunk_id "Novel-4128_00087"
    text "Samuel Pepys made a vow to himself to drink no wine during the week."
    community 16
  ]
  node [
    id 1926
    label "U:Novel-4128_00087#14"
    kind "unit"
    chunk_id "Novel-4128_00087"
    text "Those absent from prayers were required to pay a forfeit."
    community 5
  ]
  node [
    id 1927
    label "E:PRAYERS"
    kind "entity"
    name "PRAYERS"
    community 5
  ]
  node [
    id 1928
    label "E:ABSENT PERSONS"
    kind "entity"
    name "ABSENT PERSONS"
    community 5
  ]
  node [
    id 1929
    label "U:Novel-4128_00087#15"
    kind "unit"
    chunk_id "Novel-4128_00087"
    text "Samuel Pepys was so much in love with plays that he was described as being in love with them."
    community 1
  ]
  node [
    id 1930
    label "E:LOVE"
    kind "entity"
    name "LOVE"
    community 1
  ]
  node [
    id 1931
    label "U:Novel-4128_00087#16"
    kind "unit"
    chunk_id "Novel-4128_00087"
    text "A woman with a rod in her hand was keeping time to the musique."
    community 20
  ]
  node [
    id 1932
    label "E:ROD"
    kind "entity"
    name "ROD"
    community 20
  ]
  node [
    id 1933
    label "H:0"
    kind "community"
    community 0
    parent 4
    n_units 18
    n_entities 76
    top_entities "WESTMINSTER | CHILDREN | 16TH | FEVER | MR. | WHITE HALL | FALCONER OF WOOLWICH | 19TH | MY LADY SANDWICH | MAID"
  ]
  node [
    id 1934
    label "H:1"
    kind "community"
    community 1
    parent 25
    n_units 16
    n_entities 52
    top_entities "MY LADY | SAMUEL PEPSY | PLAYS | SUPPER | MRS. PALMER | ROBERT PEPYS | PRETTY DOG | BAUBLE | MRS. CRISPE | PERSONAL SECURITY"
  ]
  node [
    id 1935
    label "H:2"
    kind "community"
    community 2
    parent 9
    n_units 14
    n_entities 91
    top_entities "AUNT | BED | AFTERNOON | BUSINESS | DAY | BEAVER | OLD WILLIAM LUFFE | COUSIN THOMAS PEPYS | OUT OF ORDER | L20"
  ]
  node [
    id 1936
    label "H:3"
    kind "community"
    community 3
    parent 3
    n_units 14
    n_entities 83
    top_entities "UNCLE WIGHT | PALL | UNCLE ROBERT | COUNTRY | LADY BATTEN | UNCLE THOMAS | MILLS | 26TH | MY FATHER | JANE"
  ]
  node [
    id 1937
    label "H:4"
    kind "community"
    community 4
    parent 0
    n_units 14
    n_entities 96
    top_entities "MOTHER | FATHER'S HOUSE | TOM TRICE | UNCLE'S WILL | NARRATOR'S FATHER | LADIES | MR. LOOKER | NARRATOR AND DR. WILLIAMS | MONEY | US"
  ]
  node [
    id 1938
    label "H:5"
    kind "community"
    community 5
    parent 22
    n_units 12
    n_entities 105
    top_entities "LONDON | HUNTINGDON | GENERAL FAST | HUSBAND | RAIN | HIS LORD | MR. SHEPLEY WALDEN | MRS. WHATELY | LORDS | HATFIELD"
  ]
  node [
    id 1939
    label "H:6"
    kind "community"
    community 6
    parent 17
    n_units 12
    n_entities 61
    top_entities "COURT | COMPTROLLER | SIR R. FORD | SIR R. FORD'S HOUSE | BILLS | BABOON | L200 PER ANNUM | BENEVOLENCE | SEASON | CLERGY"
  ]
  node [
    id 1940
    label "H:7"
    kind "community"
    community 7
    parent 7
    n_units 12
    n_entities 69
    top_entities "SHIPS | NIGHT | IGNORANT PEOPLE | WEATHER | MR. EDWARD MONTAGU | GREENWICH | WASTECOAT | 6TH | 7TH | VERY HOT"
  ]
  node [
    id 1941
    label "H:8"
    kind "community"
    community 8
    parent 2
    n_units 11
    n_entities 92
    top_entities "SAMUEL PEPYS | CAMBRIDGE | DEPTFORD | VENISON PASTY | FELLMONGER | MAN | SINGING | SIR WILLIAMS | EXPENSE | WOOLWICH"
  ]
  node [
    id 1942
    label "H:9"
    kind "community"
    community 9
    parent 1
    n_units 11
    n_entities 92
    top_entities "MY LORD | PERSON | LORD | MR. CREED | SYMONS | L300 | BARTHOLOMEW FAIRE | ALDERMAN BACKWELL | CREED | MR. TOWNSEND"
  ]
  node [
    id 1943
    label "H:10"
    kind "community"
    community 10
    parent 18
    n_units 11
    n_entities 89
    top_entities "I | COACH | CAPTAIN FERRERS | NED PICKERING | VESSEL | HE AND MR. MOORE | HOLCROFT | NARRATOR AND FATHER | QUEEN OF BOHEMIA | DEVIL TAVERN"
  ]
  node [
    id 1944
    label "H:11"
    kind "community"
    community 11
    parent 6
    n_units 11
    n_entities 71
    top_entities "BRAMPTON | WILL | UNCLE | PAPERS | DR. WILLIAMS | MARTIN | 20TH | FAMILY | BOX OF PAPERS | RIBBANDS"
  ]
  node [
    id 1945
    label "H:12"
    kind "community"
    community 12
    parent 10
    n_units 11
    n_entities 60
    top_entities "MR. MOORE | HOME | WHITEHALL | EXCHANGE | NOON | LORD PRIVY SEAL | WESTMINSTER HALL | GREEN SAY | 8TH | WORKMEN"
  ]
  node [
    id 1946
    label "H:13"
    kind "community"
    community 13
    parent 12
    n_units 11
    n_entities 83
    top_entities "BROTHER TOM | ESTATE | 29TH | TOM | TRADE | 30TH | UNCLE FENNER | MITRE | SPEAKER AND HIS FATHER | MONTH"
  ]
  node [
    id 1947
    label "H:14"
    kind "community"
    community 14
    parent 14
    n_units 10
    n_entities 57
    top_entities "LADY | PORTUGAL | LORD CREW | WOMAN | ALCHYMIST | LORD SANDWICH | CAPTAIN ISHAM | ALICANTE | MR. FANSHAW | 22ND JULY LAST"
  ]
  node [
    id 1948
    label "H:15"
    kind "community"
    community 15
    parent 11
    n_units 9
    n_entities 62
    top_entities "DINNER | CHURCH | TOWNSEND | LORD'S DAY | 28TH | TOWNSEND AND HIS WIFE | CAPTAIN ALLEN | MR. HEMPSON | TRADE OF BRIEFS | BATTEN"
  ]
  node [
    id 1949
    label "H:16"
    kind "community"
    community 16
    parent 15
    n_units 9
    n_entities 58
    top_entities "WINE | THEATRE | GROUP | NARRATOR AND HIS WIFE | PLAY | MR. HILL OF CAMBRIDGE | FAYRE BOTELERS | DUCHESS | MIRTH | 11TH"
  ]
  node [
    id 1950
    label "H:17"
    kind "community"
    community 17
    parent 5
    n_units 9
    n_entities 76
    top_entities "SIR W. PEN | SIR W. BATTEN | AUTHOR | OPERA | DUKE OF YORK | DUKE | MR. CHETWIND | 15TH | SCENES | MR. MILLS"
  ]
  node [
    id 1951
    label "H:18"
    kind "community"
    community 18
    parent 8
    n_units 9
    n_entities 67
    top_entities "ROGER PEPYS | TALBOT PEPS | SERMON | BROTHER JOHN | YOUNG MEN | PARSON | SIEGE OF RHODES | BOARD | SIR WILLIAM DAVENANT'S OPERA | TRINITY HALL"
  ]
  node [
    id 1952
    label "H:19"
    kind "community"
    community 19
    parent 16
    n_units 6
    n_entities 55
    top_entities "ALEHOUSE | NARRATOR AND WIFE | FRANCE | TAVERN | 22ND | COMPANY | UNCLE FENNER'S | FRENCH COMEDY | NARRATOR AND LUELLIN | HIS FATHER"
  ]
  node [
    id 1953
    label "H:20"
    kind "community"
    community 20
    parent 21
    n_units 6
    n_entities 38
    top_entities "PRIVY SEAL | MONS. ESCAR | LORD CHANCELLOR | L20000 | MUSIQUE | MY LORD OF SANDWICH | LA BELLE PIERCE | LYON | WARRANT FOR L5000 | MRS. CLIFFORD"
  ]
  node [
    id 1954
    label "H:21"
    kind "community"
    community 21
    parent 13
    n_units 5
    n_entities 63
    top_entities "MY LORD HINCHINGBROKE | PARLIAMENT | FRUIT | MR. TURNER | BURIAL | MR. GEORGE MONTAGU | MY LORD CHANCELLOR | PURSER | 12TH | FUNERAL SERMON"
  ]
  edge [
    source 0
    target 1
    kind "from_chunk"
  ]
  edge [
    source 1
    target 2
    kind "mentions"
  ]
  edge [
    source 1
    target 3
    kind "mentions"
  ]
  edge [
    source 1
    target 4
    kind "mentions"
  ]
  edge [
    source 1
    target 5
    kind "mentions"
  ]
  edge [
    source 1
    target 6
    kind "mentions"
  ]
  edge [
    source 1
    target 7
    kind "mentions"
  ]
  edge [
    source 1
    target 8
    kind "mentions"
  ]
  edge [
    source 1
    target 9
    kind "mentions"
  ]
  edge [
    source 1
    target 10
    kind "mentions"
  ]
  edge [
    source 1
    target 11
    kind "mentions"
  ]
  edge [
    source 1
    target 12
    kind "mentions"
  ]
  edge [
    source 1
    target 13
    kind "mentions"
  ]
  edge [
    source 1
    target 14
    kind "mentions"
  ]
  edge [
    source 1
    target 15
    kind "mentions"
  ]
  edge [
    source 1
    target 16
    kind "mentions"
  ]
  edge [
    source 1
    target 17
    kind "mentions"
  ]
  edge [
    source 1
    target 18
    kind "mentions"
  ]
  edge [
    source 1
    target 19
    kind "mentions"
  ]
  edge [
    source 1
    target 20
    kind "mentions"
  ]
  edge [
    source 1
    target 21
    kind "mentions"
  ]
  edge [
    source 1
    target 1941
    kind "summarizes"
  ]
  edge [
    source 2
    target 3
    kind "relation"
    relation "traveled by water with"
    weight 1
  ]
  edge [
    source 2
    target 4
    kind "relation"
    relation "traveled by water with"
    weight 1
  ]
  edge [
    source 2
    target 5
    kind "relation"
    relation "visited ships to give orders and take notice of their readiness to sail | returned by water"
    weight 2
  ]
  edge [
    source 2
    target 6
    kind "relation"
    relation "performed similar actions at"
    weight 1
  ]
  edge [
    source 2
    target 8
    kind "relation"
    relation "dined with"
    weight 1
  ]
  edge [
    source 2
    target 7
    kind "relation"
    relation "walked to"
    weight 1
  ]
  edge [
    source 2
    target 19
    kind "relation"
    relation "conducted office business including"
    weight 1
  ]
  edge [
    source 2
    target 20
    kind "relation"
    relation "secured imprest of"
    weight 1
  ]
  edge [
    source 2
    target 700
    kind "mentions"
  ]
  edge [
    source 2
    target 702
    kind "relation"
    relation "bought"
    weight 1
  ]
  edge [
    source 2
    target 703
    kind "relation"
    relation "bought"
    weight 1
  ]
  edge [
    source 2
    target 589
    kind "relation"
    relation "dined with"
    weight 1
  ]
  edge [
    source 2
    target 591
    kind "relation"
    relation "attended"
    weight 1
  ]
  edge [
    source 2
    target 68
    kind "relation"
    relation "went to | worked at"
    weight 2
  ]
  edge [
    source 2
    target 701
    kind "relation"
    relation "went to"
    weight 1
  ]
  edge [
    source 2
    target 707
    kind "mentions"
  ]
  edge [
    source 2
    target 711
    kind "relation"
    relation "has been under | hopes to recover"
    weight 2
  ]
  edge [
    source 2
    target 714
    kind "relation"
    relation "will prepare items for"
    weight 1
  ]
  edge [
    source 2
    target 693
    kind "relation"
    relation "will send items to"
    weight 1
  ]
  edge [
    source 2
    target 709
    kind "relation"
    relation "is prone to"
    weight 1
  ]
  edge [
    source 2
    target 715
    kind "relation"
    relation "wears a cloth over"
    weight 1
  ]
  edge [
    source 2
    target 1181
    kind "mentions"
  ]
  edge [
    source 2
    target 603
    kind "relation"
    relation "traveled with"
    weight 1
  ]
  edge [
    source 2
    target 1182
    kind "relation"
    relation "traveled with"
    weight 1
  ]
  edge [
    source 2
    target 1183
    kind "relation"
    relation "traveled with"
    weight 1
  ]
  edge [
    source 2
    target 1185
    kind "relation"
    relation "gave"
    weight 1
  ]
  edge [
    source 2
    target 777
    kind "relation"
    relation "ate"
    weight 1
  ]
  edge [
    source 2
    target 1191
    kind "relation"
    relation "attempted to reconcile"
    weight 1
  ]
  edge [
    source 2
    target 1192
    kind "relation"
    relation "believes"
    weight 1
  ]
  edge [
    source 2
    target 1188
    kind "relation"
    relation "rode to"
    weight 2
  ]
  edge [
    source 2
    target 1189
    kind "relation"
    relation "discussed with | had discourse with"
    weight 2
  ]
  edge [
    source 2
    target 1196
    kind "mentions"
  ]
  edge [
    source 2
    target 1198
    kind "relation"
    relation "dined with"
    weight 1
  ]
  edge [
    source 2
    target 597
    kind "relation"
    relation "had visit from"
    weight 1
  ]
  edge [
    source 2
    target 11
    kind "relation"
    relation "prepared to ride to"
    weight 1
  ]
  edge [
    source 3
    target 141
    kind "mentions"
  ]
  edge [
    source 3
    target 59
    kind "relation"
    relation "went home with | talked with | sang with | went to"
    weight 4
  ]
  edge [
    source 3
    target 146
    kind "relation"
    relation "played bowls at"
    weight 1
  ]
  edge [
    source 3
    target 83
    kind "relation"
    relation "came out in his shirt"
    weight 1
  ]
  edge [
    source 3
    target 471
    kind "mentions"
  ]
  edge [
    source 3
    target 547
    kind "mentions"
  ]
  edge [
    source 3
    target 33
    kind "relation"
    relation "was a guest at"
    weight 1
  ]
  edge [
    source 3
    target 640
    kind "mentions"
  ]
  edge [
    source 3
    target 28
    kind "relation"
    relation "went with | made visits to | came home with | drank with | went to the dolphin with | forged a letter to"
    weight 8
  ]
  edge [
    source 3
    target 647
    kind "relation"
    relation "examined into | and i were satisfied with"
    weight 2
  ]
  edge [
    source 3
    target 659
    kind "mentions"
  ]
  edge [
    source 3
    target 987
    kind "mentions"
  ]
  edge [
    source 3
    target 1118
    kind "mentions"
  ]
  edge [
    source 3
    target 1125
    kind "relation"
    relation "went away"
    weight 1
  ]
  edge [
    source 3
    target 84
    kind "relation"
    relation "followed"
    weight 1
  ]
  edge [
    source 3
    target 1415
    kind "mentions"
  ]
  edge [
    source 3
    target 307
    kind "relation"
    relation "waited upon"
    weight 1
  ]
  edge [
    source 3
    target 1419
    kind "relation"
    relation "took captain ferrers to | set captain ferrers down at | carried"
    weight 3
  ]
  edge [
    source 3
    target 1429
    kind "relation"
    relation "carried the narrator home"
    weight 1
  ]
  edge [
    source 3
    target 1436
    kind "mentions"
  ]
  edge [
    source 3
    target 436
    kind "relation"
    relation "took"
    weight 1
  ]
  edge [
    source 3
    target 1444
    kind "relation"
    relation "was overtaken by | followed"
    weight 2
  ]
  edge [
    source 3
    target 620
    kind "relation"
    relation "had been with"
    weight 1
  ]
  edge [
    source 3
    target 1752
    kind "mentions"
  ]
  edge [
    source 3
    target 1757
    kind "relation"
    relation "was intended to mock"
    weight 1
  ]
  edge [
    source 5
    target 403
    kind "mentions"
  ]
  edge [
    source 5
    target 28
    kind "relation"
    relation "went ashore at"
    weight 1
  ]
  edge [
    source 5
    target 1436
    kind "mentions"
  ]
  edge [
    source 6
    target 391
    kind "mentions"
  ]
  edge [
    source 6
    target 61
    kind "relation"
    relation "traveled by barge to"
    weight 1
  ]
  edge [
    source 6
    target 640
    kind "mentions"
  ]
  edge [
    source 6
    target 659
    kind "mentions"
  ]
  edge [
    source 6
    target 28
    kind "relation"
    relation "went to"
    weight 1
  ]
  edge [
    source 6
    target 1314
    kind "mentions"
  ]
  edge [
    source 7
    target 15
    kind "relation"
    relation "had an abundance of"
    weight 1
  ]
  edge [
    source 8
    target 403
    kind "mentions"
  ]
  edge [
    source 8
    target 28
    kind "relation"
    relation "went ashore with"
    weight 1
  ]
  edge [
    source 11
    target 861
    kind "mentions"
  ]
  edge [
    source 11
    target 28
    kind "relation"
    relation "rode to | arrived in"
    weight 2
  ]
  edge [
    source 11
    target 890
    kind "mentions"
  ]
  edge [
    source 11
    target 1161
    kind "mentions"
  ]
  edge [
    source 11
    target 1181
    kind "mentions"
  ]
  edge [
    source 11
    target 1196
    kind "mentions"
  ]
  edge [
    source 11
    target 1200
    kind "mentions"
  ]
  edge [
    source 13
    target 21
    kind "relation"
    relation "had bills signed for"
    weight 1
  ]
  edge [
    source 13
    target 56
    kind "mentions"
  ]
  edge [
    source 13
    target 59
    kind "relation"
    relation "returns home with"
    weight 1
  ]
  edge [
    source 13
    target 79
    kind "mentions"
  ]
  edge [
    source 13
    target 28
    kind "relation"
    relation "takes | sent a letter to"
    weight 2
  ]
  edge [
    source 13
    target 198
    kind "mentions"
  ]
  edge [
    source 13
    target 196
    kind "relation"
    relation "dined with | met"
    weight 2
  ]
  edge [
    source 13
    target 366
    kind "mentions"
  ]
  edge [
    source 13
    target 379
    kind "mentions"
  ]
  edge [
    source 13
    target 45
    kind "relation"
    relation "ordered"
    weight 1
  ]
  edge [
    source 13
    target 369
    kind "relation"
    relation "was to imprest"
    weight 1
  ]
  edge [
    source 13
    target 285
    kind "relation"
    relation "was to be paid by"
    weight 1
  ]
  edge [
    source 13
    target 1415
    kind "mentions"
  ]
  edge [
    source 13
    target 1431
    kind "relation"
    relation "informed the narrator that"
    weight 1
  ]
  edge [
    source 18
    target 23
    kind "mentions"
  ]
  edge [
    source 22
    target 23
    kind "from_chunk"
  ]
  edge [
    source 23
    target 24
    kind "mentions"
  ]
  edge [
    source 23
    target 25
    kind "mentions"
  ]
  edge [
    source 23
    target 26
    kind "mentions"
  ]
  edge [
    source 23
    target 27
    kind "mentions"
  ]
  edge [
    source 23
    target 28
    kind "mentions"
  ]
  edge [
    source 23
    target 29
    kind "mentions"
  ]
  edge [
    source 23
    target 30
    kind "mentions"
  ]
  edge [
    source 23
    target 31
    kind "mentions"
  ]
  edge [
    source 23
    target 32
    kind "mentions"
  ]
  edge [
    source 23
    target 33
    kind "mentions"
  ]
  edge [
    source 23
    target 34
    kind "mentions"
  ]
  edge [
    source 23
    target 35
    kind "mentions"
  ]
  edge [
    source 23
    target 36
    kind "mentions"
  ]
  edge [
    source 23
    target 37
    kind "mentions"
  ]
  edge [
    source 23
    target 38
    kind "mentions"
  ]
  edge [
    source 23
    target 39
    kind "mentions"
  ]
  edge [
    source 23
    target 40
    kind "mentions"
  ]
  edge [
    source 23
    target 41
    kind "mentions"
  ]
  edge [
    source 23
    target 42
    kind "mentions"
  ]
  edge [
    source 23
    target 43
    kind "mentions"
  ]
  edge [
    source 23
    target 44
    kind "mentions"
  ]
  edge [
    source 23
    target 45
    kind "mentions"
  ]
  edge [
    source 23
    target 46
    kind "mentions"
  ]
  edge [
    source 23
    target 47
    kind "mentions"
  ]
  edge [
    source 23
    target 48
    kind "mentions"
  ]
  edge [
    source 23
    target 49
    kind "mentions"
  ]
  edge [
    source 23
    target 50
    kind "mentions"
  ]
  edge [
    source 23
    target 51
    kind "mentions"
  ]
  edge [
    source 23
    target 52
    kind "mentions"
  ]
  edge [
    source 23
    target 53
    kind "mentions"
  ]
  edge [
    source 23
    target 54
    kind "mentions"
  ]
  edge [
    source 23
    target 1938
    kind "summarizes"
  ]
  edge [
    source 24
    target 25
    kind "relation"
    relation "signed bills against"
    weight 1
  ]
  edge [
    source 26
    target 28
    kind "relation"
    relation "wrote letters"
    weight 1
  ]
  edge [
    source 27
    target 28
    kind "relation"
    relation "read things"
    weight 1
  ]
  edge [
    source 28
    target 48
    kind "relation"
    relation "went to bed"
    weight 1
  ]
  edge [
    source 28
    target 49
    kind "relation"
    relation "went to church"
    weight 1
  ]
  edge [
    source 28
    target 50
    kind "relation"
    relation "had dinner | returned home"
    weight 2
  ]
  edge [
    source 28
    target 51
    kind "relation"
    relation "went to church again"
    weight 1
  ]
  edge [
    source 28
    target 52
    kind "relation"
    relation "found greatorex"
    weight 1
  ]
  edge [
    source 28
    target 34
    kind "relation"
    relation "spent time with | discussed mathematics with | stayed longer than"
    weight 3
  ]
  edge [
    source 28
    target 54
    kind "relation"
    relation "went to the wardrobe"
    weight 1
  ]
  edge [
    source 28
    target 79
    kind "mentions"
  ]
  edge [
    source 28
    target 68
    kind "relation"
    relation "is called to | stays a little at | went to | sat at | stayed at | worked at | went to the office | went home by water | was a great pleasure to | involved talking with persons of quality | involved being in command | sat down and did business | returned to | was at"
    weight 21
  ]
  edge [
    source 28
    target 80
    kind "relation"
    relation "goes to | walks round"
    weight 2
  ]
  edge [
    source 28
    target 81
    kind "relation"
    relation "speaks about"
    weight 1
  ]
  edge [
    source 28
    target 82
    kind "relation"
    relation "returns to | went to bed | walked up and down | dined at | took coach again to | returned to"
    weight 6
  ]
  edge [
    source 28
    target 84
    kind "relation"
    relation "walks with | goes to bed with | gave | told | found | met | took"
    weight 10
  ]
  edge [
    source 28
    target 86
    kind "mentions"
  ]
  edge [
    source 28
    target 88
    kind "relation"
    relation "goes to"
    weight 1
  ]
  edge [
    source 28
    target 89
    kind "relation"
    relation "intends to meet"
    weight 1
  ]
  edge [
    source 28
    target 90
    kind "relation"
    relation "intends to meet"
    weight 1
  ]
  edge [
    source 28
    target 44
    kind "relation"
    relation "goes to | went to | met at"
    weight 9
  ]
  edge [
    source 28
    target 95
    kind "mentions"
  ]
  edge [
    source 28
    target 96
    kind "relation"
    relation "invites | visited sir w. batten with"
    weight 2
  ]
  edge [
    source 28
    target 97
    kind "relation"
    relation "does not appeal to"
    weight 1
  ]
  edge [
    source 28
    target 101
    kind "relation"
    relation "goes by water to | was landed at"
    weight 2
  ]
  edge [
    source 28
    target 102
    kind "relation"
    relation "walks over"
    weight 1
  ]
  edge [
    source 28
    target 103
    kind "relation"
    relation "goes to"
    weight 1
  ]
  edge [
    source 28
    target 104
    kind "relation"
    relation "goes to | went home to | went to | took coach to | was at"
    weight 8
  ]
  edge [
    source 28
    target 105
    kind "relation"
    relation "meets"
    weight 1
  ]
  edge [
    source 28
    target 110
    kind "mentions"
  ]
  edge [
    source 28
    target 111
    kind "relation"
    relation "gave wine to"
    weight 1
  ]
  edge [
    source 28
    target 116
    kind "relation"
    relation "had dinner with"
    weight 1
  ]
  edge [
    source 28
    target 122
    kind "relation"
    relation "was visited by | went to"
    weight 5
  ]
  edge [
    source 28
    target 123
    kind "relation"
    relation "saw"
    weight 1
  ]
  edge [
    source 28
    target 124
    kind "relation"
    relation "crossed the water | walked over fields to | returned home"
    weight 3
  ]
  edge [
    source 28
    target 125
    kind "relation"
    relation "played"
    weight 1
  ]
  edge [
    source 28
    target 135
    kind "relation"
    relation "went to bed | returned home and to bed | drank until | took horse"
    weight 5
  ]
  edge [
    source 28
    target 137
    kind "mentions"
  ]
  edge [
    source 28
    target 161
    kind "mentions"
  ]
  edge [
    source 28
    target 179
    kind "relation"
    relation "had aching head due to"
    weight 2
  ]
  edge [
    source 28
    target 165
    kind "relation"
    relation "traveled by water to | reached"
    weight 3
  ]
  edge [
    source 28
    target 182
    kind "relation"
    relation "observed and discussed"
    weight 2
  ]
  edge [
    source 28
    target 166
    kind "relation"
    relation "ate and drank at"
    weight 2
  ]
  edge [
    source 28
    target 183
    kind "relation"
    relation "saw"
    weight 2
  ]
  edge [
    source 28
    target 170
    kind "relation"
    relation "and captain lambert went to | stayed and supped at"
    weight 4
  ]
  edge [
    source 28
    target 172
    kind "relation"
    relation "paid"
    weight 2
  ]
  edge [
    source 28
    target 173
    kind "relation"
    relation "was merry with"
    weight 2
  ]
  edge [
    source 28
    target 175
    kind "relation"
    relation "left off"
    weight 2
  ]
  edge [
    source 28
    target 189
    kind "mentions"
  ]
  edge [
    source 28
    target 214
    kind "mentions"
  ]
  edge [
    source 28
    target 216
    kind "relation"
    relation "offered a land purchase to | told father to speak to | visited his father and heard that"
    weight 3
  ]
  edge [
    source 28
    target 223
    kind "relation"
    relation "is glad about"
    weight 1
  ]
  edge [
    source 28
    target 224
    kind "relation"
    relation "agrees to"
    weight 1
  ]
  edge [
    source 28
    target 225
    kind "mentions"
  ]
  edge [
    source 28
    target 229
    kind "relation"
    relation "left wife at"
    weight 1
  ]
  edge [
    source 28
    target 62
    kind "relation"
    relation "walked to | went to | traveled by water to | traveled up and down"
    weight 9
  ]
  edge [
    source 28
    target 231
    kind "relation"
    relation "sat with"
    weight 1
  ]
  edge [
    source 28
    target 293
    kind "mentions"
  ]
  edge [
    source 28
    target 294
    kind "relation"
    relation "stayed and dined with | dined with | attended to | went to tell | supped with | saw"
    weight 9
  ]
  edge [
    source 28
    target 295
    kind "relation"
    relation "dined by themselves with | were fond of | went with"
    weight 3
  ]
  edge [
    source 28
    target 303
    kind "relation"
    relation "lived in"
    weight 1
  ]
  edge [
    source 28
    target 296
    kind "relation"
    relation "laid in"
    weight 1
  ]
  edge [
    source 28
    target 305
    kind "mentions"
  ]
  edge [
    source 28
    target 306
    kind "relation"
    relation "was with | went out to see if | did not send"
    weight 3
  ]
  edge [
    source 28
    target 307
    kind "relation"
    relation "agreed to write a letter to | waited upon"
    weight 2
  ]
  edge [
    source 28
    target 310
    kind "relation"
    relation "agreed to give"
    weight 1
  ]
  edge [
    source 28
    target 315
    kind "mentions"
  ]
  edge [
    source 28
    target 316
    kind "relation"
    relation "was abroad about"
    weight 1
  ]
  edge [
    source 28
    target 85
    kind "relation"
    relation "returned home and went to"
    weight 2
  ]
  edge [
    source 28
    target 356
    kind "mentions"
  ]
  edge [
    source 28
    target 357
    kind "relation"
    relation "met"
    weight 1
  ]
  edge [
    source 28
    target 358
    kind "relation"
    relation "met"
    weight 1
  ]
  edge [
    source 28
    target 359
    kind "relation"
    relation "went to"
    weight 1
  ]
  edge [
    source 28
    target 360
    kind "relation"
    relation "drank their morning draft at | stayed at | was merry at"
    weight 3
  ]
  edge [
    source 28
    target 363
    kind "relation"
    relation "found | was going down the river"
    weight 2
  ]
  edge [
    source 28
    target 364
    kind "relation"
    relation "went into"
    weight 1
  ]
  edge [
    source 28
    target 366
    kind "mentions"
  ]
  edge [
    source 28
    target 45
    kind "relation"
    relation "instructed | met | stayed with | wrote to | organized papers from | wrote letters to"
    weight 6
  ]
  edge [
    source 28
    target 368
    kind "relation"
    relation "wrote a letter to"
    weight 1
  ]
  edge [
    source 28
    target 376
    kind "relation"
    relation "was glad about"
    weight 1
  ]
  edge [
    source 28
    target 240
    kind "relation"
    relation "visited | went to"
    weight 3
  ]
  edge [
    source 28
    target 145
    kind "relation"
    relation "went to | went with"
    weight 2
  ]
  edge [
    source 28
    target 58
    kind "relation"
    relation "went to bed with | walked and met | met | met with | found | parted with | told | informed | stayed with | learned from | leads"
    weight 13
  ]
  edge [
    source 28
    target 379
    kind "mentions"
  ]
  edge [
    source 28
    target 388
    kind "relation"
    relation "went to | went home"
    weight 2
  ]
  edge [
    source 28
    target 285
    kind "relation"
    relation "had servants not up"
    weight 1
  ]
  edge [
    source 28
    target 382
    kind "relation"
    relation "put on | first wore"
    weight 2
  ]
  edge [
    source 28
    target 383
    kind "relation"
    relation "wore"
    weight 1
  ]
  edge [
    source 28
    target 385
    kind "relation"
    relation "dressed in"
    weight 1
  ]
  edge [
    source 28
    target 374
    kind "relation"
    relation "spoke with"
    weight 1
  ]
  edge [
    source 28
    target 389
    kind "relation"
    relation "was pleased by"
    weight 1
  ]
  edge [
    source 28
    target 403
    kind "mentions"
  ]
  edge [
    source 28
    target 404
    kind "relation"
    relation "left"
    weight 1
  ]
  edge [
    source 28
    target 405
    kind "relation"
    relation "hoped to be in"
    weight 1
  ]
  edge [
    source 28
    target 330
    kind "relation"
    relation "traveled toward | rode to | took horse for | reached"
    weight 4
  ]
  edge [
    source 28
    target 413
    kind "relation"
    relation "pulled off stockings and bathed legs in"
    weight 1
  ]
  edge [
    source 28
    target 414
    kind "relation"
    relation "had not done this in"
    weight 1
  ]
  edge [
    source 28
    target 406
    kind "relation"
    relation "intended to board | passed by"
    weight 2
  ]
  edge [
    source 28
    target 407
    kind "relation"
    relation "went ashore with"
    weight 1
  ]
  edge [
    source 28
    target 408
    kind "relation"
    relation "went to"
    weight 1
  ]
  edge [
    source 28
    target 35
    kind "relation"
    relation "drank a great deal of | consumed fully | called for | broke vow against will"
    weight 4
  ]
  edge [
    source 28
    target 409
    kind "relation"
    relation "drank a great deal of"
    weight 1
  ]
  edge [
    source 28
    target 417
    kind "relation"
    relation "returned to"
    weight 1
  ]
  edge [
    source 28
    target 397
    kind "relation"
    relation "returned to"
    weight 1
  ]
  edge [
    source 28
    target 412
    kind "relation"
    relation "fell asleep until nearly reaching"
    weight 1
  ]
  edge [
    source 28
    target 419
    kind "relation"
    relation "parted from | met"
    weight 2
  ]
  edge [
    source 28
    target 420
    kind "relation"
    relation "returned home and drank enough wine to be drunk"
    weight 1
  ]
  edge [
    source 28
    target 421
    kind "relation"
    relation "found | went to westminster to discuss business with"
    weight 3
  ]
  edge [
    source 28
    target 422
    kind "relation"
    relation "found"
    weight 2
  ]
  edge [
    source 28
    target 423
    kind "relation"
    relation "sent to house by lord's order"
    weight 2
  ]
  edge [
    source 28
    target 424
    kind "relation"
    relation "sent to house by lord's order"
    weight 2
  ]
  edge [
    source 28
    target 425
    kind "mentions"
  ]
  edge [
    source 28
    target 428
    kind "mentions"
  ]
  edge [
    source 28
    target 430
    kind "relation"
    relation "got a great cold from"
    weight 1
  ]
  edge [
    source 28
    target 429
    kind "relation"
    relation "experienced great pain due to"
    weight 1
  ]
  edge [
    source 28
    target 431
    kind "relation"
    relation "traveled by"
    weight 1
  ]
  edge [
    source 28
    target 433
    kind "relation"
    relation "broke wind after"
    weight 1
  ]
  edge [
    source 28
    target 373
    kind "relation"
    relation "ate"
    weight 1
  ]
  edge [
    source 28
    target 434
    kind "mentions"
  ]
  edge [
    source 28
    target 112
    kind "relation"
    relation "drank morning draft with | sat with | told | reconciled with | went to find | accompanied by | wrote to | does not know what to do with | wrote letters to | returned home to | went with | had discourse with | spoke to | troubled | had dinner with | was merry with | went to | had a morning draft with | came to dine with | met | ended the conversation on friendly terms with | has borrowed a great deal to help | has left things in order"
    weight 24
  ]
  edge [
    source 28
    target 435
    kind "relation"
    relation "discussed"
    weight 1
  ]
  edge [
    source 28
    target 369
    kind "relation"
    relation "took home | took"
    weight 2
  ]
  edge [
    source 28
    target 443
    kind "mentions"
  ]
  edge [
    source 28
    target 452
    kind "relation"
    relation "planned to go to bed"
    weight 1
  ]
  edge [
    source 28
    target 453
    kind "relation"
    relation "instructed will to fetch"
    weight 1
  ]
  edge [
    source 28
    target 456
    kind "relation"
    relation "learned that"
    weight 1
  ]
  edge [
    source 28
    target 457
    kind "relation"
    relation "was in great loss about | was in great mental trouble over"
    weight 2
  ]
  edge [
    source 28
    target 458
    kind "relation"
    relation "stayed at home"
    weight 1
  ]
  edge [
    source 28
    target 459
    kind "relation"
    relation "sent will to inquire"
    weight 1
  ]
  edge [
    source 28
    target 460
    kind "relation"
    relation "considered sending by carrier to"
    weight 1
  ]
  edge [
    source 28
    target 461
    kind "relation"
    relation "considered sending by sea via"
    weight 1
  ]
  edge [
    source 28
    target 451
    kind "relation"
    relation "spent afternoon reading | read | was commended much | was considered not very good"
    weight 4
  ]
  edge [
    source 28
    target 462
    kind "mentions"
  ]
  edge [
    source 28
    target 480
    kind "mentions"
  ]
  edge [
    source 28
    target 474
    kind "relation"
    relation "was vexed by | saw stairs finished by"
    weight 3
  ]
  edge [
    source 28
    target 484
    kind "relation"
    relation "were considered the best"
    weight 1
  ]
  edge [
    source 28
    target 485
    kind "relation"
    relation "had musique on"
    weight 1
  ]
  edge [
    source 28
    target 489
    kind "relation"
    relation "met | stayed with | is glad to see"
    weight 3
  ]
  edge [
    source 28
    target 494
    kind "mentions"
  ]
  edge [
    source 28
    target 547
    kind "mentions"
  ]
  edge [
    source 28
    target 557
    kind "relation"
    relation "entertained guests at"
    weight 1
  ]
  edge [
    source 28
    target 572
    kind "mentions"
  ]
  edge [
    source 28
    target 575
    kind "relation"
    relation "went to | dined at"
    weight 2
  ]
  edge [
    source 28
    target 576
    kind "relation"
    relation "had a major argument with"
    weight 1
  ]
  edge [
    source 28
    target 581
    kind "mentions"
  ]
  edge [
    source 28
    target 582
    kind "relation"
    relation "went to | sat at"
    weight 2
  ]
  edge [
    source 28
    target 583
    kind "mentions"
  ]
  edge [
    source 28
    target 586
    kind "relation"
    relation "had previously kept"
    weight 1
  ]
  edge [
    source 28
    target 587
    kind "mentions"
  ]
  edge [
    source 28
    target 588
    kind "relation"
    relation "is the singing master of | began singing lessons with"
    weight 2
  ]
  edge [
    source 28
    target 594
    kind "relation"
    relation "agreed to give"
    weight 1
  ]
  edge [
    source 28
    target 595
    kind "relation"
    relation "agreed to pay"
    weight 1
  ]
  edge [
    source 28
    target 591
    kind "relation"
    relation "hopes to have made progress in | is now the narrator's great trade"
    weight 2
  ]
  edge [
    source 28
    target 596
    kind "mentions"
  ]
  edge [
    source 28
    target 598
    kind "relation"
    relation "reconciled with"
    weight 1
  ]
  edge [
    source 28
    target 602
    kind "mentions"
  ]
  edge [
    source 28
    target 603
    kind "relation"
    relation "sat with | had a gallant collation for"
    weight 2
  ]
  edge [
    source 28
    target 605
    kind "mentions"
  ]
  edge [
    source 28
    target 142
    kind "relation"
    relation "went to | walked to"
    weight 4
  ]
  edge [
    source 28
    target 241
    kind "relation"
    relation "took"
    weight 1
  ]
  edge [
    source 28
    target 612
    kind "relation"
    relation "returned by"
    weight 1
  ]
  edge [
    source 28
    target 486
    kind "relation"
    relation "went home to"
    weight 1
  ]
  edge [
    source 28
    target 613
    kind "mentions"
  ]
  edge [
    source 28
    target 47
    kind "relation"
    relation "went with | met with | took"
    weight 3
  ]
  edge [
    source 28
    target 615
    kind "mentions"
  ]
  edge [
    source 28
    target 616
    kind "relation"
    relation "offered to pay"
    weight 1
  ]
  edge [
    source 28
    target 631
    kind "relation"
    relation "agreed to pay"
    weight 1
  ]
  edge [
    source 28
    target 632
    kind "relation"
    relation "intended to pay"
    weight 1
  ]
  edge [
    source 28
    target 633
    kind "relation"
    relation "has only"
    weight 1
  ]
  edge [
    source 28
    target 620
    kind "relation"
    relation "joined with"
    weight 1
  ]
  edge [
    source 28
    target 621
    kind "relation"
    relation "joined with"
    weight 1
  ]
  edge [
    source 28
    target 622
    kind "relation"
    relation "joined with"
    weight 1
  ]
  edge [
    source 28
    target 634
    kind "relation"
    relation "went with"
    weight 1
  ]
  edge [
    source 28
    target 201
    kind "relation"
    relation "was performed very well"
    weight 1
  ]
  edge [
    source 28
    target 543
    kind "relation"
    relation "stayed at | borrowed from | sat and talked with"
    weight 4
  ]
  edge [
    source 28
    target 640
    kind "mentions"
  ]
  edge [
    source 28
    target 655
    kind "relation"
    relation "practised singing"
    weight 1
  ]
  edge [
    source 28
    target 645
    kind "relation"
    relation "sat until"
    weight 1
  ]
  edge [
    source 28
    target 641
    kind "relation"
    relation "traveled by coach to"
    weight 1
  ]
  edge [
    source 28
    target 646
    kind "relation"
    relation "watched"
    weight 1
  ]
  edge [
    source 28
    target 644
    kind "relation"
    relation "set up bed in | is pleased with"
    weight 2
  ]
  edge [
    source 28
    target 657
    kind "relation"
    relation "returned home"
    weight 2
  ]
  edge [
    source 28
    target 317
    kind "relation"
    relation "stayed at home until | returned to business | went to church"
    weight 4
  ]
  edge [
    source 28
    target 648
    kind "relation"
    relation "walked to"
    weight 2
  ]
  edge [
    source 28
    target 650
    kind "relation"
    relation "came to | stayed and drank with | talked with"
    weight 6
  ]
  edge [
    source 28
    target 651
    kind "relation"
    relation "came to | stayed and drank with | talked with"
    weight 6
  ]
  edge [
    source 28
    target 652
    kind "relation"
    relation "came to | stayed and drank with | talked with"
    weight 6
  ]
  edge [
    source 28
    target 653
    kind "relation"
    relation "came to | stayed and drank with | talked with"
    weight 6
  ]
  edge [
    source 28
    target 658
    kind "relation"
    relation "walked home and to bed"
    weight 2
  ]
  edge [
    source 28
    target 659
    kind "mentions"
  ]
  edge [
    source 28
    target 647
    kind "relation"
    relation "examined into | was satisfied with"
    weight 2
  ]
  edge [
    source 28
    target 717
    kind "mentions"
  ]
  edge [
    source 28
    target 718
    kind "relation"
    relation "spoke with | intended to meet | went with | rode with | is a sober man"
    weight 5
  ]
  edge [
    source 28
    target 736
    kind "relation"
    relation "took a coach to | was attended by"
    weight 2
  ]
  edge [
    source 28
    target 728
    kind "relation"
    relation "waited for"
    weight 1
  ]
  edge [
    source 28
    target 729
    kind "relation"
    relation "waited for"
    weight 1
  ]
  edge [
    source 28
    target 727
    kind "relation"
    relation "was performed | was well acted"
    weight 2
  ]
  edge [
    source 28
    target 735
    kind "relation"
    relation "wrote letters to"
    weight 1
  ]
  edge [
    source 28
    target 740
    kind "mentions"
  ]
  edge [
    source 28
    target 742
    kind "mentions"
  ]
  edge [
    source 28
    target 61
    kind "relation"
    relation "wrote letters to | delayed business | treated the clerks of the privy seal severely"
    weight 3
  ]
  edge [
    source 28
    target 753
    kind "relation"
    relation "went to bed after"
    weight 1
  ]
  edge [
    source 28
    target 192
    kind "relation"
    relation "dined with | visited | showed | gave the greatest favor to | met | was merry and well | prevents the children from coming | found the simplicity and harmlessness of my lady pleasurable | stayed to talk with"
    weight 11
  ]
  edge [
    source 28
    target 745
    kind "relation"
    relation "returned home through"
    weight 1
  ]
  edge [
    source 28
    target 746
    kind "relation"
    relation "looked for"
    weight 1
  ]
  edge [
    source 28
    target 31
    kind "relation"
    relation "sat late talking and disputing with"
    weight 1
  ]
  edge [
    source 28
    target 756
    kind "relation"
    relation "received rings for"
    weight 1
  ]
  edge [
    source 28
    target 752
    kind "relation"
    relation "went to the theatre and saw"
    weight 1
  ]
  edge [
    source 28
    target 766
    kind "mentions"
  ]
  edge [
    source 28
    target 772
    kind "relation"
    relation "tried to remove"
    weight 1
  ]
  edge [
    source 28
    target 774
    kind "relation"
    relation "is resolved not to meddle in"
    weight 1
  ]
  edge [
    source 28
    target 775
    kind "mentions"
  ]
  edge [
    source 28
    target 779
    kind "mentions"
  ]
  edge [
    source 28
    target 780
    kind "relation"
    relation "was woken by | brought"
    weight 2
  ]
  edge [
    source 28
    target 781
    kind "relation"
    relation "felt sorry about | felt glad about"
    weight 2
  ]
  edge [
    source 28
    target 499
    kind "relation"
    relation "went to tell | visited | met"
    weight 3
  ]
  edge [
    source 28
    target 771
    kind "relation"
    relation "bought a pair of boots in"
    weight 1
  ]
  edge [
    source 28
    target 861
    kind "mentions"
  ]
  edge [
    source 28
    target 862
    kind "relation"
    relation "rose at"
    weight 1
  ]
  edge [
    source 28
    target 863
    kind "relation"
    relation "arrived at"
    weight 1
  ]
  edge [
    source 28
    target 864
    kind "relation"
    relation "went to"
    weight 1
  ]
  edge [
    source 28
    target 865
    kind "relation"
    relation "found"
    weight 1
  ]
  edge [
    source 28
    target 866
    kind "relation"
    relation "went to"
    weight 1
  ]
  edge [
    source 28
    target 869
    kind "relation"
    relation "met"
    weight 1
  ]
  edge [
    source 28
    target 870
    kind "relation"
    relation "went to"
    weight 1
  ]
  edge [
    source 28
    target 98
    kind "relation"
    relation "met"
    weight 1
  ]
  edge [
    source 28
    target 871
    kind "relation"
    relation "sent for"
    weight 1
  ]
  edge [
    source 28
    target 886
    kind "relation"
    relation "was merry with"
    weight 1
  ]
  edge [
    source 28
    target 872
    kind "relation"
    relation "sent for"
    weight 1
  ]
  edge [
    source 28
    target 887
    kind "relation"
    relation "was merry with | treated"
    weight 2
  ]
  edge [
    source 28
    target 888
    kind "relation"
    relation "took horse at | met sir w. at | sat until"
    weight 3
  ]
  edge [
    source 28
    target 875
    kind "relation"
    relation "said goodbye to"
    weight 1
  ]
  edge [
    source 28
    target 876
    kind "relation"
    relation "rode to"
    weight 1
  ]
  edge [
    source 28
    target 877
    kind "relation"
    relation "found"
    weight 1
  ]
  edge [
    source 28
    target 934
    kind "mentions"
  ]
  edge [
    source 28
    target 935
    kind "relation"
    relation "discussed money due to"
    weight 1
  ]
  edge [
    source 28
    target 930
    kind "relation"
    relation "stayed with"
    weight 1
  ]
  edge [
    source 28
    target 938
    kind "relation"
    relation "dined with"
    weight 1
  ]
  edge [
    source 28
    target 939
    kind "relation"
    relation "spent afternoon with | went to | stayed with | drank with"
    weight 4
  ]
  edge [
    source 28
    target 940
    kind "relation"
    relation "spent afternoon with"
    weight 1
  ]
  edge [
    source 28
    target 941
    kind "relation"
    relation "spent afternoon with"
    weight 1
  ]
  edge [
    source 28
    target 942
    kind "relation"
    relation "spent afternoon with"
    weight 1
  ]
  edge [
    source 28
    target 943
    kind "relation"
    relation "spent afternoon with"
    weight 1
  ]
  edge [
    source 28
    target 945
    kind "relation"
    relation "sat over against"
    weight 1
  ]
  edge [
    source 28
    target 944
    kind "relation"
    relation "drank ale with"
    weight 1
  ]
  edge [
    source 28
    target 946
    kind "relation"
    relation "was merry until"
    weight 1
  ]
  edge [
    source 28
    target 813
    kind "relation"
    relation "walked home and encountered | went to | had the will probated"
    weight 3
  ]
  edge [
    source 28
    target 947
    kind "relation"
    relation "found | went to"
    weight 2
  ]
  edge [
    source 28
    target 931
    kind "relation"
    relation "met | had calm discourse with"
    weight 2
  ]
  edge [
    source 28
    target 948
    kind "relation"
    relation "met | had calm discourse with"
    weight 3
  ]
  edge [
    source 28
    target 949
    kind "relation"
    relation "felt better in"
    weight 1
  ]
  edge [
    source 28
    target 952
    kind "relation"
    relation "was at home all morning"
    weight 2
  ]
  edge [
    source 28
    target 957
    kind "relation"
    relation "put papers in order for | did many things else to that end"
    weight 3
  ]
  edge [
    source 28
    target 913
    kind "relation"
    relation "had good dinner with | was with | had a good dinner with"
    weight 5
  ]
  edge [
    source 28
    target 958
    kind "mentions"
  ]
  edge [
    source 28
    target 960
    kind "mentions"
  ]
  edge [
    source 28
    target 962
    kind "relation"
    relation "met"
    weight 1
  ]
  edge [
    source 28
    target 843
    kind "relation"
    relation "met"
    weight 1
  ]
  edge [
    source 28
    target 609
    kind "relation"
    relation "agreed with | saw | stayed with"
    weight 3
  ]
  edge [
    source 28
    target 965
    kind "relation"
    relation "took leave of"
    weight 1
  ]
  edge [
    source 28
    target 966
    kind "relation"
    relation "took leave of"
    weight 1
  ]
  edge [
    source 28
    target 978
    kind "relation"
    relation "put things in order for"
    weight 1
  ]
  edge [
    source 28
    target 979
    kind "relation"
    relation "gave"
    weight 1
  ]
  edge [
    source 28
    target 981
    kind "relation"
    relation "went to bed"
    weight 1
  ]
  edge [
    source 28
    target 982
    kind "relation"
    relation "went to london"
    weight 2
  ]
  edge [
    source 28
    target 972
    kind "relation"
    relation "put on | had no stockings but"
    weight 2
  ]
  edge [
    source 28
    target 973
    kind "relation"
    relation "bought | put on"
    weight 4
  ]
  edge [
    source 28
    target 983
    kind "relation"
    relation "went to bigglesworth"
    weight 2
  ]
  edge [
    source 28
    target 984
    kind "mentions"
  ]
  edge [
    source 28
    target 987
    kind "mentions"
  ]
  edge [
    source 28
    target 989
    kind "relation"
    relation "dined at"
    weight 1
  ]
  edge [
    source 28
    target 990
    kind "relation"
    relation "walked to"
    weight 1
  ]
  edge [
    source 28
    target 991
    kind "relation"
    relation "met | drank with | set up"
    weight 3
  ]
  edge [
    source 28
    target 999
    kind "relation"
    relation "visited"
    weight 1
  ]
  edge [
    source 28
    target 64
    kind "relation"
    relation "visited | believed something unfortunate had befallen | did not speak to | troubled | came to dine with"
    weight 5
  ]
  edge [
    source 28
    target 1002
    kind "relation"
    relation "found everything as"
    weight 1
  ]
  edge [
    source 28
    target 1003
    kind "relation"
    relation "went to bed after"
    weight 1
  ]
  edge [
    source 28
    target 1004
    kind "relation"
    relation "put on"
    weight 1
  ]
  edge [
    source 28
    target 548
    kind "relation"
    relation "made visits to"
    weight 1
  ]
  edge [
    source 28
    target 1000
    kind "relation"
    relation "stayed talking with | sat before"
    weight 2
  ]
  edge [
    source 28
    target 1001
    kind "relation"
    relation "saw | was a play the narrator had never seen before | was ill acted | was good in content but ill acted"
    weight 4
  ]
  edge [
    source 28
    target 1005
    kind "mentions"
  ]
  edge [
    source 28
    target 1007
    kind "mentions"
  ]
  edge [
    source 28
    target 1008
    kind "relation"
    relation "sat before"
    weight 1
  ]
  edge [
    source 28
    target 1012
    kind "relation"
    relation "was pleased by"
    weight 1
  ]
  edge [
    source 28
    target 1010
    kind "relation"
    relation "met | discoursed with | satisfied"
    weight 3
  ]
  edge [
    source 28
    target 1011
    kind "relation"
    relation "discussed | read | had more trouble about"
    weight 4
  ]
  edge [
    source 28
    target 1013
    kind "mentions"
  ]
  edge [
    source 28
    target 1014
    kind "relation"
    relation "found"
    weight 1
  ]
  edge [
    source 28
    target 1015
    kind "relation"
    relation "is troubled by"
    weight 1
  ]
  edge [
    source 28
    target 559
    kind "relation"
    relation "decides not to keep"
    weight 1
  ]
  edge [
    source 28
    target 1016
    kind "mentions"
  ]
  edge [
    source 28
    target 1021
    kind "relation"
    relation "was vexed by"
    weight 1
  ]
  edge [
    source 28
    target 1022
    kind "relation"
    relation "left"
    weight 1
  ]
  edge [
    source 28
    target 1020
    kind "relation"
    relation "went to | discoursed with"
    weight 2
  ]
  edge [
    source 28
    target 1026
    kind "mentions"
  ]
  edge [
    source 28
    target 1027
    kind "relation"
    relation "arrived by chance | walked with"
    weight 2
  ]
  edge [
    source 28
    target 1028
    kind "relation"
    relation "walked with"
    weight 1
  ]
  edge [
    source 28
    target 297
    kind "relation"
    relation "found the place very pretty | slept at"
    weight 2
  ]
  edge [
    source 28
    target 381
    kind "relation"
    relation "dined with"
    weight 1
  ]
  edge [
    source 28
    target 1031
    kind "relation"
    relation "took great content in"
    weight 1
  ]
  edge [
    source 28
    target 221
    kind "relation"
    relation "gave out to others | included moneys"
    weight 2
  ]
  edge [
    source 28
    target 1034
    kind "relation"
    relation "set down journals"
    weight 1
  ]
  edge [
    source 28
    target 1037
    kind "relation"
    relation "heard that"
    weight 1
  ]
  edge [
    source 28
    target 1041
    kind "relation"
    relation "was very glad that"
    weight 1
  ]
  edge [
    source 28
    target 1042
    kind "relation"
    relation "set the narrator at work"
    weight 2
  ]
  edge [
    source 28
    target 1043
    kind "mentions"
  ]
  edge [
    source 28
    target 1045
    kind "mentions"
  ]
  edge [
    source 28
    target 498
    kind "relation"
    relation "went to"
    weight 2
  ]
  edge [
    source 28
    target 1049
    kind "relation"
    relation "went to"
    weight 1
  ]
  edge [
    source 28
    target 1046
    kind "relation"
    relation "found | came to dine with | was at the narrator's house for the first time"
    weight 3
  ]
  edge [
    source 28
    target 1047
    kind "relation"
    relation "found"
    weight 1
  ]
  edge [
    source 28
    target 1051
    kind "relation"
    relation "was angry about"
    weight 1
  ]
  edge [
    source 28
    target 1048
    kind "relation"
    relation "saw | was merry and innocent | was well performed"
    weight 3
  ]
  edge [
    source 28
    target 1052
    kind "relation"
    relation "thought about"
    weight 1
  ]
  edge [
    source 28
    target 606
    kind "relation"
    relation "went home | was at home | had vowed to drink no wine"
    weight 3
  ]
  edge [
    source 28
    target 1053
    kind "mentions"
  ]
  edge [
    source 28
    target 1055
    kind "mentions"
  ]
  edge [
    source 28
    target 1056
    kind "relation"
    relation "met with | took"
    weight 2
  ]
  edge [
    source 28
    target 1067
    kind "relation"
    relation "found that"
    weight 1
  ]
  edge [
    source 28
    target 1068
    kind "relation"
    relation "is troubled by | hopes god will forgive"
    weight 2
  ]
  edge [
    source 28
    target 1069
    kind "mentions"
  ]
  edge [
    source 28
    target 1118
    kind "mentions"
  ]
  edge [
    source 28
    target 1121
    kind "relation"
    relation "stayed at home reading"
    weight 1
  ]
  edge [
    source 28
    target 1122
    kind "relation"
    relation "intends to keep"
    weight 1
  ]
  edge [
    source 28
    target 660
    kind "relation"
    relation "had supper and went to bed | returned home for dinner"
    weight 2
  ]
  edge [
    source 28
    target 1126
    kind "mentions"
  ]
  edge [
    source 28
    target 1128
    kind "relation"
    relation "went to see"
    weight 1
  ]
  edge [
    source 28
    target 597
    kind "relation"
    relation "dined with | had a long conversation with"
    weight 2
  ]
  edge [
    source 28
    target 1161
    kind "mentions"
  ]
  edge [
    source 28
    target 1163
    kind "relation"
    relation "met about"
    weight 1
  ]
  edge [
    source 28
    target 701
    kind "relation"
    relation "walked into"
    weight 1
  ]
  edge [
    source 28
    target 1164
    kind "relation"
    relation "went to"
    weight 1
  ]
  edge [
    source 28
    target 1165
    kind "relation"
    relation "sought information about"
    weight 1
  ]
  edge [
    source 28
    target 1167
    kind "relation"
    relation "took to"
    weight 1
  ]
  edge [
    source 28
    target 1175
    kind "relation"
    relation "sat with"
    weight 1
  ]
  edge [
    source 28
    target 1169
    kind "relation"
    relation "was forced to borrow"
    weight 2
  ]
  edge [
    source 28
    target 1176
    kind "mentions"
  ]
  edge [
    source 28
    target 1147
    kind "relation"
    relation "came to"
    weight 1
  ]
  edge [
    source 28
    target 1178
    kind "relation"
    relation "saw"
    weight 1
  ]
  edge [
    source 28
    target 1179
    kind "relation"
    relation "prepared to go to"
    weight 1
  ]
  edge [
    source 28
    target 1200
    kind "mentions"
  ]
  edge [
    source 28
    target 468
    kind "relation"
    relation "got up early"
    weight 1
  ]
  edge [
    source 28
    target 1201
    kind "relation"
    relation "went to | stayed at | drank at"
    weight 3
  ]
  edge [
    source 28
    target 1202
    kind "relation"
    relation "met | rode with"
    weight 2
  ]
  edge [
    source 28
    target 1203
    kind "relation"
    relation "was tired"
    weight 1
  ]
  edge [
    source 28
    target 41
    kind "relation"
    relation "was wet from"
    weight 1
  ]
  edge [
    source 28
    target 1204
    kind "mentions"
  ]
  edge [
    source 28
    target 1205
    kind "relation"
    relation "went to | stayed at"
    weight 2
  ]
  edge [
    source 28
    target 1209
    kind "relation"
    relation "waited until"
    weight 1
  ]
  edge [
    source 28
    target 1207
    kind "relation"
    relation "dined with"
    weight 1
  ]
  edge [
    source 28
    target 1208
    kind "relation"
    relation "dined with"
    weight 1
  ]
  edge [
    source 28
    target 880
    kind "relation"
    relation "went to"
    weight 1
  ]
  edge [
    source 28
    target 1210
    kind "mentions"
  ]
  edge [
    source 28
    target 1211
    kind "relation"
    relation "went to | was very merry"
    weight 2
  ]
  edge [
    source 28
    target 1212
    kind "relation"
    relation "sat with"
    weight 1
  ]
  edge [
    source 28
    target 1213
    kind "relation"
    relation "sat with"
    weight 1
  ]
  edge [
    source 28
    target 1214
    kind "relation"
    relation "were found by"
    weight 1
  ]
  edge [
    source 28
    target 1217
    kind "relation"
    relation "is sorry for"
    weight 1
  ]
  edge [
    source 28
    target 1219
    kind "mentions"
  ]
  edge [
    source 28
    target 1220
    kind "relation"
    relation "rode with"
    weight 1
  ]
  edge [
    source 28
    target 1221
    kind "relation"
    relation "was led to"
    weight 1
  ]
  edge [
    source 28
    target 1223
    kind "mentions"
  ]
  edge [
    source 28
    target 1227
    kind "relation"
    relation "walked into"
    weight 1
  ]
  edge [
    source 28
    target 1226
    kind "relation"
    relation "accompanied"
    weight 1
  ]
  edge [
    source 28
    target 1229
    kind "relation"
    relation "rose with reverence"
    weight 1
  ]
  edge [
    source 28
    target 33
    kind "relation"
    relation "had | ate a bit of"
    weight 2
  ]
  edge [
    source 28
    target 32
    kind "relation"
    relation "attended | stayed out of"
    weight 2
  ]
  edge [
    source 28
    target 1230
    kind "relation"
    relation "talked about"
    weight 1
  ]
  edge [
    source 28
    target 1262
    kind "mentions"
  ]
  edge [
    source 28
    target 290
    kind "relation"
    relation "returned to | rode to"
    weight 2
  ]
  edge [
    source 28
    target 1263
    kind "relation"
    relation "stayed with | drank with | talked with"
    weight 3
  ]
  edge [
    source 28
    target 500
    kind "relation"
    relation "went to"
    weight 1
  ]
  edge [
    source 28
    target 1265
    kind "relation"
    relation "arrived at | had a good supper at"
    weight 2
  ]
  edge [
    source 28
    target 1266
    kind "relation"
    relation "did not take notice of"
    weight 1
  ]
  edge [
    source 28
    target 30
    kind "relation"
    relation "visited | was very handsome"
    weight 2
  ]
  edge [
    source 28
    target 1273
    kind "mentions"
  ]
  edge [
    source 28
    target 1274
    kind "relation"
    relation "was called up at"
    weight 1
  ]
  edge [
    source 28
    target 1275
    kind "relation"
    relation "was on horseback by"
    weight 1
  ]
  edge [
    source 28
    target 1277
    kind "relation"
    relation "saw | had ridden with | called in | shared breakfast with | traveled together"
    weight 5
  ]
  edge [
    source 28
    target 1281
    kind "relation"
    relation "wanted to steal | could not steal"
    weight 2
  ]
  edge [
    source 28
    target 1287
    kind "relation"
    relation "was troubled by"
    weight 1
  ]
  edge [
    source 28
    target 1288
    kind "relation"
    relation "found"
    weight 1
  ]
  edge [
    source 28
    target 1289
    kind "relation"
    relation "found"
    weight 1
  ]
  edge [
    source 28
    target 1290
    kind "relation"
    relation "found"
    weight 1
  ]
  edge [
    source 28
    target 1282
    kind "relation"
    relation "was to wait upon"
    weight 1
  ]
  edge [
    source 28
    target 1283
    kind "relation"
    relation "did not see | asked | replied that he had no deputation from"
    weight 4
  ]
  edge [
    source 28
    target 1292
    kind "mentions"
  ]
  edge [
    source 28
    target 1294
    kind "mentions"
  ]
  edge [
    source 28
    target 1297
    kind "relation"
    relation "became mad because"
    weight 1
  ]
  edge [
    source 28
    target 1298
    kind "mentions"
  ]
  edge [
    source 28
    target 1301
    kind "relation"
    relation "took to the tavern"
    weight 1
  ]
  edge [
    source 28
    target 1299
    kind "relation"
    relation "stayed with | left after"
    weight 2
  ]
  edge [
    source 28
    target 1300
    kind "relation"
    relation "stayed with"
    weight 1
  ]
  edge [
    source 28
    target 590
    kind "relation"
    relation "met"
    weight 1
  ]
  edge [
    source 28
    target 1304
    kind "mentions"
  ]
  edge [
    source 28
    target 1312
    kind "relation"
    relation "went to"
    weight 1
  ]
  edge [
    source 28
    target 1306
    kind "relation"
    relation "was not as ill as thought | believes will recover"
    weight 2
  ]
  edge [
    source 28
    target 1309
    kind "relation"
    relation "promised to be a friend to"
    weight 1
  ]
  edge [
    source 28
    target 1310
    kind "relation"
    relation "promised to be a friend to"
    weight 1
  ]
  edge [
    source 28
    target 1314
    kind "mentions"
  ]
  edge [
    source 28
    target 1318
    kind "relation"
    relation "was sworn as deputy by"
    weight 1
  ]
  edge [
    source 28
    target 1319
    kind "relation"
    relation "concludes that"
    weight 1
  ]
  edge [
    source 28
    target 1322
    kind "mentions"
  ]
  edge [
    source 28
    target 1325
    kind "relation"
    relation "visited | stayed with | was extraordinary merry with"
    weight 4
  ]
  edge [
    source 28
    target 1326
    kind "relation"
    relation "stayed with"
    weight 1
  ]
  edge [
    source 28
    target 1327
    kind "mentions"
  ]
  edge [
    source 28
    target 1331
    kind "mentions"
  ]
  edge [
    source 28
    target 921
    kind "relation"
    relation "is very ugly | seems very good"
    weight 2
  ]
  edge [
    source 28
    target 1333
    kind "relation"
    relation "plans for"
    weight 1
  ]
  edge [
    source 28
    target 1334
    kind "relation"
    relation "plans for"
    weight 1
  ]
  edge [
    source 28
    target 1359
    kind "mentions"
  ]
  edge [
    source 28
    target 1363
    kind "relation"
    relation "sat in"
    weight 1
  ]
  edge [
    source 28
    target 1360
    kind "relation"
    relation "had full view of | no longer trusts"
    weight 2
  ]
  edge [
    source 28
    target 1361
    kind "relation"
    relation "no longer trusts"
    weight 1
  ]
  edge [
    source 28
    target 1364
    kind "mentions"
  ]
  edge [
    source 28
    target 1365
    kind "relation"
    relation "met | was met with"
    weight 2
  ]
  edge [
    source 28
    target 1369
    kind "mentions"
  ]
  edge [
    source 28
    target 1371
    kind "relation"
    relation "went to"
    weight 1
  ]
  edge [
    source 28
    target 1374
    kind "mentions"
  ]
  edge [
    source 28
    target 1375
    kind "relation"
    relation "consulted about"
    weight 1
  ]
  edge [
    source 28
    target 1381
    kind "relation"
    relation "feels troubled by"
    weight 1
  ]
  edge [
    source 28
    target 1382
    kind "relation"
    relation "feels troubled by"
    weight 1
  ]
  edge [
    source 28
    target 1384
    kind "mentions"
  ]
  edge [
    source 28
    target 1388
    kind "mentions"
  ]
  edge [
    source 28
    target 1295
    kind "relation"
    relation "went to | was visited by"
    weight 3
  ]
  edge [
    source 28
    target 1392
    kind "relation"
    relation "found"
    weight 1
  ]
  edge [
    source 28
    target 1393
    kind "mentions"
  ]
  edge [
    source 28
    target 585
    kind "relation"
    relation "took | took away | spent the morning organizing"
    weight 3
  ]
  edge [
    source 28
    target 1396
    kind "mentions"
  ]
  edge [
    source 28
    target 268
    kind "relation"
    relation "discussed not keeping"
    weight 1
  ]
  edge [
    source 28
    target 1402
    kind "relation"
    relation "went forth to"
    weight 1
  ]
  edge [
    source 28
    target 1406
    kind "relation"
    relation "told them about"
    weight 1
  ]
  edge [
    source 28
    target 1407
    kind "relation"
    relation "expressed thoughts regarding"
    weight 1
  ]
  edge [
    source 28
    target 1399
    kind "relation"
    relation "returns home and finds"
    weight 1
  ]
  edge [
    source 28
    target 1410
    kind "relation"
    relation "is glad to be able to assist"
    weight 1
  ]
  edge [
    source 28
    target 1411
    kind "relation"
    relation "remains troubled about | is afraid of"
    weight 2
  ]
  edge [
    source 28
    target 1412
    kind "mentions"
  ]
  edge [
    source 28
    target 1415
    kind "mentions"
  ]
  edge [
    source 28
    target 1418
    kind "relation"
    relation "is somewhat better"
    weight 1
  ]
  edge [
    source 28
    target 395
    kind "relation"
    relation "went to the theatre with | went with"
    weight 2
  ]
  edge [
    source 28
    target 532
    kind "relation"
    relation "saw"
    weight 1
  ]
  edge [
    source 28
    target 1430
    kind "relation"
    relation "carried a bottle of wine to"
    weight 1
  ]
  edge [
    source 28
    target 1433
    kind "relation"
    relation "feels great comfort about"
    weight 1
  ]
  edge [
    source 28
    target 1434
    kind "mentions"
  ]
  edge [
    source 28
    target 1464
    kind "mentions"
  ]
  edge [
    source 28
    target 1465
    kind "relation"
    relation "had great and very noble alterations | walked in | had a great variety of fowl"
    weight 3
  ]
  edge [
    source 28
    target 1475
    kind "relation"
    relation "is sorry to hear"
    weight 1
  ]
  edge [
    source 28
    target 1439
    kind "relation"
    relation "was seen again | was liked by | showed his wife | was highly pleased with"
    weight 4
  ]
  edge [
    source 28
    target 1482
    kind "relation"
    relation "feels troubled about"
    weight 1
  ]
  edge [
    source 28
    target 1471
    kind "relation"
    relation "is drawn to"
    weight 1
  ]
  edge [
    source 28
    target 1473
    kind "relation"
    relation "sent a vessel to"
    weight 1
  ]
  edge [
    source 28
    target 1485
    kind "mentions"
  ]
  edge [
    source 28
    target 1486
    kind "relation"
    relation "attended | returned home after"
    weight 2
  ]
  edge [
    source 28
    target 1487
    kind "relation"
    relation "had dinner with | was merry with"
    weight 2
  ]
  edge [
    source 28
    target 1493
    kind "mentions"
  ]
  edge [
    source 28
    target 1494
    kind "relation"
    relation "came to dine with"
    weight 1
  ]
  edge [
    source 28
    target 1078
    kind "relation"
    relation "took his wife and mr. sidney to | is now recovering and sits up and walks about his chamber"
    weight 2
  ]
  edge [
    source 28
    target 666
    kind "relation"
    relation "read in | intended to read with great pains and love"
    weight 2
  ]
  edge [
    source 28
    target 490
    kind "relation"
    relation "had supper and went to bed | was at the office all morning | dined at my father's"
    weight 3
  ]
  edge [
    source 28
    target 1497
    kind "relation"
    relation "went with the children to my father's"
    weight 1
  ]
  edge [
    source 28
    target 1498
    kind "relation"
    relation "went with the children to see | went with"
    weight 2
  ]
  edge [
    source 28
    target 1499
    kind "mentions"
  ]
  edge [
    source 28
    target 1338
    kind "relation"
    relation "dined at"
    weight 1
  ]
  edge [
    source 28
    target 1542
    kind "mentions"
  ]
  edge [
    source 28
    target 1543
    kind "relation"
    relation "caused suspicion in"
    weight 1
  ]
  edge [
    source 28
    target 822
    kind "relation"
    relation "drank with"
    weight 1
  ]
  edge [
    source 28
    target 573
    kind "relation"
    relation "was not available | went to | spent the afternoon drinking with"
    weight 4
  ]
  edge [
    source 28
    target 1549
    kind "relation"
    relation "discussed the marriage proposal with"
    weight 2
  ]
  edge [
    source 28
    target 1555
    kind "relation"
    relation "agreed to visit"
    weight 2
  ]
  edge [
    source 28
    target 446
    kind "relation"
    relation "went to"
    weight 2
  ]
  edge [
    source 28
    target 1556
    kind "mentions"
  ]
  edge [
    source 28
    target 1558
    kind "mentions"
  ]
  edge [
    source 28
    target 1559
    kind "relation"
    relation "has company that tires"
    weight 1
  ]
  edge [
    source 28
    target 1567
    kind "mentions"
  ]
  edge [
    source 28
    target 1571
    kind "relation"
    relation "went to"
    weight 1
  ]
  edge [
    source 28
    target 1574
    kind "mentions"
  ]
  edge [
    source 28
    target 1580
    kind "relation"
    relation "thinks the girl will do well for"
    weight 1
  ]
  edge [
    source 28
    target 988
    kind "relation"
    relation "will wait for"
    weight 1
  ]
  edge [
    source 28
    target 1578
    kind "relation"
    relation "is desirous of"
    weight 1
  ]
  edge [
    source 28
    target 1582
    kind "mentions"
  ]
  edge [
    source 28
    target 732
    kind "relation"
    relation "supped with"
    weight 1
  ]
  edge [
    source 28
    target 1585
    kind "mentions"
  ]
  edge [
    source 28
    target 1593
    kind "relation"
    relation "took his wife by coach to | went to"
    weight 3
  ]
  edge [
    source 28
    target 1250
    kind "relation"
    relation "returned to church after | returned to | drank at | went to | felt no pleasure | took trouble to leave"
    weight 7
  ]
  edge [
    source 28
    target 1599
    kind "relation"
    relation "went with his aunt wight, his wife, and pall to"
    weight 1
  ]
  edge [
    source 28
    target 1600
    kind "mentions"
  ]
  edge [
    source 28
    target 1607
    kind "relation"
    relation "went to"
    weight 1
  ]
  edge [
    source 28
    target 1608
    kind "relation"
    relation "found his father and mother in"
    weight 1
  ]
  edge [
    source 28
    target 1605
    kind "relation"
    relation "gave"
    weight 1
  ]
  edge [
    source 28
    target 1615
    kind "mentions"
  ]
  edge [
    source 28
    target 1618
    kind "relation"
    relation "was taken to | was sworn in"
    weight 2
  ]
  edge [
    source 28
    target 202
    kind "relation"
    relation "went to"
    weight 1
  ]
  edge [
    source 28
    target 1619
    kind "relation"
    relation "ate"
    weight 1
  ]
  edge [
    source 28
    target 1620
    kind "relation"
    relation "went to"
    weight 1
  ]
  edge [
    source 28
    target 725
    kind "relation"
    relation "took his wife to"
    weight 1
  ]
  edge [
    source 28
    target 1623
    kind "mentions"
  ]
  edge [
    source 28
    target 1630
    kind "relation"
    relation "believes"
    weight 1
  ]
  edge [
    source 28
    target 1626
    kind "relation"
    relation "understands much english | believes it could be taught to speak or make signs"
    weight 2
  ]
  edge [
    source 28
    target 1628
    kind "relation"
    relation "reached agreement with"
    weight 1
  ]
  edge [
    source 28
    target 1672
    kind "mentions"
  ]
  edge [
    source 28
    target 1673
    kind "relation"
    relation "would please them better in all things than anyone else | was so harmless"
    weight 2
  ]
  edge [
    source 28
    target 1675
    kind "relation"
    relation "paid"
    weight 1
  ]
  edge [
    source 28
    target 1674
    kind "relation"
    relation "gave"
    weight 1
  ]
  edge [
    source 28
    target 1678
    kind "relation"
    relation "felt sorrow at"
    weight 1
  ]
  edge [
    source 28
    target 1679
    kind "mentions"
  ]
  edge [
    source 28
    target 1683
    kind "relation"
    relation "found"
    weight 1
  ]
  edge [
    source 28
    target 1684
    kind "relation"
    relation "concluded"
    weight 1
  ]
  edge [
    source 28
    target 1685
    kind "mentions"
  ]
  edge [
    source 28
    target 1686
    kind "relation"
    relation "gave good content to"
    weight 1
  ]
  edge [
    source 28
    target 1688
    kind "mentions"
  ]
  edge [
    source 28
    target 1689
    kind "relation"
    relation "went to"
    weight 1
  ]
  edge [
    source 28
    target 1693
    kind "mentions"
  ]
  edge [
    source 28
    target 1694
    kind "relation"
    relation "met | drank with"
    weight 2
  ]
  edge [
    source 28
    target 1470
    kind "relation"
    relation "went to"
    weight 2
  ]
  edge [
    source 28
    target 1698
    kind "mentions"
  ]
  edge [
    source 28
    target 1708
    kind "relation"
    relation "and his father"
    weight 1
  ]
  edge [
    source 28
    target 1699
    kind "relation"
    relation "fears the match will not succeed"
    weight 1
  ]
  edge [
    source 28
    target 1709
    kind "relation"
    relation "and his father"
    weight 1
  ]
  edge [
    source 28
    target 1711
    kind "relation"
    relation "received news of"
    weight 1
  ]
  edge [
    source 28
    target 1705
    kind "relation"
    relation "called in at | visited"
    weight 2
  ]
  edge [
    source 28
    target 1707
    kind "relation"
    relation "met and took leave of"
    weight 2
  ]
  edge [
    source 28
    target 1714
    kind "mentions"
  ]
  edge [
    source 28
    target 1716
    kind "mentions"
  ]
  edge [
    source 28
    target 1730
    kind "relation"
    relation "prayed that god bless"
    weight 1
  ]
  edge [
    source 28
    target 1734
    kind "relation"
    relation "was to enquire after"
    weight 1
  ]
  edge [
    source 28
    target 1737
    kind "relation"
    relation "thought the dinners were"
    weight 1
  ]
  edge [
    source 28
    target 1740
    kind "mentions"
  ]
  edge [
    source 28
    target 1742
    kind "mentions"
  ]
  edge [
    source 28
    target 150
    kind "relation"
    relation "returned home by"
    weight 1
  ]
  edge [
    source 28
    target 1743
    kind "relation"
    relation "feared getting involved in | did not want to be tied to"
    weight 2
  ]
  edge [
    source 28
    target 1747
    kind "relation"
    relation "was troubled by"
    weight 1
  ]
  edge [
    source 28
    target 1752
    kind "mentions"
  ]
  edge [
    source 28
    target 638
    kind "relation"
    relation "met dr. williams"
    weight 1
  ]
  edge [
    source 28
    target 1753
    kind "relation"
    relation "went with dr. williams to look for"
    weight 1
  ]
  edge [
    source 28
    target 1762
    kind "relation"
    relation "doubted"
    weight 1
  ]
  edge [
    source 28
    target 1765
    kind "mentions"
  ]
  edge [
    source 28
    target 1771
    kind "relation"
    relation "went to | stayed at"
    weight 2
  ]
  edge [
    source 28
    target 669
    kind "relation"
    relation "returned home"
    weight 1
  ]
  edge [
    source 28
    target 1782
    kind "mentions"
  ]
  edge [
    source 28
    target 1784
    kind "relation"
    relation "felt sick in mind"
    weight 1
  ]
  edge [
    source 28
    target 1787
    kind "relation"
    relation "did not show"
    weight 1
  ]
  edge [
    source 28
    target 1792
    kind "relation"
    relation "came to"
    weight 2
  ]
  edge [
    source 28
    target 1789
    kind "relation"
    relation "returned to"
    weight 2
  ]
  edge [
    source 28
    target 1793
    kind "relation"
    relation "met"
    weight 2
  ]
  edge [
    source 28
    target 1794
    kind "relation"
    relation "met"
    weight 2
  ]
  edge [
    source 28
    target 1795
    kind "relation"
    relation "met"
    weight 2
  ]
  edge [
    source 28
    target 1799
    kind "mentions"
  ]
  edge [
    source 28
    target 1800
    kind "relation"
    relation "was at home"
    weight 1
  ]
  edge [
    source 28
    target 1791
    kind "relation"
    relation "disapproved of"
    weight 1
  ]
  edge [
    source 28
    target 1802
    kind "mentions"
  ]
  edge [
    source 28
    target 1803
    kind "relation"
    relation "met with"
    weight 1
  ]
  edge [
    source 28
    target 1804
    kind "relation"
    relation "met with"
    weight 1
  ]
  edge [
    source 28
    target 1805
    kind "relation"
    relation "met with"
    weight 1
  ]
  edge [
    source 28
    target 1807
    kind "relation"
    relation "found the company unclean"
    weight 1
  ]
  edge [
    source 28
    target 1810
    kind "relation"
    relation "gave to each of the ladies"
    weight 1
  ]
  edge [
    source 28
    target 1814
    kind "mentions"
  ]
  edge [
    source 28
    target 1816
    kind "mentions"
  ]
  edge [
    source 28
    target 1817
    kind "relation"
    relation "arrived at"
    weight 1
  ]
  edge [
    source 28
    target 1830
    kind "relation"
    relation "is under much business and trouble in"
    weight 1
  ]
  edge [
    source 28
    target 1831
    kind "relation"
    relation "has become too much given to"
    weight 1
  ]
  edge [
    source 28
    target 711
    kind "relation"
    relation "has become too much given to"
    weight 1
  ]
  edge [
    source 28
    target 1032
    kind "relation"
    relation "has become too much given to"
    weight 1
  ]
  edge [
    source 28
    target 1832
    kind "relation"
    relation "has forgotten his business duties"
    weight 1
  ]
  edge [
    source 28
    target 1833
    kind "relation"
    relation "is working to amend"
    weight 1
  ]
  edge [
    source 28
    target 1818
    kind "relation"
    relation "has no money coming in"
    weight 1
  ]
  edge [
    source 28
    target 1834
    kind "relation"
    relation "has borrowed a great deal for"
    weight 1
  ]
  edge [
    source 28
    target 113
    kind "relation"
    relation "has trouble about"
    weight 1
  ]
  edge [
    source 28
    target 1836
    kind "relation"
    relation "has great fears that"
    weight 2
  ]
  edge [
    source 28
    target 1838
    kind "mentions"
  ]
  edge [
    source 30
    target 31
    kind "relation"
    relation "delivered a good sermon"
    weight 1
  ]
  edge [
    source 30
    target 541
    kind "mentions"
  ]
  edge [
    source 30
    target 59
    kind "relation"
    relation "goes to"
    weight 1
  ]
  edge [
    source 30
    target 668
    kind "mentions"
  ]
  edge [
    source 30
    target 670
    kind "relation"
    relation "has become a regular sunday practice at"
    weight 1
  ]
  edge [
    source 30
    target 803
    kind "mentions"
  ]
  edge [
    source 30
    target 811
    kind "relation"
    relation "was carried to"
    weight 1
  ]
  edge [
    source 30
    target 1055
    kind "mentions"
  ]
  edge [
    source 30
    target 1098
    kind "mentions"
  ]
  edge [
    source 30
    target 1116
    kind "mentions"
  ]
  edge [
    source 30
    target 1262
    kind "mentions"
  ]
  edge [
    source 30
    target 1359
    kind "mentions"
  ]
  edge [
    source 30
    target 1585
    kind "mentions"
  ]
  edge [
    source 30
    target 1633
    kind "mentions"
  ]
  edge [
    source 30
    target 1444
    kind "relation"
    relation "went to"
    weight 1
  ]
  edge [
    source 31
    target 742
    kind "mentions"
  ]
  edge [
    source 31
    target 1633
    kind "mentions"
  ]
  edge [
    source 31
    target 1643
    kind "relation"
    relation "delivered a sermon on"
    weight 1
  ]
  edge [
    source 32
    target 679
    kind "mentions"
  ]
  edge [
    source 32
    target 59
    kind "relation"
    relation "attended"
    weight 1
  ]
  edge [
    source 32
    target 1223
    kind "mentions"
  ]
  edge [
    source 32
    target 1585
    kind "mentions"
  ]
  edge [
    source 33
    target 225
    kind "mentions"
  ]
  edge [
    source 33
    target 541
    kind "mentions"
  ]
  edge [
    source 33
    target 59
    kind "relation"
    relation "goes home to | returned home to"
    weight 2
  ]
  edge [
    source 33
    target 547
    kind "mentions"
  ]
  edge [
    source 33
    target 548
    kind "relation"
    relation "was the location of"
    weight 1
  ]
  edge [
    source 33
    target 192
    kind "relation"
    relation "was out of town"
    weight 1
  ]
  edge [
    source 33
    target 549
    kind "relation"
    relation "was a guest at"
    weight 1
  ]
  edge [
    source 33
    target 551
    kind "relation"
    relation "was a guest at"
    weight 1
  ]
  edge [
    source 33
    target 679
    kind "mentions"
  ]
  edge [
    source 33
    target 1098
    kind "mentions"
  ]
  edge [
    source 33
    target 1116
    kind "mentions"
  ]
  edge [
    source 33
    target 1223
    kind "mentions"
  ]
  edge [
    source 33
    target 1262
    kind "mentions"
  ]
  edge [
    source 33
    target 1273
    kind "mentions"
  ]
  edge [
    source 33
    target 1343
    kind "mentions"
  ]
  edge [
    source 33
    target 1464
    kind "mentions"
  ]
  edge [
    source 33
    target 44
    kind "relation"
    relation "was the location of"
    weight 1
  ]
  edge [
    source 33
    target 1485
    kind "mentions"
  ]
  edge [
    source 33
    target 1716
    kind "mentions"
  ]
  edge [
    source 33
    target 1738
    kind "relation"
    relation "included"
    weight 1
  ]
  edge [
    source 33
    target 1775
    kind "mentions"
  ]
  edge [
    source 34
    target 39
    kind "relation"
    relation "explained how levers work"
    weight 1
  ]
  edge [
    source 34
    target 40
    kind "relation"
    relation "noted that gain in strength is lost in time"
    weight 1
  ]
  edge [
    source 35
    target 56
    kind "mentions"
  ]
  edge [
    source 35
    target 59
    kind "relation"
    relation "drinks a great deal of"
    weight 1
  ]
  edge [
    source 35
    target 403
    kind "mentions"
  ]
  edge [
    source 35
    target 418
    kind "relation"
    relation "served"
    weight 1
  ]
  edge [
    source 35
    target 803
    kind "mentions"
  ]
  edge [
    source 35
    target 822
    kind "relation"
    relation "served | drank"
    weight 2
  ]
  edge [
    source 35
    target 861
    kind "mentions"
  ]
  edge [
    source 35
    target 1055
    kind "mentions"
  ]
  edge [
    source 35
    target 1056
    kind "relation"
    relation "served"
    weight 1
  ]
  edge [
    source 35
    target 1349
    kind "mentions"
  ]
  edge [
    source 35
    target 824
    kind "relation"
    relation "gave"
    weight 1
  ]
  edge [
    source 35
    target 1716
    kind "mentions"
  ]
  edge [
    source 35
    target 1816
    kind "mentions"
  ]
  edge [
    source 35
    target 1823
    kind "relation"
    relation "drank a glass of"
    weight 1
  ]
  edge [
    source 35
    target 1925
    kind "mentions"
  ]
  edge [
    source 35
    target 1903
    kind "relation"
    relation "made a vow to drink no"
    weight 1
  ]
  edge [
    source 41
    target 53
    kind "relation"
    relation "has rained heavily"
    weight 1
  ]
  edge [
    source 41
    target 42
    kind "relation"
    relation "caused concern about"
    weight 1
  ]
  edge [
    source 41
    target 1200
    kind "mentions"
  ]
  edge [
    source 41
    target 1241
    kind "mentions"
  ]
  edge [
    source 41
    target 1245
    kind "relation"
    relation "caused"
    weight 1
  ]
  edge [
    source 43
    target 45
    kind "relation"
    relation "intended to join"
    weight 1
  ]
  edge [
    source 43
    target 198
    kind "mentions"
  ]
  edge [
    source 43
    target 44
    kind "relation"
    relation "was ordered to reveal"
    weight 1
  ]
  edge [
    source 43
    target 196
    kind "relation"
    relation "revealed to"
    weight 1
  ]
  edge [
    source 43
    target 237
    kind "mentions"
  ]
  edge [
    source 43
    target 238
    kind "relation"
    relation "met"
    weight 1
  ]
  edge [
    source 43
    target 61
    kind "relation"
    relation "is willing to communicate information for"
    weight 1
  ]
  edge [
    source 44
    target 45
    kind "relation"
    relation "instructed the narrator about | stayed at"
    weight 2
  ]
  edge [
    source 44
    target 56
    kind "mentions"
  ]
  edge [
    source 44
    target 86
    kind "mentions"
  ]
  edge [
    source 44
    target 141
    kind "mentions"
  ]
  edge [
    source 44
    target 59
    kind "relation"
    relation "went to | returns to | traveled by water to"
    weight 4
  ]
  edge [
    source 44
    target 191
    kind "mentions"
  ]
  edge [
    source 44
    target 196
    kind "relation"
    relation "went to"
    weight 1
  ]
  edge [
    source 44
    target 198
    kind "mentions"
  ]
  edge [
    source 44
    target 237
    kind "mentions"
  ]
  edge [
    source 44
    target 280
    kind "mentions"
  ]
  edge [
    source 44
    target 366
    kind "mentions"
  ]
  edge [
    source 44
    target 379
    kind "mentions"
  ]
  edge [
    source 44
    target 471
    kind "mentions"
  ]
  edge [
    source 44
    target 496
    kind "mentions"
  ]
  edge [
    source 44
    target 58
    kind "relation"
    relation "travels by water to | returns home from | went to | had dinner with"
    weight 4
  ]
  edge [
    source 44
    target 605
    kind "mentions"
  ]
  edge [
    source 44
    target 742
    kind "mentions"
  ]
  edge [
    source 44
    target 1026
    kind "mentions"
  ]
  edge [
    source 44
    target 1071
    kind "mentions"
  ]
  edge [
    source 44
    target 1093
    kind "relation"
    relation "was visited by"
    weight 1
  ]
  edge [
    source 44
    target 1086
    kind "relation"
    relation "was the birthday celebration of"
    weight 2
  ]
  edge [
    source 44
    target 1094
    kind "mentions"
  ]
  edge [
    source 44
    target 1158
    kind "mentions"
  ]
  edge [
    source 44
    target 248
    kind "relation"
    relation "was going in his barge to"
    weight 1
  ]
  edge [
    source 44
    target 1273
    kind "mentions"
  ]
  edge [
    source 44
    target 1292
    kind "mentions"
  ]
  edge [
    source 44
    target 1294
    kind "mentions"
  ]
  edge [
    source 44
    target 192
    kind "relation"
    relation "was attended by"
    weight 1
  ]
  edge [
    source 44
    target 1388
    kind "mentions"
  ]
  edge [
    source 44
    target 1436
    kind "mentions"
  ]
  edge [
    source 44
    target 1444
    kind "relation"
    relation "walked to"
    weight 1
  ]
  edge [
    source 44
    target 1464
    kind "mentions"
  ]
  edge [
    source 44
    target 1365
    kind "relation"
    relation "went to"
    weight 1
  ]
  edge [
    source 44
    target 1582
    kind "mentions"
  ]
  edge [
    source 44
    target 1615
    kind "mentions"
  ]
  edge [
    source 44
    target 1622
    kind "relation"
    relation "went to"
    weight 1
  ]
  edge [
    source 44
    target 1716
    kind "mentions"
  ]
  edge [
    source 44
    target 1782
    kind "mentions"
  ]
  edge [
    source 45
    target 366
    kind "mentions"
  ]
  edge [
    source 45
    target 375
    kind "relation"
    relation "ordered"
    weight 1
  ]
  edge [
    source 45
    target 377
    kind "relation"
    relation "left"
    weight 1
  ]
  edge [
    source 45
    target 378
    kind "relation"
    relation "came in"
    weight 1
  ]
  edge [
    source 45
    target 379
    kind "mentions"
  ]
  edge [
    source 45
    target 370
    kind "relation"
    relation "agreed to buy"
    weight 1
  ]
  edge [
    source 45
    target 425
    kind "mentions"
  ]
  edge [
    source 45
    target 421
    kind "relation"
    relation "was absent"
    weight 1
  ]
  edge [
    source 45
    target 443
    kind "mentions"
  ]
  edge [
    source 45
    target 583
    kind "mentions"
  ]
  edge [
    source 45
    target 585
    kind "relation"
    relation "were received from"
    weight 1
  ]
  edge [
    source 45
    target 1161
    kind "mentions"
  ]
  edge [
    source 45
    target 1415
    kind "mentions"
  ]
  edge [
    source 45
    target 1423
    kind "relation"
    relation "is now free from"
    weight 1
  ]
  edge [
    source 45
    target 1432
    kind "relation"
    relation "is hopeful to go aboard"
    weight 1
  ]
  edge [
    source 47
    target 56
    kind "mentions"
  ]
  edge [
    source 47
    target 59
    kind "relation"
    relation "returns home and takes"
    weight 1
  ]
  edge [
    source 47
    target 77
    kind "mentions"
  ]
  edge [
    source 47
    target 613
    kind "mentions"
  ]
  edge [
    source 47
    target 740
    kind "mentions"
  ]
  edge [
    source 47
    target 1069
    kind "mentions"
  ]
  edge [
    source 47
    target 1485
    kind "mentions"
  ]
  edge [
    source 50
    target 1223
    kind "mentions"
  ]
  edge [
    source 55
    target 56
    kind "from_chunk"
  ]
  edge [
    source 55
    target 77
    kind "from_chunk"
  ]
  edge [
    source 56
    target 57
    kind "mentions"
  ]
  edge [
    source 56
    target 58
    kind "mentions"
  ]
  edge [
    source 56
    target 59
    kind "mentions"
  ]
  edge [
    source 56
    target 60
    kind "mentions"
  ]
  edge [
    source 56
    target 61
    kind "mentions"
  ]
  edge [
    source 56
    target 62
    kind "mentions"
  ]
  edge [
    source 56
    target 63
    kind "mentions"
  ]
  edge [
    source 56
    target 64
    kind "mentions"
  ]
  edge [
    source 56
    target 65
    kind "mentions"
  ]
  edge [
    source 56
    target 66
    kind "mentions"
  ]
  edge [
    source 56
    target 67
    kind "mentions"
  ]
  edge [
    source 56
    target 68
    kind "mentions"
  ]
  edge [
    source 56
    target 69
    kind "mentions"
  ]
  edge [
    source 56
    target 70
    kind "mentions"
  ]
  edge [
    source 56
    target 71
    kind "mentions"
  ]
  edge [
    source 56
    target 72
    kind "mentions"
  ]
  edge [
    source 56
    target 73
    kind "mentions"
  ]
  edge [
    source 56
    target 74
    kind "mentions"
  ]
  edge [
    source 56
    target 75
    kind "mentions"
  ]
  edge [
    source 56
    target 76
    kind "mentions"
  ]
  edge [
    source 56
    target 1948
    kind "summarizes"
  ]
  edge [
    source 57
    target 69
    kind "relation"
    relation "intends to join"
    weight 1
  ]
  edge [
    source 57
    target 70
    kind "relation"
    relation "has placed great confidence in"
    weight 1
  ]
  edge [
    source 57
    target 1098
    kind "mentions"
  ]
  edge [
    source 57
    target 1099
    kind "relation"
    relation "was with | had a good venison pasty with | returned with"
    weight 3
  ]
  edge [
    source 57
    target 1100
    kind "relation"
    relation "was with"
    weight 1
  ]
  edge [
    source 57
    target 1101
    kind "relation"
    relation "was with"
    weight 1
  ]
  edge [
    source 57
    target 1102
    kind "relation"
    relation "was with"
    weight 1
  ]
  edge [
    source 57
    target 181
    kind "relation"
    relation "showed"
    weight 1
  ]
  edge [
    source 57
    target 1109
    kind "relation"
    relation "took"
    weight 1
  ]
  edge [
    source 57
    target 1111
    kind "relation"
    relation "treated"
    weight 1
  ]
  edge [
    source 57
    target 1112
    kind "relation"
    relation "wrote a letter to"
    weight 1
  ]
  edge [
    source 57
    target 1116
    kind "mentions"
  ]
  edge [
    source 58
    target 366
    kind "mentions"
  ]
  edge [
    source 58
    target 496
    kind "mentions"
  ]
  edge [
    source 58
    target 497
    kind "relation"
    relation "goes to"
    weight 1
  ]
  edge [
    source 58
    target 498
    kind "relation"
    relation "visits"
    weight 1
  ]
  edge [
    source 58
    target 499
    kind "relation"
    relation "speaks with"
    weight 1
  ]
  edge [
    source 58
    target 508
    kind "relation"
    relation "is weary of"
    weight 1
  ]
  edge [
    source 58
    target 503
    kind "relation"
    relation "has become the most negligent man in the world regarding | neither knows nor asks about"
    weight 2
  ]
  edge [
    source 58
    target 367
    kind "relation"
    relation "complete work for"
    weight 2
  ]
  edge [
    source 58
    target 509
    kind "relation"
    relation "is content with"
    weight 2
  ]
  edge [
    source 58
    target 112
    kind "relation"
    relation "meets | goes with"
    weight 4
  ]
  edge [
    source 58
    target 504
    kind "relation"
    relation "drinks morning draft at | eats gammon of bacon at"
    weight 4
  ]
  edge [
    source 58
    target 506
    kind "relation"
    relation "buys"
    weight 2
  ]
  edge [
    source 58
    target 511
    kind "mentions"
  ]
  edge [
    source 58
    target 82
    kind "relation"
    relation "spends most of the day at"
    weight 1
  ]
  edge [
    source 58
    target 912
    kind "mentions"
  ]
  edge [
    source 58
    target 59
    kind "relation"
    relation "was advised by"
    weight 1
  ]
  edge [
    source 58
    target 1045
    kind "mentions"
  ]
  edge [
    source 58
    target 1053
    kind "mentions"
  ]
  edge [
    source 58
    target 1055
    kind "mentions"
  ]
  edge [
    source 58
    target 1011
    kind "relation"
    relation "gave opinion on"
    weight 1
  ]
  edge [
    source 58
    target 1161
    kind "mentions"
  ]
  edge [
    source 58
    target 1273
    kind "mentions"
  ]
  edge [
    source 58
    target 1284
    kind "relation"
    relation "stated"
    weight 1
  ]
  edge [
    source 58
    target 1291
    kind "relation"
    relation "stated"
    weight 1
  ]
  edge [
    source 58
    target 1292
    kind "mentions"
  ]
  edge [
    source 58
    target 1294
    kind "mentions"
  ]
  edge [
    source 58
    target 1298
    kind "mentions"
  ]
  edge [
    source 58
    target 1314
    kind "mentions"
  ]
  edge [
    source 58
    target 1493
    kind "mentions"
  ]
  edge [
    source 58
    target 666
    kind "relation"
    relation "gave"
    weight 1
  ]
  edge [
    source 58
    target 1525
    kind "mentions"
  ]
  edge [
    source 58
    target 1567
    kind "mentions"
  ]
  edge [
    source 58
    target 1816
    kind "mentions"
  ]
  edge [
    source 59
    target 71
    kind "relation"
    relation "wishes to spend part of his blessing for"
    weight 1
  ]
  edge [
    source 59
    target 72
    kind "relation"
    relation "has chosen"
    weight 1
  ]
  edge [
    source 59
    target 73
    kind "relation"
    relation "requests that"
    weight 1
  ]
  edge [
    source 59
    target 75
    kind "relation"
    relation "sees off"
    weight 1
  ]
  edge [
    source 59
    target 76
    kind "relation"
    relation "hosts | stays with | is very merry with"
    weight 3
  ]
  edge [
    source 59
    target 68
    kind "relation"
    relation "is called to | stays at | sat and did business at | went to | goes to"
    weight 5
  ]
  edge [
    source 59
    target 77
    kind "mentions"
  ]
  edge [
    source 59
    target 141
    kind "mentions"
  ]
  edge [
    source 59
    target 84
    kind "relation"
    relation "gave | is not well | was alone with | went home to dinner with | met"
    weight 5
  ]
  edge [
    source 59
    target 62
    kind "relation"
    relation "traveled to"
    weight 1
  ]
  edge [
    source 59
    target 142
    kind "relation"
    relation "traveled to"
    weight 1
  ]
  edge [
    source 59
    target 143
    kind "relation"
    relation "dined with"
    weight 1
  ]
  edge [
    source 59
    target 144
    kind "relation"
    relation "dined with"
    weight 1
  ]
  edge [
    source 59
    target 152
    kind "relation"
    relation "played upon"
    weight 1
  ]
  edge [
    source 59
    target 153
    kind "relation"
    relation "stayed in the garden"
    weight 1
  ]
  edge [
    source 59
    target 148
    kind "relation"
    relation "drank large drafts of"
    weight 1
  ]
  edge [
    source 59
    target 147
    kind "relation"
    relation "ate"
    weight 1
  ]
  edge [
    source 59
    target 149
    kind "relation"
    relation "ate"
    weight 1
  ]
  edge [
    source 59
    target 154
    kind "relation"
    relation "stayed until"
    weight 1
  ]
  edge [
    source 59
    target 85
    kind "relation"
    relation "went to bed | returned to"
    weight 2
  ]
  edge [
    source 59
    target 155
    kind "relation"
    relation "felt very drunk"
    weight 1
  ]
  edge [
    source 59
    target 156
    kind "relation"
    relation "had a headache"
    weight 2
  ]
  edge [
    source 59
    target 157
    kind "relation"
    relation "had a headache"
    weight 2
  ]
  edge [
    source 59
    target 158
    kind "mentions"
  ]
  edge [
    source 59
    target 269
    kind "mentions"
  ]
  edge [
    source 59
    target 278
    kind "relation"
    relation "entrusted the management of"
    weight 1
  ]
  edge [
    source 59
    target 274
    kind "relation"
    relation "will receive orders from"
    weight 1
  ]
  edge [
    source 59
    target 275
    kind "relation"
    relation "will receive orders from"
    weight 1
  ]
  edge [
    source 59
    target 279
    kind "relation"
    relation "is glad about"
    weight 1
  ]
  edge [
    source 59
    target 277
    kind "relation"
    relation "hopes for"
    weight 1
  ]
  edge [
    source 59
    target 280
    kind "mentions"
  ]
  edge [
    source 59
    target 464
    kind "mentions"
  ]
  edge [
    source 59
    target 465
    kind "relation"
    relation "resolved to hire"
    weight 1
  ]
  edge [
    source 59
    target 469
    kind "relation"
    relation "sent | put"
    weight 2
  ]
  edge [
    source 59
    target 470
    kind "relation"
    relation "hoped for"
    weight 1
  ]
  edge [
    source 59
    target 471
    kind "mentions"
  ]
  edge [
    source 59
    target 472
    kind "relation"
    relation "was visited by | parted with"
    weight 2
  ]
  edge [
    source 59
    target 192
    kind "relation"
    relation "dined with"
    weight 1
  ]
  edge [
    source 59
    target 476
    kind "relation"
    relation "sat and drank until"
    weight 1
  ]
  edge [
    source 59
    target 517
    kind "mentions"
  ]
  edge [
    source 59
    target 499
    kind "relation"
    relation "meets with | returns with"
    weight 2
  ]
  edge [
    source 59
    target 521
    kind "relation"
    relation "goes to"
    weight 1
  ]
  edge [
    source 59
    target 522
    kind "relation"
    relation "discourses with"
    weight 1
  ]
  edge [
    source 59
    target 500
    kind "relation"
    relation "is too expensive for | returns to"
    weight 2
  ]
  edge [
    source 59
    target 527
    kind "mentions"
  ]
  edge [
    source 59
    target 524
    kind "relation"
    relation "is abroad all morning on"
    weight 1
  ]
  edge [
    source 59
    target 529
    kind "relation"
    relation "handles"
    weight 1
  ]
  edge [
    source 59
    target 530
    kind "relation"
    relation "dines with | makes much of"
    weight 2
  ]
  edge [
    source 59
    target 122
    kind "relation"
    relation "goes to"
    weight 1
  ]
  edge [
    source 59
    target 535
    kind "relation"
    relation "meets with | takes | is very merry with"
    weight 3
  ]
  edge [
    source 59
    target 536
    kind "relation"
    relation "meets with | takes"
    weight 2
  ]
  edge [
    source 59
    target 537
    kind "relation"
    relation "goes to"
    weight 1
  ]
  edge [
    source 59
    target 539
    kind "relation"
    relation "drinks"
    weight 1
  ]
  edge [
    source 59
    target 525
    kind "relation"
    relation "returns home to find | brings great contentment to"
    weight 2
  ]
  edge [
    source 59
    target 541
    kind "mentions"
  ]
  edge [
    source 59
    target 543
    kind "relation"
    relation "goes with | is with | has dinner with"
    weight 3
  ]
  edge [
    source 59
    target 82
    kind "relation"
    relation "goes to"
    weight 1
  ]
  edge [
    source 59
    target 668
    kind "mentions"
  ]
  edge [
    source 59
    target 670
    kind "relation"
    relation "decided to stop giving money to"
    weight 1
  ]
  edge [
    source 59
    target 679
    kind "mentions"
  ]
  edge [
    source 59
    target 683
    kind "mentions"
  ]
  edge [
    source 59
    target 603
    kind "relation"
    relation "traveled by water with | walked with"
    weight 2
  ]
  edge [
    source 59
    target 307
    kind "relation"
    relation "met | reported to"
    weight 2
  ]
  edge [
    source 59
    target 684
    kind "mentions"
  ]
  edge [
    source 59
    target 685
    kind "relation"
    relation "went to"
    weight 1
  ]
  edge [
    source 59
    target 686
    kind "relation"
    relation "saw"
    weight 1
  ]
  edge [
    source 59
    target 687
    kind "relation"
    relation "hummed | came upon"
    weight 2
  ]
  edge [
    source 59
    target 688
    kind "mentions"
  ]
  edge [
    source 59
    target 834
    kind "mentions"
  ]
  edge [
    source 59
    target 585
    kind "relation"
    relation "are in confusion and poorly sorted | frustrates"
    weight 2
  ]
  edge [
    source 59
    target 838
    kind "relation"
    relation "contributes to mental strain"
    weight 1
  ]
  edge [
    source 59
    target 839
    kind "relation"
    relation "contributes to mental strain"
    weight 1
  ]
  edge [
    source 59
    target 840
    kind "relation"
    relation "bite at night and cause trouble"
    weight 1
  ]
  edge [
    source 59
    target 841
    kind "relation"
    relation "causes disappointment"
    weight 1
  ]
  edge [
    source 59
    target 842
    kind "relation"
    relation "causes mental strain"
    weight 1
  ]
  edge [
    source 59
    target 858
    kind "mentions"
  ]
  edge [
    source 59
    target 912
    kind "mentions"
  ]
  edge [
    source 59
    target 112
    kind "relation"
    relation "walked about fields with | would have gone with"
    weight 2
  ]
  edge [
    source 59
    target 929
    kind "mentions"
  ]
  edge [
    source 59
    target 290
    kind "relation"
    relation "traveled to"
    weight 1
  ]
  edge [
    source 59
    target 930
    kind "relation"
    relation "met | spoke with | could not reach agreement with"
    weight 3
  ]
  edge [
    source 59
    target 446
    kind "relation"
    relation "showed"
    weight 1
  ]
  edge [
    source 59
    target 1071
    kind "mentions"
  ]
  edge [
    source 59
    target 1077
    kind "relation"
    relation "spoke with"
    weight 1
  ]
  edge [
    source 59
    target 1094
    kind "mentions"
  ]
  edge [
    source 59
    target 1096
    kind "relation"
    relation "had friends with"
    weight 1
  ]
  edge [
    source 59
    target 1131
    kind "mentions"
  ]
  edge [
    source 59
    target 64
    kind "relation"
    relation "told"
    weight 1
  ]
  edge [
    source 59
    target 1136
    kind "relation"
    relation "found"
    weight 1
  ]
  edge [
    source 59
    target 1138
    kind "relation"
    relation "is troubled by"
    weight 1
  ]
  edge [
    source 59
    target 1146
    kind "mentions"
  ]
  edge [
    source 59
    target 240
    kind "relation"
    relation "went to"
    weight 1
  ]
  edge [
    source 59
    target 497
    kind "relation"
    relation "went to"
    weight 1
  ]
  edge [
    source 59
    target 1158
    kind "mentions"
  ]
  edge [
    source 59
    target 248
    kind "relation"
    relation "met"
    weight 1
  ]
  edge [
    source 59
    target 294
    kind "relation"
    relation "dined with"
    weight 1
  ]
  edge [
    source 59
    target 560
    kind "relation"
    relation "met"
    weight 1
  ]
  edge [
    source 59
    target 1238
    kind "mentions"
  ]
  edge [
    source 59
    target 1241
    kind "mentions"
  ]
  edge [
    source 59
    target 1242
    kind "relation"
    relation "stayed at"
    weight 1
  ]
  edge [
    source 59
    target 1243
    kind "relation"
    relation "rode without any coat"
    weight 1
  ]
  edge [
    source 59
    target 1246
    kind "mentions"
  ]
  edge [
    source 59
    target 1252
    kind "relation"
    relation "finds his father"
    weight 1
  ]
  edge [
    source 59
    target 297
    kind "relation"
    relation "learns that his aunt has left | feels very quiet and content in"
    weight 2
  ]
  edge [
    source 59
    target 1253
    kind "relation"
    relation "is glad about | spends l10"
    weight 2
  ]
  edge [
    source 59
    target 1255
    kind "mentions"
  ]
  edge [
    source 59
    target 1250
    kind "relation"
    relation "meets at"
    weight 1
  ]
  edge [
    source 59
    target 1258
    kind "relation"
    relation "has a great deal of discourse with"
    weight 1
  ]
  edge [
    source 59
    target 1251
    kind "relation"
    relation "is greatly satisfied by"
    weight 1
  ]
  edge [
    source 59
    target 1501
    kind "mentions"
  ]
  edge [
    source 59
    target 1502
    kind "relation"
    relation "is invited by"
    weight 1
  ]
  edge [
    source 59
    target 1295
    kind "relation"
    relation "is sent to"
    weight 1
  ]
  edge [
    source 59
    target 1887
    kind "mentions"
  ]
  edge [
    source 59
    target 316
    kind "relation"
    relation "could not remember"
    weight 1
  ]
  edge [
    source 59
    target 1888
    kind "mentions"
  ]
  edge [
    source 59
    target 1893
    kind "mentions"
  ]
  edge [
    source 59
    target 1894
    kind "mentions"
  ]
  edge [
    source 59
    target 689
    kind "relation"
    relation "found wife not sick but"
    weight 1
  ]
  edge [
    source 59
    target 1895
    kind "mentions"
  ]
  edge [
    source 59
    target 1896
    kind "relation"
    relation "found brother john not as ill as thought"
    weight 1
  ]
  edge [
    source 59
    target 1897
    kind "mentions"
  ]
  edge [
    source 59
    target 865
    kind "relation"
    relation "was vexed by"
    weight 1
  ]
  edge [
    source 59
    target 1899
    kind "mentions"
  ]
  edge [
    source 59
    target 186
    kind "relation"
    relation "was shocked by"
    weight 1
  ]
  edge [
    source 61
    target 74
    kind "relation"
    relation "freely promises to do"
    weight 1
  ]
  edge [
    source 61
    target 79
    kind "mentions"
  ]
  edge [
    source 61
    target 86
    kind "mentions"
  ]
  edge [
    source 61
    target 94
    kind "relation"
    relation "wishes for"
    weight 1
  ]
  edge [
    source 61
    target 191
    kind "mentions"
  ]
  edge [
    source 61
    target 196
    kind "relation"
    relation "did not find | told | made | was made deputy with"
    weight 4
  ]
  edge [
    source 61
    target 198
    kind "mentions"
  ]
  edge [
    source 61
    target 237
    kind "mentions"
  ]
  edge [
    source 61
    target 238
    kind "relation"
    relation "went to sea with"
    weight 1
  ]
  edge [
    source 61
    target 250
    kind "relation"
    relation "was appointed embassador in the bringing over of"
    weight 2
  ]
  edge [
    source 61
    target 248
    kind "relation"
    relation "appointed | made | took leave of"
    weight 5
  ]
  edge [
    source 61
    target 257
    kind "mentions"
  ]
  edge [
    source 61
    target 391
    kind "mentions"
  ]
  edge [
    source 61
    target 62
    kind "relation"
    relation "traveled to"
    weight 1
  ]
  edge [
    source 61
    target 398
    kind "relation"
    relation "arrived at"
    weight 1
  ]
  edge [
    source 61
    target 393
    kind "relation"
    relation "met at"
    weight 1
  ]
  edge [
    source 61
    target 145
    kind "relation"
    relation "took leave of | thanked"
    weight 2
  ]
  edge [
    source 61
    target 392
    kind "relation"
    relation "went with | set sail with | dined with | went up to take leave of | gave his hand to | parted with | showed the greatest respect to"
    weight 7
  ]
  edge [
    source 61
    target 394
    kind "relation"
    relation "boarded | stayed at"
    weight 2
  ]
  edge [
    source 61
    target 400
    kind "relation"
    relation "became very angry because"
    weight 1
  ]
  edge [
    source 61
    target 396
    kind "relation"
    relation "gave | were fully charged"
    weight 2
  ]
  edge [
    source 61
    target 742
    kind "mentions"
  ]
  edge [
    source 61
    target 834
    kind "mentions"
  ]
  edge [
    source 61
    target 858
    kind "mentions"
  ]
  edge [
    source 61
    target 1273
    kind "mentions"
  ]
  edge [
    source 61
    target 1294
    kind "mentions"
  ]
  edge [
    source 61
    target 1295
    kind "relation"
    relation "did not arrive at"
    weight 1
  ]
  edge [
    source 61
    target 1296
    kind "relation"
    relation "were ill-treated by"
    weight 1
  ]
  edge [
    source 61
    target 1488
    kind "mentions"
  ]
  edge [
    source 61
    target 1472
    kind "relation"
    relation "was sent about a month ago"
    weight 1
  ]
  edge [
    source 61
    target 1716
    kind "mentions"
  ]
  edge [
    source 62
    target 141
    kind "mentions"
  ]
  edge [
    source 62
    target 191
    kind "mentions"
  ]
  edge [
    source 62
    target 196
    kind "relation"
    relation "went to"
    weight 1
  ]
  edge [
    source 62
    target 225
    kind "mentions"
  ]
  edge [
    source 62
    target 356
    kind "mentions"
  ]
  edge [
    source 62
    target 391
    kind "mentions"
  ]
  edge [
    source 62
    target 403
    kind "mentions"
  ]
  edge [
    source 62
    target 425
    kind "mentions"
  ]
  edge [
    source 62
    target 683
    kind "mentions"
  ]
  edge [
    source 62
    target 691
    kind "mentions"
  ]
  edge [
    source 62
    target 692
    kind "relation"
    relation "came to"
    weight 1
  ]
  edge [
    source 62
    target 1016
    kind "mentions"
  ]
  edge [
    source 62
    target 1273
    kind "mentions"
  ]
  edge [
    source 62
    target 1292
    kind "mentions"
  ]
  edge [
    source 62
    target 1434
    kind "mentions"
  ]
  edge [
    source 62
    target 1567
    kind "mentions"
  ]
  edge [
    source 62
    target 1573
    kind "relation"
    relation "went to"
    weight 1
  ]
  edge [
    source 64
    target 803
    kind "mentions"
  ]
  edge [
    source 64
    target 813
    kind "relation"
    relation "acted in behalf of"
    weight 2
  ]
  edge [
    source 64
    target 721
    kind "relation"
    relation "did not give anything to"
    weight 2
  ]
  edge [
    source 64
    target 830
    kind "mentions"
  ]
  edge [
    source 64
    target 987
    kind "mentions"
  ]
  edge [
    source 64
    target 1045
    kind "mentions"
  ]
  edge [
    source 64
    target 1050
    kind "relation"
    relation "had a great deal of tattle with"
    weight 1
  ]
  edge [
    source 64
    target 1131
    kind "mentions"
  ]
  edge [
    source 64
    target 1137
    kind "relation"
    relation "uses"
    weight 1
  ]
  edge [
    source 64
    target 1139
    kind "mentions"
  ]
  edge [
    source 64
    target 1140
    kind "relation"
    relation "is sent for to"
    weight 1
  ]
  edge [
    source 64
    target 1396
    kind "mentions"
  ]
  edge [
    source 64
    target 1400
    kind "relation"
    relation "has become"
    weight 1
  ]
  edge [
    source 64
    target 1582
    kind "mentions"
  ]
  edge [
    source 64
    target 732
    kind "relation"
    relation "have mother who is well"
    weight 1
  ]
  edge [
    source 64
    target 1600
    kind "mentions"
  ]
  edge [
    source 64
    target 1679
    kind "mentions"
  ]
  edge [
    source 64
    target 1765
    kind "mentions"
  ]
  edge [
    source 64
    target 112
    kind "relation"
    relation "was to settle matters for"
    weight 2
  ]
  edge [
    source 64
    target 1775
    kind "mentions"
  ]
  edge [
    source 67
    target 1542
    kind "mentions"
  ]
  edge [
    source 67
    target 1549
    kind "relation"
    relation "offered a proposal for"
    weight 2
  ]
  edge [
    source 67
    target 1556
    kind "mentions"
  ]
  edge [
    source 68
    target 79
    kind "mentions"
  ]
  edge [
    source 68
    target 95
    kind "mentions"
  ]
  edge [
    source 68
    target 141
    kind "mentions"
  ]
  edge [
    source 68
    target 161
    kind "mentions"
  ]
  edge [
    source 68
    target 189
    kind "mentions"
  ]
  edge [
    source 68
    target 191
    kind "mentions"
  ]
  edge [
    source 68
    target 196
    kind "relation"
    relation "went to | stayed at"
    weight 2
  ]
  edge [
    source 68
    target 293
    kind "mentions"
  ]
  edge [
    source 68
    target 305
    kind "mentions"
  ]
  edge [
    source 68
    target 312
    kind "relation"
    relation "is in a sad condition due to"
    weight 1
  ]
  edge [
    source 68
    target 313
    kind "relation"
    relation "are unable to serve"
    weight 1
  ]
  edge [
    source 68
    target 314
    kind "relation"
    relation "has low credit so that"
    weight 1
  ]
  edge [
    source 68
    target 315
    kind "mentions"
  ]
  edge [
    source 68
    target 471
    kind "mentions"
  ]
  edge [
    source 68
    target 496
    kind "mentions"
  ]
  edge [
    source 68
    target 517
    kind "mentions"
  ]
  edge [
    source 68
    target 564
    kind "mentions"
  ]
  edge [
    source 68
    target 566
    kind "relation"
    relation "had no office visit"
    weight 1
  ]
  edge [
    source 68
    target 605
    kind "mentions"
  ]
  edge [
    source 68
    target 640
    kind "mentions"
  ]
  edge [
    source 68
    target 700
    kind "mentions"
  ]
  edge [
    source 68
    target 742
    kind "mentions"
  ]
  edge [
    source 68
    target 775
    kind "mentions"
  ]
  edge [
    source 68
    target 1026
    kind "mentions"
  ]
  edge [
    source 68
    target 1055
    kind "mentions"
  ]
  edge [
    source 68
    target 1118
    kind "mentions"
  ]
  edge [
    source 68
    target 1126
    kind "mentions"
  ]
  edge [
    source 68
    target 1128
    kind "relation"
    relation "would be convenient to add to | is acquiring | is planning to acquire"
    weight 3
  ]
  edge [
    source 68
    target 1176
    kind "mentions"
  ]
  edge [
    source 68
    target 1196
    kind "mentions"
  ]
  edge [
    source 68
    target 1304
    kind "mentions"
  ]
  edge [
    source 68
    target 1308
    kind "relation"
    relation "was visited by"
    weight 1
  ]
  edge [
    source 68
    target 1369
    kind "mentions"
  ]
  edge [
    source 68
    target 1448
    kind "mentions"
  ]
  edge [
    source 68
    target 1542
    kind "mentions"
  ]
  edge [
    source 68
    target 1123
    kind "relation"
    relation "agreed to add his house to | enlarged the quarters of"
    weight 2
  ]
  edge [
    source 68
    target 1623
    kind "mentions"
  ]
  edge [
    source 68
    target 1716
    kind "mentions"
  ]
  edge [
    source 68
    target 1765
    kind "mentions"
  ]
  edge [
    source 68
    target 1775
    kind "mentions"
  ]
  edge [
    source 68
    target 1782
    kind "mentions"
  ]
  edge [
    source 68
    target 1799
    kind "mentions"
  ]
  edge [
    source 68
    target 1840
    kind "mentions"
  ]
  edge [
    source 68
    target 1862
    kind "relation"
    relation "has lack of money"
    weight 1
  ]
  edge [
    source 68
    target 1867
    kind "mentions"
  ]
  edge [
    source 68
    target 1863
    kind "relation"
    relation "has bills offered for sale at"
    weight 1
  ]
  edge [
    source 68
    target 1868
    kind "relation"
    relation "believes acquisition will not happen"
    weight 1
  ]
  edge [
    source 71
    target 1585
    kind "mentions"
  ]
  edge [
    source 71
    target 1587
    kind "relation"
    relation "was in mourning | showed him great honour"
    weight 2
  ]
  edge [
    source 77
    target 1933
    kind "summarizes"
  ]
  edge [
    source 78
    target 79
    kind "from_chunk"
  ]
  edge [
    source 78
    target 86
    kind "from_chunk"
  ]
  edge [
    source 78
    target 95
    kind "from_chunk"
  ]
  edge [
    source 79
    target 80
    kind "mentions"
  ]
  edge [
    source 79
    target 81
    kind "mentions"
  ]
  edge [
    source 79
    target 82
    kind "mentions"
  ]
  edge [
    source 79
    target 83
    kind "mentions"
  ]
  edge [
    source 79
    target 84
    kind "mentions"
  ]
  edge [
    source 79
    target 85
    kind "mentions"
  ]
  edge [
    source 79
    target 1935
    kind "summarizes"
  ]
  edge [
    source 82
    target 191
    kind "mentions"
  ]
  edge [
    source 82
    target 196
    kind "relation"
    relation "returned to"
    weight 1
  ]
  edge [
    source 82
    target 315
    kind "mentions"
  ]
  edge [
    source 82
    target 403
    kind "mentions"
  ]
  edge [
    source 82
    target 480
    kind "mentions"
  ]
  edge [
    source 82
    target 511
    kind "mentions"
  ]
  edge [
    source 82
    target 517
    kind "mentions"
  ]
  edge [
    source 82
    target 541
    kind "mentions"
  ]
  edge [
    source 82
    target 564
    kind "mentions"
  ]
  edge [
    source 82
    target 567
    kind "relation"
    relation "began at"
    weight 1
  ]
  edge [
    source 82
    target 679
    kind "mentions"
  ]
  edge [
    source 82
    target 700
    kind "mentions"
  ]
  edge [
    source 82
    target 987
    kind "mentions"
  ]
  edge [
    source 82
    target 1045
    kind "mentions"
  ]
  edge [
    source 82
    target 1223
    kind "mentions"
  ]
  edge [
    source 82
    target 1314
    kind "mentions"
  ]
  edge [
    source 82
    target 1327
    kind "mentions"
  ]
  edge [
    source 82
    target 1436
    kind "mentions"
  ]
  edge [
    source 82
    target 1448
    kind "mentions"
  ]
  edge [
    source 82
    target 1585
    kind "mentions"
  ]
  edge [
    source 82
    target 888
    kind "relation"
    relation "was reached at"
    weight 1
  ]
  edge [
    source 82
    target 1623
    kind "mentions"
  ]
  edge [
    source 82
    target 1752
    kind "mentions"
  ]
  edge [
    source 83
    target 141
    kind "mentions"
  ]
  edge [
    source 84
    target 110
    kind "mentions"
  ]
  edge [
    source 84
    target 136
    kind "relation"
    relation "received l4"
    weight 1
  ]
  edge [
    source 84
    target 137
    kind "mentions"
  ]
  edge [
    source 84
    target 139
    kind "relation"
    relation "spent l4 on"
    weight 1
  ]
  edge [
    source 84
    target 141
    kind "mentions"
  ]
  edge [
    source 84
    target 225
    kind "mentions"
  ]
  edge [
    source 84
    target 226
    kind "relation"
    relation "wore"
    weight 1
  ]
  edge [
    source 84
    target 228
    kind "relation"
    relation "appeared very pretty"
    weight 1
  ]
  edge [
    source 84
    target 480
    kind "mentions"
  ]
  edge [
    source 84
    target 541
    kind "mentions"
  ]
  edge [
    source 84
    target 572
    kind "mentions"
  ]
  edge [
    source 84
    target 573
    kind "relation"
    relation "came to see"
    weight 1
  ]
  edge [
    source 84
    target 580
    kind "relation"
    relation "has a swollen belly"
    weight 1
  ]
  edge [
    source 84
    target 679
    kind "mentions"
  ]
  edge [
    source 84
    target 683
    kind "mentions"
  ]
  edge [
    source 84
    target 688
    kind "mentions"
  ]
  edge [
    source 84
    target 689
    kind "relation"
    relation "was not sick but"
    weight 1
  ]
  edge [
    source 84
    target 690
    kind "relation"
    relation "might become"
    weight 1
  ]
  edge [
    source 84
    target 934
    kind "mentions"
  ]
  edge [
    source 84
    target 958
    kind "mentions"
  ]
  edge [
    source 84
    target 1016
    kind "mentions"
  ]
  edge [
    source 84
    target 1026
    kind "mentions"
  ]
  edge [
    source 84
    target 192
    kind "relation"
    relation "showed"
    weight 1
  ]
  edge [
    source 84
    target 1045
    kind "mentions"
  ]
  edge [
    source 84
    target 1071
    kind "mentions"
  ]
  edge [
    source 84
    target 1094
    kind "mentions"
  ]
  edge [
    source 84
    target 1118
    kind "mentions"
  ]
  edge [
    source 84
    target 1327
    kind "mentions"
  ]
  edge [
    source 84
    target 1330
    kind "relation"
    relation "heard that"
    weight 1
  ]
  edge [
    source 84
    target 1328
    kind "relation"
    relation "is not yet delivered"
    weight 1
  ]
  edge [
    source 84
    target 1331
    kind "mentions"
  ]
  edge [
    source 84
    target 921
    kind "relation"
    relation "hired"
    weight 1
  ]
  edge [
    source 84
    target 1374
    kind "mentions"
  ]
  edge [
    source 84
    target 1388
    kind "mentions"
  ]
  edge [
    source 84
    target 1393
    kind "mentions"
  ]
  edge [
    source 84
    target 1485
    kind "mentions"
  ]
  edge [
    source 84
    target 1742
    kind "mentions"
  ]
  edge [
    source 84
    target 1751
    kind "relation"
    relation "told | told the narrator with tears"
    weight 2
  ]
  edge [
    source 84
    target 1782
    kind "mentions"
  ]
  edge [
    source 84
    target 1787
    kind "relation"
    relation "met"
    weight 1
  ]
  edge [
    source 84
    target 1816
    kind "mentions"
  ]
  edge [
    source 84
    target 1889
    kind "mentions"
  ]
  edge [
    source 84
    target 1894
    kind "mentions"
  ]
  edge [
    source 84
    target 1910
    kind "mentions"
  ]
  edge [
    source 84
    target 1903
    kind "relation"
    relation "looked askew upon"
    weight 1
  ]
  edge [
    source 84
    target 1911
    kind "relation"
    relation "did not buckle to"
    weight 1
  ]
  edge [
    source 85
    target 141
    kind "mentions"
  ]
  edge [
    source 85
    target 191
    kind "mentions"
  ]
  edge [
    source 85
    target 196
    kind "relation"
    relation "went to"
    weight 1
  ]
  edge [
    source 85
    target 315
    kind "mentions"
  ]
  edge [
    source 85
    target 428
    kind "mentions"
  ]
  edge [
    source 85
    target 688
    kind "mentions"
  ]
  edge [
    source 85
    target 783
    kind "mentions"
  ]
  edge [
    source 85
    target 609
    kind "relation"
    relation "was found in"
    weight 1
  ]
  edge [
    source 85
    target 803
    kind "mentions"
  ]
  edge [
    source 85
    target 1585
    kind "mentions"
  ]
  edge [
    source 85
    target 1897
    kind "mentions"
  ]
  edge [
    source 86
    target 87
    kind "mentions"
  ]
  edge [
    source 86
    target 88
    kind "mentions"
  ]
  edge [
    source 86
    target 89
    kind "mentions"
  ]
  edge [
    source 86
    target 90
    kind "mentions"
  ]
  edge [
    source 86
    target 91
    kind "mentions"
  ]
  edge [
    source 86
    target 92
    kind "mentions"
  ]
  edge [
    source 86
    target 93
    kind "mentions"
  ]
  edge [
    source 86
    target 94
    kind "mentions"
  ]
  edge [
    source 86
    target 1942
    kind "summarizes"
  ]
  edge [
    source 90
    target 1716
    kind "mentions"
  ]
  edge [
    source 91
    target 1512
    kind "mentions"
  ]
  edge [
    source 91
    target 1716
    kind "mentions"
  ]
  edge [
    source 91
    target 1078
    kind "relation"
    relation "was on way to"
    weight 1
  ]
  edge [
    source 91
    target 1782
    kind "mentions"
  ]
  edge [
    source 91
    target 1787
    kind "relation"
    relation "was known to"
    weight 1
  ]
  edge [
    source 92
    target 93
    kind "relation"
    relation "is not in"
    weight 1
  ]
  edge [
    source 95
    target 96
    kind "mentions"
  ]
  edge [
    source 95
    target 97
    kind "mentions"
  ]
  edge [
    source 95
    target 98
    kind "mentions"
  ]
  edge [
    source 95
    target 99
    kind "mentions"
  ]
  edge [
    source 95
    target 100
    kind "mentions"
  ]
  edge [
    source 95
    target 101
    kind "mentions"
  ]
  edge [
    source 95
    target 102
    kind "mentions"
  ]
  edge [
    source 95
    target 103
    kind "mentions"
  ]
  edge [
    source 95
    target 104
    kind "mentions"
  ]
  edge [
    source 95
    target 105
    kind "mentions"
  ]
  edge [
    source 95
    target 106
    kind "mentions"
  ]
  edge [
    source 95
    target 107
    kind "mentions"
  ]
  edge [
    source 95
    target 108
    kind "mentions"
  ]
  edge [
    source 95
    target 1939
    kind "summarizes"
  ]
  edge [
    source 96
    target 97
    kind "relation"
    relation "wants to take"
    weight 1
  ]
  edge [
    source 96
    target 106
    kind "relation"
    relation "wants to have"
    weight 1
  ]
  edge [
    source 96
    target 107
    kind "relation"
    relation "wants to have"
    weight 1
  ]
  edge [
    source 96
    target 108
    kind "relation"
    relation "wants to have"
    weight 1
  ]
  edge [
    source 96
    target 742
    kind "mentions"
  ]
  edge [
    source 96
    target 1623
    kind "mentions"
  ]
  edge [
    source 96
    target 1628
    kind "relation"
    relation "went to"
    weight 1
  ]
  edge [
    source 96
    target 297
    kind "relation"
    relation "viewed"
    weight 1
  ]
  edge [
    source 98
    target 803
    kind "mentions"
  ]
  edge [
    source 98
    target 809
    kind "relation"
    relation "delivered"
    weight 1
  ]
  edge [
    source 98
    target 861
    kind "mentions"
  ]
  edge [
    source 101
    target 356
    kind "mentions"
  ]
  edge [
    source 101
    target 1098
    kind "mentions"
  ]
  edge [
    source 103
    target 1436
    kind "mentions"
  ]
  edge [
    source 103
    target 1441
    kind "relation"
    relation "was reader at"
    weight 1
  ]
  edge [
    source 104
    target 568
    kind "mentions"
  ]
  edge [
    source 104
    target 559
    kind "relation"
    relation "stayed overnight at"
    weight 1
  ]
  edge [
    source 104
    target 605
    kind "mentions"
  ]
  edge [
    source 104
    target 613
    kind "mentions"
  ]
  edge [
    source 104
    target 1327
    kind "mentions"
  ]
  edge [
    source 104
    target 1369
    kind "mentions"
  ]
  edge [
    source 104
    target 1393
    kind "mentions"
  ]
  edge [
    source 104
    target 1582
    kind "mentions"
  ]
  edge [
    source 104
    target 1600
    kind "mentions"
  ]
  edge [
    source 104
    target 1742
    kind "mentions"
  ]
  edge [
    source 109
    target 110
    kind "from_chunk"
  ]
  edge [
    source 109
    target 137
    kind "from_chunk"
  ]
  edge [
    source 110
    target 111
    kind "mentions"
  ]
  edge [
    source 110
    target 112
    kind "mentions"
  ]
  edge [
    source 110
    target 113
    kind "mentions"
  ]
  edge [
    source 110
    target 114
    kind "mentions"
  ]
  edge [
    source 110
    target 115
    kind "mentions"
  ]
  edge [
    source 110
    target 116
    kind "mentions"
  ]
  edge [
    source 110
    target 117
    kind "mentions"
  ]
  edge [
    source 110
    target 118
    kind "mentions"
  ]
  edge [
    source 110
    target 119
    kind "mentions"
  ]
  edge [
    source 110
    target 120
    kind "mentions"
  ]
  edge [
    source 110
    target 121
    kind "mentions"
  ]
  edge [
    source 110
    target 122
    kind "mentions"
  ]
  edge [
    source 110
    target 123
    kind "mentions"
  ]
  edge [
    source 110
    target 124
    kind "mentions"
  ]
  edge [
    source 110
    target 125
    kind "mentions"
  ]
  edge [
    source 110
    target 126
    kind "mentions"
  ]
  edge [
    source 110
    target 127
    kind "mentions"
  ]
  edge [
    source 110
    target 128
    kind "mentions"
  ]
  edge [
    source 110
    target 129
    kind "mentions"
  ]
  edge [
    source 110
    target 130
    kind "mentions"
  ]
  edge [
    source 110
    target 131
    kind "mentions"
  ]
  edge [
    source 110
    target 132
    kind "mentions"
  ]
  edge [
    source 110
    target 133
    kind "mentions"
  ]
  edge [
    source 110
    target 134
    kind "mentions"
  ]
  edge [
    source 110
    target 135
    kind "mentions"
  ]
  edge [
    source 110
    target 136
    kind "mentions"
  ]
  edge [
    source 110
    target 1943
    kind "summarizes"
  ]
  edge [
    source 111
    target 114
    kind "relation"
    relation "took to"
    weight 1
  ]
  edge [
    source 111
    target 112
    kind "relation"
    relation "gave wine to"
    weight 1
  ]
  edge [
    source 111
    target 113
    kind "relation"
    relation "gave wine to"
    weight 1
  ]
  edge [
    source 111
    target 128
    kind "relation"
    relation "arranged for"
    weight 1
  ]
  edge [
    source 111
    target 132
    kind "relation"
    relation "described"
    weight 1
  ]
  edge [
    source 112
    target 434
    kind "mentions"
  ]
  edge [
    source 112
    target 496
    kind "mentions"
  ]
  edge [
    source 112
    target 511
    kind "mentions"
  ]
  edge [
    source 112
    target 547
    kind "mentions"
  ]
  edge [
    source 112
    target 564
    kind "mentions"
  ]
  edge [
    source 112
    target 297
    kind "relation"
    relation "came to see | was found within"
    weight 2
  ]
  edge [
    source 112
    target 572
    kind "mentions"
  ]
  edge [
    source 112
    target 454
    kind "relation"
    relation "visited"
    weight 1
  ]
  edge [
    source 112
    target 596
    kind "mentions"
  ]
  edge [
    source 112
    target 605
    kind "mentions"
  ]
  edge [
    source 112
    target 609
    kind "relation"
    relation "sent a letter to | sent letter to"
    weight 2
  ]
  edge [
    source 112
    target 611
    kind "relation"
    relation "decides to go"
    weight 1
  ]
  edge [
    source 112
    target 613
    kind "mentions"
  ]
  edge [
    source 112
    target 615
    kind "mentions"
  ]
  edge [
    source 112
    target 216
    kind "relation"
    relation "is going to visit | is going to help | saw"
    weight 3
  ]
  edge [
    source 112
    target 707
    kind "mentions"
  ]
  edge [
    source 112
    target 500
    kind "relation"
    relation "went to | returned from | left to go to"
    weight 5
  ]
  edge [
    source 112
    target 717
    kind "mentions"
  ]
  edge [
    source 112
    target 721
    kind "relation"
    relation "is sometimes stupid and like a man who is drunk | is sometimes speechless"
    weight 2
  ]
  edge [
    source 112
    target 742
    kind "mentions"
  ]
  edge [
    source 112
    target 766
    kind "mentions"
  ]
  edge [
    source 112
    target 783
    kind "mentions"
  ]
  edge [
    source 112
    target 794
    kind "relation"
    relation "was found in"
    weight 1
  ]
  edge [
    source 112
    target 784
    kind "relation"
    relation "gave nothing to | gave very little to"
    weight 4
  ]
  edge [
    source 112
    target 797
    kind "relation"
    relation "provided well for"
    weight 2
  ]
  edge [
    source 112
    target 798
    kind "relation"
    relation "provided well for"
    weight 2
  ]
  edge [
    source 112
    target 801
    kind "mentions"
  ]
  edge [
    source 112
    target 803
    kind "mentions"
  ]
  edge [
    source 112
    target 815
    kind "relation"
    relation "looked over"
    weight 1
  ]
  edge [
    source 112
    target 816
    kind "relation"
    relation "looked over"
    weight 1
  ]
  edge [
    source 112
    target 825
    kind "relation"
    relation "continued work"
    weight 1
  ]
  edge [
    source 112
    target 858
    kind "mentions"
  ]
  edge [
    source 112
    target 906
    kind "mentions"
  ]
  edge [
    source 112
    target 912
    kind "mentions"
  ]
  edge [
    source 112
    target 1007
    kind "mentions"
  ]
  edge [
    source 112
    target 1045
    kind "mentions"
  ]
  edge [
    source 112
    target 499
    kind "relation"
    relation "was discontented about | feels unacquainted with things or feels abandoned by"
    weight 2
  ]
  edge [
    source 112
    target 1118
    kind "mentions"
  ]
  edge [
    source 112
    target 1126
    kind "mentions"
  ]
  edge [
    source 112
    target 1129
    kind "relation"
    relation "intends to make profit from | wants to leave"
    weight 2
  ]
  edge [
    source 112
    target 1124
    kind "relation"
    relation "has no intention of setting up"
    weight 1
  ]
  edge [
    source 112
    target 1161
    kind "mentions"
  ]
  edge [
    source 112
    target 1246
    kind "mentions"
  ]
  edge [
    source 112
    target 1262
    kind "mentions"
  ]
  edge [
    source 112
    target 1268
    kind "relation"
    relation "noticed that"
    weight 1
  ]
  edge [
    source 112
    target 1269
    kind "relation"
    relation "had never seen or heard of"
    weight 1
  ]
  edge [
    source 112
    target 1273
    kind "mentions"
  ]
  edge [
    source 112
    target 1327
    kind "mentions"
  ]
  edge [
    source 112
    target 1329
    kind "relation"
    relation "is in good health"
    weight 1
  ]
  edge [
    source 112
    target 1331
    kind "mentions"
  ]
  edge [
    source 112
    target 1369
    kind "mentions"
  ]
  edge [
    source 112
    target 1393
    kind "mentions"
  ]
  edge [
    source 112
    target 1394
    kind "relation"
    relation "is settling papers for"
    weight 1
  ]
  edge [
    source 112
    target 1396
    kind "mentions"
  ]
  edge [
    source 112
    target 1397
    kind "relation"
    relation "visits to take leave of"
    weight 1
  ]
  edge [
    source 112
    target 332
    kind "relation"
    relation "is going to"
    weight 1
  ]
  edge [
    source 112
    target 1401
    kind "relation"
    relation "will have"
    weight 1
  ]
  edge [
    source 112
    target 1448
    kind "mentions"
  ]
  edge [
    source 112
    target 1449
    kind "relation"
    relation "dined with | went out with"
    weight 2
  ]
  edge [
    source 112
    target 1485
    kind "mentions"
  ]
  edge [
    source 112
    target 1501
    kind "mentions"
  ]
  edge [
    source 112
    target 1542
    kind "mentions"
  ]
  edge [
    source 112
    target 573
    kind "relation"
    relation "went to"
    weight 1
  ]
  edge [
    source 112
    target 1556
    kind "mentions"
  ]
  edge [
    source 112
    target 1585
    kind "mentions"
  ]
  edge [
    source 112
    target 1679
    kind "mentions"
  ]
  edge [
    source 112
    target 1681
    kind "relation"
    relation "had only | owed"
    weight 2
  ]
  edge [
    source 112
    target 308
    kind "relation"
    relation "had due to him in the world"
    weight 1
  ]
  edge [
    source 112
    target 1685
    kind "mentions"
  ]
  edge [
    source 112
    target 1686
    kind "relation"
    relation "gave good content to"
    weight 1
  ]
  edge [
    source 112
    target 1698
    kind "mentions"
  ]
  edge [
    source 112
    target 1250
    kind "relation"
    relation "was at"
    weight 1
  ]
  edge [
    source 112
    target 1699
    kind "relation"
    relation "will try his best"
    weight 1
  ]
  edge [
    source 112
    target 1701
    kind "relation"
    relation "are angry at"
    weight 1
  ]
  edge [
    source 112
    target 1765
    kind "mentions"
  ]
  edge [
    source 112
    target 1590
    kind "relation"
    relation "went about other business"
    weight 1
  ]
  edge [
    source 112
    target 1773
    kind "relation"
    relation "has no objection to"
    weight 2
  ]
  edge [
    source 112
    target 1774
    kind "relation"
    relation "believes the estate is too great to give"
    weight 2
  ]
  edge [
    source 112
    target 1775
    kind "mentions"
  ]
  edge [
    source 112
    target 1816
    kind "mentions"
  ]
  edge [
    source 112
    target 1838
    kind "mentions"
  ]
  edge [
    source 113
    target 1118
    kind "mentions"
  ]
  edge [
    source 113
    target 1126
    kind "mentions"
  ]
  edge [
    source 113
    target 1542
    kind "mentions"
  ]
  edge [
    source 113
    target 1556
    kind "mentions"
  ]
  edge [
    source 113
    target 1816
    kind "mentions"
  ]
  edge [
    source 113
    target 1835
    kind "relation"
    relation "is now left to keep | is responsible for"
    weight 2
  ]
  edge [
    source 113
    target 1837
    kind "relation"
    relation "will miscarry due to"
    weight 2
  ]
  edge [
    source 113
    target 1838
    kind "mentions"
  ]
  edge [
    source 115
    target 1525
    kind "mentions"
  ]
  edge [
    source 119
    target 120
    kind "relation"
    relation "waited upon | made sit in his place"
    weight 2
  ]
  edge [
    source 120
    target 133
    kind "relation"
    relation "rose from table when"
    weight 1
  ]
  edge [
    source 120
    target 134
    kind "relation"
    relation "took a lower seat"
    weight 1
  ]
  edge [
    source 122
    target 198
    kind "mentions"
  ]
  edge [
    source 122
    target 527
    kind "mentions"
  ]
  edge [
    source 122
    target 532
    kind "relation"
    relation "has a performance of"
    weight 1
  ]
  edge [
    source 122
    target 742
    kind "mentions"
  ]
  edge [
    source 122
    target 757
    kind "relation"
    relation "used to be thronged"
    weight 1
  ]
  edge [
    source 122
    target 758
    kind "relation"
    relation "is now empty since"
    weight 1
  ]
  edge [
    source 122
    target 759
    kind "relation"
    relation "will remain empty for"
    weight 1
  ]
  edge [
    source 122
    target 987
    kind "mentions"
  ]
  edge [
    source 122
    target 1045
    kind "mentions"
  ]
  edge [
    source 122
    target 1176
    kind "mentions"
  ]
  edge [
    source 122
    target 1343
    kind "mentions"
  ]
  edge [
    source 122
    target 1688
    kind "mentions"
  ]
  edge [
    source 122
    target 1716
    kind "mentions"
  ]
  edge [
    source 122
    target 1622
    kind "relation"
    relation "went to"
    weight 1
  ]
  edge [
    source 122
    target 1740
    kind "mentions"
  ]
  edge [
    source 126
    target 137
    kind "mentions"
  ]
  edge [
    source 126
    target 141
    kind "mentions"
  ]
  edge [
    source 127
    target 137
    kind "mentions"
  ]
  edge [
    source 129
    target 130
    kind "relation"
    relation "discussed"
    weight 1
  ]
  edge [
    source 129
    target 434
    kind "mentions"
  ]
  edge [
    source 129
    target 437
    kind "relation"
    relation "resolved to buy"
    weight 1
  ]
  edge [
    source 129
    target 438
    kind "relation"
    relation "resolved to buy"
    weight 1
  ]
  edge [
    source 129
    target 439
    kind "relation"
    relation "resolved to buy"
    weight 1
  ]
  edge [
    source 129
    target 440
    kind "relation"
    relation "resolved to buy"
    weight 1
  ]
  edge [
    source 130
    target 131
    kind "relation"
    relation "is considered as honourable as"
    weight 1
  ]
  edge [
    source 135
    target 161
    kind "mentions"
  ]
  edge [
    source 135
    target 189
    kind "mentions"
  ]
  edge [
    source 135
    target 315
    kind "mentions"
  ]
  edge [
    source 135
    target 803
    kind "mentions"
  ]
  edge [
    source 135
    target 824
    kind "relation"
    relation "fell to work"
    weight 1
  ]
  edge [
    source 135
    target 1210
    kind "mentions"
  ]
  edge [
    source 135
    target 1219
    kind "mentions"
  ]
  edge [
    source 137
    target 138
    kind "mentions"
  ]
  edge [
    source 137
    target 139
    kind "mentions"
  ]
  edge [
    source 137
    target 1943
    kind "summarizes"
  ]
  edge [
    source 138
    target 803
    kind "mentions"
  ]
  edge [
    source 138
    target 822
    kind "relation"
    relation "served"
    weight 1
  ]
  edge [
    source 140
    target 141
    kind "from_chunk"
  ]
  edge [
    source 140
    target 158
    kind "from_chunk"
  ]
  edge [
    source 141
    target 142
    kind "mentions"
  ]
  edge [
    source 141
    target 143
    kind "mentions"
  ]
  edge [
    source 141
    target 144
    kind "mentions"
  ]
  edge [
    source 141
    target 145
    kind "mentions"
  ]
  edge [
    source 141
    target 146
    kind "mentions"
  ]
  edge [
    source 141
    target 147
    kind "mentions"
  ]
  edge [
    source 141
    target 148
    kind "mentions"
  ]
  edge [
    source 141
    target 149
    kind "mentions"
  ]
  edge [
    source 141
    target 150
    kind "mentions"
  ]
  edge [
    source 141
    target 151
    kind "mentions"
  ]
  edge [
    source 141
    target 152
    kind "mentions"
  ]
  edge [
    source 141
    target 153
    kind "mentions"
  ]
  edge [
    source 141
    target 154
    kind "mentions"
  ]
  edge [
    source 141
    target 155
    kind "mentions"
  ]
  edge [
    source 141
    target 156
    kind "mentions"
  ]
  edge [
    source 141
    target 157
    kind "mentions"
  ]
  edge [
    source 141
    target 1935
    kind "summarizes"
  ]
  edge [
    source 142
    target 356
    kind "mentions"
  ]
  edge [
    source 142
    target 364
    kind "relation"
    relation "landed"
    weight 1
  ]
  edge [
    source 142
    target 471
    kind "mentions"
  ]
  edge [
    source 142
    target 472
    kind "relation"
    relation "stayed and went to"
    weight 1
  ]
  edge [
    source 142
    target 605
    kind "mentions"
  ]
  edge [
    source 142
    target 740
    kind "mentions"
  ]
  edge [
    source 142
    target 987
    kind "mentions"
  ]
  edge [
    source 142
    target 1069
    kind "mentions"
  ]
  edge [
    source 142
    target 1071
    kind "mentions"
  ]
  edge [
    source 142
    target 1542
    kind "mentions"
  ]
  edge [
    source 143
    target 269
    kind "mentions"
  ]
  edge [
    source 143
    target 280
    kind "mentions"
  ]
  edge [
    source 143
    target 287
    kind "relation"
    relation "is going to | dines at"
    weight 2
  ]
  edge [
    source 143
    target 288
    kind "relation"
    relation "is chosen as"
    weight 1
  ]
  edge [
    source 143
    target 1436
    kind "mentions"
  ]
  edge [
    source 145
    target 293
    kind "mentions"
  ]
  edge [
    source 145
    target 366
    kind "mentions"
  ]
  edge [
    source 145
    target 391
    kind "mentions"
  ]
  edge [
    source 145
    target 1118
    kind "mentions"
  ]
  edge [
    source 145
    target 1126
    kind "mentions"
  ]
  edge [
    source 150
    target 1742
    kind "mentions"
  ]
  edge [
    source 151
    target 707
    kind "mentions"
  ]
  edge [
    source 151
    target 709
    kind "relation"
    relation "causes"
    weight 1
  ]
  edge [
    source 153
    target 783
    kind "mentions"
  ]
  edge [
    source 153
    target 801
    kind "mentions"
  ]
  edge [
    source 155
    target 158
    kind "mentions"
  ]
  edge [
    source 156
    target 158
    kind "mentions"
  ]
  edge [
    source 157
    target 158
    kind "mentions"
  ]
  edge [
    source 158
    target 159
    kind "mentions"
  ]
  edge [
    source 158
    target 1935
    kind "summarizes"
  ]
  edge [
    source 160
    target 161
    kind "from_chunk"
  ]
  edge [
    source 160
    target 189
    kind "from_chunk"
  ]
  edge [
    source 161
    target 162
    kind "mentions"
  ]
  edge [
    source 161
    target 163
    kind "mentions"
  ]
  edge [
    source 161
    target 164
    kind "mentions"
  ]
  edge [
    source 161
    target 165
    kind "mentions"
  ]
  edge [
    source 161
    target 166
    kind "mentions"
  ]
  edge [
    source 161
    target 167
    kind "mentions"
  ]
  edge [
    source 161
    target 168
    kind "mentions"
  ]
  edge [
    source 161
    target 169
    kind "mentions"
  ]
  edge [
    source 161
    target 170
    kind "mentions"
  ]
  edge [
    source 161
    target 171
    kind "mentions"
  ]
  edge [
    source 161
    target 172
    kind "mentions"
  ]
  edge [
    source 161
    target 173
    kind "mentions"
  ]
  edge [
    source 161
    target 174
    kind "mentions"
  ]
  edge [
    source 161
    target 175
    kind "mentions"
  ]
  edge [
    source 161
    target 176
    kind "mentions"
  ]
  edge [
    source 161
    target 177
    kind "mentions"
  ]
  edge [
    source 161
    target 178
    kind "mentions"
  ]
  edge [
    source 161
    target 179
    kind "mentions"
  ]
  edge [
    source 161
    target 180
    kind "mentions"
  ]
  edge [
    source 161
    target 181
    kind "mentions"
  ]
  edge [
    source 161
    target 182
    kind "mentions"
  ]
  edge [
    source 161
    target 183
    kind "mentions"
  ]
  edge [
    source 161
    target 184
    kind "mentions"
  ]
  edge [
    source 161
    target 185
    kind "mentions"
  ]
  edge [
    source 161
    target 186
    kind "mentions"
  ]
  edge [
    source 161
    target 187
    kind "mentions"
  ]
  edge [
    source 161
    target 188
    kind "mentions"
  ]
  edge [
    source 161
    target 1940
    kind "summarizes"
  ]
  edge [
    source 162
    target 180
    kind "relation"
    relation "was promoted to"
    weight 2
  ]
  edge [
    source 162
    target 181
    kind "relation"
    relation "answered questions about"
    weight 2
  ]
  edge [
    source 162
    target 189
    kind "mentions"
  ]
  edge [
    source 163
    target 189
    kind "mentions"
  ]
  edge [
    source 164
    target 189
    kind "mentions"
  ]
  edge [
    source 165
    target 189
    kind "mentions"
  ]
  edge [
    source 165
    target 403
    kind "mentions"
  ]
  edge [
    source 165
    target 406
    kind "relation"
    relation "had the king in"
    weight 1
  ]
  edge [
    source 166
    target 189
    kind "mentions"
  ]
  edge [
    source 167
    target 168
    kind "relation"
    relation "kept time to"
    weight 2
  ]
  edge [
    source 167
    target 189
    kind "mentions"
  ]
  edge [
    source 168
    target 189
    kind "mentions"
  ]
  edge [
    source 169
    target 184
    kind "relation"
    relation "was described as"
    weight 2
  ]
  edge [
    source 169
    target 189
    kind "mentions"
  ]
  edge [
    source 170
    target 189
    kind "mentions"
  ]
  edge [
    source 171
    target 172
    kind "relation"
    relation "had wife | had mother"
    weight 4
  ]
  edge [
    source 171
    target 173
    kind "relation"
    relation "came to see"
    weight 2
  ]
  edge [
    source 171
    target 189
    kind "mentions"
  ]
  edge [
    source 172
    target 189
    kind "mentions"
  ]
  edge [
    source 173
    target 189
    kind "mentions"
  ]
  edge [
    source 174
    target 185
    kind "relation"
    relation "played"
    weight 2
  ]
  edge [
    source 174
    target 189
    kind "mentions"
  ]
  edge [
    source 175
    target 189
    kind "mentions"
  ]
  edge [
    source 175
    target 191
    kind "mentions"
  ]
  edge [
    source 175
    target 196
    kind "relation"
    relation "left off"
    weight 1
  ]
  edge [
    source 176
    target 188
    kind "relation"
    relation "was"
    weight 4
  ]
  edge [
    source 176
    target 189
    kind "mentions"
  ]
  edge [
    source 176
    target 191
    kind "mentions"
  ]
  edge [
    source 176
    target 694
    kind "mentions"
  ]
  edge [
    source 176
    target 695
    kind "relation"
    relation "was"
    weight 1
  ]
  edge [
    source 177
    target 189
    kind "mentions"
  ]
  edge [
    source 177
    target 779
    kind "mentions"
  ]
  edge [
    source 177
    target 216
    kind "relation"
    relation "died"
    weight 1
  ]
  edge [
    source 177
    target 1262
    kind "mentions"
  ]
  edge [
    source 178
    target 189
    kind "mentions"
  ]
  edge [
    source 178
    target 801
    kind "mentions"
  ]
  edge [
    source 178
    target 1271
    kind "mentions"
  ]
  edge [
    source 178
    target 1273
    kind "mentions"
  ]
  edge [
    source 179
    target 189
    kind "mentions"
  ]
  edge [
    source 180
    target 189
    kind "mentions"
  ]
  edge [
    source 181
    target 189
    kind "mentions"
  ]
  edge [
    source 181
    target 640
    kind "mentions"
  ]
  edge [
    source 181
    target 659
    kind "mentions"
  ]
  edge [
    source 181
    target 683
    kind "mentions"
  ]
  edge [
    source 181
    target 413
    kind "relation"
    relation "could not get out of"
    weight 1
  ]
  edge [
    source 181
    target 467
    kind "relation"
    relation "was against"
    weight 1
  ]
  edge [
    source 181
    target 1098
    kind "mentions"
  ]
  edge [
    source 182
    target 189
    kind "mentions"
  ]
  edge [
    source 183
    target 189
    kind "mentions"
  ]
  edge [
    source 184
    target 189
    kind "mentions"
  ]
  edge [
    source 185
    target 189
    kind "mentions"
  ]
  edge [
    source 186
    target 187
    kind "relation"
    relation "cried up"
    weight 2
  ]
  edge [
    source 186
    target 189
    kind "mentions"
  ]
  edge [
    source 186
    target 1899
    kind "mentions"
  ]
  edge [
    source 186
    target 1902
    kind "mentions"
  ]
  edge [
    source 186
    target 1903
    kind "relation"
    relation "cried up"
    weight 1
  ]
  edge [
    source 187
    target 189
    kind "mentions"
  ]
  edge [
    source 188
    target 189
    kind "mentions"
  ]
  edge [
    source 188
    target 191
    kind "mentions"
  ]
  edge [
    source 188
    target 694
    kind "mentions"
  ]
  edge [
    source 189
    target 1940
    kind "summarizes"
  ]
  edge [
    source 190
    target 191
    kind "from_chunk"
  ]
  edge [
    source 190
    target 198
    kind "from_chunk"
  ]
  edge [
    source 191
    target 192
    kind "mentions"
  ]
  edge [
    source 191
    target 193
    kind "mentions"
  ]
  edge [
    source 191
    target 194
    kind "mentions"
  ]
  edge [
    source 191
    target 195
    kind "mentions"
  ]
  edge [
    source 191
    target 196
    kind "mentions"
  ]
  edge [
    source 191
    target 197
    kind "mentions"
  ]
  edge [
    source 191
    target 1940
    kind "summarizes"
  ]
  edge [
    source 192
    target 196
    kind "relation"
    relation "dined with | treated"
    weight 2
  ]
  edge [
    source 192
    target 195
    kind "relation"
    relation "was troubled with"
    weight 1
  ]
  edge [
    source 192
    target 471
    kind "mentions"
  ]
  edge [
    source 192
    target 547
    kind "mentions"
  ]
  edge [
    source 192
    target 742
    kind "mentions"
  ]
  edge [
    source 192
    target 743
    kind "relation"
    relation "is mourning"
    weight 1
  ]
  edge [
    source 192
    target 987
    kind "mentions"
  ]
  edge [
    source 192
    target 1026
    kind "mentions"
  ]
  edge [
    source 192
    target 1273
    kind "mentions"
  ]
  edge [
    source 192
    target 1292
    kind "mentions"
  ]
  edge [
    source 192
    target 1294
    kind "mentions"
  ]
  edge [
    source 192
    target 1493
    kind "mentions"
  ]
  edge [
    source 192
    target 1542
    kind "mentions"
  ]
  edge [
    source 192
    target 295
    kind "relation"
    relation "keeps the children at home"
    weight 1
  ]
  edge [
    source 192
    target 1716
    kind "mentions"
  ]
  edge [
    source 192
    target 1782
    kind "mentions"
  ]
  edge [
    source 192
    target 1802
    kind "mentions"
  ]
  edge [
    source 192
    target 1812
    kind "relation"
    relation "told | told the story with innocence | sweated while telling | demonstrated simplicity and harmlessness"
    weight 7
  ]
  edge [
    source 192
    target 1814
    kind "mentions"
  ]
  edge [
    source 193
    target 194
    kind "relation"
    relation "arrived from"
    weight 1
  ]
  edge [
    source 196
    target 197
    kind "relation"
    relation "went to | stayed at"
    weight 2
  ]
  edge [
    source 196
    target 198
    kind "mentions"
  ]
  edge [
    source 196
    target 206
    kind "relation"
    relation "found"
    weight 1
  ]
  edge [
    source 196
    target 202
    kind "relation"
    relation "went to"
    weight 1
  ]
  edge [
    source 196
    target 203
    kind "relation"
    relation "dined with"
    weight 1
  ]
  edge [
    source 196
    target 201
    kind "relation"
    relation "saw"
    weight 1
  ]
  edge [
    source 196
    target 211
    kind "relation"
    relation "went to"
    weight 1
  ]
  edge [
    source 196
    target 212
    kind "relation"
    relation "went up to"
    weight 1
  ]
  edge [
    source 196
    target 205
    kind "relation"
    relation "sat drinking"
    weight 1
  ]
  edge [
    source 196
    target 1889
    kind "mentions"
  ]
  edge [
    source 196
    target 383
    kind "relation"
    relation "was worn by"
    weight 1
  ]
  edge [
    source 198
    target 199
    kind "mentions"
  ]
  edge [
    source 198
    target 200
    kind "mentions"
  ]
  edge [
    source 198
    target 201
    kind "mentions"
  ]
  edge [
    source 198
    target 202
    kind "mentions"
  ]
  edge [
    source 198
    target 203
    kind "mentions"
  ]
  edge [
    source 198
    target 204
    kind "mentions"
  ]
  edge [
    source 198
    target 205
    kind "mentions"
  ]
  edge [
    source 198
    target 206
    kind "mentions"
  ]
  edge [
    source 198
    target 207
    kind "mentions"
  ]
  edge [
    source 198
    target 208
    kind "mentions"
  ]
  edge [
    source 198
    target 209
    kind "mentions"
  ]
  edge [
    source 198
    target 210
    kind "mentions"
  ]
  edge [
    source 198
    target 211
    kind "mentions"
  ]
  edge [
    source 198
    target 212
    kind "mentions"
  ]
  edge [
    source 198
    target 1942
    kind "summarizes"
  ]
  edge [
    source 199
    target 803
    kind "mentions"
  ]
  edge [
    source 199
    target 1273
    kind "mentions"
  ]
  edge [
    source 199
    target 1292
    kind "mentions"
  ]
  edge [
    source 201
    target 207
    kind "relation"
    relation "was first performed"
    weight 1
  ]
  edge [
    source 201
    target 208
    kind "relation"
    relation "was"
    weight 1
  ]
  edge [
    source 201
    target 209
    kind "relation"
    relation "was"
    weight 1
  ]
  edge [
    source 201
    target 210
    kind "relation"
    relation "was"
    weight 1
  ]
  edge [
    source 201
    target 615
    kind "mentions"
  ]
  edge [
    source 201
    target 634
    kind "relation"
    relation "saw"
    weight 1
  ]
  edge [
    source 202
    target 1615
    kind "mentions"
  ]
  edge [
    source 205
    target 280
    kind "mentions"
  ]
  edge [
    source 205
    target 281
    kind "relation"
    relation "drinks"
    weight 1
  ]
  edge [
    source 206
    target 1919
    kind "mentions"
  ]
  edge [
    source 213
    target 214
    kind "from_chunk"
  ]
  edge [
    source 213
    target 225
    kind "from_chunk"
  ]
  edge [
    source 214
    target 215
    kind "mentions"
  ]
  edge [
    source 214
    target 216
    kind "mentions"
  ]
  edge [
    source 214
    target 217
    kind "mentions"
  ]
  edge [
    source 214
    target 218
    kind "mentions"
  ]
  edge [
    source 214
    target 219
    kind "mentions"
  ]
  edge [
    source 214
    target 220
    kind "mentions"
  ]
  edge [
    source 214
    target 221
    kind "mentions"
  ]
  edge [
    source 214
    target 222
    kind "mentions"
  ]
  edge [
    source 214
    target 223
    kind "mentions"
  ]
  edge [
    source 214
    target 224
    kind "mentions"
  ]
  edge [
    source 214
    target 1936
    kind "summarizes"
  ]
  edge [
    source 215
    target 222
    kind "relation"
    relation "advised the narrator to"
    weight 1
  ]
  edge [
    source 215
    target 223
    kind "relation"
    relation "stated the reason for advice is"
    weight 1
  ]
  edge [
    source 215
    target 1396
    kind "mentions"
  ]
  edge [
    source 216
    target 605
    kind "mentions"
  ]
  edge [
    source 216
    target 607
    kind "relation"
    relation "is suffering from"
    weight 1
  ]
  edge [
    source 216
    target 610
    kind "relation"
    relation "desires"
    weight 1
  ]
  edge [
    source 216
    target 615
    kind "mentions"
  ]
  edge [
    source 216
    target 696
    kind "mentions"
  ]
  edge [
    source 216
    target 697
    kind "relation"
    relation "visited"
    weight 1
  ]
  edge [
    source 216
    target 698
    kind "relation"
    relation "was found to be"
    weight 1
  ]
  edge [
    source 216
    target 707
    kind "mentions"
  ]
  edge [
    source 216
    target 742
    kind "mentions"
  ]
  edge [
    source 216
    target 760
    kind "relation"
    relation "has fits of stupefaction for"
    weight 1
  ]
  edge [
    source 216
    target 766
    kind "mentions"
  ]
  edge [
    source 216
    target 779
    kind "mentions"
  ]
  edge [
    source 216
    target 1679
    kind "mentions"
  ]
  edge [
    source 221
    target 834
    kind "mentions"
  ]
  edge [
    source 221
    target 850
    kind "relation"
    relation "does not appear as"
    weight 1
  ]
  edge [
    source 221
    target 1026
    kind "mentions"
  ]
  edge [
    source 221
    target 1040
    kind "relation"
    relation "included annual income of"
    weight 1
  ]
  edge [
    source 221
    target 1181
    kind "mentions"
  ]
  edge [
    source 221
    target 1765
    kind "mentions"
  ]
  edge [
    source 221
    target 1775
    kind "mentions"
  ]
  edge [
    source 221
    target 1816
    kind "mentions"
  ]
  edge [
    source 225
    target 226
    kind "mentions"
  ]
  edge [
    source 225
    target 227
    kind "mentions"
  ]
  edge [
    source 225
    target 228
    kind "mentions"
  ]
  edge [
    source 225
    target 229
    kind "mentions"
  ]
  edge [
    source 225
    target 230
    kind "mentions"
  ]
  edge [
    source 225
    target 231
    kind "mentions"
  ]
  edge [
    source 225
    target 232
    kind "mentions"
  ]
  edge [
    source 225
    target 233
    kind "mentions"
  ]
  edge [
    source 225
    target 234
    kind "mentions"
  ]
  edge [
    source 225
    target 235
    kind "mentions"
  ]
  edge [
    source 225
    target 1952
    kind "summarizes"
  ]
  edge [
    source 226
    target 227
    kind "relation"
    relation "is laced with"
    weight 1
  ]
  edge [
    source 229
    target 232
    kind "relation"
    relation "walked to | dined at | were greatly admired at"
    weight 3
  ]
  edge [
    source 231
    target 233
    kind "relation"
    relation "remained very pretty"
    weight 1
  ]
  edge [
    source 232
    target 480
    kind "mentions"
  ]
  edge [
    source 232
    target 482
    kind "relation"
    relation "went by water to"
    weight 1
  ]
  edge [
    source 232
    target 487
    kind "relation"
    relation "stayed until"
    weight 1
  ]
  edge [
    source 232
    target 1393
    kind "mentions"
  ]
  edge [
    source 232
    target 585
    kind "relation"
    relation "are of difference between"
    weight 1
  ]
  edge [
    source 232
    target 1782
    kind "mentions"
  ]
  edge [
    source 232
    target 295
    kind "relation"
    relation "dined with"
    weight 1
  ]
  edge [
    source 232
    target 1796
    kind "relation"
    relation "went to"
    weight 1
  ]
  edge [
    source 232
    target 1797
    kind "relation"
    relation "talked and laughed"
    weight 1
  ]
  edge [
    source 232
    target 1783
    kind "relation"
    relation "went to"
    weight 1
  ]
  edge [
    source 234
    target 235
    kind "relation"
    relation "went on together"
    weight 1
  ]
  edge [
    source 236
    target 237
    kind "from_chunk"
  ]
  edge [
    source 236
    target 257
    kind "from_chunk"
  ]
  edge [
    source 237
    target 238
    kind "mentions"
  ]
  edge [
    source 237
    target 239
    kind "mentions"
  ]
  edge [
    source 237
    target 240
    kind "mentions"
  ]
  edge [
    source 237
    target 241
    kind "mentions"
  ]
  edge [
    source 237
    target 242
    kind "mentions"
  ]
  edge [
    source 237
    target 243
    kind "mentions"
  ]
  edge [
    source 237
    target 244
    kind "mentions"
  ]
  edge [
    source 237
    target 245
    kind "mentions"
  ]
  edge [
    source 237
    target 246
    kind "mentions"
  ]
  edge [
    source 237
    target 247
    kind "mentions"
  ]
  edge [
    source 237
    target 248
    kind "mentions"
  ]
  edge [
    source 237
    target 249
    kind "mentions"
  ]
  edge [
    source 237
    target 250
    kind "mentions"
  ]
  edge [
    source 237
    target 251
    kind "mentions"
  ]
  edge [
    source 237
    target 252
    kind "mentions"
  ]
  edge [
    source 237
    target 253
    kind "mentions"
  ]
  edge [
    source 237
    target 254
    kind "mentions"
  ]
  edge [
    source 237
    target 255
    kind "mentions"
  ]
  edge [
    source 237
    target 256
    kind "mentions"
  ]
  edge [
    source 237
    target 1942
    kind "summarizes"
  ]
  edge [
    source 238
    target 239
    kind "relation"
    relation "visited"
    weight 1
  ]
  edge [
    source 238
    target 241
    kind "relation"
    relation "met"
    weight 1
  ]
  edge [
    source 238
    target 242
    kind "relation"
    relation "discussed | would complain about"
    weight 2
  ]
  edge [
    source 238
    target 246
    kind "relation"
    relation "obtained a sculler with | sang with | took his wife and walked home with"
    weight 3
  ]
  edge [
    source 238
    target 245
    kind "relation"
    relation "landed the sculler at"
    weight 1
  ]
  edge [
    source 238
    target 247
    kind "relation"
    relation "went to"
    weight 1
  ]
  edge [
    source 238
    target 255
    kind "relation"
    relation "went to bed after"
    weight 1
  ]
  edge [
    source 240
    target 366
    kind "mentions"
  ]
  edge [
    source 240
    target 1146
    kind "mentions"
  ]
  edge [
    source 240
    target 1314
    kind "mentions"
  ]
  edge [
    source 240
    target 1283
    kind "relation"
    relation "arrived at"
    weight 1
  ]
  edge [
    source 240
    target 1493
    kind "mentions"
  ]
  edge [
    source 240
    target 1496
    kind "relation"
    relation "had news that"
    weight 1
  ]
  edge [
    source 241
    target 605
    kind "mentions"
  ]
  edge [
    source 241
    target 1273
    kind "mentions"
  ]
  edge [
    source 242
    target 243
    kind "relation"
    relation "admits into orders"
    weight 1
  ]
  edge [
    source 243
    target 244
    kind "relation"
    relation "was formerly a"
    weight 1
  ]
  edge [
    source 243
    target 254
    kind "relation"
    relation "was formerly a"
    weight 1
  ]
  edge [
    source 245
    target 1525
    kind "mentions"
  ]
  edge [
    source 245
    target 1533
    kind "relation"
    relation "was where"
    weight 1
  ]
  edge [
    source 246
    target 391
    kind "mentions"
  ]
  edge [
    source 246
    target 399
    kind "relation"
    relation "did not arrive with"
    weight 1
  ]
  edge [
    source 246
    target 392
    kind "relation"
    relation "took leave of"
    weight 1
  ]
  edge [
    source 248
    target 249
    kind "relation"
    relation "made"
    weight 1
  ]
  edge [
    source 248
    target 257
    kind "mentions"
  ]
  edge [
    source 248
    target 391
    kind "mentions"
  ]
  edge [
    source 248
    target 691
    kind "mentions"
  ]
  edge [
    source 248
    target 692
    kind "relation"
    relation "took leave of"
    weight 1
  ]
  edge [
    source 248
    target 1055
    kind "mentions"
  ]
  edge [
    source 248
    target 1071
    kind "mentions"
  ]
  edge [
    source 248
    target 1083
    kind "relation"
    relation "cannot function without | does not love as a companion"
    weight 2
  ]
  edge [
    source 248
    target 1092
    kind "relation"
    relation "is fond of"
    weight 1
  ]
  edge [
    source 248
    target 1146
    kind "mentions"
  ]
  edge [
    source 248
    target 1154
    kind "relation"
    relation "is expected to come to"
    weight 1
  ]
  edge [
    source 248
    target 1060
    kind "relation"
    relation "will adjourn"
    weight 1
  ]
  edge [
    source 248
    target 1158
    kind "mentions"
  ]
  edge [
    source 248
    target 1364
    kind "mentions"
  ]
  edge [
    source 248
    target 1366
    kind "relation"
    relation "had a hunting match with"
    weight 1
  ]
  edge [
    source 248
    target 1368
    kind "relation"
    relation "tired | could not keep pace with"
    weight 2
  ]
  edge [
    source 248
    target 1436
    kind "mentions"
  ]
  edge [
    source 248
    target 725
    kind "relation"
    relation "was at"
    weight 1
  ]
  edge [
    source 248
    target 1441
    kind "relation"
    relation "dined with"
    weight 1
  ]
  edge [
    source 248
    target 1501
    kind "mentions"
  ]
  edge [
    source 248
    target 274
    kind "relation"
    relation "procured from | obtained large grants from | received lands and manors from | received a warrant from"
    weight 4
  ]
  edge [
    source 248
    target 1505
    kind "relation"
    relation "issued a warrant in his own handwriting to"
    weight 1
  ]
  edge [
    source 248
    target 1512
    kind "mentions"
  ]
  edge [
    source 248
    target 1515
    kind "relation"
    relation "voted money to"
    weight 1
  ]
  edge [
    source 248
    target 1525
    kind "mentions"
  ]
  edge [
    source 248
    target 1534
    kind "relation"
    relation "arrived in"
    weight 1
  ]
  edge [
    source 248
    target 1535
    kind "relation"
    relation "appeared ordinary to"
    weight 1
  ]
  edge [
    source 248
    target 1716
    kind "mentions"
  ]
  edge [
    source 248
    target 1740
    kind "mentions"
  ]
  edge [
    source 248
    target 1802
    kind "mentions"
  ]
  edge [
    source 248
    target 1814
    kind "mentions"
  ]
  edge [
    source 248
    target 1908
    kind "mentions"
  ]
  edge [
    source 248
    target 1916
    kind "mentions"
  ]
  edge [
    source 248
    target 1008
    kind "relation"
    relation "is the king's mistress"
    weight 1
  ]
  edge [
    source 249
    target 257
    kind "mentions"
  ]
  edge [
    source 250
    target 256
    kind "relation"
    relation "was born in"
    weight 2
  ]
  edge [
    source 250
    target 252
    kind "relation"
    relation "was married to | married"
    weight 4
  ]
  edge [
    source 250
    target 253
    kind "relation"
    relation "was the date of marriage"
    weight 2
  ]
  edge [
    source 250
    target 257
    kind "mentions"
  ]
  edge [
    source 251
    target 257
    kind "mentions"
  ]
  edge [
    source 252
    target 257
    kind "mentions"
  ]
  edge [
    source 253
    target 257
    kind "mentions"
  ]
  edge [
    source 254
    target 1223
    kind "mentions"
  ]
  edge [
    source 254
    target 1233
    kind "relation"
    relation "began service by saying"
    weight 1
  ]
  edge [
    source 256
    target 257
    kind "mentions"
  ]
  edge [
    source 256
    target 260
    kind "mentions"
  ]
  edge [
    source 257
    target 258
    kind "mentions"
  ]
  edge [
    source 257
    target 1942
    kind "summarizes"
  ]
  edge [
    source 259
    target 260
    kind "from_chunk"
  ]
  edge [
    source 259
    target 269
    kind "from_chunk"
  ]
  edge [
    source 259
    target 280
    kind "from_chunk"
  ]
  edge [
    source 260
    target 261
    kind "mentions"
  ]
  edge [
    source 260
    target 262
    kind "mentions"
  ]
  edge [
    source 260
    target 263
    kind "mentions"
  ]
  edge [
    source 260
    target 264
    kind "mentions"
  ]
  edge [
    source 260
    target 265
    kind "mentions"
  ]
  edge [
    source 260
    target 266
    kind "mentions"
  ]
  edge [
    source 260
    target 267
    kind "mentions"
  ]
  edge [
    source 260
    target 268
    kind "mentions"
  ]
  edge [
    source 260
    target 1947
    kind "summarizes"
  ]
  edge [
    source 261
    target 268
    kind "relation"
    relation "was born in | returned to | became regent of"
    weight 3
  ]
  edge [
    source 261
    target 1322
    kind "mentions"
  ]
  edge [
    source 261
    target 1086
    kind "relation"
    relation "has preparation for"
    weight 1
  ]
  edge [
    source 261
    target 1633
    kind "mentions"
  ]
  edge [
    source 261
    target 1634
    kind "relation"
    relation "is traveling to"
    weight 1
  ]
  edge [
    source 261
    target 1698
    kind "mentions"
  ]
  edge [
    source 261
    target 1707
    kind "relation"
    relation "is going tomorrow | is going to"
    weight 2
  ]
  edge [
    source 261
    target 1101
    kind "relation"
    relation "is going toward | is heading toward"
    weight 3
  ]
  edge [
    source 261
    target 1714
    kind "mentions"
  ]
  edge [
    source 261
    target 1716
    kind "mentions"
  ]
  edge [
    source 262
    target 268
    kind "relation"
    relation "married"
    weight 1
  ]
  edge [
    source 262
    target 263
    kind "relation"
    relation "died"
    weight 1
  ]
  edge [
    source 264
    target 268
    kind "relation"
    relation "lived at"
    weight 1
  ]
  edge [
    source 267
    target 268
    kind "relation"
    relation "died on"
    weight 1
  ]
  edge [
    source 268
    target 1396
    kind "mentions"
  ]
  edge [
    source 269
    target 270
    kind "mentions"
  ]
  edge [
    source 269
    target 271
    kind "mentions"
  ]
  edge [
    source 269
    target 272
    kind "mentions"
  ]
  edge [
    source 269
    target 273
    kind "mentions"
  ]
  edge [
    source 269
    target 274
    kind "mentions"
  ]
  edge [
    source 269
    target 275
    kind "mentions"
  ]
  edge [
    source 269
    target 276
    kind "mentions"
  ]
  edge [
    source 269
    target 277
    kind "mentions"
  ]
  edge [
    source 269
    target 278
    kind "mentions"
  ]
  edge [
    source 269
    target 279
    kind "mentions"
  ]
  edge [
    source 269
    target 1941
    kind "summarizes"
  ]
  edge [
    source 270
    target 278
    kind "relation"
    relation "is to go to | will settle business in | will organize the fleet in"
    weight 3
  ]
  edge [
    source 271
    target 278
    kind "relation"
    relation "will return to | will meet a fleet in"
    weight 2
  ]
  edge [
    source 273
    target 707
    kind "mentions"
  ]
  edge [
    source 274
    target 1501
    kind "mentions"
  ]
  edge [
    source 274
    target 1295
    kind "relation"
    relation "contains a document from"
    weight 1
  ]
  edge [
    source 274
    target 1505
    kind "relation"
    relation "paid l20000 to"
    weight 1
  ]
  edge [
    source 274
    target 1506
    kind "relation"
    relation "gave a warrant for"
    weight 1
  ]
  edge [
    source 278
    target 1181
    kind "mentions"
  ]
  edge [
    source 278
    target 620
    kind "relation"
    relation "left her estate to"
    weight 1
  ]
  edge [
    source 280
    target 281
    kind "mentions"
  ]
  edge [
    source 280
    target 282
    kind "mentions"
  ]
  edge [
    source 280
    target 283
    kind "mentions"
  ]
  edge [
    source 280
    target 284
    kind "mentions"
  ]
  edge [
    source 280
    target 285
    kind "mentions"
  ]
  edge [
    source 280
    target 286
    kind "mentions"
  ]
  edge [
    source 280
    target 287
    kind "mentions"
  ]
  edge [
    source 280
    target 288
    kind "mentions"
  ]
  edge [
    source 280
    target 289
    kind "mentions"
  ]
  edge [
    source 280
    target 290
    kind "mentions"
  ]
  edge [
    source 280
    target 291
    kind "mentions"
  ]
  edge [
    source 280
    target 1938
    kind "summarizes"
  ]
  edge [
    source 281
    target 290
    kind "relation"
    relation "is a parliament-man for"
    weight 1
  ]
  edge [
    source 281
    target 283
    kind "relation"
    relation "is also a parliament-man for"
    weight 1
  ]
  edge [
    source 281
    target 284
    kind "relation"
    relation "is also a parliament-man for"
    weight 1
  ]
  edge [
    source 281
    target 291
    kind "relation"
    relation "is an alderman of"
    weight 1
  ]
  edge [
    source 281
    target 286
    kind "relation"
    relation "is taken to"
    weight 1
  ]
  edge [
    source 285
    target 366
    kind "mentions"
  ]
  edge [
    source 285
    target 379
    kind "mentions"
  ]
  edge [
    source 285
    target 391
    kind "mentions"
  ]
  edge [
    source 285
    target 392
    kind "relation"
    relation "was told to be paid by"
    weight 1
  ]
  edge [
    source 285
    target 434
    kind "mentions"
  ]
  edge [
    source 285
    target 443
    kind "mentions"
  ]
  edge [
    source 287
    target 288
    kind "relation"
    relation "has a solemn day of choosing"
    weight 1
  ]
  edge [
    source 290
    target 929
    kind "mentions"
  ]
  edge [
    source 290
    target 1161
    kind "mentions"
  ]
  edge [
    source 290
    target 1241
    kind "mentions"
  ]
  edge [
    source 290
    target 1262
    kind "mentions"
  ]
  edge [
    source 290
    target 939
    kind "relation"
    relation "was lying at"
    weight 1
  ]
  edge [
    source 292
    target 293
    kind "from_chunk"
  ]
  edge [
    source 292
    target 305
    kind "from_chunk"
  ]
  edge [
    source 292
    target 315
    kind "from_chunk"
  ]
  edge [
    source 292
    target 318
    kind "from_chunk"
  ]
  edge [
    source 293
    target 294
    kind "mentions"
  ]
  edge [
    source 293
    target 295
    kind "mentions"
  ]
  edge [
    source 293
    target 296
    kind "mentions"
  ]
  edge [
    source 293
    target 297
    kind "mentions"
  ]
  edge [
    source 293
    target 298
    kind "mentions"
  ]
  edge [
    source 293
    target 299
    kind "mentions"
  ]
  edge [
    source 293
    target 300
    kind "mentions"
  ]
  edge [
    source 293
    target 301
    kind "mentions"
  ]
  edge [
    source 293
    target 302
    kind "mentions"
  ]
  edge [
    source 293
    target 303
    kind "mentions"
  ]
  edge [
    source 293
    target 304
    kind "mentions"
  ]
  edge [
    source 293
    target 1949
    kind "summarizes"
  ]
  edge [
    source 294
    target 356
    kind "mentions"
  ]
  edge [
    source 294
    target 364
    kind "relation"
    relation "carried"
    weight 1
  ]
  edge [
    source 294
    target 434
    kind "mentions"
  ]
  edge [
    source 294
    target 441
    kind "relation"
    relation "returned to"
    weight 1
  ]
  edge [
    source 294
    target 541
    kind "mentions"
  ]
  edge [
    source 294
    target 605
    kind "mentions"
  ]
  edge [
    source 294
    target 640
    kind "mentions"
  ]
  edge [
    source 294
    target 779
    kind "mentions"
  ]
  edge [
    source 294
    target 1158
    kind "mentions"
  ]
  edge [
    source 294
    target 1273
    kind "mentions"
  ]
  edge [
    source 294
    target 1374
    kind "mentions"
  ]
  edge [
    source 294
    target 1388
    kind "mentions"
  ]
  edge [
    source 294
    target 1389
    kind "relation"
    relation "intends to send | is a son of"
    weight 2
  ]
  edge [
    source 294
    target 1390
    kind "relation"
    relation "intends to send | is a son of"
    weight 2
  ]
  edge [
    source 294
    target 1391
    kind "relation"
    relation "intends to send | is a son of"
    weight 2
  ]
  edge [
    source 294
    target 1396
    kind "mentions"
  ]
  edge [
    source 294
    target 1415
    kind "mentions"
  ]
  edge [
    source 294
    target 1436
    kind "mentions"
  ]
  edge [
    source 294
    target 1444
    kind "relation"
    relation "dined with"
    weight 1
  ]
  edge [
    source 294
    target 1615
    kind "mentions"
  ]
  edge [
    source 295
    target 1448
    kind "mentions"
  ]
  edge [
    source 295
    target 1449
    kind "relation"
    relation "dined with"
    weight 1
  ]
  edge [
    source 295
    target 1499
    kind "mentions"
  ]
  edge [
    source 295
    target 1497
    kind "relation"
    relation "sent for"
    weight 1
  ]
  edge [
    source 295
    target 1542
    kind "mentions"
  ]
  edge [
    source 295
    target 1782
    kind "mentions"
  ]
  edge [
    source 295
    target 1917
    kind "mentions"
  ]
  edge [
    source 295
    target 1903
    kind "relation"
    relation "rose and dined with"
    weight 1
  ]
  edge [
    source 297
    target 304
    kind "relation"
    relation "was in its last work of"
    weight 1
  ]
  edge [
    source 297
    target 496
    kind "mentions"
  ]
  edge [
    source 297
    target 517
    kind "mentions"
  ]
  edge [
    source 297
    target 526
    kind "relation"
    relation "begins to be clean after"
    weight 1
  ]
  edge [
    source 297
    target 564
    kind "mentions"
  ]
  edge [
    source 297
    target 567
    kind "relation"
    relation "was completed | is now very neat"
    weight 2
  ]
  edge [
    source 297
    target 581
    kind "mentions"
  ]
  edge [
    source 297
    target 583
    kind "mentions"
  ]
  edge [
    source 297
    target 586
    kind "relation"
    relation "is now gone from"
    weight 1
  ]
  edge [
    source 297
    target 602
    kind "mentions"
  ]
  edge [
    source 297
    target 549
    kind "relation"
    relation "came to"
    weight 1
  ]
  edge [
    source 297
    target 550
    kind "relation"
    relation "came to"
    weight 1
  ]
  edge [
    source 297
    target 551
    kind "relation"
    relation "came to"
    weight 1
  ]
  edge [
    source 297
    target 960
    kind "mentions"
  ]
  edge [
    source 297
    target 609
    kind "relation"
    relation "will quit"
    weight 1
  ]
  edge [
    source 297
    target 987
    kind "mentions"
  ]
  edge [
    source 297
    target 991
    kind "relation"
    relation "showed the narrator"
    weight 1
  ]
  edge [
    source 297
    target 1026
    kind "mentions"
  ]
  edge [
    source 297
    target 1027
    kind "relation"
    relation "saw a bill on the door | intended to withdraw agreement for"
    weight 2
  ]
  edge [
    source 297
    target 1029
    kind "relation"
    relation "had a fine of"
    weight 1
  ]
  edge [
    source 297
    target 1030
    kind "relation"
    relation "had annual rent of"
    weight 1
  ]
  edge [
    source 297
    target 1098
    kind "mentions"
  ]
  edge [
    source 297
    target 1110
    kind "relation"
    relation "had been alone to see"
    weight 1
  ]
  edge [
    source 297
    target 1118
    kind "mentions"
  ]
  edge [
    source 297
    target 1126
    kind "mentions"
  ]
  edge [
    source 297
    target 1219
    kind "mentions"
  ]
  edge [
    source 297
    target 1246
    kind "mentions"
  ]
  edge [
    source 297
    target 1255
    kind "mentions"
  ]
  edge [
    source 297
    target 1388
    kind "mentions"
  ]
  edge [
    source 297
    target 1389
    kind "relation"
    relation "will go to | is being visited by"
    weight 2
  ]
  edge [
    source 297
    target 1390
    kind "relation"
    relation "will go to | is being visited by"
    weight 2
  ]
  edge [
    source 297
    target 1391
    kind "relation"
    relation "will go to | is being visited by"
    weight 2
  ]
  edge [
    source 297
    target 1393
    kind "mentions"
  ]
  edge [
    source 297
    target 1585
    kind "mentions"
  ]
  edge [
    source 297
    target 1593
    kind "relation"
    relation "had great deal of company at | had poor entertainment at"
    weight 2
  ]
  edge [
    source 297
    target 1594
    kind "relation"
    relation "was so hot that"
    weight 1
  ]
  edge [
    source 297
    target 1600
    kind "mentions"
  ]
  edge [
    source 297
    target 573
    kind "relation"
    relation "was found within"
    weight 1
  ]
  edge [
    source 297
    target 1623
    kind "mentions"
  ]
  edge [
    source 297
    target 1765
    kind "mentions"
  ]
  edge [
    source 297
    target 1775
    kind "mentions"
  ]
  edge [
    source 297
    target 1840
    kind "mentions"
  ]
  edge [
    source 297
    target 1867
    kind "mentions"
  ]
  edge [
    source 300
    target 803
    kind "mentions"
  ]
  edge [
    source 300
    target 1350
    kind "mentions"
  ]
  edge [
    source 300
    target 449
    kind "relation"
    relation "was lord's day"
    weight 1
  ]
  edge [
    source 305
    target 306
    kind "mentions"
  ]
  edge [
    source 305
    target 307
    kind "mentions"
  ]
  edge [
    source 305
    target 308
    kind "mentions"
  ]
  edge [
    source 305
    target 309
    kind "mentions"
  ]
  edge [
    source 305
    target 310
    kind "mentions"
  ]
  edge [
    source 305
    target 311
    kind "mentions"
  ]
  edge [
    source 305
    target 312
    kind "mentions"
  ]
  edge [
    source 305
    target 313
    kind "mentions"
  ]
  edge [
    source 305
    target 314
    kind "mentions"
  ]
  edge [
    source 305
    target 1950
    kind "summarizes"
  ]
  edge [
    source 306
    target 1314
    kind "mentions"
  ]
  edge [
    source 307
    target 443
    kind "mentions"
  ]
  edge [
    source 307
    target 683
    kind "mentions"
  ]
  edge [
    source 307
    target 1415
    kind "mentions"
  ]
  edge [
    source 307
    target 543
    kind "relation"
    relation "waited upon"
    weight 1
  ]
  edge [
    source 307
    target 1427
    kind "relation"
    relation "is troubled by"
    weight 1
  ]
  edge [
    source 307
    target 1428
    kind "relation"
    relation "will speak to"
    weight 1
  ]
  edge [
    source 308
    target 1131
    kind "mentions"
  ]
  edge [
    source 308
    target 1415
    kind "mentions"
  ]
  edge [
    source 308
    target 1679
    kind "mentions"
  ]
  edge [
    source 310
    target 1912
    kind "mentions"
  ]
  edge [
    source 311
    target 1098
    kind "mentions"
  ]
  edge [
    source 312
    target 1415
    kind "mentions"
  ]
  edge [
    source 312
    target 1416
    kind "relation"
    relation "is in poor financial condition due to"
    weight 1
  ]
  edge [
    source 315
    target 316
    kind "mentions"
  ]
  edge [
    source 315
    target 317
    kind "mentions"
  ]
  edge [
    source 315
    target 1935
    kind "summarizes"
  ]
  edge [
    source 316
    target 1246
    kind "mentions"
  ]
  edge [
    source 316
    target 1248
    kind "relation"
    relation "tells the speaker about"
    weight 1
  ]
  edge [
    source 316
    target 1464
    kind "mentions"
  ]
  edge [
    source 316
    target 1816
    kind "mentions"
  ]
  edge [
    source 316
    target 1887
    kind "mentions"
  ]
  edge [
    source 317
    target 640
    kind "mentions"
  ]
  edge [
    source 317
    target 659
    kind "mentions"
  ]
  edge [
    source 317
    target 803
    kind "mentions"
  ]
  edge [
    source 317
    target 793
    kind "relation"
    relation "was done in"
    weight 1
  ]
  edge [
    source 317
    target 960
    kind "mentions"
  ]
  edge [
    source 317
    target 967
    kind "relation"
    relation "visited"
    weight 1
  ]
  edge [
    source 317
    target 1118
    kind "mentions"
  ]
  edge [
    source 318
    target 319
    kind "mentions"
  ]
  edge [
    source 318
    target 320
    kind "mentions"
  ]
  edge [
    source 318
    target 321
    kind "mentions"
  ]
  edge [
    source 318
    target 322
    kind "mentions"
  ]
  edge [
    source 318
    target 323
    kind "mentions"
  ]
  edge [
    source 318
    target 324
    kind "mentions"
  ]
  edge [
    source 318
    target 325
    kind "mentions"
  ]
  edge [
    source 318
    target 326
    kind "mentions"
  ]
  edge [
    source 318
    target 1954
    kind "summarizes"
  ]
  edge [
    source 319
    target 803
    kind "mentions"
  ]
  edge [
    source 319
    target 1369
    kind "mentions"
  ]
  edge [
    source 319
    target 1078
    kind "relation"
    relation "fell ill"
    weight 1
  ]
  edge [
    source 321
    target 322
    kind "relation"
    relation "were not ready to keep"
    weight 1
  ]
  edge [
    source 321
    target 326
    kind "relation"
    relation "were forced to keep"
    weight 1
  ]
  edge [
    source 324
    target 325
    kind "relation"
    relation "occurred before"
    weight 1
  ]
  edge [
    source 327
    target 328
    kind "from_chunk"
  ]
  edge [
    source 327
    target 356
    kind "from_chunk"
  ]
  edge [
    source 328
    target 329
    kind "mentions"
  ]
  edge [
    source 328
    target 330
    kind "mentions"
  ]
  edge [
    source 328
    target 331
    kind "mentions"
  ]
  edge [
    source 328
    target 332
    kind "mentions"
  ]
  edge [
    source 328
    target 333
    kind "mentions"
  ]
  edge [
    source 328
    target 334
    kind "mentions"
  ]
  edge [
    source 328
    target 335
    kind "mentions"
  ]
  edge [
    source 328
    target 336
    kind "mentions"
  ]
  edge [
    source 328
    target 337
    kind "mentions"
  ]
  edge [
    source 328
    target 338
    kind "mentions"
  ]
  edge [
    source 328
    target 339
    kind "mentions"
  ]
  edge [
    source 328
    target 340
    kind "mentions"
  ]
  edge [
    source 328
    target 341
    kind "mentions"
  ]
  edge [
    source 328
    target 342
    kind "mentions"
  ]
  edge [
    source 328
    target 343
    kind "mentions"
  ]
  edge [
    source 328
    target 344
    kind "mentions"
  ]
  edge [
    source 328
    target 345
    kind "mentions"
  ]
  edge [
    source 328
    target 346
    kind "mentions"
  ]
  edge [
    source 328
    target 347
    kind "mentions"
  ]
  edge [
    source 328
    target 348
    kind "mentions"
  ]
  edge [
    source 328
    target 349
    kind "mentions"
  ]
  edge [
    source 328
    target 350
    kind "mentions"
  ]
  edge [
    source 328
    target 351
    kind "mentions"
  ]
  edge [
    source 328
    target 352
    kind "mentions"
  ]
  edge [
    source 328
    target 353
    kind "mentions"
  ]
  edge [
    source 328
    target 354
    kind "mentions"
  ]
  edge [
    source 328
    target 355
    kind "mentions"
  ]
  edge [
    source 328
    target 1938
    kind "summarizes"
  ]
  edge [
    source 329
    target 330
    kind "relation"
    relation "was published for use in"
    weight 1
  ]
  edge [
    source 329
    target 332
    kind "relation"
    relation "was published for use in"
    weight 1
  ]
  edge [
    source 330
    target 403
    kind "mentions"
  ]
  edge [
    source 330
    target 912
    kind "mentions"
  ]
  edge [
    source 330
    target 960
    kind "mentions"
  ]
  edge [
    source 330
    target 984
    kind "mentions"
  ]
  edge [
    source 330
    target 987
    kind "mentions"
  ]
  edge [
    source 330
    target 1026
    kind "mentions"
  ]
  edge [
    source 330
    target 1181
    kind "mentions"
  ]
  edge [
    source 330
    target 777
    kind "relation"
    relation "was brought from"
    weight 1
  ]
  edge [
    source 330
    target 1262
    kind "mentions"
  ]
  edge [
    source 330
    target 1273
    kind "mentions"
  ]
  edge [
    source 330
    target 1277
    kind "relation"
    relation "was going to"
    weight 1
  ]
  edge [
    source 331
    target 334
    kind "relation"
    relation "was appointed for"
    weight 1
  ]
  edge [
    source 332
    target 1098
    kind "mentions"
  ]
  edge [
    source 332
    target 1139
    kind "mentions"
  ]
  edge [
    source 332
    target 1145
    kind "relation"
    relation "has gone to"
    weight 1
  ]
  edge [
    source 332
    target 1396
    kind "mentions"
  ]
  edge [
    source 332
    target 1650
    kind "mentions"
  ]
  edge [
    source 332
    target 1654
    kind "relation"
    relation "intends to go into"
    weight 1
  ]
  edge [
    source 332
    target 559
    kind "relation"
    relation "is observed for her behavior at"
    weight 1
  ]
  edge [
    source 332
    target 1670
    kind "mentions"
  ]
  edge [
    source 332
    target 1698
    kind "mentions"
  ]
  edge [
    source 333
    target 334
    kind "relation"
    relation "was appointed for"
    weight 1
  ]
  edge [
    source 334
    target 335
    kind "relation"
    relation "was held to avert"
    weight 1
  ]
  edge [
    source 334
    target 336
    kind "relation"
    relation "was held to avert"
    weight 1
  ]
  edge [
    source 334
    target 339
    kind "relation"
    relation "was held for thanksgiving of"
    weight 1
  ]
  edge [
    source 334
    target 340
    kind "relation"
    relation "included a request for"
    weight 1
  ]
  edge [
    source 334
    target 352
    kind "relation"
    relation "included a request for"
    weight 1
  ]
  edge [
    source 334
    target 353
    kind "relation"
    relation "included a request for"
    weight 1
  ]
  edge [
    source 336
    target 337
    kind "relation"
    relation "was caused by"
    weight 1
  ]
  edge [
    source 343
    target 354
    kind "relation"
    relation "preached a sermon before"
    weight 1
  ]
  edge [
    source 343
    target 344
    kind "relation"
    relation "is the preacher of"
    weight 1
  ]
  edge [
    source 345
    target 355
    kind "relation"
    relation "taxed themselves for"
    weight 2
  ]
  edge [
    source 345
    target 1146
    kind "mentions"
  ]
  edge [
    source 345
    target 1155
    kind "relation"
    relation "challenge"
    weight 1
  ]
  edge [
    source 345
    target 1156
    kind "relation"
    relation "deny to pass"
    weight 1
  ]
  edge [
    source 345
    target 1923
    kind "mentions"
  ]
  edge [
    source 346
    target 347
    kind "relation"
    relation "paid"
    weight 1
  ]
  edge [
    source 346
    target 1923
    kind "mentions"
  ]
  edge [
    source 346
    target 1924
    kind "relation"
    relation "was among the lords who taxed themselves"
    weight 1
  ]
  edge [
    source 348
    target 349
    kind "relation"
    relation "paid"
    weight 1
  ]
  edge [
    source 349
    target 587
    kind "mentions"
  ]
  edge [
    source 350
    target 351
    kind "relation"
    relation "were to pay"
    weight 1
  ]
  edge [
    source 351
    target 1926
    kind "mentions"
  ]
  edge [
    source 351
    target 1928
    kind "relation"
    relation "were to pay"
    weight 1
  ]
  edge [
    source 355
    target 1923
    kind "mentions"
  ]
  edge [
    source 356
    target 357
    kind "mentions"
  ]
  edge [
    source 356
    target 358
    kind "mentions"
  ]
  edge [
    source 356
    target 359
    kind "mentions"
  ]
  edge [
    source 356
    target 360
    kind "mentions"
  ]
  edge [
    source 356
    target 361
    kind "mentions"
  ]
  edge [
    source 356
    target 362
    kind "mentions"
  ]
  edge [
    source 356
    target 363
    kind "mentions"
  ]
  edge [
    source 356
    target 364
    kind "mentions"
  ]
  edge [
    source 356
    target 1933
    kind "summarizes"
  ]
  edge [
    source 357
    target 391
    kind "mentions"
  ]
  edge [
    source 357
    target 392
    kind "relation"
    relation "took leave of"
    weight 1
  ]
  edge [
    source 361
    target 934
    kind "mentions"
  ]
  edge [
    source 362
    target 434
    kind "mentions"
  ]
  edge [
    source 362
    target 1542
    kind "mentions"
  ]
  edge [
    source 365
    target 366
    kind "from_chunk"
  ]
  edge [
    source 365
    target 379
    kind "from_chunk"
  ]
  edge [
    source 366
    target 367
    kind "mentions"
  ]
  edge [
    source 366
    target 368
    kind "mentions"
  ]
  edge [
    source 366
    target 369
    kind "mentions"
  ]
  edge [
    source 366
    target 370
    kind "mentions"
  ]
  edge [
    source 366
    target 371
    kind "mentions"
  ]
  edge [
    source 366
    target 372
    kind "mentions"
  ]
  edge [
    source 366
    target 373
    kind "mentions"
  ]
  edge [
    source 366
    target 374
    kind "mentions"
  ]
  edge [
    source 366
    target 375
    kind "mentions"
  ]
  edge [
    source 366
    target 376
    kind "mentions"
  ]
  edge [
    source 366
    target 377
    kind "mentions"
  ]
  edge [
    source 366
    target 378
    kind "mentions"
  ]
  edge [
    source 366
    target 1942
    kind "summarizes"
  ]
  edge [
    source 367
    target 496
    kind "mentions"
  ]
  edge [
    source 367
    target 511
    kind "mentions"
  ]
  edge [
    source 368
    target 640
    kind "mentions"
  ]
  edge [
    source 368
    target 656
    kind "relation"
    relation "complained of | sent a letter complaining of"
    weight 2
  ]
  edge [
    source 368
    target 659
    kind "mentions"
  ]
  edge [
    source 368
    target 1436
    kind "mentions"
  ]
  edge [
    source 368
    target 725
    kind "relation"
    relation "was at"
    weight 1
  ]
  edge [
    source 368
    target 1716
    kind "mentions"
  ]
  edge [
    source 368
    target 1740
    kind "mentions"
  ]
  edge [
    source 368
    target 1908
    kind "mentions"
  ]
  edge [
    source 369
    target 379
    kind "mentions"
  ]
  edge [
    source 369
    target 374
    kind "relation"
    relation "offered"
    weight 1
  ]
  edge [
    source 369
    target 434
    kind "mentions"
  ]
  edge [
    source 369
    target 443
    kind "mentions"
  ]
  edge [
    source 369
    target 444
    kind "relation"
    relation "agreed to stowage for"
    weight 1
  ]
  edge [
    source 369
    target 454
    kind "relation"
    relation "were brought to"
    weight 1
  ]
  edge [
    source 369
    target 455
    kind "relation"
    relation "were laid"
    weight 1
  ]
  edge [
    source 370
    target 379
    kind "mentions"
  ]
  edge [
    source 370
    target 707
    kind "mentions"
  ]
  edge [
    source 373
    target 428
    kind "mentions"
  ]
  edge [
    source 373
    target 1223
    kind "mentions"
  ]
  edge [
    source 373
    target 1802
    kind "mentions"
  ]
  edge [
    source 374
    target 379
    kind "mentions"
  ]
  edge [
    source 379
    target 380
    kind "mentions"
  ]
  edge [
    source 379
    target 381
    kind "mentions"
  ]
  edge [
    source 379
    target 382
    kind "mentions"
  ]
  edge [
    source 379
    target 383
    kind "mentions"
  ]
  edge [
    source 379
    target 384
    kind "mentions"
  ]
  edge [
    source 379
    target 385
    kind "mentions"
  ]
  edge [
    source 379
    target 386
    kind "mentions"
  ]
  edge [
    source 379
    target 387
    kind "mentions"
  ]
  edge [
    source 379
    target 388
    kind "mentions"
  ]
  edge [
    source 379
    target 389
    kind "mentions"
  ]
  edge [
    source 379
    target 1942
    kind "summarizes"
  ]
  edge [
    source 380
    target 803
    kind "mentions"
  ]
  edge [
    source 381
    target 1026
    kind "mentions"
  ]
  edge [
    source 382
    target 384
    kind "relation"
    relation "was made from"
    weight 1
  ]
  edge [
    source 383
    target 1889
    kind "mentions"
  ]
  edge [
    source 383
    target 1890
    kind "relation"
    relation "was made from"
    weight 1
  ]
  edge [
    source 390
    target 391
    kind "from_chunk"
  ]
  edge [
    source 391
    target 392
    kind "mentions"
  ]
  edge [
    source 391
    target 393
    kind "mentions"
  ]
  edge [
    source 391
    target 394
    kind "mentions"
  ]
  edge [
    source 391
    target 395
    kind "mentions"
  ]
  edge [
    source 391
    target 396
    kind "mentions"
  ]
  edge [
    source 391
    target 397
    kind "mentions"
  ]
  edge [
    source 391
    target 398
    kind "mentions"
  ]
  edge [
    source 391
    target 399
    kind "mentions"
  ]
  edge [
    source 391
    target 400
    kind "mentions"
  ]
  edge [
    source 391
    target 401
    kind "mentions"
  ]
  edge [
    source 391
    target 1942
    kind "summarizes"
  ]
  edge [
    source 392
    target 394
    kind "relation"
    relation "sang below"
    weight 1
  ]
  edge [
    source 392
    target 401
    kind "relation"
    relation "took leave of"
    weight 1
  ]
  edge [
    source 392
    target 395
    kind "relation"
    relation "went with"
    weight 1
  ]
  edge [
    source 392
    target 396
    kind "relation"
    relation "was proud of"
    weight 1
  ]
  edge [
    source 395
    target 1343
    kind "mentions"
  ]
  edge [
    source 395
    target 824
    kind "relation"
    relation "took"
    weight 1
  ]
  edge [
    source 395
    target 1415
    kind "mentions"
  ]
  edge [
    source 395
    target 1464
    kind "mentions"
  ]
  edge [
    source 395
    target 1477
    kind "relation"
    relation "and the narrator"
    weight 1
  ]
  edge [
    source 395
    target 1479
    kind "relation"
    relation "went with"
    weight 1
  ]
  edge [
    source 395
    target 1480
    kind "relation"
    relation "and the narrator and another"
    weight 1
  ]
  edge [
    source 397
    target 403
    kind "mentions"
  ]
  edge [
    source 402
    target 403
    kind "from_chunk"
  ]
  edge [
    source 402
    target 425
    kind "from_chunk"
  ]
  edge [
    source 403
    target 404
    kind "mentions"
  ]
  edge [
    source 403
    target 405
    kind "mentions"
  ]
  edge [
    source 403
    target 406
    kind "mentions"
  ]
  edge [
    source 403
    target 407
    kind "mentions"
  ]
  edge [
    source 403
    target 408
    kind "mentions"
  ]
  edge [
    source 403
    target 409
    kind "mentions"
  ]
  edge [
    source 403
    target 410
    kind "mentions"
  ]
  edge [
    source 403
    target 411
    kind "mentions"
  ]
  edge [
    source 403
    target 412
    kind "mentions"
  ]
  edge [
    source 403
    target 413
    kind "mentions"
  ]
  edge [
    source 403
    target 414
    kind "mentions"
  ]
  edge [
    source 403
    target 415
    kind "mentions"
  ]
  edge [
    source 403
    target 416
    kind "mentions"
  ]
  edge [
    source 403
    target 417
    kind "mentions"
  ]
  edge [
    source 403
    target 418
    kind "mentions"
  ]
  edge [
    source 403
    target 419
    kind "mentions"
  ]
  edge [
    source 403
    target 420
    kind "mentions"
  ]
  edge [
    source 403
    target 421
    kind "mentions"
  ]
  edge [
    source 403
    target 422
    kind "mentions"
  ]
  edge [
    source 403
    target 423
    kind "mentions"
  ]
  edge [
    source 403
    target 424
    kind "mentions"
  ]
  edge [
    source 403
    target 1940
    kind "summarizes"
  ]
  edge [
    source 405
    target 464
    kind "mentions"
  ]
  edge [
    source 405
    target 467
    kind "relation"
    relation "serves in"
    weight 1
  ]
  edge [
    source 408
    target 1055
    kind "mentions"
  ]
  edge [
    source 408
    target 1782
    kind "mentions"
  ]
  edge [
    source 408
    target 1798
    kind "relation"
    relation "went to"
    weight 2
  ]
  edge [
    source 408
    target 1799
    kind "mentions"
  ]
  edge [
    source 410
    target 415
    kind "relation"
    relation "gave"
    weight 1
  ]
  edge [
    source 410
    target 416
    kind "relation"
    relation "gave"
    weight 1
  ]
  edge [
    source 410
    target 1436
    kind "mentions"
  ]
  edge [
    source 410
    target 1444
    kind "relation"
    relation "managed to fuddle"
    weight 1
  ]
  edge [
    source 411
    target 418
    kind "relation"
    relation "took"
    weight 1
  ]
  edge [
    source 413
    target 683
    kind "mentions"
  ]
  edge [
    source 419
    target 1623
    kind "mentions"
  ]
  edge [
    source 421
    target 425
    kind "mentions"
  ]
  edge [
    source 421
    target 742
    kind "mentions"
  ]
  edge [
    source 421
    target 1716
    kind "mentions"
  ]
  edge [
    source 422
    target 425
    kind "mentions"
  ]
  edge [
    source 423
    target 425
    kind "mentions"
  ]
  edge [
    source 424
    target 425
    kind "mentions"
  ]
  edge [
    source 425
    target 426
    kind "mentions"
  ]
  edge [
    source 425
    target 1940
    kind "summarizes"
  ]
  edge [
    source 426
    target 1396
    kind "mentions"
  ]
  edge [
    source 426
    target 1412
    kind "mentions"
  ]
  edge [
    source 427
    target 428
    kind "from_chunk"
  ]
  edge [
    source 427
    target 434
    kind "from_chunk"
  ]
  edge [
    source 428
    target 429
    kind "mentions"
  ]
  edge [
    source 428
    target 430
    kind "mentions"
  ]
  edge [
    source 428
    target 431
    kind "mentions"
  ]
  edge [
    source 428
    target 432
    kind "mentions"
  ]
  edge [
    source 428
    target 433
    kind "mentions"
  ]
  edge [
    source 428
    target 1934
    kind "summarizes"
  ]
  edge [
    source 431
    target 605
    kind "mentions"
  ]
  edge [
    source 431
    target 640
    kind "mentions"
  ]
  edge [
    source 431
    target 717
    kind "mentions"
  ]
  edge [
    source 431
    target 1327
    kind "mentions"
  ]
  edge [
    source 431
    target 1349
    kind "mentions"
  ]
  edge [
    source 431
    target 824
    kind "relation"
    relation "took"
    weight 1
  ]
  edge [
    source 431
    target 1464
    kind "mentions"
  ]
  edge [
    source 431
    target 1481
    kind "relation"
    relation "returned home by"
    weight 1
  ]
  edge [
    source 431
    target 1525
    kind "mentions"
  ]
  edge [
    source 431
    target 1585
    kind "mentions"
  ]
  edge [
    source 432
    target 1904
    kind "mentions"
  ]
  edge [
    source 434
    target 435
    kind "mentions"
  ]
  edge [
    source 434
    target 436
    kind "mentions"
  ]
  edge [
    source 434
    target 437
    kind "mentions"
  ]
  edge [
    source 434
    target 438
    kind "mentions"
  ]
  edge [
    source 434
    target 439
    kind "mentions"
  ]
  edge [
    source 434
    target 440
    kind "mentions"
  ]
  edge [
    source 434
    target 441
    kind "mentions"
  ]
  edge [
    source 434
    target 1943
    kind "summarizes"
  ]
  edge [
    source 436
    target 861
    kind "mentions"
  ]
  edge [
    source 436
    target 877
    kind "relation"
    relation "was seventy-eight years old at the time"
    weight 1
  ]
  edge [
    source 436
    target 1434
    kind "mentions"
  ]
  edge [
    source 436
    target 1436
    kind "mentions"
  ]
  edge [
    source 436
    target 1418
    kind "relation"
    relation "was getting better"
    weight 1
  ]
  edge [
    source 436
    target 725
    kind "relation"
    relation "began on"
    weight 1
  ]
  edge [
    source 442
    target 443
    kind "from_chunk"
  ]
  edge [
    source 442
    target 462
    kind "from_chunk"
  ]
  edge [
    source 443
    target 444
    kind "mentions"
  ]
  edge [
    source 443
    target 445
    kind "mentions"
  ]
  edge [
    source 443
    target 446
    kind "mentions"
  ]
  edge [
    source 443
    target 447
    kind "mentions"
  ]
  edge [
    source 443
    target 448
    kind "mentions"
  ]
  edge [
    source 443
    target 449
    kind "mentions"
  ]
  edge [
    source 443
    target 450
    kind "mentions"
  ]
  edge [
    source 443
    target 451
    kind "mentions"
  ]
  edge [
    source 443
    target 452
    kind "mentions"
  ]
  edge [
    source 443
    target 453
    kind "mentions"
  ]
  edge [
    source 443
    target 454
    kind "mentions"
  ]
  edge [
    source 443
    target 455
    kind "mentions"
  ]
  edge [
    source 443
    target 456
    kind "mentions"
  ]
  edge [
    source 443
    target 457
    kind "mentions"
  ]
  edge [
    source 443
    target 458
    kind "mentions"
  ]
  edge [
    source 443
    target 459
    kind "mentions"
  ]
  edge [
    source 443
    target 460
    kind "mentions"
  ]
  edge [
    source 443
    target 461
    kind "mentions"
  ]
  edge [
    source 443
    target 1942
    kind "summarizes"
  ]
  edge [
    source 446
    target 462
    kind "mentions"
  ]
  edge [
    source 446
    target 783
    kind "mentions"
  ]
  edge [
    source 446
    target 784
    kind "relation"
    relation "desired to see | did not ask to see"
    weight 2
  ]
  edge [
    source 446
    target 801
    kind "mentions"
  ]
  edge [
    source 446
    target 899
    kind "mentions"
  ]
  edge [
    source 446
    target 900
    kind "relation"
    relation "confirmed the sufficiency of"
    weight 1
  ]
  edge [
    source 446
    target 912
    kind "mentions"
  ]
  edge [
    source 446
    target 917
    kind "relation"
    relation "are all legatees"
    weight 1
  ]
  edge [
    source 446
    target 929
    kind "mentions"
  ]
  edge [
    source 446
    target 1396
    kind "mentions"
  ]
  edge [
    source 446
    target 1405
    kind "relation"
    relation "read the will"
    weight 1
  ]
  edge [
    source 446
    target 1542
    kind "mentions"
  ]
  edge [
    source 446
    target 1556
    kind "mentions"
  ]
  edge [
    source 446
    target 1685
    kind "mentions"
  ]
  edge [
    source 446
    target 1902
    kind "mentions"
  ]
  edge [
    source 446
    target 1903
    kind "relation"
    relation "was greedy to see"
    weight 1
  ]
  edge [
    source 448
    target 906
    kind "mentions"
  ]
  edge [
    source 448
    target 912
    kind "mentions"
  ]
  edge [
    source 448
    target 922
    kind "relation"
    relation "was part of"
    weight 1
  ]
  edge [
    source 448
    target 923
    kind "relation"
    relation "was part of"
    weight 1
  ]
  edge [
    source 448
    target 924
    kind "relation"
    relation "was part of"
    weight 1
  ]
  edge [
    source 448
    target 925
    kind "relation"
    relation "was part of"
    weight 1
  ]
  edge [
    source 448
    target 1446
    kind "mentions"
  ]
  edge [
    source 448
    target 1448
    kind "mentions"
  ]
  edge [
    source 448
    target 1450
    kind "relation"
    relation "died in burial"
    weight 1
  ]
  edge [
    source 448
    target 1140
    kind "relation"
    relation "is upon the point of death"
    weight 1
  ]
  edge [
    source 448
    target 1462
    kind "mentions"
  ]
  edge [
    source 449
    target 541
    kind "mentions"
  ]
  edge [
    source 449
    target 668
    kind "mentions"
  ]
  edge [
    source 449
    target 801
    kind "mentions"
  ]
  edge [
    source 449
    target 1098
    kind "mentions"
  ]
  edge [
    source 449
    target 1114
    kind "relation"
    relation "went to church"
    weight 1
  ]
  edge [
    source 449
    target 1116
    kind "mentions"
  ]
  edge [
    source 449
    target 638
    kind "relation"
    relation "was a lord's day"
    weight 1
  ]
  edge [
    source 449
    target 1350
    kind "mentions"
  ]
  edge [
    source 450
    target 987
    kind "mentions"
  ]
  edge [
    source 451
    target 462
    kind "mentions"
  ]
  edge [
    source 454
    target 572
    kind "mentions"
  ]
  edge [
    source 462
    target 1944
    kind "summarizes"
  ]
  edge [
    source 463
    target 464
    kind "from_chunk"
  ]
  edge [
    source 463
    target 471
    kind "from_chunk"
  ]
  edge [
    source 463
    target 477
    kind "from_chunk"
  ]
  edge [
    source 464
    target 465
    kind "mentions"
  ]
  edge [
    source 464
    target 466
    kind "mentions"
  ]
  edge [
    source 464
    target 467
    kind "mentions"
  ]
  edge [
    source 464
    target 468
    kind "mentions"
  ]
  edge [
    source 464
    target 469
    kind "mentions"
  ]
  edge [
    source 464
    target 470
    kind "mentions"
  ]
  edge [
    source 464
    target 1940
    kind "summarizes"
  ]
  edge [
    source 465
    target 468
    kind "relation"
    relation "was to leave"
    weight 1
  ]
  edge [
    source 467
    target 683
    kind "mentions"
  ]
  edge [
    source 468
    target 1200
    kind "mentions"
  ]
  edge [
    source 471
    target 472
    kind "mentions"
  ]
  edge [
    source 471
    target 473
    kind "mentions"
  ]
  edge [
    source 471
    target 474
    kind "mentions"
  ]
  edge [
    source 471
    target 475
    kind "mentions"
  ]
  edge [
    source 471
    target 476
    kind "mentions"
  ]
  edge [
    source 471
    target 1933
    kind "summarizes"
  ]
  edge [
    source 473
    target 906
    kind "mentions"
  ]
  edge [
    source 473
    target 912
    kind "mentions"
  ]
  edge [
    source 473
    target 1448
    kind "mentions"
  ]
  edge [
    source 474
    target 475
    kind "relation"
    relation "were painting | were finished"
    weight 3
  ]
  edge [
    source 474
    target 480
    kind "mentions"
  ]
  edge [
    source 474
    target 494
    kind "mentions"
  ]
  edge [
    source 475
    target 480
    kind "mentions"
  ]
  edge [
    source 475
    target 494
    kind "mentions"
  ]
  edge [
    source 476
    target 480
    kind "mentions"
  ]
  edge [
    source 476
    target 481
    kind "relation"
    relation "was visited and drank at"
    weight 1
  ]
  edge [
    source 477
    target 478
    kind "mentions"
  ]
  edge [
    source 477
    target 1933
    kind "summarizes"
  ]
  edge [
    source 478
    target 480
    kind "mentions"
  ]
  edge [
    source 478
    target 906
    kind "mentions"
  ]
  edge [
    source 478
    target 912
    kind "mentions"
  ]
  edge [
    source 478
    target 1485
    kind "mentions"
  ]
  edge [
    source 479
    target 480
    kind "from_chunk"
  ]
  edge [
    source 479
    target 494
    kind "from_chunk"
  ]
  edge [
    source 480
    target 481
    kind "mentions"
  ]
  edge [
    source 480
    target 482
    kind "mentions"
  ]
  edge [
    source 480
    target 483
    kind "mentions"
  ]
  edge [
    source 480
    target 484
    kind "mentions"
  ]
  edge [
    source 480
    target 485
    kind "mentions"
  ]
  edge [
    source 480
    target 486
    kind "mentions"
  ]
  edge [
    source 480
    target 487
    kind "mentions"
  ]
  edge [
    source 480
    target 488
    kind "mentions"
  ]
  edge [
    source 480
    target 489
    kind "mentions"
  ]
  edge [
    source 480
    target 490
    kind "mentions"
  ]
  edge [
    source 480
    target 491
    kind "mentions"
  ]
  edge [
    source 480
    target 492
    kind "mentions"
  ]
  edge [
    source 480
    target 493
    kind "mentions"
  ]
  edge [
    source 480
    target 1933
    kind "summarizes"
  ]
  edge [
    source 482
    target 483
    kind "relation"
    relation "had a turret-garden"
    weight 1
  ]
  edge [
    source 482
    target 488
    kind "relation"
    relation "would not let them go"
    weight 1
  ]
  edge [
    source 484
    target 491
    kind "relation"
    relation "made needleworks"
    weight 1
  ]
  edge [
    source 486
    target 605
    kind "mentions"
  ]
  edge [
    source 486
    target 1298
    kind "mentions"
  ]
  edge [
    source 486
    target 1299
    kind "relation"
    relation "made the narrator mad"
    weight 1
  ]
  edge [
    source 486
    target 1931
    kind "mentions"
  ]
  edge [
    source 488
    target 492
    kind "relation"
    relation "began crying"
    weight 1
  ]
  edge [
    source 489
    target 493
    kind "relation"
    relation "remained in"
    weight 1
  ]
  edge [
    source 490
    target 494
    kind "mentions"
  ]
  edge [
    source 490
    target 906
    kind "mentions"
  ]
  edge [
    source 490
    target 912
    kind "mentions"
  ]
  edge [
    source 490
    target 1493
    kind "mentions"
  ]
  edge [
    source 490
    target 1497
    kind "relation"
    relation "sent for the children at noon"
    weight 1
  ]
  edge [
    source 490
    target 1499
    kind "mentions"
  ]
  edge [
    source 494
    target 1933
    kind "summarizes"
  ]
  edge [
    source 495
    target 496
    kind "from_chunk"
  ]
  edge [
    source 495
    target 511
    kind "from_chunk"
  ]
  edge [
    source 496
    target 497
    kind "mentions"
  ]
  edge [
    source 496
    target 498
    kind "mentions"
  ]
  edge [
    source 496
    target 499
    kind "mentions"
  ]
  edge [
    source 496
    target 500
    kind "mentions"
  ]
  edge [
    source 496
    target 501
    kind "mentions"
  ]
  edge [
    source 496
    target 502
    kind "mentions"
  ]
  edge [
    source 496
    target 503
    kind "mentions"
  ]
  edge [
    source 496
    target 504
    kind "mentions"
  ]
  edge [
    source 496
    target 505
    kind "mentions"
  ]
  edge [
    source 496
    target 506
    kind "mentions"
  ]
  edge [
    source 496
    target 507
    kind "mentions"
  ]
  edge [
    source 496
    target 508
    kind "mentions"
  ]
  edge [
    source 496
    target 509
    kind "mentions"
  ]
  edge [
    source 496
    target 510
    kind "mentions"
  ]
  edge [
    source 496
    target 1945
    kind "summarizes"
  ]
  edge [
    source 497
    target 717
    kind "mentions"
  ]
  edge [
    source 497
    target 1071
    kind "mentions"
  ]
  edge [
    source 497
    target 1146
    kind "mentions"
  ]
  edge [
    source 498
    target 766
    kind "mentions"
  ]
  edge [
    source 498
    target 1045
    kind "mentions"
  ]
  edge [
    source 498
    target 1415
    kind "mentions"
  ]
  edge [
    source 498
    target 1752
    kind "mentions"
  ]
  edge [
    source 498
    target 1840
    kind "mentions"
  ]
  edge [
    source 498
    target 1867
    kind "mentions"
  ]
  edge [
    source 499
    target 517
    kind "mentions"
  ]
  edge [
    source 499
    target 766
    kind "mentions"
  ]
  edge [
    source 499
    target 767
    kind "relation"
    relation "went to"
    weight 1
  ]
  edge [
    source 499
    target 779
    kind "mentions"
  ]
  edge [
    source 499
    target 1013
    kind "mentions"
  ]
  edge [
    source 499
    target 1045
    kind "mentions"
  ]
  edge [
    source 499
    target 1337
    kind "mentions"
  ]
  edge [
    source 499
    target 1338
    kind "relation"
    relation "went with"
    weight 1
  ]
  edge [
    source 499
    target 1010
    kind "relation"
    relation "agreed to meet | met with"
    weight 2
  ]
  edge [
    source 499
    target 1341
    kind "relation"
    relation "and read over"
    weight 1
  ]
  edge [
    source 499
    target 1396
    kind "mentions"
  ]
  edge [
    source 499
    target 1404
    kind "relation"
    relation "arrives by appointment of"
    weight 1
  ]
  edge [
    source 499
    target 1585
    kind "mentions"
  ]
  edge [
    source 499
    target 1595
    kind "relation"
    relation "was with"
    weight 1
  ]
  edge [
    source 499
    target 1650
    kind "mentions"
  ]
  edge [
    source 499
    target 1664
    kind "relation"
    relation "takes his leave of"
    weight 1
  ]
  edge [
    source 500
    target 517
    kind "mentions"
  ]
  edge [
    source 500
    target 522
    kind "relation"
    relation "has a house and land at"
    weight 1
  ]
  edge [
    source 500
    target 696
    kind "mentions"
  ]
  edge [
    source 500
    target 697
    kind "relation"
    relation "went to"
    weight 1
  ]
  edge [
    source 500
    target 707
    kind "mentions"
  ]
  edge [
    source 500
    target 717
    kind "mentions"
  ]
  edge [
    source 500
    target 742
    kind "mentions"
  ]
  edge [
    source 500
    target 762
    kind "mentions"
  ]
  edge [
    source 500
    target 766
    kind "mentions"
  ]
  edge [
    source 500
    target 783
    kind "mentions"
  ]
  edge [
    source 500
    target 784
    kind "relation"
    relation "rode to | arrived at"
    weight 2
  ]
  edge [
    source 500
    target 906
    kind "mentions"
  ]
  edge [
    source 500
    target 1026
    kind "mentions"
  ]
  edge [
    source 500
    target 1042
    kind "relation"
    relation "came from"
    weight 2
  ]
  edge [
    source 500
    target 1043
    kind "mentions"
  ]
  edge [
    source 500
    target 1098
    kind "mentions"
  ]
  edge [
    source 500
    target 1246
    kind "mentions"
  ]
  edge [
    source 500
    target 1255
    kind "mentions"
  ]
  edge [
    source 500
    target 1262
    kind "mentions"
  ]
  edge [
    source 500
    target 1327
    kind "mentions"
  ]
  edge [
    source 500
    target 1331
    kind "mentions"
  ]
  edge [
    source 500
    target 1765
    kind "mentions"
  ]
  edge [
    source 500
    target 1775
    kind "mentions"
  ]
  edge [
    source 500
    target 1816
    kind "mentions"
  ]
  edge [
    source 500
    target 955
    kind "relation"
    relation "has gone to settle at"
    weight 1
  ]
  edge [
    source 501
    target 1415
    kind "mentions"
  ]
  edge [
    source 501
    target 1422
    kind "relation"
    relation "was caused by"
    weight 1
  ]
  edge [
    source 504
    target 511
    kind "mentions"
  ]
  edge [
    source 505
    target 511
    kind "mentions"
  ]
  edge [
    source 506
    target 510
    kind "relation"
    relation "is used for"
    weight 1
  ]
  edge [
    source 506
    target 511
    kind "mentions"
  ]
  edge [
    source 506
    target 515
    kind "relation"
    relation "is used for"
    weight 1
  ]
  edge [
    source 507
    target 517
    kind "mentions"
  ]
  edge [
    source 507
    target 520
    kind "relation"
    relation "are in"
    weight 1
  ]
  edge [
    source 509
    target 511
    kind "mentions"
  ]
  edge [
    source 511
    target 512
    kind "mentions"
  ]
  edge [
    source 511
    target 513
    kind "mentions"
  ]
  edge [
    source 511
    target 514
    kind "mentions"
  ]
  edge [
    source 511
    target 515
    kind "mentions"
  ]
  edge [
    source 511
    target 1945
    kind "summarizes"
  ]
  edge [
    source 512
    target 912
    kind "mentions"
  ]
  edge [
    source 512
    target 929
    kind "mentions"
  ]
  edge [
    source 512
    target 1542
    kind "mentions"
  ]
  edge [
    source 512
    target 1552
    kind "relation"
    relation "was the day of"
    weight 1
  ]
  edge [
    source 512
    target 1553
    kind "relation"
    relation "was the day of"
    weight 1
  ]
  edge [
    source 512
    target 1554
    kind "relation"
    relation "was the day of"
    weight 1
  ]
  edge [
    source 516
    target 517
    kind "from_chunk"
  ]
  edge [
    source 516
    target 527
    kind "from_chunk"
  ]
  edge [
    source 516
    target 541
    kind "from_chunk"
  ]
  edge [
    source 517
    target 518
    kind "mentions"
  ]
  edge [
    source 517
    target 519
    kind "mentions"
  ]
  edge [
    source 517
    target 520
    kind "mentions"
  ]
  edge [
    source 517
    target 521
    kind "mentions"
  ]
  edge [
    source 517
    target 522
    kind "mentions"
  ]
  edge [
    source 517
    target 523
    kind "mentions"
  ]
  edge [
    source 517
    target 524
    kind "mentions"
  ]
  edge [
    source 517
    target 525
    kind "mentions"
  ]
  edge [
    source 517
    target 526
    kind "mentions"
  ]
  edge [
    source 517
    target 1945
    kind "summarizes"
  ]
  edge [
    source 518
    target 519
    kind "relation"
    relation "clothes with"
    weight 1
  ]
  edge [
    source 519
    target 520
    kind "relation"
    relation "is used for"
    weight 1
  ]
  edge [
    source 523
    target 615
    kind "mentions"
  ]
  edge [
    source 523
    target 1026
    kind "mentions"
  ]
  edge [
    source 524
    target 527
    kind "mentions"
  ]
  edge [
    source 524
    target 1585
    kind "mentions"
  ]
  edge [
    source 524
    target 1592
    kind "relation"
    relation "was a day when"
    weight 1
  ]
  edge [
    source 525
    target 527
    kind "mentions"
  ]
  edge [
    source 527
    target 528
    kind "mentions"
  ]
  edge [
    source 527
    target 529
    kind "mentions"
  ]
  edge [
    source 527
    target 530
    kind "mentions"
  ]
  edge [
    source 527
    target 531
    kind "mentions"
  ]
  edge [
    source 527
    target 532
    kind "mentions"
  ]
  edge [
    source 527
    target 533
    kind "mentions"
  ]
  edge [
    source 527
    target 534
    kind "mentions"
  ]
  edge [
    source 527
    target 535
    kind "mentions"
  ]
  edge [
    source 527
    target 536
    kind "mentions"
  ]
  edge [
    source 527
    target 537
    kind "mentions"
  ]
  edge [
    source 527
    target 538
    kind "mentions"
  ]
  edge [
    source 527
    target 539
    kind "mentions"
  ]
  edge [
    source 527
    target 540
    kind "mentions"
  ]
  edge [
    source 527
    target 1947
    kind "summarizes"
  ]
  edge [
    source 529
    target 605
    kind "mentions"
  ]
  edge [
    source 530
    target 531
    kind "relation"
    relation "makes much of"
    weight 1
  ]
  edge [
    source 530
    target 1374
    kind "mentions"
  ]
  edge [
    source 530
    target 1384
    kind "mentions"
  ]
  edge [
    source 530
    target 1386
    kind "relation"
    relation "is at"
    weight 1
  ]
  edge [
    source 530
    target 1385
    kind "relation"
    relation "is being made fit for"
    weight 1
  ]
  edge [
    source 530
    target 1387
    kind "relation"
    relation "is troubled by"
    weight 1
  ]
  edge [
    source 532
    target 533
    kind "relation"
    relation "is a comedy by"
    weight 2
  ]
  edge [
    source 532
    target 534
    kind "relation"
    relation "was first printed in"
    weight 1
  ]
  edge [
    source 532
    target 1415
    kind "mentions"
  ]
  edge [
    source 532
    target 1921
    kind "mentions"
  ]
  edge [
    source 533
    target 1921
    kind "mentions"
  ]
  edge [
    source 537
    target 538
    kind "relation"
    relation "is located in"
    weight 1
  ]
  edge [
    source 540
    target 1294
    kind "mentions"
  ]
  edge [
    source 541
    target 542
    kind "mentions"
  ]
  edge [
    source 541
    target 543
    kind "mentions"
  ]
  edge [
    source 541
    target 544
    kind "mentions"
  ]
  edge [
    source 541
    target 545
    kind "mentions"
  ]
  edge [
    source 541
    target 1948
    kind "summarizes"
  ]
  edge [
    source 542
    target 987
    kind "mentions"
  ]
  edge [
    source 542
    target 1600
    kind "mentions"
  ]
  edge [
    source 542
    target 1606
    kind "relation"
    relation "was a day when"
    weight 1
  ]
  edge [
    source 543
    target 581
    kind "mentions"
  ]
  edge [
    source 543
    target 615
    kind "mentions"
  ]
  edge [
    source 543
    target 742
    kind "mentions"
  ]
  edge [
    source 543
    target 775
    kind "mentions"
  ]
  edge [
    source 543
    target 1161
    kind "mentions"
  ]
  edge [
    source 543
    target 1176
    kind "mentions"
  ]
  edge [
    source 543
    target 1415
    kind "mentions"
  ]
  edge [
    source 543
    target 1420
    kind "relation"
    relation "was not at"
    weight 1
  ]
  edge [
    source 543
    target 1436
    kind "mentions"
  ]
  edge [
    source 543
    target 1444
    kind "relation"
    relation "sat with"
    weight 1
  ]
  edge [
    source 543
    target 1623
    kind "mentions"
  ]
  edge [
    source 544
    target 1434
    kind "mentions"
  ]
  edge [
    source 546
    target 547
    kind "from_chunk"
  ]
  edge [
    source 546
    target 564
    kind "from_chunk"
  ]
  edge [
    source 546
    target 568
    kind "from_chunk"
  ]
  edge [
    source 547
    target 548
    kind "mentions"
  ]
  edge [
    source 547
    target 549
    kind "mentions"
  ]
  edge [
    source 547
    target 550
    kind "mentions"
  ]
  edge [
    source 547
    target 551
    kind "mentions"
  ]
  edge [
    source 547
    target 552
    kind "mentions"
  ]
  edge [
    source 547
    target 553
    kind "mentions"
  ]
  edge [
    source 547
    target 554
    kind "mentions"
  ]
  edge [
    source 547
    target 555
    kind "mentions"
  ]
  edge [
    source 547
    target 556
    kind "mentions"
  ]
  edge [
    source 547
    target 557
    kind "mentions"
  ]
  edge [
    source 547
    target 558
    kind "mentions"
  ]
  edge [
    source 547
    target 559
    kind "mentions"
  ]
  edge [
    source 547
    target 560
    kind "mentions"
  ]
  edge [
    source 547
    target 561
    kind "mentions"
  ]
  edge [
    source 547
    target 562
    kind "mentions"
  ]
  edge [
    source 547
    target 563
    kind "mentions"
  ]
  edge [
    source 547
    target 1948
    kind "summarizes"
  ]
  edge [
    source 548
    target 987
    kind "mentions"
  ]
  edge [
    source 549
    target 550
    kind "relation"
    relation "has a daughter named"
    weight 1
  ]
  edge [
    source 549
    target 602
    kind "mentions"
  ]
  edge [
    source 550
    target 602
    kind "mentions"
  ]
  edge [
    source 551
    target 552
    kind "relation"
    relation "has a wife"
    weight 1
  ]
  edge [
    source 551
    target 602
    kind "mentions"
  ]
  edge [
    source 553
    target 561
    kind "relation"
    relation "was visited by"
    weight 1
  ]
  edge [
    source 554
    target 555
    kind "relation"
    relation "is sister of"
    weight 1
  ]
  edge [
    source 554
    target 562
    kind "relation"
    relation "is considered the greatest beauty among"
    weight 1
  ]
  edge [
    source 556
    target 563
    kind "relation"
    relation "was the location of"
    weight 1
  ]
  edge [
    source 557
    target 1273
    kind "mentions"
  ]
  edge [
    source 558
    target 568
    kind "mentions"
  ]
  edge [
    source 559
    target 568
    kind "mentions"
  ]
  edge [
    source 559
    target 570
    kind "relation"
    relation "attended"
    weight 1
  ]
  edge [
    source 559
    target 569
    kind "relation"
    relation "was not well"
    weight 1
  ]
  edge [
    source 559
    target 1013
    kind "mentions"
  ]
  edge [
    source 559
    target 1098
    kind "mentions"
  ]
  edge [
    source 559
    target 1396
    kind "mentions"
  ]
  edge [
    source 559
    target 1585
    kind "mentions"
  ]
  edge [
    source 559
    target 1650
    kind "mentions"
  ]
  edge [
    source 559
    target 1664
    kind "relation"
    relation "call"
    weight 1
  ]
  edge [
    source 559
    target 1651
    kind "relation"
    relation "announces he will no longer keep | feels relief after ending"
    weight 2
  ]
  edge [
    source 559
    target 1654
    kind "relation"
    relation "states he will have nothing to do with"
    weight 1
  ]
  edge [
    source 559
    target 1666
    kind "relation"
    relation "stays with"
    weight 1
  ]
  edge [
    source 559
    target 1672
    kind "mentions"
  ]
  edge [
    source 559
    target 1673
    kind "relation"
    relation "became lazy and spoilt due to"
    weight 1
  ]
  edge [
    source 559
    target 1816
    kind "mentions"
  ]
  edge [
    source 559
    target 1825
    kind "relation"
    relation "is now left to manage"
    weight 1
  ]
  edge [
    source 559
    target 1826
    kind "relation"
    relation "will manage until"
    weight 1
  ]
  edge [
    source 560
    target 1158
    kind "mentions"
  ]
  edge [
    source 563
    target 1585
    kind "mentions"
  ]
  edge [
    source 564
    target 565
    kind "mentions"
  ]
  edge [
    source 564
    target 566
    kind "mentions"
  ]
  edge [
    source 564
    target 567
    kind "mentions"
  ]
  edge [
    source 564
    target 1939
    kind "summarizes"
  ]
  edge [
    source 565
    target 566
    kind "relation"
    relation "was a holiday"
    weight 1
  ]
  edge [
    source 565
    target 1623
    kind "mentions"
  ]
  edge [
    source 567
    target 960
    kind "mentions"
  ]
  edge [
    source 567
    target 974
    kind "relation"
    relation "was very cold"
    weight 1
  ]
  edge [
    source 567
    target 1650
    kind "mentions"
  ]
  edge [
    source 568
    target 569
    kind "mentions"
  ]
  edge [
    source 568
    target 570
    kind "mentions"
  ]
  edge [
    source 568
    target 1936
    kind "summarizes"
  ]
  edge [
    source 571
    target 572
    kind "from_chunk"
  ]
  edge [
    source 571
    target 581
    kind "from_chunk"
  ]
  edge [
    source 571
    target 583
    kind "from_chunk"
  ]
  edge [
    source 571
    target 587
    kind "from_chunk"
  ]
  edge [
    source 571
    target 596
    kind "from_chunk"
  ]
  edge [
    source 572
    target 573
    kind "mentions"
  ]
  edge [
    source 572
    target 574
    kind "mentions"
  ]
  edge [
    source 572
    target 575
    kind "mentions"
  ]
  edge [
    source 572
    target 576
    kind "mentions"
  ]
  edge [
    source 572
    target 577
    kind "mentions"
  ]
  edge [
    source 572
    target 578
    kind "mentions"
  ]
  edge [
    source 572
    target 579
    kind "mentions"
  ]
  edge [
    source 572
    target 580
    kind "mentions"
  ]
  edge [
    source 572
    target 1942
    kind "summarizes"
  ]
  edge [
    source 573
    target 1542
    kind "mentions"
  ]
  edge [
    source 573
    target 1556
    kind "mentions"
  ]
  edge [
    source 573
    target 1600
    kind "mentions"
  ]
  edge [
    source 573
    target 1752
    kind "mentions"
  ]
  edge [
    source 573
    target 1762
    kind "relation"
    relation "told"
    weight 1
  ]
  edge [
    source 576
    target 579
    kind "relation"
    relation "charged excessively high prices for"
    weight 1
  ]
  edge [
    source 581
    target 582
    kind "mentions"
  ]
  edge [
    source 581
    target 1950
    kind "summarizes"
  ]
  edge [
    source 582
    target 775
    kind "mentions"
  ]
  edge [
    source 582
    target 778
    kind "relation"
    relation "went to | were very merry at"
    weight 2
  ]
  edge [
    source 582
    target 777
    kind "relation"
    relation "had a"
    weight 1
  ]
  edge [
    source 583
    target 584
    kind "mentions"
  ]
  edge [
    source 583
    target 585
    kind "mentions"
  ]
  edge [
    source 583
    target 586
    kind "mentions"
  ]
  edge [
    source 583
    target 1944
    kind "summarizes"
  ]
  edge [
    source 584
    target 1026
    kind "mentions"
  ]
  edge [
    source 584
    target 1042
    kind "relation"
    relation "had arrival of"
    weight 2
  ]
  edge [
    source 584
    target 1043
    kind "mentions"
  ]
  edge [
    source 585
    target 834
    kind "mentions"
  ]
  edge [
    source 585
    target 958
    kind "mentions"
  ]
  edge [
    source 585
    target 1026
    kind "mentions"
  ]
  edge [
    source 585
    target 1043
    kind "mentions"
  ]
  edge [
    source 585
    target 1374
    kind "mentions"
  ]
  edge [
    source 585
    target 1393
    kind "mentions"
  ]
  edge [
    source 585
    target 1542
    kind "mentions"
  ]
  edge [
    source 585
    target 1752
    kind "mentions"
  ]
  edge [
    source 587
    target 588
    kind "mentions"
  ]
  edge [
    source 587
    target 589
    kind "mentions"
  ]
  edge [
    source 587
    target 590
    kind "mentions"
  ]
  edge [
    source 587
    target 591
    kind "mentions"
  ]
  edge [
    source 587
    target 592
    kind "mentions"
  ]
  edge [
    source 587
    target 593
    kind "mentions"
  ]
  edge [
    source 587
    target 594
    kind "mentions"
  ]
  edge [
    source 587
    target 595
    kind "mentions"
  ]
  edge [
    source 587
    target 1941
    kind "summarizes"
  ]
  edge [
    source 588
    target 590
    kind "relation"
    relation "was recommended by"
    weight 1
  ]
  edge [
    source 588
    target 593
    kind "relation"
    relation "taught the narrator to sing"
    weight 1
  ]
  edge [
    source 589
    target 700
    kind "mentions"
  ]
  edge [
    source 590
    target 1298
    kind "mentions"
  ]
  edge [
    source 591
    target 640
    kind "mentions"
  ]
  edge [
    source 591
    target 700
    kind "mentions"
  ]
  edge [
    source 591
    target 1098
    kind "mentions"
  ]
  edge [
    source 592
    target 717
    kind "mentions"
  ]
  edge [
    source 596
    target 597
    kind "mentions"
  ]
  edge [
    source 596
    target 598
    kind "mentions"
  ]
  edge [
    source 596
    target 599
    kind "mentions"
  ]
  edge [
    source 596
    target 600
    kind "mentions"
  ]
  edge [
    source 596
    target 1946
    kind "summarizes"
  ]
  edge [
    source 597
    target 1118
    kind "mentions"
  ]
  edge [
    source 597
    target 1126
    kind "mentions"
  ]
  edge [
    source 597
    target 1196
    kind "mentions"
  ]
  edge [
    source 597
    target 1765
    kind "mentions"
  ]
  edge [
    source 597
    target 1775
    kind "mentions"
  ]
  edge [
    source 599
    target 600
    kind "relation"
    relation "were sent to"
    weight 1
  ]
  edge [
    source 601
    target 602
    kind "from_chunk"
  ]
  edge [
    source 601
    target 605
    kind "from_chunk"
  ]
  edge [
    source 601
    target 613
    kind "from_chunk"
  ]
  edge [
    source 602
    target 603
    kind "mentions"
  ]
  edge [
    source 602
    target 604
    kind "mentions"
  ]
  edge [
    source 602
    target 1948
    kind "summarizes"
  ]
  edge [
    source 603
    target 683
    kind "mentions"
  ]
  edge [
    source 603
    target 1181
    kind "mentions"
  ]
  edge [
    source 605
    target 606
    kind "mentions"
  ]
  edge [
    source 605
    target 607
    kind "mentions"
  ]
  edge [
    source 605
    target 608
    kind "mentions"
  ]
  edge [
    source 605
    target 609
    kind "mentions"
  ]
  edge [
    source 605
    target 610
    kind "mentions"
  ]
  edge [
    source 605
    target 611
    kind "mentions"
  ]
  edge [
    source 605
    target 612
    kind "mentions"
  ]
  edge [
    source 605
    target 1936
    kind "summarizes"
  ]
  edge [
    source 606
    target 1045
    kind "mentions"
  ]
  edge [
    source 606
    target 1053
    kind "mentions"
  ]
  edge [
    source 606
    target 1055
    kind "mentions"
  ]
  edge [
    source 606
    target 1650
    kind "mentions"
  ]
  edge [
    source 606
    target 1669
    kind "relation"
    relation "is the day of"
    weight 1
  ]
  edge [
    source 608
    target 613
    kind "mentions"
  ]
  edge [
    source 608
    target 1069
    kind "mentions"
  ]
  edge [
    source 608
    target 1716
    kind "mentions"
  ]
  edge [
    source 608
    target 1729
    kind "relation"
    relation "was the date when"
    weight 1
  ]
  edge [
    source 609
    target 615
    kind "mentions"
  ]
  edge [
    source 609
    target 783
    kind "mentions"
  ]
  edge [
    source 609
    target 796
    kind "relation"
    relation "was in"
    weight 1
  ]
  edge [
    source 609
    target 803
    kind "mentions"
  ]
  edge [
    source 609
    target 912
    kind "mentions"
  ]
  edge [
    source 609
    target 927
    kind "relation"
    relation "engages in"
    weight 1
  ]
  edge [
    source 609
    target 960
    kind "mentions"
  ]
  edge [
    source 609
    target 1013
    kind "mentions"
  ]
  edge [
    source 609
    target 1246
    kind "mentions"
  ]
  edge [
    source 609
    target 1558
    kind "mentions"
  ]
  edge [
    source 612
    target 1349
    kind "mentions"
  ]
  edge [
    source 612
    target 824
    kind "relation"
    relation "returned home by"
    weight 1
  ]
  edge [
    source 613
    target 1933
    kind "summarizes"
  ]
  edge [
    source 614
    target 615
    kind "from_chunk"
  ]
  edge [
    source 614
    target 637
    kind "from_chunk"
  ]
  edge [
    source 615
    target 616
    kind "mentions"
  ]
  edge [
    source 615
    target 617
    kind "mentions"
  ]
  edge [
    source 615
    target 618
    kind "mentions"
  ]
  edge [
    source 615
    target 619
    kind "mentions"
  ]
  edge [
    source 615
    target 620
    kind "mentions"
  ]
  edge [
    source 615
    target 621
    kind "mentions"
  ]
  edge [
    source 615
    target 622
    kind "mentions"
  ]
  edge [
    source 615
    target 623
    kind "mentions"
  ]
  edge [
    source 615
    target 624
    kind "mentions"
  ]
  edge [
    source 615
    target 625
    kind "mentions"
  ]
  edge [
    source 615
    target 626
    kind "mentions"
  ]
  edge [
    source 615
    target 627
    kind "mentions"
  ]
  edge [
    source 615
    target 628
    kind "mentions"
  ]
  edge [
    source 615
    target 629
    kind "mentions"
  ]
  edge [
    source 615
    target 630
    kind "mentions"
  ]
  edge [
    source 615
    target 631
    kind "mentions"
  ]
  edge [
    source 615
    target 632
    kind "mentions"
  ]
  edge [
    source 615
    target 633
    kind "mentions"
  ]
  edge [
    source 615
    target 634
    kind "mentions"
  ]
  edge [
    source 615
    target 635
    kind "mentions"
  ]
  edge [
    source 615
    target 636
    kind "mentions"
  ]
  edge [
    source 615
    target 1935
    kind "summarizes"
  ]
  edge [
    source 619
    target 1016
    kind "mentions"
  ]
  edge [
    source 619
    target 1020
    kind "relation"
    relation "states that more than found"
    weight 1
  ]
  edge [
    source 620
    target 1181
    kind "mentions"
  ]
  edge [
    source 620
    target 1187
    kind "relation"
    relation "spoke negatively about"
    weight 1
  ]
  edge [
    source 620
    target 1436
    kind "mentions"
  ]
  edge [
    source 620
    target 1650
    kind "mentions"
  ]
  edge [
    source 620
    target 1653
    kind "relation"
    relation "looks askew at | does not conform to"
    weight 2
  ]
  edge [
    source 620
    target 1908
    kind "mentions"
  ]
  edge [
    source 623
    target 624
    kind "relation"
    relation "sent"
    weight 1
  ]
  edge [
    source 624
    target 625
    kind "relation"
    relation "cost"
    weight 1
  ]
  edge [
    source 624
    target 629
    kind "relation"
    relation "had hat only left in lieu of"
    weight 1
  ]
  edge [
    source 624
    target 630
    kind "relation"
    relation "had hat only left in lieu of"
    weight 1
  ]
  edge [
    source 626
    target 635
    kind "relation"
    relation "cost"
    weight 1
  ]
  edge [
    source 627
    target 635
    kind "relation"
    relation "had hat cost"
    weight 1
  ]
  edge [
    source 628
    target 636
    kind "relation"
    relation "was lord sandwich's vexation at"
    weight 1
  ]
  edge [
    source 637
    target 638
    kind "mentions"
  ]
  edge [
    source 637
    target 1948
    kind "summarizes"
  ]
  edge [
    source 638
    target 1116
    kind "mentions"
  ]
  edge [
    source 638
    target 1114
    kind "relation"
    relation "went to church on"
    weight 1
  ]
  edge [
    source 638
    target 1752
    kind "mentions"
  ]
  edge [
    source 639
    target 640
    kind "from_chunk"
  ]
  edge [
    source 639
    target 659
    kind "from_chunk"
  ]
  edge [
    source 640
    target 641
    kind "mentions"
  ]
  edge [
    source 640
    target 642
    kind "mentions"
  ]
  edge [
    source 640
    target 643
    kind "mentions"
  ]
  edge [
    source 640
    target 644
    kind "mentions"
  ]
  edge [
    source 640
    target 645
    kind "mentions"
  ]
  edge [
    source 640
    target 646
    kind "mentions"
  ]
  edge [
    source 640
    target 647
    kind "mentions"
  ]
  edge [
    source 640
    target 648
    kind "mentions"
  ]
  edge [
    source 640
    target 649
    kind "mentions"
  ]
  edge [
    source 640
    target 650
    kind "mentions"
  ]
  edge [
    source 640
    target 651
    kind "mentions"
  ]
  edge [
    source 640
    target 652
    kind "mentions"
  ]
  edge [
    source 640
    target 653
    kind "mentions"
  ]
  edge [
    source 640
    target 654
    kind "mentions"
  ]
  edge [
    source 640
    target 655
    kind "mentions"
  ]
  edge [
    source 640
    target 656
    kind "mentions"
  ]
  edge [
    source 640
    target 657
    kind "mentions"
  ]
  edge [
    source 640
    target 658
    kind "mentions"
  ]
  edge [
    source 640
    target 1950
    kind "summarizes"
  ]
  edge [
    source 642
    target 646
    kind "relation"
    relation "was between"
    weight 1
  ]
  edge [
    source 643
    target 646
    kind "relation"
    relation "was between"
    weight 1
  ]
  edge [
    source 647
    target 659
    kind "mentions"
  ]
  edge [
    source 648
    target 659
    kind "mentions"
  ]
  edge [
    source 649
    target 659
    kind "mentions"
  ]
  edge [
    source 650
    target 654
    kind "relation"
    relation "is a member of"
    weight 2
  ]
  edge [
    source 650
    target 659
    kind "mentions"
  ]
  edge [
    source 650
    target 663
    kind "mentions"
  ]
  edge [
    source 650
    target 664
    kind "relation"
    relation "became fat and sallow due to"
    weight 1
  ]
  edge [
    source 650
    target 665
    kind "relation"
    relation "was previously"
    weight 1
  ]
  edge [
    source 650
    target 666
    kind "relation"
    relation "commended | is considered the only book that made"
    weight 2
  ]
  edge [
    source 650
    target 667
    kind "relation"
    relation "is described as having become"
    weight 1
  ]
  edge [
    source 651
    target 654
    kind "relation"
    relation "is a member of"
    weight 2
  ]
  edge [
    source 651
    target 659
    kind "mentions"
  ]
  edge [
    source 652
    target 654
    kind "relation"
    relation "is a member of"
    weight 2
  ]
  edge [
    source 652
    target 659
    kind "mentions"
  ]
  edge [
    source 653
    target 654
    kind "relation"
    relation "is a member of"
    weight 2
  ]
  edge [
    source 653
    target 659
    kind "mentions"
  ]
  edge [
    source 654
    target 659
    kind "mentions"
  ]
  edge [
    source 656
    target 659
    kind "mentions"
  ]
  edge [
    source 657
    target 659
    kind "mentions"
  ]
  edge [
    source 658
    target 659
    kind "mentions"
  ]
  edge [
    source 659
    target 660
    kind "mentions"
  ]
  edge [
    source 659
    target 661
    kind "mentions"
  ]
  edge [
    source 659
    target 1950
    kind "summarizes"
  ]
  edge [
    source 660
    target 1118
    kind "mentions"
  ]
  edge [
    source 660
    target 1126
    kind "mentions"
  ]
  edge [
    source 660
    target 1763
    kind "mentions"
  ]
  edge [
    source 660
    target 1775
    kind "mentions"
  ]
  edge [
    source 660
    target 1776
    kind "relation"
    relation "was the day of"
    weight 1
  ]
  edge [
    source 660
    target 1777
    kind "relation"
    relation "was the day of"
    weight 1
  ]
  edge [
    source 660
    target 1778
    kind "relation"
    relation "was the day of"
    weight 1
  ]
  edge [
    source 660
    target 1779
    kind "relation"
    relation "was the day of"
    weight 1
  ]
  edge [
    source 662
    target 663
    kind "from_chunk"
  ]
  edge [
    source 662
    target 668
    kind "from_chunk"
  ]
  edge [
    source 662
    target 679
    kind "from_chunk"
  ]
  edge [
    source 663
    target 664
    kind "mentions"
  ]
  edge [
    source 663
    target 665
    kind "mentions"
  ]
  edge [
    source 663
    target 666
    kind "mentions"
  ]
  edge [
    source 663
    target 667
    kind "mentions"
  ]
  edge [
    source 663
    target 1950
    kind "summarizes"
  ]
  edge [
    source 666
    target 1493
    kind "mentions"
  ]
  edge [
    source 668
    target 669
    kind "mentions"
  ]
  edge [
    source 668
    target 670
    kind "mentions"
  ]
  edge [
    source 668
    target 671
    kind "mentions"
  ]
  edge [
    source 668
    target 672
    kind "mentions"
  ]
  edge [
    source 668
    target 673
    kind "mentions"
  ]
  edge [
    source 668
    target 674
    kind "mentions"
  ]
  edge [
    source 668
    target 675
    kind "mentions"
  ]
  edge [
    source 668
    target 676
    kind "mentions"
  ]
  edge [
    source 668
    target 677
    kind "mentions"
  ]
  edge [
    source 668
    target 678
    kind "mentions"
  ]
  edge [
    source 668
    target 1948
    kind "summarizes"
  ]
  edge [
    source 669
    target 1765
    kind "mentions"
  ]
  edge [
    source 669
    target 1775
    kind "mentions"
  ]
  edge [
    source 669
    target 1780
    kind "relation"
    relation "was the day of"
    weight 1
  ]
  edge [
    source 669
    target 1782
    kind "mentions"
  ]
  edge [
    source 670
    target 674
    kind "relation"
    relation "had been levied fourteen weeks prior to"
    weight 1
  ]
  edge [
    source 670
    target 678
    kind "relation"
    relation "was abolished in"
    weight 1
  ]
  edge [
    source 671
    target 672
    kind "relation"
    relation "has an account-book beginning in"
    weight 1
  ]
  edge [
    source 671
    target 674
    kind "relation"
    relation "collected money on"
    weight 1
  ]
  edge [
    source 671
    target 675
    kind "relation"
    relation "collected"
    weight 1
  ]
  edge [
    source 675
    target 676
    kind "relation"
    relation "was collected for"
    weight 1
  ]
  edge [
    source 676
    target 677
    kind "relation"
    relation "lost property in"
    weight 1
  ]
  edge [
    source 678
    target 681
    kind "mentions"
  ]
  edge [
    source 678
    target 682
    kind "relation"
    relation "were abolished in"
    weight 1
  ]
  edge [
    source 679
    target 1951
    kind "summarizes"
  ]
  edge [
    source 680
    target 681
    kind "from_chunk"
  ]
  edge [
    source 680
    target 683
    kind "from_chunk"
  ]
  edge [
    source 680
    target 684
    kind "from_chunk"
  ]
  edge [
    source 680
    target 688
    kind "from_chunk"
  ]
  edge [
    source 680
    target 691
    kind "from_chunk"
  ]
  edge [
    source 680
    target 694
    kind "from_chunk"
  ]
  edge [
    source 680
    target 696
    kind "from_chunk"
  ]
  edge [
    source 681
    target 682
    kind "mentions"
  ]
  edge [
    source 681
    target 1948
    kind "summarizes"
  ]
  edge [
    source 683
    target 1940
    kind "summarizes"
  ]
  edge [
    source 684
    target 685
    kind "mentions"
  ]
  edge [
    source 684
    target 686
    kind "mentions"
  ]
  edge [
    source 684
    target 687
    kind "mentions"
  ]
  edge [
    source 684
    target 1940
    kind "summarizes"
  ]
  edge [
    source 688
    target 689
    kind "mentions"
  ]
  edge [
    source 688
    target 690
    kind "mentions"
  ]
  edge [
    source 688
    target 1935
    kind "summarizes"
  ]
  edge [
    source 689
    target 1894
    kind "mentions"
  ]
  edge [
    source 691
    target 692
    kind "mentions"
  ]
  edge [
    source 691
    target 693
    kind "mentions"
  ]
  edge [
    source 691
    target 1945
    kind "summarizes"
  ]
  edge [
    source 692
    target 693
    kind "relation"
    relation "was going to end with | was going to send"
    weight 2
  ]
  edge [
    source 693
    target 707
    kind "mentions"
  ]
  edge [
    source 694
    target 695
    kind "mentions"
  ]
  edge [
    source 694
    target 1940
    kind "summarizes"
  ]
  edge [
    source 696
    target 697
    kind "mentions"
  ]
  edge [
    source 696
    target 698
    kind "mentions"
  ]
  edge [
    source 696
    target 1936
    kind "summarizes"
  ]
  edge [
    source 699
    target 700
    kind "from_chunk"
  ]
  edge [
    source 699
    target 707
    kind "from_chunk"
  ]
  edge [
    source 700
    target 701
    kind "mentions"
  ]
  edge [
    source 700
    target 702
    kind "mentions"
  ]
  edge [
    source 700
    target 703
    kind "mentions"
  ]
  edge [
    source 700
    target 704
    kind "mentions"
  ]
  edge [
    source 700
    target 705
    kind "mentions"
  ]
  edge [
    source 700
    target 706
    kind "mentions"
  ]
  edge [
    source 700
    target 1941
    kind "summarizes"
  ]
  edge [
    source 701
    target 1055
    kind "mentions"
  ]
  edge [
    source 701
    target 1161
    kind "mentions"
  ]
  edge [
    source 702
    target 705
    kind "relation"
    relation "cost"
    weight 1
  ]
  edge [
    source 703
    target 706
    kind "relation"
    relation "cost"
    weight 1
  ]
  edge [
    source 707
    target 708
    kind "mentions"
  ]
  edge [
    source 707
    target 709
    kind "mentions"
  ]
  edge [
    source 707
    target 710
    kind "mentions"
  ]
  edge [
    source 707
    target 711
    kind "mentions"
  ]
  edge [
    source 707
    target 712
    kind "mentions"
  ]
  edge [
    source 707
    target 713
    kind "mentions"
  ]
  edge [
    source 707
    target 714
    kind "mentions"
  ]
  edge [
    source 707
    target 715
    kind "mentions"
  ]
  edge [
    source 707
    target 1941
    kind "summarizes"
  ]
  edge [
    source 708
    target 1567
    kind "mentions"
  ]
  edge [
    source 708
    target 1582
    kind "mentions"
  ]
  edge [
    source 711
    target 1816
    kind "mentions"
  ]
  edge [
    source 711
    target 1909
    kind "mentions"
  ]
  edge [
    source 711
    target 1903
    kind "relation"
    relation "was given to"
    weight 1
  ]
  edge [
    source 716
    target 717
    kind "from_chunk"
  ]
  edge [
    source 716
    target 740
    kind "from_chunk"
  ]
  edge [
    source 717
    target 718
    kind "mentions"
  ]
  edge [
    source 717
    target 719
    kind "mentions"
  ]
  edge [
    source 717
    target 720
    kind "mentions"
  ]
  edge [
    source 717
    target 721
    kind "mentions"
  ]
  edge [
    source 717
    target 722
    kind "mentions"
  ]
  edge [
    source 717
    target 723
    kind "mentions"
  ]
  edge [
    source 717
    target 724
    kind "mentions"
  ]
  edge [
    source 717
    target 725
    kind "mentions"
  ]
  edge [
    source 717
    target 726
    kind "mentions"
  ]
  edge [
    source 717
    target 727
    kind "mentions"
  ]
  edge [
    source 717
    target 728
    kind "mentions"
  ]
  edge [
    source 717
    target 729
    kind "mentions"
  ]
  edge [
    source 717
    target 730
    kind "mentions"
  ]
  edge [
    source 717
    target 731
    kind "mentions"
  ]
  edge [
    source 717
    target 732
    kind "mentions"
  ]
  edge [
    source 717
    target 733
    kind "mentions"
  ]
  edge [
    source 717
    target 734
    kind "mentions"
  ]
  edge [
    source 717
    target 735
    kind "mentions"
  ]
  edge [
    source 717
    target 736
    kind "mentions"
  ]
  edge [
    source 717
    target 737
    kind "mentions"
  ]
  edge [
    source 717
    target 738
    kind "mentions"
  ]
  edge [
    source 717
    target 739
    kind "mentions"
  ]
  edge [
    source 717
    target 1951
    kind "summarizes"
  ]
  edge [
    source 718
    target 720
    kind "relation"
    relation "was going to"
    weight 1
  ]
  edge [
    source 718
    target 1161
    kind "mentions"
  ]
  edge [
    source 718
    target 1204
    kind "mentions"
  ]
  edge [
    source 718
    target 1219
    kind "mentions"
  ]
  edge [
    source 718
    target 1220
    kind "relation"
    relation "are brothers of"
    weight 1
  ]
  edge [
    source 718
    target 1223
    kind "mentions"
  ]
  edge [
    source 718
    target 1234
    kind "relation"
    relation "described how young men in parliament acted"
    weight 1
  ]
  edge [
    source 718
    target 1235
    kind "mentions"
  ]
  edge [
    source 718
    target 1231
    kind "relation"
    relation "described how"
    weight 1
  ]
  edge [
    source 721
    target 783
    kind "mentions"
  ]
  edge [
    source 721
    target 787
    kind "relation"
    relation "was placed on"
    weight 1
  ]
  edge [
    source 721
    target 788
    kind "relation"
    relation "was in"
    weight 1
  ]
  edge [
    source 721
    target 789
    kind "relation"
    relation "was in"
    weight 1
  ]
  edge [
    source 721
    target 790
    kind "relation"
    relation "was moved to"
    weight 1
  ]
  edge [
    source 721
    target 795
    kind "relation"
    relation "was watched by"
    weight 1
  ]
  edge [
    source 721
    target 803
    kind "mentions"
  ]
  edge [
    source 721
    target 830
    kind "mentions"
  ]
  edge [
    source 721
    target 906
    kind "mentions"
  ]
  edge [
    source 721
    target 960
    kind "mentions"
  ]
  edge [
    source 721
    target 1026
    kind "mentions"
  ]
  edge [
    source 721
    target 1042
    kind "relation"
    relation "contained all papers of"
    weight 2
  ]
  edge [
    source 721
    target 1043
    kind "mentions"
  ]
  edge [
    source 721
    target 1131
    kind "mentions"
  ]
  edge [
    source 721
    target 1137
    kind "relation"
    relation "is left by"
    weight 1
  ]
  edge [
    source 724
    target 1645
    kind "mentions"
  ]
  edge [
    source 724
    target 1443
    kind "relation"
    relation "introduced the use of"
    weight 1
  ]
  edge [
    source 725
    target 742
    kind "mentions"
  ]
  edge [
    source 725
    target 1436
    kind "mentions"
  ]
  edge [
    source 725
    target 1443
    kind "relation"
    relation "was performed with"
    weight 1
  ]
  edge [
    source 725
    target 1440
    kind "relation"
    relation "was at"
    weight 1
  ]
  edge [
    source 725
    target 1464
    kind "mentions"
  ]
  edge [
    source 725
    target 1615
    kind "mentions"
  ]
  edge [
    source 725
    target 1633
    kind "mentions"
  ]
  edge [
    source 726
    target 736
    kind "relation"
    relation "began on"
    weight 1
  ]
  edge [
    source 727
    target 736
    kind "relation"
    relation "had the second part of"
    weight 1
  ]
  edge [
    source 727
    target 734
    kind "relation"
    relation "was out of place | was hissed off the stage | was not well acted"
    weight 3
  ]
  edge [
    source 729
    target 1464
    kind "mentions"
  ]
  edge [
    source 729
    target 1478
    kind "relation"
    relation "was present"
    weight 1
  ]
  edge [
    source 729
    target 1469
    kind "relation"
    relation "was brought by"
    weight 1
  ]
  edge [
    source 730
    target 737
    kind "relation"
    relation "broke over"
    weight 1
  ]
  edge [
    source 730
    target 738
    kind "relation"
    relation "caused dust to fall into"
    weight 1
  ]
  edge [
    source 730
    target 739
    kind "relation"
    relation "caused dust to fall into"
    weight 1
  ]
  edge [
    source 732
    target 1582
    kind "mentions"
  ]
  edge [
    source 732
    target 1583
    kind "relation"
    relation "have young child who is well"
    weight 1
  ]
  edge [
    source 732
    target 1716
    kind "mentions"
  ]
  edge [
    source 740
    target 1933
    kind "summarizes"
  ]
  edge [
    source 741
    target 742
    kind "from_chunk"
  ]
  edge [
    source 741
    target 762
    kind "from_chunk"
  ]
  edge [
    source 742
    target 743
    kind "mentions"
  ]
  edge [
    source 742
    target 744
    kind "mentions"
  ]
  edge [
    source 742
    target 745
    kind "mentions"
  ]
  edge [
    source 742
    target 746
    kind "mentions"
  ]
  edge [
    source 742
    target 747
    kind "mentions"
  ]
  edge [
    source 742
    target 748
    kind "mentions"
  ]
  edge [
    source 742
    target 749
    kind "mentions"
  ]
  edge [
    source 742
    target 750
    kind "mentions"
  ]
  edge [
    source 742
    target 751
    kind "mentions"
  ]
  edge [
    source 742
    target 752
    kind "mentions"
  ]
  edge [
    source 742
    target 753
    kind "mentions"
  ]
  edge [
    source 742
    target 754
    kind "mentions"
  ]
  edge [
    source 742
    target 755
    kind "mentions"
  ]
  edge [
    source 742
    target 756
    kind "mentions"
  ]
  edge [
    source 742
    target 757
    kind "mentions"
  ]
  edge [
    source 742
    target 758
    kind "mentions"
  ]
  edge [
    source 742
    target 759
    kind "mentions"
  ]
  edge [
    source 742
    target 760
    kind "mentions"
  ]
  edge [
    source 742
    target 761
    kind "mentions"
  ]
  edge [
    source 742
    target 1934
    kind "summarizes"
  ]
  edge [
    source 743
    target 744
    kind "relation"
    relation "died of"
    weight 1
  ]
  edge [
    source 751
    target 761
    kind "relation"
    relation "died on"
    weight 1
  ]
  edge [
    source 751
    target 762
    kind "mentions"
  ]
  edge [
    source 751
    target 764
    kind "relation"
    relation "has fits of stupefaction for"
    weight 1
  ]
  edge [
    source 754
    target 755
    kind "relation"
    relation "attended the burial of"
    weight 1
  ]
  edge [
    source 754
    target 756
    kind "relation"
    relation "received rings for"
    weight 1
  ]
  edge [
    source 756
    target 1262
    kind "mentions"
  ]
  edge [
    source 756
    target 1266
    kind "relation"
    relation "was present with"
    weight 1
  ]
  edge [
    source 756
    target 1574
    kind "mentions"
  ]
  edge [
    source 756
    target 988
    kind "relation"
    relation "is at"
    weight 1
  ]
  edge [
    source 756
    target 1888
    kind "mentions"
  ]
  edge [
    source 759
    target 1600
    kind "mentions"
  ]
  edge [
    source 759
    target 1611
    kind "relation"
    relation "sat and talked"
    weight 1
  ]
  edge [
    source 762
    target 763
    kind "mentions"
  ]
  edge [
    source 762
    target 764
    kind "mentions"
  ]
  edge [
    source 762
    target 1934
    kind "summarizes"
  ]
  edge [
    source 765
    target 766
    kind "from_chunk"
  ]
  edge [
    source 765
    target 775
    kind "from_chunk"
  ]
  edge [
    source 765
    target 779
    kind "from_chunk"
  ]
  edge [
    source 766
    target 767
    kind "mentions"
  ]
  edge [
    source 766
    target 768
    kind "mentions"
  ]
  edge [
    source 766
    target 769
    kind "mentions"
  ]
  edge [
    source 766
    target 770
    kind "mentions"
  ]
  edge [
    source 766
    target 771
    kind "mentions"
  ]
  edge [
    source 766
    target 772
    kind "mentions"
  ]
  edge [
    source 766
    target 773
    kind "mentions"
  ]
  edge [
    source 766
    target 774
    kind "mentions"
  ]
  edge [
    source 766
    target 1936
    kind "summarizes"
  ]
  edge [
    source 767
    target 1633
    kind "mentions"
  ]
  edge [
    source 767
    target 1816
    kind "mentions"
  ]
  edge [
    source 767
    target 1817
    kind "relation"
    relation "has the mitre"
    weight 1
  ]
  edge [
    source 768
    target 773
    kind "relation"
    relation "advised that"
    weight 1
  ]
  edge [
    source 771
    target 779
    kind "mentions"
  ]
  edge [
    source 775
    target 776
    kind "mentions"
  ]
  edge [
    source 775
    target 777
    kind "mentions"
  ]
  edge [
    source 775
    target 778
    kind "mentions"
  ]
  edge [
    source 775
    target 1941
    kind "summarizes"
  ]
  edge [
    source 776
    target 1241
    kind "mentions"
  ]
  edge [
    source 777
    target 1098
    kind "mentions"
  ]
  edge [
    source 777
    target 1181
    kind "mentions"
  ]
  edge [
    source 777
    target 1716
    kind "mentions"
  ]
  edge [
    source 779
    target 780
    kind "mentions"
  ]
  edge [
    source 779
    target 781
    kind "mentions"
  ]
  edge [
    source 779
    target 1936
    kind "summarizes"
  ]
  edge [
    source 782
    target 783
    kind "from_chunk"
  ]
  edge [
    source 782
    target 801
    kind "from_chunk"
  ]
  edge [
    source 783
    target 784
    kind "mentions"
  ]
  edge [
    source 783
    target 785
    kind "mentions"
  ]
  edge [
    source 783
    target 786
    kind "mentions"
  ]
  edge [
    source 783
    target 787
    kind "mentions"
  ]
  edge [
    source 783
    target 788
    kind "mentions"
  ]
  edge [
    source 783
    target 789
    kind "mentions"
  ]
  edge [
    source 783
    target 790
    kind "mentions"
  ]
  edge [
    source 783
    target 791
    kind "mentions"
  ]
  edge [
    source 783
    target 792
    kind "mentions"
  ]
  edge [
    source 783
    target 793
    kind "mentions"
  ]
  edge [
    source 783
    target 794
    kind "mentions"
  ]
  edge [
    source 783
    target 795
    kind "mentions"
  ]
  edge [
    source 783
    target 796
    kind "mentions"
  ]
  edge [
    source 783
    target 797
    kind "mentions"
  ]
  edge [
    source 783
    target 798
    kind "mentions"
  ]
  edge [
    source 783
    target 799
    kind "mentions"
  ]
  edge [
    source 783
    target 800
    kind "mentions"
  ]
  edge [
    source 783
    target 1944
    kind "summarizes"
  ]
  edge [
    source 784
    target 785
    kind "relation"
    relation "set out with"
    weight 1
  ]
  edge [
    source 784
    target 799
    kind "relation"
    relation "and his father"
    weight 1
  ]
  edge [
    source 784
    target 800
    kind "relation"
    relation "and his father"
    weight 2
  ]
  edge [
    source 784
    target 791
    kind "relation"
    relation "went about preparing"
    weight 2
  ]
  edge [
    source 784
    target 792
    kind "relation"
    relation "went about preparing"
    weight 2
  ]
  edge [
    source 784
    target 801
    kind "mentions"
  ]
  edge [
    source 791
    target 801
    kind "mentions"
  ]
  edge [
    source 791
    target 803
    kind "mentions"
  ]
  edge [
    source 791
    target 804
    kind "relation"
    relation "included gathering"
    weight 1
  ]
  edge [
    source 792
    target 801
    kind "mentions"
  ]
  edge [
    source 793
    target 801
    kind "mentions"
  ]
  edge [
    source 793
    target 803
    kind "mentions"
  ]
  edge [
    source 793
    target 806
    kind "relation"
    relation "occurred on"
    weight 1
  ]
  edge [
    source 797
    target 801
    kind "mentions"
  ]
  edge [
    source 797
    target 1374
    kind "mentions"
  ]
  edge [
    source 797
    target 1891
    kind "mentions"
  ]
  edge [
    source 797
    target 1892
    kind "relation"
    relation "was in mourning | showed greatest honour to"
    weight 2
  ]
  edge [
    source 798
    target 801
    kind "mentions"
  ]
  edge [
    source 800
    target 801
    kind "mentions"
  ]
  edge [
    source 801
    target 1944
    kind "summarizes"
  ]
  edge [
    source 802
    target 803
    kind "from_chunk"
  ]
  edge [
    source 802
    target 830
    kind "from_chunk"
  ]
  edge [
    source 803
    target 804
    kind "mentions"
  ]
  edge [
    source 803
    target 805
    kind "mentions"
  ]
  edge [
    source 803
    target 806
    kind "mentions"
  ]
  edge [
    source 803
    target 807
    kind "mentions"
  ]
  edge [
    source 803
    target 808
    kind "mentions"
  ]
  edge [
    source 803
    target 809
    kind "mentions"
  ]
  edge [
    source 803
    target 810
    kind "mentions"
  ]
  edge [
    source 803
    target 811
    kind "mentions"
  ]
  edge [
    source 803
    target 812
    kind "mentions"
  ]
  edge [
    source 803
    target 813
    kind "mentions"
  ]
  edge [
    source 803
    target 814
    kind "mentions"
  ]
  edge [
    source 803
    target 815
    kind "mentions"
  ]
  edge [
    source 803
    target 816
    kind "mentions"
  ]
  edge [
    source 803
    target 817
    kind "mentions"
  ]
  edge [
    source 803
    target 818
    kind "mentions"
  ]
  edge [
    source 803
    target 819
    kind "mentions"
  ]
  edge [
    source 803
    target 820
    kind "mentions"
  ]
  edge [
    source 803
    target 821
    kind "mentions"
  ]
  edge [
    source 803
    target 822
    kind "mentions"
  ]
  edge [
    source 803
    target 823
    kind "mentions"
  ]
  edge [
    source 803
    target 824
    kind "mentions"
  ]
  edge [
    source 803
    target 825
    kind "mentions"
  ]
  edge [
    source 803
    target 826
    kind "mentions"
  ]
  edge [
    source 803
    target 827
    kind "mentions"
  ]
  edge [
    source 803
    target 828
    kind "mentions"
  ]
  edge [
    source 803
    target 829
    kind "mentions"
  ]
  edge [
    source 803
    target 1954
    kind "summarizes"
  ]
  edge [
    source 804
    target 805
    kind "relation"
    relation "included gathering"
    weight 1
  ]
  edge [
    source 806
    target 1369
    kind "mentions"
  ]
  edge [
    source 807
    target 821
    kind "relation"
    relation "caused"
    weight 1
  ]
  edge [
    source 808
    target 811
    kind "relation"
    relation "buried"
    weight 1
  ]
  edge [
    source 809
    target 811
    kind "relation"
    relation "did not mention"
    weight 1
  ]
  edge [
    source 809
    target 810
    kind "relation"
    relation "highlighted"
    weight 1
  ]
  edge [
    source 810
    target 823
    kind "relation"
    relation "was sufficient to make"
    weight 1
  ]
  edge [
    source 813
    target 827
    kind "relation"
    relation "put in a caveat against | filed a caveat against"
    weight 2
  ]
  edge [
    source 813
    target 830
    kind "mentions"
  ]
  edge [
    source 813
    target 929
    kind "mentions"
  ]
  edge [
    source 813
    target 932
    kind "relation"
    relation "arrived"
    weight 1
  ]
  edge [
    source 813
    target 934
    kind "mentions"
  ]
  edge [
    source 813
    target 955
    kind "relation"
    relation "came with"
    weight 1
  ]
  edge [
    source 813
    target 1600
    kind "mentions"
  ]
  edge [
    source 813
    target 1611
    kind "relation"
    relation "found tom trice fair"
    weight 1
  ]
  edge [
    source 813
    target 1685
    kind "mentions"
  ]
  edge [
    source 814
    target 830
    kind "mentions"
  ]
  edge [
    source 814
    target 828
    kind "relation"
    relation "expressed the reason"
    weight 1
  ]
  edge [
    source 814
    target 827
    kind "relation"
    relation "was troubled by"
    weight 1
  ]
  edge [
    source 819
    target 1304
    kind "mentions"
  ]
  edge [
    source 822
    target 1350
    kind "mentions"
  ]
  edge [
    source 822
    target 1351
    kind "relation"
    relation "attended"
    weight 1
  ]
  edge [
    source 822
    target 1352
    kind "relation"
    relation "went to"
    weight 1
  ]
  edge [
    source 822
    target 1542
    kind "mentions"
  ]
  edge [
    source 822
    target 1716
    kind "mentions"
  ]
  edge [
    source 822
    target 1728
    kind "relation"
    relation "took leave of"
    weight 1
  ]
  edge [
    source 824
    target 826
    kind "relation"
    relation "was troubled by"
    weight 1
  ]
  edge [
    source 824
    target 1343
    kind "mentions"
  ]
  edge [
    source 824
    target 1344
    kind "relation"
    relation "went to | dined with"
    weight 2
  ]
  edge [
    source 824
    target 1345
    kind "relation"
    relation "took"
    weight 1
  ]
  edge [
    source 824
    target 1346
    kind "relation"
    relation "took"
    weight 1
  ]
  edge [
    source 824
    target 1347
    kind "relation"
    relation "showed them"
    weight 1
  ]
  edge [
    source 824
    target 1349
    kind "mentions"
  ]
  edge [
    source 824
    target 977
    kind "relation"
    relation "took"
    weight 1
  ]
  edge [
    source 824
    target 1228
    kind "relation"
    relation "gave"
    weight 1
  ]
  edge [
    source 827
    target 829
    kind "relation"
    relation "was troubled by"
    weight 1
  ]
  edge [
    source 827
    target 830
    kind "mentions"
  ]
  edge [
    source 828
    target 829
    kind "relation"
    relation "expressed in"
    weight 1
  ]
  edge [
    source 828
    target 830
    kind "mentions"
  ]
  edge [
    source 830
    target 831
    kind "mentions"
  ]
  edge [
    source 830
    target 832
    kind "mentions"
  ]
  edge [
    source 830
    target 1937
    kind "summarizes"
  ]
  edge [
    source 832
    target 1131
    kind "mentions"
  ]
  edge [
    source 832
    target 1742
    kind "mentions"
  ]
  edge [
    source 833
    target 834
    kind "from_chunk"
  ]
  edge [
    source 833
    target 858
    kind "from_chunk"
  ]
  edge [
    source 834
    target 835
    kind "mentions"
  ]
  edge [
    source 834
    target 836
    kind "mentions"
  ]
  edge [
    source 834
    target 837
    kind "mentions"
  ]
  edge [
    source 834
    target 838
    kind "mentions"
  ]
  edge [
    source 834
    target 839
    kind "mentions"
  ]
  edge [
    source 834
    target 840
    kind "mentions"
  ]
  edge [
    source 834
    target 841
    kind "mentions"
  ]
  edge [
    source 834
    target 842
    kind "mentions"
  ]
  edge [
    source 834
    target 843
    kind "mentions"
  ]
  edge [
    source 834
    target 844
    kind "mentions"
  ]
  edge [
    source 834
    target 845
    kind "mentions"
  ]
  edge [
    source 834
    target 846
    kind "mentions"
  ]
  edge [
    source 834
    target 847
    kind "mentions"
  ]
  edge [
    source 834
    target 848
    kind "mentions"
  ]
  edge [
    source 834
    target 849
    kind "mentions"
  ]
  edge [
    source 834
    target 850
    kind "mentions"
  ]
  edge [
    source 834
    target 851
    kind "mentions"
  ]
  edge [
    source 834
    target 852
    kind "mentions"
  ]
  edge [
    source 834
    target 853
    kind "mentions"
  ]
  edge [
    source 834
    target 854
    kind "mentions"
  ]
  edge [
    source 834
    target 855
    kind "mentions"
  ]
  edge [
    source 834
    target 856
    kind "mentions"
  ]
  edge [
    source 834
    target 857
    kind "mentions"
  ]
  edge [
    source 834
    target 1946
    kind "summarizes"
  ]
  edge [
    source 837
    target 851
    kind "relation"
    relation "means the land goes to"
    weight 1
  ]
  edge [
    source 837
    target 934
    kind "mentions"
  ]
  edge [
    source 843
    target 852
    kind "relation"
    relation "gives advice"
    weight 1
  ]
  edge [
    source 843
    target 960
    kind "mentions"
  ]
  edge [
    source 844
    target 853
    kind "relation"
    relation "is when"
    weight 1
  ]
  edge [
    source 846
    target 854
    kind "relation"
    relation "walk around"
    weight 2
  ]
  edge [
    source 846
    target 858
    kind "mentions"
  ]
  edge [
    source 847
    target 856
    kind "relation"
    relation "is now covered in dirt due to | is currently covered in dirt because of"
    weight 2
  ]
  edge [
    source 847
    target 858
    kind "mentions"
  ]
  edge [
    source 848
    target 858
    kind "mentions"
  ]
  edge [
    source 854
    target 855
    kind "relation"
    relation "view"
    weight 1
  ]
  edge [
    source 854
    target 858
    kind "mentions"
  ]
  edge [
    source 854
    target 859
    kind "relation"
    relation "view"
    weight 1
  ]
  edge [
    source 856
    target 857
    kind "relation"
    relation "will make"
    weight 2
  ]
  edge [
    source 856
    target 858
    kind "mentions"
  ]
  edge [
    source 857
    target 858
    kind "mentions"
  ]
  edge [
    source 858
    target 859
    kind "mentions"
  ]
  edge [
    source 858
    target 1946
    kind "summarizes"
  ]
  edge [
    source 860
    target 861
    kind "from_chunk"
  ]
  edge [
    source 861
    target 862
    kind "mentions"
  ]
  edge [
    source 861
    target 863
    kind "mentions"
  ]
  edge [
    source 861
    target 864
    kind "mentions"
  ]
  edge [
    source 861
    target 865
    kind "mentions"
  ]
  edge [
    source 861
    target 866
    kind "mentions"
  ]
  edge [
    source 861
    target 867
    kind "mentions"
  ]
  edge [
    source 861
    target 868
    kind "mentions"
  ]
  edge [
    source 861
    target 869
    kind "mentions"
  ]
  edge [
    source 861
    target 870
    kind "mentions"
  ]
  edge [
    source 861
    target 871
    kind "mentions"
  ]
  edge [
    source 861
    target 872
    kind "mentions"
  ]
  edge [
    source 861
    target 873
    kind "mentions"
  ]
  edge [
    source 861
    target 874
    kind "mentions"
  ]
  edge [
    source 861
    target 875
    kind "mentions"
  ]
  edge [
    source 861
    target 876
    kind "mentions"
  ]
  edge [
    source 861
    target 877
    kind "mentions"
  ]
  edge [
    source 861
    target 878
    kind "mentions"
  ]
  edge [
    source 861
    target 879
    kind "mentions"
  ]
  edge [
    source 861
    target 880
    kind "mentions"
  ]
  edge [
    source 861
    target 881
    kind "mentions"
  ]
  edge [
    source 861
    target 882
    kind "mentions"
  ]
  edge [
    source 861
    target 883
    kind "mentions"
  ]
  edge [
    source 861
    target 884
    kind "mentions"
  ]
  edge [
    source 861
    target 885
    kind "mentions"
  ]
  edge [
    source 861
    target 886
    kind "mentions"
  ]
  edge [
    source 861
    target 887
    kind "mentions"
  ]
  edge [
    source 861
    target 888
    kind "mentions"
  ]
  edge [
    source 861
    target 1951
    kind "summarizes"
  ]
  edge [
    source 865
    target 884
    kind "relation"
    relation "was in bed at"
    weight 2
  ]
  edge [
    source 865
    target 1895
    kind "mentions"
  ]
  edge [
    source 865
    target 1897
    kind "mentions"
  ]
  edge [
    source 866
    target 885
    kind "relation"
    relation "involved organs"
    weight 1
  ]
  edge [
    source 867
    target 885
    kind "relation"
    relation "were in surplices at"
    weight 1
  ]
  edge [
    source 876
    target 1219
    kind "mentions"
  ]
  edge [
    source 877
    target 878
    kind "relation"
    relation "was born in"
    weight 1
  ]
  edge [
    source 877
    target 880
    kind "relation"
    relation "was educated at"
    weight 1
  ]
  edge [
    source 877
    target 881
    kind "relation"
    relation "was called to the bar at"
    weight 1
  ]
  edge [
    source 877
    target 882
    kind "relation"
    relation "was a member of parliament"
    weight 1
  ]
  edge [
    source 880
    target 1204
    kind "mentions"
  ]
  edge [
    source 884
    target 1897
    kind "mentions"
  ]
  edge [
    source 888
    target 1273
    kind "mentions"
  ]
  edge [
    source 888
    target 1292
    kind "mentions"
  ]
  edge [
    source 888
    target 1314
    kind "mentions"
  ]
  edge [
    source 888
    target 1434
    kind "mentions"
  ]
  edge [
    source 888
    target 1585
    kind "mentions"
  ]
  edge [
    source 888
    target 1716
    kind "mentions"
  ]
  edge [
    source 889
    target 890
    kind "from_chunk"
  ]
  edge [
    source 889
    target 899
    kind "from_chunk"
  ]
  edge [
    source 889
    target 906
    kind "from_chunk"
  ]
  edge [
    source 890
    target 891
    kind "mentions"
  ]
  edge [
    source 890
    target 892
    kind "mentions"
  ]
  edge [
    source 890
    target 893
    kind "mentions"
  ]
  edge [
    source 890
    target 894
    kind "mentions"
  ]
  edge [
    source 890
    target 895
    kind "mentions"
  ]
  edge [
    source 890
    target 896
    kind "mentions"
  ]
  edge [
    source 890
    target 897
    kind "mentions"
  ]
  edge [
    source 890
    target 898
    kind "mentions"
  ]
  edge [
    source 890
    target 1941
    kind "summarizes"
  ]
  edge [
    source 899
    target 900
    kind "mentions"
  ]
  edge [
    source 899
    target 901
    kind "mentions"
  ]
  edge [
    source 899
    target 902
    kind "mentions"
  ]
  edge [
    source 899
    target 903
    kind "mentions"
  ]
  edge [
    source 899
    target 904
    kind "mentions"
  ]
  edge [
    source 899
    target 905
    kind "mentions"
  ]
  edge [
    source 899
    target 1944
    kind "summarizes"
  ]
  edge [
    source 900
    target 905
    kind "relation"
    relation "advised on"
    weight 1
  ]
  edge [
    source 906
    target 907
    kind "mentions"
  ]
  edge [
    source 906
    target 908
    kind "mentions"
  ]
  edge [
    source 906
    target 909
    kind "mentions"
  ]
  edge [
    source 906
    target 910
    kind "mentions"
  ]
  edge [
    source 906
    target 1933
    kind "summarizes"
  ]
  edge [
    source 907
    target 1448
    kind "mentions"
  ]
  edge [
    source 907
    target 1458
    kind "relation"
    relation "was well acquainted with | was well informed about"
    weight 2
  ]
  edge [
    source 907
    target 1462
    kind "mentions"
  ]
  edge [
    source 909
    target 1246
    kind "mentions"
  ]
  edge [
    source 911
    target 912
    kind "from_chunk"
  ]
  edge [
    source 911
    target 929
    kind "from_chunk"
  ]
  edge [
    source 912
    target 913
    kind "mentions"
  ]
  edge [
    source 912
    target 914
    kind "mentions"
  ]
  edge [
    source 912
    target 915
    kind "mentions"
  ]
  edge [
    source 912
    target 916
    kind "mentions"
  ]
  edge [
    source 912
    target 917
    kind "mentions"
  ]
  edge [
    source 912
    target 918
    kind "mentions"
  ]
  edge [
    source 912
    target 919
    kind "mentions"
  ]
  edge [
    source 912
    target 920
    kind "mentions"
  ]
  edge [
    source 912
    target 921
    kind "mentions"
  ]
  edge [
    source 912
    target 922
    kind "mentions"
  ]
  edge [
    source 912
    target 923
    kind "mentions"
  ]
  edge [
    source 912
    target 924
    kind "mentions"
  ]
  edge [
    source 912
    target 925
    kind "mentions"
  ]
  edge [
    source 912
    target 926
    kind "mentions"
  ]
  edge [
    source 912
    target 927
    kind "mentions"
  ]
  edge [
    source 912
    target 928
    kind "mentions"
  ]
  edge [
    source 912
    target 1933
    kind "summarizes"
  ]
  edge [
    source 913
    target 934
    kind "mentions"
  ]
  edge [
    source 913
    target 958
    kind "mentions"
  ]
  edge [
    source 913
    target 960
    kind "mentions"
  ]
  edge [
    source 916
    target 960
    kind "mentions"
  ]
  edge [
    source 919
    target 926
    kind "relation"
    relation "arrived home in country"
    weight 1
  ]
  edge [
    source 920
    target 928
    kind "relation"
    relation "tells family about"
    weight 1
  ]
  edge [
    source 921
    target 928
    kind "relation"
    relation "tells family about"
    weight 1
  ]
  edge [
    source 921
    target 1331
    kind "mentions"
  ]
  edge [
    source 921
    target 1335
    kind "relation"
    relation "will come"
    weight 1
  ]
  edge [
    source 929
    target 930
    kind "mentions"
  ]
  edge [
    source 929
    target 931
    kind "mentions"
  ]
  edge [
    source 929
    target 932
    kind "mentions"
  ]
  edge [
    source 929
    target 1937
    kind "summarizes"
  ]
  edge [
    source 930
    target 934
    kind "mentions"
  ]
  edge [
    source 931
    target 934
    kind "mentions"
  ]
  edge [
    source 933
    target 934
    kind "from_chunk"
  ]
  edge [
    source 933
    target 958
    kind "from_chunk"
  ]
  edge [
    source 934
    target 935
    kind "mentions"
  ]
  edge [
    source 934
    target 936
    kind "mentions"
  ]
  edge [
    source 934
    target 937
    kind "mentions"
  ]
  edge [
    source 934
    target 938
    kind "mentions"
  ]
  edge [
    source 934
    target 939
    kind "mentions"
  ]
  edge [
    source 934
    target 940
    kind "mentions"
  ]
  edge [
    source 934
    target 941
    kind "mentions"
  ]
  edge [
    source 934
    target 942
    kind "mentions"
  ]
  edge [
    source 934
    target 943
    kind "mentions"
  ]
  edge [
    source 934
    target 944
    kind "mentions"
  ]
  edge [
    source 934
    target 945
    kind "mentions"
  ]
  edge [
    source 934
    target 946
    kind "mentions"
  ]
  edge [
    source 934
    target 947
    kind "mentions"
  ]
  edge [
    source 934
    target 948
    kind "mentions"
  ]
  edge [
    source 934
    target 949
    kind "mentions"
  ]
  edge [
    source 934
    target 950
    kind "mentions"
  ]
  edge [
    source 934
    target 951
    kind "mentions"
  ]
  edge [
    source 934
    target 952
    kind "mentions"
  ]
  edge [
    source 934
    target 953
    kind "mentions"
  ]
  edge [
    source 934
    target 954
    kind "mentions"
  ]
  edge [
    source 934
    target 955
    kind "mentions"
  ]
  edge [
    source 934
    target 956
    kind "mentions"
  ]
  edge [
    source 934
    target 957
    kind "mentions"
  ]
  edge [
    source 934
    target 1937
    kind "summarizes"
  ]
  edge [
    source 937
    target 953
    kind "relation"
    relation "amounts to"
    weight 1
  ]
  edge [
    source 937
    target 954
    kind "relation"
    relation "will be included with"
    weight 1
  ]
  edge [
    source 939
    target 1262
    kind "mentions"
  ]
  edge [
    source 947
    target 1262
    kind "mentions"
  ]
  edge [
    source 948
    target 960
    kind "mentions"
  ]
  edge [
    source 949
    target 956
    kind "relation"
    relation "was stung and very much swelled"
    weight 1
  ]
  edge [
    source 952
    target 958
    kind "mentions"
  ]
  edge [
    source 955
    target 1615
    kind "mentions"
  ]
  edge [
    source 955
    target 1618
    kind "relation"
    relation "was taken to"
    weight 1
  ]
  edge [
    source 955
    target 1716
    kind "mentions"
  ]
  edge [
    source 955
    target 1816
    kind "mentions"
  ]
  edge [
    source 957
    target 958
    kind "mentions"
  ]
  edge [
    source 958
    target 1937
    kind "summarizes"
  ]
  edge [
    source 959
    target 960
    kind "from_chunk"
  ]
  edge [
    source 959
    target 984
    kind "from_chunk"
  ]
  edge [
    source 960
    target 961
    kind "mentions"
  ]
  edge [
    source 960
    target 962
    kind "mentions"
  ]
  edge [
    source 960
    target 963
    kind "mentions"
  ]
  edge [
    source 960
    target 964
    kind "mentions"
  ]
  edge [
    source 960
    target 965
    kind "mentions"
  ]
  edge [
    source 960
    target 966
    kind "mentions"
  ]
  edge [
    source 960
    target 967
    kind "mentions"
  ]
  edge [
    source 960
    target 968
    kind "mentions"
  ]
  edge [
    source 960
    target 969
    kind "mentions"
  ]
  edge [
    source 960
    target 970
    kind "mentions"
  ]
  edge [
    source 960
    target 971
    kind "mentions"
  ]
  edge [
    source 960
    target 972
    kind "mentions"
  ]
  edge [
    source 960
    target 973
    kind "mentions"
  ]
  edge [
    source 960
    target 974
    kind "mentions"
  ]
  edge [
    source 960
    target 975
    kind "mentions"
  ]
  edge [
    source 960
    target 976
    kind "mentions"
  ]
  edge [
    source 960
    target 977
    kind "mentions"
  ]
  edge [
    source 960
    target 978
    kind "mentions"
  ]
  edge [
    source 960
    target 979
    kind "mentions"
  ]
  edge [
    source 960
    target 980
    kind "mentions"
  ]
  edge [
    source 960
    target 981
    kind "mentions"
  ]
  edge [
    source 960
    target 982
    kind "mentions"
  ]
  edge [
    source 960
    target 983
    kind "mentions"
  ]
  edge [
    source 960
    target 1935
    kind "summarizes"
  ]
  edge [
    source 963
    target 1246
    kind "mentions"
  ]
  edge [
    source 964
    target 976
    kind "relation"
    relation "will be left to"
    weight 1
  ]
  edge [
    source 964
    target 977
    kind "relation"
    relation "pleased"
    weight 1
  ]
  edge [
    source 967
    target 968
    kind "relation"
    relation "paid"
    weight 1
  ]
  edge [
    source 967
    target 979
    kind "relation"
    relation "was delivered to"
    weight 1
  ]
  edge [
    source 967
    target 980
    kind "relation"
    relation "acknowledged"
    weight 1
  ]
  edge [
    source 968
    target 1840
    kind "mentions"
  ]
  edge [
    source 968
    target 1444
    kind "relation"
    relation "intends to subscribe"
    weight 1
  ]
  edge [
    source 971
    target 984
    kind "mentions"
  ]
  edge [
    source 972
    target 984
    kind "mentions"
  ]
  edge [
    source 973
    target 984
    kind "mentions"
  ]
  edge [
    source 974
    target 984
    kind "mentions"
  ]
  edge [
    source 974
    target 985
    kind "relation"
    relation "caused"
    weight 1
  ]
  edge [
    source 975
    target 984
    kind "mentions"
  ]
  edge [
    source 975
    target 1314
    kind "mentions"
  ]
  edge [
    source 977
    target 1349
    kind "mentions"
  ]
  edge [
    source 982
    target 984
    kind "mentions"
  ]
  edge [
    source 983
    target 984
    kind "mentions"
  ]
  edge [
    source 984
    target 985
    kind "mentions"
  ]
  edge [
    source 984
    target 1935
    kind "summarizes"
  ]
  edge [
    source 986
    target 987
    kind "from_chunk"
  ]
  edge [
    source 986
    target 1005
    kind "from_chunk"
  ]
  edge [
    source 987
    target 988
    kind "mentions"
  ]
  edge [
    source 987
    target 989
    kind "mentions"
  ]
  edge [
    source 987
    target 990
    kind "mentions"
  ]
  edge [
    source 987
    target 991
    kind "mentions"
  ]
  edge [
    source 987
    target 992
    kind "mentions"
  ]
  edge [
    source 987
    target 993
    kind "mentions"
  ]
  edge [
    source 987
    target 994
    kind "mentions"
  ]
  edge [
    source 987
    target 995
    kind "mentions"
  ]
  edge [
    source 987
    target 996
    kind "mentions"
  ]
  edge [
    source 987
    target 997
    kind "mentions"
  ]
  edge [
    source 987
    target 998
    kind "mentions"
  ]
  edge [
    source 987
    target 999
    kind "mentions"
  ]
  edge [
    source 987
    target 1000
    kind "mentions"
  ]
  edge [
    source 987
    target 1001
    kind "mentions"
  ]
  edge [
    source 987
    target 1002
    kind "mentions"
  ]
  edge [
    source 987
    target 1003
    kind "mentions"
  ]
  edge [
    source 987
    target 1004
    kind "mentions"
  ]
  edge [
    source 987
    target 1937
    kind "summarizes"
  ]
  edge [
    source 988
    target 1273
    kind "mentions"
  ]
  edge [
    source 988
    target 1574
    kind "mentions"
  ]
  edge [
    source 991
    target 992
    kind "relation"
    relation "is a friend of"
    weight 1
  ]
  edge [
    source 991
    target 993
    kind "relation"
    relation "showed the narrator"
    weight 1
  ]
  edge [
    source 991
    target 995
    kind "relation"
    relation "showed the narrator"
    weight 1
  ]
  edge [
    source 995
    target 997
    kind "relation"
    relation "have large gooseberries as big as"
    weight 1
  ]
  edge [
    source 999
    target 1585
    kind "mentions"
  ]
  edge [
    source 999
    target 1698
    kind "mentions"
  ]
  edge [
    source 999
    target 1765
    kind "mentions"
  ]
  edge [
    source 999
    target 1775
    kind "mentions"
  ]
  edge [
    source 1000
    target 1005
    kind "mentions"
  ]
  edge [
    source 1001
    target 1005
    kind "mentions"
  ]
  edge [
    source 1004
    target 1585
    kind "mentions"
  ]
  edge [
    source 1004
    target 1891
    kind "mentions"
  ]
  edge [
    source 1005
    target 1937
    kind "summarizes"
  ]
  edge [
    source 1006
    target 1007
    kind "from_chunk"
  ]
  edge [
    source 1006
    target 1013
    kind "from_chunk"
  ]
  edge [
    source 1006
    target 1016
    kind "from_chunk"
  ]
  edge [
    source 1007
    target 1008
    kind "mentions"
  ]
  edge [
    source 1007
    target 1009
    kind "mentions"
  ]
  edge [
    source 1007
    target 1010
    kind "mentions"
  ]
  edge [
    source 1007
    target 1011
    kind "mentions"
  ]
  edge [
    source 1007
    target 1012
    kind "mentions"
  ]
  edge [
    source 1007
    target 1934
    kind "summarizes"
  ]
  edge [
    source 1008
    target 1916
    kind "mentions"
  ]
  edge [
    source 1008
    target 1903
    kind "relation"
    relation "sat before"
    weight 1
  ]
  edge [
    source 1009
    target 1916
    kind "mentions"
  ]
  edge [
    source 1010
    target 1337
    kind "mentions"
  ]
  edge [
    source 1010
    target 1396
    kind "mentions"
  ]
  edge [
    source 1010
    target 1403
    kind "relation"
    relation "arrives with"
    weight 1
  ]
  edge [
    source 1010
    target 1408
    kind "relation"
    relation "promised to withdraw"
    weight 1
  ]
  edge [
    source 1010
    target 1409
    kind "relation"
    relation "seems to be content with"
    weight 1
  ]
  edge [
    source 1010
    target 1698
    kind "mentions"
  ]
  edge [
    source 1010
    target 1710
    kind "relation"
    relation "and his son thomas"
    weight 1
  ]
  edge [
    source 1011
    target 1016
    kind "mentions"
  ]
  edge [
    source 1011
    target 1055
    kind "mentions"
  ]
  edge [
    source 1011
    target 1223
    kind "mentions"
  ]
  edge [
    source 1011
    target 1600
    kind "mentions"
  ]
  edge [
    source 1011
    target 1611
    kind "relation"
    relation "examined"
    weight 1
  ]
  edge [
    source 1013
    target 1014
    kind "mentions"
  ]
  edge [
    source 1013
    target 1015
    kind "mentions"
  ]
  edge [
    source 1013
    target 1936
    kind "summarizes"
  ]
  edge [
    source 1016
    target 1017
    kind "mentions"
  ]
  edge [
    source 1016
    target 1018
    kind "mentions"
  ]
  edge [
    source 1016
    target 1019
    kind "mentions"
  ]
  edge [
    source 1016
    target 1020
    kind "mentions"
  ]
  edge [
    source 1016
    target 1021
    kind "mentions"
  ]
  edge [
    source 1016
    target 1022
    kind "mentions"
  ]
  edge [
    source 1016
    target 1023
    kind "mentions"
  ]
  edge [
    source 1016
    target 1024
    kind "mentions"
  ]
  edge [
    source 1016
    target 1935
    kind "summarizes"
  ]
  edge [
    source 1020
    target 1023
    kind "relation"
    relation "can give no light into"
    weight 1
  ]
  edge [
    source 1020
    target 1024
    kind "relation"
    relation "believes"
    weight 1
  ]
  edge [
    source 1025
    target 1026
    kind "from_chunk"
  ]
  edge [
    source 1025
    target 1043
    kind "from_chunk"
  ]
  edge [
    source 1026
    target 1027
    kind "mentions"
  ]
  edge [
    source 1026
    target 1028
    kind "mentions"
  ]
  edge [
    source 1026
    target 1029
    kind "mentions"
  ]
  edge [
    source 1026
    target 1030
    kind "mentions"
  ]
  edge [
    source 1026
    target 1031
    kind "mentions"
  ]
  edge [
    source 1026
    target 1032
    kind "mentions"
  ]
  edge [
    source 1026
    target 1033
    kind "mentions"
  ]
  edge [
    source 1026
    target 1034
    kind "mentions"
  ]
  edge [
    source 1026
    target 1035
    kind "mentions"
  ]
  edge [
    source 1026
    target 1036
    kind "mentions"
  ]
  edge [
    source 1026
    target 1037
    kind "mentions"
  ]
  edge [
    source 1026
    target 1038
    kind "mentions"
  ]
  edge [
    source 1026
    target 1039
    kind "mentions"
  ]
  edge [
    source 1026
    target 1040
    kind "mentions"
  ]
  edge [
    source 1026
    target 1041
    kind "mentions"
  ]
  edge [
    source 1026
    target 1042
    kind "mentions"
  ]
  edge [
    source 1026
    target 1944
    kind "summarizes"
  ]
  edge [
    source 1032
    target 1816
    kind "mentions"
  ]
  edge [
    source 1034
    target 1035
    kind "relation"
    relation "were kept since leaving london"
    weight 1
  ]
  edge [
    source 1037
    target 1038
    kind "relation"
    relation "lost"
    weight 1
  ]
  edge [
    source 1038
    target 1039
    kind "relation"
    relation "was with"
    weight 1
  ]
  edge [
    source 1039
    target 1752
    kind "mentions"
  ]
  edge [
    source 1039
    target 1765
    kind "mentions"
  ]
  edge [
    source 1039
    target 1758
    kind "relation"
    relation "stole"
    weight 1
  ]
  edge [
    source 1040
    target 1574
    kind "mentions"
  ]
  edge [
    source 1040
    target 1568
    kind "relation"
    relation "offers"
    weight 1
  ]
  edge [
    source 1040
    target 1752
    kind "mentions"
  ]
  edge [
    source 1042
    target 1043
    kind "mentions"
  ]
  edge [
    source 1043
    target 1944
    kind "summarizes"
  ]
  edge [
    source 1044
    target 1045
    kind "from_chunk"
  ]
  edge [
    source 1044
    target 1053
    kind "from_chunk"
  ]
  edge [
    source 1045
    target 1046
    kind "mentions"
  ]
  edge [
    source 1045
    target 1047
    kind "mentions"
  ]
  edge [
    source 1045
    target 1048
    kind "mentions"
  ]
  edge [
    source 1045
    target 1049
    kind "mentions"
  ]
  edge [
    source 1045
    target 1050
    kind "mentions"
  ]
  edge [
    source 1045
    target 1051
    kind "mentions"
  ]
  edge [
    source 1045
    target 1052
    kind "mentions"
  ]
  edge [
    source 1045
    target 1945
    kind "summarizes"
  ]
  edge [
    source 1046
    target 1765
    kind "mentions"
  ]
  edge [
    source 1046
    target 1775
    kind "mentions"
  ]
  edge [
    source 1053
    target 1945
    kind "summarizes"
  ]
  edge [
    source 1054
    target 1055
    kind "from_chunk"
  ]
  edge [
    source 1054
    target 1069
    kind "from_chunk"
  ]
  edge [
    source 1055
    target 1056
    kind "mentions"
  ]
  edge [
    source 1055
    target 1057
    kind "mentions"
  ]
  edge [
    source 1055
    target 1058
    kind "mentions"
  ]
  edge [
    source 1055
    target 1059
    kind "mentions"
  ]
  edge [
    source 1055
    target 1060
    kind "mentions"
  ]
  edge [
    source 1055
    target 1061
    kind "mentions"
  ]
  edge [
    source 1055
    target 1062
    kind "mentions"
  ]
  edge [
    source 1055
    target 1063
    kind "mentions"
  ]
  edge [
    source 1055
    target 1064
    kind "mentions"
  ]
  edge [
    source 1055
    target 1065
    kind "mentions"
  ]
  edge [
    source 1055
    target 1066
    kind "mentions"
  ]
  edge [
    source 1055
    target 1067
    kind "mentions"
  ]
  edge [
    source 1055
    target 1068
    kind "mentions"
  ]
  edge [
    source 1055
    target 1949
    kind "summarizes"
  ]
  edge [
    source 1056
    target 1065
    kind "relation"
    relation "claimed that"
    weight 1
  ]
  edge [
    source 1056
    target 1066
    kind "relation"
    relation "said that"
    weight 1
  ]
  edge [
    source 1060
    target 1071
    kind "mentions"
  ]
  edge [
    source 1060
    target 1088
    kind "relation"
    relation "was expected to be adjourned for"
    weight 1
  ]
  edge [
    source 1060
    target 1089
    kind "relation"
    relation "was delayed by"
    weight 1
  ]
  edge [
    source 1060
    target 1146
    kind "mentions"
  ]
  edge [
    source 1060
    target 1223
    kind "mentions"
  ]
  edge [
    source 1060
    target 1235
    kind "mentions"
  ]
  edge [
    source 1062
    target 1925
    kind "mentions"
  ]
  edge [
    source 1063
    target 1223
    kind "mentions"
  ]
  edge [
    source 1063
    target 1816
    kind "mentions"
  ]
  edge [
    source 1064
    target 1716
    kind "mentions"
  ]
  edge [
    source 1069
    target 1933
    kind "summarizes"
  ]
  edge [
    source 1070
    target 1071
    kind "from_chunk"
  ]
  edge [
    source 1070
    target 1094
    kind "from_chunk"
  ]
  edge [
    source 1071
    target 1072
    kind "mentions"
  ]
  edge [
    source 1071
    target 1073
    kind "mentions"
  ]
  edge [
    source 1071
    target 1074
    kind "mentions"
  ]
  edge [
    source 1071
    target 1075
    kind "mentions"
  ]
  edge [
    source 1071
    target 1076
    kind "mentions"
  ]
  edge [
    source 1071
    target 1077
    kind "mentions"
  ]
  edge [
    source 1071
    target 1078
    kind "mentions"
  ]
  edge [
    source 1071
    target 1079
    kind "mentions"
  ]
  edge [
    source 1071
    target 1080
    kind "mentions"
  ]
  edge [
    source 1071
    target 1081
    kind "mentions"
  ]
  edge [
    source 1071
    target 1082
    kind "mentions"
  ]
  edge [
    source 1071
    target 1083
    kind "mentions"
  ]
  edge [
    source 1071
    target 1084
    kind "mentions"
  ]
  edge [
    source 1071
    target 1085
    kind "mentions"
  ]
  edge [
    source 1071
    target 1086
    kind "mentions"
  ]
  edge [
    source 1071
    target 1087
    kind "mentions"
  ]
  edge [
    source 1071
    target 1088
    kind "mentions"
  ]
  edge [
    source 1071
    target 1089
    kind "mentions"
  ]
  edge [
    source 1071
    target 1090
    kind "mentions"
  ]
  edge [
    source 1071
    target 1091
    kind "mentions"
  ]
  edge [
    source 1071
    target 1092
    kind "mentions"
  ]
  edge [
    source 1071
    target 1093
    kind "mentions"
  ]
  edge [
    source 1071
    target 1954
    kind "summarizes"
  ]
  edge [
    source 1073
    target 1074
    kind "relation"
    relation "is a friend of"
    weight 1
  ]
  edge [
    source 1073
    target 1087
    kind "relation"
    relation "played the guitar"
    weight 1
  ]
  edge [
    source 1073
    target 1075
    kind "relation"
    relation "played extremely well | was considered a bawble"
    weight 2
  ]
  edge [
    source 1077
    target 1078
    kind "relation"
    relation "advised about a ship to carry"
    weight 1
  ]
  edge [
    source 1077
    target 1090
    kind "relation"
    relation "learned that they have decided to go in"
    weight 1
  ]
  edge [
    source 1077
    target 1091
    kind "relation"
    relation "told the speaker that my lord chancellor is much envied"
    weight 1
  ]
  edge [
    source 1078
    target 1369
    kind "mentions"
  ]
  edge [
    source 1078
    target 1228
    kind "relation"
    relation "was given to"
    weight 1
  ]
  edge [
    source 1078
    target 1370
    kind "relation"
    relation "was in great fear of"
    weight 1
  ]
  edge [
    source 1078
    target 1493
    kind "mentions"
  ]
  edge [
    source 1078
    target 1716
    kind "mentions"
  ]
  edge [
    source 1078
    target 1081
    kind "relation"
    relation "left by coach toward"
    weight 1
  ]
  edge [
    source 1081
    target 1716
    kind "mentions"
  ]
  edge [
    source 1083
    target 1084
    kind "relation"
    relation "endeavours to undermine"
    weight 1
  ]
  edge [
    source 1083
    target 1085
    kind "relation"
    relation "endeavours to undermine"
    weight 1
  ]
  edge [
    source 1083
    target 1091
    kind "relation"
    relation "is envied by"
    weight 1
  ]
  edge [
    source 1086
    target 1094
    kind "mentions"
  ]
  edge [
    source 1086
    target 1322
    kind "mentions"
  ]
  edge [
    source 1094
    target 1095
    kind "mentions"
  ]
  edge [
    source 1094
    target 1096
    kind "mentions"
  ]
  edge [
    source 1094
    target 1953
    kind "summarizes"
  ]
  edge [
    source 1097
    target 1098
    kind "from_chunk"
  ]
  edge [
    source 1097
    target 1116
    kind "from_chunk"
  ]
  edge [
    source 1098
    target 1099
    kind "mentions"
  ]
  edge [
    source 1098
    target 1100
    kind "mentions"
  ]
  edge [
    source 1098
    target 1101
    kind "mentions"
  ]
  edge [
    source 1098
    target 1102
    kind "mentions"
  ]
  edge [
    source 1098
    target 1103
    kind "mentions"
  ]
  edge [
    source 1098
    target 1104
    kind "mentions"
  ]
  edge [
    source 1098
    target 1105
    kind "mentions"
  ]
  edge [
    source 1098
    target 1106
    kind "mentions"
  ]
  edge [
    source 1098
    target 1107
    kind "mentions"
  ]
  edge [
    source 1098
    target 1108
    kind "mentions"
  ]
  edge [
    source 1098
    target 1109
    kind "mentions"
  ]
  edge [
    source 1098
    target 1110
    kind "mentions"
  ]
  edge [
    source 1098
    target 1111
    kind "mentions"
  ]
  edge [
    source 1098
    target 1112
    kind "mentions"
  ]
  edge [
    source 1098
    target 1113
    kind "mentions"
  ]
  edge [
    source 1098
    target 1114
    kind "mentions"
  ]
  edge [
    source 1098
    target 1115
    kind "mentions"
  ]
  edge [
    source 1098
    target 1948
    kind "summarizes"
  ]
  edge [
    source 1099
    target 1116
    kind "mentions"
  ]
  edge [
    source 1101
    target 1698
    kind "mentions"
  ]
  edge [
    source 1101
    target 1714
    kind "mentions"
  ]
  edge [
    source 1101
    target 1716
    kind "mentions"
  ]
  edge [
    source 1104
    target 1107
    kind "relation"
    relation "gave"
    weight 1
  ]
  edge [
    source 1104
    target 1108
    kind "relation"
    relation "has the best manner of singing"
    weight 1
  ]
  edge [
    source 1105
    target 1114
    kind "relation"
    relation "came to see | dined with | was welcomed by"
    weight 6
  ]
  edge [
    source 1105
    target 1116
    kind "mentions"
  ]
  edge [
    source 1112
    target 1113
    kind "relation"
    relation "is alone and has not been heard from since"
    weight 1
  ]
  edge [
    source 1114
    target 1115
    kind "relation"
    relation "sent"
    weight 2
  ]
  edge [
    source 1114
    target 1116
    kind "mentions"
  ]
  edge [
    source 1115
    target 1116
    kind "mentions"
  ]
  edge [
    source 1116
    target 1948
    kind "summarizes"
  ]
  edge [
    source 1117
    target 1118
    kind "from_chunk"
  ]
  edge [
    source 1117
    target 1126
    kind "from_chunk"
  ]
  edge [
    source 1118
    target 1119
    kind "mentions"
  ]
  edge [
    source 1118
    target 1120
    kind "mentions"
  ]
  edge [
    source 1118
    target 1121
    kind "mentions"
  ]
  edge [
    source 1118
    target 1122
    kind "mentions"
  ]
  edge [
    source 1118
    target 1123
    kind "mentions"
  ]
  edge [
    source 1118
    target 1124
    kind "mentions"
  ]
  edge [
    source 1118
    target 1125
    kind "mentions"
  ]
  edge [
    source 1118
    target 1946
    kind "summarizes"
  ]
  edge [
    source 1119
    target 1120
    kind "relation"
    relation "recently arrived from"
    weight 1
  ]
  edge [
    source 1120
    target 1359
    kind "mentions"
  ]
  edge [
    source 1120
    target 1362
    kind "relation"
    relation "returned from"
    weight 1
  ]
  edge [
    source 1123
    target 1126
    kind "mentions"
  ]
  edge [
    source 1123
    target 1542
    kind "mentions"
  ]
  edge [
    source 1123
    target 1840
    kind "mentions"
  ]
  edge [
    source 1123
    target 1867
    kind "mentions"
  ]
  edge [
    source 1124
    target 1126
    kind "mentions"
  ]
  edge [
    source 1124
    target 1765
    kind "mentions"
  ]
  edge [
    source 1124
    target 1775
    kind "mentions"
  ]
  edge [
    source 1124
    target 1816
    kind "mentions"
  ]
  edge [
    source 1124
    target 1838
    kind "mentions"
  ]
  edge [
    source 1126
    target 1127
    kind "mentions"
  ]
  edge [
    source 1126
    target 1128
    kind "mentions"
  ]
  edge [
    source 1126
    target 1129
    kind "mentions"
  ]
  edge [
    source 1126
    target 1946
    kind "summarizes"
  ]
  edge [
    source 1128
    target 1840
    kind "mentions"
  ]
  edge [
    source 1128
    target 1867
    kind "mentions"
  ]
  edge [
    source 1130
    target 1131
    kind "from_chunk"
  ]
  edge [
    source 1130
    target 1139
    kind "from_chunk"
  ]
  edge [
    source 1130
    target 1146
    kind "from_chunk"
  ]
  edge [
    source 1130
    target 1158
    kind "from_chunk"
  ]
  edge [
    source 1131
    target 1132
    kind "mentions"
  ]
  edge [
    source 1131
    target 1133
    kind "mentions"
  ]
  edge [
    source 1131
    target 1134
    kind "mentions"
  ]
  edge [
    source 1131
    target 1135
    kind "mentions"
  ]
  edge [
    source 1131
    target 1136
    kind "mentions"
  ]
  edge [
    source 1131
    target 1137
    kind "mentions"
  ]
  edge [
    source 1131
    target 1138
    kind "mentions"
  ]
  edge [
    source 1131
    target 1937
    kind "summarizes"
  ]
  edge [
    source 1132
    target 1919
    kind "mentions"
  ]
  edge [
    source 1132
    target 1903
    kind "relation"
    relation "felt sorry in some respect and glad in another respect"
    weight 1
  ]
  edge [
    source 1139
    target 1140
    kind "mentions"
  ]
  edge [
    source 1139
    target 1141
    kind "mentions"
  ]
  edge [
    source 1139
    target 1142
    kind "mentions"
  ]
  edge [
    source 1139
    target 1143
    kind "mentions"
  ]
  edge [
    source 1139
    target 1144
    kind "mentions"
  ]
  edge [
    source 1139
    target 1145
    kind "mentions"
  ]
  edge [
    source 1139
    target 1936
    kind "summarizes"
  ]
  edge [
    source 1140
    target 1448
    kind "mentions"
  ]
  edge [
    source 1142
    target 1145
    kind "relation"
    relation "has gone to visit"
    weight 1
  ]
  edge [
    source 1146
    target 1147
    kind "mentions"
  ]
  edge [
    source 1146
    target 1148
    kind "mentions"
  ]
  edge [
    source 1146
    target 1149
    kind "mentions"
  ]
  edge [
    source 1146
    target 1150
    kind "mentions"
  ]
  edge [
    source 1146
    target 1151
    kind "mentions"
  ]
  edge [
    source 1146
    target 1152
    kind "mentions"
  ]
  edge [
    source 1146
    target 1153
    kind "mentions"
  ]
  edge [
    source 1146
    target 1154
    kind "mentions"
  ]
  edge [
    source 1146
    target 1155
    kind "mentions"
  ]
  edge [
    source 1146
    target 1156
    kind "mentions"
  ]
  edge [
    source 1146
    target 1157
    kind "mentions"
  ]
  edge [
    source 1146
    target 1938
    kind "summarizes"
  ]
  edge [
    source 1147
    target 1176
    kind "mentions"
  ]
  edge [
    source 1148
    target 1157
    kind "relation"
    relation "has a bill for"
    weight 1
  ]
  edge [
    source 1158
    target 1159
    kind "mentions"
  ]
  edge [
    source 1158
    target 1947
    kind "summarizes"
  ]
  edge [
    source 1160
    target 1161
    kind "from_chunk"
  ]
  edge [
    source 1160
    target 1176
    kind "from_chunk"
  ]
  edge [
    source 1161
    target 1162
    kind "mentions"
  ]
  edge [
    source 1161
    target 1163
    kind "mentions"
  ]
  edge [
    source 1161
    target 1164
    kind "mentions"
  ]
  edge [
    source 1161
    target 1165
    kind "mentions"
  ]
  edge [
    source 1161
    target 1166
    kind "mentions"
  ]
  edge [
    source 1161
    target 1167
    kind "mentions"
  ]
  edge [
    source 1161
    target 1168
    kind "mentions"
  ]
  edge [
    source 1161
    target 1169
    kind "mentions"
  ]
  edge [
    source 1161
    target 1170
    kind "mentions"
  ]
  edge [
    source 1161
    target 1171
    kind "mentions"
  ]
  edge [
    source 1161
    target 1172
    kind "mentions"
  ]
  edge [
    source 1161
    target 1173
    kind "mentions"
  ]
  edge [
    source 1161
    target 1174
    kind "mentions"
  ]
  edge [
    source 1161
    target 1175
    kind "mentions"
  ]
  edge [
    source 1161
    target 1941
    kind "summarizes"
  ]
  edge [
    source 1162
    target 1170
    kind "relation"
    relation "is described as"
    weight 1
  ]
  edge [
    source 1165
    target 1171
    kind "relation"
    relation "are held at"
    weight 1
  ]
  edge [
    source 1165
    target 1204
    kind "mentions"
  ]
  edge [
    source 1166
    target 1172
    kind "relation"
    relation "has become"
    weight 1
  ]
  edge [
    source 1166
    target 1173
    kind "relation"
    relation "earns"
    weight 1
  ]
  edge [
    source 1166
    target 1168
    kind "relation"
    relation "is a friend of"
    weight 1
  ]
  edge [
    source 1168
    target 1174
    kind "relation"
    relation "is described as"
    weight 1
  ]
  edge [
    source 1169
    target 1176
    kind "mentions"
  ]
  edge [
    source 1176
    target 1177
    kind "mentions"
  ]
  edge [
    source 1176
    target 1178
    kind "mentions"
  ]
  edge [
    source 1176
    target 1179
    kind "mentions"
  ]
  edge [
    source 1176
    target 1941
    kind "summarizes"
  ]
  edge [
    source 1179
    target 1181
    kind "mentions"
  ]
  edge [
    source 1180
    target 1181
    kind "from_chunk"
  ]
  edge [
    source 1180
    target 1196
    kind "from_chunk"
  ]
  edge [
    source 1181
    target 1182
    kind "mentions"
  ]
  edge [
    source 1181
    target 1183
    kind "mentions"
  ]
  edge [
    source 1181
    target 1184
    kind "mentions"
  ]
  edge [
    source 1181
    target 1185
    kind "mentions"
  ]
  edge [
    source 1181
    target 1186
    kind "mentions"
  ]
  edge [
    source 1181
    target 1187
    kind "mentions"
  ]
  edge [
    source 1181
    target 1188
    kind "mentions"
  ]
  edge [
    source 1181
    target 1189
    kind "mentions"
  ]
  edge [
    source 1181
    target 1190
    kind "mentions"
  ]
  edge [
    source 1181
    target 1191
    kind "mentions"
  ]
  edge [
    source 1181
    target 1192
    kind "mentions"
  ]
  edge [
    source 1181
    target 1193
    kind "mentions"
  ]
  edge [
    source 1181
    target 1194
    kind "mentions"
  ]
  edge [
    source 1181
    target 1195
    kind "mentions"
  ]
  edge [
    source 1181
    target 1941
    kind "summarizes"
  ]
  edge [
    source 1184
    target 1185
    kind "relation"
    relation "were given to"
    weight 1
  ]
  edge [
    source 1185
    target 1186
    kind "relation"
    relation "excluded"
    weight 1
  ]
  edge [
    source 1188
    target 1196
    kind "mentions"
  ]
  edge [
    source 1189
    target 1193
    kind "relation"
    relation "is a dealer in hides"
    weight 1
  ]
  edge [
    source 1189
    target 1194
    kind "relation"
    relation "claimed to have been a wicked man"
    weight 1
  ]
  edge [
    source 1189
    target 1195
    kind "relation"
    relation "changed his behavior"
    weight 1
  ]
  edge [
    source 1189
    target 1196
    kind "mentions"
  ]
  edge [
    source 1189
    target 1190
    kind "relation"
    relation "is a quaker"
    weight 1
  ]
  edge [
    source 1190
    target 1196
    kind "mentions"
  ]
  edge [
    source 1196
    target 1197
    kind "mentions"
  ]
  edge [
    source 1196
    target 1198
    kind "mentions"
  ]
  edge [
    source 1196
    target 1941
    kind "summarizes"
  ]
  edge [
    source 1199
    target 1200
    kind "from_chunk"
  ]
  edge [
    source 1199
    target 1204
    kind "from_chunk"
  ]
  edge [
    source 1199
    target 1210
    kind "from_chunk"
  ]
  edge [
    source 1199
    target 1219
    kind "from_chunk"
  ]
  edge [
    source 1200
    target 1201
    kind "mentions"
  ]
  edge [
    source 1200
    target 1202
    kind "mentions"
  ]
  edge [
    source 1200
    target 1203
    kind "mentions"
  ]
  edge [
    source 1200
    target 1938
    kind "summarizes"
  ]
  edge [
    source 1204
    target 1205
    kind "mentions"
  ]
  edge [
    source 1204
    target 1206
    kind "mentions"
  ]
  edge [
    source 1204
    target 1207
    kind "mentions"
  ]
  edge [
    source 1204
    target 1208
    kind "mentions"
  ]
  edge [
    source 1204
    target 1209
    kind "mentions"
  ]
  edge [
    source 1204
    target 1951
    kind "summarizes"
  ]
  edge [
    source 1210
    target 1211
    kind "mentions"
  ]
  edge [
    source 1210
    target 1212
    kind "mentions"
  ]
  edge [
    source 1210
    target 1213
    kind "mentions"
  ]
  edge [
    source 1210
    target 1214
    kind "mentions"
  ]
  edge [
    source 1210
    target 1215
    kind "mentions"
  ]
  edge [
    source 1210
    target 1216
    kind "mentions"
  ]
  edge [
    source 1210
    target 1217
    kind "mentions"
  ]
  edge [
    source 1210
    target 1218
    kind "mentions"
  ]
  edge [
    source 1210
    target 1940
    kind "summarizes"
  ]
  edge [
    source 1214
    target 1215
    kind "relation"
    relation "are highly regarded in"
    weight 1
  ]
  edge [
    source 1214
    target 1218
    kind "relation"
    relation "are better scholars than"
    weight 1
  ]
  edge [
    source 1219
    target 1220
    kind "mentions"
  ]
  edge [
    source 1219
    target 1221
    kind "mentions"
  ]
  edge [
    source 1219
    target 1951
    kind "summarizes"
  ]
  edge [
    source 1222
    target 1223
    kind "from_chunk"
  ]
  edge [
    source 1222
    target 1235
    kind "from_chunk"
  ]
  edge [
    source 1223
    target 1224
    kind "mentions"
  ]
  edge [
    source 1223
    target 1225
    kind "mentions"
  ]
  edge [
    source 1223
    target 1226
    kind "mentions"
  ]
  edge [
    source 1223
    target 1227
    kind "mentions"
  ]
  edge [
    source 1223
    target 1228
    kind "mentions"
  ]
  edge [
    source 1223
    target 1229
    kind "mentions"
  ]
  edge [
    source 1223
    target 1230
    kind "mentions"
  ]
  edge [
    source 1223
    target 1231
    kind "mentions"
  ]
  edge [
    source 1223
    target 1232
    kind "mentions"
  ]
  edge [
    source 1223
    target 1233
    kind "mentions"
  ]
  edge [
    source 1223
    target 1234
    kind "mentions"
  ]
  edge [
    source 1223
    target 1951
    kind "summarizes"
  ]
  edge [
    source 1228
    target 1349
    kind "mentions"
  ]
  edge [
    source 1228
    target 1369
    kind "mentions"
  ]
  edge [
    source 1228
    target 1372
    kind "relation"
    relation "caused"
    weight 1
  ]
  edge [
    source 1231
    target 1232
    kind "relation"
    relation "opposed initiatives by"
    weight 1
  ]
  edge [
    source 1231
    target 1235
    kind "mentions"
  ]
  edge [
    source 1231
    target 1236
    kind "relation"
    relation "opposed"
    weight 1
  ]
  edge [
    source 1232
    target 1235
    kind "mentions"
  ]
  edge [
    source 1232
    target 1236
    kind "relation"
    relation "were proposed by"
    weight 1
  ]
  edge [
    source 1235
    target 1236
    kind "mentions"
  ]
  edge [
    source 1235
    target 1951
    kind "summarizes"
  ]
  edge [
    source 1237
    target 1238
    kind "from_chunk"
  ]
  edge [
    source 1237
    target 1241
    kind "from_chunk"
  ]
  edge [
    source 1237
    target 1246
    kind "from_chunk"
  ]
  edge [
    source 1237
    target 1255
    kind "from_chunk"
  ]
  edge [
    source 1238
    target 1239
    kind "mentions"
  ]
  edge [
    source 1238
    target 1240
    kind "mentions"
  ]
  edge [
    source 1238
    target 1935
    kind "summarizes"
  ]
  edge [
    source 1239
    target 1240
    kind "relation"
    relation "make him think they will cause"
    weight 1
  ]
  edge [
    source 1241
    target 1242
    kind "mentions"
  ]
  edge [
    source 1241
    target 1243
    kind "mentions"
  ]
  edge [
    source 1241
    target 1244
    kind "mentions"
  ]
  edge [
    source 1241
    target 1245
    kind "mentions"
  ]
  edge [
    source 1241
    target 1938
    kind "summarizes"
  ]
  edge [
    source 1246
    target 1247
    kind "mentions"
  ]
  edge [
    source 1246
    target 1248
    kind "mentions"
  ]
  edge [
    source 1246
    target 1249
    kind "mentions"
  ]
  edge [
    source 1246
    target 1250
    kind "mentions"
  ]
  edge [
    source 1246
    target 1251
    kind "mentions"
  ]
  edge [
    source 1246
    target 1252
    kind "mentions"
  ]
  edge [
    source 1246
    target 1253
    kind "mentions"
  ]
  edge [
    source 1246
    target 1254
    kind "mentions"
  ]
  edge [
    source 1246
    target 1935
    kind "summarizes"
  ]
  edge [
    source 1247
    target 1248
    kind "relation"
    relation "has a pretty house at"
    weight 1
  ]
  edge [
    source 1248
    target 1254
    kind "relation"
    relation "gives the speaker light on"
    weight 1
  ]
  edge [
    source 1250
    target 1255
    kind "mentions"
  ]
  edge [
    source 1250
    target 1448
    kind "mentions"
  ]
  edge [
    source 1250
    target 1462
    kind "mentions"
  ]
  edge [
    source 1250
    target 1449
    kind "relation"
    relation "stayed at"
    weight 1
  ]
  edge [
    source 1250
    target 1525
    kind "mentions"
  ]
  edge [
    source 1250
    target 1536
    kind "relation"
    relation "sat at"
    weight 1
  ]
  edge [
    source 1250
    target 1585
    kind "mentions"
  ]
  edge [
    source 1250
    target 1595
    kind "relation"
    relation "went out to"
    weight 1
  ]
  edge [
    source 1250
    target 1600
    kind "mentions"
  ]
  edge [
    source 1250
    target 1615
    kind "mentions"
  ]
  edge [
    source 1250
    target 1698
    kind "mentions"
  ]
  edge [
    source 1250
    target 1765
    kind "mentions"
  ]
  edge [
    source 1250
    target 1767
    kind "relation"
    relation "arrived at"
    weight 1
  ]
  edge [
    source 1250
    target 1775
    kind "mentions"
  ]
  edge [
    source 1250
    target 1782
    kind "mentions"
  ]
  edge [
    source 1250
    target 1792
    kind "relation"
    relation "motivated"
    weight 2
  ]
  edge [
    source 1250
    target 1790
    kind "relation"
    relation "had whores"
    weight 1
  ]
  edge [
    source 1250
    target 1799
    kind "mentions"
  ]
  edge [
    source 1250
    target 1791
    kind "relation"
    relation "had"
    weight 1
  ]
  edge [
    source 1251
    target 1255
    kind "mentions"
  ]
  edge [
    source 1255
    target 1256
    kind "mentions"
  ]
  edge [
    source 1255
    target 1257
    kind "mentions"
  ]
  edge [
    source 1255
    target 1258
    kind "mentions"
  ]
  edge [
    source 1255
    target 1259
    kind "mentions"
  ]
  edge [
    source 1255
    target 1260
    kind "mentions"
  ]
  edge [
    source 1255
    target 1935
    kind "summarizes"
  ]
  edge [
    source 1257
    target 1259
    kind "relation"
    relation "is a tenant for"
    weight 1
  ]
  edge [
    source 1260
    target 1840
    kind "mentions"
  ]
  edge [
    source 1261
    target 1262
    kind "from_chunk"
  ]
  edge [
    source 1261
    target 1271
    kind "from_chunk"
  ]
  edge [
    source 1262
    target 1263
    kind "mentions"
  ]
  edge [
    source 1262
    target 1264
    kind "mentions"
  ]
  edge [
    source 1262
    target 1265
    kind "mentions"
  ]
  edge [
    source 1262
    target 1266
    kind "mentions"
  ]
  edge [
    source 1262
    target 1267
    kind "mentions"
  ]
  edge [
    source 1262
    target 1268
    kind "mentions"
  ]
  edge [
    source 1262
    target 1269
    kind "mentions"
  ]
  edge [
    source 1262
    target 1270
    kind "mentions"
  ]
  edge [
    source 1262
    target 1938
    kind "summarizes"
  ]
  edge [
    source 1267
    target 1270
    kind "relation"
    relation "continue to exist | are growing rather than lessening"
    weight 2
  ]
  edge [
    source 1267
    target 1914
    kind "mentions"
  ]
  edge [
    source 1267
    target 1915
    kind "relation"
    relation "continue to"
    weight 1
  ]
  edge [
    source 1271
    target 1940
    kind "summarizes"
  ]
  edge [
    source 1272
    target 1273
    kind "from_chunk"
  ]
  edge [
    source 1272
    target 1292
    kind "from_chunk"
  ]
  edge [
    source 1273
    target 1274
    kind "mentions"
  ]
  edge [
    source 1273
    target 1275
    kind "mentions"
  ]
  edge [
    source 1273
    target 1276
    kind "mentions"
  ]
  edge [
    source 1273
    target 1277
    kind "mentions"
  ]
  edge [
    source 1273
    target 1278
    kind "mentions"
  ]
  edge [
    source 1273
    target 1279
    kind "mentions"
  ]
  edge [
    source 1273
    target 1280
    kind "mentions"
  ]
  edge [
    source 1273
    target 1281
    kind "mentions"
  ]
  edge [
    source 1273
    target 1282
    kind "mentions"
  ]
  edge [
    source 1273
    target 1283
    kind "mentions"
  ]
  edge [
    source 1273
    target 1284
    kind "mentions"
  ]
  edge [
    source 1273
    target 1285
    kind "mentions"
  ]
  edge [
    source 1273
    target 1286
    kind "mentions"
  ]
  edge [
    source 1273
    target 1287
    kind "mentions"
  ]
  edge [
    source 1273
    target 1288
    kind "mentions"
  ]
  edge [
    source 1273
    target 1289
    kind "mentions"
  ]
  edge [
    source 1273
    target 1290
    kind "mentions"
  ]
  edge [
    source 1273
    target 1291
    kind "mentions"
  ]
  edge [
    source 1273
    target 1945
    kind "summarizes"
  ]
  edge [
    source 1277
    target 1278
    kind "relation"
    relation "was carrying"
    weight 1
  ]
  edge [
    source 1281
    target 1907
    kind "mentions"
  ]
  edge [
    source 1281
    target 1903
    kind "relation"
    relation "would have stolen"
    weight 1
  ]
  edge [
    source 1283
    target 1292
    kind "mentions"
  ]
  edge [
    source 1283
    target 1314
    kind "mentions"
  ]
  edge [
    source 1283
    target 1320
    kind "relation"
    relation "had mr. moore read over"
    weight 1
  ]
  edge [
    source 1283
    target 1525
    kind "mentions"
  ]
  edge [
    source 1285
    target 1292
    kind "mentions"
  ]
  edge [
    source 1286
    target 1292
    kind "mentions"
  ]
  edge [
    source 1292
    target 1945
    kind "summarizes"
  ]
  edge [
    source 1293
    target 1294
    kind "from_chunk"
  ]
  edge [
    source 1293
    target 1298
    kind "from_chunk"
  ]
  edge [
    source 1293
    target 1304
    kind "from_chunk"
  ]
  edge [
    source 1294
    target 1295
    kind "mentions"
  ]
  edge [
    source 1294
    target 1296
    kind "mentions"
  ]
  edge [
    source 1294
    target 1297
    kind "mentions"
  ]
  edge [
    source 1294
    target 1942
    kind "summarizes"
  ]
  edge [
    source 1295
    target 1322
    kind "mentions"
  ]
  edge [
    source 1295
    target 1299
    kind "relation"
    relation "was waiting at"
    weight 1
  ]
  edge [
    source 1295
    target 1388
    kind "mentions"
  ]
  edge [
    source 1295
    target 1434
    kind "mentions"
  ]
  edge [
    source 1295
    target 1448
    kind "mentions"
  ]
  edge [
    source 1295
    target 1449
    kind "relation"
    relation "attended"
    weight 1
  ]
  edge [
    source 1295
    target 1501
    kind "mentions"
  ]
  edge [
    source 1295
    target 1585
    kind "mentions"
  ]
  edge [
    source 1298
    target 1299
    kind "mentions"
  ]
  edge [
    source 1298
    target 1300
    kind "mentions"
  ]
  edge [
    source 1298
    target 1301
    kind "mentions"
  ]
  edge [
    source 1298
    target 1302
    kind "mentions"
  ]
  edge [
    source 1298
    target 1303
    kind "mentions"
  ]
  edge [
    source 1298
    target 1953
    kind "summarizes"
  ]
  edge [
    source 1299
    target 1302
    kind "relation"
    relation "spoke against"
    weight 1
  ]
  edge [
    source 1299
    target 1303
    kind "relation"
    relation "spoke in praise of"
    weight 1
  ]
  edge [
    source 1299
    target 1322
    kind "mentions"
  ]
  edge [
    source 1299
    target 1323
    kind "relation"
    relation "had been waiting for"
    weight 1
  ]
  edge [
    source 1304
    target 1305
    kind "mentions"
  ]
  edge [
    source 1304
    target 1306
    kind "mentions"
  ]
  edge [
    source 1304
    target 1307
    kind "mentions"
  ]
  edge [
    source 1304
    target 1308
    kind "mentions"
  ]
  edge [
    source 1304
    target 1309
    kind "mentions"
  ]
  edge [
    source 1304
    target 1310
    kind "mentions"
  ]
  edge [
    source 1304
    target 1311
    kind "mentions"
  ]
  edge [
    source 1304
    target 1312
    kind "mentions"
  ]
  edge [
    source 1304
    target 1954
    kind "summarizes"
  ]
  edge [
    source 1305
    target 1311
    kind "relation"
    relation "informed the narrator about"
    weight 1
  ]
  edge [
    source 1306
    target 1307
    kind "relation"
    relation "died"
    weight 1
  ]
  edge [
    source 1306
    target 1309
    kind "relation"
    relation "desired that the narrator would be a friend to"
    weight 1
  ]
  edge [
    source 1306
    target 1310
    kind "relation"
    relation "desired that the narrator would be a friend to"
    weight 1
  ]
  edge [
    source 1313
    target 1314
    kind "from_chunk"
  ]
  edge [
    source 1314
    target 1315
    kind "mentions"
  ]
  edge [
    source 1314
    target 1316
    kind "mentions"
  ]
  edge [
    source 1314
    target 1317
    kind "mentions"
  ]
  edge [
    source 1314
    target 1318
    kind "mentions"
  ]
  edge [
    source 1314
    target 1319
    kind "mentions"
  ]
  edge [
    source 1314
    target 1320
    kind "mentions"
  ]
  edge [
    source 1314
    target 1945
    kind "summarizes"
  ]
  edge [
    source 1315
    target 1316
    kind "relation"
    relation "brought news that | came for"
    weight 2
  ]
  edge [
    source 1319
    target 1322
    kind "mentions"
  ]
  edge [
    source 1320
    target 1840
    kind "mentions"
  ]
  edge [
    source 1320
    target 1863
    kind "relation"
    relation "are offered for sale at"
    weight 1
  ]
  edge [
    source 1320
    target 1867
    kind "mentions"
  ]
  edge [
    source 1321
    target 1322
    kind "from_chunk"
  ]
  edge [
    source 1321
    target 1327
    kind "from_chunk"
  ]
  edge [
    source 1321
    target 1331
    kind "from_chunk"
  ]
  edge [
    source 1322
    target 1323
    kind "mentions"
  ]
  edge [
    source 1322
    target 1324
    kind "mentions"
  ]
  edge [
    source 1322
    target 1325
    kind "mentions"
  ]
  edge [
    source 1322
    target 1326
    kind "mentions"
  ]
  edge [
    source 1322
    target 1953
    kind "summarizes"
  ]
  edge [
    source 1323
    target 1324
    kind "relation"
    relation "is for"
    weight 1
  ]
  edge [
    source 1325
    target 1326
    kind "relation"
    relation "is very big with child"
    weight 1
  ]
  edge [
    source 1325
    target 1493
    kind "mentions"
  ]
  edge [
    source 1327
    target 1328
    kind "mentions"
  ]
  edge [
    source 1327
    target 1329
    kind "mentions"
  ]
  edge [
    source 1327
    target 1330
    kind "mentions"
  ]
  edge [
    source 1327
    target 1943
    kind "summarizes"
  ]
  edge [
    source 1331
    target 1332
    kind "mentions"
  ]
  edge [
    source 1331
    target 1333
    kind "mentions"
  ]
  edge [
    source 1331
    target 1334
    kind "mentions"
  ]
  edge [
    source 1331
    target 1335
    kind "mentions"
  ]
  edge [
    source 1331
    target 1933
    kind "summarizes"
  ]
  edge [
    source 1336
    target 1337
    kind "from_chunk"
  ]
  edge [
    source 1336
    target 1343
    kind "from_chunk"
  ]
  edge [
    source 1336
    target 1349
    kind "from_chunk"
  ]
  edge [
    source 1336
    target 1350
    kind "from_chunk"
  ]
  edge [
    source 1337
    target 1338
    kind "mentions"
  ]
  edge [
    source 1337
    target 1339
    kind "mentions"
  ]
  edge [
    source 1337
    target 1340
    kind "mentions"
  ]
  edge [
    source 1337
    target 1341
    kind "mentions"
  ]
  edge [
    source 1337
    target 1342
    kind "mentions"
  ]
  edge [
    source 1337
    target 1936
    kind "summarizes"
  ]
  edge [
    source 1338
    target 1339
    kind "relation"
    relation "came to"
    weight 1
  ]
  edge [
    source 1338
    target 1493
    kind "mentions"
  ]
  edge [
    source 1338
    target 1499
    kind "mentions"
  ]
  edge [
    source 1339
    target 1349
    kind "mentions"
  ]
  edge [
    source 1343
    target 1344
    kind "mentions"
  ]
  edge [
    source 1343
    target 1345
    kind "mentions"
  ]
  edge [
    source 1343
    target 1346
    kind "mentions"
  ]
  edge [
    source 1343
    target 1347
    kind "mentions"
  ]
  edge [
    source 1343
    target 1348
    kind "mentions"
  ]
  edge [
    source 1343
    target 1943
    kind "summarizes"
  ]
  edge [
    source 1347
    target 1348
    kind "relation"
    relation "was first seen by | pleased"
    weight 2
  ]
  edge [
    source 1349
    target 1943
    kind "summarizes"
  ]
  edge [
    source 1350
    target 1351
    kind "mentions"
  ]
  edge [
    source 1350
    target 1352
    kind "mentions"
  ]
  edge [
    source 1350
    target 1353
    kind "mentions"
  ]
  edge [
    source 1350
    target 1354
    kind "mentions"
  ]
  edge [
    source 1350
    target 1355
    kind "mentions"
  ]
  edge [
    source 1350
    target 1356
    kind "mentions"
  ]
  edge [
    source 1350
    target 1357
    kind "mentions"
  ]
  edge [
    source 1350
    target 1949
    kind "summarizes"
  ]
  edge [
    source 1353
    target 1354
    kind "relation"
    relation "was first printed in"
    weight 1
  ]
  edge [
    source 1353
    target 1355
    kind "relation"
    relation "was attributed to"
    weight 1
  ]
  edge [
    source 1353
    target 1356
    kind "relation"
    relation "has been falsely attributed to"
    weight 1
  ]
  edge [
    source 1353
    target 1357
    kind "relation"
    relation "has been falsely attributed to"
    weight 1
  ]
  edge [
    source 1356
    target 1633
    kind "mentions"
  ]
  edge [
    source 1356
    target 1645
    kind "mentions"
  ]
  edge [
    source 1356
    target 1647
    kind "relation"
    relation "was instructed by"
    weight 1
  ]
  edge [
    source 1356
    target 1646
    kind "relation"
    relation "was originally instructed by"
    weight 1
  ]
  edge [
    source 1358
    target 1359
    kind "from_chunk"
  ]
  edge [
    source 1358
    target 1364
    kind "from_chunk"
  ]
  edge [
    source 1358
    target 1369
    kind "from_chunk"
  ]
  edge [
    source 1359
    target 1360
    kind "mentions"
  ]
  edge [
    source 1359
    target 1361
    kind "mentions"
  ]
  edge [
    source 1359
    target 1362
    kind "mentions"
  ]
  edge [
    source 1359
    target 1363
    kind "mentions"
  ]
  edge [
    source 1359
    target 1946
    kind "summarizes"
  ]
  edge [
    source 1360
    target 1362
    kind "relation"
    relation "began courting"
    weight 1
  ]
  edge [
    source 1361
    target 1362
    kind "relation"
    relation "began courting"
    weight 1
  ]
  edge [
    source 1364
    target 1365
    kind "mentions"
  ]
  edge [
    source 1364
    target 1366
    kind "mentions"
  ]
  edge [
    source 1364
    target 1367
    kind "mentions"
  ]
  edge [
    source 1364
    target 1368
    kind "mentions"
  ]
  edge [
    source 1364
    target 1943
    kind "summarizes"
  ]
  edge [
    source 1365
    target 1448
    kind "mentions"
  ]
  edge [
    source 1365
    target 1449
    kind "relation"
    relation "met | walked with"
    weight 2
  ]
  edge [
    source 1365
    target 1464
    kind "mentions"
  ]
  edge [
    source 1365
    target 1465
    kind "relation"
    relation "walked into"
    weight 1
  ]
  edge [
    source 1365
    target 1466
    kind "relation"
    relation "complained about"
    weight 1
  ]
  edge [
    source 1365
    target 1467
    kind "relation"
    relation "complained about"
    weight 1
  ]
  edge [
    source 1369
    target 1370
    kind "mentions"
  ]
  edge [
    source 1369
    target 1371
    kind "mentions"
  ]
  edge [
    source 1369
    target 1372
    kind "mentions"
  ]
  edge [
    source 1369
    target 1954
    kind "summarizes"
  ]
  edge [
    source 1373
    target 1374
    kind "from_chunk"
  ]
  edge [
    source 1373
    target 1384
    kind "from_chunk"
  ]
  edge [
    source 1373
    target 1388
    kind "from_chunk"
  ]
  edge [
    source 1373
    target 1393
    kind "from_chunk"
  ]
  edge [
    source 1374
    target 1375
    kind "mentions"
  ]
  edge [
    source 1374
    target 1376
    kind "mentions"
  ]
  edge [
    source 1374
    target 1377
    kind "mentions"
  ]
  edge [
    source 1374
    target 1378
    kind "mentions"
  ]
  edge [
    source 1374
    target 1379
    kind "mentions"
  ]
  edge [
    source 1374
    target 1380
    kind "mentions"
  ]
  edge [
    source 1374
    target 1381
    kind "mentions"
  ]
  edge [
    source 1374
    target 1382
    kind "mentions"
  ]
  edge [
    source 1374
    target 1383
    kind "mentions"
  ]
  edge [
    source 1374
    target 1947
    kind "summarizes"
  ]
  edge [
    source 1376
    target 1377
    kind "relation"
    relation "is sick at | is now very well again of his fever | was twice let blood"
    weight 4
  ]
  edge [
    source 1376
    target 1383
    kind "relation"
    relation "if he should miscarry, would leave his family in"
    weight 1
  ]
  edge [
    source 1376
    target 1698
    kind "mentions"
  ]
  edge [
    source 1376
    target 1704
    kind "relation"
    relation "wrote a letter dated"
    weight 1
  ]
  edge [
    source 1376
    target 1712
    kind "mentions"
  ]
  edge [
    source 1376
    target 1423
    kind "relation"
    relation "was ill with"
    weight 1
  ]
  edge [
    source 1377
    target 1698
    kind "mentions"
  ]
  edge [
    source 1377
    target 1712
    kind "mentions"
  ]
  edge [
    source 1377
    target 1423
    kind "relation"
    relation "was where"
    weight 1
  ]
  edge [
    source 1377
    target 1816
    kind "mentions"
  ]
  edge [
    source 1378
    target 1384
    kind "mentions"
  ]
  edge [
    source 1378
    target 1388
    kind "mentions"
  ]
  edge [
    source 1379
    target 1384
    kind "mentions"
  ]
  edge [
    source 1380
    target 1384
    kind "mentions"
  ]
  edge [
    source 1380
    target 1388
    kind "mentions"
  ]
  edge [
    source 1384
    target 1385
    kind "mentions"
  ]
  edge [
    source 1384
    target 1386
    kind "mentions"
  ]
  edge [
    source 1384
    target 1387
    kind "mentions"
  ]
  edge [
    source 1384
    target 1947
    kind "summarizes"
  ]
  edge [
    source 1388
    target 1389
    kind "mentions"
  ]
  edge [
    source 1388
    target 1390
    kind "mentions"
  ]
  edge [
    source 1388
    target 1391
    kind "mentions"
  ]
  edge [
    source 1388
    target 1392
    kind "mentions"
  ]
  edge [
    source 1388
    target 1947
    kind "summarizes"
  ]
  edge [
    source 1393
    target 1394
    kind "mentions"
  ]
  edge [
    source 1393
    target 1952
    kind "summarizes"
  ]
  edge [
    source 1395
    target 1396
    kind "from_chunk"
  ]
  edge [
    source 1395
    target 1412
    kind "from_chunk"
  ]
  edge [
    source 1396
    target 1397
    kind "mentions"
  ]
  edge [
    source 1396
    target 1398
    kind "mentions"
  ]
  edge [
    source 1396
    target 1399
    kind "mentions"
  ]
  edge [
    source 1396
    target 1400
    kind "mentions"
  ]
  edge [
    source 1396
    target 1401
    kind "mentions"
  ]
  edge [
    source 1396
    target 1402
    kind "mentions"
  ]
  edge [
    source 1396
    target 1403
    kind "mentions"
  ]
  edge [
    source 1396
    target 1404
    kind "mentions"
  ]
  edge [
    source 1396
    target 1405
    kind "mentions"
  ]
  edge [
    source 1396
    target 1406
    kind "mentions"
  ]
  edge [
    source 1396
    target 1407
    kind "mentions"
  ]
  edge [
    source 1396
    target 1408
    kind "mentions"
  ]
  edge [
    source 1396
    target 1409
    kind "mentions"
  ]
  edge [
    source 1396
    target 1410
    kind "mentions"
  ]
  edge [
    source 1396
    target 1411
    kind "mentions"
  ]
  edge [
    source 1396
    target 1936
    kind "summarizes"
  ]
  edge [
    source 1399
    target 1410
    kind "relation"
    relation "are present"
    weight 1
  ]
  edge [
    source 1411
    target 1412
    kind "mentions"
  ]
  edge [
    source 1412
    target 1413
    kind "mentions"
  ]
  edge [
    source 1412
    target 1936
    kind "summarizes"
  ]
  edge [
    source 1414
    target 1415
    kind "from_chunk"
  ]
  edge [
    source 1414
    target 1434
    kind "from_chunk"
  ]
  edge [
    source 1415
    target 1416
    kind "mentions"
  ]
  edge [
    source 1415
    target 1417
    kind "mentions"
  ]
  edge [
    source 1415
    target 1418
    kind "mentions"
  ]
  edge [
    source 1415
    target 1419
    kind "mentions"
  ]
  edge [
    source 1415
    target 1420
    kind "mentions"
  ]
  edge [
    source 1415
    target 1421
    kind "mentions"
  ]
  edge [
    source 1415
    target 1422
    kind "mentions"
  ]
  edge [
    source 1415
    target 1423
    kind "mentions"
  ]
  edge [
    source 1415
    target 1424
    kind "mentions"
  ]
  edge [
    source 1415
    target 1425
    kind "mentions"
  ]
  edge [
    source 1415
    target 1426
    kind "mentions"
  ]
  edge [
    source 1415
    target 1427
    kind "mentions"
  ]
  edge [
    source 1415
    target 1428
    kind "mentions"
  ]
  edge [
    source 1415
    target 1429
    kind "mentions"
  ]
  edge [
    source 1415
    target 1430
    kind "mentions"
  ]
  edge [
    source 1415
    target 1431
    kind "mentions"
  ]
  edge [
    source 1415
    target 1432
    kind "mentions"
  ]
  edge [
    source 1415
    target 1433
    kind "mentions"
  ]
  edge [
    source 1415
    target 1950
    kind "summarizes"
  ]
  edge [
    source 1417
    target 1426
    kind "relation"
    relation "are offered on the exchange at"
    weight 1
  ]
  edge [
    source 1418
    target 1436
    kind "mentions"
  ]
  edge [
    source 1418
    target 1444
    kind "relation"
    relation "told"
    weight 1
  ]
  edge [
    source 1418
    target 1445
    kind "relation"
    relation "has passed"
    weight 1
  ]
  edge [
    source 1419
    target 1436
    kind "mentions"
  ]
  edge [
    source 1419
    target 1650
    kind "mentions"
  ]
  edge [
    source 1419
    target 1664
    kind "relation"
    relation "part at"
    weight 1
  ]
  edge [
    source 1420
    target 1436
    kind "mentions"
  ]
  edge [
    source 1423
    target 1448
    kind "mentions"
  ]
  edge [
    source 1423
    target 1460
    kind "relation"
    relation "affected"
    weight 1
  ]
  edge [
    source 1423
    target 1461
    kind "relation"
    relation "was rare"
    weight 1
  ]
  edge [
    source 1423
    target 1453
    kind "relation"
    relation "died of"
    weight 1
  ]
  edge [
    source 1423
    target 1454
    kind "relation"
    relation "died of"
    weight 1
  ]
  edge [
    source 1423
    target 1456
    kind "relation"
    relation "was dangerously ill from"
    weight 1
  ]
  edge [
    source 1423
    target 1698
    kind "mentions"
  ]
  edge [
    source 1423
    target 1712
    kind "mentions"
  ]
  edge [
    source 1434
    target 1945
    kind "summarizes"
  ]
  edge [
    source 1435
    target 1436
    kind "from_chunk"
  ]
  edge [
    source 1435
    target 1446
    kind "from_chunk"
  ]
  edge [
    source 1436
    target 1437
    kind "mentions"
  ]
  edge [
    source 1436
    target 1438
    kind "mentions"
  ]
  edge [
    source 1436
    target 1439
    kind "mentions"
  ]
  edge [
    source 1436
    target 1440
    kind "mentions"
  ]
  edge [
    source 1436
    target 1441
    kind "mentions"
  ]
  edge [
    source 1436
    target 1442
    kind "mentions"
  ]
  edge [
    source 1436
    target 1443
    kind "mentions"
  ]
  edge [
    source 1436
    target 1444
    kind "mentions"
  ]
  edge [
    source 1436
    target 1445
    kind "mentions"
  ]
  edge [
    source 1436
    target 1950
    kind "summarizes"
  ]
  edge [
    source 1439
    target 1443
    kind "relation"
    relation "was never acted with | are considered admirable"
    weight 2
  ]
  edge [
    source 1439
    target 1442
    kind "relation"
    relation "is considered excellent"
    weight 1
  ]
  edge [
    source 1439
    target 1464
    kind "mentions"
  ]
  edge [
    source 1439
    target 1615
    kind "mentions"
  ]
  edge [
    source 1440
    target 1716
    kind "mentions"
  ]
  edge [
    source 1440
    target 1740
    kind "mentions"
  ]
  edge [
    source 1440
    target 1908
    kind "mentions"
  ]
  edge [
    source 1442
    target 1716
    kind "mentions"
  ]
  edge [
    source 1442
    target 1691
    kind "relation"
    relation "was full of"
    weight 2
  ]
  edge [
    source 1442
    target 1740
    kind "mentions"
  ]
  edge [
    source 1442
    target 1873
    kind "mentions"
  ]
  edge [
    source 1442
    target 1874
    kind "relation"
    relation "was not very good"
    weight 1
  ]
  edge [
    source 1443
    target 1645
    kind "mentions"
  ]
  edge [
    source 1443
    target 1782
    kind "mentions"
  ]
  edge [
    source 1443
    target 1784
    kind "relation"
    relation "was poorly performed"
    weight 1
  ]
  edge [
    source 1444
    target 1633
    kind "mentions"
  ]
  edge [
    source 1444
    target 1634
    kind "relation"
    relation "inquired for | took"
    weight 2
  ]
  edge [
    source 1444
    target 1635
    kind "relation"
    relation "gave"
    weight 1
  ]
  edge [
    source 1444
    target 1636
    kind "relation"
    relation "saw"
    weight 1
  ]
  edge [
    source 1444
    target 1639
    kind "relation"
    relation "met | took"
    weight 2
  ]
  edge [
    source 1444
    target 1840
    kind "mentions"
  ]
  edge [
    source 1446
    target 1933
    kind "summarizes"
  ]
  edge [
    source 1447
    target 1448
    kind "from_chunk"
  ]
  edge [
    source 1447
    target 1462
    kind "from_chunk"
  ]
  edge [
    source 1448
    target 1449
    kind "mentions"
  ]
  edge [
    source 1448
    target 1450
    kind "mentions"
  ]
  edge [
    source 1448
    target 1451
    kind "mentions"
  ]
  edge [
    source 1448
    target 1452
    kind "mentions"
  ]
  edge [
    source 1448
    target 1453
    kind "mentions"
  ]
  edge [
    source 1448
    target 1454
    kind "mentions"
  ]
  edge [
    source 1448
    target 1455
    kind "mentions"
  ]
  edge [
    source 1448
    target 1456
    kind "mentions"
  ]
  edge [
    source 1448
    target 1457
    kind "mentions"
  ]
  edge [
    source 1448
    target 1458
    kind "mentions"
  ]
  edge [
    source 1448
    target 1459
    kind "mentions"
  ]
  edge [
    source 1448
    target 1460
    kind "mentions"
  ]
  edge [
    source 1448
    target 1461
    kind "mentions"
  ]
  edge [
    source 1448
    target 1933
    kind "summarizes"
  ]
  edge [
    source 1449
    target 1458
    kind "relation"
    relation "met | expects to benefit from | spoke with"
    weight 4
  ]
  edge [
    source 1449
    target 1462
    kind "mentions"
  ]
  edge [
    source 1449
    target 1457
    kind "relation"
    relation "visited"
    weight 1
  ]
  edge [
    source 1450
    target 1451
    kind "relation"
    relation "was a clerk of"
    weight 1
  ]
  edge [
    source 1457
    target 1462
    kind "mentions"
  ]
  edge [
    source 1458
    target 1462
    kind "mentions"
  ]
  edge [
    source 1462
    target 1933
    kind "summarizes"
  ]
  edge [
    source 1463
    target 1464
    kind "from_chunk"
  ]
  edge [
    source 1463
    target 1485
    kind "from_chunk"
  ]
  edge [
    source 1463
    target 1488
    kind "from_chunk"
  ]
  edge [
    source 1464
    target 1465
    kind "mentions"
  ]
  edge [
    source 1464
    target 1466
    kind "mentions"
  ]
  edge [
    source 1464
    target 1467
    kind "mentions"
  ]
  edge [
    source 1464
    target 1468
    kind "mentions"
  ]
  edge [
    source 1464
    target 1469
    kind "mentions"
  ]
  edge [
    source 1464
    target 1470
    kind "mentions"
  ]
  edge [
    source 1464
    target 1471
    kind "mentions"
  ]
  edge [
    source 1464
    target 1472
    kind "mentions"
  ]
  edge [
    source 1464
    target 1473
    kind "mentions"
  ]
  edge [
    source 1464
    target 1474
    kind "mentions"
  ]
  edge [
    source 1464
    target 1475
    kind "mentions"
  ]
  edge [
    source 1464
    target 1476
    kind "mentions"
  ]
  edge [
    source 1464
    target 1477
    kind "mentions"
  ]
  edge [
    source 1464
    target 1478
    kind "mentions"
  ]
  edge [
    source 1464
    target 1479
    kind "mentions"
  ]
  edge [
    source 1464
    target 1480
    kind "mentions"
  ]
  edge [
    source 1464
    target 1481
    kind "mentions"
  ]
  edge [
    source 1464
    target 1482
    kind "mentions"
  ]
  edge [
    source 1464
    target 1483
    kind "mentions"
  ]
  edge [
    source 1464
    target 1484
    kind "mentions"
  ]
  edge [
    source 1464
    target 1943
    kind "summarizes"
  ]
  edge [
    source 1465
    target 1493
    kind "mentions"
  ]
  edge [
    source 1466
    target 1468
    kind "relation"
    relation "is associated with"
    weight 1
  ]
  edge [
    source 1467
    target 1468
    kind "relation"
    relation "is associated with"
    weight 1
  ]
  edge [
    source 1468
    target 1840
    kind "mentions"
  ]
  edge [
    source 1468
    target 1841
    kind "relation"
    relation "is in very ill condition due to"
    weight 1
  ]
  edge [
    source 1468
    target 1842
    kind "relation"
    relation "is in very ill condition due to"
    weight 1
  ]
  edge [
    source 1468
    target 1756
    kind "relation"
    relation "is in very ill condition due to"
    weight 1
  ]
  edge [
    source 1468
    target 1843
    kind "relation"
    relation "is in very ill condition due to"
    weight 1
  ]
  edge [
    source 1468
    target 1844
    kind "relation"
    relation "is in very ill condition due to"
    weight 1
  ]
  edge [
    source 1468
    target 1845
    kind "relation"
    relation "leads to"
    weight 1
  ]
  edge [
    source 1468
    target 1846
    kind "relation"
    relation "are extremely high in status"
    weight 1
  ]
  edge [
    source 1470
    target 1481
    kind "relation"
    relation "was visited by"
    weight 1
  ]
  edge [
    source 1470
    target 1693
    kind "mentions"
  ]
  edge [
    source 1470
    target 1698
    kind "mentions"
  ]
  edge [
    source 1471
    target 1816
    kind "mentions"
  ]
  edge [
    source 1471
    target 1909
    kind "mentions"
  ]
  edge [
    source 1471
    target 1903
    kind "relation"
    relation "was lately too much given to | was so much in love of"
    weight 2
  ]
  edge [
    source 1471
    target 1929
    kind "mentions"
  ]
  edge [
    source 1472
    target 1483
    kind "relation"
    relation "was sent with"
    weight 1
  ]
  edge [
    source 1472
    target 1474
    kind "relation"
    relation "was reported to have arrived in | arrived in"
    weight 2
  ]
  edge [
    source 1472
    target 1484
    kind "relation"
    relation "was not known to have reached"
    weight 1
  ]
  edge [
    source 1472
    target 1488
    kind "mentions"
  ]
  edge [
    source 1472
    target 1473
    kind "relation"
    relation "was sent to"
    weight 1
  ]
  edge [
    source 1472
    target 1491
    kind "relation"
    relation "has unknown purpose"
    weight 1
  ]
  edge [
    source 1473
    target 1488
    kind "mentions"
  ]
  edge [
    source 1474
    target 1488
    kind "mentions"
  ]
  edge [
    source 1475
    target 1476
    kind "relation"
    relation "will bring"
    weight 1
  ]
  edge [
    source 1485
    target 1486
    kind "mentions"
  ]
  edge [
    source 1485
    target 1487
    kind "mentions"
  ]
  edge [
    source 1485
    target 1933
    kind "summarizes"
  ]
  edge [
    source 1488
    target 1489
    kind "mentions"
  ]
  edge [
    source 1488
    target 1490
    kind "mentions"
  ]
  edge [
    source 1488
    target 1491
    kind "mentions"
  ]
  edge [
    source 1488
    target 1943
    kind "summarizes"
  ]
  edge [
    source 1492
    target 1493
    kind "from_chunk"
  ]
  edge [
    source 1492
    target 1499
    kind "from_chunk"
  ]
  edge [
    source 1493
    target 1494
    kind "mentions"
  ]
  edge [
    source 1493
    target 1495
    kind "mentions"
  ]
  edge [
    source 1493
    target 1496
    kind "mentions"
  ]
  edge [
    source 1493
    target 1497
    kind "mentions"
  ]
  edge [
    source 1493
    target 1498
    kind "mentions"
  ]
  edge [
    source 1493
    target 1933
    kind "summarizes"
  ]
  edge [
    source 1497
    target 1499
    kind "mentions"
  ]
  edge [
    source 1497
    target 1567
    kind "mentions"
  ]
  edge [
    source 1497
    target 1569
    kind "relation"
    relation "gave birth to | is very well"
    weight 2
  ]
  edge [
    source 1498
    target 1499
    kind "mentions"
  ]
  edge [
    source 1499
    target 1933
    kind "summarizes"
  ]
  edge [
    source 1500
    target 1501
    kind "from_chunk"
  ]
  edge [
    source 1501
    target 1502
    kind "mentions"
  ]
  edge [
    source 1501
    target 1503
    kind "mentions"
  ]
  edge [
    source 1501
    target 1504
    kind "mentions"
  ]
  edge [
    source 1501
    target 1505
    kind "mentions"
  ]
  edge [
    source 1501
    target 1506
    kind "mentions"
  ]
  edge [
    source 1501
    target 1507
    kind "mentions"
  ]
  edge [
    source 1501
    target 1508
    kind "mentions"
  ]
  edge [
    source 1501
    target 1509
    kind "mentions"
  ]
  edge [
    source 1501
    target 1510
    kind "mentions"
  ]
  edge [
    source 1501
    target 1953
    kind "summarizes"
  ]
  edge [
    source 1506
    target 1507
    kind "relation"
    relation "is equivalent to"
    weight 1
  ]
  edge [
    source 1506
    target 1510
    kind "relation"
    relation "was not noticed by"
    weight 1
  ]
  edge [
    source 1506
    target 1512
    kind "mentions"
  ]
  edge [
    source 1506
    target 1517
    kind "relation"
    relation "recorded"
    weight 1
  ]
  edge [
    source 1506
    target 1519
    kind "relation"
    relation "was given to"
    weight 1
  ]
  edge [
    source 1511
    target 1512
    kind "from_chunk"
  ]
  edge [
    source 1511
    target 1525
    kind "from_chunk"
  ]
  edge [
    source 1512
    target 1513
    kind "mentions"
  ]
  edge [
    source 1512
    target 1514
    kind "mentions"
  ]
  edge [
    source 1512
    target 1515
    kind "mentions"
  ]
  edge [
    source 1512
    target 1516
    kind "mentions"
  ]
  edge [
    source 1512
    target 1517
    kind "mentions"
  ]
  edge [
    source 1512
    target 1518
    kind "mentions"
  ]
  edge [
    source 1512
    target 1519
    kind "mentions"
  ]
  edge [
    source 1512
    target 1520
    kind "mentions"
  ]
  edge [
    source 1512
    target 1521
    kind "mentions"
  ]
  edge [
    source 1512
    target 1522
    kind "mentions"
  ]
  edge [
    source 1512
    target 1523
    kind "mentions"
  ]
  edge [
    source 1512
    target 1524
    kind "mentions"
  ]
  edge [
    source 1512
    target 1953
    kind "summarizes"
  ]
  edge [
    source 1514
    target 1716
    kind "mentions"
  ]
  edge [
    source 1519
    target 1523
    kind "relation"
    relation "used to clear"
    weight 1
  ]
  edge [
    source 1522
    target 1524
    kind "relation"
    relation "was obtained through"
    weight 1
  ]
  edge [
    source 1525
    target 1526
    kind "mentions"
  ]
  edge [
    source 1525
    target 1527
    kind "mentions"
  ]
  edge [
    source 1525
    target 1528
    kind "mentions"
  ]
  edge [
    source 1525
    target 1529
    kind "mentions"
  ]
  edge [
    source 1525
    target 1530
    kind "mentions"
  ]
  edge [
    source 1525
    target 1531
    kind "mentions"
  ]
  edge [
    source 1525
    target 1532
    kind "mentions"
  ]
  edge [
    source 1525
    target 1533
    kind "mentions"
  ]
  edge [
    source 1525
    target 1534
    kind "mentions"
  ]
  edge [
    source 1525
    target 1535
    kind "mentions"
  ]
  edge [
    source 1525
    target 1536
    kind "mentions"
  ]
  edge [
    source 1525
    target 1537
    kind "mentions"
  ]
  edge [
    source 1525
    target 1538
    kind "mentions"
  ]
  edge [
    source 1525
    target 1539
    kind "mentions"
  ]
  edge [
    source 1525
    target 1540
    kind "mentions"
  ]
  edge [
    source 1525
    target 1943
    kind "summarizes"
  ]
  edge [
    source 1529
    target 1536
    kind "relation"
    relation "went to"
    weight 1
  ]
  edge [
    source 1530
    target 1536
    kind "relation"
    relation "examined and sealed"
    weight 1
  ]
  edge [
    source 1536
    target 1537
    kind "relation"
    relation "waited until"
    weight 1
  ]
  edge [
    source 1536
    target 1538
    kind "relation"
    relation "went to"
    weight 1
  ]
  edge [
    source 1536
    target 1539
    kind "relation"
    relation "found their coach gone"
    weight 1
  ]
  edge [
    source 1536
    target 1540
    kind "relation"
    relation "walked home on foot"
    weight 1
  ]
  edge [
    source 1541
    target 1542
    kind "from_chunk"
  ]
  edge [
    source 1541
    target 1556
    kind "from_chunk"
  ]
  edge [
    source 1542
    target 1543
    kind "mentions"
  ]
  edge [
    source 1542
    target 1544
    kind "mentions"
  ]
  edge [
    source 1542
    target 1545
    kind "mentions"
  ]
  edge [
    source 1542
    target 1546
    kind "mentions"
  ]
  edge [
    source 1542
    target 1547
    kind "mentions"
  ]
  edge [
    source 1542
    target 1548
    kind "mentions"
  ]
  edge [
    source 1542
    target 1549
    kind "mentions"
  ]
  edge [
    source 1542
    target 1550
    kind "mentions"
  ]
  edge [
    source 1542
    target 1551
    kind "mentions"
  ]
  edge [
    source 1542
    target 1552
    kind "mentions"
  ]
  edge [
    source 1542
    target 1553
    kind "mentions"
  ]
  edge [
    source 1542
    target 1554
    kind "mentions"
  ]
  edge [
    source 1542
    target 1555
    kind "mentions"
  ]
  edge [
    source 1542
    target 1944
    kind "summarizes"
  ]
  edge [
    source 1543
    target 1544
    kind "relation"
    relation "began to whistle"
    weight 1
  ]
  edge [
    source 1543
    target 1545
    kind "relation"
    relation "answered the whistling"
    weight 1
  ]
  edge [
    source 1545
    target 1551
    kind "relation"
    relation "has lost his voice"
    weight 1
  ]
  edge [
    source 1549
    target 1550
    kind "relation"
    relation "is a daughter of"
    weight 2
  ]
  edge [
    source 1549
    target 1556
    kind "mentions"
  ]
  edge [
    source 1550
    target 1556
    kind "mentions"
  ]
  edge [
    source 1555
    target 1556
    kind "mentions"
  ]
  edge [
    source 1556
    target 1944
    kind "summarizes"
  ]
  edge [
    source 1557
    target 1558
    kind "from_chunk"
  ]
  edge [
    source 1557
    target 1567
    kind "from_chunk"
  ]
  edge [
    source 1557
    target 1574
    kind "from_chunk"
  ]
  edge [
    source 1557
    target 1582
    kind "from_chunk"
  ]
  edge [
    source 1558
    target 1559
    kind "mentions"
  ]
  edge [
    source 1558
    target 1560
    kind "mentions"
  ]
  edge [
    source 1558
    target 1561
    kind "mentions"
  ]
  edge [
    source 1558
    target 1562
    kind "mentions"
  ]
  edge [
    source 1558
    target 1563
    kind "mentions"
  ]
  edge [
    source 1558
    target 1564
    kind "mentions"
  ]
  edge [
    source 1558
    target 1565
    kind "mentions"
  ]
  edge [
    source 1558
    target 1566
    kind "mentions"
  ]
  edge [
    source 1558
    target 1952
    kind "summarizes"
  ]
  edge [
    source 1559
    target 1560
    kind "relation"
    relation "is angry that"
    weight 1
  ]
  edge [
    source 1559
    target 1563
    kind "relation"
    relation "is described as"
    weight 1
  ]
  edge [
    source 1560
    target 1565
    kind "relation"
    relation "gave minimal mourning to"
    weight 1
  ]
  edge [
    source 1560
    target 1566
    kind "relation"
    relation "gave similar mourning to"
    weight 1
  ]
  edge [
    source 1564
    target 1585
    kind "mentions"
  ]
  edge [
    source 1564
    target 1782
    kind "mentions"
  ]
  edge [
    source 1564
    target 1784
    kind "relation"
    relation "was unpleasant"
    weight 1
  ]
  edge [
    source 1564
    target 1904
    kind "mentions"
  ]
  edge [
    source 1567
    target 1568
    kind "mentions"
  ]
  edge [
    source 1567
    target 1569
    kind "mentions"
  ]
  edge [
    source 1567
    target 1570
    kind "mentions"
  ]
  edge [
    source 1567
    target 1571
    kind "mentions"
  ]
  edge [
    source 1567
    target 1572
    kind "mentions"
  ]
  edge [
    source 1567
    target 1573
    kind "mentions"
  ]
  edge [
    source 1567
    target 1945
    kind "summarizes"
  ]
  edge [
    source 1568
    target 1572
    kind "relation"
    relation "was going to dinner at"
    weight 1
  ]
  edge [
    source 1568
    target 1574
    kind "mentions"
  ]
  edge [
    source 1568
    target 1578
    kind "relation"
    relation "is eager for"
    weight 1
  ]
  edge [
    source 1568
    target 1575
    kind "relation"
    relation "fears daughter is too young"
    weight 1
  ]
  edge [
    source 1568
    target 1576
    kind "relation"
    relation "fears portion is not big enough"
    weight 1
  ]
  edge [
    source 1574
    target 1575
    kind "mentions"
  ]
  edge [
    source 1574
    target 1576
    kind "mentions"
  ]
  edge [
    source 1574
    target 1577
    kind "mentions"
  ]
  edge [
    source 1574
    target 1578
    kind "mentions"
  ]
  edge [
    source 1574
    target 1579
    kind "mentions"
  ]
  edge [
    source 1574
    target 1580
    kind "mentions"
  ]
  edge [
    source 1574
    target 1581
    kind "mentions"
  ]
  edge [
    source 1574
    target 1938
    kind "summarizes"
  ]
  edge [
    source 1576
    target 1698
    kind "mentions"
  ]
  edge [
    source 1578
    target 1581
    kind "relation"
    relation "is desirous of"
    weight 1
  ]
  edge [
    source 1582
    target 1583
    kind "mentions"
  ]
  edge [
    source 1582
    target 1937
    kind "summarizes"
  ]
  edge [
    source 1584
    target 1585
    kind "from_chunk"
  ]
  edge [
    source 1584
    target 1600
    kind "from_chunk"
  ]
  edge [
    source 1585
    target 1586
    kind "mentions"
  ]
  edge [
    source 1585
    target 1587
    kind "mentions"
  ]
  edge [
    source 1585
    target 1588
    kind "mentions"
  ]
  edge [
    source 1585
    target 1589
    kind "mentions"
  ]
  edge [
    source 1585
    target 1590
    kind "mentions"
  ]
  edge [
    source 1585
    target 1591
    kind "mentions"
  ]
  edge [
    source 1585
    target 1592
    kind "mentions"
  ]
  edge [
    source 1585
    target 1593
    kind "mentions"
  ]
  edge [
    source 1585
    target 1594
    kind "mentions"
  ]
  edge [
    source 1585
    target 1595
    kind "mentions"
  ]
  edge [
    source 1585
    target 1596
    kind "mentions"
  ]
  edge [
    source 1585
    target 1597
    kind "mentions"
  ]
  edge [
    source 1585
    target 1598
    kind "mentions"
  ]
  edge [
    source 1585
    target 1599
    kind "mentions"
  ]
  edge [
    source 1585
    target 1952
    kind "summarizes"
  ]
  edge [
    source 1589
    target 1599
    kind "relation"
    relation "had a supper of"
    weight 1
  ]
  edge [
    source 1590
    target 1765
    kind "mentions"
  ]
  edge [
    source 1590
    target 1775
    kind "mentions"
  ]
  edge [
    source 1593
    target 1698
    kind "mentions"
  ]
  edge [
    source 1593
    target 1765
    kind "mentions"
  ]
  edge [
    source 1595
    target 1596
    kind "relation"
    relation "stayed at"
    weight 1
  ]
  edge [
    source 1597
    target 1598
    kind "relation"
    relation "believed that"
    weight 1
  ]
  edge [
    source 1600
    target 1601
    kind "mentions"
  ]
  edge [
    source 1600
    target 1602
    kind "mentions"
  ]
  edge [
    source 1600
    target 1603
    kind "mentions"
  ]
  edge [
    source 1600
    target 1604
    kind "mentions"
  ]
  edge [
    source 1600
    target 1605
    kind "mentions"
  ]
  edge [
    source 1600
    target 1606
    kind "mentions"
  ]
  edge [
    source 1600
    target 1607
    kind "mentions"
  ]
  edge [
    source 1600
    target 1608
    kind "mentions"
  ]
  edge [
    source 1600
    target 1609
    kind "mentions"
  ]
  edge [
    source 1600
    target 1610
    kind "mentions"
  ]
  edge [
    source 1600
    target 1611
    kind "mentions"
  ]
  edge [
    source 1600
    target 1612
    kind "mentions"
  ]
  edge [
    source 1600
    target 1613
    kind "mentions"
  ]
  edge [
    source 1600
    target 1937
    kind "summarizes"
  ]
  edge [
    source 1604
    target 1615
    kind "mentions"
  ]
  edge [
    source 1604
    target 1616
    kind "relation"
    relation "had them sign"
    weight 1
  ]
  edge [
    source 1609
    target 1610
    kind "relation"
    relation "had become"
    weight 1
  ]
  edge [
    source 1611
    target 1612
    kind "relation"
    relation "went to | sat and talked at"
    weight 2
  ]
  edge [
    source 1611
    target 1613
    kind "relation"
    relation "had signed"
    weight 1
  ]
  edge [
    source 1614
    target 1615
    kind "from_chunk"
  ]
  edge [
    source 1614
    target 1623
    kind "from_chunk"
  ]
  edge [
    source 1615
    target 1616
    kind "mentions"
  ]
  edge [
    source 1615
    target 1617
    kind "mentions"
  ]
  edge [
    source 1615
    target 1618
    kind "mentions"
  ]
  edge [
    source 1615
    target 1619
    kind "mentions"
  ]
  edge [
    source 1615
    target 1620
    kind "mentions"
  ]
  edge [
    source 1615
    target 1621
    kind "mentions"
  ]
  edge [
    source 1615
    target 1622
    kind "mentions"
  ]
  edge [
    source 1615
    target 1937
    kind "summarizes"
  ]
  edge [
    source 1616
    target 1617
    kind "relation"
    relation "gave"
    weight 1
  ]
  edge [
    source 1617
    target 1621
    kind "relation"
    relation "received"
    weight 1
  ]
  edge [
    source 1622
    target 1716
    kind "mentions"
  ]
  edge [
    source 1622
    target 1735
    kind "relation"
    relation "traveled by coach to"
    weight 1
  ]
  edge [
    source 1622
    target 1736
    kind "relation"
    relation "had dinner with"
    weight 1
  ]
  edge [
    source 1622
    target 1724
    kind "relation"
    relation "saw"
    weight 2
  ]
  edge [
    source 1622
    target 1740
    kind "mentions"
  ]
  edge [
    source 1622
    target 1816
    kind "mentions"
  ]
  edge [
    source 1622
    target 1818
    kind "relation"
    relation "are in good health"
    weight 1
  ]
  edge [
    source 1623
    target 1624
    kind "mentions"
  ]
  edge [
    source 1623
    target 1625
    kind "mentions"
  ]
  edge [
    source 1623
    target 1626
    kind "mentions"
  ]
  edge [
    source 1623
    target 1627
    kind "mentions"
  ]
  edge [
    source 1623
    target 1628
    kind "mentions"
  ]
  edge [
    source 1623
    target 1629
    kind "mentions"
  ]
  edge [
    source 1623
    target 1630
    kind "mentions"
  ]
  edge [
    source 1623
    target 1631
    kind "mentions"
  ]
  edge [
    source 1623
    target 1939
    kind "summarizes"
  ]
  edge [
    source 1624
    target 1625
    kind "relation"
    relation "brought from"
    weight 1
  ]
  edge [
    source 1624
    target 1626
    kind "relation"
    relation "brought"
    weight 1
  ]
  edge [
    source 1626
    target 1627
    kind "relation"
    relation "is large | resembles a man in most things"
    weight 2
  ]
  edge [
    source 1626
    target 1872
    kind "mentions"
  ]
  edge [
    source 1629
    target 1631
    kind "relation"
    relation "agreed to give"
    weight 1
  ]
  edge [
    source 1629
    target 1840
    kind "mentions"
  ]
  edge [
    source 1629
    target 1854
    kind "relation"
    relation "involves paying"
    weight 2
  ]
  edge [
    source 1629
    target 1867
    kind "mentions"
  ]
  edge [
    source 1632
    target 1633
    kind "from_chunk"
  ]
  edge [
    source 1632
    target 1645
    kind "from_chunk"
  ]
  edge [
    source 1633
    target 1634
    kind "mentions"
  ]
  edge [
    source 1633
    target 1635
    kind "mentions"
  ]
  edge [
    source 1633
    target 1636
    kind "mentions"
  ]
  edge [
    source 1633
    target 1637
    kind "mentions"
  ]
  edge [
    source 1633
    target 1638
    kind "mentions"
  ]
  edge [
    source 1633
    target 1639
    kind "mentions"
  ]
  edge [
    source 1633
    target 1640
    kind "mentions"
  ]
  edge [
    source 1633
    target 1641
    kind "mentions"
  ]
  edge [
    source 1633
    target 1642
    kind "mentions"
  ]
  edge [
    source 1633
    target 1643
    kind "mentions"
  ]
  edge [
    source 1633
    target 1644
    kind "mentions"
  ]
  edge [
    source 1633
    target 1950
    kind "summarizes"
  ]
  edge [
    source 1637
    target 1644
    kind "relation"
    relation "performed the prince's part"
    weight 1
  ]
  edge [
    source 1637
    target 1645
    kind "mentions"
  ]
  edge [
    source 1637
    target 1648
    kind "relation"
    relation "taught | was taught by"
    weight 2
  ]
  edge [
    source 1638
    target 1645
    kind "mentions"
  ]
  edge [
    source 1639
    target 1640
    kind "relation"
    relation "stayed at"
    weight 1
  ]
  edge [
    source 1640
    target 1641
    kind "relation"
    relation "is located in"
    weight 1
  ]
  edge [
    source 1645
    target 1646
    kind "mentions"
  ]
  edge [
    source 1645
    target 1647
    kind "mentions"
  ]
  edge [
    source 1645
    target 1648
    kind "mentions"
  ]
  edge [
    source 1645
    target 1950
    kind "summarizes"
  ]
  edge [
    source 1649
    target 1650
    kind "from_chunk"
  ]
  edge [
    source 1649
    target 1670
    kind "from_chunk"
  ]
  edge [
    source 1650
    target 1651
    kind "mentions"
  ]
  edge [
    source 1650
    target 1652
    kind "mentions"
  ]
  edge [
    source 1650
    target 1653
    kind "mentions"
  ]
  edge [
    source 1650
    target 1654
    kind "mentions"
  ]
  edge [
    source 1650
    target 1655
    kind "mentions"
  ]
  edge [
    source 1650
    target 1656
    kind "mentions"
  ]
  edge [
    source 1650
    target 1657
    kind "mentions"
  ]
  edge [
    source 1650
    target 1658
    kind "mentions"
  ]
  edge [
    source 1650
    target 1659
    kind "mentions"
  ]
  edge [
    source 1650
    target 1660
    kind "mentions"
  ]
  edge [
    source 1650
    target 1661
    kind "mentions"
  ]
  edge [
    source 1650
    target 1662
    kind "mentions"
  ]
  edge [
    source 1650
    target 1663
    kind "mentions"
  ]
  edge [
    source 1650
    target 1664
    kind "mentions"
  ]
  edge [
    source 1650
    target 1665
    kind "mentions"
  ]
  edge [
    source 1650
    target 1666
    kind "mentions"
  ]
  edge [
    source 1650
    target 1667
    kind "mentions"
  ]
  edge [
    source 1650
    target 1668
    kind "mentions"
  ]
  edge [
    source 1650
    target 1669
    kind "mentions"
  ]
  edge [
    source 1650
    target 1936
    kind "summarizes"
  ]
  edge [
    source 1651
    target 1661
    kind "relation"
    relation "discusses"
    weight 1
  ]
  edge [
    source 1651
    target 1663
    kind "relation"
    relation "is not troubled by"
    weight 1
  ]
  edge [
    source 1651
    target 1654
    kind "relation"
    relation "tells | convinces | walks with"
    weight 3
  ]
  edge [
    source 1651
    target 1660
    kind "relation"
    relation "returns home"
    weight 1
  ]
  edge [
    source 1651
    target 1656
    kind "relation"
    relation "makes even with | reconciles with"
    weight 2
  ]
  edge [
    source 1651
    target 1670
    kind "mentions"
  ]
  edge [
    source 1653
    target 1662
    kind "relation"
    relation "does not show solicitude for"
    weight 1
  ]
  edge [
    source 1654
    target 1665
    kind "relation"
    relation "allows"
    weight 1
  ]
  edge [
    source 1656
    target 1658
    kind "relation"
    relation "has been mills' maid for | has served mills for"
    weight 2
  ]
  edge [
    source 1656
    target 1668
    kind "relation"
    relation "is to go into the country to | is going into the country to"
    weight 2
  ]
  edge [
    source 1656
    target 1659
    kind "relation"
    relation "is with mills before"
    weight 2
  ]
  edge [
    source 1656
    target 1670
    kind "mentions"
  ]
  edge [
    source 1658
    target 1670
    kind "mentions"
  ]
  edge [
    source 1659
    target 1670
    kind "mentions"
  ]
  edge [
    source 1664
    target 1667
    kind "relation"
    relation "go to | sup at"
    weight 2
  ]
  edge [
    source 1668
    target 1670
    kind "mentions"
  ]
  edge [
    source 1670
    target 1936
    kind "summarizes"
  ]
  edge [
    source 1671
    target 1672
    kind "from_chunk"
  ]
  edge [
    source 1671
    target 1679
    kind "from_chunk"
  ]
  edge [
    source 1671
    target 1685
    kind "from_chunk"
  ]
  edge [
    source 1671
    target 1688
    kind "from_chunk"
  ]
  edge [
    source 1671
    target 1693
    kind "from_chunk"
  ]
  edge [
    source 1672
    target 1673
    kind "mentions"
  ]
  edge [
    source 1672
    target 1674
    kind "mentions"
  ]
  edge [
    source 1672
    target 1675
    kind "mentions"
  ]
  edge [
    source 1672
    target 1676
    kind "mentions"
  ]
  edge [
    source 1672
    target 1677
    kind "mentions"
  ]
  edge [
    source 1672
    target 1678
    kind "mentions"
  ]
  edge [
    source 1672
    target 1936
    kind "summarizes"
  ]
  edge [
    source 1679
    target 1680
    kind "mentions"
  ]
  edge [
    source 1679
    target 1681
    kind "mentions"
  ]
  edge [
    source 1679
    target 1682
    kind "mentions"
  ]
  edge [
    source 1679
    target 1683
    kind "mentions"
  ]
  edge [
    source 1679
    target 1684
    kind "mentions"
  ]
  edge [
    source 1679
    target 1937
    kind "summarizes"
  ]
  edge [
    source 1685
    target 1686
    kind "mentions"
  ]
  edge [
    source 1685
    target 1687
    kind "mentions"
  ]
  edge [
    source 1685
    target 1937
    kind "summarizes"
  ]
  edge [
    source 1688
    target 1689
    kind "mentions"
  ]
  edge [
    source 1688
    target 1690
    kind "mentions"
  ]
  edge [
    source 1688
    target 1691
    kind "mentions"
  ]
  edge [
    source 1688
    target 1692
    kind "mentions"
  ]
  edge [
    source 1688
    target 1949
    kind "summarizes"
  ]
  edge [
    source 1690
    target 1691
    kind "relation"
    relation "was full of | contained no great matter beyond"
    weight 2
  ]
  edge [
    source 1691
    target 1716
    kind "mentions"
  ]
  edge [
    source 1691
    target 1740
    kind "mentions"
  ]
  edge [
    source 1693
    target 1694
    kind "mentions"
  ]
  edge [
    source 1693
    target 1695
    kind "mentions"
  ]
  edge [
    source 1693
    target 1696
    kind "mentions"
  ]
  edge [
    source 1693
    target 1943
    kind "summarizes"
  ]
  edge [
    source 1694
    target 1695
    kind "relation"
    relation "was formerly a clerk of"
    weight 1
  ]
  edge [
    source 1697
    target 1698
    kind "from_chunk"
  ]
  edge [
    source 1697
    target 1712
    kind "from_chunk"
  ]
  edge [
    source 1697
    target 1714
    kind "from_chunk"
  ]
  edge [
    source 1698
    target 1699
    kind "mentions"
  ]
  edge [
    source 1698
    target 1700
    kind "mentions"
  ]
  edge [
    source 1698
    target 1701
    kind "mentions"
  ]
  edge [
    source 1698
    target 1702
    kind "mentions"
  ]
  edge [
    source 1698
    target 1703
    kind "mentions"
  ]
  edge [
    source 1698
    target 1704
    kind "mentions"
  ]
  edge [
    source 1698
    target 1705
    kind "mentions"
  ]
  edge [
    source 1698
    target 1706
    kind "mentions"
  ]
  edge [
    source 1698
    target 1707
    kind "mentions"
  ]
  edge [
    source 1698
    target 1708
    kind "mentions"
  ]
  edge [
    source 1698
    target 1709
    kind "mentions"
  ]
  edge [
    source 1698
    target 1710
    kind "mentions"
  ]
  edge [
    source 1698
    target 1711
    kind "mentions"
  ]
  edge [
    source 1698
    target 1947
    kind "summarizes"
  ]
  edge [
    source 1700
    target 1701
    kind "relation"
    relation "are friends of"
    weight 1
  ]
  edge [
    source 1703
    target 1712
    kind "mentions"
  ]
  edge [
    source 1704
    target 1712
    kind "mentions"
  ]
  edge [
    source 1704
    target 1713
    kind "relation"
    relation "is the date of"
    weight 1
  ]
  edge [
    source 1705
    target 1714
    kind "mentions"
  ]
  edge [
    source 1706
    target 1714
    kind "mentions"
  ]
  edge [
    source 1707
    target 1714
    kind "mentions"
  ]
  edge [
    source 1707
    target 1716
    kind "mentions"
  ]
  edge [
    source 1707
    target 1727
    kind "relation"
    relation "drank so much that"
    weight 1
  ]
  edge [
    source 1712
    target 1713
    kind "mentions"
  ]
  edge [
    source 1712
    target 1947
    kind "summarizes"
  ]
  edge [
    source 1714
    target 1947
    kind "summarizes"
  ]
  edge [
    source 1715
    target 1716
    kind "from_chunk"
  ]
  edge [
    source 1715
    target 1740
    kind "from_chunk"
  ]
  edge [
    source 1716
    target 1717
    kind "mentions"
  ]
  edge [
    source 1716
    target 1718
    kind "mentions"
  ]
  edge [
    source 1716
    target 1719
    kind "mentions"
  ]
  edge [
    source 1716
    target 1720
    kind "mentions"
  ]
  edge [
    source 1716
    target 1721
    kind "mentions"
  ]
  edge [
    source 1716
    target 1722
    kind "mentions"
  ]
  edge [
    source 1716
    target 1723
    kind "mentions"
  ]
  edge [
    source 1716
    target 1724
    kind "mentions"
  ]
  edge [
    source 1716
    target 1725
    kind "mentions"
  ]
  edge [
    source 1716
    target 1726
    kind "mentions"
  ]
  edge [
    source 1716
    target 1727
    kind "mentions"
  ]
  edge [
    source 1716
    target 1728
    kind "mentions"
  ]
  edge [
    source 1716
    target 1729
    kind "mentions"
  ]
  edge [
    source 1716
    target 1730
    kind "mentions"
  ]
  edge [
    source 1716
    target 1731
    kind "mentions"
  ]
  edge [
    source 1716
    target 1732
    kind "mentions"
  ]
  edge [
    source 1716
    target 1733
    kind "mentions"
  ]
  edge [
    source 1716
    target 1734
    kind "mentions"
  ]
  edge [
    source 1716
    target 1735
    kind "mentions"
  ]
  edge [
    source 1716
    target 1736
    kind "mentions"
  ]
  edge [
    source 1716
    target 1737
    kind "mentions"
  ]
  edge [
    source 1716
    target 1738
    kind "mentions"
  ]
  edge [
    source 1716
    target 1739
    kind "mentions"
  ]
  edge [
    source 1716
    target 1949
    kind "summarizes"
  ]
  edge [
    source 1717
    target 1726
    kind "relation"
    relation "is going"
    weight 1
  ]
  edge [
    source 1720
    target 1739
    kind "relation"
    relation "had a full sight of"
    weight 2
  ]
  edge [
    source 1720
    target 1740
    kind "mentions"
  ]
  edge [
    source 1724
    target 1740
    kind "mentions"
  ]
  edge [
    source 1725
    target 1740
    kind "mentions"
  ]
  edge [
    source 1725
    target 1908
    kind "mentions"
  ]
  edge [
    source 1731
    target 1732
    kind "relation"
    relation "talked about"
    weight 1
  ]
  edge [
    source 1731
    target 1733
    kind "relation"
    relation "had fears that"
    weight 1
  ]
  edge [
    source 1739
    target 1740
    kind "mentions"
  ]
  edge [
    source 1740
    target 1949
    kind "summarizes"
  ]
  edge [
    source 1741
    target 1742
    kind "from_chunk"
  ]
  edge [
    source 1741
    target 1752
    kind "from_chunk"
  ]
  edge [
    source 1741
    target 1763
    kind "from_chunk"
  ]
  edge [
    source 1742
    target 1743
    kind "mentions"
  ]
  edge [
    source 1742
    target 1744
    kind "mentions"
  ]
  edge [
    source 1742
    target 1745
    kind "mentions"
  ]
  edge [
    source 1742
    target 1746
    kind "mentions"
  ]
  edge [
    source 1742
    target 1747
    kind "mentions"
  ]
  edge [
    source 1742
    target 1748
    kind "mentions"
  ]
  edge [
    source 1742
    target 1749
    kind "mentions"
  ]
  edge [
    source 1742
    target 1750
    kind "mentions"
  ]
  edge [
    source 1742
    target 1751
    kind "mentions"
  ]
  edge [
    source 1742
    target 1937
    kind "summarizes"
  ]
  edge [
    source 1748
    target 1893
    kind "mentions"
  ]
  edge [
    source 1752
    target 1753
    kind "mentions"
  ]
  edge [
    source 1752
    target 1754
    kind "mentions"
  ]
  edge [
    source 1752
    target 1755
    kind "mentions"
  ]
  edge [
    source 1752
    target 1756
    kind "mentions"
  ]
  edge [
    source 1752
    target 1757
    kind "mentions"
  ]
  edge [
    source 1752
    target 1758
    kind "mentions"
  ]
  edge [
    source 1752
    target 1759
    kind "mentions"
  ]
  edge [
    source 1752
    target 1760
    kind "mentions"
  ]
  edge [
    source 1752
    target 1761
    kind "mentions"
  ]
  edge [
    source 1752
    target 1762
    kind "mentions"
  ]
  edge [
    source 1752
    target 1944
    kind "summarizes"
  ]
  edge [
    source 1756
    target 1840
    kind "mentions"
  ]
  edge [
    source 1757
    target 1758
    kind "relation"
    relation "was from"
    weight 1
  ]
  edge [
    source 1758
    target 1765
    kind "mentions"
  ]
  edge [
    source 1763
    target 1946
    kind "summarizes"
  ]
  edge [
    source 1764
    target 1765
    kind "from_chunk"
  ]
  edge [
    source 1764
    target 1775
    kind "from_chunk"
  ]
  edge [
    source 1765
    target 1766
    kind "mentions"
  ]
  edge [
    source 1765
    target 1767
    kind "mentions"
  ]
  edge [
    source 1765
    target 1768
    kind "mentions"
  ]
  edge [
    source 1765
    target 1769
    kind "mentions"
  ]
  edge [
    source 1765
    target 1770
    kind "mentions"
  ]
  edge [
    source 1765
    target 1771
    kind "mentions"
  ]
  edge [
    source 1765
    target 1772
    kind "mentions"
  ]
  edge [
    source 1765
    target 1773
    kind "mentions"
  ]
  edge [
    source 1765
    target 1774
    kind "mentions"
  ]
  edge [
    source 1765
    target 1946
    kind "summarizes"
  ]
  edge [
    source 1766
    target 1770
    kind "relation"
    relation "was used as a metaphor for"
    weight 1
  ]
  edge [
    source 1767
    target 1772
    kind "relation"
    relation "is the tailor whose daughter"
    weight 2
  ]
  edge [
    source 1767
    target 1775
    kind "mentions"
  ]
  edge [
    source 1769
    target 1775
    kind "mentions"
  ]
  edge [
    source 1772
    target 1775
    kind "mentions"
  ]
  edge [
    source 1773
    target 1775
    kind "mentions"
  ]
  edge [
    source 1774
    target 1775
    kind "mentions"
  ]
  edge [
    source 1775
    target 1776
    kind "mentions"
  ]
  edge [
    source 1775
    target 1777
    kind "mentions"
  ]
  edge [
    source 1775
    target 1778
    kind "mentions"
  ]
  edge [
    source 1775
    target 1779
    kind "mentions"
  ]
  edge [
    source 1775
    target 1780
    kind "mentions"
  ]
  edge [
    source 1775
    target 1946
    kind "summarizes"
  ]
  edge [
    source 1781
    target 1782
    kind "from_chunk"
  ]
  edge [
    source 1781
    target 1799
    kind "from_chunk"
  ]
  edge [
    source 1782
    target 1783
    kind "mentions"
  ]
  edge [
    source 1782
    target 1784
    kind "mentions"
  ]
  edge [
    source 1782
    target 1785
    kind "mentions"
  ]
  edge [
    source 1782
    target 1786
    kind "mentions"
  ]
  edge [
    source 1782
    target 1787
    kind "mentions"
  ]
  edge [
    source 1782
    target 1788
    kind "mentions"
  ]
  edge [
    source 1782
    target 1789
    kind "mentions"
  ]
  edge [
    source 1782
    target 1790
    kind "mentions"
  ]
  edge [
    source 1782
    target 1791
    kind "mentions"
  ]
  edge [
    source 1782
    target 1792
    kind "mentions"
  ]
  edge [
    source 1782
    target 1793
    kind "mentions"
  ]
  edge [
    source 1782
    target 1794
    kind "mentions"
  ]
  edge [
    source 1782
    target 1795
    kind "mentions"
  ]
  edge [
    source 1782
    target 1796
    kind "mentions"
  ]
  edge [
    source 1782
    target 1797
    kind "mentions"
  ]
  edge [
    source 1782
    target 1798
    kind "mentions"
  ]
  edge [
    source 1782
    target 1952
    kind "summarizes"
  ]
  edge [
    source 1784
    target 1785
    kind "relation"
    relation "was bad in every aspect"
    weight 1
  ]
  edge [
    source 1788
    target 1798
    kind "relation"
    relation "walked towards | parted"
    weight 4
  ]
  edge [
    source 1788
    target 1799
    kind "mentions"
  ]
  edge [
    source 1789
    target 1798
    kind "relation"
    relation "went to"
    weight 2
  ]
  edge [
    source 1789
    target 1799
    kind "mentions"
  ]
  edge [
    source 1790
    target 1799
    kind "mentions"
  ]
  edge [
    source 1791
    target 1799
    kind "mentions"
  ]
  edge [
    source 1792
    target 1799
    kind "mentions"
  ]
  edge [
    source 1793
    target 1799
    kind "mentions"
  ]
  edge [
    source 1794
    target 1799
    kind "mentions"
  ]
  edge [
    source 1795
    target 1799
    kind "mentions"
  ]
  edge [
    source 1798
    target 1799
    kind "mentions"
  ]
  edge [
    source 1799
    target 1800
    kind "mentions"
  ]
  edge [
    source 1799
    target 1952
    kind "summarizes"
  ]
  edge [
    source 1801
    target 1802
    kind "from_chunk"
  ]
  edge [
    source 1801
    target 1814
    kind "from_chunk"
  ]
  edge [
    source 1802
    target 1803
    kind "mentions"
  ]
  edge [
    source 1802
    target 1804
    kind "mentions"
  ]
  edge [
    source 1802
    target 1805
    kind "mentions"
  ]
  edge [
    source 1802
    target 1806
    kind "mentions"
  ]
  edge [
    source 1802
    target 1807
    kind "mentions"
  ]
  edge [
    source 1802
    target 1808
    kind "mentions"
  ]
  edge [
    source 1802
    target 1809
    kind "mentions"
  ]
  edge [
    source 1802
    target 1810
    kind "mentions"
  ]
  edge [
    source 1802
    target 1811
    kind "mentions"
  ]
  edge [
    source 1802
    target 1812
    kind "mentions"
  ]
  edge [
    source 1802
    target 1813
    kind "mentions"
  ]
  edge [
    source 1802
    target 1934
    kind "summarizes"
  ]
  edge [
    source 1803
    target 1810
    kind "relation"
    relation "pleased"
    weight 1
  ]
  edge [
    source 1804
    target 1809
    kind "relation"
    relation "bought for them"
    weight 1
  ]
  edge [
    source 1806
    target 1807
    kind "relation"
    relation "was observed at"
    weight 1
  ]
  edge [
    source 1810
    target 1811
    kind "relation"
    relation "is a"
    weight 1
  ]
  edge [
    source 1812
    target 1813
    kind "relation"
    relation "intended to have the king serve as godfather to"
    weight 2
  ]
  edge [
    source 1812
    target 1814
    kind "mentions"
  ]
  edge [
    source 1813
    target 1814
    kind "mentions"
  ]
  edge [
    source 1814
    target 1934
    kind "summarizes"
  ]
  edge [
    source 1815
    target 1816
    kind "from_chunk"
  ]
  edge [
    source 1815
    target 1838
    kind "from_chunk"
  ]
  edge [
    source 1816
    target 1817
    kind "mentions"
  ]
  edge [
    source 1816
    target 1818
    kind "mentions"
  ]
  edge [
    source 1816
    target 1819
    kind "mentions"
  ]
  edge [
    source 1816
    target 1820
    kind "mentions"
  ]
  edge [
    source 1816
    target 1821
    kind "mentions"
  ]
  edge [
    source 1816
    target 1822
    kind "mentions"
  ]
  edge [
    source 1816
    target 1823
    kind "mentions"
  ]
  edge [
    source 1816
    target 1824
    kind "mentions"
  ]
  edge [
    source 1816
    target 1825
    kind "mentions"
  ]
  edge [
    source 1816
    target 1826
    kind "mentions"
  ]
  edge [
    source 1816
    target 1827
    kind "mentions"
  ]
  edge [
    source 1816
    target 1828
    kind "mentions"
  ]
  edge [
    source 1816
    target 1829
    kind "mentions"
  ]
  edge [
    source 1816
    target 1830
    kind "mentions"
  ]
  edge [
    source 1816
    target 1831
    kind "mentions"
  ]
  edge [
    source 1816
    target 1832
    kind "mentions"
  ]
  edge [
    source 1816
    target 1833
    kind "mentions"
  ]
  edge [
    source 1816
    target 1834
    kind "mentions"
  ]
  edge [
    source 1816
    target 1835
    kind "mentions"
  ]
  edge [
    source 1816
    target 1836
    kind "mentions"
  ]
  edge [
    source 1816
    target 1837
    kind "mentions"
  ]
  edge [
    source 1816
    target 1946
    kind "summarizes"
  ]
  edge [
    source 1818
    target 1824
    kind "relation"
    relation "ends with"
    weight 1
  ]
  edge [
    source 1818
    target 1819
    kind "relation"
    relation "has recently gone"
    weight 1
  ]
  edge [
    source 1820
    target 1821
    kind "relation"
    relation "is in"
    weight 1
  ]
  edge [
    source 1820
    target 1829
    kind "relation"
    relation "has recovered from"
    weight 1
  ]
  edge [
    source 1827
    target 1828
    kind "relation"
    relation "will not arrive until"
    weight 1
  ]
  edge [
    source 1835
    target 1838
    kind "mentions"
  ]
  edge [
    source 1836
    target 1838
    kind "mentions"
  ]
  edge [
    source 1837
    target 1838
    kind "mentions"
  ]
  edge [
    source 1838
    target 1946
    kind "summarizes"
  ]
  edge [
    source 1839
    target 1840
    kind "from_chunk"
  ]
  edge [
    source 1839
    target 1866
    kind "from_chunk"
  ]
  edge [
    source 1839
    target 1867
    kind "from_chunk"
  ]
  edge [
    source 1839
    target 1869
    kind "from_chunk"
  ]
  edge [
    source 1840
    target 1841
    kind "mentions"
  ]
  edge [
    source 1840
    target 1842
    kind "mentions"
  ]
  edge [
    source 1840
    target 1843
    kind "mentions"
  ]
  edge [
    source 1840
    target 1844
    kind "mentions"
  ]
  edge [
    source 1840
    target 1845
    kind "mentions"
  ]
  edge [
    source 1840
    target 1846
    kind "mentions"
  ]
  edge [
    source 1840
    target 1847
    kind "mentions"
  ]
  edge [
    source 1840
    target 1848
    kind "mentions"
  ]
  edge [
    source 1840
    target 1849
    kind "mentions"
  ]
  edge [
    source 1840
    target 1850
    kind "mentions"
  ]
  edge [
    source 1840
    target 1851
    kind "mentions"
  ]
  edge [
    source 1840
    target 1852
    kind "mentions"
  ]
  edge [
    source 1840
    target 1853
    kind "mentions"
  ]
  edge [
    source 1840
    target 1854
    kind "mentions"
  ]
  edge [
    source 1840
    target 1855
    kind "mentions"
  ]
  edge [
    source 1840
    target 1856
    kind "mentions"
  ]
  edge [
    source 1840
    target 1857
    kind "mentions"
  ]
  edge [
    source 1840
    target 1858
    kind "mentions"
  ]
  edge [
    source 1840
    target 1859
    kind "mentions"
  ]
  edge [
    source 1840
    target 1860
    kind "mentions"
  ]
  edge [
    source 1840
    target 1861
    kind "mentions"
  ]
  edge [
    source 1840
    target 1862
    kind "mentions"
  ]
  edge [
    source 1840
    target 1863
    kind "mentions"
  ]
  edge [
    source 1840
    target 1864
    kind "mentions"
  ]
  edge [
    source 1840
    target 1865
    kind "mentions"
  ]
  edge [
    source 1840
    target 1939
    kind "summarizes"
  ]
  edge [
    source 1846
    target 1866
    kind "mentions"
  ]
  edge [
    source 1846
    target 1849
    kind "relation"
    relation "contributed"
    weight 1
  ]
  edge [
    source 1848
    target 1849
    kind "relation"
    relation "amounts to"
    weight 1
  ]
  edge [
    source 1848
    target 1861
    kind "relation"
    relation "is seen as insufficient | had better never have been established | is considered inadequate"
    weight 3
  ]
  edge [
    source 1848
    target 1866
    kind "mentions"
  ]
  edge [
    source 1848
    target 1850
    kind "relation"
    relation "was established on"
    weight 1
  ]
  edge [
    source 1849
    target 1866
    kind "mentions"
  ]
  edge [
    source 1850
    target 1866
    kind "mentions"
  ]
  edge [
    source 1852
    target 1867
    kind "mentions"
  ]
  edge [
    source 1853
    target 1864
    kind "relation"
    relation "causes difficulties in"
    weight 2
  ]
  edge [
    source 1853
    target 1867
    kind "mentions"
  ]
  edge [
    source 1854
    target 1867
    kind "mentions"
  ]
  edge [
    source 1855
    target 1871
    kind "mentions"
  ]
  edge [
    source 1855
    target 1865
    kind "relation"
    relation "was marked by"
    weight 1
  ]
  edge [
    source 1856
    target 1865
    kind "relation"
    relation "is very sickly with"
    weight 2
  ]
  edge [
    source 1856
    target 1869
    kind "mentions"
  ]
  edge [
    source 1857
    target 1858
    kind "relation"
    relation "protest against"
    weight 1
  ]
  edge [
    source 1859
    target 1860
    kind "relation"
    relation "sees no content or satisfaction"
    weight 1
  ]
  edge [
    source 1861
    target 1866
    kind "mentions"
  ]
  edge [
    source 1863
    target 1867
    kind "mentions"
  ]
  edge [
    source 1864
    target 1867
    kind "mentions"
  ]
  edge [
    source 1865
    target 1869
    kind "mentions"
  ]
  edge [
    source 1865
    target 1871
    kind "mentions"
  ]
  edge [
    source 1866
    target 1939
    kind "summarizes"
  ]
  edge [
    source 1867
    target 1868
    kind "mentions"
  ]
  edge [
    source 1867
    target 1939
    kind "summarizes"
  ]
  edge [
    source 1869
    target 1939
    kind "summarizes"
  ]
  edge [
    source 1870
    target 1871
    kind "from_chunk"
  ]
  edge [
    source 1870
    target 1872
    kind "from_chunk"
  ]
  edge [
    source 1870
    target 1873
    kind "from_chunk"
  ]
  edge [
    source 1870
    target 1875
    kind "from_chunk"
  ]
  edge [
    source 1870
    target 1879
    kind "from_chunk"
  ]
  edge [
    source 1870
    target 1883
    kind "from_chunk"
  ]
  edge [
    source 1870
    target 1887
    kind "from_chunk"
  ]
  edge [
    source 1870
    target 1888
    kind "from_chunk"
  ]
  edge [
    source 1870
    target 1889
    kind "from_chunk"
  ]
  edge [
    source 1870
    target 1891
    kind "from_chunk"
  ]
  edge [
    source 1870
    target 1893
    kind "from_chunk"
  ]
  edge [
    source 1870
    target 1894
    kind "from_chunk"
  ]
  edge [
    source 1870
    target 1895
    kind "from_chunk"
  ]
  edge [
    source 1870
    target 1897
    kind "from_chunk"
  ]
  edge [
    source 1870
    target 1899
    kind "from_chunk"
  ]
  edge [
    source 1871
    target 1939
    kind "summarizes"
  ]
  edge [
    source 1872
    target 1939
    kind "summarizes"
  ]
  edge [
    source 1873
    target 1874
    kind "mentions"
  ]
  edge [
    source 1873
    target 1949
    kind "summarizes"
  ]
  edge [
    source 1875
    target 1876
    kind "mentions"
  ]
  edge [
    source 1875
    target 1877
    kind "mentions"
  ]
  edge [
    source 1875
    target 1878
    kind "mentions"
  ]
  edge [
    source 1875
    target 1939
    kind "summarizes"
  ]
  edge [
    source 1876
    target 1877
    kind "relation"
    relation "caused | was set forth"
    weight 2
  ]
  edge [
    source 1879
    target 1880
    kind "mentions"
  ]
  edge [
    source 1879
    target 1881
    kind "mentions"
  ]
  edge [
    source 1879
    target 1882
    kind "mentions"
  ]
  edge [
    source 1879
    target 1939
    kind "summarizes"
  ]
  edge [
    source 1880
    target 1881
    kind "relation"
    relation "cure by"
    weight 1
  ]
  edge [
    source 1883
    target 1884
    kind "mentions"
  ]
  edge [
    source 1883
    target 1885
    kind "mentions"
  ]
  edge [
    source 1883
    target 1886
    kind "mentions"
  ]
  edge [
    source 1883
    target 1939
    kind "summarizes"
  ]
  edge [
    source 1884
    target 1885
    kind "relation"
    relation "caused to become"
    weight 1
  ]
  edge [
    source 1884
    target 1886
    kind "relation"
    relation "caused to become"
    weight 1
  ]
  edge [
    source 1887
    target 1935
    kind "summarizes"
  ]
  edge [
    source 1888
    target 1938
    kind "summarizes"
  ]
  edge [
    source 1889
    target 1890
    kind "mentions"
  ]
  edge [
    source 1889
    target 1942
    kind "summarizes"
  ]
  edge [
    source 1891
    target 1892
    kind "mentions"
  ]
  edge [
    source 1891
    target 1944
    kind "summarizes"
  ]
  edge [
    source 1893
    target 1937
    kind "summarizes"
  ]
  edge [
    source 1894
    target 1935
    kind "summarizes"
  ]
  edge [
    source 1895
    target 1896
    kind "mentions"
  ]
  edge [
    source 1895
    target 1951
    kind "summarizes"
  ]
  edge [
    source 1897
    target 1898
    kind "mentions"
  ]
  edge [
    source 1897
    target 1951
    kind "summarizes"
  ]
  edge [
    source 1899
    target 1900
    kind "mentions"
  ]
  edge [
    source 1899
    target 1940
    kind "summarizes"
  ]
  edge [
    source 1901
    target 1902
    kind "from_chunk"
  ]
  edge [
    source 1901
    target 1904
    kind "from_chunk"
  ]
  edge [
    source 1901
    target 1907
    kind "from_chunk"
  ]
  edge [
    source 1901
    target 1908
    kind "from_chunk"
  ]
  edge [
    source 1901
    target 1909
    kind "from_chunk"
  ]
  edge [
    source 1901
    target 1910
    kind "from_chunk"
  ]
  edge [
    source 1901
    target 1912
    kind "from_chunk"
  ]
  edge [
    source 1901
    target 1914
    kind "from_chunk"
  ]
  edge [
    source 1901
    target 1916
    kind "from_chunk"
  ]
  edge [
    source 1901
    target 1917
    kind "from_chunk"
  ]
  edge [
    source 1901
    target 1919
    kind "from_chunk"
  ]
  edge [
    source 1901
    target 1921
    kind "from_chunk"
  ]
  edge [
    source 1901
    target 1923
    kind "from_chunk"
  ]
  edge [
    source 1901
    target 1925
    kind "from_chunk"
  ]
  edge [
    source 1901
    target 1926
    kind "from_chunk"
  ]
  edge [
    source 1901
    target 1929
    kind "from_chunk"
  ]
  edge [
    source 1901
    target 1931
    kind "from_chunk"
  ]
  edge [
    source 1902
    target 1903
    kind "mentions"
  ]
  edge [
    source 1902
    target 1934
    kind "summarizes"
  ]
  edge [
    source 1903
    target 1904
    kind "mentions"
  ]
  edge [
    source 1903
    target 1906
    kind "relation"
    relation "found his company"
    weight 1
  ]
  edge [
    source 1903
    target 1905
    kind "relation"
    relation "broke wind and came to"
    weight 1
  ]
  edge [
    source 1903
    target 1907
    kind "mentions"
  ]
  edge [
    source 1903
    target 1909
    kind "mentions"
  ]
  edge [
    source 1903
    target 1910
    kind "mentions"
  ]
  edge [
    source 1903
    target 1912
    kind "mentions"
  ]
  edge [
    source 1903
    target 1913
    kind "relation"
    relation "required personal security from"
    weight 1
  ]
  edge [
    source 1903
    target 1916
    kind "mentions"
  ]
  edge [
    source 1903
    target 1917
    kind "mentions"
  ]
  edge [
    source 1903
    target 1919
    kind "mentions"
  ]
  edge [
    source 1903
    target 1925
    kind "mentions"
  ]
  edge [
    source 1903
    target 1929
    kind "mentions"
  ]
  edge [
    source 1904
    target 1905
    kind "mentions"
  ]
  edge [
    source 1904
    target 1906
    kind "mentions"
  ]
  edge [
    source 1904
    target 1934
    kind "summarizes"
  ]
  edge [
    source 1907
    target 1934
    kind "summarizes"
  ]
  edge [
    source 1908
    target 1949
    kind "summarizes"
  ]
  edge [
    source 1909
    target 1934
    kind "summarizes"
  ]
  edge [
    source 1910
    target 1911
    kind "mentions"
  ]
  edge [
    source 1910
    target 1934
    kind "summarizes"
  ]
  edge [
    source 1912
    target 1913
    kind "mentions"
  ]
  edge [
    source 1912
    target 1934
    kind "summarizes"
  ]
  edge [
    source 1914
    target 1915
    kind "mentions"
  ]
  edge [
    source 1914
    target 1938
    kind "summarizes"
  ]
  edge [
    source 1916
    target 1934
    kind "summarizes"
  ]
  edge [
    source 1917
    target 1918
    kind "mentions"
  ]
  edge [
    source 1917
    target 1934
    kind "summarizes"
  ]
  edge [
    source 1919
    target 1920
    kind "mentions"
  ]
  edge [
    source 1919
    target 1934
    kind "summarizes"
  ]
  edge [
    source 1921
    target 1922
    kind "mentions"
  ]
  edge [
    source 1921
    target 1947
    kind "summarizes"
  ]
  edge [
    source 1923
    target 1924
    kind "mentions"
  ]
  edge [
    source 1923
    target 1938
    kind "summarizes"
  ]
  edge [
    source 1925
    target 1949
    kind "summarizes"
  ]
  edge [
    source 1926
    target 1927
    kind "mentions"
  ]
  edge [
    source 1926
    target 1928
    kind "mentions"
  ]
  edge [
    source 1926
    target 1938
    kind "summarizes"
  ]
  edge [
    source 1929
    target 1930
    kind "mentions"
  ]
  edge [
    source 1929
    target 1934
    kind "summarizes"
  ]
  edge [
    source 1931
    target 1932
    kind "mentions"
  ]
  edge [
    source 1931
    target 1953
    kind "summarizes"
  ]
]
