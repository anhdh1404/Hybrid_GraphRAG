graph [
  node [
    id 0
    label "C:Novel-25646_00000"
    kind "chunk"
    chunk_id "Novel-25646_00000"
  ]
  node [
    id 1
    label "C:Novel-25646_00001"
    kind "chunk"
    chunk_id "Novel-25646_00001"
  ]
  node [
    id 2
    label "U:Novel-25646_00001#0"
    kind "unit"
    chunk_id "Novel-25646_00001"
    text "The book on hygienic physiology for high schools and academies is a more elaborate treatise prepared for teaching youth about the principles underlying health preservation and the formation of correct physical habits. It is beautifully illustrated and presented in 12mo cloth binding."
    community 9
  ]
  node [
    id 3
    label "E:HYGIENIC PHYSIOLOGY"
    kind "entity"
    name "HYGIENIC PHYSIOLOGY"
    community 9
  ]
  node [
    id 4
    label "E:HIGH SCHOOLS"
    kind "entity"
    name "HIGH SCHOOLS"
    community 9
  ]
  node [
    id 5
    label "E:ACADEMIES"
    kind "entity"
    name "ACADEMIES"
    community 9
  ]
  node [
    id 6
    label "E:PRINCIPLES OF HEALTH PRESERVATION"
    kind "entity"
    name "PRINCIPLES OF HEALTH PRESERVATION"
    community 9
  ]
  node [
    id 7
    label "E:CORRECT PHYSICAL HABITS"
    kind "entity"
    name "CORRECT PHYSICAL HABITS"
    community 9
  ]
  node [
    id 8
    label "E:12MO"
    kind "entity"
    name "12MO"
    community 9
  ]
  node [
    id 9
    label "E:CLOTH"
    kind "entity"
    name "CLOTH"
    community 9
  ]
  node [
    id 10
    label "E:BEAUTIFULLY ILLUSTRATED"
    kind "entity"
    name "BEAUTIFULLY ILLUSTRATED"
    community 9
  ]
  node [
    id 11
    label "E:HYGIENE FOR YOUNG PEOPLE"
    kind "entity"
    name "HYGIENE FOR YOUNG PEOPLE"
    community 9
  ]
  node [
    id 12
    label "U:Novel-25646_00001#1"
    kind "unit"
    chunk_id "Novel-25646_00001"
    text "As this book goes to press, Massachusetts has passed a legislative act making it the fourteenth state to require public school pupils, in both primary and higher grades, to be taught the effects of alcoholics and other narcotics on the human system, in connection with other facts of physiology and hygiene."
    community 9
  ]
  node [
    id 13
    label "E:MASSACHUSETTS"
    kind "entity"
    name "MASSACHUSETTS"
    community 9
  ]
  node [
    id 14
    label "E:LEGISLATIVE ACT"
    kind "entity"
    name "LEGISLATIVE ACT"
    community 9
  ]
  node [
    id 15
    label "E:PRIMARY GRADES"
    kind "entity"
    name "PRIMARY GRADES"
    community 9
  ]
  node [
    id 16
    label "E:HIGHER GRADES"
    kind "entity"
    name "HIGHER GRADES"
    community 9
  ]
  node [
    id 17
    label "E:PUBLIC SCHOOLS"
    kind "entity"
    name "PUBLIC SCHOOLS"
    community 9
  ]
  node [
    id 18
    label "E:ALCOHOLICS"
    kind "entity"
    name "ALCOHOLICS"
    community 9
  ]
  node [
    id 19
    label "E:OTHER NARCOTICS"
    kind "entity"
    name "OTHER NARCOTICS"
    community 9
  ]
  node [
    id 20
    label "E:HUMAN SYSTEM"
    kind "entity"
    name "HUMAN SYSTEM"
    community 9
  ]
  node [
    id 21
    label "E:PHYSIOLOGY"
    kind "entity"
    name "PHYSIOLOGY"
    community 9
  ]
  node [
    id 22
    label "E:HYGIENE"
    kind "entity"
    name "HYGIENE"
    community 9
  ]
  node [
    id 23
    label "E:REQUIRE TEACHING OF EFFECTS OF ALCOHOLICS AND OTHER NARCOTICS"
    kind "entity"
    name "REQUIRE TEACHING OF EFFECTS OF ALCOHOLICS AND OTHER NARCOTICS"
    community 9
  ]
  node [
    id 24
    label "E:REQUIRES TEACHING OF EFFECTS OF ALCOHOLICS AND OTHER NARCOTICS"
    kind "entity"
    name "REQUIRES TEACHING OF EFFECTS OF ALCOHOLICS AND OTHER NARCOTICS"
    community 9
  ]
  node [
    id 25
    label "E:EFFECTS OF ALCOHOLICS AND OTHER NARCOTICS"
    kind "entity"
    name "EFFECTS OF ALCOHOLICS AND OTHER NARCOTICS"
    community 9
  ]
  node [
    id 26
    label "E:PHYSIOLOGY AND HYGIENE"
    kind "entity"
    name "PHYSIOLOGY AND HYGIENE"
    community 9
  ]
  node [
    id 27
    label "E:PUPILS IN PRIMARY AND HIGHER GRADES"
    kind "entity"
    name "PUPILS IN PRIMARY AND HIGHER GRADES"
    community 9
  ]
  node [
    id 28
    label "C:Novel-25646_00002"
    kind "chunk"
    chunk_id "Novel-25646_00002"
  ]
  node [
    id 29
    label "U:Novel-25646_00002#0"
    kind "unit"
    chunk_id "Novel-25646_00002"
    text "The purpose of the legislation is not for future citizens to learn the technical names of bones, nerves, and muscles, but to provide them with timely and forewarning knowledge of how alcohol and other popular poisons affect the human body, life, and character. To support this education, a well-arranged, simple, and practical book has been created for use in the schoolroom to meet the needs of teachers and students who lack prior experience or study in this area. The book avoids technical terms and focuses only on essential physiological facts related to the effects of alcohol, tobacco, opium, and hygiene principles."
    community 9
  ]
  node [
    id 30
    label "E:FUTURE CITIZEN"
    kind "entity"
    name "FUTURE CITIZEN"
    community 9
  ]
  node [
    id 31
    label "E:TECHNICAL NAMES OF BONES"
    kind "entity"
    name "TECHNICAL NAMES OF BONES"
    community 9
  ]
  node [
    id 32
    label "E:TECHNICAL NAMES OF NERVES"
    kind "entity"
    name "TECHNICAL NAMES OF NERVES"
    community 9
  ]
  node [
    id 33
    label "E:TECHNICAL NAMES OF MUSCLES"
    kind "entity"
    name "TECHNICAL NAMES OF MUSCLES"
    community 9
  ]
  node [
    id 34
    label "E:ALCOHOL"
    kind "entity"
    name "ALCOHOL"
    community -1
  ]
  node [
    id 35
    label "E:POPULAR POISONS"
    kind "entity"
    name "POPULAR POISONS"
    community 9
  ]
  node [
    id 36
    label "E:HUMAN BODY"
    kind "entity"
    name "HUMAN BODY"
    community 1
  ]
  node [
    id 37
    label "E:LIFE"
    kind "entity"
    name "LIFE"
    community 9
  ]
  node [
    id 38
    label "E:CHARACTER"
    kind "entity"
    name "CHARACTER"
    community 9
  ]
  node [
    id 39
    label "E:TIMELY KNOWLEDGE"
    kind "entity"
    name "TIMELY KNOWLEDGE"
    community 9
  ]
  node [
    id 40
    label "E:FOREWARNING KNOWLEDGE"
    kind "entity"
    name "FOREWARNING KNOWLEDGE"
    community 9
  ]
  node [
    id 41
    label "E:EDUCATION"
    kind "entity"
    name "EDUCATION"
    community 9
  ]
  node [
    id 42
    label "E:SCHOOL-ROOM"
    kind "entity"
    name "SCHOOL-ROOM"
    community 9
  ]
  node [
    id 43
    label "E:TEACHER"
    kind "entity"
    name "TEACHER"
    community 9
  ]
  node [
    id 44
    label "E:SCHOLAR"
    kind "entity"
    name "SCHOLAR"
    community 9
  ]
  node [
    id 45
    label "E:NORMAL SCHOOLS"
    kind "entity"
    name "NORMAL SCHOOLS"
    community 9
  ]
  node [
    id 46
    label "E:PRIMARY TEACHER"
    kind "entity"
    name "PRIMARY TEACHER"
    community 9
  ]
  node [
    id 47
    label "E:PREVIOUS STUDY"
    kind "entity"
    name "PREVIOUS STUDY"
    community 9
  ]
  node [
    id 48
    label "E:WORK"
    kind "entity"
    name "WORK"
    community 9
  ]
  node [
    id 49
    label "E:FACTS OF PHYSIOLOGY"
    kind "entity"
    name "FACTS OF PHYSIOLOGY"
    community 9
  ]
  node [
    id 50
    label "E:TOBACCO"
    kind "entity"
    name "TOBACCO"
    community -1
  ]
  node [
    id 51
    label "E:OPIUM"
    kind "entity"
    name "OPIUM"
    community 16
  ]
  node [
    id 52
    label "E:TRUTHS OF HYGIENE"
    kind "entity"
    name "TRUTHS OF HYGIENE"
    community 9
  ]
  node [
    id 53
    label "E:TIMELY AND FOREWARNING KNOWLEDGE OF"
    kind "entity"
    name "TIMELY AND FOREWARNING KNOWLEDGE OF"
    community 9
  ]
  node [
    id 54
    label "E:LEGISLATION"
    kind "entity"
    name "LEGISLATION"
    community 9
  ]
  node [
    id 55
    label "E:PRIOR EXPERIENCE"
    kind "entity"
    name "PRIOR EXPERIENCE"
    community 9
  ]
  node [
    id 56
    label "E:SCHOOLROOM USE"
    kind "entity"
    name "SCHOOLROOM USE"
    community 9
  ]
  node [
    id 57
    label "E:TECHNICAL TERMS"
    kind "entity"
    name "TECHNICAL TERMS"
    community 9
  ]
  node [
    id 58
    label "E:ESSENTIAL PHYSIOLOGICAL FACTS"
    kind "entity"
    name "ESSENTIAL PHYSIOLOGICAL FACTS"
    community 9
  ]
  node [
    id 59
    label "E:EFFECTS OF ALCOHOL"
    kind "entity"
    name "EFFECTS OF ALCOHOL"
    community 9
  ]
  node [
    id 60
    label "E:EFFECTS OF TOBACCO"
    kind "entity"
    name "EFFECTS OF TOBACCO"
    community 9
  ]
  node [
    id 61
    label "E:EFFECTS OF OPIUM"
    kind "entity"
    name "EFFECTS OF OPIUM"
    community 9
  ]
  node [
    id 62
    label "C:Novel-25646_00003"
    kind "chunk"
    chunk_id "Novel-25646_00003"
  ]
  node [
    id 63
    label "C:Novel-25646_00004"
    kind "chunk"
    chunk_id "Novel-25646_00004"
  ]
  node [
    id 64
    label "U:Novel-25646_00004#0"
    kind "unit"
    chunk_id "Novel-25646_00004"
    text "Little girls like jointed dolls to play with because they can bend such dolls in eight or ten places, make them stand or sit, or play them as walking. As you study your own bodies, you will find that you each have better joints than any dolls bought at a toy shop. Some of your joints work like the hinges of a door and are called hinge-joints. Hinge-joints can be found in the elbows, knees, fingers, and toes. The boy who takes off his hat and makes a polite bow to his teacher on the street uses many hinges, one for each hinge-joint he moves."
    community 6
  ]
  node [
    id 65
    label "E:LITTLE GIRLS"
    kind "entity"
    name "LITTLE GIRLS"
    community 6
  ]
  node [
    id 66
    label "E:JOINTED DOLLS"
    kind "entity"
    name "JOINTED DOLLS"
    community 6
  ]
  node [
    id 67
    label "E:EIGHT OR TEN PLACES"
    kind "entity"
    name "EIGHT OR TEN PLACES"
    community 6
  ]
  node [
    id 68
    label "E:STAND"
    kind "entity"
    name "STAND"
    community 6
  ]
  node [
    id 69
    label "E:SIT"
    kind "entity"
    name "SIT"
    community 6
  ]
  node [
    id 70
    label "E:WALKING"
    kind "entity"
    name "WALKING"
    community 6
  ]
  node [
    id 71
    label "E:YOUR OWN BODIES"
    kind "entity"
    name "YOUR OWN BODIES"
    community 6
  ]
  node [
    id 72
    label "E:HINGE-JOINTS"
    kind "entity"
    name "HINGE-JOINTS"
    community 6
  ]
  node [
    id 73
    label "E:ELBOWS"
    kind "entity"
    name "ELBOWS"
    community 6
  ]
  node [
    id 74
    label "E:KNEES"
    kind "entity"
    name "KNEES"
    community 6
  ]
  node [
    id 75
    label "E:FINGERS"
    kind "entity"
    name "FINGERS"
    community 6
  ]
  node [
    id 76
    label "E:TOES"
    kind "entity"
    name "TOES"
    community 6
  ]
  node [
    id 77
    label "E:BOY WHO TAKES OFF HIS HAT"
    kind "entity"
    name "BOY WHO TAKES OFF HIS HAT"
    community 6
  ]
  node [
    id 78
    label "E:POLITE BOW"
    kind "entity"
    name "POLITE BOW"
    community 6
  ]
  node [
    id 79
    label "E:STREET"
    kind "entity"
    name "STREET"
    community 6
  ]
  node [
    id 80
    label "E:HINGES OF A DOOR"
    kind "entity"
    name "HINGES OF A DOOR"
    community 6
  ]
  node [
    id 81
    label "U:Novel-25646_00004#1"
    kind "unit"
    chunk_id "Novel-25646_00004"
    text "The boy who takes off his hat and makes a polite bow to his teacher on the street uses many hinges, one for each hinge-joint he moves."
    community 6
  ]
  node [
    id 82
    label "E:HINGE-JOINT"
    kind "entity"
    name "HINGE-JOINT"
    community 6
  ]
  node [
    id 83
    label "C:Novel-25646_00005"
    kind "chunk"
    chunk_id "Novel-25646_00005"
  ]
  node [
    id 84
    label "U:Novel-25646_00005#0"
    kind "unit"
    chunk_id "Novel-25646_00005"
    text "Hinges are used in various daily activities such as running up-stairs, opening the door, buttoning a coat or boots, playing ball, or digging in the garden, and are used nearly all the time; people could not function without them."
    community 20
  ]
  node [
    id 85
    label "E:HINGES"
    kind "entity"
    name "HINGES"
    community 20
  ]
  node [
    id 86
    label "E:RUNNING UP-STAIRS"
    kind "entity"
    name "RUNNING UP-STAIRS"
    community 20
  ]
  node [
    id 87
    label "E:OPENING THE DOOR"
    kind "entity"
    name "OPENING THE DOOR"
    community 20
  ]
  node [
    id 88
    label "E:BUTTONING COAT"
    kind "entity"
    name "BUTTONING COAT"
    community 20
  ]
  node [
    id 89
    label "E:BUTTONING BOOTS"
    kind "entity"
    name "BUTTONING BOOTS"
    community 20
  ]
  node [
    id 90
    label "E:PLAYING BALL"
    kind "entity"
    name "PLAYING BALL"
    community 20
  ]
  node [
    id 91
    label "E:DIGGING IN GARDEN"
    kind "entity"
    name "DIGGING IN GARDEN"
    community 20
  ]
  node [
    id 92
    label "U:Novel-25646_00005#1"
    kind "unit"
    chunk_id "Novel-25646_00005"
    text "Not all body joints are hinge-joints; the shoulder has a ball-and-socket joint that allows the arm to swing round and move up and down, and the hip has a similar joint that allows the leg to move in a similar way."
    community 20
  ]
  node [
    id 93
    label "E:BALL AND SOCKET JOINTS"
    kind "entity"
    name "BALL AND SOCKET JOINTS"
    community 20
  ]
  node [
    id 94
    label "E:SHOULDER"
    kind "entity"
    name "SHOULDER"
    community 20
  ]
  node [
    id 95
    label "E:ARM"
    kind "entity"
    name "ARM"
    community 20
  ]
  node [
    id 96
    label "E:HIP"
    kind "entity"
    name "HIP"
    community 20
  ]
  node [
    id 97
    label "E:LEG"
    kind "entity"
    name "LEG"
    community 20
  ]
  node [
    id 98
    label "E:LONG BONE"
    kind "entity"
    name "LONG BONE"
    community 20
  ]
  node [
    id 99
    label "E:SOCKET"
    kind "entity"
    name "SOCKET"
    community 20
  ]
  node [
    id 100
    label "E:BALL AND SOCKET JOINT"
    kind "entity"
    name "BALL AND SOCKET JOINT"
    community 20
  ]
  node [
    id 101
    label "U:Novel-25646_00005#2"
    kind "unit"
    chunk_id "Novel-25646_00005"
    text "The ball-and-socket joint consists of the round end of a long bone that moves within a hole called a socket, and body joints do not creak or fail like door or gate hinges because a soft, smooth fluid similar to the white of an egg keeps them moist and enables smooth movement."
    community 20
  ]
  node [
    id 102
    label "E:ROUND END OF LONG BONE"
    kind "entity"
    name "ROUND END OF LONG BONE"
    community 20
  ]
  node [
    id 103
    label "E:SOFT SMOOOTH FLUID"
    kind "entity"
    name "SOFT SMOOOTH FLUID"
    community 20
  ]
  node [
    id 104
    label "E:WHITE OF AN EGG"
    kind "entity"
    name "WHITE OF AN EGG"
    community 20
  ]
  node [
    id 105
    label "E:BODY JOINTS"
    kind "entity"
    name "BODY JOINTS"
    community 20
  ]
  node [
    id 106
    label "E:DOOR HINGES"
    kind "entity"
    name "DOOR HINGES"
    community 20
  ]
  node [
    id 107
    label "E:GATE HINGES"
    kind "entity"
    name "GATE HINGES"
    community 20
  ]
  node [
    id 108
    label "U:Novel-25646_00005#3"
    kind "unit"
    chunk_id "Novel-25646_00005"
    text "The parts of the body that are jointed together are bones; each person has about two hundred bones, some large, some small, including long bones in the legs and arms and many short bones in the fingers and toes; the backbone is called the spine."
    community 6
  ]
  node [
    id 109
    label "E:BONES"
    kind "entity"
    name "BONES"
    community 1
  ]
  node [
    id 110
    label "E:TWO HUNDRED"
    kind "entity"
    name "TWO HUNDRED"
    community 6
  ]
  node [
    id 111
    label "E:LARGE BONES"
    kind "entity"
    name "LARGE BONES"
    community 6
  ]
  node [
    id 112
    label "E:SMALL BONES"
    kind "entity"
    name "SMALL BONES"
    community 18
  ]
  node [
    id 113
    label "E:LONG BONES"
    kind "entity"
    name "LONG BONES"
    community 6
  ]
  node [
    id 114
    label "E:LEGS"
    kind "entity"
    name "LEGS"
    community 6
  ]
  node [
    id 115
    label "E:ARMS"
    kind "entity"
    name "ARMS"
    community 6
  ]
  node [
    id 116
    label "E:BACKBONE"
    kind "entity"
    name "BACKBONE"
    community 18
  ]
  node [
    id 117
    label "E:SPINE"
    kind "entity"
    name "SPINE"
    community 18
  ]
  node [
    id 118
    label "E:SHORT BONES"
    kind "entity"
    name "SHORT BONES"
    community 6
  ]
  node [
    id 119
    label "C:Novel-25646_00006"
    kind "chunk"
    chunk_id "Novel-25646_00006"
  ]
  node [
    id 120
    label "U:Novel-25646_00006#0"
    kind "unit"
    chunk_id "Novel-25646_00006"
    text "The backbone is called the spine; in a fish, it is made up of many small bones, and in humans, the spine is formed from twenty-four small bones, with an elastic cushion of gristle located between each bone and the next. When the body bends, these cushions are pressed together on one side and stretched on the other, then return to their original shape when standing straight again. These cushions act like springs, reducing the jolting effect felt when moving in vehicles without springs, such as wheelbarrows or carts. Twenty-four ribs, twelve on each side, curve from the spine to the breast bone and are covered by flesh, making them hard to feel or count, though they are present. Two flat shoulder-blades and two collar-bones, which almost meet in front near the collar, are also part of the skeletal structure."
    community 18
  ]
  node [
    id 121
    label "E:FISH"
    kind "entity"
    name "FISH"
    community 18
  ]
  node [
    id 122
    label "E:MANY LITTLE BONES"
    kind "entity"
    name "MANY LITTLE BONES"
    community 18
  ]
  node [
    id 123
    label "E:HUMAN SPINE"
    kind "entity"
    name "HUMAN SPINE"
    community 18
  ]
  node [
    id 124
    label "E:24 SMALL BONES"
    kind "entity"
    name "24 SMALL BONES"
    community 18
  ]
  node [
    id 125
    label "E:ELASTIC CUSHION OF GRISSEL"
    kind "entity"
    name "ELASTIC CUSHION OF GRISSEL"
    community 18
  ]
  node [
    id 126
    label "E:BENDING"
    kind "entity"
    name "BENDING"
    community 18
  ]
  node [
    id 127
    label "E:PRESSING TOGETHER"
    kind "entity"
    name "PRESSING TOGETHER"
    community 18
  ]
  node [
    id 128
    label "E:STRETCHED"
    kind "entity"
    name "STRETCHED"
    community 18
  ]
  node [
    id 129
    label "E:STANDING STRAIGHT"
    kind "entity"
    name "STANDING STRAIGHT"
    community 18
  ]
  node [
    id 130
    label "E:WHEELBARROW"
    kind "entity"
    name "WHEELBARROW"
    community 18
  ]
  node [
    id 131
    label "E:CART WITHOUT SPRINGS"
    kind "entity"
    name "CART WITHOUT SPRINGS"
    community 18
  ]
  node [
    id 132
    label "E:JOLTING"
    kind "entity"
    name "JOLTING"
    community 18
  ]
  node [
    id 133
    label "E:SPRING CUSHIONS"
    kind "entity"
    name "SPRING CUSHIONS"
    community 18
  ]
  node [
    id 134
    label "E:24 RIBS"
    kind "entity"
    name "24 RIBS"
    community 18
  ]
  node [
    id 135
    label "E:12 RIBS ON EACH SIDE"
    kind "entity"
    name "12 RIBS ON EACH SIDE"
    community 18
  ]
  node [
    id 136
    label "E:BREAST BONE"
    kind "entity"
    name "BREAST BONE"
    community 18
  ]
  node [
    id 137
    label "E:FLESH"
    kind "entity"
    name "FLESH"
    community 18
  ]
  node [
    id 138
    label "E:SHOULDER-BLADES"
    kind "entity"
    name "SHOULDER-BLADES"
    community 18
  ]
  node [
    id 139
    label "E:COLLAR-BONES"
    kind "entity"
    name "COLLAR-BONES"
    community 18
  ]
  node [
    id 140
    label "E:COLLAR"
    kind "entity"
    name "COLLAR"
    community 18
  ]
  node [
    id 141
    label "E:MADE OF"
    kind "entity"
    name "MADE OF"
    community 18
  ]
  node [
    id 142
    label "E:EACH LITTLE BONE AND THE NEXT"
    kind "entity"
    name "EACH LITTLE BONE AND THE NEXT"
    community 18
  ]
  node [
    id 143
    label "E:CUSHIONS TO BE PRESSED TOGETHER ON ONE SIDE AND STRETCHED ON THE OTHER"
    kind "entity"
    name "CUSHIONS TO BE PRESSED TOGETHER ON ONE SIDE AND STRETCHED ON THE OTHER"
    community 18
  ]
  node [
    id 144
    label "E:CUSHIONS"
    kind "entity"
    name "CUSHIONS"
    community 18
  ]
  node [
    id 145
    label "E:WHEN STANDING STRAIGHT AGAIN"
    kind "entity"
    name "WHEN STANDING STRAIGHT AGAIN"
    community 18
  ]
  node [
    id 146
    label "E:WHEN RIDDEN IN WITHOUT SPRINGS"
    kind "entity"
    name "WHEN RIDDEN IN WITHOUT SPRINGS"
    community 18
  ]
  node [
    id 147
    label "E:DURING MOVEMENT"
    kind "entity"
    name "DURING MOVEMENT"
    community 18
  ]
  node [
    id 148
    label "E:SPINE TO BREAST BONE"
    kind "entity"
    name "SPINE TO BREAST BONE"
    community 18
  ]
  node [
    id 149
    label "E:THAT ALMOST MEET IN FRONT NEAR THE COLLAR"
    kind "entity"
    name "THAT ALMOST MEET IN FRONT NEAR THE COLLAR"
    community 18
  ]
  node [
    id 150
    label "U:Novel-25646_00006#1"
    kind "unit"
    chunk_id "Novel-25646_00006"
    text "The passage ends with a question about the composition of bones, asking what they are made of."
    community 18
  ]
  node [
    id 151
    label "C:Novel-25646_00007"
    kind "chunk"
    chunk_id "Novel-25646_00007"
  ]
  node [
    id 152
    label "U:Novel-25646_00007#0"
    kind "unit"
    chunk_id "Novel-25646_00007"
    text "Bones are made of lime and a soft part called gristle. When a bone is heated in fire, it loses lime and crumbles to dust; when soaked in weak muriatic acid, the lime is removed and only the non-lime part remains, which is flexible and can be bent, twisted, and tied into a knot. The remaining substance is similar to the lime used by masons in mortar. Children's bones have more gristle than older people's bones, which makes them more flexible and easier to bend."
    community 8
  ]
  node [
    id 153
    label "E:LIME"
    kind "entity"
    name "LIME"
    community 1
  ]
  node [
    id 154
    label "E:GRISTLE"
    kind "entity"
    name "GRISTLE"
    community 8
  ]
  node [
    id 155
    label "E:FIRE"
    kind "entity"
    name "FIRE"
    community 0
  ]
  node [
    id 156
    label "E:WEAK MURIATIC ACID"
    kind "entity"
    name "WEAK MURIATIC ACID"
    community 8
  ]
  node [
    id 157
    label "E:DRUGGIST"
    kind "entity"
    name "DRUGGIST"
    community 8
  ]
  node [
    id 158
    label "E:MASON MORTAR"
    kind "entity"
    name "MASON MORTAR"
    community 8
  ]
  node [
    id 159
    label "E:CHILDREN'S BONES"
    kind "entity"
    name "CHILDREN'S BONES"
    community 8
  ]
  node [
    id 160
    label "E:OLDER PEOPLE'S BONES"
    kind "entity"
    name "OLDER PEOPLE'S BONES"
    community 8
  ]
  node [
    id 161
    label "E:FLEXIBLE BONE"
    kind "entity"
    name "FLEXIBLE BONE"
    community 8
  ]
  node [
    id 162
    label "E:BONE"
    kind "entity"
    name "BONE"
    community 8
  ]
  node [
    id 163
    label "E:HEATED IN FIRE"
    kind "entity"
    name "HEATED IN FIRE"
    community 8
  ]
  node [
    id 164
    label "E:SOAKED IN WEAK MURIATIC ACID"
    kind "entity"
    name "SOAKED IN WEAK MURIATIC ACID"
    community 8
  ]
  node [
    id 165
    label "E:STRUCK WITH A QUICK BLOW"
    kind "entity"
    name "STRUCK WITH A QUICK BLOW"
    community 8
  ]
  node [
    id 166
    label "U:Novel-25646_00007#1"
    kind "unit"
    chunk_id "Novel-25646_00007"
    text "A lady who has one leg shorter than the other became lame and now wears a boot with iron supports three or four inches high to walk."
    community 18
  ]
  node [
    id 167
    label "E:LADY"
    kind "entity"
    name "LADY"
    community 18
  ]
  node [
    id 168
    label "E:ONE LEG SHORTER THAN THE OTHER"
    kind "entity"
    name "ONE LEG SHORTER THAN THE OTHER"
    community 18
  ]
  node [
    id 169
    label "E:LAME"
    kind "entity"
    name "LAME"
    community 18
  ]
  node [
    id 170
    label "E:BOOT"
    kind "entity"
    name "BOOT"
    community 18
  ]
  node [
    id 171
    label "E:IRON SUPPORTS"
    kind "entity"
    name "IRON SUPPORTS"
    community 18
  ]
  node [
    id 172
    label "E:THREE OR FOUR INCHES HIGH"
    kind "entity"
    name "THREE OR FOUR INCHES HIGH"
    community 18
  ]
  node [
    id 173
    label "E:OTHER LEG"
    kind "entity"
    name "OTHER LEG"
    community 18
  ]
  node [
    id 174
    label "C:Novel-25646_00008"
    kind "chunk"
    chunk_id "Novel-25646_00008"
  ]
  node [
    id 175
    label "U:Novel-25646_00008#0"
    kind "unit"
    chunk_id "Novel-25646_00008"
    text "One day she told the narrator how she became lame: when she was between three and four years old, she sat in her high chair and twisted one foot under the little step of the chair; the next morning she felt lame, but no one could tell what was wrong; eventually doctors discovered the problem originated from that twist, which had gone too far to be cured; before she had the boot, she could only walk with a crutch."
    community 18
  ]
  node [
    id 176
    label "E:THREE TO FOUR YEARS OLD"
    kind "entity"
    name "THREE TO FOUR YEARS OLD"
    community 18
  ]
  node [
    id 177
    label "E:HIGH CHAIR"
    kind "entity"
    name "HIGH CHAIR"
    community 18
  ]
  node [
    id 178
    label "E:LITTLE STEP OF THE CHAIR"
    kind "entity"
    name "LITTLE STEP OF THE CHAIR"
    community 18
  ]
  node [
    id 179
    label "E:NEXT MORNING"
    kind "entity"
    name "NEXT MORNING"
    community 18
  ]
  node [
    id 180
    label "E:DOCTORS"
    kind "entity"
    name "DOCTORS"
    community 10
  ]
  node [
    id 181
    label "E:TWIST"
    kind "entity"
    name "TWIST"
    community 10
  ]
  node [
    id 182
    label "E:CRUTCH"
    kind "entity"
    name "CRUTCH"
    community 18
  ]
  node [
    id 183
    label "U:Novel-25646_00008#1"
    kind "unit"
    chunk_id "Novel-25646_00008"
    text "The spine is made of small bones with cushions between them, so it bends easily; children sometimes bend it more than they should; when leaning over books or writing, the elastic cushions on the inner edge get pressed and do not spring back, leading to round-shouldered or hump-backed posture; this bending also cramps the lungs, reducing their room for breathing; young people's bones are easily bent; if standing unevenly, one shoulder or hip becomes higher than the other, which is more serious because growth may cause crookedness before it is noticed."
    community 18
  ]
  node [
    id 184
    label "E:CHILDREN"
    kind "entity"
    name "CHILDREN"
    community 12
  ]
  node [
    id 185
    label "E:LEANING OVER"
    kind "entity"
    name "LEANING OVER"
    community 18
  ]
  node [
    id 186
    label "E:BOOK"
    kind "entity"
    name "BOOK"
    community 18
  ]
  node [
    id 187
    label "E:WRITING"
    kind "entity"
    name "WRITING"
    community 17
  ]
  node [
    id 188
    label "E:ELASTIC CUSHIONS"
    kind "entity"
    name "ELASTIC CUSHIONS"
    community 18
  ]
  node [
    id 189
    label "E:ROUND-SHOULDERED"
    kind "entity"
    name "ROUND-SHOULDERED"
    community 18
  ]
  node [
    id 190
    label "E:HUMP-BACKED"
    kind "entity"
    name "HUMP-BACKED"
    community 18
  ]
  node [
    id 191
    label "E:LUNGS"
    kind "entity"
    name "LUNGS"
    community 0
  ]
  node [
    id 192
    label "E:BREATHING"
    kind "entity"
    name "BREATHING"
    community 0
  ]
  node [
    id 193
    label "E:YOUNG PEOPLE"
    kind "entity"
    name "YOUNG PEOPLE"
    community 18
  ]
  node [
    id 194
    label "E:STANDING UNEVENLY"
    kind "entity"
    name "STANDING UNEVENLY"
    community 18
  ]
  node [
    id 195
    label "E:ONE SHOULDER"
    kind "entity"
    name "ONE SHOULDER"
    community 18
  ]
  node [
    id 196
    label "E:ONE HIP"
    kind "entity"
    name "ONE HIP"
    community 18
  ]
  node [
    id 197
    label "E:GROWING"
    kind "entity"
    name "GROWING"
    community 18
  ]
  node [
    id 198
    label "E:CROOKEDNESS"
    kind "entity"
    name "CROOKEDNESS"
    community 18
  ]
  node [
    id 199
    label "C:Novel-25646_00009"
    kind "chunk"
    chunk_id "Novel-25646_00009"
  ]
  node [
    id 200
    label "U:Novel-25646_00009#0"
    kind "unit"
    chunk_id "Novel-25646_00009"
    text "Growing children have soft bones that easily bend, so they must sit and stand erect to avoid growing crooked, round-shouldered, hump-backed, or lame; twisting legs, arms, or shoulders should be avoided to grow into straight and graceful men and women."
    community 18
  ]
  node [
    id 201
    label "E:GROWING CHILDREN"
    kind "entity"
    name "GROWING CHILDREN"
    community 18
  ]
  node [
    id 202
    label "E:SOFT BONES"
    kind "entity"
    name "SOFT BONES"
    community 18
  ]
  node [
    id 203
    label "E:SITTING ERECT"
    kind "entity"
    name "SITTING ERECT"
    community 18
  ]
  node [
    id 204
    label "E:STANDING ERECT"
    kind "entity"
    name "STANDING ERECT"
    community 18
  ]
  node [
    id 205
    label "E:TWISTING LEGS"
    kind "entity"
    name "TWISTING LEGS"
    community 18
  ]
  node [
    id 206
    label "E:TWISTING ARMS"
    kind "entity"
    name "TWISTING ARMS"
    community 18
  ]
  node [
    id 207
    label "E:TWISTING SHOULDERS"
    kind "entity"
    name "TWISTING SHOULDERS"
    community 18
  ]
  node [
    id 208
    label "E:CROOKED GROWTH"
    kind "entity"
    name "CROOKED GROWTH"
    community 18
  ]
  node [
    id 209
    label "E:STRAIGHT AND GRACEFUL MEN AND WOMEN"
    kind "entity"
    name "STRAIGHT AND GRACEFUL MEN AND WOMEN"
    community 18
  ]
  node [
    id 210
    label "U:Novel-25646_00009#1"
    kind "unit"
    chunk_id "Novel-25646_00009"
    text "Old people have bones with more lime, which makes them break more easily, so children should be kindly helpful to them to prevent falls and possible bone breaks."
    community 12
  ]
  node [
    id 211
    label "E:OLD PEOPLE"
    kind "entity"
    name "OLD PEOPLE"
    community 12
  ]
  node [
    id 212
    label "E:BREAKING"
    kind "entity"
    name "BREAKING"
    community 12
  ]
  node [
    id 213
    label "E:KINDLY HELPFUL"
    kind "entity"
    name "KINDLY HELPFUL"
    community 12
  ]
  node [
    id 214
    label "E:FALLS"
    kind "entity"
    name "FALLS"
    community 12
  ]
  node [
    id 215
    label "E:BONE BREAKS"
    kind "entity"
    name "BONE BREAKS"
    community 12
  ]
  node [
    id 216
    label "U:Novel-25646_00009#2"
    kind "unit"
    chunk_id "Novel-25646_00009"
    text "Healthy children outgrow their shoes quickly, and tight shoes cause corns, in-growing nails, and sore places on the feet, which are hard to treat; no one should wear shoes that pinch or hurt the foot."
    community 7
  ]
  node [
    id 217
    label "E:HEALTHY CHILDREN"
    kind "entity"
    name "HEALTHY CHILDREN"
    community 7
  ]
  node [
    id 218
    label "E:SHOES"
    kind "entity"
    name "SHOES"
    community 7
  ]
  node [
    id 219
    label "E:OUT-GROWING"
    kind "entity"
    name "OUT-GROWING"
    community 7
  ]
  node [
    id 220
    label "E:TIGHT SHOES"
    kind "entity"
    name "TIGHT SHOES"
    community 7
  ]
  node [
    id 221
    label "E:CORNS"
    kind "entity"
    name "CORNS"
    community 7
  ]
  node [
    id 222
    label "E:IN-GROWING NAILS"
    kind "entity"
    name "IN-GROWING NAILS"
    community 7
  ]
  node [
    id 223
    label "E:SORE PLACES ON FEET"
    kind "entity"
    name "SORE PLACES ON FEET"
    community 7
  ]
  node [
    id 224
    label "E:PINCHING"
    kind "entity"
    name "PINCHING"
    community 7
  ]
  node [
    id 225
    label "E:HURTING"
    kind "entity"
    name "HURTING"
    community 7
  ]
  node [
    id 226
    label "E:NO ONE"
    kind "entity"
    name "NO ONE"
    community 7
  ]
  node [
    id 227
    label "E:SHOES THAT PINCH OR HURT THE FOOT"
    kind "entity"
    name "SHOES THAT PINCH OR HURT THE FOOT"
    community 7
  ]
  node [
    id 228
    label "U:Novel-25646_00009#3"
    kind "unit"
    chunk_id "Novel-25646_00009"
    text "Tobacco is not good for men, but it is worse for boys because of a very good reason."
    community 9
  ]
  node [
    id 229
    label "E:BOYS"
    kind "entity"
    name "BOYS"
    community 9
  ]
  node [
    id 230
    label "E:NOT GOOD FOR MEN"
    kind "entity"
    name "NOT GOOD FOR MEN"
    community 9
  ]
  node [
    id 231
    label "E:WORSE FOR BOYS"
    kind "entity"
    name "WORSE FOR BOYS"
    community 9
  ]
  node [
    id 232
    label "E:VERY GOOD REASON"
    kind "entity"
    name "VERY GOOD REASON"
    community 9
  ]
  node [
    id 233
    label "C:Novel-25646_00010"
    kind "chunk"
    chunk_id "Novel-25646_00010"
  ]
  node [
    id 234
    label "U:Novel-25646_00010#0"
    kind "unit"
    chunk_id "Novel-25646_00010"
    text "It would be unwise to weaken any part of a house's structure by using poor materials in stone-work, brick-work, mortar, wood-work, nails, walls, or chimneys, as this would make the structure weak and tottering instead of strong and steady. Repairing a house with poor materials is insufficient; it must be built initially with the best available materials."
    community 13
  ]
  node [
    id 235
    label "E:STONE-WORK"
    kind "entity"
    name "STONE-WORK"
    community 13
  ]
  node [
    id 236
    label "E:BRICK-WORK"
    kind "entity"
    name "BRICK-WORK"
    community 13
  ]
  node [
    id 237
    label "E:MORTAR"
    kind "entity"
    name "MORTAR"
    community 13
  ]
  node [
    id 238
    label "E:WOOD-WORK"
    kind "entity"
    name "WOOD-WORK"
    community 13
  ]
  node [
    id 239
    label "E:NAILS"
    kind "entity"
    name "NAILS"
    community 13
  ]
  node [
    id 240
    label "E:WALLS"
    kind "entity"
    name "WALLS"
    community 13
  ]
  node [
    id 241
    label "E:CHIMNEYS"
    kind "entity"
    name "CHIMNEYS"
    community 13
  ]
  node [
    id 242
    label "E:POOR MATERIALS"
    kind "entity"
    name "POOR MATERIALS"
    community 13
  ]
  node [
    id 243
    label "E:STRONG AND STEADY"
    kind "entity"
    name "STRONG AND STEADY"
    community 13
  ]
  node [
    id 244
    label "E:HOUSE STRUCTURE"
    kind "entity"
    name "HOUSE STRUCTURE"
    community 13
  ]
  node [
    id 245
    label "E:POOR MATERIALS ARE USED"
    kind "entity"
    name "POOR MATERIALS ARE USED"
    community 13
  ]
  node [
    id 246
    label "E:BEST AVAILABLE MATERIALS"
    kind "entity"
    name "BEST AVAILABLE MATERIALS"
    community 13
  ]
  node [
    id 247
    label "U:Novel-25646_00010#1"
    kind "unit"
    chunk_id "Novel-25646_00010"
    text "Boys and girls are continuously building their bodies day after day until they reach full size, after which they must be repaired as fast as they wear out. It is foolish to build any part of the body in a way that makes it weaker than necessary."
    community 9
  ]
  node [
    id 248
    label "E:GIRLS"
    kind "entity"
    name "GIRLS"
    community 9
  ]
  node [
    id 249
    label "E:BODY"
    kind "entity"
    name "BODY"
    community -1
  ]
  node [
    id 250
    label "E:FULL SIZE"
    kind "entity"
    name "FULL SIZE"
    community 9
  ]
  node [
    id 251
    label "E:REPAIR"
    kind "entity"
    name "REPAIR"
    community 9
  ]
  node [
    id 252
    label "E:WEAR OUT"
    kind "entity"
    name "WEAR OUT"
    community 9
  ]
  node [
    id 253
    label "E:BUILDING BODY"
    kind "entity"
    name "BUILDING BODY"
    community 9
  ]
  node [
    id 254
    label "E:WEAKER THAN NECESSARY"
    kind "entity"
    name "WEAKER THAN NECESSARY"
    community 9
  ]
  node [
    id 255
    label "E:DAY AFTER DAY"
    kind "entity"
    name "DAY AFTER DAY"
    community 9
  ]
  node [
    id 256
    label "E:AFTER CONTINUOUS BUILDING"
    kind "entity"
    name "AFTER CONTINUOUS BUILDING"
    community 9
  ]
  node [
    id 257
    label "E:AS FAST AS IT WEARS OUT"
    kind "entity"
    name "AS FAST AS IT WEARS OUT"
    community 9
  ]
  node [
    id 258
    label "U:Novel-25646_00010#2"
    kind "unit"
    chunk_id "Novel-25646_00010"
    text "Wise doctors have stated that a boy who uses tobacco while growing makes every part of his body less strong than it would otherwise be, and his bones do not grow as well. Boys who smoke cannot become large, fine-looking men as they would if they did not smoke."
    community 21
  ]
  node [
    id 259
    label "E:BOY"
    kind "entity"
    name "BOY"
    community 21
  ]
  node [
    id 260
    label "E:LESS STRONG"
    kind "entity"
    name "LESS STRONG"
    community 21
  ]
  node [
    id 261
    label "E:FINE-LOOKING MEN"
    kind "entity"
    name "FINE-LOOKING MEN"
    community 21
  ]
  node [
    id 262
    label "E:SMOKING"
    kind "entity"
    name "SMOKING"
    community 21
  ]
  node [
    id 263
    label "E:THAN OTHERWISE"
    kind "entity"
    name "THAN OTHERWISE"
    community 21
  ]
  node [
    id 264
    label "E:DURING GROWING"
    kind "entity"
    name "DURING GROWING"
    community 21
  ]
  node [
    id 265
    label "U:Novel-25646_00010#3"
    kind "unit"
    chunk_id "Novel-25646_00010"
    text "Cigarettes are small in size but very poisonous. Chewing tobacco is a worse and more filthy habit than smoking."
    community 21
  ]
  node [
    id 266
    label "E:CIGARETTES"
    kind "entity"
    name "CIGARETTES"
    community 21
  ]
  node [
    id 267
    label "E:CHEWING TOBACCO"
    kind "entity"
    name "CHEWING TOBACCO"
    community 21
  ]
  node [
    id 268
    label "E:POISONOUS"
    kind "entity"
    name "POISONOUS"
    community 21
  ]
  node [
    id 269
    label "E:WORSE HABIT"
    kind "entity"
    name "WORSE HABIT"
    community 21
  ]
  node [
    id 270
    label "E:FILTHY HABIT"
    kind "entity"
    name "FILTHY HABIT"
    community 21
  ]
  node [
    id 271
    label "E:VERY POISONOUS"
    kind "entity"
    name "VERY POISONOUS"
    community 21
  ]
  node [
    id 272
    label "C:Novel-25646_00011"
    kind "chunk"
    chunk_id "Novel-25646_00011"
  ]
  node [
    id 273
    label "U:Novel-25646_00011#0"
    kind "unit"
    chunk_id "Novel-25646_00011"
    text "Chewing tobacco is a worse and more filthy habit than smoking, causing frequent spitting that is disgusting to others and harmful to the health of the user. Tobacco in any form is harmful to youth, stunting their growth, harming their minds, and damaging them in every way. No boy or girl aged seven to fourteen can begin using tobacco and still have a healthy body and mind at age twenty-one, as they would have if they had never used tobacco. To be strong and well, one should avoid using tobacco in any form."
    community 21
  ]
  node [
    id 274
    label "E:YOUTH"
    kind "entity"
    name "YOUTH"
    community 21
  ]
  node [
    id 275
    label "E:GROWTH"
    kind "entity"
    name "GROWTH"
    community 7
  ]
  node [
    id 276
    label "E:MIND"
    kind "entity"
    name "MIND"
    community 5
  ]
  node [
    id 277
    label "E:SPITTING"
    kind "entity"
    name "SPITTING"
    community 16
  ]
  node [
    id 278
    label "E:AGE 7 TO 14"
    kind "entity"
    name "AGE 7 TO 14"
    community 21
  ]
  node [
    id 279
    label "E:AGE 21"
    kind "entity"
    name "AGE 21"
    community 21
  ]
  node [
    id 280
    label "E:HEALTH"
    kind "entity"
    name "HEALTH"
    community 7
  ]
  node [
    id 281
    label "E:STUNTS"
    kind "entity"
    name "STUNTS"
    community 21
  ]
  node [
    id 282
    label "E:HURTS"
    kind "entity"
    name "HURTS"
    community 21
  ]
  node [
    id 283
    label "E:DAMAGES"
    kind "entity"
    name "DAMAGES"
    community 21
  ]
  node [
    id 284
    label "E:STRONG AND WELL MEN AND WOMEN"
    kind "entity"
    name "STRONG AND WELL MEN AND WOMEN"
    community 21
  ]
  node [
    id 285
    label "E:FREQUENT SPITTING"
    kind "entity"
    name "FREQUENT SPITTING"
    community 21
  ]
  node [
    id 286
    label "E:OTHERS"
    kind "entity"
    name "OTHERS"
    community 21
  ]
  node [
    id 287
    label "E:CHEWER"
    kind "entity"
    name "CHEWER"
    community 21
  ]
  node [
    id 288
    label "E:BOY OR GIRL AGED 7 TO 14"
    kind "entity"
    name "BOY OR GIRL AGED 7 TO 14"
    community 21
  ]
  node [
    id 289
    label "E:HEALTHY BODY AND MIND AT AGE 21"
    kind "entity"
    name "HEALTHY BODY AND MIND AT AGE 21"
    community 21
  ]
  node [
    id 290
    label "C:Novel-25646_00012"
    kind "chunk"
    chunk_id "Novel-25646_00012"
  ]
  node [
    id 291
    label "U:Novel-25646_00012#0"
    kind "unit"
    chunk_id "Novel-25646_00012"
    text "The passage lists a series of questions about human anatomy and health, including locations of bones, composition of bones, differences between children's and old people's bones, reasons for brittleness in old age, effects of posture, tobacco use, and muscle function. It ends with a question about what makes limbs move, comparing the need to hold a door to move it versus the internal mechanism of arm movement."
    community 21
  ]
  node [
    id 292
    label "E:OLD PEOPLE'S BONES"
    kind "entity"
    name "OLD PEOPLE'S BONES"
    community 21
  ]
  node [
    id 293
    label "E:FEET"
    kind "entity"
    name "FEET"
    community 15
  ]
  node [
    id 294
    label "E:MUSCLES"
    kind "entity"
    name "MUSCLES"
    community -1
  ]
  node [
    id 295
    label "E:DOOR"
    kind "entity"
    name "DOOR"
    community 20
  ]
  node [
    id 296
    label "E:GATE"
    kind "entity"
    name "GATE"
    community 20
  ]
  node [
    id 297
    label "E:BONE MATERIAL"
    kind "entity"
    name "BONE MATERIAL"
    community 21
  ]
  node [
    id 298
    label "E:LEANING OVER DESK"
    kind "entity"
    name "LEANING OVER DESK"
    community 21
  ]
  node [
    id 299
    label "E:WRONG POSITIONS"
    kind "entity"
    name "WRONG POSITIONS"
    community 21
  ]
  node [
    id 300
    label "E:OTHER BONES"
    kind "entity"
    name "OTHER BONES"
    community 21
  ]
  node [
    id 301
    label "E:TOBACCO USE"
    kind "entity"
    name "TOBACCO USE"
    community 10
  ]
  node [
    id 302
    label "E:HARM HEALTH"
    kind "entity"
    name "HARM HEALTH"
    community 21
  ]
  node [
    id 303
    label "E:LIMBS"
    kind "entity"
    name "LIMBS"
    community 20
  ]
  node [
    id 304
    label "U:Novel-25646_00012#1"
    kind "unit"
    chunk_id "Novel-25646_00012"
    text "The passage asks what makes limbs move, explaining that unlike a door which requires being held to move, the arm moves without needing to be held, implying that muscles are responsible for movement."
    community 20
  ]
  node [
    id 305
    label "E:LIMBS TO MOVE"
    kind "entity"
    name "LIMBS TO MOVE"
    community 20
  ]
  node [
    id 306
    label "C:Novel-25646_00013"
    kind "chunk"
    chunk_id "Novel-25646_00013"
  ]
  node [
    id 307
    label "U:Novel-25646_00013#0"
    kind "unit"
    chunk_id "Novel-25646_00013"
    text "A door or gate can be designed to shut itself when left open, using a wide rubber strap fastened to the door frame near the hinge and to the door near its edge. When the door is pushed open, the strap is stretched; after passing through, it tightens and pulls the door shut. This action is similar to how a muscle works in the arm: when the elbow is bent, a muscle contracts and pulls the joint, and when the arm is straightened, the muscle returns to its original shape. One end of this muscle is attached to the bone just below the elbow, and the other end is higher up above the joint. A second muscle on the outside of the arm stretches when the first one shortens, helping to move the joint smoothly."
    community 20
  ]
  node [
    id 308
    label "E:RUBBER STRAP"
    kind "entity"
    name "RUBBER STRAP"
    community 20
  ]
  node [
    id 309
    label "E:DOOR FRAME"
    kind "entity"
    name "DOOR FRAME"
    community 20
  ]
  node [
    id 310
    label "E:ELBOW JOINT"
    kind "entity"
    name "ELBOW JOINT"
    community 20
  ]
  node [
    id 311
    label "E:MUSCLE"
    kind "entity"
    name "MUSCLE"
    community 20
  ]
  node [
    id 312
    label "E:JOINT"
    kind "entity"
    name "JOINT"
    community 20
  ]
  node [
    id 313
    label "E:STRETCH"
    kind "entity"
    name "STRETCH"
    community 20
  ]
  node [
    id 314
    label "E:CONTRACT"
    kind "entity"
    name "CONTRACT"
    community 20
  ]
  node [
    id 315
    label "E:STRAIGHTEN"
    kind "entity"
    name "STRAIGHTEN"
    community 20
  ]
  node [
    id 316
    label "E:MUSCLE ON OUTSIDE OF ARM"
    kind "entity"
    name "MUSCLE ON OUTSIDE OF ARM"
    community 20
  ]
  node [
    id 317
    label "E:DOOR IS PUSHED OPEN"
    kind "entity"
    name "DOOR IS PUSHED OPEN"
    community 20
  ]
  node [
    id 318
    label "E:PERSON HAS PASSED THROUGH"
    kind "entity"
    name "PERSON HAS PASSED THROUGH"
    community 20
  ]
  node [
    id 319
    label "E:MUSCLE CONTRACTS"
    kind "entity"
    name "MUSCLE CONTRACTS"
    community 20
  ]
  node [
    id 320
    label "E:BONE JUST BELOW ELBOW"
    kind "entity"
    name "BONE JUST BELOW ELBOW"
    community 20
  ]
  node [
    id 321
    label "E:BONE ABOVE ELBOW JOINT"
    kind "entity"
    name "BONE ABOVE ELBOW JOINT"
    community 20
  ]
  node [
    id 322
    label "E:BEND THE JOINT"
    kind "entity"
    name "BEND THE JOINT"
    community 20
  ]
  node [
    id 323
    label "E:ARM IS STRAIGHTENED"
    kind "entity"
    name "ARM IS STRAIGHTENED"
    community 20
  ]
  node [
    id 324
    label "U:Novel-25646_00013#1"
    kind "unit"
    chunk_id "Novel-25646_00013"
    text "When the elbow joint is bent, the muscle contracts and pulls the joint, and when the arm is straightened, the muscle returns to its original shape. A second muscle on the outside of the arm stretches when the first muscle shortens, assisting in joint movement."
    community 20
  ]
  node [
    id 325
    label "E:RETURN TO ORIGINAL SHAPE"
    kind "entity"
    name "RETURN TO ORIGINAL SHAPE"
    community 20
  ]
  node [
    id 326
    label "E:JOINT MOVEMENT"
    kind "entity"
    name "JOINT MOVEMENT"
    community 20
  ]
  node [
    id 327
    label "C:Novel-25646_00014"
    kind "chunk"
    chunk_id "Novel-25646_00014"
  ]
  node [
    id 328
    label "U:Novel-25646_00014#0"
    kind "unit"
    chunk_id "Novel-25646_00014"
    text "Every joint is controlled by two or more muscles, and the number of muscles in the fingers is particularly large. Counting all the muscles in the human body would require more effort than some people could complete."
    community 6
  ]
  node [
    id 329
    label "U:Novel-25646_00014#1"
    kind "unit"
    chunk_id "Novel-25646_00014"
    text "Muscles on the dinner table appear as lean meat and are connected to bones by strong cords called tendons, which can be seen in the leg of a chicken or turkey. These tendons can hold meat tightly, making it difficult to remove."
    community 1
  ]
  node [
    id 330
    label "E:TENDONS"
    kind "entity"
    name "TENDONS"
    community 1
  ]
  node [
    id 331
    label "E:CHICKEN"
    kind "entity"
    name "CHICKEN"
    community 1
  ]
  node [
    id 332
    label "E:TURKEY"
    kind "entity"
    name "TURKEY"
    community 1
  ]
  node [
    id 333
    label "E:LEAN MEAT"
    kind "entity"
    name "LEAN MEAT"
    community 1
  ]
  node [
    id 334
    label "E:MEAT"
    kind "entity"
    name "MEAT"
    community 1
  ]
  node [
    id 335
    label "U:Novel-25646_00014#2"
    kind "unit"
    chunk_id "Novel-25646_00014"
    text "The muscles that move the wings of a swallow are attached to the breast, and these breast muscles must be large and strong because swallows do not walk but fly."
    community 6
  ]
  node [
    id 336
    label "E:SWALLOWS"
    kind "entity"
    name "SWALLOWS"
    community 6
  ]
  node [
    id 337
    label "E:WINGS"
    kind "entity"
    name "WINGS"
    community 6
  ]
  node [
    id 338
    label "E:BREAST"
    kind "entity"
    name "BREAST"
    community 6
  ]
  node [
    id 339
    label "E:FLYING"
    kind "entity"
    name "FLYING"
    community 6
  ]
  node [
    id 340
    label "C:Novel-25646_00015"
    kind "chunk"
    chunk_id "Novel-25646_00015"
  ]
  node [
    id 341
    label "U:Novel-25646_00015#0"
    kind "unit"
    chunk_id "Novel-25646_00015"
    text "The breast muscles of the swallow must be large and strong. Exercise of muscles makes them strong, as people who work hard with any body part develop strong muscles in that part."
    community 15
  ]
  node [
    id 342
    label "E:BREAST MUSCLES OF THE SWALLOW"
    kind "entity"
    name "BREAST MUSCLES OF THE SWALLOW"
    community 15
  ]
  node [
    id 343
    label "E:EXERCISE OF THE MUSCLES"
    kind "entity"
    name "EXERCISE OF THE MUSCLES"
    community 15
  ]
  node [
    id 344
    label "E:BODY PART"
    kind "entity"
    name "BODY PART"
    community 17
  ]
  node [
    id 345
    label "E:STRENGTH"
    kind "entity"
    name "STRENGTH"
    community 7
  ]
  node [
    id 346
    label "E:PEOPLE"
    kind "entity"
    name "PEOPLE"
    community 15
  ]
  node [
    id 347
    label "E:WORKING HARD WITH A BODY PART"
    kind "entity"
    name "WORKING HARD WITH A BODY PART"
    community 15
  ]
  node [
    id 348
    label "U:Novel-25646_00015#1"
    kind "unit"
    chunk_id "Novel-25646_00015"
    text "The blacksmith has big, strong muscles in his arms because he uses them frequently."
    community 6
  ]
  node [
    id 349
    label "E:BLACKSMITH"
    kind "entity"
    name "BLACKSMITH"
    community 6
  ]
  node [
    id 350
    label "E:USE"
    kind "entity"
    name "USE"
    community 6
  ]
  node [
    id 351
    label "U:Novel-25646_00015#2"
    kind "unit"
    chunk_id "Novel-25646_00015"
    text "People use their muscles every day, which helps them grow stronger."
    community 7
  ]
  node [
    id 352
    label "E:DAILY USE"
    kind "entity"
    name "DAILY USE"
    community 7
  ]
  node [
    id 353
    label "E:GROW"
    kind "entity"
    name "GROW"
    community 7
  ]
  node [
    id 354
    label "U:Novel-25646_00015#3"
    kind "unit"
    chunk_id "Novel-25646_00015"
    text "A little girl who had been very sick previously had strong muscles in her arms and legs and was active before her illness, but after the sickness she could hardly walk and preferred to sit and look at her playthings."
    community 6
  ]
  node [
    id 355
    label "E:LITTLE GIRL"
    kind "entity"
    name "LITTLE GIRL"
    community 6
  ]
  node [
    id 356
    label "E:SICKNESS"
    kind "entity"
    name "SICKNESS"
    community 6
  ]
  node [
    id 357
    label "E:RUNNING"
    kind "entity"
    name "RUNNING"
    community 0
  ]
  node [
    id 358
    label "E:CARRYING DOLL"
    kind "entity"
    name "CARRYING DOLL"
    community 6
  ]
  node [
    id 359
    label "E:SITTING"
    kind "entity"
    name "SITTING"
    community 6
  ]
  node [
    id 360
    label "E:PLAYING"
    kind "entity"
    name "PLAYING"
    community 6
  ]
  node [
    id 361
    label "U:Novel-25646_00015#4"
    kind "unit"
    chunk_id "Novel-25646_00015"
    text "After her sickness, the little girl had to make new muscles as fast as possible, and brisk activities like running, coasting, games of ball, and play help build strong muscles."
    community 6
  ]
  node [
    id 362
    label "E:NEW MUSCLES"
    kind "entity"
    name "NEW MUSCLES"
    community 6
  ]
  node [
    id 363
    label "E:COASTING"
    kind "entity"
    name "COASTING"
    community 6
  ]
  node [
    id 364
    label "E:GAMES OF BALL"
    kind "entity"
    name "GAMES OF BALL"
    community 6
  ]
  node [
    id 365
    label "E:BRISK PLAY"
    kind "entity"
    name "BRISK PLAY"
    community 6
  ]
  node [
    id 366
    label "E:MUSCLE GROWTH"
    kind "entity"
    name "MUSCLE GROWTH"
    community 6
  ]
  node [
    id 367
    label "E:BRISK PLAY AND WORK"
    kind "entity"
    name "BRISK PLAY AND WORK"
    community 6
  ]
  node [
    id 368
    label "U:Novel-25646_00015#5"
    kind "unit"
    chunk_id "Novel-25646_00015"
    text "Idle habits make weak muscles, so idleness is an enemy to muscle strength."
    community 6
  ]
  node [
    id 369
    label "E:IDLE HABITS"
    kind "entity"
    name "IDLE HABITS"
    community 6
  ]
  node [
    id 370
    label "E:IDLENESS"
    kind "entity"
    name "IDLENESS"
    community 6
  ]
  node [
    id 371
    label "E:WEAK MUSCLES"
    kind "entity"
    name "WEAK MUSCLES"
    community 6
  ]
  node [
    id 372
    label "U:Novel-25646_00015#6"
    kind "unit"
    chunk_id "Novel-25646_00015"
    text "Alcohol changes part of the muscles into fat, reducing their strength, because muscles are lean meat and fat meat cannot work joints as muscles do."
    community 7
  ]
  node [
    id 373
    label "E:FAT MEAT"
    kind "entity"
    name "FAT MEAT"
    community 7
  ]
  node [
    id 374
    label "E:JOINTS"
    kind "entity"
    name "JOINTS"
    community 7
  ]
  node [
    id 375
    label "E:FAT"
    kind "entity"
    name "FAT"
    community 7
  ]
  node [
    id 376
    label "E:TRUE"
    kind "entity"
    name "TRUE"
    community 7
  ]
  node [
    id 377
    label "C:Novel-25646_00016"
    kind "chunk"
    chunk_id "Novel-25646_00016"
  ]
  node [
    id 378
    label "U:Novel-25646_00016#0"
    kind "unit"
    chunk_id "Novel-25646_00016"
    text "Alcohol often changes muscle tissue to fat, reducing muscle strength, and people who drink beer regularly become fleshy because beer contains alcohol; however, such fatty muscles cannot work effectively and do not provide greater strength."
    community 7
  ]
  node [
    id 379
    label "E:BEER"
    kind "entity"
    name "BEER"
    community 5
  ]
  node [
    id 380
    label "E:MUSCLE STRENGTH"
    kind "entity"
    name "MUSCLE STRENGTH"
    community 7
  ]
  node [
    id 381
    label "E:PEOPLE WHO DRINK BEER"
    kind "entity"
    name "PEOPLE WHO DRINK BEER"
    community 7
  ]
  node [
    id 382
    label "E:FAT MUSCLES"
    kind "entity"
    name "FAT MUSCLES"
    community 7
  ]
  node [
    id 383
    label "U:Novel-25646_00016#1"
    kind "unit"
    chunk_id "Novel-25646_00016"
    text "Review questions include inquiries about joint movement, arm muscles that assist elbow motion, the necessity of muscles for joints, the muscles of lower animals, what attaches muscles to bones, and the reasons chickens and turkeys need strong leg muscles, swallows need strong breast muscles, blacksmiths' arm muscles are strong, and what makes or weakens muscles."
    community 6
  ]
  node [
    id 384
    label "E:REVIEW QUESTIONS"
    kind "entity"
    name "REVIEW QUESTIONS"
    community 3
  ]
  node [
    id 385
    label "E:LOWER ANIMALS"
    kind "entity"
    name "LOWER ANIMALS"
    community 6
  ]
  node [
    id 386
    label "E:CHICKENS"
    kind "entity"
    name "CHICKENS"
    community 6
  ]
  node [
    id 387
    label "E:TURKEYS"
    kind "entity"
    name "TURKEYS"
    community 6
  ]
  node [
    id 388
    label "E:ARM MUSCLES"
    kind "entity"
    name "ARM MUSCLES"
    community 6
  ]
  node [
    id 389
    label "E:CHICKENS AND TURKEYS"
    kind "entity"
    name "CHICKENS AND TURKEYS"
    community 6
  ]
  node [
    id 390
    label "E:EXERCISE"
    kind "entity"
    name "EXERCISE"
    community 16
  ]
  node [
    id 391
    label "U:Novel-25646_00016#2"
    kind "unit"
    chunk_id "Novel-25646_00016"
    text "Muscles know when to move through a system similar to telegraph wires, which send messages from one place to another, indicating that nerves transmit signals to muscles to control movement."
    community 4
  ]
  node [
    id 392
    label "E:NERVES"
    kind "entity"
    name "NERVES"
    community 4
  ]
  node [
    id 393
    label "E:TELEGRAPH WIRES"
    kind "entity"
    name "TELEGRAPH WIRES"
    community 4
  ]
  node [
    id 394
    label "E:MOVEMENT"
    kind "entity"
    name "MOVEMENT"
    community 4
  ]
  node [
    id 395
    label "C:Novel-25646_00017"
    kind "chunk"
    chunk_id "Novel-25646_00017"
  ]
  node [
    id 396
    label "U:Novel-25646_00017#0"
    kind "unit"
    chunk_id "Novel-25646_00017"
    text "Each person has a part inside them that sends messages almost every minute while awake, and the brain is the thinking part of the body, protected by a bony case, which is considered the most precious part of the body and is referred to as the central telegraph office."
    community 8
  ]
  node [
    id 397
    label "E:BRAIN"
    kind "entity"
    name "BRAIN"
    community -1
  ]
  node [
    id 398
    label "E:THINKING"
    kind "entity"
    name "THINKING"
    community 16
  ]
  node [
    id 399
    label "E:CENTRAL TELEGRAPH OFFICE"
    kind "entity"
    name "CENTRAL TELEGRAPH OFFICE"
    community 8
  ]
  node [
    id 400
    label "U:Novel-25646_00017#1"
    kind "unit"
    chunk_id "Novel-25646_00017"
    text "Nerves, which are white cords, connect the brain to the rest of the body, with the spinal cord being a large nerve that lies in a bony case formed by the spine and from which many nerves branch off."
    community 4
  ]
  node [
    id 401
    label "E:SPINAL CORD"
    kind "entity"
    name "SPINAL CORD"
    community 4
  ]
  node [
    id 402
    label "E:BRANCHES"
    kind "entity"
    name "BRANCHES"
    community 4
  ]
  node [
    id 403
    label "U:Novel-25646_00017#2"
    kind "unit"
    chunk_id "Novel-25646_00017"
    text "When a finger is placed on a hot stove, a message travels through the nerves to the brain, which receives the warning that the finger will burn, and then the brain sends a message back to the muscles to quickly contract, bend the joint, and remove the finger to prevent burning."
    community 8
  ]
  node [
    id 404
    label "E:FINGER"
    kind "entity"
    name "FINGER"
    community 8
  ]
  node [
    id 405
    label "E:HOT STOVE"
    kind "entity"
    name "HOT STOVE"
    community 8
  ]
  node [
    id 406
    label "E:NERVE"
    kind "entity"
    name "NERVE"
    community 8
  ]
  node [
    id 407
    label "E:BEND"
    kind "entity"
    name "BEND"
    community 8
  ]
  node [
    id 408
    label "E:REMOVE"
    kind "entity"
    name "REMOVE"
    community 8
  ]
  node [
    id 409
    label "E:BURN"
    kind "entity"
    name "BURN"
    community 8
  ]
  node [
    id 410
    label "E:FINGER WILL BURN"
    kind "entity"
    name "FINGER WILL BURN"
    community 8
  ]
  node [
    id 411
    label "E:STAYS ON HOT STOVE"
    kind "entity"
    name "STAYS ON HOT STOVE"
    community 8
  ]
  node [
    id 412
    label "C:Novel-25646_00018"
    kind "chunk"
    chunk_id "Novel-25646_00018"
  ]
  node [
    id 413
    label "U:Novel-25646_00018#0"
    kind "unit"
    chunk_id "Novel-25646_00018"
    text "You cannot believe there was time to send all messages because as soon as you felt the hot stove, you pulled your finger away, but you could not have done so unless the brain sent a signal to the muscles."
    community 8
  ]
  node [
    id 414
    label "U:Novel-25646_00018#1"
    kind "unit"
    chunk_id "Novel-25646_00018"
    text "The brain has a great deal of work to do because it sends many orders, and the phrase 'as quick as thought' means nothing could be quicker."
    community 0
  ]
  node [
    id 415
    label "E:THOUGHT"
    kind "entity"
    name "THOUGHT"
    community 0
  ]
  node [
    id 416
    label "E:ORDERS"
    kind "entity"
    name "ORDERS"
    community 0
  ]
  node [
    id 417
    label "E:QUICKNESS"
    kind "entity"
    name "QUICKNESS"
    community 0
  ]
  node [
    id 418
    label "U:Novel-25646_00018#2"
    kind "unit"
    chunk_id "Novel-25646_00018"
    text "Some muscles move quietly and steadily all the time, and breathing is one such process; you do not have to think about breathing, yet the muscles work continuously by moving the chest."
    community 0
  ]
  node [
    id 419
    label "E:CHEST"
    kind "entity"
    name "CHEST"
    community 0
  ]
  node [
    id 420
    label "E:ALL THE TIME"
    kind "entity"
    name "ALL THE TIME"
    community 0
  ]
  node [
    id 421
    label "U:Novel-25646_00018#3"
    kind "unit"
    chunk_id "Novel-25646_00018"
    text "One part of the brain takes care of breathing by sending messages to the breathing muscles and keeping them and other muscles working faithfully without requiring conscious thought."
    community 0
  ]
  node [
    id 422
    label "E:BREATHING MUSCLES"
    kind "entity"
    name "BREATHING MUSCLES"
    community 0
  ]
  node [
    id 423
    label "E:MESSAGES"
    kind "entity"
    name "MESSAGES"
    community 0
  ]
  node [
    id 424
    label "U:Novel-25646_00018#4"
    kind "unit"
    chunk_id "Novel-25646_00018"
    text "The body is a busy workshop where many kinds of work are being done continuously throughout the day and night."
    community 9
  ]
  node [
    id 425
    label "E:WORKSHOP"
    kind "entity"
    name "WORKSHOP"
    community 9
  ]
  node [
    id 426
    label "E:MANY KINDS OF WORK"
    kind "entity"
    name "MANY KINDS OF WORK"
    community 9
  ]
  node [
    id 427
    label "C:Novel-25646_00019"
    kind "chunk"
    chunk_id "Novel-25646_00019"
  ]
  node [
    id 428
    label "U:Novel-25646_00019#0"
    kind "unit"
    chunk_id "Novel-25646_00019"
    text "Although the body lies still and sleeps at night, breathing and the work of other organs continue until death. Nerves consist of small white threads lying side by side to form white cords, with each type of message traveling on its own thread to prevent mixing or confusion. These nerves are delicate messengers that carry all sensations throughout the body, enabling both pain and pleasure. Without nerves in the tooth, it could not ache; without nerves in the mouth and tongue, one could not taste food; without nerves in the hands, one might cut them and feel no pain; but one could not feel the soft, warm hand of one's mother when it is placed on their own hand."
    community 4
  ]
  node [
    id 429
    label "E:ORGANS"
    kind "entity"
    name "ORGANS"
    community 4
  ]
  node [
    id 430
    label "E:TOOTH"
    kind "entity"
    name "TOOTH"
    community 4
  ]
  node [
    id 431
    label "E:MOUTH"
    kind "entity"
    name "MOUTH"
    community 16
  ]
  node [
    id 432
    label "E:TONGUE"
    kind "entity"
    name "TONGUE"
    community 4
  ]
  node [
    id 433
    label "E:HAND"
    kind "entity"
    name "HAND"
    community 4
  ]
  node [
    id 434
    label "E:PAIN"
    kind "entity"
    name "PAIN"
    community 4
  ]
  node [
    id 435
    label "E:PLEASURE"
    kind "entity"
    name "PLEASURE"
    community 4
  ]
  node [
    id 436
    label "E:FEELING"
    kind "entity"
    name "FEELING"
    community 4
  ]
  node [
    id 437
    label "E:MOTHER"
    kind "entity"
    name "MOTHER"
    community 4
  ]
  node [
    id 438
    label "E:SMALL WHITE THREADS"
    kind "entity"
    name "SMALL WHITE THREADS"
    community 4
  ]
  node [
    id 439
    label "E:WHITE CORDS"
    kind "entity"
    name "WHITE CORDS"
    community 4
  ]
  node [
    id 440
    label "E:EACH KIND OF MESSAGE"
    kind "entity"
    name "EACH KIND OF MESSAGE"
    community 4
  ]
  node [
    id 441
    label "E:ITS OWN THREAD"
    kind "entity"
    name "ITS OWN THREAD"
    community 4
  ]
  node [
    id 442
    label "E:ALL SENSATIONS"
    kind "entity"
    name "ALL SENSATIONS"
    community 4
  ]
  node [
    id 443
    label "U:Novel-25646_00019#1"
    kind "unit"
    chunk_id "Novel-25646_00019"
    text "One of the first duties of a person is self-care. Children may say their parents take care of them, but even as young individuals, there are some ways in which only they themselves can take care of themselves. As people grow older, the responsibility for self-care increases and becomes their own, not someone else's."
    community 12
  ]
  node [
    id 444
    label "E:SELF-CARE"
    kind "entity"
    name "SELF-CARE"
    community 12
  ]
  node [
    id 445
    label "E:PARENTS"
    kind "entity"
    name "PARENTS"
    community 12
  ]
  node [
    id 446
    label "E:OLDER PERSONS"
    kind "entity"
    name "OLDER PERSONS"
    community 12
  ]
  node [
    id 447
    label "E:DUTY"
    kind "entity"
    name "DUTY"
    community 12
  ]
  node [
    id 448
    label "E:THEM"
    kind "entity"
    name "THEM"
    community 12
  ]
  node [
    id 449
    label "U:Novel-25646_00019#2"
    kind "unit"
    chunk_id "Novel-25646_00019"
    text "The various parts of the body perform work that helps us to be well and happy."
    community 9
  ]
  node [
    id 450
    label "E:BODY PARTS"
    kind "entity"
    name "BODY PARTS"
    community 9
  ]
  node [
    id 451
    label "E:BEING WELL"
    kind "entity"
    name "BEING WELL"
    community 9
  ]
  node [
    id 452
    label "E:BEING HAPPY"
    kind "entity"
    name "BEING HAPPY"
    community 9
  ]
  node [
    id 453
    label "E:BEING WELL AND HAPPY"
    kind "entity"
    name "BEING WELL AND HAPPY"
    community 9
  ]
  node [
    id 454
    label "C:Novel-25646_00020"
    kind "chunk"
    chunk_id "Novel-25646_00020"
  ]
  node [
    id 455
    label "U:Novel-25646_00020#0"
    kind "unit"
    chunk_id "Novel-25646_00020"
    text "The body's parts, including the brain and nerves, help us be well and happy, and it is important to take care of them and keep them in good order. The brain has two parts: one that continuously monitors and keeps all organs working, which cannot go to sleep, and another that handles thinking, which needs rest. If the thinking part of the brain does not get good quiet sleep, it will wear out and be hard to repair. A well-cared-for brain can function effectively for seventy or eighty years. Nerves are easily tired and need rest; they get tired from doing one thing too long and are rested by changing work."
    community 4
  ]
  node [
    id 456
    label "E:THINKING PART OF THE BRAIN"
    kind "entity"
    name "THINKING PART OF THE BRAIN"
    community 4
  ]
  node [
    id 457
    label "E:SLEEP"
    kind "entity"
    name "SLEEP"
    community 0
  ]
  node [
    id 458
    label "E:REST"
    kind "entity"
    name "REST"
    community 4
  ]
  node [
    id 459
    label "E:SEVENTY OR EIGHTY YEARS"
    kind "entity"
    name "SEVENTY OR EIGHTY YEARS"
    community 4
  ]
  node [
    id 460
    label "E:GOOD QUIET SLEEP"
    kind "entity"
    name "GOOD QUIET SLEEP"
    community 4
  ]
  node [
    id 461
    label "E:LACKS GOOD QUIET SLEEP"
    kind "entity"
    name "LACKS GOOD QUIET SLEEP"
    community 4
  ]
  node [
    id 462
    label "E:WORN-OUT BRAIN"
    kind "entity"
    name "WORN-OUT BRAIN"
    community 4
  ]
  node [
    id 463
    label "E:AFTER LONG USE"
    kind "entity"
    name "AFTER LONG USE"
    community 4
  ]
  node [
    id 464
    label "E:ITSELF"
    kind "entity"
    name "ITSELF"
    community 4
  ]
  node [
    id 465
    label "E:DOING ONE THING TOO LONG"
    kind "entity"
    name "DOING ONE THING TOO LONG"
    community 4
  ]
  node [
    id 466
    label "E:CHANGE OF WORK"
    kind "entity"
    name "CHANGE OF WORK"
    community 4
  ]
  node [
    id 467
    label "U:Novel-25646_00020#1"
    kind "unit"
    chunk_id "Novel-25646_00020"
    text "Alcohol is questioned as to whether it is good for the nerves and the brain, as the passage raises the question but does not provide a direct answer."
    community 4
  ]
  node [
    id 468
    label "C:Novel-25646_00021"
    kind "chunk"
    chunk_id "Novel-25646_00021"
  ]
  node [
    id 469
    label "U:Novel-25646_00021#0"
    kind "unit"
    chunk_id "Novel-25646_00021"
    text "The brain continuously performs important work for the body and requires proper nutrition to function well; alcohol-containing drinks are not suitable food and act as poisons that harm the brain and nerves, impairing their ability to send messages properly."
    community 0
  ]
  node [
    id 470
    label "E:FOOD"
    kind "entity"
    name "FOOD"
    community -1
  ]
  node [
    id 471
    label "E:POISON"
    kind "entity"
    name "POISON"
    community 23
  ]
  node [
    id 472
    label "E:NEURONS"
    kind "entity"
    name "NEURONS"
    community 0
  ]
  node [
    id 473
    label "U:Novel-25646_00021#1"
    kind "unit"
    chunk_id "Novel-25646_00021"
    text "Alcohol causes people to become careless and fail to perform their duties faithfully; when nerves are affected, individuals may not distinguish between a railroad track and a safe area, leading to dangerous actions such as setting houses on fire, forgetting to turn off switches and wrecking trains, or lying down on tracks and being run over."
    community 5
  ]
  node [
    id 474
    label "E:DRUNKARD"
    kind "entity"
    name "DRUNKARD"
    community 5
  ]
  node [
    id 475
    label "E:HOUSES ON FIRE"
    kind "entity"
    name "HOUSES ON FIRE"
    community 5
  ]
  node [
    id 476
    label "E:SWITCH"
    kind "entity"
    name "SWITCH"
    community 5
  ]
  node [
    id 477
    label "E:RAILROAD TRAIN"
    kind "entity"
    name "RAILROAD TRAIN"
    community 5
  ]
  node [
    id 478
    label "E:RAILROAD TRACK"
    kind "entity"
    name "RAILROAD TRACK"
    community 5
  ]
  node [
    id 479
    label "E:CAR"
    kind "entity"
    name "CAR"
    community 5
  ]
  node [
    id 480
    label "E:CARELESSNESS"
    kind "entity"
    name "CARELESSNESS"
    community 5
  ]
  node [
    id 481
    label "E:FAILURE TO PERFORM WORK"
    kind "entity"
    name "FAILURE TO PERFORM WORK"
    community 5
  ]
  node [
    id 482
    label "E:MISRECOGNITION"
    kind "entity"
    name "MISRECOGNITION"
    community 5
  ]
  node [
    id 483
    label "E:LYING DOWN ON RAILROAD TRACK"
    kind "entity"
    name "LYING DOWN ON RAILROAD TRACK"
    community 5
  ]
  node [
    id 484
    label "E:FORGETTING TO TURN OFF SWITCH"
    kind "entity"
    name "FORGETTING TO TURN OFF SWITCH"
    community 5
  ]
  node [
    id 485
    label "E:SETTING HOUSES ON FIRE"
    kind "entity"
    name "SETTING HOUSES ON FIRE"
    community 5
  ]
  node [
    id 486
    label "E:WRECKING A RAILROAD TRAIN"
    kind "entity"
    name "WRECKING A RAILROAD TRAIN"
    community 5
  ]
  node [
    id 487
    label "U:Novel-25646_00021#2"
    kind "unit"
    chunk_id "Novel-25646_00021"
    text "Even small amounts of alcohol cause headaches and harm the brain and nerves."
    community 0
  ]
  node [
    id 488
    label "E:HEADACHE"
    kind "entity"
    name "HEADACHE"
    community 0
  ]
  node [
    id 489
    label "C:Novel-25646_00022"
    kind "chunk"
    chunk_id "Novel-25646_00022"
  ]
  node [
    id 490
    label "U:Novel-25646_00022#0"
    kind "unit"
    chunk_id "Novel-25646_00022"
    text "Even a small amount of alcohol causes headaches, harms the brain and nerves, and leads to bodily poisoning. A body kept pure and strong is beneficial to its owner. Some people who are not drunkards still drink a little liquor, which slowly poisons their bodies. When sick, they are less able to endure illness and less likely to recover than those who have never consumed alcohol. When a sick or wounded man is admitted to the hospital, doctors first ask if he drinks; if he answers yes, they ask what he drinks and how much, and these answers indicate his chances of recovery. A man who never drinks liquor will recover, while a drinking man would surely die."
    community 22
  ]
  node [
    id 491
    label "E:POISONING"
    kind "entity"
    name "POISONING"
    community 22
  ]
  node [
    id 492
    label "E:RECOVERY"
    kind "entity"
    name "RECOVERY"
    community 22
  ]
  node [
    id 493
    label "E:HOSPITAL"
    kind "entity"
    name "HOSPITAL"
    community 22
  ]
  node [
    id 494
    label "E:DOCTOR"
    kind "entity"
    name "DOCTOR"
    community 22
  ]
  node [
    id 495
    label "E:DRINKING"
    kind "entity"
    name "DRINKING"
    community 2
  ]
  node [
    id 496
    label "E:WOUNDED MAN"
    kind "entity"
    name "WOUNDED MAN"
    community 22
  ]
  node [
    id 497
    label "E:ANSWERS"
    kind "entity"
    name "ANSWERS"
    community 22
  ]
  node [
    id 498
    label "E:CHANCES OF GETTING WELL"
    kind "entity"
    name "CHANCES OF GETTING WELL"
    community 22
  ]
  node [
    id 499
    label "E:ITS OWNER"
    kind "entity"
    name "ITS OWNER"
    community 22
  ]
  node [
    id 500
    label "E:PEOPLE WHO ARE NOT DRUNKARDS"
    kind "entity"
    name "PEOPLE WHO ARE NOT DRUNKARDS"
    community 22
  ]
  node [
    id 501
    label "E:LITTLE LIQUOR"
    kind "entity"
    name "LITTLE LIQUOR"
    community 22
  ]
  node [
    id 502
    label "E:THEY"
    kind "entity"
    name "THEY"
    community 6
  ]
  node [
    id 503
    label "E:SICK OR WOUNDED MAN"
    kind "entity"
    name "SICK OR WOUNDED MAN"
    community 22
  ]
  node [
    id 504
    label "E:MAN WHO NEVER DRINKS LIQUOR"
    kind "entity"
    name "MAN WHO NEVER DRINKS LIQUOR"
    community 22
  ]
  node [
    id 505
    label "E:WHERE A DRINKING MAN WOULD SURELY DIE"
    kind "entity"
    name "WHERE A DRINKING MAN WOULD SURELY DIE"
    community 22
  ]
  node [
    id 506
    label "U:Novel-25646_00022#1"
    kind "unit"
    chunk_id "Novel-25646_00022"
    text "Tobacco is used by some men because they believe it helps them and makes them feel better. When a man is cold, tobacco deadens his nerves, so he does not feel the cold and does not take action to warm himself."
    community 16
  ]
  node [
    id 507
    label "E:FEELING BETTER"
    kind "entity"
    name "FEELING BETTER"
    community 16
  ]
  node [
    id 508
    label "E:COLD"
    kind "entity"
    name "COLD"
    community 16
  ]
  node [
    id 509
    label "E:FEELING THE COLD"
    kind "entity"
    name "FEELING THE COLD"
    community 16
  ]
  node [
    id 510
    label "E:WARMING HIMSELF"
    kind "entity"
    name "WARMING HIMSELF"
    community 16
  ]
  node [
    id 511
    label "E:MAN WHO IS COLD"
    kind "entity"
    name "MAN WHO IS COLD"
    community 16
  ]
  node [
    id 512
    label "E:WARM HIMSELF"
    kind "entity"
    name "WARM HIMSELF"
    community 16
  ]
  node [
    id 513
    label "C:Novel-25646_00023"
    kind "chunk"
    chunk_id "Novel-25646_00023"
  ]
  node [
    id 514
    label "U:Novel-25646_00023#0"
    kind "unit"
    chunk_id "Novel-25646_00023"
    text "Tobacco does not truly rest a tired or troubled man; instead, it puts his nerves to sleep, making him think he is not tired and that he does not need to face his troubles, similar to how alcohol affects the body. It leads to a false sense of contentment with things that should not content him."
    community 4
  ]
  node [
    id 515
    label "E:TROUBLE"
    kind "entity"
    name "TROUBLE"
    community 4
  ]
  node [
    id 516
    label "E:TIREDNESS"
    kind "entity"
    name "TIREDNESS"
    community 4
  ]
  node [
    id 517
    label "E:CONTENTMENT"
    kind "entity"
    name "CONTENTMENT"
    community 4
  ]
  node [
    id 518
    label "U:Novel-25646_00023#1"
    kind "unit"
    chunk_id "Novel-25646_00023"
    text "A boy who smokes or chews tobacco is not as good a scholar as one who does not use tobacco; he remembers lessons less well and is generally less polite and less good-natured than he otherwise would be."
    community 21
  ]
  node [
    id 519
    label "E:LESSONS"
    kind "entity"
    name "LESSONS"
    community 21
  ]
  node [
    id 520
    label "E:POLITE"
    kind "entity"
    name "POLITE"
    community 21
  ]
  node [
    id 521
    label "E:GOOD BOY"
    kind "entity"
    name "GOOD BOY"
    community 21
  ]
  node [
    id 522
    label "E:BOY WHO DOES NOT USE TOBACCO"
    kind "entity"
    name "BOY WHO DOES NOT USE TOBACCO"
    community 21
  ]
  node [
    id 523
    label "E:BOY WHO USES TOBACCO"
    kind "entity"
    name "BOY WHO USES TOBACCO"
    community 21
  ]
  node [
    id 524
    label "C:Novel-25646_00024"
    kind "chunk"
    chunk_id "Novel-25646_00024"
  ]
  node [
    id 525
    label "U:Novel-25646_00024#0"
    kind "unit"
    chunk_id "Novel-25646_00024"
    text "The nerves give us pain through stimuli such as injury, heat, cold, pressure, and inflammation."
    community 4
  ]
  node [
    id 526
    label "E:INJURY"
    kind "entity"
    name "INJURY"
    community 4
  ]
  node [
    id 527
    label "E:HEAT"
    kind "entity"
    name "HEAT"
    community 10
  ]
  node [
    id 528
    label "E:PRESSURE"
    kind "entity"
    name "PRESSURE"
    community 4
  ]
  node [
    id 529
    label "E:INFLAMMATION"
    kind "entity"
    name "INFLAMMATION"
    community 12
  ]
  node [
    id 530
    label "U:Novel-25646_00024#1"
    kind "unit"
    chunk_id "Novel-25646_00024"
    text "The nerves give us pleasure through stimuli such as touch, warmth, sweet tastes, and pleasant smells."
    community 4
  ]
  node [
    id 531
    label "E:TOUCH"
    kind "entity"
    name "TOUCH"
    community 4
  ]
  node [
    id 532
    label "E:WARMTH"
    kind "entity"
    name "WARMTH"
    community 16
  ]
  node [
    id 533
    label "E:SWEET TASTES"
    kind "entity"
    name "SWEET TASTES"
    community 4
  ]
  node [
    id 534
    label "E:PLEASANT SMELLS"
    kind "entity"
    name "PLEASANT SMELLS"
    community 4
  ]
  node [
    id 535
    label "U:Novel-25646_00024#2"
    kind "unit"
    chunk_id "Novel-25646_00024"
    text "The brain has the most work to do among the body's parts because it processes information, controls movements, and manages thoughts and emotions."
    community 9
  ]
  node [
    id 536
    label "E:MOST WORK"
    kind "entity"
    name "MOST WORK"
    community 9
  ]
  node [
    id 537
    label "E:PROCESSING INFORMATION"
    kind "entity"
    name "PROCESSING INFORMATION"
    community 9
  ]
  node [
    id 538
    label "E:CONTROL MOVEMENTS"
    kind "entity"
    name "CONTROL MOVEMENTS"
    community 9
  ]
  node [
    id 539
    label "E:MANAGE THOUGHTS AND EMOTIONS"
    kind "entity"
    name "MANAGE THOUGHTS AND EMOTIONS"
    community 9
  ]
  node [
    id 540
    label "E:INFORMATION"
    kind "entity"
    name "INFORMATION"
    community 9
  ]
  node [
    id 541
    label "E:MOVEMENTS"
    kind "entity"
    name "MOVEMENTS"
    community 9
  ]
  node [
    id 542
    label "E:THOUGHTS AND EMOTIONS"
    kind "entity"
    name "THOUGHTS AND EMOTIONS"
    community 9
  ]
  node [
    id 543
    label "U:Novel-25646_00024#3"
    kind "unit"
    chunk_id "Novel-25646_00024"
    text "We must keep the brain strong and well by getting enough sleep, eating a balanced diet, exercising regularly, and avoiding harmful substances like alcohol and tobacco."
    community 19
  ]
  node [
    id 544
    label "E:BALANCED DIET"
    kind "entity"
    name "BALANCED DIET"
    community 19
  ]
  node [
    id 545
    label "E:HARMFUL SUBSTANCES"
    kind "entity"
    name "HARMFUL SUBSTANCES"
    community 19
  ]
  node [
    id 546
    label "U:Novel-25646_00024#4"
    kind "unit"
    chunk_id "Novel-25646_00024"
    text "Alcohol damages the nerves and brain by impairing nerve function, reducing brain activity, and disrupting communication between nerve cells."
    community 4
  ]
  node [
    id 547
    label "E:IMPAIRS NERVE FUNCTION"
    kind "entity"
    name "IMPAIRS NERVE FUNCTION"
    community 4
  ]
  node [
    id 548
    label "E:REDUCES BRAIN ACTIVITY"
    kind "entity"
    name "REDUCES BRAIN ACTIVITY"
    community 4
  ]
  node [
    id 549
    label "E:DISRUPTS COMMUNICATION"
    kind "entity"
    name "DISRUPTS COMMUNICATION"
    community 4
  ]
  node [
    id 550
    label "E:NERVE FUNCTION"
    kind "entity"
    name "NERVE FUNCTION"
    community 1
  ]
  node [
    id 551
    label "E:BRAIN ACTIVITY"
    kind "entity"
    name "BRAIN ACTIVITY"
    community 4
  ]
  node [
    id 552
    label "E:COMMUNICATION BETWEEN NERVE CELLS"
    kind "entity"
    name "COMMUNICATION BETWEEN NERVE CELLS"
    community 4
  ]
  node [
    id 553
    label "U:Novel-25646_00024#5"
    kind "unit"
    chunk_id "Novel-25646_00024"
    text "A drunken man does not know what he is about because alcohol impairs his brain's ability to process information and make decisions."
    community 9
  ]
  node [
    id 554
    label "E:DRUNKEN MAN"
    kind "entity"
    name "DRUNKEN MAN"
    community 9
  ]
  node [
    id 555
    label "E:PROCESS INFORMATION"
    kind "entity"
    name "PROCESS INFORMATION"
    community 9
  ]
  node [
    id 556
    label "E:MAKE DECISIONS"
    kind "entity"
    name "MAKE DECISIONS"
    community 9
  ]
  node [
    id 557
    label "E:DECISIONS"
    kind "entity"
    name "DECISIONS"
    community 9
  ]
  node [
    id 558
    label "U:Novel-25646_00024#6"
    kind "unit"
    chunk_id "Novel-25646_00024"
    text "Most of the accidents we read of are caused by alcohol consumption, which impairs judgment and coordination."
    community 5
  ]
  node [
    id 559
    label "E:ACCIDENTS"
    kind "entity"
    name "ACCIDENTS"
    community 5
  ]
  node [
    id 560
    label "E:JUDGMENT"
    kind "entity"
    name "JUDGMENT"
    community 5
  ]
  node [
    id 561
    label "E:COORDINATION"
    kind "entity"
    name "COORDINATION"
    community 5
  ]
  node [
    id 562
    label "U:Novel-25646_00024#7"
    kind "unit"
    chunk_id "Novel-25646_00024"
    text "A man who had been drinking could not tell the difference between a railroad track and a place of safety because alcohol impairs his brain's ability to process visual information and make correct judgments."
    community 5
  ]
  node [
    id 563
    label "E:PLACE OF SAFETY"
    kind "entity"
    name "PLACE OF SAFETY"
    community 5
  ]
  node [
    id 564
    label "E:VISUAL INFORMATION"
    kind "entity"
    name "VISUAL INFORMATION"
    community 5
  ]
  node [
    id 565
    label "U:Novel-25646_00024#8"
    kind "unit"
    chunk_id "Novel-25646_00024"
    text "Frequent drinking of a little liquor affects the body by slowly damaging the nerves and brain, reducing their efficiency over time."
    community 22
  ]
  node [
    id 566
    label "E:FREQUENT DRINKING"
    kind "entity"
    name "FREQUENT DRINKING"
    community 22
  ]
  node [
    id 567
    label "E:REDUCES EFFICIENCY"
    kind "entity"
    name "REDUCES EFFICIENCY"
    community 22
  ]
  node [
    id 568
    label "E:EFFICIENCY"
    kind "entity"
    name "EFFICIENCY"
    community 22
  ]
  node [
    id 569
    label "U:Novel-25646_00024#9"
    kind "unit"
    chunk_id "Novel-25646_00024"
    text "Sickness affects people who often drink liquors by weakening their bodies and making it harder for the brain and nerves to function properly."
    community 6
  ]
  node [
    id 570
    label "E:FUNCTION PROPERLY"
    kind "entity"
    name "FUNCTION PROPERLY"
    community 6
  ]
  node [
    id 571
    label "U:Novel-25646_00024#10"
    kind "unit"
    chunk_id "Novel-25646_00024"
    text "When a man is taken to the hospital, the doctor asks questions about his symptoms, medical history, medications, and lifestyle habits."
    community 22
  ]
  node [
    id 572
    label "E:SYMPTOMS"
    kind "entity"
    name "SYMPTOMS"
    community 22
  ]
  node [
    id 573
    label "E:MEDICAL HISTORY"
    kind "entity"
    name "MEDICAL HISTORY"
    community 22
  ]
  node [
    id 574
    label "E:MEDICATIONS"
    kind "entity"
    name "MEDICATIONS"
    community 22
  ]
  node [
    id 575
    label "E:LIFESTYLE HABITS"
    kind "entity"
    name "LIFESTYLE HABITS"
    community 22
  ]
  node [
    id 576
    label "U:Novel-25646_00024#11"
    kind "unit"
    chunk_id "Novel-25646_00024"
    text "The diagnosis and treatment plan depend upon the man's answers to the doctor's questions."
    community 22
  ]
  node [
    id 577
    label "E:DIAGNOSIS"
    kind "entity"
    name "DIAGNOSIS"
    community 22
  ]
  node [
    id 578
    label "E:TREATMENT PLAN"
    kind "entity"
    name "TREATMENT PLAN"
    community 22
  ]
  node [
    id 579
    label "E:MAN'S ANSWERS"
    kind "entity"
    name "MAN'S ANSWERS"
    community 22
  ]
  node [
    id 580
    label "U:Novel-25646_00024#12"
    kind "unit"
    chunk_id "Novel-25646_00024"
    text "Many men use tobacco because they believe it helps them feel better and relaxes them."
    community 4
  ]
  node [
    id 581
    label "E:FEEL BETTER"
    kind "entity"
    name "FEEL BETTER"
    community 4
  ]
  node [
    id 582
    label "E:RELAX"
    kind "entity"
    name "RELAX"
    community 4
  ]
  node [
    id 583
    label "E:BETTER"
    kind "entity"
    name "BETTER"
    community 4
  ]
  node [
    id 584
    label "U:Novel-25646_00024#13"
    kind "unit"
    chunk_id "Novel-25646_00024"
    text "Tobacco makes people feel better by stimulating the release of certain chemicals in the brain that produce a sense of calm or relaxation."
    community 4
  ]
  node [
    id 585
    label "E:CHEMICALS"
    kind "entity"
    name "CHEMICALS"
    community 4
  ]
  node [
    id 586
    label "E:SENSE OF CALM"
    kind "entity"
    name "SENSE OF CALM"
    community 4
  ]
  node [
    id 587
    label "E:RELAXATION"
    kind "entity"
    name "RELAXATION"
    community 4
  ]
  node [
    id 588
    label "U:Novel-25646_00024#14"
    kind "unit"
    chunk_id "Novel-25646_00024"
    text "Tobacco does not really help a person who uses it because it can lead to health problems and addiction."
    community 0
  ]
  node [
    id 589
    label "E:HEALTH PROBLEMS"
    kind "entity"
    name "HEALTH PROBLEMS"
    community 0
  ]
  node [
    id 590
    label "E:ADDICTION"
    kind "entity"
    name "ADDICTION"
    community 0
  ]
  node [
    id 591
    label "E:REALLY HELPS"
    kind "entity"
    name "REALLY HELPS"
    community 0
  ]
  node [
    id 592
    label "E:PERSON"
    kind "entity"
    name "PERSON"
    community 0
  ]
  node [
    id 593
    label "U:Novel-25646_00024#15"
    kind "unit"
    chunk_id "Novel-25646_00024"
    text "Tobacco does not help a boy to be a good scholar because it affects his concentration and manners."
    community 21
  ]
  node [
    id 594
    label "E:GOOD SCHOLAR"
    kind "entity"
    name "GOOD SCHOLAR"
    community 21
  ]
  node [
    id 595
    label "E:CONCENTRATION"
    kind "entity"
    name "CONCENTRATION"
    community 21
  ]
  node [
    id 596
    label "E:MANNERS"
    kind "entity"
    name "MANNERS"
    community 21
  ]
  node [
    id 597
    label "E:BOY TO BE A GOOD SCHOLAR"
    kind "entity"
    name "BOY TO BE A GOOD SCHOLAR"
    community 21
  ]
  node [
    id 598
    label "U:Novel-25646_00024#16"
    kind "unit"
    chunk_id "Novel-25646_00024"
    text "Ripe grapes are full of juice, mostly water, sweetened with a sugar of its own."
    community 15
  ]
  node [
    id 599
    label "E:RIPE GRAPE"
    kind "entity"
    name "RIPE GRAPE"
    community 15
  ]
  node [
    id 600
    label "E:JUICE"
    kind "entity"
    name "JUICE"
    community 15
  ]
  node [
    id 601
    label "E:WATER"
    kind "entity"
    name "WATER"
    community 2
  ]
  node [
    id 602
    label "E:SUGAR"
    kind "entity"
    name "SUGAR"
    community -1
  ]
  node [
    id 603
    label "E:ITS OWN"
    kind "entity"
    name "ITS OWN"
    community 15
  ]
  node [
    id 604
    label "C:Novel-25646_00025"
    kind "chunk"
    chunk_id "Novel-25646_00025"
  ]
  node [
    id 605
    label "U:Novel-25646_00025#0"
    kind "unit"
    chunk_id "Novel-25646_00025"
    text "This juice is mostly water, sweetened with a sugar of its own, and flavored in a way that makes it immediately identifiable as grape-juice when tasted, distinguishing it from cherry-juice or plum-juice. Apples contain water, sugar, and apple flavor, while cherries contain water, sugar, and cherry flavor. The same pattern applies to other fruits: when ripe, they all contain water and sugar, and each has a unique flavor."
    community 2
  ]
  node [
    id 606
    label "E:THIS JUICE"
    kind "entity"
    name "THIS JUICE"
    community 2
  ]
  node [
    id 607
    label "E:GRAPE-JUICE"
    kind "entity"
    name "GRAPE-JUICE"
    community 2
  ]
  node [
    id 608
    label "E:CHERRY-JUICE"
    kind "entity"
    name "CHERRY-JUICE"
    community 2
  ]
  node [
    id 609
    label "E:PLUM-JUICE"
    kind "entity"
    name "PLUM-JUICE"
    community 2
  ]
  node [
    id 610
    label "E:APPLES"
    kind "entity"
    name "APPLES"
    community 2
  ]
  node [
    id 611
    label "E:APPLE FLAVOR"
    kind "entity"
    name "APPLE FLAVOR"
    community 2
  ]
  node [
    id 612
    label "E:CHERRIES"
    kind "entity"
    name "CHERRIES"
    community 2
  ]
  node [
    id 613
    label "E:CHERRY FLAVOR"
    kind "entity"
    name "CHERRY FLAVOR"
    community 2
  ]
  node [
    id 614
    label "E:OTHER FRUITS"
    kind "entity"
    name "OTHER FRUITS"
    community 2
  ]
  node [
    id 615
    label "E:RIPE FRUITS"
    kind "entity"
    name "RIPE FRUITS"
    community 2
  ]
  node [
    id 616
    label "E:FLAVOR OF THEIR OWN"
    kind "entity"
    name "FLAVOR OF THEIR OWN"
    community 2
  ]
  node [
    id 617
    label "U:Novel-25646_00025#1"
    kind "unit"
    chunk_id "Novel-25646_00025"
    text "Ripe grapes are gathered and placed into large tubs called vats, where the juice is squeezed out. In some countries, bare-footed men jump into the vats and press the grapes with their feet. After squeezing, the grape-juice is separated from the skins and seeds and left in a warm place, where bubbles begin to rise and form froth on the surface, indicating that the juice is in motion."
    community 15
  ]
  node [
    id 618
    label "E:RIPE GRAPES"
    kind "entity"
    name "RIPE GRAPES"
    community 15
  ]
  node [
    id 619
    label "E:VATS"
    kind "entity"
    name "VATS"
    community 15
  ]
  node [
    id 620
    label "E:GRAPES"
    kind "entity"
    name "GRAPES"
    community 15
  ]
  node [
    id 621
    label "E:BARE-FOOTED MEN"
    kind "entity"
    name "BARE-FOOTED MEN"
    community 15
  ]
  node [
    id 622
    label "E:SKINS"
    kind "entity"
    name "SKINS"
    community 15
  ]
  node [
    id 623
    label "E:SEEDS"
    kind "entity"
    name "SEEDS"
    community 15
  ]
  node [
    id 624
    label "E:WARM PLACE"
    kind "entity"
    name "WARM PLACE"
    community 15
  ]
  node [
    id 625
    label "E:BUBBLES"
    kind "entity"
    name "BUBBLES"
    community 2
  ]
  node [
    id 626
    label "E:FROTH"
    kind "entity"
    name "FROTH"
    community 15
  ]
  node [
    id 627
    label "E:BUBBLES TO RISE"
    kind "entity"
    name "BUBBLES TO RISE"
    community 15
  ]
  node [
    id 628
    label "E:TOP OF JUICE"
    kind "entity"
    name "TOP OF JUICE"
    community 2
  ]
  node [
    id 629
    label "U:Novel-25646_00025#2"
    kind "unit"
    chunk_id "Novel-25646_00025"
    text "If a cook wanted to use grape-juice to make jelly, she would say: 'I cannot make my grape-jelly, for the grape-juice is spoiled.' The change in grape-juice is that the sugar in it is transforming into something else."
    community 2
  ]
  node [
    id 630
    label "E:COOK"
    kind "entity"
    name "COOK"
    community 2
  ]
  node [
    id 631
    label "E:SPOILED"
    kind "entity"
    name "SPOILED"
    community 2
  ]
  node [
    id 632
    label "E:CHANGE"
    kind "entity"
    name "CHANGE"
    community 2
  ]
  node [
    id 633
    label "E:SOMETHING ELSE"
    kind "entity"
    name "SOMETHING ELSE"
    community 2
  ]
  node [
    id 634
    label "E:I CANNOT MAKE MY GRAPE-JELLY BECAUSE THE GRAPE-JUICE IS SPOILED"
    kind "entity"
    name "I CANNOT MAKE MY GRAPE-JELLY BECAUSE THE GRAPE-JUICE IS SPOILED"
    community 2
  ]
  node [
    id 635
    label "C:Novel-25646_00026"
    kind "chunk"
    chunk_id "Novel-25646_00026"
  ]
  node [
    id 636
    label "U:Novel-25646_00026#0"
    kind "unit"
    chunk_id "Novel-25646_00026"
    text "The sugar in grape-juice changes into alcohol and a gas that forms small bubbles and rises to the top, eventually going into the air; the alcohol remains as a thin liquid mixed with water in the juice, while the sugar is no longer present."
    community 2
  ]
  node [
    id 637
    label "E:GAS"
    kind "entity"
    name "GAS"
    community 2
  ]
  node [
    id 638
    label "U:Novel-25646_00026#1"
    kind "unit"
    chunk_id "Novel-25646_00026"
    text "The alcohol produced in grape-juice is a liquid poison; a small amount can harm anyone who drinks it, and a large amount would be fatal."
    community 10
  ]
  node [
    id 639
    label "E:LIQUID POISON"
    kind "entity"
    name "LIQUID POISON"
    community 10
  ]
  node [
    id 640
    label "E:DRINKER"
    kind "entity"
    name "DRINKER"
    community 10
  ]
  node [
    id 641
    label "E:LITTLE OF ALCOHOL"
    kind "entity"
    name "LITTLE OF ALCOHOL"
    community 10
  ]
  node [
    id 642
    label "E:MUCH OF ALCOHOL"
    kind "entity"
    name "MUCH OF ALCOHOL"
    community 10
  ]
  node [
    id 643
    label "U:Novel-25646_00026#2"
    kind "unit"
    chunk_id "Novel-25646_00026"
    text "Ripe grapes are safe food, but grape-juice that has had its sugar converted to alcohol is unsafe to drink because it is poisoned by the alcohol."
    community 9
  ]
  node [
    id 644
    label "E:SAFETY"
    kind "entity"
    name "SAFETY"
    community 9
  ]
  node [
    id 645
    label "E:POISONED"
    kind "entity"
    name "POISONED"
    community 9
  ]
  node [
    id 646
    label "E:ANYONE"
    kind "entity"
    name "ANYONE"
    community 9
  ]
  node [
    id 647
    label "U:Novel-25646_00026#3"
    kind "unit"
    chunk_id "Novel-25646_00026"
    text "The grape-juice that has undergone this change is called wine; it is partly water, partly alcohol, and still has the grape flavor."
    community 5
  ]
  node [
    id 648
    label "E:WINE"
    kind "entity"
    name "WINE"
    community 5
  ]
  node [
    id 649
    label "E:PARTLY WATER"
    kind "entity"
    name "PARTLY WATER"
    community 5
  ]
  node [
    id 650
    label "E:PARTLY ALCOHOL"
    kind "entity"
    name "PARTLY ALCOHOL"
    community 5
  ]
  node [
    id 651
    label "E:GRAPE-FLAVOR"
    kind "entity"
    name "GRAPE-FLAVOR"
    community 5
  ]
  node [
    id 652
    label "U:Novel-25646_00026#4"
    kind "unit"
    chunk_id "Novel-25646_00026"
    text "Wine is also made from currants, elderberries, and other fruits in a way similar to that of grapes; people sometimes make it at home from fruits from their own gardens and believe there is no alcohol because they do not add any, but the alcohol is actually formed in the fruit-juice by the conversion of sugar into alcohol and gas."
    community 15
  ]
  node [
    id 653
    label "E:CURRANTS"
    kind "entity"
    name "CURRANTS"
    community 15
  ]
  node [
    id 654
    label "E:ELDERBERRIES"
    kind "entity"
    name "ELDERBERRIES"
    community 15
  ]
  node [
    id 655
    label "E:HOME-MADE WINE"
    kind "entity"
    name "HOME-MADE WINE"
    community 15
  ]
  node [
    id 656
    label "E:FRUIT-JUICE"
    kind "entity"
    name "FRUIT-JUICE"
    community 2
  ]
  node [
    id 657
    label "E:FRUITS FROM THEIR GARDENS"
    kind "entity"
    name "FRUITS FROM THEIR GARDENS"
    community 15
  ]
  node [
    id 658
    label "C:Novel-25646_00027"
    kind "chunk"
    chunk_id "Novel-25646_00027"
  ]
  node [
    id 659
    label "U:Novel-25646_00027#0"
    kind "unit"
    chunk_id "Novel-25646_00027"
    text "Alcohol in wine or other drinks causes a person to want more of it, leading to increased consumption; when this continues, the person is called a drunkard. Wine has contributed to the creation of many drunkards. Alcohol harms both the body and mind, changing a person's character: it can make a good and kind person cruel and bad, and make a bad person worse. Not everyone who drinks wine becomes a drunkard, but one cannot be certain of avoiding it. Wine should not be drunk because it contains alcohol."
    community 5
  ]
  node [
    id 660
    label "E:GOOD PERSON"
    kind "entity"
    name "GOOD PERSON"
    community 5
  ]
  node [
    id 661
    label "E:KIND PERSON"
    kind "entity"
    name "KIND PERSON"
    community 5
  ]
  node [
    id 662
    label "E:CRUEL PERSON"
    kind "entity"
    name "CRUEL PERSON"
    community 5
  ]
  node [
    id 663
    label "E:BAD PERSON"
    kind "entity"
    name "BAD PERSON"
    community 5
  ]
  node [
    id 664
    label "E:WINE DRINKER"
    kind "entity"
    name "WINE DRINKER"
    community 5
  ]
  node [
    id 665
    label "U:Novel-25646_00027#1"
    kind "unit"
    chunk_id "Novel-25646_00027"
    text "Cider is made from apples. After the juice is pressed from apples and left open to air, sugar begins to change into alcohol and bubbles of gas. Initially, cider has little alcohol, but over time more alcohol forms until ten cups of cider may contain one cup of alcohol. Cider can make drinkers ill-tempered and cross. If left in a warm place for a long time, cider and wine will turn into vinegar."
    community 19
  ]
  node [
    id 666
    label "E:CIDER"
    kind "entity"
    name "CIDER"
    community 19
  ]
  node [
    id 667
    label "E:AIR"
    kind "entity"
    name "AIR"
    community 0
  ]
  node [
    id 668
    label "E:BUBBLES OF GAS"
    kind "entity"
    name "BUBBLES OF GAS"
    community 15
  ]
  node [
    id 669
    label "E:ILL-TEMPERED"
    kind "entity"
    name "ILL-TEMPERED"
    community 19
  ]
  node [
    id 670
    label "E:CROSS"
    kind "entity"
    name "CROSS"
    community 19
  ]
  node [
    id 671
    label "E:VINEGAR"
    kind "entity"
    name "VINEGAR"
    community 19
  ]
  node [
    id 672
    label "E:TEN CUPS"
    kind "entity"
    name "TEN CUPS"
    community 19
  ]
  node [
    id 673
    label "E:ONE CUP OF ALCOHOL"
    kind "entity"
    name "ONE CUP OF ALCOHOL"
    community 19
  ]
  node [
    id 674
    label "C:Novel-25646_00028"
    kind "chunk"
    chunk_id "Novel-25646_00028"
  ]
  node [
    id 675
    label "U:Novel-25646_00028#0"
    kind "unit"
    chunk_id "Novel-25646_00028"
    text "Cider and wine will turn into vinegar if left in a warm place long enough."
    community 15
  ]
  node [
    id 676
    label "E:CIDER TURNS INTO VINEGAR"
    kind "entity"
    name "CIDER TURNS INTO VINEGAR"
    community 15
  ]
  node [
    id 677
    label "E:WINE TURNS INTO VINEGAR"
    kind "entity"
    name "WINE TURNS INTO VINEGAR"
    community 15
  ]
  node [
    id 678
    label "U:Novel-25646_00028#1"
    kind "unit"
    chunk_id "Novel-25646_00028"
    text "The sugar in fruit-juice is changed into alcohol and the gas and alcohol are released, resulting in a changed juice that is no longer safe for making jelly."
    community 2
  ]
  node [
    id 679
    label "E:JELLY"
    kind "entity"
    name "JELLY"
    community 2
  ]
  node [
    id 680
    label "E:CHANGED JUICE"
    kind "entity"
    name "CHANGED JUICE"
    community 2
  ]
  node [
    id 681
    label "U:Novel-25646_00028#2"
    kind "unit"
    chunk_id "Novel-25646_00028"
    text "The changed grape-juice is called vinegar and is not safe to drink because it contains alcohol and harmful substances."
    community 19
  ]
  node [
    id 682
    label "E:GRAPES JUICE"
    kind "entity"
    name "GRAPES JUICE"
    community 19
  ]
  node [
    id 683
    label "E:SAFE DRINK"
    kind "entity"
    name "SAFE DRINK"
    community 19
  ]
  node [
    id 684
    label "U:Novel-25646_00028#3"
    kind "unit"
    chunk_id "Novel-25646_00028"
    text "Alcohol is a substance found in grape-juice and wine that can affect the body and mind, causing intoxication and leading to harmful effects on health."
    community 19
  ]
  node [
    id 685
    label "E:INTOXICATION"
    kind "entity"
    name "INTOXICATION"
    community 19
  ]
  node [
    id 686
    label "E:HARMFUL EFFECTS"
    kind "entity"
    name "HARMFUL EFFECTS"
    community 19
  ]
  node [
    id 687
    label "C:Novel-25646_00029"
    kind "chunk"
    chunk_id "Novel-25646_00029"
  ]
  node [
    id 688
    label "U:Novel-25646_00029#0"
    kind "unit"
    chunk_id "Novel-25646_00029"
    text "Alcohol hurts many persons, and wine has done harm to many people. Alcohol injures the body and affects a person's health negatively."
    community 5
  ]
  node [
    id 689
    label "U:Novel-25646_00029#1"
    kind "unit"
    chunk_id "Novel-25646_00029"
    text "Alcohol changes a person by affecting their behavior and mental state, potentially leading to loss of control and impaired judgment."
    community 5
  ]
  node [
    id 690
    label "U:Novel-25646_00029#2"
    kind "unit"
    chunk_id "Novel-25646_00029"
    text "Drinking wine may lead to becoming a drunkard, and one should not drink it because it harms the body and affects mental and physical health."
    community 5
  ]
  node [
    id 691
    label "U:Novel-25646_00029#3"
    kind "unit"
    chunk_id "Novel-25646_00029"
    text "Cider is made from apple-juice, and apple-juice soon turns into vinegar through fermentation."
    community 19
  ]
  node [
    id 692
    label "E:APPLE-JUICE"
    kind "entity"
    name "APPLE-JUICE"
    community 19
  ]
  node [
    id 693
    label "U:Novel-25646_00029#4"
    kind "unit"
    chunk_id "Novel-25646_00029"
    text "Vinegar can be made by fermenting apple-juice, a process that involves the action of natural bacteria and time."
    community 19
  ]
  node [
    id 694
    label "E:FERMENTATION"
    kind "entity"
    name "FERMENTATION"
    community 19
  ]
  node [
    id 695
    label "U:Novel-25646_00029#5"
    kind "unit"
    chunk_id "Novel-25646_00029"
    text "Alcohol is produced from grains as well as fruit; grains contain starch instead of sugar, and when planted in moist, warm soil, they sprout and grow with roots going down and stems going up into the sunshine."
    community 3
  ]
  node [
    id 696
    label "E:GRAINS"
    kind "entity"
    name "GRAINS"
    community 1
  ]
  node [
    id 697
    label "E:STARCH"
    kind "entity"
    name "STARCH"
    community 3
  ]
  node [
    id 698
    label "E:PLANTING"
    kind "entity"
    name "PLANTING"
    community 3
  ]
  node [
    id 699
    label "E:MOIST"
    kind "entity"
    name "MOIST"
    community 3
  ]
  node [
    id 700
    label "E:WARM"
    kind "entity"
    name "WARM"
    community 3
  ]
  node [
    id 701
    label "E:ROOTS"
    kind "entity"
    name "ROOTS"
    community 3
  ]
  node [
    id 702
    label "E:STEMS"
    kind "entity"
    name "STEMS"
    community 3
  ]
  node [
    id 703
    label "E:SUNSHINE"
    kind "entity"
    name "SUNSHINE"
    community 3
  ]
  node [
    id 704
    label "E:FRUIT"
    kind "entity"
    name "FRUIT"
    community 3
  ]
  node [
    id 705
    label "E:BEGIN TO SPROUT AND GROW"
    kind "entity"
    name "BEGIN TO SPROUT AND GROW"
    community 3
  ]
  node [
    id 706
    label "E:WHEN PLANTED IN MOIST AND WARM SOIL"
    kind "entity"
    name "WHEN PLANTED IN MOIST AND WARM SOIL"
    community 1
  ]
  node [
    id 707
    label "C:Novel-25646_00030"
    kind "chunk"
    chunk_id "Novel-25646_00030"
  ]
  node [
    id 708
    label "U:Novel-25646_00030#0"
    kind "unit"
    chunk_id "Novel-25646_00030"
    text "The roots and stems of sprouting seeds must be fed with sugar, and as soon as the seed begins to sprout, its starch turns into sugar in a process too wonderful for humans to fully understand. This can be tested by chewing a grain of wheat before and after sprouting, which shows a difference in taste."
    community 3
  ]
  node [
    id 709
    label "E:SEED"
    kind "entity"
    name "SEED"
    community 3
  ]
  node [
    id 710
    label "E:SPROUTING"
    kind "entity"
    name "SPROUTING"
    community 3
  ]
  node [
    id 711
    label "E:WHEAT"
    kind "entity"
    name "WHEAT"
    community 1
  ]
  node [
    id 712
    label "E:CHEWING"
    kind "entity"
    name "CHEWING"
    community 3
  ]
  node [
    id 713
    label "E:TASTE"
    kind "entity"
    name "TASTE"
    community 4
  ]
  node [
    id 714
    label "U:Novel-25646_00030#1"
    kind "unit"
    chunk_id "Novel-25646_00030"
    text "Barley is a grain used by brewers to make beer, and before brewing, its starch must be converted into sugar. To do this, the grain is sprouted, but not planted in the ground because it would need to be dug up quickly. Instead, it is kept warm and moist in a visible location so the sprouting can be stopped at the right time to preserve the sugar."
    community 3
  ]
  node [
    id 715
    label "E:BARLEY"
    kind "entity"
    name "BARLEY"
    community 3
  ]
  node [
    id 716
    label "E:BREWERS"
    kind "entity"
    name "BREWERS"
    community 3
  ]
  node [
    id 717
    label "E:GROUND"
    kind "entity"
    name "GROUND"
    community 3
  ]
  node [
    id 718
    label "E:PLACE"
    kind "entity"
    name "PLACE"
    community 7
  ]
  node [
    id 719
    label "E:SUGAR PRESERVATION"
    kind "entity"
    name "SUGAR PRESERVATION"
    community 3
  ]
  node [
    id 720
    label "U:Novel-25646_00030#2"
    kind "unit"
    chunk_id "Novel-25646_00030"
    text "After sprouting, the grain is called malt. The brewer soaks it in plenty of water because the grain itself does not contain water, unlike grapes. Yeast is added to help convert sugar into gas and alcohol. Hops may also be added to give the beer a bitter taste. The brewer watches for bubbles of gas, which clearly indicate that sugar is being used and alcohol is being produced."
    community 2
  ]
  node [
    id 721
    label "E:MALT"
    kind "entity"
    name "MALT"
    community 2
  ]
  node [
    id 722
    label "E:GRAPE"
    kind "entity"
    name "GRAPE"
    community 2
  ]
  node [
    id 723
    label "E:YEAST"
    kind "entity"
    name "YEAST"
    community 2
  ]
  node [
    id 724
    label "E:HOPS"
    kind "entity"
    name "HOPS"
    community 2
  ]
  node [
    id 725
    label "E:SPROUTED BARLEY"
    kind "entity"
    name "SPROUTED BARLEY"
    community 2
  ]
  node [
    id 726
    label "E:BITTER TASTE"
    kind "entity"
    name "BITTER TASTE"
    community 2
  ]
  node [
    id 727
    label "E:SUGAR DEPLETION"
    kind "entity"
    name "SUGAR DEPLETION"
    community 2
  ]
  node [
    id 728
    label "E:ALCOHOL PRODUCTION"
    kind "entity"
    name "ALCOHOL PRODUCTION"
    community 2
  ]
  node [
    id 729
    label "C:Novel-25646_00031"
    kind "chunk"
    chunk_id "Novel-25646_00031"
  ]
  node [
    id 730
    label "U:Novel-25646_00031#0"
    kind "unit"
    chunk_id "Novel-25646_00031"
    text "When the work is finished, the barley has been made into beer, which may have been ground into barley-cakes or pearl barley to thicken soups and serve as food. Beer now contains alcohol, which is a poison, and therefore one should not drink it because alcohol is present."
    community 3
  ]
  node [
    id 731
    label "E:BARLEY-CAKES"
    kind "entity"
    name "BARLEY-CAKES"
    community 3
  ]
  node [
    id 732
    label "E:PEARL BARLEY"
    kind "entity"
    name "PEARL BARLEY"
    community 3
  ]
  node [
    id 733
    label "E:SOUPS"
    kind "entity"
    name "SOUPS"
    community 3
  ]
  node [
    id 734
    label "U:Novel-25646_00031#1"
    kind "unit"
    chunk_id "Novel-25646_00031"
    text "Two boys of the same age begin school together; one drinks wine, cider, and beer, while the other never consumes these drinks. The boys become very different because one is poisoning his body and mind with alcohol, and the other is not."
    community 5
  ]
  node [
    id 735
    label "E:BOY WHO DRINKS WINE"
    kind "entity"
    name "BOY WHO DRINKS WINE"
    community 5
  ]
  node [
    id 736
    label "E:BOY WHO NEVER DRINKS"
    kind "entity"
    name "BOY WHO NEVER DRINKS"
    community 5
  ]
  node [
    id 737
    label "U:Novel-25646_00031#2"
    kind "unit"
    chunk_id "Novel-25646_00031"
    text "A man wants a good, steady boy to work for him and will likely select the boy who does not drink alcohol, as the one who drinks is poisoning his body and mind. Later, a young man is wanted who can be trusted with the care of an engine or a bank, and the one who avoids alcohol is more likely to get this position."
    community 5
  ]
  node [
    id 738
    label "E:GOOD STEADY BOY"
    kind "entity"
    name "GOOD STEADY BOY"
    community 5
  ]
  node [
    id 739
    label "E:ENGINE"
    kind "entity"
    name "ENGINE"
    community 5
  ]
  node [
    id 740
    label "E:BANK"
    kind "entity"
    name "BANK"
    community 5
  ]
  node [
    id 741
    label "E:TRUST"
    kind "entity"
    name "TRUST"
    community 5
  ]
  node [
    id 742
    label "E:CARE OF ENGINE"
    kind "entity"
    name "CARE OF ENGINE"
    community 5
  ]
  node [
    id 743
    label "E:CARE OF BANK"
    kind "entity"
    name "CARE OF BANK"
    community 5
  ]
  node [
    id 744
    label "C:Novel-25646_00032"
    kind "chunk"
    chunk_id "Novel-25646_00032"
  ]
  node [
    id 745
    label "U:Novel-25646_00032#0"
    kind "unit"
    chunk_id "Novel-25646_00032"
    text "Distilling is a process where water is boiled into steam and then condensed back into liquid water, which is called distillation. When water in a tea-kettle boils, steam comes out and turns into drops of water when it touches a cold surface."
    community 2
  ]
  node [
    id 746
    label "E:DISTILLING"
    kind "entity"
    name "DISTILLING"
    community 2
  ]
  node [
    id 747
    label "E:STEAM"
    kind "entity"
    name "STEAM"
    community 2
  ]
  node [
    id 748
    label "E:TEA-KETTLE"
    kind "entity"
    name "TEA-KETTLE"
    community 2
  ]
  node [
    id 749
    label "E:COOL PLATE"
    kind "entity"
    name "COOL PLATE"
    community 2
  ]
  node [
    id 750
    label "E:VAPOR"
    kind "entity"
    name "VAPOR"
    community 2
  ]
  node [
    id 751
    label "U:Novel-25646_00032#1"
    kind "unit"
    chunk_id "Novel-25646_00032"
    text "The term vapor is used instead of steam when discussing the boiling of alcohol."
    community 2
  ]
  node [
    id 752
    label "C:Novel-25646_00033"
    kind "chunk"
    chunk_id "Novel-25646_00033"
  ]
  node [
    id 753
    label "U:Novel-25646_00033#0"
    kind "unit"
    chunk_id "Novel-25646_00033"
    text "When alcohol boils, we call the resulting gas vapor instead of steam. It takes less heat to turn alcohol into vapor than water into steam. When a liquid containing alcohol is heated over a fire and the vapor is collected, alcohol rises first, followed by water. The resulting vapor is not pure alcohol because alcohol mixes easily with water and must be distilled multiple times to become pure. Each distillation increases the alcohol concentration and reduces water content, making the final product stronger. Brandy, rum, whiskey, and gin are produced by distilling wine, cider, or fermented liquors made from corn, rye, or barley. These fermented drinks initially contain little alcohol, while brandy, rum, whiskey, and gin contain nearly half alcohol. A single glass of distilled strong liquor is more harmful and acts faster than a glass of cider, rum, or beer. However, a person who drinks large amounts of weaker liquors like cider or beer can still consume a significant amount of alcohol. People can become drunkards through excessive consumption of cider or beer. The more alcohol present, the greater the danger."
    community 23
  ]
  node [
    id 754
    label "E:DISTILLATION"
    kind "entity"
    name "DISTILLATION"
    community 23
  ]
  node [
    id 755
    label "E:BRANDY"
    kind "entity"
    name "BRANDY"
    community 5
  ]
  node [
    id 756
    label "E:RUM"
    kind "entity"
    name "RUM"
    community 23
  ]
  node [
    id 757
    label "E:WHISKEY"
    kind "entity"
    name "WHISKEY"
    community 5
  ]
  node [
    id 758
    label "E:GIN"
    kind "entity"
    name "GIN"
    community 23
  ]
  node [
    id 759
    label "E:CORN"
    kind "entity"
    name "CORN"
    community 1
  ]
  node [
    id 760
    label "E:RYE"
    kind "entity"
    name "RYE"
    community 23
  ]
  node [
    id 761
    label "E:ALCOHOL CONCENTRATION"
    kind "entity"
    name "ALCOHOL CONCENTRATION"
    community 23
  ]
  node [
    id 762
    label "E:DANGER"
    kind "entity"
    name "DANGER"
    community 23
  ]
  node [
    id 763
    label "E:LIQUID CONTAINING ALCOHOL"
    kind "entity"
    name "LIQUID CONTAINING ALCOHOL"
    community 2
  ]
  node [
    id 764
    label "E:COLLECTED VAPOUR"
    kind "entity"
    name "COLLECTED VAPOUR"
    community 2
  ]
  node [
    id 765
    label "E:ALCOHOL MIXED WITH WATER"
    kind "entity"
    name "ALCOHOL MIXED WITH WATER"
    community 23
  ]
  node [
    id 766
    label "E:PURE ALCOHOL"
    kind "entity"
    name "PURE ALCOHOL"
    community 23
  ]
  node [
    id 767
    label "E:ALCOHOL VAPOR"
    kind "entity"
    name "ALCOHOL VAPOR"
    community 23
  ]
  node [
    id 768
    label "E:WEAK LIQUORS"
    kind "entity"
    name "WEAK LIQUORS"
    community 23
  ]
  node [
    id 769
    label "E:GLASS OF DISTILLED STRONG LIQUOR"
    kind "entity"
    name "GLASS OF DISTILLED STRONG LIQUOR"
    community 23
  ]
  node [
    id 770
    label "E:GLASS OF CIDER OR RUM OR BEER"
    kind "entity"
    name "GLASS OF CIDER OR RUM OR BEER"
    community 23
  ]
  node [
    id 771
    label "E:WEAKER LIQUORS"
    kind "entity"
    name "WEAKER LIQUORS"
    community 23
  ]
  node [
    id 772
    label "E:ALCOHOL INTAKE"
    kind "entity"
    name "ALCOHOL INTAKE"
    community 23
  ]
  node [
    id 773
    label "E:CIDER OR BEER DRINKERS"
    kind "entity"
    name "CIDER OR BEER DRINKERS"
    community 23
  ]
  node [
    id 774
    label "E:MORE ALCOHOL"
    kind "entity"
    name "MORE ALCOHOL"
    community 23
  ]
  node [
    id 775
    label "C:Novel-25646_00034"
    kind "chunk"
    chunk_id "Novel-25646_00034"
  ]
  node [
    id 776
    label "U:Novel-25646_00034#0"
    kind "unit"
    chunk_id "Novel-25646_00034"
    text "People are often made drunkards by drinking cider or beer, and the more poison (alcohol) consumed, the greater the danger."
    community 5
  ]
  node [
    id 777
    label "E:DRUNKARDS"
    kind "entity"
    name "DRUNKARDS"
    community 5
  ]
  node [
    id 778
    label "U:Novel-25646_00034#1"
    kind "unit"
    chunk_id "Novel-25646_00034"
    text "Alcohol looks like water but is not like water; it burns when a lighted match is held near it, producing a blue flame, and gives off heat without smoke or soot."
    community 6
  ]
  node [
    id 779
    label "E:FLAME"
    kind "entity"
    name "FLAME"
    community 6
  ]
  node [
    id 780
    label "E:SMOKE"
    kind "entity"
    name "SMOKE"
    community 6
  ]
  node [
    id 781
    label "E:SOOT"
    kind "entity"
    name "SOOT"
    community 6
  ]
  node [
    id 782
    label "U:Novel-25646_00034#2"
    kind "unit"
    chunk_id "Novel-25646_00034"
    text "A dead tree-toad was placed in a bottle of alcohol many years ago and is still alive and unchanged to this day, which shows that alcohol preserves life."
    community 2
  ]
  node [
    id 783
    label "E:TREE-TOAD"
    kind "entity"
    name "TREE-TOAD"
    community 2
  ]
  node [
    id 784
    label "E:BOTTLE"
    kind "entity"
    name "BOTTLE"
    community 2
  ]
  node [
    id 785
    label "E:YEARS AGO"
    kind "entity"
    name "YEARS AGO"
    community 2
  ]
  node [
    id 786
    label "C:Novel-25646_00035"
    kind "chunk"
    chunk_id "Novel-25646_00035"
  ]
  node [
    id 787
    label "U:Novel-25646_00035#0"
    kind "unit"
    chunk_id "Novel-25646_00035"
    text "Alcohol prevents dead bodies from decaying, as demonstrated by the tree-toad which would have decayed if placed in water."
    community 2
  ]
  node [
    id 788
    label "U:Novel-25646_00035#1"
    kind "unit"
    chunk_id "Novel-25646_00035"
    text "Pure alcohol is rarely consumed as a drink, but people who consume beer, wine, and cider ingest a small amount of alcohol with each drink."
    community 23
  ]
  node [
    id 789
    label "U:Novel-25646_00035#2"
    kind "unit"
    chunk_id "Novel-25646_00035"
    text "People who drink brandy, rum, whiskey, or gin consume significantly more alcohol, as these liquors are nearly one half alcohol."
    community 5
  ]
  node [
    id 790
    label "E:ONE HALF"
    kind "entity"
    name "ONE HALF"
    community 5
  ]
  node [
    id 791
    label "U:Novel-25646_00035#3"
    kind "unit"
    chunk_id "Novel-25646_00035"
    text "Alcohol is a deceiver that leads people to believe it is beneficial, causing them to consume more, especially when the appetite for it is formed in childhood."
    community 15
  ]
  node [
    id 792
    label "E:CHILDHOOD"
    kind "entity"
    name "CHILDHOOD"
    community 15
  ]
  node [
    id 793
    label "E:APPETITE"
    kind "entity"
    name "APPETITE"
    community 15
  ]
  node [
    id 794
    label "U:Novel-25646_00035#4"
    kind "unit"
    chunk_id "Novel-25646_00035"
    text "Consuming wine-jelly or wine-sauce may lead someone to develop a liking for the taste of alcohol, making it easier to begin drinking weak liquor."
    community 15
  ]
  node [
    id 795
    label "E:WINE-JELLY"
    kind "entity"
    name "WINE-JELLY"
    community 15
  ]
  node [
    id 796
    label "E:WINE-SAUCE"
    kind "entity"
    name "WINE-SAUCE"
    community 15
  ]
  node [
    id 797
    label "E:WEAK LIQUOR"
    kind "entity"
    name "WEAK LIQUOR"
    community 15
  ]
  node [
    id 798
    label "U:Novel-25646_00035#5"
    kind "unit"
    chunk_id "Novel-25646_00035"
    text "As a person drinks more alcohol, they often desire more, progressing from cider, wine, or beer to whiskey, brandy, or rum, eventually becoming a drunkard."
    community 5
  ]
  node [
    id 799
    label "E:DRINKING MORE"
    kind "entity"
    name "DRINKING MORE"
    community 5
  ]
  node [
    id 800
    label "U:Novel-25646_00035#6"
    kind "unit"
    chunk_id "Novel-25646_00035"
    text "People who regularly consume alcohol-containing drinks often prioritize them over all other things, even when they know they are being harmed by them."
    community 11
  ]
  node [
    id 801
    label "E:DRINKING HABIT"
    kind "entity"
    name "DRINKING HABIT"
    community 11
  ]
  node [
    id 802
    label "E:OTHER THINGS"
    kind "entity"
    name "OTHER THINGS"
    community 11
  ]
  node [
    id 803
    label "E:HARM"
    kind "entity"
    name "HARM"
    community 11
  ]
  node [
    id 804
    label "C:Novel-25646_00036"
    kind "chunk"
    chunk_id "Novel-25646_00036"
  ]
  node [
    id 805
    label "U:Novel-25646_00036#0"
    kind "unit"
    chunk_id "Novel-25646_00036"
    text "Alcohol does not have a visible appearance described in the passage, and its burning properties are not specified. Alcohol does not affect a dead body as stated in the questions. Drinks that contain a little alcohol are not specified. Drinks that are about one half alcohol are not specified. Alcohol is said to cheat people, though the mechanism is not explained. The appetite is sometimes formed at unspecified times. Wine-sauce and wine-jelly should not be eaten because they may affect health, though the exact reason is not given. Drunkards are made through consumption of alcohol, though the process is not detailed."
    community 15
  ]
  node [
    id 806
    label "E:DEAD BODY"
    kind "entity"
    name "DEAD BODY"
    community 15
  ]
  node [
    id 807
    label "E:DRINKS WITH LITTLE ALCOHOL"
    kind "entity"
    name "DRINKS WITH LITTLE ALCOHOL"
    community 15
  ]
  node [
    id 808
    label "E:DRINKS WITH ONE HALF ALCOHOL"
    kind "entity"
    name "DRINKS WITH ONE HALF ALCOHOL"
    community 15
  ]
  node [
    id 809
    label "E:CHEATING"
    kind "entity"
    name "CHEATING"
    community 15
  ]
  node [
    id 810
    label "E:HOW DOES ALCOHOL LOOK"
    kind "entity"
    name "HOW DOES ALCOHOL LOOK"
    community 15
  ]
  node [
    id 811
    label "E:UNSPECIFIED TIME"
    kind "entity"
    name "UNSPECIFIED TIME"
    community 15
  ]
  node [
    id 812
    label "U:Novel-25646_00036#1"
    kind "unit"
    chunk_id "Novel-25646_00036"
    text "A farmer who regularly planted corn, wheat, and potatoes decided to switch to planting tobacco. The tobacco plants grew as tall as a little boy or girl and developed broad, green leaves. The farmer harvested the stalks, dried the leaves, and processed them into tobacco cakes, cigars, and snuff. Tobacco contains a substance called nicotine, which is a strong poison, and one drop is sufficient to kill a dog."
    community 1
  ]
  node [
    id 813
    label "E:FARMER"
    kind "entity"
    name "FARMER"
    community 1
  ]
  node [
    id 814
    label "E:POTATOES"
    kind "entity"
    name "POTATOES"
    community 1
  ]
  node [
    id 815
    label "E:TOBACCO PLANTS"
    kind "entity"
    name "TOBACCO PLANTS"
    community 1
  ]
  node [
    id 816
    label "E:LITTLE BOY OR GIRL"
    kind "entity"
    name "LITTLE BOY OR GIRL"
    community 1
  ]
  node [
    id 817
    label "E:GREEN LEAVES"
    kind "entity"
    name "GREEN LEAVES"
    community 1
  ]
  node [
    id 818
    label "E:STALKS"
    kind "entity"
    name "STALKS"
    community 1
  ]
  node [
    id 819
    label "E:DRIED LEAVES"
    kind "entity"
    name "DRIED LEAVES"
    community 1
  ]
  node [
    id 820
    label "E:TOBACCO CAKES"
    kind "entity"
    name "TOBACCO CAKES"
    community 1
  ]
  node [
    id 821
    label "E:CIGARS"
    kind "entity"
    name "CIGARS"
    community 11
  ]
  node [
    id 822
    label "E:SNUFF"
    kind "entity"
    name "SNUFF"
    community 1
  ]
  node [
    id 823
    label "E:NICOTINE"
    kind "entity"
    name "NICOTINE"
    community 1
  ]
  node [
    id 824
    label "E:DOG"
    kind "entity"
    name "DOG"
    community 1
  ]
  node [
    id 825
    label "E:LEAVES"
    kind "entity"
    name "LEAVES"
    community 1
  ]
  node [
    id 826
    label "E:NONE"
    kind "entity"
    name "NONE"
    community 1
  ]
  node [
    id 827
    label "E:ONE DROP OF NICOTINE"
    kind "entity"
    name "ONE DROP OF NICOTINE"
    community 1
  ]
  node [
    id 828
    label "C:Novel-25646_00037"
    kind "chunk"
    chunk_id "Novel-25646_00037"
  ]
  node [
    id 829
    label "U:Novel-25646_00037#0"
    kind "unit"
    chunk_id "Novel-25646_00037"
    text "A strong poison exists such that one drop is sufficient to kill a dog, and one cigar, when taken pure, is enough to kill two men."
    community 1
  ]
  node [
    id 830
    label "E:STRONG POISON"
    kind "entity"
    name "STRONG POISON"
    community 1
  ]
  node [
    id 831
    label "E:ONE DROP"
    kind "entity"
    name "ONE DROP"
    community 1
  ]
  node [
    id 832
    label "E:ONE CIGAR"
    kind "entity"
    name "ONE CIGAR"
    community 1
  ]
  node [
    id 833
    label "E:TWO MEN"
    kind "entity"
    name "TWO MEN"
    community 1
  ]
  node [
    id 834
    label "U:Novel-25646_00037#1"
    kind "unit"
    chunk_id "Novel-25646_00037"
    text "Working with tobacco makes people pale and sickly; in a snuff mill, the strong smell of tobacco forces a person to leave repeatedly for fresh air."
    community 11
  ]
  node [
    id 835
    label "E:SNUFF MILL"
    kind "entity"
    name "SNUFF MILL"
    community 11
  ]
  node [
    id 836
    label "E:SMELL OF TOBACCO"
    kind "entity"
    name "SMELL OF TOBACCO"
    community 11
  ]
  node [
    id 837
    label "E:PURE AIR"
    kind "entity"
    name "PURE AIR"
    community 11
  ]
  node [
    id 838
    label "E:BREATH OF PURE AIR"
    kind "entity"
    name "BREATH OF PURE AIR"
    community 11
  ]
  node [
    id 839
    label "E:PEOPLE MUST LEAVE REPEATEDLY FOR PURE AIR"
    kind "entity"
    name "PEOPLE MUST LEAVE REPEATEDLY FOR PURE AIR"
    community 11
  ]
  node [
    id 840
    label "U:Novel-25646_00037#2"
    kind "unit"
    chunk_id "Novel-25646_00037"
    text "A man who cared for a snuff mill showed the narrator how the mill operated; the mill stood beside a stream that turned the mill-wheel, with tall trees bending over it and a fresh breeze blowing through open windows."
    community 11
  ]
  node [
    id 841
    label "E:LITTLE STREAM"
    kind "entity"
    name "LITTLE STREAM"
    community 11
  ]
  node [
    id 842
    label "E:MILL-WHEEL"
    kind "entity"
    name "MILL-WHEEL"
    community 11
  ]
  node [
    id 843
    label "E:TALL TREES"
    kind "entity"
    name "TALL TREES"
    community 11
  ]
  node [
    id 844
    label "E:FRESH BREEZE"
    kind "entity"
    name "FRESH BREEZE"
    community 11
  ]
  node [
    id 845
    label "E:OPEN WINDOWS"
    kind "entity"
    name "OPEN WINDOWS"
    community 11
  ]
  node [
    id 846
    label "U:Novel-25646_00037#3"
    kind "unit"
    chunk_id "Novel-25646_00037"
    text "The man who cared for the snuff mill said that the tobacco made him very sick during the first few weeks, after which he got used to it and no longer minded working there."
    community 11
  ]
  node [
    id 847
    label "E:FIRST FEW WEEKS"
    kind "entity"
    name "FIRST FEW WEEKS"
    community 11
  ]
  node [
    id 848
    label "E:GET USED TO IT"
    kind "entity"
    name "GET USED TO IT"
    community 11
  ]
  node [
    id 849
    label "E:NOW DOES NOT MIND"
    kind "entity"
    name "NOW DOES NOT MIND"
    community 11
  ]
  node [
    id 850
    label "U:Novel-25646_00037#4"
    kind "unit"
    chunk_id "Novel-25646_00037"
    text "The sickness experienced by boys trying to learn to smoke is similar to that of the man in the snuff mill; it is the body's way of warning them that they are playing with poison and that harm could result if they continue."
    community 23
  ]
  node [
    id 851
    label "E:BOYS WHO TRY TO LEARN TO SMOKING"
    kind "entity"
    name "BOYS WHO TRY TO LEARN TO SMOKING"
    community 23
  ]
  node [
    id 852
    label "E:STOP THEM"
    kind "entity"
    name "STOP THEM"
    community 23
  ]
  node [
    id 853
    label "E:DANGER EXISTS AND HARM COULD RESULT"
    kind "entity"
    name "DANGER EXISTS AND HARM COULD RESULT"
    community 6
  ]
  node [
    id 854
    label "U:Novel-25646_00037#5"
    kind "unit"
    chunk_id "Novel-25646_00037"
    text "Some people observe men smoking cigars, even four or five per day, and claim they did not die from it."
    community 11
  ]
  node [
    id 855
    label "E:SMOKING CIGARS"
    kind "entity"
    name "SMOKING CIGARS"
    community 11
  ]
  node [
    id 856
    label "E:FOUR OR FIVE CIGARS PER DAY"
    kind "entity"
    name "FOUR OR FIVE CIGARS PER DAY"
    community 11
  ]
  node [
    id 857
    label "E:DID NOT KILL THEM"
    kind "entity"
    name "DID NOT KILL THEM"
    community 11
  ]
  node [
    id 858
    label "C:Novel-25646_00038"
    kind "chunk"
    chunk_id "Novel-25646_00038"
  ]
  node [
    id 859
    label "U:Novel-25646_00038#0"
    kind "unit"
    chunk_id "Novel-25646_00038"
    text "The nicotine in tobacco does not kill people because they do not swallow it; they only inhale a small amount with their breath. However, taking a small amount of poison like nicotine day after day is not safe and is not helpful to anyone."
    community 9
  ]
  node [
    id 860
    label "E:BREATH"
    kind "entity"
    name "BREATH"
    community 6
  ]
  node [
    id 861
    label "E:TAKING A SMALL AMOUNT OF POISON"
    kind "entity"
    name "TAKING A SMALL AMOUNT OF POISON"
    community 9
  ]
  node [
    id 862
    label "U:Novel-25646_00038#1"
    kind "unit"
    chunk_id "Novel-25646_00038"
    text "The farmer planted something instead of corn, wheat, and potatoes. The tobacco leaves were processed, and the poison in tobacco is nicotine. It takes a certain amount of nicotine to kill a dog, and taking pure nicotine from one cigar can cause harm to a person."
    community 1
  ]
  node [
    id 863
    label "E:TOBACCO LEAVES"
    kind "entity"
    name "TOBACCO LEAVES"
    community 1
  ]
  node [
    id 864
    label "E:CIGAR"
    kind "entity"
    name "CIGAR"
    community 6
  ]
  node [
    id 865
    label "E:CAN CAUSE HARM TO A PERSON"
    kind "entity"
    name "CAN CAUSE HARM TO A PERSON"
    community 1
  ]
  node [
    id 866
    label "U:Novel-25646_00038#2"
    kind "unit"
    chunk_id "Novel-25646_00038"
    text "Alcohol and tobacco are called narcotics because they have the power of putting the nerves to sleep. Opium is another narcotic, made from the juice of poppies, and is used in medicines. It is added to soothing syrups, which are sometimes given to babies to stop them from crying by injuring their tender nerves and poisoning their small bodies."
    community 16
  ]
  node [
    id 867
    label "E:NARCOTICS"
    kind "entity"
    name "NARCOTICS"
    community 16
  ]
  node [
    id 868
    label "E:POPPY JUICE"
    kind "entity"
    name "POPPY JUICE"
    community 16
  ]
  node [
    id 869
    label "E:MEDICINES"
    kind "entity"
    name "MEDICINES"
    community 16
  ]
  node [
    id 870
    label "E:SOOTHING SYRUPS"
    kind "entity"
    name "SOOTHING SYRUPS"
    community 16
  ]
  node [
    id 871
    label "E:BABIES"
    kind "entity"
    name "BABIES"
    community 16
  ]
  node [
    id 872
    label "E:TEENAGER"
    kind "entity"
    name "TEENAGER"
    community 16
  ]
  node [
    id 873
    label "E:PUTS NERVES TO SLEEP"
    kind "entity"
    name "PUTS NERVES TO SLEEP"
    community 16
  ]
  node [
    id 874
    label "E:TENDER NERVES"
    kind "entity"
    name "TENDER NERVES"
    community 16
  ]
  node [
    id 875
    label "E:SMALL BODIES"
    kind "entity"
    name "SMALL BODIES"
    community 16
  ]
  node [
    id 876
    label "C:Novel-25646_00039"
    kind "chunk"
    chunk_id "Novel-25646_00039"
  ]
  node [
    id 877
    label "U:Novel-25646_00039#0"
    kind "unit"
    chunk_id "Novel-25646_00039"
    text "Giving a baby opium injures its tender nerves and poisons its little body; it is wrong to give opium to a baby as a soothing-syrup because it is actually a poison and an enemy, not a friend, and mothers would not do it if they knew the truth."
    community 16
  ]
  node [
    id 878
    label "E:BABY"
    kind "entity"
    name "BABY"
    community 16
  ]
  node [
    id 879
    label "E:LITTLE BODY"
    kind "entity"
    name "LITTLE BODY"
    community 16
  ]
  node [
    id 880
    label "E:SOOTHING-SYRUP"
    kind "entity"
    name "SOOTHING-SYRUP"
    community 16
  ]
  node [
    id 881
    label "E:MOTHERS"
    kind "entity"
    name "MOTHERS"
    community 16
  ]
  node [
    id 882
    label "U:Novel-25646_00039#1"
    kind "unit"
    chunk_id "Novel-25646_00039"
    text "A child, even if no older than some of the audience, may be left at home with a baby brother or sister, so it is important to know that opium is a dangerous enemy and to avoid giving it to a baby in place of kind and careful care."
    community 16
  ]
  node [
    id 883
    label "E:CHILD"
    kind "entity"
    name "CHILD"
    community 16
  ]
  node [
    id 884
    label "E:BABY BROTHER OR SISTER"
    kind "entity"
    name "BABY BROTHER OR SISTER"
    community 16
  ]
  node [
    id 885
    label "E:DANGEROUS ENEMY"
    kind "entity"
    name "DANGEROUS ENEMY"
    community 16
  ]
  node [
    id 886
    label "E:CARE"
    kind "entity"
    name "CARE"
    community 16
  ]
  node [
    id 887
    label "U:Novel-25646_00039#2"
    kind "unit"
    chunk_id "Novel-25646_00039"
    text "An organ is a part of the body that has a special function; the eye is the organ of sight and the stomach is an organ that processes food."
    community 17
  ]
  node [
    id 888
    label "E:ORGAN"
    kind "entity"
    name "ORGAN"
    community 17
  ]
  node [
    id 889
    label "E:EYE"
    kind "entity"
    name "EYE"
    community 17
  ]
  node [
    id 890
    label "E:SIGHT"
    kind "entity"
    name "SIGHT"
    community 17
  ]
  node [
    id 891
    label "E:STOMACH"
    kind "entity"
    name "STOMACH"
    community 14
  ]
  node [
    id 892
    label "E:PROCESSING"
    kind "entity"
    name "PROCESSING"
    community 17
  ]
  node [
    id 893
    label "U:Novel-25646_00039#3"
    kind "unit"
    chunk_id "Novel-25646_00039"
    text "Teeth come in different types and serve different functions: the front teeth cut and the back teeth grind."
    community 14
  ]
  node [
    id 894
    label "E:TEETH"
    kind "entity"
    name "TEETH"
    community 14
  ]
  node [
    id 895
    label "E:FRONT TEETH"
    kind "entity"
    name "FRONT TEETH"
    community 14
  ]
  node [
    id 896
    label "E:BACK TEETH"
    kind "entity"
    name "BACK TEETH"
    community 14
  ]
  node [
    id 897
    label "E:CUT"
    kind "entity"
    name "CUT"
    community 14
  ]
  node [
    id 898
    label "E:GRIND"
    kind "entity"
    name "GRIND"
    community 14
  ]
  node [
    id 899
    label "C:Novel-25646_00040"
    kind "chunk"
    chunk_id "Novel-25646_00040"
  ]
  node [
    id 900
    label "U:Novel-25646_00040#0"
    kind "unit"
    chunk_id "Novel-25646_00040"
    text "The front teeth cut and the back teeth grind. They are made of bone covered with a hard smooth enamel. If the enamel is broken, the teeth decay and ache because each tooth has a nerve that quickly feels pain."
    community 14
  ]
  node [
    id 901
    label "E:ENAMEL"
    kind "entity"
    name "ENAMEL"
    community 14
  ]
  node [
    id 902
    label "E:DECAY"
    kind "entity"
    name "DECAY"
    community 14
  ]
  node [
    id 903
    label "E:ACHE"
    kind "entity"
    name "ACHE"
    community 14
  ]
  node [
    id 904
    label "E:ENAMEL IS BROKEN"
    kind "entity"
    name "ENAMEL IS BROKEN"
    community 14
  ]
  node [
    id 905
    label "U:Novel-25646_00040#1"
    kind "unit"
    chunk_id "Novel-25646_00040"
    text "Cracking nuts or biting thread with the teeth is likely to break the enamel. Once broken, the enamel cannot be mended. A dentist can fill a hole in a tooth but cannot cover it with new enamel. Food bits should be carefully picked from between teeth using a tooth-pick made of quill or wood, not a pin or hard sharp object that might break the enamel. Teeth must be well brushed. Only perfect cleanliness keeps teeth in good order. Brush teeth before breakfast, as breakfast will taste better. Brush teeth at night before bed to prevent food from decaying in the mouth during the night. Take care of the teeth so they do not decay and fail to perform their functions properly."
    community 14
  ]
  node [
    id 906
    label "E:CRACKING NUTS"
    kind "entity"
    name "CRACKING NUTS"
    community 14
  ]
  node [
    id 907
    label "E:BITING THREAD"
    kind "entity"
    name "BITING THREAD"
    community 14
  ]
  node [
    id 908
    label "E:DENTIST"
    kind "entity"
    name "DENTIST"
    community 14
  ]
  node [
    id 909
    label "E:HOLE IN TEETH"
    kind "entity"
    name "HOLE IN TEETH"
    community 14
  ]
  node [
    id 910
    label "E:TOOTH-PICK"
    kind "entity"
    name "TOOTH-PICK"
    community 14
  ]
  node [
    id 911
    label "E:QUILL"
    kind "entity"
    name "QUILL"
    community 14
  ]
  node [
    id 912
    label "E:WOOD"
    kind "entity"
    name "WOOD"
    community 14
  ]
  node [
    id 913
    label "E:PIN"
    kind "entity"
    name "PIN"
    community 8
  ]
  node [
    id 914
    label "E:FOOD BITS"
    kind "entity"
    name "FOOD BITS"
    community 14
  ]
  node [
    id 915
    label "E:BRUSHING"
    kind "entity"
    name "BRUSHING"
    community 14
  ]
  node [
    id 916
    label "E:CLEANLINESS"
    kind "entity"
    name "CLEANLINESS"
    community 14
  ]
  node [
    id 917
    label "E:BREAKFAST"
    kind "entity"
    name "BREAKFAST"
    community 14
  ]
  node [
    id 918
    label "E:NIGHT"
    kind "entity"
    name "NIGHT"
    community 13
  ]
  node [
    id 919
    label "E:DECAYING FOOD"
    kind "entity"
    name "DECAYING FOOD"
    community 13
  ]
  node [
    id 920
    label "E:TEETH FUNCTION"
    kind "entity"
    name "TEETH FUNCTION"
    community 14
  ]
  node [
    id 921
    label "E:TEETH WITH NEW ENAMEL"
    kind "entity"
    name "TEETH WITH NEW ENAMEL"
    community 14
  ]
  node [
    id 922
    label "E:QUILL OR WOOD"
    kind "entity"
    name "QUILL OR WOOD"
    community 14
  ]
  node [
    id 923
    label "E:TEETH IN GOOD ORDER"
    kind "entity"
    name "TEETH IN GOOD ORDER"
    community 14
  ]
  node [
    id 924
    label "E:TO PERFORM THEIR WORK WELL"
    kind "entity"
    name "TO PERFORM THEIR WORK WELL"
    community 14
  ]
  node [
    id 925
    label "U:Novel-25646_00040#2"
    kind "unit"
    chunk_id "Novel-25646_00040"
    text "The chest and abdomen are discussed in the passage, but no specific facts about them are provided."
    community 14
  ]
  node [
    id 926
    label "E:ABDOMEN"
    kind "entity"
    name "ABDOMEN"
    community 14
  ]
  node [
    id 927
    label "C:Novel-25646_00041"
    kind "chunk"
    chunk_id "Novel-25646_00041"
  ]
  node [
    id 928
    label "U:Novel-25646_00041#0"
    kind "unit"
    chunk_id "Novel-25646_00041"
    text "The chest and abdomen are formed by bones including the spine, ribs, shoulder-blades, and collar-bones, creating a bony box divided by a strong muscle into two sections: the upper chest and the lower abdomen. The chest contains the heart and lungs, while the abdomen contains the stomach, liver, and other organs."
    community 18
  ]
  node [
    id 929
    label "E:RIBS"
    kind "entity"
    name "RIBS"
    community 18
  ]
  node [
    id 930
    label "E:HEART"
    kind "entity"
    name "HEART"
    community 0
  ]
  node [
    id 931
    label "E:LIVER"
    kind "entity"
    name "LIVER"
    community 4
  ]
  node [
    id 932
    label "E:BONY BOX"
    kind "entity"
    name "BONY BOX"
    community 18
  ]
  node [
    id 933
    label "E:STRONG MUSCLE"
    kind "entity"
    name "STRONG MUSCLE"
    community 18
  ]
  node [
    id 934
    label "E:BREAST-BONE"
    kind "entity"
    name "BREAST-BONE"
    community 18
  ]
  node [
    id 935
    label "E:FORM A BONY BOX"
    kind "entity"
    name "FORM A BONY BOX"
    community 18
  ]
  node [
    id 936
    label "E:CHEST AND ABDOMEN"
    kind "entity"
    name "CHEST AND ABDOMEN"
    community 18
  ]
  node [
    id 937
    label "E:OTHER ORGANS"
    kind "entity"
    name "OTHER ORGANS"
    community 18
  ]
  node [
    id 938
    label "U:Novel-25646_00041#1"
    kind "unit"
    chunk_id "Novel-25646_00041"
    text "The stomach is a strong bag made of muscles on the outside, with a lining that produces gastric juice, which is always ready for use."
    community 14
  ]
  node [
    id 939
    label "E:GASTRIC JUICE"
    kind "entity"
    name "GASTRIC JUICE"
    community 14
  ]
  node [
    id 940
    label "C:Novel-25646_00042"
    kind "chunk"
    chunk_id "Novel-25646_00042"
  ]
  node [
    id 941
    label "U:Novel-25646_00042#0"
    kind "unit"
    chunk_id "Novel-25646_00042"
    text "If a man could put beef, apples, potatoes, bread, milk, sugar, and salt into a bag, tie it up, leave it on a shelf for a few hours, and then show that all the food had disappeared, leaving only a thin grayish fluid, one would call it a magical bag. The human stomach and the stomach of a person are just such magical bags: they take in food like breakfast, dinner, and supper, and after a few hours, mix it with gastric juice and squeeze it with strong muscles, changing it into a thin grayish fluid."
    community 1
  ]
  node [
    id 942
    label "E:MAGICAL BAG"
    kind "entity"
    name "MAGICAL BAG"
    community 1
  ]
  node [
    id 943
    label "E:BEAF"
    kind "entity"
    name "BEAF"
    community 1
  ]
  node [
    id 944
    label "E:BREAD"
    kind "entity"
    name "BREAD"
    community 1
  ]
  node [
    id 945
    label "E:MILK"
    kind "entity"
    name "MILK"
    community 1
  ]
  node [
    id 946
    label "E:SALT"
    kind "entity"
    name "SALT"
    community 1
  ]
  node [
    id 947
    label "E:STRONG MUSCLES"
    kind "entity"
    name "STRONG MUSCLES"
    community 1
  ]
  node [
    id 948
    label "E:THIN GRAYISH FLUID"
    kind "entity"
    name "THIN GRAYISH FLUID"
    community 14
  ]
  node [
    id 949
    label "E:DINNER"
    kind "entity"
    name "DINNER"
    community 1
  ]
  node [
    id 950
    label "E:SUPPER"
    kind "entity"
    name "SUPPER"
    community 1
  ]
  node [
    id 951
    label "U:Novel-25646_00042#1"
    kind "unit"
    chunk_id "Novel-25646_00042"
    text "A soldier was shot in the side in a way that left a wound with a piece of loose skin forming a small opening, like a door leading into his stomach. A doctor who wanted to learn about the stomach hired him as a servant and studied him daily to observe the internal workings of the stomach."
    community 22
  ]
  node [
    id 952
    label "E:SOLDIER"
    kind "entity"
    name "SOLDIER"
    community 22
  ]
  node [
    id 953
    label "E:SIDE"
    kind "entity"
    name "SIDE"
    community 22
  ]
  node [
    id 954
    label "E:WOUND"
    kind "entity"
    name "WOUND"
    community 22
  ]
  node [
    id 955
    label "E:LOOSE SKIN"
    kind "entity"
    name "LOOSE SKIN"
    community 22
  ]
  node [
    id 956
    label "E:SMALL OPENING"
    kind "entity"
    name "SMALL OPENING"
    community 22
  ]
  node [
    id 957
    label "E:DOOR INTO STOMACH"
    kind "entity"
    name "DOOR INTO STOMACH"
    community 22
  ]
  node [
    id 958
    label "E:STUDIED"
    kind "entity"
    name "STUDIED"
    community 22
  ]
  node [
    id 959
    label "C:Novel-25646_00043"
    kind "chunk"
    chunk_id "Novel-25646_00043"
  ]
  node [
    id 960
    label "U:Novel-25646_00043#0"
    kind "unit"
    chunk_id "Novel-25646_00043"
    text "He would push aside a small flap of skin and insert any food into the stomach, then observe what happened, learning from the process and recording his findings so others could also benefit."
    community 6
  ]
  node [
    id 961
    label "E:LITTLE FLAP OF SKIN"
    kind "entity"
    name "LITTLE FLAP OF SKIN"
    community 6
  ]
  node [
    id 962
    label "E:LEARNING"
    kind "entity"
    name "LEARNING"
    community 6
  ]
  node [
    id 963
    label "E:RECORDING"
    kind "entity"
    name "RECORDING"
    community 6
  ]
  node [
    id 964
    label "E:OTHER PEOPLE"
    kind "entity"
    name "OTHER PEOPLE"
    community 6
  ]
  node [
    id 965
    label "U:Novel-25646_00043#1"
    kind "unit"
    chunk_id "Novel-25646_00043"
    text "Doctors have learned, through other methods not described here, how the body's food-bags transform food to support bodily functions."
    community 10
  ]
  node [
    id 966
    label "E:FOOD-BAGS"
    kind "entity"
    name "FOOD-BAGS"
    community 10
  ]
  node [
    id 967
    label "E:FUNCTIONS"
    kind "entity"
    name "FUNCTIONS"
    community 10
  ]
  node [
    id 968
    label "U:Novel-25646_00043#2"
    kind "unit"
    chunk_id "Novel-25646_00043"
    text "Mamma tells children at breakfast that eating oat-meal and milk helps them grow into big men or women, but the body parts such as stout arms and rosy cheeks do not resemble oat-meal or milk, so the food must be changed before it can reach and feed different parts of the body."
    community 12
  ]
  node [
    id 969
    label "E:MAMMA"
    kind "entity"
    name "MAMMA"
    community 12
  ]
  node [
    id 970
    label "E:OAT-MEAL"
    kind "entity"
    name "OAT-MEAL"
    community 12
  ]
  node [
    id 971
    label "E:STOUT ARM"
    kind "entity"
    name "STOUT ARM"
    community 12
  ]
  node [
    id 972
    label "E:ROSY CHEEKS"
    kind "entity"
    name "ROSY CHEEKS"
    community 12
  ]
  node [
    id 973
    label "E:BIG MAN OR WOMAN"
    kind "entity"
    name "BIG MAN OR WOMAN"
    community 12
  ]
  node [
    id 974
    label "E:FOOD CHANGE"
    kind "entity"
    name "FOOD CHANGE"
    community 12
  ]
  node [
    id 975
    label "E:OAT-MEAL AND MILK"
    kind "entity"
    name "OAT-MEAL AND MILK"
    community 12
  ]
  node [
    id 976
    label "E:GROW INTO BIG MAN OR WOMAN"
    kind "entity"
    name "GROW INTO BIG MAN OR WOMAN"
    community 12
  ]
  node [
    id 977
    label "E:TO FEED BODY PARTS"
    kind "entity"
    name "TO FEED BODY PARTS"
    community 12
  ]
  node [
    id 978
    label "U:Novel-25646_00043#3"
    kind "unit"
    chunk_id "Novel-25646_00043"
    text "After being mixed and prepared in the stomach, food is ready to be sent through the body, with portions going to bones, muscles, nerves and brain, skin, finger nails, hair, and eyes, each of which needs to be fed to grow."
    community 13
  ]
  node [
    id 979
    label "E:MIXED AND PREPARED"
    kind "entity"
    name "MIXED AND PREPARED"
    community 13
  ]
  node [
    id 980
    label "E:NERVES AND BRAIN"
    kind "entity"
    name "NERVES AND BRAIN"
    community 13
  ]
  node [
    id 981
    label "E:SKIN"
    kind "entity"
    name "SKIN"
    community 13
  ]
  node [
    id 982
    label "E:FINGER NAILES"
    kind "entity"
    name "FINGER NAILES"
    community 13
  ]
  node [
    id 983
    label "E:HAIR"
    kind "entity"
    name "HAIR"
    community 13
  ]
  node [
    id 984
    label "E:EYES"
    kind "entity"
    name "EYES"
    community 17
  ]
  node [
    id 985
    label "E:FEEDING"
    kind "entity"
    name "FEEDING"
    community 13
  ]
  node [
    id 986
    label "E:TO GROW"
    kind "entity"
    name "TO GROW"
    community 13
  ]
  node [
    id 987
    label "C:Novel-25646_00044"
    kind "chunk"
    chunk_id "Novel-25646_00044"
  ]
  node [
    id 988
    label "U:Novel-25646_00044#0"
    kind "unit"
    chunk_id "Novel-25646_00044"
    text "Each part of the body needs to be fed in order to grow. Children require daily intake of food to develop larger bones, muscles, and skin to cover their growing bodies. Every day, body parts wear out slightly and need to be repaired using new food. Adults also need food to support the ongoing repair and maintenance of their bodies."
    community 9
  ]
  node [
    id 989
    label "E:ADULTS"
    kind "entity"
    name "ADULTS"
    community 9
  ]
  node [
    id 990
    label "E:MENDING"
    kind "entity"
    name "MENDING"
    community 9
  ]
  node [
    id 991
    label "E:EVERY DAY"
    kind "entity"
    name "EVERY DAY"
    community 9
  ]
  node [
    id 992
    label "U:Novel-25646_00044#1"
    kind "unit"
    chunk_id "Novel-25646_00044"
    text "One way to care for the stomach is to give it only its own work to do. The teeth must perform their function faithfully before the stomach begins its work. The stomach also needs rest, just like a machine. Some children constantly eat apples, candy, or other foods, which prevents their stomachs from resting. If the stomach does not rest, it will wear out like a machine. The stomach cannot function well unless it is warm. Pouring ice-water into the stomach while food is changing into gray fluid stops the digestive process until the stomach warms up again."
    community 14
  ]
  node [
    id 993
    label "E:CANDY"
    kind "entity"
    name "CANDY"
    community 12
  ]
  node [
    id 994
    label "E:ICE-WATER"
    kind "entity"
    name "ICE-WATER"
    community 14
  ]
  node [
    id 995
    label "E:GRAY FLUID"
    kind "entity"
    name "GRAY FLUID"
    community 0
  ]
  node [
    id 996
    label "E:DIGESTIVE PROCESS"
    kind "entity"
    name "DIGESTIVE PROCESS"
    community 14
  ]
  node [
    id 997
    label "E:LIKE A MACHINE"
    kind "entity"
    name "LIKE A MACHINE"
    community 14
  ]
  node [
    id 998
    label "U:Novel-25646_00044#2"
    kind "unit"
    chunk_id "Novel-25646_00044"
    text "Alcohol affects the stomach, as illustrated by the man with a small door to his stomach. The man's stomach has a small opening, which may represent a vulnerability to alcohol's harmful effects."
    community 14
  ]
  node [
    id 999
    label "E:SMALL DOOR TO STOMACH"
    kind "entity"
    name "SMALL DOOR TO STOMACH"
    community 14
  ]
  node [
    id 1000
    label "C:Novel-25646_00045"
    kind "chunk"
    chunk_id "Novel-25646_00045"
  ]
  node [
    id 1001
    label "U:Novel-25646_00045#0"
    kind "unit"
    chunk_id "Novel-25646_00045"
    text "Alcohol harms the stomach by injuring the gastric juice, preventing it from mixing with food; it is carried away quickly but causes damage during its short stay, and repeated daily use may lead to sores on the stomach lining, potentially resulting in death if the stomach is severely damaged."
    community 5
  ]
  node [
    id 1002
    label "E:DRINK CONTAINING ALCOHOL"
    kind "entity"
    name "DRINK CONTAINING ALCOHOL"
    community 3
  ]
  node [
    id 1003
    label "E:SORES"
    kind "entity"
    name "SORES"
    community 3
  ]
  node [
    id 1004
    label "E:DEADLY EFFECTS"
    kind "entity"
    name "DEADLY EFFECTS"
    community 5
  ]
  node [
    id 1005
    label "E:STOMACH LINING"
    kind "entity"
    name "STOMACH LINING"
    community 14
  ]
  node [
    id 1006
    label "U:Novel-25646_00045#1"
    kind "unit"
    chunk_id "Novel-25646_00045"
    text "Tobacco makes the mouth very dry, causing more saliva to flow out to moisten it; tobacco juice mixes with saliva and must be spit out, which removes the saliva needed to prepare food; tobacco discolors teeth, causes bad sores in the mouth, and often leads to a disease of the throat."
    community 3
  ]
  node [
    id 1007
    label "E:SALIVA"
    kind "entity"
    name "SALIVA"
    community 3
  ]
  node [
    id 1008
    label "E:THROAT"
    kind "entity"
    name "THROAT"
    community 3
  ]
  node [
    id 1009
    label "E:DISEASE OF THE THROAT"
    kind "entity"
    name "DISEASE OF THE THROAT"
    community 3
  ]
  node [
    id 1010
    label "E:TOBACCO JUICE"
    kind "entity"
    name "TOBACCO JUICE"
    community 3
  ]
  node [
    id 1011
    label "E:TOBACCO JUICE IS SPIT OUT"
    kind "entity"
    name "TOBACCO JUICE IS SPIT OUT"
    community 3
  ]
  node [
    id 1012
    label "C:Novel-25646_00046"
    kind "chunk"
    chunk_id "Novel-25646_00046"
  ]
  node [
    id 1013
    label "U:Novel-25646_00046#0"
    kind "unit"
    chunk_id "Novel-25646_00046"
    text "Tobacco discolors the teeth, causes bad sores in the mouth, and often leads to a disease of the throat."
    community 3
  ]
  node [
    id 1014
    label "E:BAD SORES"
    kind "entity"
    name "BAD SORES"
    community 3
  ]
  node [
    id 1015
    label "E:DISEASE"
    kind "entity"
    name "DISEASE"
    community 3
  ]
  node [
    id 1016
    label "U:Novel-25646_00046#1"
    kind "unit"
    chunk_id "Novel-25646_00046"
    text "The neatness and comfort left by people can indicate where they have been."
    community 7
  ]
  node [
    id 1017
    label "E:NEATNESS"
    kind "entity"
    name "NEATNESS"
    community 7
  ]
  node [
    id 1018
    label "E:COMFORT"
    kind "entity"
    name "COMFORT"
    community 7
  ]
  node [
    id 1019
    label "U:Novel-25646_00046#2"
    kind "unit"
    chunk_id "Novel-25646_00046"
    text "The presence of a dirty floor, street, and air made unfit to breathe due to smoke and the strong, bad smell of old tobacco from a tobacco user's pipe, cigar, breath, and clothes indicates where a tobacco user has been."
    community 6
  ]
  node [
    id 1020
    label "E:DIRTY FLOOR"
    kind "entity"
    name "DIRTY FLOOR"
    community 6
  ]
  node [
    id 1021
    label "E:OLD TOBACCO"
    kind "entity"
    name "OLD TOBACCO"
    community 6
  ]
  node [
    id 1022
    label "E:PIPE"
    kind "entity"
    name "PIPE"
    community 6
  ]
  node [
    id 1023
    label "E:CLOTHES"
    kind "entity"
    name "CLOTHES"
    community 13
  ]
  node [
    id 1024
    label "E:TOBACCO USER"
    kind "entity"
    name "TOBACCO USER"
    community 6
  ]
  node [
    id 1025
    label "U:Novel-25646_00046#3"
    kind "unit"
    chunk_id "Novel-25646_00046"
    text "Review questions include inquiries about organs, the functions of front and back teeth, the composition of teeth, causes of toothache, how enamel is broken, the use of a tooth-pick, the importance of brushing teeth, when to brush, the bones forming a case or box, the upper and lower rooms of this box, organs in the chest and abdomen, the stomach, its lining, the actions of the stomach and gastric juice on food, how the stomach's function was discovered, why all food must be changed, and why food is needed."
    community 14
  ]
  node [
    id 1026
    label "E:TEETH COMPOSITION"
    kind "entity"
    name "TEETH COMPOSITION"
    community 14
  ]
  node [
    id 1027
    label "E:TOOTHACHE"
    kind "entity"
    name "TOOTHACHE"
    community 14
  ]
  node [
    id 1028
    label "E:BRUSHING TEETH"
    kind "entity"
    name "BRUSHING TEETH"
    community 14
  ]
  node [
    id 1029
    label "E:TIME FOR BRUSHING"
    kind "entity"
    name "TIME FOR BRUSHING"
    community 14
  ]
  node [
    id 1030
    label "E:UPPER ROOM"
    kind "entity"
    name "UPPER ROOM"
    community 14
  ]
  node [
    id 1031
    label "E:LOWER ROOM"
    kind "entity"
    name "LOWER ROOM"
    community 14
  ]
  node [
    id 1032
    label "E:LINING"
    kind "entity"
    name "LINING"
    community 14
  ]
  node [
    id 1033
    label "E:STOMACH FUNCTION"
    kind "entity"
    name "STOMACH FUNCTION"
    community 14
  ]
  node [
    id 1034
    label "E:NEED FOR FOOD"
    kind "entity"
    name "NEED FOR FOOD"
    community 14
  ]
  node [
    id 1035
    label "E:ORAL FUNCTION"
    kind "entity"
    name "ORAL FUNCTION"
    community 14
  ]
  node [
    id 1036
    label "E:CHOMPING AND CHURNING"
    kind "entity"
    name "CHOMPING AND CHURNING"
    community 14
  ]
  node [
    id 1037
    label "E:ENAMEL AND DENTIN"
    kind "entity"
    name "ENAMEL AND DENTIN"
    community 14
  ]
  node [
    id 1038
    label "E:INFECTION OR DAMAGE TO TEETH"
    kind "entity"
    name "INFECTION OR DAMAGE TO TEETH"
    community 14
  ]
  node [
    id 1039
    label "E:BRAZING OR HARD FOOD"
    kind "entity"
    name "BRAZING OR HARD FOOD"
    community 14
  ]
  node [
    id 1040
    label "E:REMOVE FOOD PARTICLES"
    kind "entity"
    name "REMOVE FOOD PARTICLES"
    community 14
  ]
  node [
    id 1041
    label "E:PREVENT DISEASE"
    kind "entity"
    name "PREVENT DISEASE"
    community 14
  ]
  node [
    id 1042
    label "E:AFTER MEALS AND BEFORE SLEEP"
    kind "entity"
    name "AFTER MEALS AND BEFORE SLEEP"
    community 14
  ]
  node [
    id 1043
    label "E:JAW"
    kind "entity"
    name "JAW"
    community 14
  ]
  node [
    id 1044
    label "E:HEART AND LUNGS"
    kind "entity"
    name "HEART AND LUNGS"
    community 14
  ]
  node [
    id 1045
    label "E:STOMACH AND INTESTINES"
    kind "entity"
    name "STOMACH AND INTESTINES"
    community 14
  ]
  node [
    id 1046
    label "E:DIGESTIVE SYSTEM"
    kind "entity"
    name "DIGESTIVE SYSTEM"
    community 14
  ]
  node [
    id 1047
    label "E:SECRETE DIGESTIVE ENZYMES"
    kind "entity"
    name "SECRETE DIGESTIVE ENZYMES"
    community 14
  ]
  node [
    id 1048
    label "E:STOMACH AND GASTRIC JUICE"
    kind "entity"
    name "STOMACH AND GASTRIC JUICE"
    community 14
  ]
  node [
    id 1049
    label "E:EATEN FOOD"
    kind "entity"
    name "EATEN FOOD"
    community 14
  ]
  node [
    id 1050
    label "E:EXPERIMENTAL STUDIES"
    kind "entity"
    name "EXPERIMENTAL STUDIES"
    community 14
  ]
  node [
    id 1051
    label "E:ALL FOOD"
    kind "entity"
    name "ALL FOOD"
    community 14
  ]
  node [
    id 1052
    label "E:TO BE ABSORBED"
    kind "entity"
    name "TO BE ABSORBED"
    community 14
  ]
  node [
    id 1053
    label "E:ENERGY AND GROWTH"
    kind "entity"
    name "ENERGY AND GROWTH"
    community 14
  ]
  node [
    id 1054
    label "C:Novel-25646_00047"
    kind "chunk"
    chunk_id "Novel-25646_00047"
  ]
  node [
    id 1055
    label "U:Novel-25646_00047#0"
    kind "unit"
    chunk_id "Novel-25646_00047"
    text "All the food we eat must be changed because the body needs to break it down to absorb nutrients for growth and to maintain strength and health."
    community 7
  ]
  node [
    id 1056
    label "U:Novel-25646_00047#1"
    kind "unit"
    chunk_id "Novel-25646_00047"
    text "People need food to grow, to maintain strength, and to stay healthy."
    community 7
  ]
  node [
    id 1057
    label "U:Novel-25646_00047#2"
    kind "unit"
    chunk_id "Novel-25646_00047"
    text "People who are not growing still need food to maintain strength and health."
    community 7
  ]
  node [
    id 1058
    label "U:Novel-25646_00047#3"
    kind "unit"
    chunk_id "Novel-25646_00047"
    text "Alcohol reduces the amount of gastric juice and damages the stomach lining."
    community 14
  ]
  node [
    id 1059
    label "U:Novel-25646_00047#4"
    kind "unit"
    chunk_id "Novel-25646_00047"
    text "Saliva helps in the initial digestion of food by breaking down starches and moistening food for easier swallowing."
    community 3
  ]
  node [
    id 1060
    label "E:DIGESTION"
    kind "entity"
    name "DIGESTION"
    community 14
  ]
  node [
    id 1061
    label "E:STARCHES"
    kind "entity"
    name "STARCHES"
    community 3
  ]
  node [
    id 1062
    label "U:Novel-25646_00047#5"
    kind "unit"
    chunk_id "Novel-25646_00047"
    text "Spitting habit injures a person by spreading germs and causing infections in the mouth and surrounding areas."
    community 16
  ]
  node [
    id 1063
    label "E:GERMS"
    kind "entity"
    name "GERMS"
    community 16
  ]
  node [
    id 1064
    label "E:INFECTIONS"
    kind "entity"
    name "INFECTIONS"
    community 16
  ]
  node [
    id 1065
    label "U:Novel-25646_00047#6"
    kind "unit"
    chunk_id "Novel-25646_00047"
    text "Tobacco affects the teeth by causing discoloration and weakening of the enamel, and harms the mouth by increasing the risk of infections and bad breath."
    community 16
  ]
  node [
    id 1066
    label "E:DISCOLORATION"
    kind "entity"
    name "DISCOLORATION"
    community 16
  ]
  node [
    id 1067
    label "E:BAD BREATH"
    kind "entity"
    name "BAD BREATH"
    community 16
  ]
  node [
    id 1068
    label "U:Novel-25646_00047#7"
    kind "unit"
    chunk_id "Novel-25646_00047"
    text "Tobacco users annoy other people by producing strong odors and visible smoke that is unpleasant to others."
    community 6
  ]
  node [
    id 1069
    label "E:ODORS"
    kind "entity"
    name "ODORS"
    community 6
  ]
  node [
    id 1070
    label "E:UNPLEASANT"
    kind "entity"
    name "UNPLEASANT"
    community 6
  ]
  node [
    id 1071
    label "U:Novel-25646_00047#8"
    kind "unit"
    chunk_id "Novel-25646_00047"
    text "The food is partly prepared by the liver and some other organs."
    community 4
  ]
  node [
    id 1072
    label "U:Novel-25646_00047#9"
    kind "unit"
    chunk_id "Novel-25646_00047"
    text "A large part of the body is made of water, so people need to drink water and have it used in preparing food."
    community 2
  ]
  node [
    id 1073
    label "E:FOOD PREPARATION"
    kind "entity"
    name "FOOD PREPARATION"
    community 2
  ]
  node [
    id 1074
    label "U:Novel-25646_00047#10"
    kind "unit"
    chunk_id "Novel-25646_00047"
    text "Water comes from clouds and is stored in cisterns or springs in the ground."
    community 2
  ]
  node [
    id 1075
    label "E:CLOUDS"
    kind "entity"
    name "CLOUDS"
    community 2
  ]
  node [
    id 1076
    label "E:CISTERN"
    kind "entity"
    name "CISTERN"
    community 2
  ]
  node [
    id 1077
    label "E:SPRING"
    kind "entity"
    name "SPRING"
    community 2
  ]
  node [
    id 1078
    label "U:Novel-25646_00047#11"
    kind "unit"
    chunk_id "Novel-25646_00047"
    text "Pipes are laid to lead water from cisterns or springs to houses."
    community 2
  ]
  node [
    id 1079
    label "E:PIPES"
    kind "entity"
    name "PIPES"
    community 2
  ]
  node [
    id 1080
    label "E:HOUSES"
    kind "entity"
    name "HOUSES"
    community 2
  ]
  node [
    id 1081
    label "U:Novel-25646_00047#12"
    kind "unit"
    chunk_id "Novel-25646_00047"
    text "Men dig down to reach a spring and make a well from which they can pump or dip water using a bucket."
    community 2
  ]
  node [
    id 1082
    label "E:PUMP"
    kind "entity"
    name "PUMP"
    community 2
  ]
  node [
    id 1083
    label "E:BUCKET"
    kind "entity"
    name "BUCKET"
    community 2
  ]
  node [
    id 1084
    label "U:Novel-25646_00047#13"
    kind "unit"
    chunk_id "Novel-25646_00047"
    text "Water that has been standing in lead pipes may have lead mixed with it."
    community 2
  ]
  node [
    id 1085
    label "E:LEAD PIPES"
    kind "entity"
    name "LEAD PIPES"
    community 2
  ]
  node [
    id 1086
    label "E:LEAD"
    kind "entity"
    name "LEAD"
    community 2
  ]
  node [
    id 1087
    label "C:Novel-25646_00048"
    kind "chunk"
    chunk_id "Novel-25646_00048"
  ]
  node [
    id 1088
    label "U:Novel-25646_00048#0"
    kind "unit"
    chunk_id "Novel-25646_00048"
    text "Water that has been standing in lead pipes may contain lead mixed with it, and drinking such water is very likely to poison a person."
    community 2
  ]
  node [
    id 1089
    label "U:Novel-25646_00048#1"
    kind "unit"
    chunk_id "Novel-25646_00048"
    text "Water from a well that is near a drain or a stable is almost certain to have impurities, and drinking it may make a person very sick."
    community 2
  ]
  node [
    id 1090
    label "E:DRAIN"
    kind "entity"
    name "DRAIN"
    community 2
  ]
  node [
    id 1091
    label "E:STABLE"
    kind "entity"
    name "STABLE"
    community 2
  ]
  node [
    id 1092
    label "E:IMPURITIES"
    kind "entity"
    name "IMPURITIES"
    community 0
  ]
  node [
    id 1093
    label "U:Novel-25646_00048#2"
    kind "unit"
    chunk_id "Novel-25646_00048"
    text "It is better to go thirsty until good water is available, as drinking unsafe water can be harmful."
    community 1
  ]
  node [
    id 1094
    label "E:GOOD WATER"
    kind "entity"
    name "GOOD WATER"
    community 1
  ]
  node [
    id 1095
    label "E:THIRST"
    kind "entity"
    name "THIRST"
    community 1
  ]
  node [
    id 1096
    label "E:UNSAFE WATER"
    kind "entity"
    name "UNSAFE WATER"
    community 1
  ]
  node [
    id 1097
    label "U:Novel-25646_00048#3"
    kind "unit"
    chunk_id "Novel-25646_00048"
    text "A sufficient quantity of pure water is just as important as good food for human health."
    community 0
  ]
  node [
    id 1098
    label "E:PURE WATER"
    kind "entity"
    name "PURE WATER"
    community 0
  ]
  node [
    id 1099
    label "E:GOOD FOOD"
    kind "entity"
    name "GOOD FOOD"
    community 0
  ]
  node [
    id 1100
    label "U:Novel-25646_00048#4"
    kind "unit"
    chunk_id "Novel-25646_00048"
    text "The human body does not drink all the water it needs; a large part of it is taken in through food, especially fruits, vegetables, beefsteak, and bread."
    community 1
  ]
  node [
    id 1101
    label "E:FRUITS"
    kind "entity"
    name "FRUITS"
    community 1
  ]
  node [
    id 1102
    label "E:VEGETABLES"
    kind "entity"
    name "VEGETABLES"
    community 1
  ]
  node [
    id 1103
    label "E:BEEFSTEAK"
    kind "entity"
    name "BEEFSTEAK"
    community 1
  ]
  node [
    id 1104
    label "U:Novel-25646_00048#5"
    kind "unit"
    chunk_id "Novel-25646_00048"
    text "Bones need lime, and a bone that has been in the fire is nothing but crumbling lime."
    community 8
  ]
  node [
    id 1105
    label "E:CRUMBLING LIME"
    kind "entity"
    name "CRUMBLING LIME"
    community 8
  ]
  node [
    id 1106
    label "U:Novel-25646_00048#6"
    kind "unit"
    chunk_id "Novel-25646_00048"
    text "Lime cannot be eaten directly, but grass and grains absorb it from the earth, and cows eat grass and turn it into milk, from which humans get lime to feed their bones."
    community 1
  ]
  node [
    id 1107
    label "E:GRASS"
    kind "entity"
    name "GRASS"
    community 1
  ]
  node [
    id 1108
    label "E:COWS"
    kind "entity"
    name "COWS"
    community 1
  ]
  node [
    id 1109
    label "E:HUMANS"
    kind "entity"
    name "HUMANS"
    community 1
  ]
  node [
    id 1110
    label "E:EARTH"
    kind "entity"
    name "EARTH"
    community 1
  ]
  node [
    id 1111
    label "U:Novel-25646_00048#7"
    kind "unit"
    chunk_id "Novel-25646_00048"
    text "Grain growing in the field takes up lime and other necessary substances, which it cannot be eaten directly."
    community 1
  ]
  node [
    id 1112
    label "E:GRAIN"
    kind "entity"
    name "GRAIN"
    community 1
  ]
  node [
    id 1113
    label "E:FIELD"
    kind "entity"
    name "FIELD"
    community 1
  ]
  node [
    id 1114
    label "E:NECESSARY SUBSTANCES"
    kind "entity"
    name "NECESSARY SUBSTANCES"
    community 1
  ]
  node [
    id 1115
    label "C:Novel-25646_00049"
    kind "chunk"
    chunk_id "Novel-25646_00049"
  ]
  node [
    id 1116
    label "U:Novel-25646_00049#0"
    kind "unit"
    chunk_id "Novel-25646_00049"
    text "The lime that becomes part of the grain is found in bread, oat-meal porridge, and other foods."
    community 1
  ]
  node [
    id 1117
    label "E:OAT-MEAL PORRIDGE"
    kind "entity"
    name "OAT-MEAL PORRIDGE"
    community 1
  ]
  node [
    id 1118
    label "E:OTHER FOODS"
    kind "entity"
    name "OTHER FOODS"
    community 1
  ]
  node [
    id 1119
    label "U:Novel-25646_00049#1"
    kind "unit"
    chunk_id "Novel-25646_00049"
    text "Animals need salt, and children living in the country observe that cows and sheep eagerly lick up the salt given by farmers. Wild cattle and buffaloes also seek out salt springs and gather in large herds to obtain salt."
    community 1
  ]
  node [
    id 1120
    label "E:ANIMALS"
    kind "entity"
    name "ANIMALS"
    community 1
  ]
  node [
    id 1121
    label "E:SHEEP"
    kind "entity"
    name "SHEEP"
    community 1
  ]
  node [
    id 1122
    label "E:WILD CATTLE"
    kind "entity"
    name "WILD CATTLE"
    community 1
  ]
  node [
    id 1123
    label "E:BUFFALOES"
    kind "entity"
    name "BUFFALOES"
    community 1
  ]
  node [
    id 1124
    label "E:SALT SPRINGS"
    kind "entity"
    name "SALT SPRINGS"
    community 1
  ]
  node [
    id 1125
    label "E:HERDS"
    kind "entity"
    name "HERDS"
    community 1
  ]
  node [
    id 1126
    label "U:Novel-25646_00049#2"
    kind "unit"
    chunk_id "Novel-25646_00049"
    text "Humans also need some salt mixed with their food, either during cooking or afterward, as a small amount is naturally present in food itself."
    community 1
  ]
  node [
    id 1127
    label "E:COOKING"
    kind "entity"
    name "COOKING"
    community 1
  ]
  node [
    id 1128
    label "E:AFTERWARD"
    kind "entity"
    name "AFTERWARD"
    community 1
  ]
  node [
    id 1129
    label "U:Novel-25646_00049#3"
    kind "unit"
    chunk_id "Novel-25646_00049"
    text "Muscles are lean meat, or flesh, and therefore require flesh-making foods such as milk, grains like wheat, corn, and oats, and also meat and eggs."
    community 1
  ]
  node [
    id 1130
    label "E:OATS"
    kind "entity"
    name "OATS"
    community 1
  ]
  node [
    id 1131
    label "E:EGGS"
    kind "entity"
    name "EGGS"
    community 1
  ]
  node [
    id 1132
    label "E:FLESH-MAKING FOODS"
    kind "entity"
    name "FLESH-MAKING FOODS"
    community 1
  ]
  node [
    id 1133
    label "U:Novel-25646_00049#4"
    kind "unit"
    chunk_id "Novel-25646_00049"
    text "Most flesh-making foods ultimately come from the ground, as meat and eggs are produced from the grain, grass, and other vegetables that cattle and hens consume."
    community 1
  ]
  node [
    id 1134
    label "E:CATTLE"
    kind "entity"
    name "CATTLE"
    community 1
  ]
  node [
    id 1135
    label "E:HENS"
    kind "entity"
    name "HENS"
    community 1
  ]
  node [
    id 1136
    label "U:Novel-25646_00049#5"
    kind "unit"
    chunk_id "Novel-25646_00049"
    text "The body needs fat for cushioning and wrapping to stay warm and feel comfortable, so certain foods that make fat are necessary. There are right and wrong places for fat, as well as for other things in the world."
    community 7
  ]
  node [
    id 1137
    label "E:CUSHIONING"
    kind "entity"
    name "CUSHIONING"
    community 7
  ]
  node [
    id 1138
    label "E:WRAPPINGS"
    kind "entity"
    name "WRAPPINGS"
    community 7
  ]
  node [
    id 1139
    label "E:FOOD THAT MAKES FAT"
    kind "entity"
    name "FOOD THAT MAKES FAT"
    community 7
  ]
  node [
    id 1140
    label "E:RIGHT PLACES"
    kind "entity"
    name "RIGHT PLACES"
    community 7
  ]
  node [
    id 1141
    label "E:WRONG PLACES"
    kind "entity"
    name "WRONG PLACES"
    community 7
  ]
  node [
    id 1142
    label "E:IN THE WORLD"
    kind "entity"
    name "IN THE WORLD"
    community 7
  ]
  node [
    id 1143
    label "C:Novel-25646_00050"
    kind "chunk"
    chunk_id "Novel-25646_00050"
  ]
  node [
    id 1144
    label "U:Novel-25646_00050#0"
    kind "unit"
    chunk_id "Novel-25646_00050"
    text "When alcohol causes fat to be deposited in muscles, this is bad fat in the wrong place. Good fat for body parts that need it comes from fat-making foods."
    community 15
  ]
  node [
    id 1145
    label "E:GOOD FAT"
    kind "entity"
    name "GOOD FAT"
    community 15
  ]
  node [
    id 1146
    label "E:FAT-MAKING FOODS"
    kind "entity"
    name "FAT-MAKING FOODS"
    community 15
  ]
  node [
    id 1147
    label "U:Novel-25646_00050#1"
    kind "unit"
    chunk_id "Novel-25646_00050"
    text "In cold weather, the body needs more fatty food than in summer, similar to how people in cold countries require such food year-round."
    community 10
  ]
  node [
    id 1148
    label "E:COLD WEATHER"
    kind "entity"
    name "COLD WEATHER"
    community 10
  ]
  node [
    id 1149
    label "E:SUMMER"
    kind "entity"
    name "SUMMER"
    community 10
  ]
  node [
    id 1150
    label "E:FATTY FOOD"
    kind "entity"
    name "FATTY FOOD"
    community 10
  ]
  node [
    id 1151
    label "E:COLD COUNTRIES"
    kind "entity"
    name "COLD COUNTRIES"
    community 10
  ]
  node [
    id 1152
    label "U:Novel-25646_00050#2"
    kind "unit"
    chunk_id "Novel-25646_00050"
    text "The Esquimaux, who live in snowy and icy regions, catch many walrus and seals and consume large amounts of fatty meat."
    community 18
  ]
  node [
    id 1153
    label "E:ESQUIMAUX"
    kind "entity"
    name "ESQUIMAUX"
    community 18
  ]
  node [
    id 1154
    label "E:SNOWY AND ICY REGIONS"
    kind "entity"
    name "SNOWY AND ICY REGIONS"
    community 18
  ]
  node [
    id 1155
    label "E:WALRUS"
    kind "entity"
    name "WALRUS"
    community 18
  ]
  node [
    id 1156
    label "E:SEAL"
    kind "entity"
    name "SEAL"
    community 18
  ]
  node [
    id 1157
    label "E:FATTY MEAT"
    kind "entity"
    name "FATTY MEAT"
    community 18
  ]
  node [
    id 1158
    label "U:Novel-25646_00050#3"
    kind "unit"
    chunk_id "Novel-25646_00050"
    text "One would not be healthy unless they consumed some fat, butter, or oil."
    community 7
  ]
  node [
    id 1159
    label "E:BUTTER"
    kind "entity"
    name "BUTTER"
    community 7
  ]
  node [
    id 1160
    label "E:OIL"
    kind "entity"
    name "OIL"
    community 7
  ]
  node [
    id 1161
    label "U:Novel-25646_00050#4"
    kind "unit"
    chunk_id "Novel-25646_00050"
    text "Sugar and starch, along with cream, rice, butter, and fat meat, will all make fat."
    community 7
  ]
  node [
    id 1162
    label "E:CREAM"
    kind "entity"
    name "CREAM"
    community 7
  ]
  node [
    id 1163
    label "E:RICE"
    kind "entity"
    name "RICE"
    community 7
  ]
  node [
    id 1164
    label "U:Novel-25646_00050#5"
    kind "unit"
    chunk_id "Novel-25646_00050"
    text "Milk helps make muscle, fat, and bones, and is considered the best kind of food."
    community 1
  ]
  node [
    id 1165
    label "E:BEST KIND OF FOOD"
    kind "entity"
    name "BEST KIND OF FOOD"
    community 1
  ]
  node [
    id 1166
    label "U:Novel-25646_00050#6"
    kind "unit"
    chunk_id "Novel-25646_00050"
    text "Fat meat comes from animals that are well fed on grain and grass; sugar comes from sugar-cane, maple-trees, or beets; oil comes from olive-trees; butter comes from cream; and starch comes from potatoes, corn, rice, and other grains."
    community 7
  ]
  node [
    id 1167
    label "E:SUGAR-CANE"
    kind "entity"
    name "SUGAR-CANE"
    community 7
  ]
  node [
    id 1168
    label "E:MAPLE-TREES"
    kind "entity"
    name "MAPLE-TREES"
    community 7
  ]
  node [
    id 1169
    label "E:BEETS"
    kind "entity"
    name "BEETS"
    community 7
  ]
  node [
    id 1170
    label "E:OLIVE-TREES"
    kind "entity"
    name "OLIVE-TREES"
    community 7
  ]
  node [
    id 1171
    label "E:OTHER GRAINS"
    kind "entity"
    name "OTHER GRAINS"
    community 7
  ]
  node [
    id 1172
    label "E:ANIMALS WELL FED ON GRAIN AND GRASS"
    kind "entity"
    name "ANIMALS WELL FED ON GRAIN AND GRASS"
    community 7
  ]
  node [
    id 1173
    label "U:Novel-25646_00050#7"
    kind "unit"
    chunk_id "Novel-25646_00050"
    text "Green apples and other unripe fruits are not yet ready to be eaten."
    community 3
  ]
  node [
    id 1174
    label "E:GREEN APPLES"
    kind "entity"
    name "GREEN APPLES"
    community 3
  ]
  node [
    id 1175
    label "E:UNRIPE FRUITS"
    kind "entity"
    name "UNRIPE FRUITS"
    community 3
  ]
  node [
    id 1176
    label "E:EATING"
    kind "entity"
    name "EATING"
    community 3
  ]
  node [
    id 1177
    label "U:Novel-25646_00050#8"
    kind "unit"
    chunk_id "Novel-25646_00050"
    text "The starch consumed as food must be converted into sugar before it can mix with the blood and help feed the body."
    community 3
  ]
  node [
    id 1178
    label "E:BLOOD"
    kind "entity"
    name "BLOOD"
    community 0
  ]
  node [
    id 1179
    label "E:FEEDING THE BODY"
    kind "entity"
    name "FEEDING THE BODY"
    community 3
  ]
  node [
    id 1180
    label "U:Novel-25646_00050#9"
    kind "unit"
    chunk_id "Novel-25646_00050"
    text "As the sun ripens fruit, it transforms its starch into sugar."
    community 3
  ]
  node [
    id 1181
    label "E:SUN"
    kind "entity"
    name "SUN"
    community 3
  ]
  node [
    id 1182
    label "E:RIPE"
    kind "entity"
    name "RIPE"
    community 3
  ]
  node [
    id 1183
    label "C:Novel-25646_00051"
    kind "chunk"
    chunk_id "Novel-25646_00051"
  ]
  node [
    id 1184
    label "U:Novel-25646_00051#0"
    kind "unit"
    chunk_id "Novel-25646_00051"
    text "As the sun ripens fruit, it converts starch into sugar, which can be observed by the difference in taste between ripe and unripe apples."
    community 3
  ]
  node [
    id 1185
    label "E:RIPE APPLES"
    kind "entity"
    name "RIPE APPLES"
    community 3
  ]
  node [
    id 1186
    label "E:UNRIPE APPLES"
    kind "entity"
    name "UNRIPE APPLES"
    community 3
  ]
  node [
    id 1187
    label "U:Novel-25646_00051#1"
    kind "unit"
    chunk_id "Novel-25646_00051"
    text "Most children enjoy candy so much that they may consume excessive sugar, which is harmful to their health."
    community 12
  ]
  node [
    id 1188
    label "U:Novel-25646_00051#2"
    kind "unit"
    chunk_id "Novel-25646_00051"
    text "One would starve if fed only on sugar, and it is not safe to consume candy that contains poison, even if it is labeled as pure and white."
    community 12
  ]
  node [
    id 1189
    label "E:PURE WHITE CANDY"
    kind "entity"
    name "PURE WHITE CANDY"
    community 12
  ]
  node [
    id 1190
    label "E:HUMAN BEING"
    kind "entity"
    name "HUMAN BEING"
    community 12
  ]
  node [
    id 1191
    label "U:Novel-25646_00051#3"
    kind "unit"
    chunk_id "Novel-25646_00051"
    text "A simple test to determine if white candy is made of pure sugar involves placing a piece in water; if it dissolves completely, it is pure sugar; if not, white earth remains at the bottom, indicating impurity."
    community 2
  ]
  node [
    id 1192
    label "E:WHITE CANDY"
    kind "entity"
    name "WHITE CANDY"
    community 2
  ]
  node [
    id 1193
    label "E:WHITE EARTH"
    kind "entity"
    name "WHITE EARTH"
    community 2
  ]
  node [
    id 1194
    label "E:TEST"
    kind "entity"
    name "TEST"
    community 2
  ]
  node [
    id 1195
    label "E:DISSOLVES COMPLETELY IF MADE OF PURE SUGAR"
    kind "entity"
    name "DISSOLVES COMPLETELY IF MADE OF PURE SUGAR"
    community 2
  ]
  node [
    id 1196
    label "E:LEAVES WHITE EARTH AT BOTTOM IF NOT PURE"
    kind "entity"
    name "LEAVES WHITE EARTH AT BOTTOM IF NOT PURE"
    community 2
  ]
  node [
    id 1197
    label "E:ANYBODY"
    kind "entity"
    name "ANYBODY"
    community 2
  ]
  node [
    id 1198
    label "U:Novel-25646_00051#4"
    kind "unit"
    chunk_id "Novel-25646_00051"
    text "Candy-makers sometimes substitute white earth for sugar in candy because it is cheaper than sugar."
    community 2
  ]
  node [
    id 1199
    label "E:CANDY-MAKERS"
    kind "entity"
    name "CANDY-MAKERS"
    community 2
  ]
  node [
    id 1200
    label "E:CHEAPER"
    kind "entity"
    name "CHEAPER"
    community 2
  ]
  node [
    id 1201
    label "C:Novel-25646_00052"
    kind "chunk"
    chunk_id "Novel-25646_00052"
  ]
  node [
    id 1202
    label "U:Novel-25646_00052#0"
    kind "unit"
    chunk_id "Novel-25646_00052"
    text "Water that has been standing in lead pipes is not safe to drink because lead can leach into the water and pose health risks."
    community 2
  ]
  node [
    id 1203
    label "U:Novel-25646_00052#1"
    kind "unit"
    chunk_id "Novel-25646_00052"
    text "Water from a well near a drain or a stable is not fit to drink because contamination from the surrounding environment may occur."
    community 2
  ]
  node [
    id 1204
    label "E:WELL WATER"
    kind "entity"
    name "WELL WATER"
    community 2
  ]
  node [
    id 1205
    label "U:Novel-25646_00052#2"
    kind "unit"
    chunk_id "Novel-25646_00052"
    text "Bones need calcium and phosphorus to maintain strength and structure."
    community 1
  ]
  node [
    id 1206
    label "E:CALCIUM"
    kind "entity"
    name "CALCIUM"
    community 1
  ]
  node [
    id 1207
    label "E:PHOSPHORUS"
    kind "entity"
    name "PHOSPHORUS"
    community 1
  ]
  node [
    id 1208
    label "U:Novel-25646_00052#3"
    kind "unit"
    chunk_id "Novel-25646_00052"
    text "Lime, which is calcium carbonate, is obtained from food sources such as dairy products and leafy greens, and is essential for bone formation."
    community 1
  ]
  node [
    id 1209
    label "E:CALCIUM CARBONATE"
    kind "entity"
    name "CALCIUM CARBONATE"
    community 1
  ]
  node [
    id 1210
    label "E:DAIRY PRODUCTS"
    kind "entity"
    name "DAIRY PRODUCTS"
    community 1
  ]
  node [
    id 1211
    label "E:LEAFY GREENS"
    kind "entity"
    name "LEAFY GREENS"
    community 1
  ]
  node [
    id 1212
    label "U:Novel-25646_00052#4"
    kind "unit"
    chunk_id "Novel-25646_00052"
    text "Salt is said to be essential for maintaining body fluids and nerve function, and it is commonly used in food."
    community 1
  ]
  node [
    id 1213
    label "E:BODY FLUIDS"
    kind "entity"
    name "BODY FLUIDS"
    community 1
  ]
  node [
    id 1214
    label "U:Novel-25646_00052#5"
    kind "unit"
    chunk_id "Novel-25646_00052"
    text "Muscles need protein and certain minerals such as potassium and magnesium to function properly."
    community 1
  ]
  node [
    id 1215
    label "E:PROTEIN"
    kind "entity"
    name "PROTEIN"
    community 1
  ]
  node [
    id 1216
    label "E:POTASSIUM"
    kind "entity"
    name "POTASSIUM"
    community 1
  ]
  node [
    id 1217
    label "E:MAGNESIUM"
    kind "entity"
    name "MAGNESIUM"
    community 1
  ]
  node [
    id 1218
    label "U:Novel-25646_00052#6"
    kind "unit"
    chunk_id "Novel-25646_00052"
    text "Flesh-making foods include meat, eggs, dairy products, and legumes, which provide protein for tissue growth and repair."
    community 1
  ]
  node [
    id 1219
    label "E:LEGUMES"
    kind "entity"
    name "LEGUMES"
    community 1
  ]
  node [
    id 1220
    label "U:Novel-25646_00052#7"
    kind "unit"
    chunk_id "Novel-25646_00052"
    text "Fat in the body is necessary for energy storage, insulation, and the absorption of fat-soluble vitamins."
    community 7
  ]
  node [
    id 1221
    label "E:ENERGY STORAGE"
    kind "entity"
    name "ENERGY STORAGE"
    community 7
  ]
  node [
    id 1222
    label "E:INSULATION"
    kind "entity"
    name "INSULATION"
    community 7
  ]
  node [
    id 1223
    label "E:VITAMINS"
    kind "entity"
    name "VITAMINS"
    community 7
  ]
  node [
    id 1224
    label "E:FAT-SOLUBLE VITAMINS"
    kind "entity"
    name "FAT-SOLUBLE VITAMINS"
    community 7
  ]
  node [
    id 1225
    label "U:Novel-25646_00052#8"
    kind "unit"
    chunk_id "Novel-25646_00052"
    text "Fat made by alcohol is harmful and can damage the liver and interfere with normal bodily functions."
    community 4
  ]
  node [
    id 1226
    label "E:ALCOHOL-MADE FAT"
    kind "entity"
    name "ALCOHOL-MADE FAT"
    community 4
  ]
  node [
    id 1227
    label "E:BODILY FUNCTIONS"
    kind "entity"
    name "BODILY FUNCTIONS"
    community 4
  ]
  node [
    id 1228
    label "U:Novel-25646_00052#9"
    kind "unit"
    chunk_id "Novel-25646_00052"
    text "Foods that make good fat include oils, nuts, seeds, and fatty fish, which are rich in healthy fats."
    community 15
  ]
  node [
    id 1229
    label "E:OILS"
    kind "entity"
    name "OILS"
    community 15
  ]
  node [
    id 1230
    label "E:NUTS"
    kind "entity"
    name "NUTS"
    community 15
  ]
  node [
    id 1231
    label "E:FATTY FISH"
    kind "entity"
    name "FATTY FISH"
    community 15
  ]
  node [
    id 1232
    label "E:HEALTHY FATS"
    kind "entity"
    name "HEALTHY FATS"
    community 15
  ]
  node [
    id 1233
    label "U:Novel-25646_00052#10"
    kind "unit"
    chunk_id "Novel-25646_00052"
    text "The Esquimaux eat primarily fish, seals, and other marine animals, which provide essential fats and proteins."
    community 18
  ]
  node [
    id 1234
    label "E:SEALS"
    kind "entity"
    name "SEALS"
    community 18
  ]
  node [
    id 1235
    label "E:MARINE ANIMALS"
    kind "entity"
    name "MARINE ANIMALS"
    community 18
  ]
  node [
    id 1236
    label "E:FATS"
    kind "entity"
    name "FATS"
    community 18
  ]
  node [
    id 1237
    label "E:PROTEINS"
    kind "entity"
    name "PROTEINS"
    community 18
  ]
  node [
    id 1238
    label "U:Novel-25646_00052#11"
    kind "unit"
    chunk_id "Novel-25646_00052"
    text "The sun changes unripe fruits by causing them to ripen through the production of ethylene gas and increased sugar content."
    community 3
  ]
  node [
    id 1239
    label "E:ETHYLENE GAS"
    kind "entity"
    name "ETHYLENE GAS"
    community 3
  ]
  node [
    id 1240
    label "E:SUGAR CONTENT"
    kind "entity"
    name "SUGAR CONTENT"
    community 3
  ]
  node [
    id 1241
    label "U:Novel-25646_00052#12"
    kind "unit"
    chunk_id "Novel-25646_00052"
    text "Candy is often poisonous because it may contain toxic substances such as mercury or lead, especially if made from unregulated sources."
    community 2
  ]
  node [
    id 1242
    label "E:TOXIC SUBSTANCES"
    kind "entity"
    name "TOXIC SUBSTANCES"
    community 2
  ]
  node [
    id 1243
    label "E:MERCURY"
    kind "entity"
    name "MERCURY"
    community 2
  ]
  node [
    id 1244
    label "U:Novel-25646_00052#13"
    kind "unit"
    chunk_id "Novel-25646_00052"
    text "White candy sometimes contains sugar and sometimes a small amount of arsenic, which is added to prevent spoilage and preserve the candy's appearance."
    community 2
  ]
  node [
    id 1245
    label "E:ARSENIC"
    kind "entity"
    name "ARSENIC"
    community 2
  ]
  node [
    id 1246
    label "E:SPOILAGE"
    kind "entity"
    name "SPOILAGE"
    community 2
  ]
  node [
    id 1247
    label "E:APPEARANCE"
    kind "entity"
    name "APPEARANCE"
    community 2
  ]
  node [
    id 1248
    label "U:Novel-25646_00052#14"
    kind "unit"
    chunk_id "Novel-25646_00052"
    text "To show that food becomes part of the body, one could demonstrate digestion by observing how food is broken down in the stomach and absorbed in the intestines."
    community 14
  ]
  node [
    id 1249
    label "E:INTESTINES"
    kind "entity"
    name "INTESTINES"
    community 0
  ]
  node [
    id 1250
    label "E:BREAKDOWN"
    kind "entity"
    name "BREAKDOWN"
    community 14
  ]
  node [
    id 1251
    label "E:ABSORPTION"
    kind "entity"
    name "ABSORPTION"
    community 14
  ]
  node [
    id 1252
    label "U:Novel-25646_00052#15"
    kind "unit"
    chunk_id "Novel-25646_00052"
    text "The dinner consists of roast beef, potatoes, tomatoes, squash, bread, butter, salt, water, peaches, bananas, oranges, and grapes. The meat, vegetables, and bread must be cooked before consumption."
    community 1
  ]
  node [
    id 1253
    label "E:ROAST BEEF"
    kind "entity"
    name "ROAST BEEF"
    community 1
  ]
  node [
    id 1254
    label "E:TOMATOES"
    kind "entity"
    name "TOMATOES"
    community 1
  ]
  node [
    id 1255
    label "E:SQUASH"
    kind "entity"
    name "SQUASH"
    community 1
  ]
  node [
    id 1256
    label "E:PEACHES"
    kind "entity"
    name "PEACHES"
    community 1
  ]
  node [
    id 1257
    label "E:BANANAS"
    kind "entity"
    name "BANANAS"
    community 1
  ]
  node [
    id 1258
    label "E:ORANGES"
    kind "entity"
    name "ORANGES"
    community 1
  ]
  node [
    id 1259
    label "E:CONSUMPTION"
    kind "entity"
    name "CONSUMPTION"
    community 1
  ]
  node [
    id 1260
    label "C:Novel-25646_00053"
    kind "chunk"
    chunk_id "Novel-25646_00053"
  ]
  node [
    id 1261
    label "U:Novel-25646_00053#0"
    kind "unit"
    chunk_id "Novel-25646_00053"
    text "The meat, vegetables, and bread must be cooked so that they can be easily processed by the mouth and stomach; if not cooked, chewing and digestion would be very difficult and could cause pains and aches in the overworked stomach."
    community 1
  ]
  node [
    id 1262
    label "E:PAINS"
    kind "entity"
    name "PAINS"
    community 1
  ]
  node [
    id 1263
    label "E:OVERWORKED STOMACH"
    kind "entity"
    name "OVERWORKED STOMACH"
    community 1
  ]
  node [
    id 1264
    label "E:UNCOOKED MEAT"
    kind "entity"
    name "UNCOOKED MEAT"
    community 1
  ]
  node [
    id 1265
    label "E:UNCOOKED VEGETABLES"
    kind "entity"
    name "UNCOOKED VEGETABLES"
    community 1
  ]
  node [
    id 1266
    label "E:UNCOOKED BREAD"
    kind "entity"
    name "UNCOOKED BREAD"
    community 1
  ]
  node [
    id 1267
    label "E:UNCOOKED FOOD"
    kind "entity"
    name "UNCOOKED FOOD"
    community 1
  ]
  node [
    id 1268
    label "U:Novel-25646_00053#1"
    kind "unit"
    chunk_id "Novel-25646_00053"
    text "The fruit is not cooked by fire but is naturally ripened and sweetened by the sun, which is similar to cooking in effect."
    community 3
  ]
  node [
    id 1269
    label "E:SWEETENED"
    kind "entity"
    name "SWEETENED"
    community 3
  ]
  node [
    id 1270
    label "U:Novel-25646_00053#2"
    kind "unit"
    chunk_id "Novel-25646_00053"
    text "When older, some individuals may be responsible for cooking at home and must remember that well-cooked food is worth twice as much as poorly cooked food, and that a good cook has more influence on family health than a good doctor."
    community 3
  ]
  node [
    id 1271
    label "E:OLDER INDIVIDUALS"
    kind "entity"
    name "OLDER INDIVIDUALS"
    community 3
  ]
  node [
    id 1272
    label "E:HOME"
    kind "entity"
    name "HOME"
    community 3
  ]
  node [
    id 1273
    label "E:WELL-COOKED FOOD"
    kind "entity"
    name "WELL-COOKED FOOD"
    community 3
  ]
  node [
    id 1274
    label "E:POORLY-COOKED FOOD"
    kind "entity"
    name "POORLY-COOKED FOOD"
    community 3
  ]
  node [
    id 1275
    label "E:GOOD COOK"
    kind "entity"
    name "GOOD COOK"
    community 3
  ]
  node [
    id 1276
    label "E:FAMILY HEALTH"
    kind "entity"
    name "FAMILY HEALTH"
    community 3
  ]
  node [
    id 1277
    label "E:GOOD DOCTOR"
    kind "entity"
    name "GOOD DOCTOR"
    community 3
  ]
  node [
    id 1278
    label "U:Novel-25646_00053#3"
    kind "unit"
    chunk_id "Novel-25646_00053"
    text "As soon as food is chewed, saliva in the mouth moistens and mixes with it; saliva has the ability to convert starch into sugar, which is necessary before food can enter the blood."
    community 3
  ]
  node [
    id 1279
    label "U:Novel-25646_00053#4"
    kind "unit"
    chunk_id "Novel-25646_00053"
    text "A piece of dry cracker can be chewed slowly to demonstrate that saliva can convert starch into sugar, because cracker is mostly made of starch from wheat."
    community 3
  ]
  node [
    id 1280
    label "E:CRACKER"
    kind "entity"
    name "CRACKER"
    community 3
  ]
  node [
    id 1281
    label "C:Novel-25646_00054"
    kind "chunk"
    chunk_id "Novel-25646_00054"
  ]
  node [
    id 1282
    label "U:Novel-25646_00054#0"
    kind "unit"
    chunk_id "Novel-25646_00054"
    text "The cracker is made mostly of starch because wheat is full of starch; initially dry and tasteless, it becomes sweet as saliva converts starch into sugar."
    community 3
  ]
  node [
    id 1283
    label "U:Novel-25646_00054#1"
    kind "unit"
    chunk_id "Novel-25646_00054"
    text "Food should be eaten slowly and chewed well so that saliva can mix with it; otherwise, starch may not be changed and one body part will have more work than its share."
    community 3
  ]
  node [
    id 1284
    label "E:ONE BODY PART"
    kind "entity"
    name "ONE BODY PART"
    community 3
  ]
  node [
    id 1285
    label "E:ANOTHER BODY PART"
    kind "entity"
    name "ANOTHER BODY PART"
    community 3
  ]
  node [
    id 1286
    label "U:Novel-25646_00054#2"
    kind "unit"
    chunk_id "Novel-25646_00054"
    text "If food is swallowed quickly and saliva does not work, the stomach has extra work; it may ache and find it hard to do more than its part."
    community 14
  ]
  node [
    id 1287
    label "E:ACHING"
    kind "entity"
    name "ACHING"
    community 14
  ]
  node [
    id 1288
    label "U:Novel-25646_00054#3"
    kind "unit"
    chunk_id "Novel-25646_00054"
    text "Swallowing comes next to chewing; there are two passages down the throat: one to the lungs for breathing and one to the stomach for swallowing."
    community 3
  ]
  node [
    id 1289
    label "E:SWALLOWING"
    kind "entity"
    name "SWALLOWING"
    community 3
  ]
  node [
    id 1290
    label "E:PASSAGES"
    kind "entity"
    name "PASSAGES"
    community 3
  ]
  node [
    id 1291
    label "E:ONE PASSAGE"
    kind "entity"
    name "ONE PASSAGE"
    community 3
  ]
  node [
    id 1292
    label "E:OTHER PASSAGE"
    kind "entity"
    name "OTHER PASSAGE"
    community 14
  ]
  node [
    id 1293
    label "U:Novel-25646_00054#4"
    kind "unit"
    chunk_id "Novel-25646_00054"
    text "Food does not sometimes go down the wrong way because the windpipe to the lungs is in front of the tube to the stomach and has a little trap-door at its top."
    community 0
  ]
  node [
    id 1294
    label "E:WINDPIPE"
    kind "entity"
    name "WINDPIPE"
    community 0
  ]
  node [
    id 1295
    label "E:TRAP-DOOR"
    kind "entity"
    name "TRAP-DOOR"
    community 0
  ]
  node [
    id 1296
    label "E:STOMACH TUBE"
    kind "entity"
    name "STOMACH TUBE"
    community 0
  ]
  node [
    id 1297
    label "C:Novel-25646_00055"
    kind "chunk"
    chunk_id "Novel-25646_00055"
  ]
  node [
    id 1298
    label "U:Novel-25646_00055#0"
    kind "unit"
    chunk_id "Novel-25646_00055"
    text "The top of the throat has a small trap-door that opens when we breathe and closes when we swallow, allowing food to slide safely into the passage leading to the stomach. If someone tries to speak with food in their mouth, the trap-door must open, and some food may slip in. The windpipe cannot pass the food to the lungs and instead tries to push it back, causing a choking sensation. If the windpipe fails to push the food back, the person will die."
    community 0
  ]
  node [
    id 1299
    label "E:PASSAGE"
    kind "entity"
    name "PASSAGE"
    community 0
  ]
  node [
    id 1300
    label "E:CHOKING"
    kind "entity"
    name "CHOKING"
    community 0
  ]
  node [
    id 1301
    label "E:DEATH"
    kind "entity"
    name "DEATH"
    community 0
  ]
  node [
    id 1302
    label "U:Novel-25646_00055#1"
    kind "unit"
    chunk_id "Novel-25646_00055"
    text "After food is safely swallowed, it enters the stomach where gastric juice mixes with it until it becomes a gray fluid. This mixture then moves into the intestines, a long coiled tube that extends from the stomach, where it is absorbed into the blood. The blood carries the nutrients to the heart, which pumps them to the lungs and then throughout the body to form bone, muscle, skin, hair, eyes, and brain. The dinner also helps repair any broken body parts."
    community 0
  ]
  node [
    id 1303
    label "E:LONG COILED TUBE"
    kind "entity"
    name "LONG COILED TUBE"
    community 0
  ]
  node [
    id 1304
    label "E:BREAKS"
    kind "entity"
    name "BREAKS"
    community 1
  ]
  node [
    id 1305
    label "E:NUTRIENTS"
    kind "entity"
    name "NUTRIENTS"
    community 9
  ]
  node [
    id 1306
    label "C:Novel-25646_00056"
    kind "chunk"
    chunk_id "Novel-25646_00056"
  ]
  node [
    id 1307
    label "U:Novel-25646_00056#0"
    kind "unit"
    chunk_id "Novel-25646_00056"
    text "A dinner can help feed all parts of the body and mend broken parts, such as a broken bone in a boy's arm. If a broken stick is bound together and left for a while, it does not grow together, but a doctor can bind the ends of a broken bone and allow the blood to bring bone food daily until the bone grows back. Thus, a dinner can both make and mend the different parts of the body."
    community 22
  ]
  node [
    id 1308
    label "E:BROKEN BONE"
    kind "entity"
    name "BROKEN BONE"
    community 22
  ]
  node [
    id 1309
    label "E:BROKEN STICK"
    kind "entity"
    name "BROKEN STICK"
    community 22
  ]
  node [
    id 1310
    label "E:BONE FOOD"
    kind "entity"
    name "BONE FOOD"
    community 22
  ]
  node [
    id 1311
    label "E:GROWING TOGETHER"
    kind "entity"
    name "GROWING TOGETHER"
    community 22
  ]
  node [
    id 1312
    label "E:ALL PARTS OF THE BODY"
    kind "entity"
    name "ALL PARTS OF THE BODY"
    community 22
  ]
  node [
    id 1313
    label "E:BOUND AND LEFT FOR A WHILE"
    kind "entity"
    name "BOUND AND LEFT FOR A WHILE"
    community 22
  ]
  node [
    id 1314
    label "E:ENDS OF BROKEN BONE"
    kind "entity"
    name "ENDS OF BROKEN BONE"
    community 22
  ]
  node [
    id 1315
    label "U:Novel-25646_00056#1"
    kind "unit"
    chunk_id "Novel-25646_00056"
    text "Review questions ask about what to have for dinner, the first thing to do with food, why meat and vegetables are cooked, why ripe fruits do not need cooking, what is said about a good cook, the first action after taking food into the mouth, why chewing is necessary, what saliva does to food, how to prove saliva turns starch into sugar, what happens if food is not chewed and mixed with saliva, what comes after chewing, and what is wonderful about swallowing."
    community 3
  ]
  node [
    id 1316
    label "E:WHAT TO HAVE FOR DINNER"
    kind "entity"
    name "WHAT TO HAVE FOR DINNER"
    community 3
  ]
  node [
    id 1317
    label "E:FIRST THING TO DO WITH FOOD"
    kind "entity"
    name "FIRST THING TO DO WITH FOOD"
    community 3
  ]
  node [
    id 1318
    label "E:MEAT AND VEGETABLES"
    kind "entity"
    name "MEAT AND VEGETABLES"
    community 3
  ]
  node [
    id 1319
    label "E:MAKE THEM SAFE TO EAT"
    kind "entity"
    name "MAKE THEM SAFE TO EAT"
    community 3
  ]
  node [
    id 1320
    label "E:THEY ARE ALREADY READY TO EAT"
    kind "entity"
    name "THEY ARE ALREADY READY TO EAT"
    community 2
  ]
  node [
    id 1321
    label "E:KNOWING HOW TO PREPARE FOOD"
    kind "entity"
    name "KNOWING HOW TO PREPARE FOOD"
    community 3
  ]
  node [
    id 1322
    label "E:STARCH INTO SUGAR"
    kind "entity"
    name "STARCH INTO SUGAR"
    community 3
  ]
  node [
    id 1323
    label "E:FOOD THAT IS NOT CHEWED AND MIXED WITH SALIVA"
    kind "entity"
    name "FOOD THAT IS NOT CHEWED AND MIXED WITH SALIVA"
    community 3
  ]
  node [
    id 1324
    label "E:IT MOVES FOOD TO THE STOMACH"
    kind "entity"
    name "IT MOVES FOOD TO THE STOMACH"
    community 3
  ]
  node [
    id 1325
    label "C:Novel-25646_00057"
    kind "chunk"
    chunk_id "Novel-25646_00057"
  ]
  node [
    id 1326
    label "U:Novel-25646_00057#0"
    kind "unit"
    chunk_id "Novel-25646_00057"
    text "The passage lists various types of food and their functions: water, salt, lime, meat, sugar, milk, starch, eggs, fat, wheat, cream, corn, oats, oil, and includes notes that fat and oil provide heat, wheat provides for muscles, and the food list is presented to help remember the different kinds of food."
    community 1
  ]
  node [
    id 1327
    label "E:FAT AND HEAT"
    kind "entity"
    name "FAT AND HEAT"
    community 1
  ]
  node [
    id 1328
    label "U:Novel-25646_00057#1"
    kind "unit"
    chunk_id "Novel-25646_00057"
    text "The passage notes that wine, beer, and alcoholic drinks were not included on the dinner bill of fare, nor were cigars, and asks why these were left out, concluding that food should be eaten to grow strong and keep strong."
    community 11
  ]
  node [
    id 1329
    label "E:ALCOHOLIC DRINKS"
    kind "entity"
    name "ALCOHOLIC DRINKS"
    community 11
  ]
  node [
    id 1330
    label "E:DINNER BILL OF FARE"
    kind "entity"
    name "DINNER BILL OF FARE"
    community 11
  ]
  node [
    id 1331
    label "E:STRENGTH OF BODY"
    kind "entity"
    name "STRENGTH OF BODY"
    community 11
  ]
  node [
    id 1332
    label "E:EATING FOOD"
    kind "entity"
    name "EATING FOOD"
    community 11
  ]
  node [
    id 1333
    label "E:GROW STRONG AND KEEP STRONG"
    kind "entity"
    name "GROW STRONG AND KEEP STRONG"
    community 11
  ]
  node [
    id 1334
    label "C:Novel-25646_00058"
    kind "chunk"
    chunk_id "Novel-25646_00058"
  ]
  node [
    id 1335
    label "U:Novel-25646_00058#0"
    kind "unit"
    chunk_id "Novel-25646_00058"
    text "To grow strong and keep strong, one should eat good and simple food to provide the blood with supplies to reach every part of the body, exercise in the open air, take pure air into the lungs to purify the blood, and engage in plenty of exercise to make muscles grow. Strength can be measured by fastening a heavy weight to one end of a rope, passing the rope over a pulley, and pulling steadily at the other end while marking the height to which the weight is raised; repeating this once a week or once a month allows one to track gains in strength."
    community 11
  ]
  node [
    id 1336
    label "E:EAT"
    kind "entity"
    name "EAT"
    community 11
  ]
  node [
    id 1337
    label "E:GROW STRONG"
    kind "entity"
    name "GROW STRONG"
    community 11
  ]
  node [
    id 1338
    label "E:KEEP STRONG"
    kind "entity"
    name "KEEP STRONG"
    community 11
  ]
  node [
    id 1339
    label "E:HEAVY WEIGHT"
    kind "entity"
    name "HEAVY WEIGHT"
    community 11
  ]
  node [
    id 1340
    label "E:ROPE"
    kind "entity"
    name "ROPE"
    community 11
  ]
  node [
    id 1341
    label "E:PULLEY"
    kind "entity"
    name "PULLEY"
    community 11
  ]
  node [
    id 1342
    label "E:OPEN AIR"
    kind "entity"
    name "OPEN AIR"
    community 11
  ]
  node [
    id 1343
    label "E:GOOD AND SIMPLE FOOD"
    kind "entity"
    name "GOOD AND SIMPLE FOOD"
    community 11
  ]
  node [
    id 1344
    label "E:BLOOD SUPPLIES"
    kind "entity"
    name "BLOOD SUPPLIES"
    community 11
  ]
  node [
    id 1345
    label "E:MARKING HEIGHT"
    kind "entity"
    name "MARKING HEIGHT"
    community 11
  ]
  node [
    id 1346
    label "E:REPEATING"
    kind "entity"
    name "REPEATING"
    community 11
  ]
  node [
    id 1347
    label "E:STRENGTH GAINS"
    kind "entity"
    name "STRENGTH GAINS"
    community 11
  ]
  node [
    id 1348
    label "E:PURIFY BLOOD"
    kind "entity"
    name "PURIFY BLOOD"
    community 11
  ]
  node [
    id 1349
    label "E:PLAIN EXERCISE"
    kind "entity"
    name "PLAIN EXERCISE"
    community 11
  ]
  node [
    id 1350
    label "E:MAKE MUSCLES GROW"
    kind "entity"
    name "MAKE MUSCLES GROW"
    community 11
  ]
  node [
    id 1351
    label "E:EVERY PART OF THE BODY"
    kind "entity"
    name "EVERY PART OF THE BODY"
    community 0
  ]
  node [
    id 1352
    label "E:PULLING"
    kind "entity"
    name "PULLING"
    community 11
  ]
  node [
    id 1353
    label "E:ONCE A WEEK OR ONCE A MONTH"
    kind "entity"
    name "ONCE A WEEK OR ONCE A MONTH"
    community 11
  ]
  node [
    id 1354
    label "U:Novel-25646_00058#1"
    kind "unit"
    chunk_id "Novel-25646_00058"
    text "Alcohol cannot make good muscles, bone, nerve, or brain, and therefore cannot give a person strength. People used to believe that alcohol made them strong, but this belief is incorrect because alcohol does not contribute to the development of muscles, bone, nerve, or brain."
    community 8
  ]
  node [
    id 1355
    label "E:BELIEVED"
    kind "entity"
    name "BELIEVED"
    community 8
  ]
  node [
    id 1356
    label "E:ALCOHOL MAKES STRONG"
    kind "entity"
    name "ALCOHOL MAKES STRONG"
    community 8
  ]
  node [
    id 1357
    label "E:ALCOHOL DEVELOPS MUSCLES"
    kind "entity"
    name "ALCOHOL DEVELOPS MUSCLES"
    community 8
  ]
  node [
    id 1358
    label "E:ALCOHOL DEVELOPS BONE"
    kind "entity"
    name "ALCOHOL DEVELOPS BONE"
    community 8
  ]
  node [
    id 1359
    label "E:ALCOHOL DEVELOPS NERVE"
    kind "entity"
    name "ALCOHOL DEVELOPS NERVE"
    community 8
  ]
  node [
    id 1360
    label "E:ALCOHOL DEVELOPS BRAIN"
    kind "entity"
    name "ALCOHOL DEVELOPS BRAIN"
    community 8
  ]
  node [
    id 1361
    label "U:Novel-25646_00058#2"
    kind "unit"
    chunk_id "Novel-25646_00058"
    text "The grain used to make beer would have given a person strength, but beer itself does not provide that strength."
    community 7
  ]
  node [
    id 1362
    label "E:BEER PROVIDES STRENGTH"
    kind "entity"
    name "BEER PROVIDES STRENGTH"
    community 7
  ]
  node [
    id 1363
    label "C:Novel-25646_00059"
    kind "chunk"
    chunk_id "Novel-25646_00059"
  ]
  node [
    id 1364
    label "U:Novel-25646_00059#0"
    kind "unit"
    chunk_id "Novel-25646_00059"
    text "The grain used to make beer contains nutrients that would provide strength, but measuring strength before and after drinking beer shows no gain. Most of the food part of the grain is converted into alcohol, and this alcohol is present in cider, which is made from crushed apples. Apple juice begins to turn sour or 'hard' shortly after pressing, and at that point alcohol starts forming. Pure water and apples are good, but apple juice becomes poisonous as soon as any alcohol is present. In cider-making, alcohol forms in the juice within a few hours after pressing the apples. Drinks containing alcohol do not provide real strength. People mistakenly believe they gain strength because alcohol suppresses the nerves, making them unable to sense how hard work is or how heavy a weight is. This false sense of strength lasts only briefly, and after it fades, men feel weaker than before."
    community 19
  ]
  node [
    id 1365
    label "E:APPLE JUICE"
    kind "entity"
    name "APPLE JUICE"
    community 19
  ]
  node [
    id 1366
    label "E:SOUR"
    kind "entity"
    name "SOUR"
    community 19
  ]
  node [
    id 1367
    label "E:HARD"
    kind "entity"
    name "HARD"
    community 19
  ]
  node [
    id 1368
    label "E:WEIGHT"
    kind "entity"
    name "WEIGHT"
    community 19
  ]
  node [
    id 1369
    label "E:FALSE FEELING OF STRENGTH"
    kind "entity"
    name "FALSE FEELING OF STRENGTH"
    community 19
  ]
  node [
    id 1370
    label "E:DRINKS WITH ALCOHOL"
    kind "entity"
    name "DRINKS WITH ALCOHOL"
    community 19
  ]
  node [
    id 1371
    label "E:PRESSING APPLES"
    kind "entity"
    name "PRESSING APPLES"
    community 19
  ]
  node [
    id 1372
    label "E:HOURS"
    kind "entity"
    name "HOURS"
    community 19
  ]
  node [
    id 1373
    label "E:REAL STRENGTH"
    kind "entity"
    name "REAL STRENGTH"
    community 19
  ]
  node [
    id 1374
    label "E:ALCOHOL FORMS"
    kind "entity"
    name "ALCOHOL FORMS"
    community 19
  ]
  node [
    id 1375
    label "E:ALCOHOL IS PRESENT"
    kind "entity"
    name "ALCOHOL IS PRESENT"
    community 19
  ]
  node [
    id 1376
    label "E:FEW HOURS AFTER PRESSING APPLES"
    kind "entity"
    name "FEW HOURS AFTER PRESSING APPLES"
    community 19
  ]
  node [
    id 1377
    label "E:HOW HARD WORK IS"
    kind "entity"
    name "HOW HARD WORK IS"
    community 19
  ]
  node [
    id 1378
    label "E:HOW HEAVY WEIGHT IS"
    kind "entity"
    name "HOW HEAVY WEIGHT IS"
    community 19
  ]
  node [
    id 1379
    label "E:MEN"
    kind "entity"
    name "MEN"
    community 19
  ]
  node [
    id 1380
    label "E:AFTER FALSE FEELING OF STRENGTH PASSES"
    kind "entity"
    name "AFTER FALSE FEELING OF STRENGTH PASSES"
    community 19
  ]
  node [
    id 1381
    label "C:Novel-25646_00060"
    kind "chunk"
    chunk_id "Novel-25646_00060"
  ]
  node [
    id 1382
    label "U:Novel-25646_00060#0"
    kind "unit"
    chunk_id "Novel-25646_00060"
    text "Men feel weaker after alcohol has passed, as shown by a story told to the captain of a ship who sailed to China and other distant places. Many years ago, when people believed a little alcohol was beneficial, ships carried large amounts of rum, a liquor distilled from molasses containing about half alcohol. Sailors were given rum daily, and during storms with heavy work, they received twice the usual amount. The captain observed that drinking rum did not make the men stronger but instead made them feel weaker over time. He decided to sail without rum on his ship. Once at sea, the men could not obtain rum. Initially, they disliked the change, but the captain ensured their food was good and plentiful. When a storm occurred and they were wet, cold, and tired, he provided them with hot coffee. By the time they reached the other side of the ocean, the men stated that the captain was right: they had worked better and felt stronger because they had gone without rum."
    community 23
  ]
  node [
    id 1383
    label "E:CAPTAIN OF A SHIP"
    kind "entity"
    name "CAPTAIN OF A SHIP"
    community 23
  ]
  node [
    id 1384
    label "E:CHINA"
    kind "entity"
    name "CHINA"
    community 23
  ]
  node [
    id 1385
    label "E:DISTANT PLACES"
    kind "entity"
    name "DISTANT PLACES"
    community 23
  ]
  node [
    id 1386
    label "E:MOLASSES"
    kind "entity"
    name "MOLASSES"
    community 23
  ]
  node [
    id 1387
    label "E:HALF ALCOHOL"
    kind "entity"
    name "HALF ALCOHOL"
    community 23
  ]
  node [
    id 1388
    label "E:SAILORS"
    kind "entity"
    name "SAILORS"
    community 23
  ]
  node [
    id 1389
    label "E:STORM"
    kind "entity"
    name "STORM"
    community 23
  ]
  node [
    id 1390
    label "E:HARD WORK"
    kind "entity"
    name "HARD WORK"
    community 13
  ]
  node [
    id 1391
    label "E:HOT COFFEE"
    kind "entity"
    name "HOT COFFEE"
    community 23
  ]
  node [
    id 1392
    label "E:OCEAN"
    kind "entity"
    name "OCEAN"
    community 23
  ]
  node [
    id 1393
    label "E:WET"
    kind "entity"
    name "WET"
    community 23
  ]
  node [
    id 1394
    label "E:TIRED"
    kind "entity"
    name "TIRED"
    community 23
  ]
  node [
    id 1395
    label "E:WORKED BETTER"
    kind "entity"
    name "WORKED BETTER"
    community 23
  ]
  node [
    id 1396
    label "E:FEEL STRONGER"
    kind "entity"
    name "FEEL STRONGER"
    community 23
  ]
  node [
    id 1397
    label "E:ALCOHOL NOT GIVING STRENGTH"
    kind "entity"
    name "ALCOHOL NOT GIVING STRENGTH"
    community 23
  ]
  node [
    id 1398
    label "E:MEN FEEL WEAKER"
    kind "entity"
    name "MEN FEEL WEAKER"
    community 23
  ]
  node [
    id 1399
    label "U:Novel-25646_00060#1"
    kind "unit"
    chunk_id "Novel-25646_00060"
    text "The captain of a ship, who sailed to China and other distant places, concluded that going without rum improved the sailors' performance and strength. He observed that after drinking rum, sailors felt weaker over time, and when they were given hot coffee during storms instead of rum, they performed better and felt stronger."
    community 23
  ]
  node [
    id 1400
    label "E:SAILORS PERFORMANCE AND STRENGTH"
    kind "entity"
    name "SAILORS PERFORMANCE AND STRENGTH"
    community 23
  ]
  node [
    id 1401
    label "E:SAILORS FEEL WEAKER"
    kind "entity"
    name "SAILORS FEEL WEAKER"
    community 23
  ]
  node [
    id 1402
    label "C:Novel-25646_00061"
    kind "chunk"
    chunk_id "Novel-25646_00061"
  ]
  node [
    id 1403
    label "U:Novel-25646_00061#0"
    kind "unit"
    chunk_id "Novel-25646_00061"
    text "Going without rum leads to greater mental strength, as alcohol causes headaches and deadens nerves, impairing the brain's ability to think properly. The best strength is brain strength or strength of mind, which is weakened by alcohol and tobacco. Every person should have a body and mind capable of working and bringing happiness, even without money or property. A person with a strong, healthy body, well-trained hands, and a clear thinking brain would prefer such a state over one whose body and mind have been poisoned by alcohol, tobacco, and opium, even if the latter lives in a palace with a million dollars. To maintain a mind capable of studying, understanding, and thinking well, one should prevent alcohol and tobacco from reaching it."
    community 16
  ]
  node [
    id 1404
    label "E:STRENGTH OF MIND"
    kind "entity"
    name "STRENGTH OF MIND"
    community 16
  ]
  node [
    id 1405
    label "E:MONEY"
    kind "entity"
    name "MONEY"
    community 11
  ]
  node [
    id 1406
    label "E:HOMES"
    kind "entity"
    name "HOMES"
    community 16
  ]
  node [
    id 1407
    label "E:LANDS"
    kind "entity"
    name "LANDS"
    community 16
  ]
  node [
    id 1408
    label "E:HAPPINESS"
    kind "entity"
    name "HAPPINESS"
    community 16
  ]
  node [
    id 1409
    label "E:PALACE"
    kind "entity"
    name "PALACE"
    community 16
  ]
  node [
    id 1410
    label "E:MILLION OF DOLLARS"
    kind "entity"
    name "MILLION OF DOLLARS"
    community 16
  ]
  node [
    id 1411
    label "E:CLEAR THINKING BRAIN"
    kind "entity"
    name "CLEAR THINKING BRAIN"
    community 16
  ]
  node [
    id 1412
    label "E:STUDY"
    kind "entity"
    name "STUDY"
    community 16
  ]
  node [
    id 1413
    label "E:UNDERSTAND"
    kind "entity"
    name "UNDERSTAND"
    community 16
  ]
  node [
    id 1414
    label "E:THINK WELL"
    kind "entity"
    name "THINK WELL"
    community 16
  ]
  node [
    id 1415
    label "E:BRAIN STRENGTH"
    kind "entity"
    name "BRAIN STRENGTH"
    community 16
  ]
  node [
    id 1416
    label "E:EVERY PERSON"
    kind "entity"
    name "EVERY PERSON"
    community 16
  ]
  node [
    id 1417
    label "E:PERSON WITH A STRONG BODY"
    kind "entity"
    name "PERSON WITH A STRONG BODY"
    community 16
  ]
  node [
    id 1418
    label "E:WELL-TRAINED HANDS"
    kind "entity"
    name "WELL-TRAINED HANDS"
    community 16
  ]
  node [
    id 1419
    label "E:PERSON WITH POISONED BODY AND MIND"
    kind "entity"
    name "PERSON WITH POISONED BODY AND MIND"
    community 16
  ]
  node [
    id 1420
    label "C:Novel-25646_00062"
    kind "chunk"
    chunk_id "Novel-25646_00062"
  ]
  node [
    id 1421
    label "U:Novel-25646_00062#0"
    kind "unit"
    chunk_id "Novel-25646_00062"
    text "Alcohol does not make a person strong; drinking beer, wine, or any other alcoholic drink does not increase physical strength. People imagine they feel strong after drinking because of a psychological illusion, not actual physical gain. A story is told showing that alcohol does not help sailors perform their work effectively. The best kind of strength to have is mental strength. Alcohol negatively affects the strength of the mind."
    community 5
  ]
  node [
    id 1422
    label "E:ALCOHOLIC DRINK"
    kind "entity"
    name "ALCOHOLIC DRINK"
    community 5
  ]
  node [
    id 1423
    label "E:PHYSICAL STRENGTH"
    kind "entity"
    name "PHYSICAL STRENGTH"
    community 15
  ]
  node [
    id 1424
    label "E:MENTAL STRENGTH"
    kind "entity"
    name "MENTAL STRENGTH"
    community 5
  ]
  node [
    id 1425
    label "E:PSYCHOLOGICAL ILLUSION"
    kind "entity"
    name "PSYCHOLOGICAL ILLUSION"
    community 5
  ]
  node [
    id 1426
    label "E:BEST KIND OF STRENGTH"
    kind "entity"
    name "BEST KIND OF STRENGTH"
    community 5
  ]
  node [
    id 1427
    label "U:Novel-25646_00062#1"
    kind "unit"
    chunk_id "Novel-25646_00062"
    text "The heart is located in the chest, in the upper part of the body formed by the ribs, spine, shoulder-blades, and collar-bones. It is made of thick, strong muscles, similar to a beef's heart, which is larger but structurally comparable to a human heart. The heart functions like a fire engine pumping water through a hose, using its muscles to push blood through arteries, which are tubes shaped like hoses and branch out throughout the body."
    community 0
  ]
  node [
    id 1428
    label "E:BEEF'S HEART"
    kind "entity"
    name "BEEF'S HEART"
    community 0
  ]
  node [
    id 1429
    label "E:HUMAN HEART"
    kind "entity"
    name "HUMAN HEART"
    community 0
  ]
  node [
    id 1430
    label "E:FIRE ENGINE"
    kind "entity"
    name "FIRE ENGINE"
    community 0
  ]
  node [
    id 1431
    label "E:HOSSE"
    kind "entity"
    name "HOSSE"
    community 0
  ]
  node [
    id 1432
    label "E:ARTERIES"
    kind "entity"
    name "ARTERIES"
    community 0
  ]
  node [
    id 1433
    label "E:THICK STRONG MUSCLES"
    kind "entity"
    name "THICK STRONG MUSCLES"
    community 0
  ]
  node [
    id 1434
    label "C:Novel-25646_00063"
    kind "chunk"
    chunk_id "Novel-25646_00063"
  ]
  node [
    id 1435
    label "U:Novel-25646_00063#0"
    kind "unit"
    chunk_id "Novel-25646_00063"
    text "Arteries are tubes that carry blood away from the heart; veins are tubes that bring blood back to the heart. Small veins can be seen in the wrist, and pressing on an artery there allows one to feel the pulse, which indicates how fast the heart is pumping and how blood is flowing. Doctors check the pulse when a person is sick to determine if the heart is working too fast, too slowly, or at a normal rate. The blood transports the gray fluid made from food and drink to every part of the body, picking up the food and delivering it to each part, then leaving with what each part needs."
    community 0
  ]
  node [
    id 1436
    label "E:VEINS"
    kind "entity"
    name "VEINS"
    community 0
  ]
  node [
    id 1437
    label "E:WRIST"
    kind "entity"
    name "WRIST"
    community 0
  ]
  node [
    id 1438
    label "E:PULSE"
    kind "entity"
    name "PULSE"
    community 0
  ]
  node [
    id 1439
    label "E:PRESSING ON ARTERY"
    kind "entity"
    name "PRESSING ON ARTERY"
    community 0
  ]
  node [
    id 1440
    label "E:HEART PUMPING RATE"
    kind "entity"
    name "HEART PUMPING RATE"
    community 0
  ]
  node [
    id 1441
    label "E:PERSON IS SICK"
    kind "entity"
    name "PERSON IS SICK"
    community 22
  ]
  node [
    id 1442
    label "E:EACH PART OF THE BODY"
    kind "entity"
    name "EACH PART OF THE BODY"
    community 0
  ]
  node [
    id 1443
    label "E:STAY STRONG"
    kind "entity"
    name "STAY STRONG"
    community 0
  ]
  node [
    id 1444
    label "E:GOOD BLOOD"
    kind "entity"
    name "GOOD BLOOD"
    community 0
  ]
  node [
    id 1445
    label "E:ALCOHOL OR TOBACCO ARE PRESENT"
    kind "entity"
    name "ALCOHOL OR TOBACCO ARE PRESENT"
    community 0
  ]
  node [
    id 1446
    label "U:Novel-25646_00063#1"
    kind "unit"
    chunk_id "Novel-25646_00063"
    text "The brain requires very pure, good blood to remain strong because it has a lot of work to do. This blood must be made from good food and cannot be compromised by substances like alcohol or tobacco."
    community 0
  ]
  node [
    id 1447
    label "C:Novel-25646_00064"
    kind "chunk"
    chunk_id "Novel-25646_00064"
  ]
  node [
    id 1448
    label "U:Novel-25646_00064#0"
    kind "unit"
    chunk_id "Novel-25646_00064"
    text "The brain requires a large amount of blood, and when alcohol enters the bloodstream, much of it is directed to the brain, where it affects the nerves and causes a man to lose control over his actions."
    community 4
  ]
  node [
    id 1449
    label "E:CONTROL OVER ACTIONS"
    kind "entity"
    name "CONTROL OVER ACTIONS"
    community 4
  ]
  node [
    id 1450
    label "U:Novel-25646_00064#1"
    kind "unit"
    chunk_id "Novel-25646_00064"
    text "When a person runs, they can feel their heart beating, and it rests momentarily between beats. Good exercise in fresh air improves heart function and warms the body more effectively than a fire can."
    community 0
  ]
  node [
    id 1451
    label "E:FRESH AIR"
    kind "entity"
    name "FRESH AIR"
    community 0
  ]
  node [
    id 1452
    label "E:BEAT"
    kind "entity"
    name "BEAT"
    community 0
  ]
  node [
    id 1453
    label "E:BODY WARMTH"
    kind "entity"
    name "BODY WARMTH"
    community 0
  ]
  node [
    id 1454
    label "E:HEART BEATING"
    kind "entity"
    name "HEART BEATING"
    community 0
  ]
  node [
    id 1455
    label "E:BEATS"
    kind "entity"
    name "BEATS"
    community 0
  ]
  node [
    id 1456
    label "E:EXERCISE IN FRESH AIR"
    kind "entity"
    name "EXERCISE IN FRESH AIR"
    community 0
  ]
  node [
    id 1457
    label "U:Novel-25646_00064#2"
    kind "unit"
    chunk_id "Novel-25646_00064"
    text "The heart is made of muscle, and since alcohol harms muscles, a fatty heart cannot work as well as a muscular heart. Alcohol also causes the heart to beat too fast, making it tired."
    community 0
  ]
  node [
    id 1458
    label "E:FATY HEART"
    kind "entity"
    name "FATY HEART"
    community 0
  ]
  node [
    id 1459
    label "E:MUSCULAR HEART"
    kind "entity"
    name "MUSCULAR HEART"
    community 0
  ]
  node [
    id 1460
    label "E:HEART BEAT RATE"
    kind "entity"
    name "HEART BEAT RATE"
    community 0
  ]
  node [
    id 1461
    label "E:HEART TIRE"
    kind "entity"
    name "HEART TIRE"
    community 0
  ]
  node [
    id 1462
    label "U:Novel-25646_00064#3"
    kind "unit"
    chunk_id "Novel-25646_00064"
    text "The heart is placed in the chest, is made of muscle, and performs the work of pumping blood throughout the body. Arteries carry blood away from the heart, and veins carry blood back to it. The pulse indicates the rate at which the heart beats. Food reaches all parts of the body through the bloodstream. Alcohol in the blood affects the brain by affecting the nerves and causing loss of control over actions. The heart rests between beats. Exercise in fresh air helps the heart by improving its function and warming the body better than a fire. Alcohol harms the heart by causing it to beat too fast and leading to fatigue."
    community 0
  ]
  node [
    id 1463
    label "E:PUMPING BLOOD"
    kind "entity"
    name "PUMPING BLOOD"
    community 0
  ]
  node [
    id 1464
    label "E:BLOODSTREAM"
    kind "entity"
    name "BLOODSTREAM"
    community 0
  ]
  node [
    id 1465
    label "E:FATIGUE"
    kind "entity"
    name "FATIGUE"
    community 0
  ]
  node [
    id 1466
    label "C:Novel-25646_00065"
    kind "chunk"
    chunk_id "Novel-25646_00065"
  ]
  node [
    id 1467
    label "U:Novel-25646_00065#0"
    kind "unit"
    chunk_id "Novel-25646_00065"
    text "The blood that returns to the heart from the body is dull and bluish due to impurities, but the heart does not pump out bad blood because the lungs, located in the chest on each side of the heart, change it back to pure, red blood."
    community 0
  ]
  node [
    id 1468
    label "E:PURE RED BLOOD"
    kind "entity"
    name "PURE RED BLOOD"
    community 0
  ]
  node [
    id 1469
    label "E:AIR-CELLS"
    kind "entity"
    name "AIR-CELLS"
    community 0
  ]
  node [
    id 1470
    label "E:EXPAND"
    kind "entity"
    name "EXPAND"
    community 0
  ]
  node [
    id 1471
    label "E:ROOM TO WORK"
    kind "entity"
    name "ROOM TO WORK"
    community 0
  ]
  node [
    id 1472
    label "E:RESPIRATION"
    kind "entity"
    name "RESPIRATION"
    community 0
  ]
  node [
    id 1473
    label "E:DUE TO IMPURITIES"
    kind "entity"
    name "DUE TO IMPURITIES"
    community 0
  ]
  node [
    id 1474
    label "E:BAD BLOOD"
    kind "entity"
    name "BAD BLOOD"
    community 0
  ]
  node [
    id 1475
    label "E:PLENTY OF FRESH AIR"
    kind "entity"
    name "PLENTY OF FRESH AIR"
    community 0
  ]
  node [
    id 1476
    label "E:PLENTY OF ROOM TO WORK"
    kind "entity"
    name "PLENTY OF ROOM TO WORK"
    community 0
  ]
  node [
    id 1477
    label "U:Novel-25646_00065#1"
    kind "unit"
    chunk_id "Novel-25646_00065"
    text "Alcohol does not directly harm the heart as described in this passage; instead, the passage explains how the lungs purify blood returning to the heart, and that tight clothing can impair lung function by limiting expansion."
    community 0
  ]
  node [
    id 1478
    label "E:EXPANSION"
    kind "entity"
    name "EXPANSION"
    community 0
  ]
  node [
    id 1479
    label "E:CONTRACTION"
    kind "entity"
    name "CONTRACTION"
    community 0
  ]
  node [
    id 1480
    label "C:Novel-25646_00066"
    kind "chunk"
    chunk_id "Novel-25646_00066"
  ]
  node [
    id 1481
    label "U:Novel-25646_00066#0"
    kind "unit"
    chunk_id "Novel-25646_00066"
    text "The blood cannot be made pure if the lungs are not functioning properly, and the whole body suffers as a result. For every good breath of fresh air the lungs take in, they expel one of impure air, which helps prepare the blood to return to the heart pure and red and be pumped through the body. The mechanism by which the lungs use fresh air to perform this good work is not yet understood, but it will be learned when people are older. The lungs never stop working, even during the night, though there are small pauses between breaths that serve as rest periods. The lungs are very steady workers both day and night. The least we can do for them is to provide fresh air and plenty of room to function. People may think they cannot give the lungs more room since they are enclosed in the chest, but tight clothing can restrict lung expansion. If any part of the lungs cannot expand, it becomes useless."
    community 0
  ]
  node [
    id 1482
    label "E:PURE BLOOD"
    kind "entity"
    name "PURE BLOOD"
    community 0
  ]
  node [
    id 1483
    label "E:IMPURE AIR"
    kind "entity"
    name "IMPURE AIR"
    community 0
  ]
  node [
    id 1484
    label "E:PAUSE BETWEEN BREATHS"
    kind "entity"
    name "PAUSE BETWEEN BREATHS"
    community 0
  ]
  node [
    id 1485
    label "E:TIGHT CLOTHING"
    kind "entity"
    name "TIGHT CLOTHING"
    community 0
  ]
  node [
    id 1486
    label "E:LUNG EXPANSION"
    kind "entity"
    name "LUNG EXPANSION"
    community 0
  ]
  node [
    id 1487
    label "E:USELESS LUNG PART"
    kind "entity"
    name "USELESS LUNG PART"
    community 0
  ]
  node [
    id 1488
    label "E:PREPARE BLOOD FOR PURITY"
    kind "entity"
    name "PREPARE BLOOD FOR PURITY"
    community 0
  ]
  node [
    id 1489
    label "E:DAY AND NIGHT"
    kind "entity"
    name "DAY AND NIGHT"
    community 4
  ]
  node [
    id 1490
    label "E:USEFUL LUNG FUNCTION"
    kind "entity"
    name "USEFUL LUNG FUNCTION"
    community 0
  ]
  node [
    id 1491
    label "U:Novel-25646_00066#1"
    kind "unit"
    chunk_id "Novel-25646_00066"
    text "If any part of the lungs cannot expand, it becomes useless due to lack of room to take a full breath."
    community 0
  ]
  node [
    id 1492
    label "E:FULL BREATH"
    kind "entity"
    name "FULL BREATH"
    community 0
  ]
  node [
    id 1493
    label "E:LUNG EXPANSION IS RESTRICTED"
    kind "entity"
    name "LUNG EXPANSION IS RESTRICTED"
    community 0
  ]
  node [
    id 1494
    label "E:LACK OF ROOM"
    kind "entity"
    name "LACK OF ROOM"
    community 0
  ]
  node [
    id 1495
    label "C:Novel-25646_00067"
    kind "chunk"
    chunk_id "Novel-25646_00067"
  ]
  node [
    id 1496
    label "U:Novel-25646_00067#0"
    kind "unit"
    chunk_id "Novel-25646_00067"
    text "If any part of the lungs cannot expand, it will become useless; if the lungs cannot take in enough air to purify the blood, a person will not be as strong as God intended and their life will be shortened."
    community 0
  ]
  node [
    id 1497
    label "E:USELESS"
    kind "entity"
    name "USELESS"
    community 0
  ]
  node [
    id 1498
    label "U:Novel-25646_00067#1"
    kind "unit"
    chunk_id "Novel-25646_00067"
    text "The lungs breathe out waste matter taken from the blood, which poisons the air; if all doors, windows, fireplace, and chimney openings are closed and no fresh air can enter, a person would die from being in such a room."
    community 0
  ]
  node [
    id 1499
    label "E:WASTE MATTER"
    kind "entity"
    name "WASTE MATTER"
    community 12
  ]
  node [
    id 1500
    label "E:DOORS"
    kind "entity"
    name "DOORS"
    community 0
  ]
  node [
    id 1501
    label "E:WINDOWS"
    kind "entity"
    name "WINDOWS"
    community 0
  ]
  node [
    id 1502
    label "E:FIREPLACE"
    kind "entity"
    name "FIREPLACE"
    community 0
  ]
  node [
    id 1503
    label "E:CHIMNEY"
    kind "entity"
    name "CHIMNEY"
    community 0
  ]
  node [
    id 1504
    label "E:ROOM"
    kind "entity"
    name "ROOM"
    community 0
  ]
  node [
    id 1505
    label "U:Novel-25646_00067#2"
    kind "unit"
    chunk_id "Novel-25646_00067"
    text "Impure air poisons a person and should not be breathed; if a person feels a headache and drowsiness from being in a closed room, breathing fresh air will improve their condition."
    community 0
  ]
  node [
    id 1506
    label "E:SLEEPINESS"
    kind "entity"
    name "SLEEPINESS"
    community 0
  ]
  node [
    id 1507
    label "E:CLOSED ROOM"
    kind "entity"
    name "CLOSED ROOM"
    community 0
  ]
  node [
    id 1508
    label "U:Novel-25646_00067#3"
    kind "unit"
    chunk_id "Novel-25646_00067"
    text "Good, pure air makes the blood pure and allows it to flow quickly through the body, refreshing every part."
    community 0
  ]
  node [
    id 1509
    label "E:GOOD AIR"
    kind "entity"
    name "GOOD AIR"
    community 0
  ]
  node [
    id 1510
    label "E:FLOW"
    kind "entity"
    name "FLOW"
    community 0
  ]
  node [
    id 1511
    label "E:REFRESH"
    kind "entity"
    name "REFRESH"
    community 0
  ]
  node [
    id 1512
    label "E:EVERY PART"
    kind "entity"
    name "EVERY PART"
    community 0
  ]
  node [
    id 1513
    label "C:Novel-25646_00068"
    kind "chunk"
    chunk_id "Novel-25646_00068"
  ]
  node [
    id 1514
    label "U:Novel-25646_00068#0"
    kind "unit"
    chunk_id "Novel-25646_00068"
    text "We should avoid staying in close rooms during the day or sleeping in close rooms at night, as it prevents the body from getting fresh air, which is essential. Breathing through the nose is better than through the mouth because the small hairs inside the nose catch dust and impurities before they reach the lungs, reducing the risk of these particles entering the lungs. Keeping the mouth shut while walking or running helps prevent dust from entering the lungs and reduces the likelihood of getting out of breath quickly."
    community 0
  ]
  node [
    id 1515
    label "E:CLOSE ROOMS"
    kind "entity"
    name "CLOSE ROOMS"
    community 0
  ]
  node [
    id 1516
    label "E:DAY-TIME"
    kind "entity"
    name "DAY-TIME"
    community 0
  ]
  node [
    id 1517
    label "E:NOSE"
    kind "entity"
    name "NOSE"
    community 0
  ]
  node [
    id 1518
    label "E:DUST"
    kind "entity"
    name "DUST"
    community 13
  ]
  node [
    id 1519
    label "E:MUSCULAR WALLS"
    kind "entity"
    name "MUSCULAR WALLS"
    community 0
  ]
  node [
    id 1520
    label "E:CHEST MUSCLES"
    kind "entity"
    name "CHEST MUSCLES"
    community 0
  ]
  node [
    id 1521
    label "E:BREATHING THROUGH THE NOSE"
    kind "entity"
    name "BREATHING THROUGH THE NOSE"
    community 0
  ]
  node [
    id 1522
    label "E:DUST AND IMPURITIES"
    kind "entity"
    name "DUST AND IMPURITIES"
    community 0
  ]
  node [
    id 1523
    label "E:WALKING AND RUNNING"
    kind "entity"
    name "WALKING AND RUNNING"
    community 16
  ]
  node [
    id 1524
    label "E:KEEPING MOUTH SHUT"
    kind "entity"
    name "KEEPING MOUTH SHUT"
    community 0
  ]
  node [
    id 1525
    label "E:GETTING OUT OF BREATH"
    kind "entity"
    name "GETTING OUT OF BREATH"
    community 0
  ]
  node [
    id 1526
    label "E:MUSCLES AND NERVES"
    kind "entity"
    name "MUSCLES AND NERVES"
    community 0
  ]
  node [
    id 1527
    label "U:Novel-25646_00068#1"
    kind "unit"
    chunk_id "Novel-25646_00068"
    text "Alcohol harms muscles and nerves, and since the muscles of the chest, stomach, and heart are controlled by nerves, alcohol can negatively affect the functioning of the lungs, stomach, and heart. Therefore, alcohol is not a help to these organs."
    community 0
  ]
  node [
    id 1528
    label "C:Novel-25646_00069"
    kind "chunk"
    chunk_id "Novel-25646_00069"
  ]
  node [
    id 1529
    label "U:Novel-25646_00069#0"
    kind "unit"
    chunk_id "Novel-25646_00069"
    text "The blood carries food throughout the body and also transports waste products. The blood in veins appears blue due to light absorption, not because it is actually blue. The blood is made pure and red again in the lungs. From the lungs, it is sent to the rest of the body. The lungs require oxygen to perform their function. The lungs rest during sleep. Tight clothes should be avoided because they restrict breathing and airflow. Air in a room becomes spoiled by the presence of carbon dioxide and other pollutants. To keep air fresh and pure, ventilation and fresh air intake are necessary. One should breathe slowly and deeply. Breathing through the nose is better than through the mouth because the nose filters, warms, and humidifies the air. Alcohol is not good for the lungs because it can damage lung tissue and impair their ability to function properly."
    community 0
  ]
  node [
    id 1530
    label "E:WASTE PRODUCTS"
    kind "entity"
    name "WASTE PRODUCTS"
    community 0
  ]
  node [
    id 1531
    label "E:BLUE"
    kind "entity"
    name "BLUE"
    community 0
  ]
  node [
    id 1532
    label "E:OXYGEN"
    kind "entity"
    name "OXYGEN"
    community 0
  ]
  node [
    id 1533
    label "E:TIGHT CLOTHES"
    kind "entity"
    name "TIGHT CLOTHES"
    community 0
  ]
  node [
    id 1534
    label "E:CARBON DIOXIDE"
    kind "entity"
    name "CARBON DIOXIDE"
    community 0
  ]
  node [
    id 1535
    label "E:POLLUTANTS"
    kind "entity"
    name "POLLUTANTS"
    community 0
  ]
  node [
    id 1536
    label "E:VENTILATION"
    kind "entity"
    name "VENTILATION"
    community 0
  ]
  node [
    id 1537
    label "E:SLOWLY AND DEEPLY"
    kind "entity"
    name "SLOWLY AND DEEPLY"
    community 17
  ]
  node [
    id 1538
    label "E:LUNG TISSUE"
    kind "entity"
    name "LUNG TISSUE"
    community 0
  ]
  node [
    id 1539
    label "E:REST OF BODY"
    kind "entity"
    name "REST OF BODY"
    community 0
  ]
  node [
    id 1540
    label "E:ONE"
    kind "entity"
    name "ONE"
    community 17
  ]
  node [
    id 1541
    label "U:Novel-25646_00069#1"
    kind "unit"
    chunk_id "Novel-25646_00069"
    text "The skin is another part of the body that continuously removes waste matter. The body is covered with skin and also has a more delicate lining skin. The outside skin and lining skin meet at the lips. There is a thin outer layer of skin that can be pulled off without injury, but it is advised not to do so because underneath lies the true skin, which contains many nerves and is sensitive to even the slightest touch."
    community 13
  ]
  node [
    id 1542
    label "E:OUTSIDE SKIN"
    kind "entity"
    name "OUTSIDE SKIN"
    community 13
  ]
  node [
    id 1543
    label "E:LINING SKIN"
    kind "entity"
    name "LINING SKIN"
    community 13
  ]
  node [
    id 1544
    label "E:LIPS"
    kind "entity"
    name "LIPS"
    community 13
  ]
  node [
    id 1545
    label "E:THIN OUTER LAYER"
    kind "entity"
    name "THIN OUTER LAYER"
    community 13
  ]
  node [
    id 1546
    label "E:TRUE SKIN"
    kind "entity"
    name "TRUE SKIN"
    community 13
  ]
  node [
    id 1547
    label "E:SENSITIVE TO TOUCH"
    kind "entity"
    name "SENSITIVE TO TOUCH"
    community 13
  ]
  node [
    id 1548
    label "E:SELF"
    kind "entity"
    name "SELF"
    community 13
  ]
  node [
    id 1549
    label "C:Novel-25646_00070"
    kind "chunk"
    chunk_id "Novel-25646_00070"
  ]
  node [
    id 1550
    label "U:Novel-25646_00070#0"
    kind "unit"
    chunk_id "Novel-25646_00070"
    text "When the outer skin, which protects the true skin, is torn away, the true skin must be covered to prevent harm. In hot weather or after hard work or play, the face and sometimes the whole body become covered with small drops of water called perspiration. Perspiration comes through tiny holes in the skin known as pores, each of which is the mouth of a tiny tube that carries off waste matter and water from the body. If all the perspiration tubes in one person's skin were laid end to end, they would form a line longer than three miles. Perspiration is not always visible, as it may be present in small amounts that do not form drops, but it continuously exits through the skin in both winter and summer. This process helps keep the body healthy by removing worn-out matter, along with other mechanisms."
    community 13
  ]
  node [
    id 1551
    label "E:OUTER SKIN"
    kind "entity"
    name "OUTER SKIN"
    community 13
  ]
  node [
    id 1552
    label "E:HOT WEATHER"
    kind "entity"
    name "HOT WEATHER"
    community 13
  ]
  node [
    id 1553
    label "E:PLAY"
    kind "entity"
    name "PLAY"
    community 13
  ]
  node [
    id 1554
    label "E:FACE"
    kind "entity"
    name "FACE"
    community 13
  ]
  node [
    id 1555
    label "E:WHOLE BODY"
    kind "entity"
    name "WHOLE BODY"
    community 13
  ]
  node [
    id 1556
    label "E:LITTLE DROPS OF WATER"
    kind "entity"
    name "LITTLE DROPS OF WATER"
    community 13
  ]
  node [
    id 1557
    label "E:PERSPIRATION"
    kind "entity"
    name "PERSPIRATION"
    community 13
  ]
  node [
    id 1558
    label "E:PORES"
    kind "entity"
    name "PORES"
    community 13
  ]
  node [
    id 1559
    label "E:TINY TUBE"
    kind "entity"
    name "TINY TUBE"
    community 13
  ]
  node [
    id 1560
    label "E:THREE MILES"
    kind "entity"
    name "THREE MILES"
    community 13
  ]
  node [
    id 1561
    label "E:WINTER"
    kind "entity"
    name "WINTER"
    community 10
  ]
  node [
    id 1562
    label "E:BODY HEALTH"
    kind "entity"
    name "BODY HEALTH"
    community 13
  ]
  node [
    id 1563
    label "E:WORN-OUT MATTER"
    kind "entity"
    name "WORN-OUT MATTER"
    community 13
  ]
  node [
    id 1564
    label "E:OUTER SKIN IS TORN AWAY"
    kind "entity"
    name "OUTER SKIN IS TORN AWAY"
    community 13
  ]
  node [
    id 1565
    label "E:PERSPIRATION ON FACE AND WHOLE BODY"
    kind "entity"
    name "PERSPIRATION ON FACE AND WHOLE BODY"
    community 13
  ]
  node [
    id 1566
    label "E:EACH PORE"
    kind "entity"
    name "EACH PORE"
    community 13
  ]
  node [
    id 1567
    label "E:WASTE MATTER AND WATER"
    kind "entity"
    name "WASTE MATTER AND WATER"
    community 13
  ]
  node [
    id 1568
    label "E:ALL PERSPIRATION TUBES"
    kind "entity"
    name "ALL PERSPIRATION TUBES"
    community 13
  ]
  node [
    id 1569
    label "E:THERE IS NOT ENOUGH TO FORM DROPS"
    kind "entity"
    name "THERE IS NOT ENOUGH TO FORM DROPS"
    community 13
  ]
  node [
    id 1570
    label "E:PERSPIRATION AND OTHER WAYS"
    kind "entity"
    name "PERSPIRATION AND OTHER WAYS"
    community 13
  ]
  node [
    id 1571
    label "U:Novel-25646_00070#1"
    kind "unit"
    chunk_id "Novel-25646_00070"
    text "The nails grow from the skin. Finger nails act as small shields that protect the ends of fingers from injury. The ends of fingers are rich in tiny nerves and would be severely damaged without such protection."
    community 12
  ]
  node [
    id 1572
    label "E:FINGER NAILS"
    kind "entity"
    name "FINGER NAILS"
    community 12
  ]
  node [
    id 1573
    label "E:ENDS OF FINGERS"
    kind "entity"
    name "ENDS OF FINGERS"
    community 12
  ]
  node [
    id 1574
    label "E:TINY NERVES"
    kind "entity"
    name "TINY NERVES"
    community 12
  ]
  node [
    id 1575
    label "E:PROTECTION"
    kind "entity"
    name "PROTECTION"
    community 12
  ]
  node [
    id 1576
    label "C:Novel-25646_00071"
    kind "chunk"
    chunk_id "Novel-25646_00071"
  ]
  node [
    id 1577
    label "U:Novel-25646_00071#0"
    kind "unit"
    chunk_id "Novel-25646_00071"
    text "The finger ends are full of tiny nerves and rely on shields to protect them; nails that have been bitten are disliked by people. Care of the skin involves removing waste matter that passes through perspiration tubes, as left behind waste can clog the small openings of these tubes. Hands and faces of children who have played outdoors are often very dirty and require washing. Even if children have been in a clean place all day and have not touched anything dirty, they still need to be washed because internal waste matter is just as harmful as mud or street dust, though it is less visible due to its gradual release. Washing off this waste keeps the skin fresh and healthy, enabling it to perform its essential functions. If the skin cannot perform its work, death would result. Wearing rubber boots or shoes continuously during school time is not recommended because rubber prevents perspiration from escaping, leading to clogged pores and discomfort in the feet or headaches in the head."
    community 12
  ]
  node [
    id 1578
    label "E:FINGER ENDS"
    kind "entity"
    name "FINGER ENDS"
    community 12
  ]
  node [
    id 1579
    label "E:SHIELDS"
    kind "entity"
    name "SHIELDS"
    community 12
  ]
  node [
    id 1580
    label "E:BITED NAILS"
    kind "entity"
    name "BITED NAILS"
    community 15
  ]
  node [
    id 1581
    label "E:CARE OF THE SKIN"
    kind "entity"
    name "CARE OF THE SKIN"
    community 12
  ]
  node [
    id 1582
    label "E:PERSPIRATION TUBES"
    kind "entity"
    name "PERSPIRATION TUBES"
    community 12
  ]
  node [
    id 1583
    label "E:SOAP AND WATER"
    kind "entity"
    name "SOAP AND WATER"
    community 12
  ]
  node [
    id 1584
    label "E:OUTDOORS"
    kind "entity"
    name "OUTDOORS"
    community 12
  ]
  node [
    id 1585
    label "E:DIRTY HANDS"
    kind "entity"
    name "DIRTY HANDS"
    community 12
  ]
  node [
    id 1586
    label "E:DIRTY FACES"
    kind "entity"
    name "DIRTY FACES"
    community 12
  ]
  node [
    id 1587
    label "E:CLEAN PLACE"
    kind "entity"
    name "CLEAN PLACE"
    community 12
  ]
  node [
    id 1588
    label "E:INTERNAL WASTE MATTER"
    kind "entity"
    name "INTERNAL WASTE MATTER"
    community 12
  ]
  node [
    id 1589
    label "E:MUD"
    kind "entity"
    name "MUD"
    community 12
  ]
  node [
    id 1590
    label "E:WASHING"
    kind "entity"
    name "WASHING"
    community 12
  ]
  node [
    id 1591
    label "E:FRESH SKIN"
    kind "entity"
    name "FRESH SKIN"
    community 12
  ]
  node [
    id 1592
    label "E:HEALTHY SKIN"
    kind "entity"
    name "HEALTHY SKIN"
    community 12
  ]
  node [
    id 1593
    label "E:SKIN WORK"
    kind "entity"
    name "SKIN WORK"
    community 12
  ]
  node [
    id 1594
    label "E:RUBBER BOOTS"
    kind "entity"
    name "RUBBER BOOTS"
    community 12
  ]
  node [
    id 1595
    label "E:RUBBER SHOES"
    kind "entity"
    name "RUBBER SHOES"
    community 12
  ]
  node [
    id 1596
    label "E:CLOGGED PORES"
    kind "entity"
    name "CLOGGED PORES"
    community 12
  ]
  node [
    id 1597
    label "E:FEET DISCOMFORT"
    kind "entity"
    name "FEET DISCOMFORT"
    community 12
  ]
  node [
    id 1598
    label "E:OPENINGS OF PERSPIRATION TUBES"
    kind "entity"
    name "OPENINGS OF PERSPIRATION TUBES"
    community 12
  ]
  node [
    id 1599
    label "E:MUD OR DUST"
    kind "entity"
    name "MUD OR DUST"
    community 12
  ]
  node [
    id 1600
    label "E:OVER TIME"
    kind "entity"
    name "OVER TIME"
    community 12
  ]
  node [
    id 1601
    label "E:SURVIVAL"
    kind "entity"
    name "SURVIVAL"
    community 12
  ]
  node [
    id 1602
    label "E:PERSPIRATION FROM PASSING OFF"
    kind "entity"
    name "PERSPIRATION FROM PASSING OFF"
    community 12
  ]
  node [
    id 1603
    label "E:RUBBER BOOTS AND SHOES"
    kind "entity"
    name "RUBBER BOOTS AND SHOES"
    community 12
  ]
  node [
    id 1604
    label "C:Novel-25646_00072"
    kind "chunk"
    chunk_id "Novel-25646_00072"
  ]
  node [
    id 1605
    label "U:Novel-25646_00072#0"
    kind "unit"
    chunk_id "Novel-25646_00072"
    text "No part of the body can function without causing trouble to the other parts; when the ground is wet, rubbers should be worn outdoors because they are very useful in such conditions. When out in fresh air, the body perspires, allowing feet to shut up slightly, but rubbers must be removed as soon as entering the house."
    community 12
  ]
  node [
    id 1606
    label "E:WET GROUND"
    kind "entity"
    name "WET GROUND"
    community 12
  ]
  node [
    id 1607
    label "E:RUBBERS"
    kind "entity"
    name "RUBBERS"
    community 12
  ]
  node [
    id 1608
    label "E:HOUSE"
    kind "entity"
    name "HOUSE"
    community 12
  ]
  node [
    id 1609
    label "E:OTHER PARTS"
    kind "entity"
    name "OTHER PARTS"
    community 12
  ]
  node [
    id 1610
    label "E:FEET TO SHUT UP"
    kind "entity"
    name "FEET TO SHUT UP"
    community 13
  ]
  node [
    id 1611
    label "U:Novel-25646_00072#1"
    kind "unit"
    chunk_id "Novel-25646_00072"
    text "Clothes worn next to the skin contain small worn-out particles brought out by perspiration; these should be air-dried thoroughly before being stored, and should never be worn overnight. Night-dresses should not be rolled up and placed under the pillow; instead, they should be aired at the window and hung where air can reach them all day."
    community 13
  ]
  node [
    id 1612
    label "E:WORN-OUT PARTICLES"
    kind "entity"
    name "WORN-OUT PARTICLES"
    community 13
  ]
  node [
    id 1613
    label "E:AIRING"
    kind "entity"
    name "AIRING"
    community 13
  ]
  node [
    id 1614
    label "E:NIGHT-DRESS"
    kind "entity"
    name "NIGHT-DRESS"
    community 13
  ]
  node [
    id 1615
    label "E:PILLOW"
    kind "entity"
    name "PILLOW"
    community 13
  ]
  node [
    id 1616
    label "E:WINDOW"
    kind "entity"
    name "WINDOW"
    community 13
  ]
  node [
    id 1617
    label "E:AIR CAN REACH IT"
    kind "entity"
    name "AIR CAN REACH IT"
    community 13
  ]
  node [
    id 1618
    label "U:Novel-25646_00072#2"
    kind "unit"
    chunk_id "Novel-25646_00072"
    text "Bed-clothes should be removed from the bed before leaving the room in the morning so that the bed and bed-clothes can have a good airing."
    community 13
  ]
  node [
    id 1619
    label "E:BED-CLOTHES"
    kind "entity"
    name "BED-CLOTHES"
    community 13
  ]
  node [
    id 1620
    label "E:BED"
    kind "entity"
    name "BED"
    community 13
  ]
  node [
    id 1621
    label "E:MORNING"
    kind "entity"
    name "MORNING"
    community 13
  ]
  node [
    id 1622
    label "C:Novel-25646_00073"
    kind "chunk"
    chunk_id "Novel-25646_00073"
  ]
  node [
    id 1623
    label "U:Novel-25646_00073#0"
    kind "unit"
    chunk_id "Novel-25646_00073"
    text "The bed and bed-clothes may have a good airing if given enough time, which helps keep them fresh and clean."
    community 13
  ]
  node [
    id 1624
    label "E:TIME"
    kind "entity"
    name "TIME"
    community 13
  ]
  node [
    id 1625
    label "U:Novel-25646_00073#1"
    kind "unit"
    chunk_id "Novel-25646_00073"
    text "The body performs four important kinds of work: the stomach prepares food for the blood, the blood is pumped from the heart to carry food and remove waste, the lungs use fresh air to make blood bright and pure again, and the skin removes waste through small perspiration tubes."
    community 0
  ]
  node [
    id 1626
    label "E:BLOOD CIRCULATION"
    kind "entity"
    name "BLOOD CIRCULATION"
    community 0
  ]
  node [
    id 1627
    label "E:BLOOD PURIFICATION"
    kind "entity"
    name "BLOOD PURIFICATION"
    community 0
  ]
  node [
    id 1628
    label "U:Novel-25646_00073#2"
    kind "unit"
    chunk_id "Novel-25646_00073"
    text "These bodily functions continue day and night without conscious thought, as nerves send messages to muscles to keep them working, whether or not a person is aware of it."
    community 4
  ]
  node [
    id 1629
    label "E:CONSCIOUS THOUGHT"
    kind "entity"
    name "CONSCIOUS THOUGHT"
    community 4
  ]
  node [
    id 1630
    label "E:WORKING"
    kind "entity"
    name "WORKING"
    community 4
  ]
  node [
    id 1631
    label "C:Novel-25646_00074"
    kind "chunk"
    chunk_id "Novel-25646_00074"
  ]
  node [
    id 1632
    label "U:Novel-25646_00074#0"
    kind "unit"
    chunk_id "Novel-25646_00074"
    text "You should not wear rubber boots or overshoes in the house because they can trap moisture and dirt, and may interfere with the proper functioning of the home environment or personal hygiene."
    community 12
  ]
  node [
    id 1633
    label "E:OVERSHOES"
    kind "entity"
    name "OVERSHOES"
    community 12
  ]
  node [
    id 1634
    label "U:Novel-25646_00074#1"
    kind "unit"
    chunk_id "Novel-25646_00074"
    text "Under-clothing should be changed at night and in the morning to maintain hygiene and prevent the buildup of bacteria and odors."
    community 13
  ]
  node [
    id 1635
    label "E:UNDER-CLOTHING"
    kind "entity"
    name "UNDER-CLOTHING"
    community 13
  ]
  node [
    id 1636
    label "U:Novel-25646_00074#2"
    kind "unit"
    chunk_id "Novel-25646_00074"
    text "The night-dress should be placed in a specific location in the morning, likely in a clean and accessible area such as a dresser or closet, to maintain order and hygiene."
    community 13
  ]
  node [
    id 1637
    label "U:Novel-25646_00074#3"
    kind "unit"
    chunk_id "Novel-25646_00074"
    text "Bed-clothes should be removed or changed to maintain cleanliness and prevent the accumulation of dust, sweat, and bacteria."
    community 13
  ]
  node [
    id 1638
    label "E:SWEAT"
    kind "entity"
    name "SWEAT"
    community 13
  ]
  node [
    id 1639
    label "E:BACTERIA"
    kind "entity"
    name "BACTERIA"
    community 13
  ]
  node [
    id 1640
    label "U:Novel-25646_00074#4"
    kind "unit"
    chunk_id "Novel-25646_00074"
    text "The four kinds of work about which you have learned are not explicitly named in the passage."
    community 13
  ]
  node [
    id 1641
    label "E:FOUR KINDS OF WORK"
    kind "entity"
    name "FOUR KINDS OF WORK"
    community 13
  ]
  node [
    id 1642
    label "C:Novel-25646_00075"
    kind "chunk"
    chunk_id "Novel-25646_00075"
  ]
  node [
    id 1643
    label "U:Novel-25646_00075#0"
    kind "unit"
    chunk_id "Novel-25646_00075"
    text "The pupils of a cat's eyes are very large in the dark so they can gather as much light as possible to detect mice."
    community 17
  ]
  node [
    id 1644
    label "E:CAT"
    kind "entity"
    name "CAT"
    community 17
  ]
  node [
    id 1645
    label "E:PUPL"
    kind "entity"
    name "PUPL"
    community 17
  ]
  node [
    id 1646
    label "E:MOUSE"
    kind "entity"
    name "MOUSE"
    community 17
  ]
  node [
    id 1647
    label "E:DARK"
    kind "entity"
    name "DARK"
    community 17
  ]
  node [
    id 1648
    label "U:Novel-25646_00075#1"
    kind "unit"
    chunk_id "Novel-25646_00075"
    text "The pupil of the eye opens into a small round chamber that houses the nerve of sight, a delicate structure that cannot tolerate excessive light."
    community 17
  ]
  node [
    id 1649
    label "E:NERVE OF SIGHT"
    kind "entity"
    name "NERVE OF SIGHT"
    community 17
  ]
  node [
    id 1650
    label "U:Novel-25646_00075#2"
    kind "unit"
    chunk_id "Novel-25646_00075"
    text "The nerve of sight transmits visual information to the brain, as if the eye is continuously taking pictures and the nerve is describing them."
    community 17
  ]
  node [
    id 1651
    label "E:EVERYTHING WE SEE"
    kind "entity"
    name "EVERYTHING WE SEE"
    community 17
  ]
  node [
    id 1652
    label "E:VISUAL INFORMATION TO BRAIN"
    kind "entity"
    name "VISUAL INFORMATION TO BRAIN"
    community 17
  ]
  node [
    id 1653
    label "U:Novel-25646_00075#3"
    kind "unit"
    chunk_id "Novel-25646_00075"
    text "The nerves of sight require great care because they are very delicate; one should not face bright light while reading or studying, and when writing, the light should come from the left side so that the hand shadow does not fall on the work."
    community 17
  ]
  node [
    id 1654
    label "E:BRIGHT LIGHT"
    kind "entity"
    name "BRIGHT LIGHT"
    community 17
  ]
  node [
    id 1655
    label "E:READING"
    kind "entity"
    name "READING"
    community 17
  ]
  node [
    id 1656
    label "E:STUDYING"
    kind "entity"
    name "STUDYING"
    community 17
  ]
  node [
    id 1657
    label "E:LEFT SIDE"
    kind "entity"
    name "LEFT SIDE"
    community 17
  ]
  node [
    id 1658
    label "E:HAND SHADOW"
    kind "entity"
    name "HAND SHADOW"
    community 9
  ]
  node [
    id 1659
    label "E:DELICATE"
    kind "entity"
    name "DELICATE"
    community 17
  ]
  node [
    id 1660
    label "U:Novel-25646_00075#4"
    kind "unit"
    chunk_id "Novel-25646_00075"
    text "When light is too strong, the nerve of sight requests that the pupil be made smaller and that the eyelid curtains be lowered to protect itself."
    community 17
  ]
  node [
    id 1661
    label "E:EYELID CURTAINS"
    kind "entity"
    name "EYELID CURTAINS"
    community 17
  ]
  node [
    id 1662
    label "C:Novel-25646_00076"
    kind "chunk"
    chunk_id "Novel-25646_00076"
  ]
  node [
    id 1663
    label "U:Novel-25646_00076#0"
    kind "unit"
    chunk_id "Novel-25646_00076"
    text "A boy told his playmates boastfully that they would see which of them could look straight at the sun for the longest time. They foolishly began to look at the sun, causing sharp pain in their delicate sight nerves, which begged to have their pupils made small and eyelids lowered. The boys refused and continued trying to see which could bear it the longest. As a result, great harm was done to both their brains and eyes, and the boy who looked the longest at the sun died from the foolish act."
    community 17
  ]
  node [
    id 1664
    label "E:BOY WHO SAID BOASTFULLY"
    kind "entity"
    name "BOY WHO SAID BOASTFULLY"
    community 17
  ]
  node [
    id 1665
    label "E:PLAYMATES"
    kind "entity"
    name "PLAYMATES"
    community 17
  ]
  node [
    id 1666
    label "E:DELICATE NERVES OF SIGHT"
    kind "entity"
    name "DELICATE NERVES OF SIGHT"
    community 17
  ]
  node [
    id 1667
    label "E:PUPILS"
    kind "entity"
    name "PUPILS"
    community 17
  ]
  node [
    id 1668
    label "E:BRAINS"
    kind "entity"
    name "BRAINS"
    community 17
  ]
  node [
    id 1669
    label "E:SHARP PAIN"
    kind "entity"
    name "SHARP PAIN"
    community 17
  ]
  node [
    id 1670
    label "E:PUPILS MADE SMALL"
    kind "entity"
    name "PUPILS MADE SMALL"
    community 17
  ]
  node [
    id 1671
    label "E:EYELID CURTAINS PUT DOWN"
    kind "entity"
    name "EYELID CURTAINS PUT DOWN"
    community 17
  ]
  node [
    id 1672
    label "E:LOWER PUPILS AND EYELIDS"
    kind "entity"
    name "LOWER PUPILS AND EYELIDS"
    community 17
  ]
  node [
    id 1673
    label "E:LOOKING AT THE SUN"
    kind "entity"
    name "LOOKING AT THE SUN"
    community 17
  ]
  node [
    id 1674
    label "E:BOY WHO LOOKED LONGEST AT THE SUN"
    kind "entity"
    name "BOY WHO LOOKED LONGEST AT THE SUN"
    community 17
  ]
  node [
    id 1675
    label "E:FOOLISH ACT"
    kind "entity"
    name "FOOLISH ACT"
    community 17
  ]
  node [
    id 1676
    label "U:Novel-25646_00076#1"
    kind "unit"
    chunk_id "Novel-25646_00076"
    text "A little boy tried to imitate a schoolmate who was cross-eyed by turning his eyes. He could not turn them back. Now, as a gentleman over fifty years old, he has had much painful eye work done, but doctors have never been able to correct his eyes properly."
    community 17
  ]
  node [
    id 1677
    label "E:LITTLE BOY WHO TRIED TO IMITATE SCHOOLMATE"
    kind "entity"
    name "LITTLE BOY WHO TRIED TO IMITATE SCHOOLMATE"
    community 17
  ]
  node [
    id 1678
    label "E:SCHOOLMATE WHO WAS CROSS-EYED"
    kind "entity"
    name "SCHOOLMATE WHO WAS CROSS-EYED"
    community 17
  ]
  node [
    id 1679
    label "E:FIFTY YEARS"
    kind "entity"
    name "FIFTY YEARS"
    community 17
  ]
  node [
    id 1680
    label "E:PAINFUL WORK DONE ON EYES"
    kind "entity"
    name "PAINFUL WORK DONE ON EYES"
    community 17
  ]
  node [
    id 1681
    label "U:Novel-25646_00076#2"
    kind "unit"
    chunk_id "Novel-25646_00076"
    text "From the first story, it is clear that one must be careful not to give the eyes too much light, but also must ensure they receive enough light. When one tries to read in the twilight, the little nerve of sight says: 'Give me more light; I am hurt by trying to see in the dark.'"
    community 17
  ]
  node [
    id 1682
    label "E:TWILIGHT"
    kind "entity"
    name "TWILIGHT"
    community 17
  ]
  node [
    id 1683
    label "E:LITTLE NERVE OF SIGHT"
    kind "entity"
    name "LITTLE NERVE OF SIGHT"
    community 17
  ]
  node [
    id 1684
    label "E:LIGHT"
    kind "entity"
    name "LIGHT"
    community 17
  ]
  node [
    id 1685
    label "E:GIVE MORE LIGHT"
    kind "entity"
    name "GIVE MORE LIGHT"
    community 17
  ]
  node [
    id 1686
    label "E:TRYING TO SEE IN THE DARK"
    kind "entity"
    name "TRYING TO SEE IN THE DARK"
    community 17
  ]
  node [
    id 1687
    label "E:READING IN TWILIGHT"
    kind "entity"
    name "READING IN TWILIGHT"
    community 17
  ]
  node [
    id 1688
    label "C:Novel-25646_00077"
    kind "chunk"
    chunk_id "Novel-25646_00077"
  ]
  node [
    id 1689
    label "U:Novel-25646_00077#0"
    kind "unit"
    chunk_id "Novel-25646_00077"
    text "If the delicate nerves in the ears are damaged, no new nerves will grow in their place and a person will never be able to see again. The ears consist of curved gristle that catches sounds and transmits them to the true ears, which are deeper in the head and contain the nerve of hearing that sends sound information to the brain. The ear nerve is less vulnerable than the eye nerve. Careless children may break the 'drum' of the ear by inserting pins, which is a very bad thing. Only a soft towel should be used when washing the ears; nothing hard or sharp should be inserted into them."
    community 8
  ]
  node [
    id 1690
    label "E:DELICATE NERVES"
    kind "entity"
    name "DELICATE NERVES"
    community 8
  ]
  node [
    id 1691
    label "E:EARS"
    kind "entity"
    name "EARS"
    community 8
  ]
  node [
    id 1692
    label "E:SOUNDS"
    kind "entity"
    name "SOUNDS"
    community 8
  ]
  node [
    id 1693
    label "E:TRUE EARS"
    kind "entity"
    name "TRUE EARS"
    community 8
  ]
  node [
    id 1694
    label "E:NERVE OF HEARING"
    kind "entity"
    name "NERVE OF HEARING"
    community 8
  ]
  node [
    id 1695
    label "E:CARELESS CHILDREN"
    kind "entity"
    name "CARELESS CHILDREN"
    community 8
  ]
  node [
    id 1696
    label "E:DRUM"
    kind "entity"
    name "DRUM"
    community 8
  ]
  node [
    id 1697
    label "E:SOFT TOWEL"
    kind "entity"
    name "SOFT TOWEL"
    community 8
  ]
  node [
    id 1698
    label "E:HARD OR SHARP OBJECT"
    kind "entity"
    name "HARD OR SHARP OBJECT"
    community 8
  ]
  node [
    id 1699
    label "E:NO OTHER NERVES"
    kind "entity"
    name "NO OTHER NERVES"
    community 8
  ]
  node [
    id 1700
    label "E:HEAD"
    kind "entity"
    name "HEAD"
    community 8
  ]
  node [
    id 1701
    label "E:WASHING EARS"
    kind "entity"
    name "WASHING EARS"
    community 8
  ]
  node [
    id 1702
    label "E:ANYTHING HARD OR SHARP"
    kind "entity"
    name "ANYTHING HARD OR SHARP"
    community 8
  ]
  node [
    id 1703
    label "U:Novel-25646_00077#1"
    kind "unit"
    chunk_id "Novel-25646_00077"
    text "A short ear story about the speaker's father when he was a small boy: one day, while playing on the floor, he laid his ear to the crack of the door to feel the wind blowing into it. He did not know it was wrong at the time, and the next day he developed a severe earache. Although he lived to be an old man, he often had earaches and believed they began when the wind blew into his ear from under the door."
    community 8
  ]
  node [
    id 1704
    label "E:SPEAKER'S FATHER"
    kind "entity"
    name "SPEAKER'S FATHER"
    community 8
  ]
  node [
    id 1705
    label "E:SMALL BOY"
    kind "entity"
    name "SMALL BOY"
    community 8
  ]
  node [
    id 1706
    label "E:FLOOR"
    kind "entity"
    name "FLOOR"
    community 8
  ]
  node [
    id 1707
    label "E:CRACK OF THE DOOR"
    kind "entity"
    name "CRACK OF THE DOOR"
    community 8
  ]
  node [
    id 1708
    label "E:WIND"
    kind "entity"
    name "WIND"
    community 8
  ]
  node [
    id 1709
    label "E:NEXT DAY"
    kind "entity"
    name "NEXT DAY"
    community 8
  ]
  node [
    id 1710
    label "E:EARACHE"
    kind "entity"
    name "EARACHE"
    community 8
  ]
  node [
    id 1711
    label "E:OLD MAN"
    kind "entity"
    name "OLD MAN"
    community 8
  ]
  node [
    id 1712
    label "E:WIND BLOWING INTO EAR"
    kind "entity"
    name "WIND BLOWING INTO EAR"
    community 8
  ]
  node [
    id 1713
    label "E:LAYING EAR TO CRACK"
    kind "entity"
    name "LAYING EAR TO CRACK"
    community 8
  ]
  node [
    id 1714
    label "E:SEVERE EARACHE"
    kind "entity"
    name "SEVERE EARACHE"
    community 8
  ]
  node [
    id 1715
    label "C:Novel-25646_00078"
    kind "chunk"
    chunk_id "Novel-25646_00078"
  ]
  node [
    id 1716
    label "U:Novel-25646_00078#0"
    kind "unit"
    chunk_id "Novel-25646_00078"
    text "Alcohol interferes with the proper functioning of the five senses&#8212;touch, taste, sight, smell, and hearing&#8212;by confusing the nerves that control them. A person who regularly consumes alcohol has impaired touch, taste, vision, smell, and hearing; his hands tremble, his speech becomes thick, and he may struggle to walk straight. He may also perceive things that are not there because his nerves are disrupted by alcohol."
    community 4
  ]
  node [
    id 1717
    label "E:FIVE SENSES"
    kind "entity"
    name "FIVE SENSES"
    community 4
  ]
  node [
    id 1718
    label "E:SEEING"
    kind "entity"
    name "SEEING"
    community 4
  ]
  node [
    id 1719
    label "E:SMELL"
    kind "entity"
    name "SMELL"
    community 4
  ]
  node [
    id 1720
    label "E:HEARING"
    kind "entity"
    name "HEARING"
    community 4
  ]
  node [
    id 1721
    label "E:HANDS"
    kind "entity"
    name "HANDS"
    community 4
  ]
  node [
    id 1722
    label "E:SPEECH"
    kind "entity"
    name "SPEECH"
    community 4
  ]
  node [
    id 1723
    label "E:VISUAL PERCEPTION"
    kind "entity"
    name "VISUAL PERCEPTION"
    community 4
  ]
  node [
    id 1724
    label "U:Novel-25646_00078#1"
    kind "unit"
    chunk_id "Novel-25646_00078"
    text "The five senses are touch, taste, sight, smell, and hearing. The pupil of the eye changes size to control the amount of light entering the eye. It becomes larger in dim light and smaller in bright light to protect the retina from damage. A cat's eyes can adjust to low light conditions and see well in the dark. The nerve of the eye transmits visual information to the brain. One must be careful of the eyes because damage to the nerves can impair vision. For reading or studying, light should be positioned directly in front of the person to avoid eye strain. The story of the boys who looked at the sun involves them experiencing harm due to staring at the sun, which damaged their eyes. The story of the boy who made himself cross-eyed describes a person intentionally causing his eyes to misalign, which results in double vision and visual distortion."
    community 17
  ]
  node [
    id 1725
    label "E:PUPIL OF THE EYE"
    kind "entity"
    name "PUPIL OF THE EYE"
    community 17
  ]
  node [
    id 1726
    label "E:DIM LIGHT"
    kind "entity"
    name "DIM LIGHT"
    community 17
  ]
  node [
    id 1727
    label "E:CAT'S EYES"
    kind "entity"
    name "CAT'S EYES"
    community 17
  ]
  node [
    id 1728
    label "E:NERVE OF THE EYE"
    kind "entity"
    name "NERVE OF THE EYE"
    community 17
  ]
  node [
    id 1729
    label "E:LIGHT POSITION"
    kind "entity"
    name "LIGHT POSITION"
    community 17
  ]
  node [
    id 1730
    label "E:BOYS WHO LOOKED AT THE SUN"
    kind "entity"
    name "BOYS WHO LOOKED AT THE SUN"
    community 17
  ]
  node [
    id 1731
    label "E:BOY WHO MADE HIMSELF CROSS-EYED"
    kind "entity"
    name "BOY WHO MADE HIMSELF CROSS-EYED"
    community 17
  ]
  node [
    id 1732
    label "E:DOUBLE VISION"
    kind "entity"
    name "DOUBLE VISION"
    community 17
  ]
  node [
    id 1733
    label "E:EYE DAMAGE"
    kind "entity"
    name "EYE DAMAGE"
    community 17
  ]
  node [
    id 1734
    label "E:DARKNESS"
    kind "entity"
    name "DARKNESS"
    community 17
  ]
  node [
    id 1735
    label "E:STARING AT THE SUN"
    kind "entity"
    name "STARING AT THE SUN"
    community 17
  ]
  node [
    id 1736
    label "C:Novel-25646_00079"
    kind "chunk"
    chunk_id "Novel-25646_00079"
  ]
  node [
    id 1737
    label "U:Novel-25646_00079#0"
    kind "unit"
    chunk_id "Novel-25646_00079"
    text "If the nerves of sight are killed, the result is loss of vision."
    community 8
  ]
  node [
    id 1738
    label "E:NERVES OF SIGHT"
    kind "entity"
    name "NERVES OF SIGHT"
    community 8
  ]
  node [
    id 1739
    label "E:VISION"
    kind "entity"
    name "VISION"
    community 8
  ]
  node [
    id 1740
    label "E:LOSS OF VISION"
    kind "entity"
    name "LOSS OF VISION"
    community 8
  ]
  node [
    id 1741
    label "U:Novel-25646_00079#1"
    kind "unit"
    chunk_id "Novel-25646_00079"
    text "The true ears are not the external ears but the internal structures responsible for hearing."
    community 8
  ]
  node [
    id 1742
    label "U:Novel-25646_00079#2"
    kind "unit"
    chunk_id "Novel-25646_00079"
    text "The nerves of hearing may be injured by exposure to loud sounds, excessive noise, or physical trauma."
    community 8
  ]
  node [
    id 1743
    label "E:NERVES OF HEARING"
    kind "entity"
    name "NERVES OF HEARING"
    community 8
  ]
  node [
    id 1744
    label "E:LOUD SOUNDS"
    kind "entity"
    name "LOUD SOUNDS"
    community 8
  ]
  node [
    id 1745
    label "E:EXCESSIVE NOISE"
    kind "entity"
    name "EXCESSIVE NOISE"
    community 8
  ]
  node [
    id 1746
    label "E:PHYSICAL TRAUMA"
    kind "entity"
    name "PHYSICAL TRAUMA"
    community 8
  ]
  node [
    id 1747
    label "U:Novel-25646_00079#3"
    kind "unit"
    chunk_id "Novel-25646_00079"
    text "The boy who injured his ear accidentally put his ear against a loud noise source, which damaged the nerves of hearing."
    community 8
  ]
  node [
    id 1748
    label "E:BOY WHO INJURED HIS EAR"
    kind "entity"
    name "BOY WHO INJURED HIS EAR"
    community 8
  ]
  node [
    id 1749
    label "E:EAR"
    kind "entity"
    name "EAR"
    community 8
  ]
  node [
    id 1750
    label "E:LOUD NOISE"
    kind "entity"
    name "LOUD NOISE"
    community 8
  ]
  node [
    id 1751
    label "U:Novel-25646_00079#4"
    kind "unit"
    chunk_id "Novel-25646_00079"
    text "Drinking liquor affects the work of the senses by impairing their function, reducing sensitivity and causing confusion."
    community 8
  ]
  node [
    id 1752
    label "E:DRINKING LIQUOR"
    kind "entity"
    name "DRINKING LIQUOR"
    community 8
  ]
  node [
    id 1753
    label "E:WORK OF THE SENSES"
    kind "entity"
    name "WORK OF THE SENSES"
    community 8
  ]
  node [
    id 1754
    label "E:SENSORY FUNCTION"
    kind "entity"
    name "SENSORY FUNCTION"
    community 8
  ]
  node [
    id 1755
    label "E:CONFUSION"
    kind "entity"
    name "CONFUSION"
    community 8
  ]
  node [
    id 1756
    label "U:Novel-25646_00079#5"
    kind "unit"
    chunk_id "Novel-25646_00079"
    text "Thick, warm clothes do not make a person warm; they only keep the body warm by insulating it. A brisk run or physical activity increases blood flow and warms the body internally. On a cold day, a teamster claps his hands and swings his arms to increase blood flow and generate warmth. Children know they are warm inside; if fingers are cold, they put them in their mouth to warm them. A thermometer under the tongue or in the mouth shows the same temperature as outside on a hot summer day, regardless of season or location, as long as the body is healthy and functioning normally."
    community 16
  ]
  node [
    id 1757
    label "E:THICK WARM CLOTHES"
    kind "entity"
    name "THICK WARM CLOTHES"
    community 16
  ]
  node [
    id 1758
    label "E:BLOOD FLOW"
    kind "entity"
    name "BLOOD FLOW"
    community 16
  ]
  node [
    id 1759
    label "E:TEAMSTER"
    kind "entity"
    name "TEAMSTER"
    community 16
  ]
  node [
    id 1760
    label "E:BRISK RUN"
    kind "entity"
    name "BRISK RUN"
    community 16
  ]
  node [
    id 1761
    label "E:THERMOMETER"
    kind "entity"
    name "THERMOMETER"
    community 16
  ]
  node [
    id 1762
    label "E:WARM COUNTRY"
    kind "entity"
    name "WARM COUNTRY"
    community 16
  ]
  node [
    id 1763
    label "E:COLD DAY"
    kind "entity"
    name "COLD DAY"
    community 11
  ]
  node [
    id 1764
    label "E:HEALTHY BODY"
    kind "entity"
    name "HEALTHY BODY"
    community 16
  ]
  node [
    id 1765
    label "E:STABLE BODY WORK"
    kind "entity"
    name "STABLE BODY WORK"
    community 16
  ]
  node [
    id 1766
    label "E:INCREASE BLOOD FLOW"
    kind "entity"
    name "INCREASE BLOOD FLOW"
    community 16
  ]
  node [
    id 1767
    label "E:OUTSIDE ON A HOT SUMMER DAY"
    kind "entity"
    name "OUTSIDE ON A HOT SUMMER DAY"
    community 16
  ]
  node [
    id 1768
    label "E:SAME INTERNAL TEMPERATURE"
    kind "entity"
    name "SAME INTERNAL TEMPERATURE"
    community 16
  ]
  node [
    id 1769
    label "U:Novel-25646_00079#6"
    kind "unit"
    chunk_id "Novel-25646_00079"
    text "The heat in the body comes from internal metabolic processes, not from external sources."
    community 10
  ]
  node [
    id 1770
    label "E:INTERNAL METABOLIC PROCESSES"
    kind "entity"
    name "INTERNAL METABOLIC PROCESSES"
    community 10
  ]
  node [
    id 1771
    label "C:Novel-25646_00080"
    kind "chunk"
    chunk_id "Novel-25646_00080"
  ]
  node [
    id 1772
    label "U:Novel-25646_00080#0"
    kind "unit"
    chunk_id "Novel-25646_00080"
    text "Some of the bodily processes generate heat, which warms the blood; the blood then transports this heat to every part of the body. The faster the blood flows, the more heat it carries, and the warmer a person feels."
    community 10
  ]
  node [
    id 1773
    label "E:BODILY PROCESSES"
    kind "entity"
    name "BODILY PROCESSES"
    community 10
  ]
  node [
    id 1774
    label "U:Novel-25646_00080#1"
    kind "unit"
    chunk_id "Novel-25646_00080"
    text "In children, the heart pumps between eighty and ninety times per minute, which is faster than in older people, and this contributes to children generally feeling warmer than older people."
    community 12
  ]
  node [
    id 1775
    label "E:PUMPING RATE"
    kind "entity"
    name "PUMPING RATE"
    community 12
  ]
  node [
    id 1776
    label "E:80-90 TIMES PER MINUTE"
    kind "entity"
    name "80-90 TIMES PER MINUTE"
    community 12
  ]
  node [
    id 1777
    label "E:FASTER HEART PUMPING"
    kind "entity"
    name "FASTER HEART PUMPING"
    community 12
  ]
  node [
    id 1778
    label "E:CHILDREN FEELING WARMER"
    kind "entity"
    name "CHILDREN FEELING WARMER"
    community 12
  ]
  node [
    id 1779
    label "U:Novel-25646_00080#2"
    kind "unit"
    chunk_id "Novel-25646_00080"
    text "The body continuously loses heat; when breathing in cold air, exhaled air is warm, and a significant amount of body heat escapes through the skin into cooler surrounding air. A room filled with people feels warmer than an empty room because of this heat retention."
    community 10
  ]
  node [
    id 1780
    label "E:HEAT LOSS"
    kind "entity"
    name "HEAT LOSS"
    community 10
  ]
  node [
    id 1781
    label "E:COLD AIR"
    kind "entity"
    name "COLD AIR"
    community 10
  ]
  node [
    id 1782
    label "E:WARM AIR"
    kind "entity"
    name "WARM AIR"
    community 10
  ]
  node [
    id 1783
    label "E:COOLER AIR"
    kind "entity"
    name "COOLER AIR"
    community 10
  ]
  node [
    id 1784
    label "E:ROOM WITH PEOPLE"
    kind "entity"
    name "ROOM WITH PEOPLE"
    community 10
  ]
  node [
    id 1785
    label "E:ROOM WITHOUT PEOPLE"
    kind "entity"
    name "ROOM WITHOUT PEOPLE"
    community 10
  ]
  node [
    id 1786
    label "U:Novel-25646_00080#3"
    kind "unit"
    chunk_id "Novel-25646_00080"
    text "Clothing is worn to retain existing body heat and to block cold air from reaching the skin and removing heat. Woolen under-garments keep people warm in winter, and thick boots and stockings are recommended in cold weather."
    community 10
  ]
  node [
    id 1787
    label "E:CLOTHING"
    kind "entity"
    name "CLOTHING"
    community 10
  ]
  node [
    id 1788
    label "E:BODY HEAT"
    kind "entity"
    name "BODY HEAT"
    community 10
  ]
  node [
    id 1789
    label "E:WOOLEN UNDER-GARMENTS"
    kind "entity"
    name "WOOLEN UNDER-GARMENTS"
    community 10
  ]
  node [
    id 1790
    label "E:THICK BOOTS"
    kind "entity"
    name "THICK BOOTS"
    community 10
  ]
  node [
    id 1791
    label "E:THICK STOCKINGS"
    kind "entity"
    name "THICK STOCKINGS"
    community 10
  ]
  node [
    id 1792
    label "E:COLD AIR FROM REACHING SKIN"
    kind "entity"
    name "COLD AIR FROM REACHING SKIN"
    community 10
  ]
  node [
    id 1793
    label "E:THICK BOOTS AND STOCKINGS"
    kind "entity"
    name "THICK BOOTS AND STOCKINGS"
    community 10
  ]
  node [
    id 1794
    label "C:Novel-25646_00081"
    kind "chunk"
    chunk_id "Novel-25646_00081"
  ]
  node [
    id 1795
    label "U:Novel-25646_00081#0"
    kind "unit"
    chunk_id "Novel-25646_00081"
    text "Thin dresses or boots may look attractive but are unsafe for winter wear, even at a party. A healthy, happy child dressed in season-appropriate clothing is more pleasant to look at than one wearing rich and handsome clothes that are not warm enough for health or comfort. When cold is felt, taking exercise is recommended as it promotes blood flow and warms the body; if not possible, one should add more clothing, go to a warm room, or take steps to get and stay warm, otherwise cold may lead to illness."
    community 16
  ]
  node [
    id 1796
    label "E:THIN DRESSES"
    kind "entity"
    name "THIN DRESSES"
    community 16
  ]
  node [
    id 1797
    label "E:BOOTS"
    kind "entity"
    name "BOOTS"
    community 16
  ]
  node [
    id 1798
    label "E:WINTER WEAR"
    kind "entity"
    name "WINTER WEAR"
    community 16
  ]
  node [
    id 1799
    label "E:PARTY"
    kind "entity"
    name "PARTY"
    community 16
  ]
  node [
    id 1800
    label "E:HEALTHY CHILD"
    kind "entity"
    name "HEALTHY CHILD"
    community 16
  ]
  node [
    id 1801
    label "E:SEASON-APPRIOPRIATE CLOTHING"
    kind "entity"
    name "SEASON-APPRIOPRIATE CLOTHING"
    community 16
  ]
  node [
    id 1802
    label "E:RICH AND HANDSOME CLOTHING"
    kind "entity"
    name "RICH AND HANDSOME CLOTHING"
    community 16
  ]
  node [
    id 1803
    label "E:WARMING THE BODY"
    kind "entity"
    name "WARMING THE BODY"
    community 16
  ]
  node [
    id 1804
    label "E:ILLNESS"
    kind "entity"
    name "ILLNESS"
    community 16
  ]
  node [
    id 1805
    label "E:PRETTY"
    kind "entity"
    name "PRETTY"
    community 16
  ]
  node [
    id 1806
    label "E:CHILD IN UNWARM CLOTHING"
    kind "entity"
    name "CHILD IN UNWARM CLOTHING"
    community 16
  ]
  node [
    id 1807
    label "E:NEED TO GET WARM"
    kind "entity"
    name "NEED TO GET WARM"
    community 16
  ]
  node [
    id 1808
    label "U:Novel-25646_00081#1"
    kind "unit"
    chunk_id "Novel-25646_00081"
    text "If skin is chilled, the tiny mouths of perspiration tubes may close and fail to expel waste matter. When one part fails, other parts suffer, possibly leading to inflammation of the inside skin, throat, or lungs, resulting in a cold or cough."
    community 12
  ]
  node [
    id 1809
    label "E:CHILLED SKIN"
    kind "entity"
    name "CHILLED SKIN"
    community 12
  ]
  node [
    id 1810
    label "E:INSIDE SKIN"
    kind "entity"
    name "INSIDE SKIN"
    community 12
  ]
  node [
    id 1811
    label "E:COUGH"
    kind "entity"
    name "COUGH"
    community 12
  ]
  node [
    id 1812
    label "E:ONE PART FAILURE"
    kind "entity"
    name "ONE PART FAILURE"
    community 12
  ]
  node [
    id 1813
    label "U:Novel-25646_00081#2"
    kind "unit"
    chunk_id "Novel-25646_00081"
    text "People used to believe that alcoholic drinks, such as whiskey, would warm a person best on a cold day. Drinking a small amount of alcohol causes a burning sensation in the throat and later a glowing heat on the skin."
    community 11
  ]
  node [
    id 1814
    label "E:DRINKING ALCOHOL"
    kind "entity"
    name "DRINKING ALCOHOL"
    community 11
  ]
  node [
    id 1815
    label "E:BURNING IN THROAT"
    kind "entity"
    name "BURNING IN THROAT"
    community 11
  ]
  node [
    id 1816
    label "E:GLOWING HEAT ON SKIN"
    kind "entity"
    name "GLOWING HEAT ON SKIN"
    community 11
  ]
  node [
    id 1817
    label "E:PERSON ON A COLD DAY"
    kind "entity"
    name "PERSON ON A COLD DAY"
    community 11
  ]
  node [
    id 1818
    label "C:Novel-25646_00082"
    kind "chunk"
    chunk_id "Novel-25646_00082"
  ]
  node [
    id 1819
    label "U:Novel-25646_00082#0"
    kind "unit"
    chunk_id "Novel-25646_00082"
    text "The alcohol causes hot blood to rush into the tiny tubes near the skin, making the drinker feel warmer, but this heat transfer allows cold air to carry away more body heat, leading to the drinker becoming colder than before. The alcohol deadens the nerves, so the brain receives no warning signals, and the person may not realize they are getting colder and may not put on more clothing, potentially freezing or even freezing to death in very cold conditions. People who have not drunk alcohol can still freeze, but would have frozen much quicker if they had consumed alcohol."
    community 10
  ]
  node [
    id 1820
    label "E:HOT BLOOD"
    kind "entity"
    name "HOT BLOOD"
    community 10
  ]
  node [
    id 1821
    label "E:TINY TUBES NEAR THE SKIN"
    kind "entity"
    name "TINY TUBES NEAR THE SKIN"
    community 10
  ]
  node [
    id 1822
    label "E:FREEZING"
    kind "entity"
    name "FREEZING"
    community 10
  ]
  node [
    id 1823
    label "E:FREEZE TO DEATH"
    kind "entity"
    name "FREEZE TO DEATH"
    community 10
  ]
  node [
    id 1824
    label "E:WATER-DRINKERS"
    kind "entity"
    name "WATER-DRINKERS"
    community 10
  ]
  node [
    id 1825
    label "E:WINTER DAY"
    kind "entity"
    name "WINTER DAY"
    community 10
  ]
  node [
    id 1826
    label "E:HORSE-CAR DRIVERS"
    kind "entity"
    name "HORSE-CAR DRIVERS"
    community 10
  ]
  node [
    id 1827
    label "E:OMNIBUS DRIVERS"
    kind "entity"
    name "OMNIBUS DRIVERS"
    community 10
  ]
  node [
    id 1828
    label "E:ARCTIC EXPLORERS"
    kind "entity"
    name "ARCTIC EXPLORERS"
    community 10
  ]
  node [
    id 1829
    label "E:SHIPS"
    kind "entity"
    name "SHIPS"
    community 10
  ]
  node [
    id 1830
    label "E:ICE-FIELDS"
    kind "entity"
    name "ICE-FIELDS"
    community 10
  ]
  node [
    id 1831
    label "E:SLEDGES"
    kind "entity"
    name "SLEDGES"
    community 10
  ]
  node [
    id 1832
    label "E:DOGS"
    kind "entity"
    name "DOGS"
    community 10
  ]
  node [
    id 1833
    label "E:ESQUIMAU HUTS"
    kind "entity"
    name "ESQUIMAU HUTS"
    community 10
  ]
  node [
    id 1834
    label "E:WALRUS MEAT"
    kind "entity"
    name "WALRUS MEAT"
    community 10
  ]
  node [
    id 1835
    label "E:VERY COLD"
    kind "entity"
    name "VERY COLD"
    community 10
  ]
  node [
    id 1836
    label "E:PEOPLE WHO HAVE NOT DRUNK ALCOHOL"
    kind "entity"
    name "PEOPLE WHO HAVE NOT DRUNK ALCOHOL"
    community 10
  ]
  node [
    id 1837
    label "E:IF THEY HAD DRUNK ALCOHOL"
    kind "entity"
    name "IF THEY HAD DRUNK ALCOHOL"
    community 10
  ]
  node [
    id 1838
    label "E:COLD WINTER DAY"
    kind "entity"
    name "COLD WINTER DAY"
    community 10
  ]
  node [
    id 1839
    label "E:WATER-DRINKERS HOLD OUT BEST AGAINST THE COLD"
    kind "entity"
    name "WATER-DRINKERS HOLD OUT BEST AGAINST THE COLD"
    community 10
  ]
  node [
    id 1840
    label "E:ALL CHILDREN"
    kind "entity"
    name "ALL CHILDREN"
    community 10
  ]
  node [
    id 1841
    label "U:Novel-25646_00082#1"
    kind "unit"
    chunk_id "Novel-25646_00082"
    text "Children are interested in stories about Arctic explorers who live in Esquimau huts, travel on sledges drawn by dogs, drink oil, and eat walrus meat, and whose ships become frozen in ice-fields during winter."
    community 10
  ]
  node [
    id 1842
    label "C:Novel-25646_00083"
    kind "chunk"
    chunk_id "Novel-25646_00083"
  ]
  node [
    id 1843
    label "U:Novel-25646_00083#0"
    kind "unit"
    chunk_id "Novel-25646_00083"
    text "These men, including hunters and trappers in the snowy regions of the Rocky Mountains, state that alcohol does not keep them warm and actually reduces their ability to resist the cold."
    community 16
  ]
  node [
    id 1844
    label "E:HUNTERS"
    kind "entity"
    name "HUNTERS"
    community 16
  ]
  node [
    id 1845
    label "E:TRAPPERS"
    kind "entity"
    name "TRAPPERS"
    community 16
  ]
  node [
    id 1846
    label "E:ROCKY MOUNTAINS"
    kind "entity"
    name "ROCKY MOUNTAINS"
    community 16
  ]
  node [
    id 1847
    label "U:Novel-25646_00083#1"
    kind "unit"
    chunk_id "Novel-25646_00083"
    text "The Greely party, consisting of twenty-six men, were rescued from the Arctic seas after starving and freezing for many months; nineteen of them died, seven were found alive, and one of those seven died shortly after being rescued."
    community 10
  ]
  node [
    id 1848
    label "E:GREELY PARTY"
    kind "entity"
    name "GREELY PARTY"
    community 10
  ]
  node [
    id 1849
    label "E:26 MEN"
    kind "entity"
    name "26 MEN"
    community 10
  ]
  node [
    id 1850
    label "E:ARCTIC SEAS"
    kind "entity"
    name "ARCTIC SEAS"
    community 10
  ]
  node [
    id 1851
    label "E:STARVING"
    kind "entity"
    name "STARVING"
    community 10
  ]
  node [
    id 1852
    label "E:RESCUED"
    kind "entity"
    name "RESCUED"
    community 10
  ]
  node [
    id 1853
    label "E:19 DEATHS"
    kind "entity"
    name "19 DEATHS"
    community 10
  ]
  node [
    id 1854
    label "E:7 SURVIVORS"
    kind "entity"
    name "7 SURVIVORS"
    community 10
  ]
  node [
    id 1855
    label "E:1 DEATH AFTER RESCUE"
    kind "entity"
    name "1 DEATH AFTER RESCUE"
    community 10
  ]
  node [
    id 1856
    label "E:STARVING AND FREEZING"
    kind "entity"
    name "STARVING AND FREEZING"
    community 10
  ]
  node [
    id 1857
    label "U:Novel-25646_00083#2"
    kind "unit"
    chunk_id "Novel-25646_00083"
    text "The first man to die in the Greely party was the only one who had ever been a drunkard; of the nineteen who died, all but one used tobacco; among the six now living, four never used tobacco and two used it very seldom."
    community 5
  ]
  node [
    id 1858
    label "E:FIRST MAN TO DIE"
    kind "entity"
    name "FIRST MAN TO DIE"
    community 5
  ]
  node [
    id 1859
    label "E:19 MEN WHO DIED"
    kind "entity"
    name "19 MEN WHO DIED"
    community 5
  ]
  node [
    id 1860
    label "E:6 MEN NOW LIVING"
    kind "entity"
    name "6 MEN NOW LIVING"
    community 5
  ]
  node [
    id 1861
    label "E:4 MEN WHO NEVER USED TOBACCO"
    kind "entity"
    name "4 MEN WHO NEVER USED TOBACCO"
    community 5
  ]
  node [
    id 1862
    label "E:2 MEN WHO USED TOBACCO SOMETIMES"
    kind "entity"
    name "2 MEN WHO USED TOBACCO SOMETIMES"
    community 5
  ]
  node [
    id 1863
    label "U:Novel-25646_00083#3"
    kind "unit"
    chunk_id "Novel-25646_00083"
    text "The tobacco used by the Greely party probably weakened their stomachs, making it impossible for them to properly utilize the poor food available during their ordeal."
    community 10
  ]
  node [
    id 1864
    label "E:POOR FOOD"
    kind "entity"
    name "POOR FOOD"
    community 10
  ]
  node [
    id 1865
    label "E:WEAKENED STOMACH"
    kind "entity"
    name "WEAKENED STOMACH"
    community 10
  ]
  node [
    id 1866
    label "C:Novel-25646_00084"
    kind "chunk"
    chunk_id "Novel-25646_00084"
  ]
  node [
    id 1867
    label "U:Novel-25646_00084#0"
    kind "unit"
    chunk_id "Novel-25646_00084"
    text "The passage poses a series of questions about the human body's heat transfer, heart rate, heat loss, methods of warming without fire, and the effects of alcohol on body temperature and perception, including how alcohol creates a false sense of warmth and what people in cold countries report about its use. It also discusses how tobacco affected men who traveled to the Arctic seas with Lieutenant Greely."
    community 10
  ]
  node [
    id 1868
    label "E:HEART BEAT"
    kind "entity"
    name "HEART BEAT"
    community 10
  ]
  node [
    id 1869
    label "E:WARMING WITHOUT FIRE"
    kind "entity"
    name "WARMING WITHOUT FIRE"
    community 10
  ]
  node [
    id 1870
    label "E:FEELING OF WARMTH"
    kind "entity"
    name "FEELING OF WARMTH"
    community 10
  ]
  node [
    id 1871
    label "E:LIEUTENANT GREELY"
    kind "entity"
    name "LIEUTENANT GREELY"
    community 10
  ]
  node [
    id 1872
    label "E:PEOPLE IN COLD COUNTRIES"
    kind "entity"
    name "PEOPLE IN COLD COUNTRIES"
    community 10
  ]
  node [
    id 1873
    label "E:MEN WHO TRAVELED TO ARCTIC SEAS"
    kind "entity"
    name "MEN WHO TRAVELED TO ARCTIC SEAS"
    community 10
  ]
  node [
    id 1874
    label "U:Novel-25646_00084#1"
    kind "unit"
    chunk_id "Novel-25646_00084"
    text "Alcohol costs a great deal of money, and spending money on it is considered wasted because it does no good and only causes harm. If a boy or girl saves ten cents a week, it will take ten weeks to save a dollar. A beer drinker who consumes two mugs of beer a day would spend a dollar in ten days. The word 'used' should not be used when describing this spending because it implies useful expenditure."
    community 11
  ]
  node [
    id 1875
    label "E:SAVING"
    kind "entity"
    name "SAVING"
    community 11
  ]
  node [
    id 1876
    label "E:DOLLAR"
    kind "entity"
    name "DOLLAR"
    community 11
  ]
  node [
    id 1877
    label "E:GIRL"
    kind "entity"
    name "GIRL"
    community 11
  ]
  node [
    id 1878
    label "E:TEN CENTS"
    kind "entity"
    name "TEN CENTS"
    community 11
  ]
  node [
    id 1879
    label "E:WEEK"
    kind "entity"
    name "WEEK"
    community 11
  ]
  node [
    id 1880
    label "E:BEER DRINKER"
    kind "entity"
    name "BEER DRINKER"
    community 11
  ]
  node [
    id 1881
    label "E:MUGS OF BEER"
    kind "entity"
    name "MUGS OF BEER"
    community 11
  ]
  node [
    id 1882
    label "E:USEFUL EXPENDITURE"
    kind "entity"
    name "USEFUL EXPENDITURE"
    community 11
  ]
  node [
    id 1883
    label "E:MONEY SPENT ON ALCOHOL"
    kind "entity"
    name "MONEY SPENT ON ALCOHOL"
    community 11
  ]
  node [
    id 1884
    label "E:BECAUSE IT DOES NO GOOD AND ONLY CAUSES HARM"
    kind "entity"
    name "BECAUSE IT DOES NO GOOD AND ONLY CAUSES HARM"
    community 11
  ]
  node [
    id 1885
    label "E:BOY OR GIRL"
    kind "entity"
    name "BOY OR GIRL"
    community 11
  ]
  node [
    id 1886
    label "E:TEN CENTS PER WEEK"
    kind "entity"
    name "TEN CENTS PER WEEK"
    community 11
  ]
  node [
    id 1887
    label "E:TWO MUGS OF BEER PER DAY"
    kind "entity"
    name "TWO MUGS OF BEER PER DAY"
    community 11
  ]
  node [
    id 1888
    label "E:TEN DAYS"
    kind "entity"
    name "TEN DAYS"
    community 11
  ]
  node [
    id 1889
    label "E:SPEAKING OF SPENDING"
    kind "entity"
    name "SPEAKING OF SPENDING"
    community 11
  ]
  node [
    id 1890
    label "C:Novel-25646_00085"
    kind "chunk"
    chunk_id "Novel-25646_00085"
  ]
  node [
    id 1891
    label "U:Novel-25646_00085#0"
    kind "unit"
    chunk_id "Novel-25646_00085"
    text "The word 'used' should not be used because it implies useful spending; instead, the dollar will be wasted in ten days. Spending it on wine or whiskey causes it to go sooner because these items cost more. If no money were spent on liquor in the country, fewer people would be sick, poor, bad, or wretched, and there would be fewer policemen, jails, and prisons needed. Without liquor consumption, men, women, and children would be better and happier. The analogy of rolling a dollar bill and burning it is presented as a form of waste, and if the burning hurts the person holding it, it would be worse than waste. Buying cigars or tobacco with a dollar and smoking them would quickly burn up the dollar and also harm the person using it."
    community 11
  ]
  node [
    id 1892
    label "E:LIQUOR"
    kind "entity"
    name "LIQUOR"
    community 11
  ]
  node [
    id 1893
    label "E:SICK"
    kind "entity"
    name "SICK"
    community 11
  ]
  node [
    id 1894
    label "E:POOR"
    kind "entity"
    name "POOR"
    community 11
  ]
  node [
    id 1895
    label "E:BAD"
    kind "entity"
    name "BAD"
    community 11
  ]
  node [
    id 1896
    label "E:WRETCHED"
    kind "entity"
    name "WRETCHED"
    community 11
  ]
  node [
    id 1897
    label "E:POLICE"
    kind "entity"
    name "POLICE"
    community 11
  ]
  node [
    id 1898
    label "E:JAILS"
    kind "entity"
    name "JAILS"
    community 11
  ]
  node [
    id 1899
    label "E:PRISONS"
    kind "entity"
    name "PRISONS"
    community 11
  ]
  node [
    id 1900
    label "E:MATCH"
    kind "entity"
    name "MATCH"
    community 11
  ]
  node [
    id 1901
    label "E:BURNING"
    kind "entity"
    name "BURNING"
    community 11
  ]
  node [
    id 1902
    label "E:PLANNING"
    kind "entity"
    name "PLANNING"
    community 11
  ]
  node [
    id 1903
    label "E:MILLION"
    kind "entity"
    name "MILLION"
    community 11
  ]
  node [
    id 1904
    label "E:10 DAYS"
    kind "entity"
    name "10 DAYS"
    community 11
  ]
  node [
    id 1905
    label "E:BETTER AND HAPPIER MEN, WOMEN, AND CHILDREN"
    kind "entity"
    name "BETTER AND HAPPIER MEN, WOMEN, AND CHILDREN"
    community 11
  ]
  node [
    id 1906
    label "E:BURNED WITH A MATCH"
    kind "entity"
    name "BURNED WITH A MATCH"
    community 11
  ]
  node [
    id 1907
    label "U:Novel-25646_00085#1"
    kind "unit"
    chunk_id "Novel-25646_00085"
    text "The passage suggests that spending money on tobacco or cigars is wasteful and harmful, as it burns up the dollar and causes personal harm. The act of counting a million is posed as a question, implying a challenge to numerical understanding or financial awareness."
    community 11
  ]
  node [
    id 1908
    label "E:COST OF TOBACCO"
    kind "entity"
    name "COST OF TOBACCO"
    community 11
  ]
  node [
    id 1909
    label "E:BURNING A DOLLAR BILL"
    kind "entity"
    name "BURNING A DOLLAR BILL"
    community 11
  ]
  node [
    id 1910
    label "E:COUNTING"
    kind "entity"
    name "COUNTING"
    community 11
  ]
  node [
    id 1911
    label "C:Novel-25646_00086"
    kind "chunk"
    chunk_id "Novel-25646_00086"
  ]
  node [
    id 1912
    label "U:Novel-25646_00086#0"
    kind "unit"
    chunk_id "Novel-25646_00086"
    text "One may attempt to count a million or a hundred million, and when one has a sense of what six hundred million is, it should be remembered that six hundred million dollars are spent each year in this country on tobacco, which is described as burned up, wasted, and worse than wasted."
    community 11
  ]
  node [
    id 1913
    label "E:HUNDRED MILLIONS"
    kind "entity"
    name "HUNDRED MILLIONS"
    community 11
  ]
  node [
    id 1914
    label "E:SIX HUNDRED MILLIONS"
    kind "entity"
    name "SIX HUNDRED MILLIONS"
    community 11
  ]
  node [
    id 1915
    label "E:SIX HUNDRED MILLION DOLLARS"
    kind "entity"
    name "SIX HUNDRED MILLION DOLLARS"
    community 11
  ]
  node [
    id 1916
    label "E:THIS COUNTRY"
    kind "entity"
    name "THIS COUNTRY"
    community 11
  ]
  node [
    id 1917
    label "E:BURNED UP"
    kind "entity"
    name "BURNED UP"
    community 11
  ]
  node [
    id 1918
    label "E:WASTED"
    kind "entity"
    name "WASTED"
    community 11
  ]
  node [
    id 1919
    label "E:WORSE THAN WASTED"
    kind "entity"
    name "WORSE THAN WASTED"
    community 11
  ]
  node [
    id 1920
    label "U:Novel-25646_00086#1"
    kind "unit"
    chunk_id "Novel-25646_00086"
    text "The farmer who planted tobacco instead of corn did not do any good to the world by this change."
    community 1
  ]
  node [
    id 1921
    label "E:WORLD"
    kind "entity"
    name "WORLD"
    community 1
  ]
  node [
    id 1922
    label "U:Novel-25646_00086#2"
    kind "unit"
    chunk_id "Novel-25646_00086"
    text "Review questions include: How may one waste money? Name some good ways for spending money? How does the liquor-drinker spend his money? What could we do if no money was spent for liquor? Tell two ways in which one could burn up a dollar bill. Which would be the safer way? How much money is spent for tobacco yearly in this country?"
    community 3
  ]
  node [
    id 1923
    label "E:WASTE MONEY"
    kind "entity"
    name "WASTE MONEY"
    community 3
  ]
  node [
    id 1924
    label "E:GOOD WAYS TO SPEND MONEY"
    kind "entity"
    name "GOOD WAYS TO SPEND MONEY"
    community 3
  ]
  node [
    id 1925
    label "E:LIQUOR-DRIKER"
    kind "entity"
    name "LIQUOR-DRIKER"
    community 3
  ]
  node [
    id 1926
    label "E:MONEY SPENT FOR LIQUOR"
    kind "entity"
    name "MONEY SPENT FOR LIQUOR"
    community 3
  ]
  node [
    id 1927
    label "E:BURN UP A DOLLAR BILL"
    kind "entity"
    name "BURN UP A DOLLAR BILL"
    community 3
  ]
  node [
    id 1928
    label "E:SAFER WAY"
    kind "entity"
    name "SAFER WAY"
    community 3
  ]
  node [
    id 1929
    label "E:MONEY SPENT FOR TOBACCO"
    kind "entity"
    name "MONEY SPENT FOR TOBACCO"
    community 3
  ]
  node [
    id 1930
    label "E:YEARLY"
    kind "entity"
    name "YEARLY"
    community 3
  ]
  node [
    id 1931
    label "E:HOW MAY ONE WASTE MONEY"
    kind "entity"
    name "HOW MAY ONE WASTE MONEY"
    community 3
  ]
  node [
    id 1932
    label "E:NAME SOME GOOD WAYS FOR SPENDING MONEY"
    kind "entity"
    name "NAME SOME GOOD WAYS FOR SPENDING MONEY"
    community 3
  ]
  node [
    id 1933
    label "E:HOW DOES THE LIQUOR-DRIKER SPEND HIS MONEY"
    kind "entity"
    name "HOW DOES THE LIQUOR-DRIKER SPEND HIS MONEY"
    community 3
  ]
  node [
    id 1934
    label "E:WHAT COULD WE DO IF NO MONEY WAS SPENT FOR LIQUOR"
    kind "entity"
    name "WHAT COULD WE DO IF NO MONEY WAS SPENT FOR LIQUOR"
    community 3
  ]
  node [
    id 1935
    label "E:TELL TWO WAYS IN WHICH ONE COULD BURN UP A DOLLAR BILL"
    kind "entity"
    name "TELL TWO WAYS IN WHICH ONE COULD BURN UP A DOLLAR BILL"
    community 3
  ]
  node [
    id 1936
    label "E:WHICH WOULD BE THE SAFER WAY"
    kind "entity"
    name "WHICH WOULD BE THE SAFER WAY"
    community 3
  ]
  node [
    id 1937
    label "E:HOW MUCH MONEY IS SPENT FOR TOBACCO YEARLY IN THIS COUNTRY"
    kind "entity"
    name "HOW MUCH MONEY IS SPENT FOR TOBACCO YEARLY IN THIS COUNTRY"
    community 3
  ]
  node [
    id 1938
    label "H:0"
    kind "community"
    community 0
    parent 1
    n_units 28
    n_entities 117
    top_entities "LUNGS | BLOOD | HEART | BREATHING | AIR | CHEST | FRESH AIR | PERSON | HEADACHE | ROOM"
  ]
  node [
    id 1939
    label "H:1"
    kind "community"
    community 1
    parent 2
    n_units 24
    n_entities 96
    top_entities "BONES | DINNER | LIME | MEAT | SALT | GRAIN | MILK | FARMER | WHEAT | HUMAN BODY"
  ]
  node [
    id 1940
    label "H:2"
    kind "community"
    community 2
    parent 10
    n_units 22
    n_entities 69
    top_entities "WATER | APPLES | GRAPE-JUICE | RIPE FRUITS | GAS | VAPOR | BUBBLES | STEAM | LEAD | WHITE CANDY"
  ]
  node [
    id 1941
    label "H:3"
    kind "community"
    community 3
    parent 3
    n_units 21
    n_entities 77
    top_entities "STARCH | SALIVA | REVIEW QUESTIONS | SUN | BARLEY | FRUIT | CHEWING | BREWERS | THROAT | UNRIPE FRUITS"
  ]
  node [
    id 1942
    label "H:4"
    kind "community"
    community 4
    parent 11
    n_units 16
    n_entities 62
    top_entities "NERVES | PAIN | PLEASURE | TASTE | FIVE SENSES | ORGANS | TOUCH | LIVER | HEARING | CHEMICALS"
  ]
  node [
    id 1943
    label "H:5"
    kind "community"
    community 5
    parent 0
    n_units 16
    n_entities 52
    top_entities "WINE | BEER | WHISKEY | DRUNKARD | MIND | BOY WHO DRINKS WINE | BOY WHO NEVER DRINKS | BRANDY | MISRECOGNITION | DRUNKARDS"
  ]
  node [
    id 1944
    label "H:6"
    kind "community"
    community 6
    parent 8
    n_units 15
    n_entities 66
    top_entities "SICKNESS | WALKING | HINGE-JOINTS | FINGERS | TOBACCO USER | JOINTED DOLLS | BOY WHO TAKES OFF HIS HAT | ARMS | SMOKE | STREET"
  ]
  node [
    id 1945
    label "H:7"
    kind "community"
    community 7
    parent 16
    n_units 14
    n_entities 47
    top_entities "FAT | STRENGTH | HEALTH | OIL | BUTTER | GROWTH | FAT MEAT | JOINTS | CREAM | TIGHT SHOES"
  ]
  node [
    id 1946
    label "H:8"
    kind "community"
    community 8
    parent 17
    n_units 13
    n_entities 66
    top_entities "BONE | GRISTLE | NERVE | SPEAKER'S FATHER | FINGER | TRUE EARS | NERVES OF HEARING | PIN | CHILDREN'S BONES | DRINKING LIQUOR"
  ]
  node [
    id 1947
    label "H:9"
    kind "community"
    community 9
    parent 19
    n_units 12
    n_entities 91
    top_entities "WORK | BODY PARTS | HYGIENIC PHYSIOLOGY | TEACHER | EFFECTS OF ALCOHOLICS AND OTHER NARCOTICS | POPULAR POISONS | LIFE | BOYS | DAY AFTER DAY | ANYONE"
  ]
  node [
    id 1948
    label "H:10"
    kind "community"
    community 10
    parent 5
    n_units 12
    n_entities 68
    top_entities "HEAT | DOCTORS | ARCTIC EXPLORERS | DRINKER | GREELY PARTY | COLD AIR | CLOTHING | FOOD-BAGS | COLD WEATHER | SLEDGES"
  ]
  node [
    id 1949
    label "H:11"
    kind "community"
    community 11
    parent 14
    n_units 12
    n_entities 88
    top_entities "DOLLAR | LIQUOR | CIGARS | MONEY | DINNER BILL OF FARE | HARM | SNUFF MILL | ALCOHOLIC DRINKS | HEAVY WEIGHT | MILLION"
  ]
  node [
    id 1950
    label "H:12"
    kind "community"
    community 12
    parent 6
    n_units 11
    n_entities 67
    top_entities "CHILDREN | WASTE MATTER | INFLAMMATION | CANDY | PERSPIRATION TUBES | OLD PEOPLE | MAMMA | TINY NERVES | INTERNAL WASTE MATTER | WASHING"
  ]
  node [
    id 1951
    label "H:13"
    kind "community"
    community 13
    parent 13
    n_units 11
    n_entities 65
    top_entities "SKIN | PERSPIRATION | BED-CLOTHES | POOR MATERIALS ARE USED | NIGHT | TO GROW | CLOTHES | AIRING | TRUE SKIN | NIGHT-DRESS"
  ]
  node [
    id 1952
    label "H:14"
    kind "community"
    community 14
    parent 7
    n_units 11
    n_entities 67
    top_entities "STOMACH | TEETH | ENAMEL | GASTRIC JUICE | ABDOMEN | FRONT TEETH | BACK TEETH | TOOTH-PICK | CLEANLINESS | BREAKFAST"
  ]
  node [
    id 1953
    label "H:15"
    kind "community"
    community 15
    parent 0
    n_units 10
    n_entities 43
    top_entities "PEOPLE | JUICE | GRAPES | WARM PLACE | GOOD FAT | SEEDS | HEALTHY FATS | FEET | APPETITE | WINE-JELLY"
  ]
  node [
    id 1954
    label "H:16"
    kind "community"
    community 16
    parent 4
    n_units 10
    n_entities 75
    top_entities "MOUTH | OPIUM | COLD | EXERCISE | WARMTH | PERSON WITH A STRONG BODY | BLOOD FLOW | SOOTHING SYRUPS | CHILD | INFECTIONS"
  ]
  node [
    id 1955
    label "H:17"
    kind "community"
    community 17
    parent 12
    n_units 10
    n_entities 55
    top_entities "EYES | NERVE OF SIGHT | EYE | DARK | BRIGHT LIGHT | PUPL | READING | PLAYMATES | BODY PART | ONE"
  ]
  node [
    id 1956
    label "H:18"
    kind "community"
    community 18
    parent 9
    n_units 9
    n_entities 80
    top_entities "SPINE | ESQUIMAUX | GROWING CHILDREN | COLLAR-BONES | FISH | SHOULDER-BLADES | LEANING OVER | CROOKED GROWTH | LADY | LAME"
  ]
  node [
    id 1957
    label "H:19"
    kind "community"
    community 19
    parent 0
    n_units 7
    n_entities 30
    top_entities "CIDER | VINEGAR | HARMFUL SUBSTANCES | GRAPES JUICE | APPLE-JUICE | APPLE JUICE | MEN | TEN CUPS | REAL STRENGTH | BALANCED DIET"
  ]
  node [
    id 1958
    label "H:20"
    kind "community"
    community 20
    parent 21
    n_units 6
    n_entities 43
    top_entities "MUSCLE | ARM | HINGES | BALL AND SOCKET JOINT | DOOR | RUBBER STRAP | JOINT | MUSCLE ON OUTSIDE OF ARM | LEG | BODY JOINTS"
  ]
  node [
    id 1959
    label "H:21"
    kind "community"
    community 21
    parent 18
    n_units 6
    n_entities 39
    top_entities "BOY | SMOKING | CHEWING TOBACCO | YOUTH | CIGARETTES | FREQUENT SPITTING | BOY WHO DOES NOT USE TOBACCO | BOY WHO USES TOBACCO | FINE-LOOKING MEN | THAN OTHERWISE"
  ]
  node [
    id 1960
    label "H:22"
    kind "community"
    community 22
    parent 20
    n_units 6
    n_entities 38
    top_entities "DOCTOR | FREQUENT DRINKING | LITTLE LIQUOR | ANSWERS | PEOPLE WHO ARE NOT DRUNKARDS | MAN'S ANSWERS | SOLDIER | WOUND | SMALL OPENING | BONE FOOD"
  ]
  node [
    id 1961
    label "H:23"
    kind "community"
    community 23
    parent 0
    n_units 5
    n_entities 36
    top_entities "RUM | POISON | CAPTAIN OF A SHIP | SAILORS | GIN | MORE ALCOHOL | PURE ALCOHOL | ALCOHOL INTAKE | BOYS WHO TRY TO LEARN TO SMOKING | STORM"
  ]
  edge [
    source 1
    target 2
    kind "from_chunk"
  ]
  edge [
    source 1
    target 12
    kind "from_chunk"
  ]
  edge [
    source 2
    target 3
    kind "mentions"
  ]
  edge [
    source 2
    target 4
    kind "mentions"
  ]
  edge [
    source 2
    target 5
    kind "mentions"
  ]
  edge [
    source 2
    target 6
    kind "mentions"
  ]
  edge [
    source 2
    target 7
    kind "mentions"
  ]
  edge [
    source 2
    target 8
    kind "mentions"
  ]
  edge [
    source 2
    target 9
    kind "mentions"
  ]
  edge [
    source 2
    target 10
    kind "mentions"
  ]
  edge [
    source 2
    target 11
    kind "mentions"
  ]
  edge [
    source 2
    target 1947
    kind "summarizes"
  ]
  edge [
    source 3
    target 11
    kind "relation"
    relation "is a more elaborate treatise than"
    weight 1
  ]
  edge [
    source 3
    target 4
    kind "relation"
    relation "is prepared for instruction in"
    weight 1
  ]
  edge [
    source 3
    target 6
    kind "relation"
    relation "teaches"
    weight 1
  ]
  edge [
    source 3
    target 7
    kind "relation"
    relation "teaches"
    weight 1
  ]
  edge [
    source 3
    target 8
    kind "relation"
    relation "is presented in"
    weight 1
  ]
  edge [
    source 3
    target 9
    kind "relation"
    relation "has a format of"
    weight 1
  ]
  edge [
    source 12
    target 13
    kind "mentions"
  ]
  edge [
    source 12
    target 14
    kind "mentions"
  ]
  edge [
    source 12
    target 15
    kind "mentions"
  ]
  edge [
    source 12
    target 16
    kind "mentions"
  ]
  edge [
    source 12
    target 17
    kind "mentions"
  ]
  edge [
    source 12
    target 18
    kind "mentions"
  ]
  edge [
    source 12
    target 19
    kind "mentions"
  ]
  edge [
    source 12
    target 20
    kind "mentions"
  ]
  edge [
    source 12
    target 21
    kind "mentions"
  ]
  edge [
    source 12
    target 22
    kind "mentions"
  ]
  edge [
    source 12
    target 23
    kind "mentions"
  ]
  edge [
    source 12
    target 24
    kind "mentions"
  ]
  edge [
    source 12
    target 25
    kind "mentions"
  ]
  edge [
    source 12
    target 26
    kind "mentions"
  ]
  edge [
    source 12
    target 27
    kind "mentions"
  ]
  edge [
    source 12
    target 1947
    kind "summarizes"
  ]
  edge [
    source 13
    target 23
    kind "relation"
    relation "passed a legislative act to"
    weight 1
  ]
  edge [
    source 13
    target 24
    kind "relation"
    relation "is now the fourteenth state that"
    weight 1
  ]
  edge [
    source 17
    target 25
    kind "relation"
    relation "are required to teach"
    weight 1
  ]
  edge [
    source 21
    target 29
    kind "mentions"
  ]
  edge [
    source 22
    target 29
    kind "mentions"
  ]
  edge [
    source 25
    target 26
    kind "relation"
    relation "are taught in connection with"
    weight 1
  ]
  edge [
    source 25
    target 27
    kind "relation"
    relation "are taught to"
    weight 1
  ]
  edge [
    source 28
    target 29
    kind "from_chunk"
  ]
  edge [
    source 29
    target 30
    kind "mentions"
  ]
  edge [
    source 29
    target 31
    kind "mentions"
  ]
  edge [
    source 29
    target 32
    kind "mentions"
  ]
  edge [
    source 29
    target 33
    kind "mentions"
  ]
  edge [
    source 29
    target 34
    kind "mentions"
  ]
  edge [
    source 29
    target 35
    kind "mentions"
  ]
  edge [
    source 29
    target 36
    kind "mentions"
  ]
  edge [
    source 29
    target 37
    kind "mentions"
  ]
  edge [
    source 29
    target 38
    kind "mentions"
  ]
  edge [
    source 29
    target 39
    kind "mentions"
  ]
  edge [
    source 29
    target 40
    kind "mentions"
  ]
  edge [
    source 29
    target 41
    kind "mentions"
  ]
  edge [
    source 29
    target 42
    kind "mentions"
  ]
  edge [
    source 29
    target 43
    kind "mentions"
  ]
  edge [
    source 29
    target 44
    kind "mentions"
  ]
  edge [
    source 29
    target 45
    kind "mentions"
  ]
  edge [
    source 29
    target 46
    kind "mentions"
  ]
  edge [
    source 29
    target 47
    kind "mentions"
  ]
  edge [
    source 29
    target 48
    kind "mentions"
  ]
  edge [
    source 29
    target 49
    kind "mentions"
  ]
  edge [
    source 29
    target 50
    kind "mentions"
  ]
  edge [
    source 29
    target 51
    kind "mentions"
  ]
  edge [
    source 29
    target 52
    kind "mentions"
  ]
  edge [
    source 29
    target 53
    kind "mentions"
  ]
  edge [
    source 29
    target 54
    kind "mentions"
  ]
  edge [
    source 29
    target 55
    kind "mentions"
  ]
  edge [
    source 29
    target 56
    kind "mentions"
  ]
  edge [
    source 29
    target 57
    kind "mentions"
  ]
  edge [
    source 29
    target 58
    kind "mentions"
  ]
  edge [
    source 29
    target 59
    kind "mentions"
  ]
  edge [
    source 29
    target 60
    kind "mentions"
  ]
  edge [
    source 29
    target 61
    kind "mentions"
  ]
  edge [
    source 29
    target 1947
    kind "summarizes"
  ]
  edge [
    source 30
    target 53
    kind "relation"
    relation "should have"
    weight 1
  ]
  edge [
    source 34
    target 36
    kind "relation"
    relation "affects"
    weight 1
  ]
  edge [
    source 34
    target 37
    kind "relation"
    relation "affects"
    weight 1
  ]
  edge [
    source 34
    target 38
    kind "relation"
    relation "affects"
    weight 1
  ]
  edge [
    source 34
    target 372
    kind "mentions"
  ]
  edge [
    source 34
    target 375
    kind "relation"
    relation "changes part of muscles into | changes muscle tissue to"
    weight 2
  ]
  edge [
    source 34
    target 378
    kind "mentions"
  ]
  edge [
    source 34
    target 379
    kind "relation"
    relation "contains | is a poison"
    weight 4
  ]
  edge [
    source 34
    target 383
    kind "mentions"
  ]
  edge [
    source 34
    target 294
    kind "relation"
    relation "become weak due to | causes fat to be deposited in | cannot make | harms"
    weight 4
  ]
  edge [
    source 34
    target 467
    kind "mentions"
  ]
  edge [
    source 34
    target 392
    kind "relation"
    relation "is questioned as to whether it is good for | harms | puts nerves to sleep | damages | suppresses | deadens | affects | confuses | deadens nerves"
    weight 11
  ]
  edge [
    source 34
    target 397
    kind "relation"
    relation "is questioned as to whether it is good for | hurts | harms | impairs | cannot make | weakens | goes to"
    weight 9
  ]
  edge [
    source 34
    target 469
    kind "mentions"
  ]
  edge [
    source 34
    target 472
    kind "relation"
    relation "impairs | hurts"
    weight 2
  ]
  edge [
    source 34
    target 473
    kind "mentions"
  ]
  edge [
    source 34
    target 480
    kind "relation"
    relation "causes"
    weight 1
  ]
  edge [
    source 34
    target 481
    kind "relation"
    relation "leads to"
    weight 1
  ]
  edge [
    source 34
    target 482
    kind "relation"
    relation "results in"
    weight 1
  ]
  edge [
    source 34
    target 487
    kind "mentions"
  ]
  edge [
    source 34
    target 488
    kind "relation"
    relation "causes"
    weight 3
  ]
  edge [
    source 34
    target 490
    kind "mentions"
  ]
  edge [
    source 34
    target 249
    kind "relation"
    relation "slowly poisons | harms | poisons | makes you feel warmer | cheats into thinking it warms"
    weight 5
  ]
  edge [
    source 34
    target 500
    kind "relation"
    relation "are slowly poisoned by"
    weight 1
  ]
  edge [
    source 34
    target 514
    kind "mentions"
  ]
  edge [
    source 34
    target 50
    kind "relation"
    relation "has effect similar to"
    weight 1
  ]
  edge [
    source 34
    target 543
    kind "mentions"
  ]
  edge [
    source 34
    target 546
    kind "mentions"
  ]
  edge [
    source 34
    target 550
    kind "relation"
    relation "impairs"
    weight 1
  ]
  edge [
    source 34
    target 551
    kind "relation"
    relation "reduces"
    weight 1
  ]
  edge [
    source 34
    target 552
    kind "relation"
    relation "disrupts"
    weight 1
  ]
  edge [
    source 34
    target 553
    kind "mentions"
  ]
  edge [
    source 34
    target 554
    kind "relation"
    relation "does not know what he is about because"
    weight 1
  ]
  edge [
    source 34
    target 558
    kind "mentions"
  ]
  edge [
    source 34
    target 559
    kind "relation"
    relation "are caused by"
    weight 1
  ]
  edge [
    source 34
    target 560
    kind "relation"
    relation "impairs"
    weight 2
  ]
  edge [
    source 34
    target 561
    kind "relation"
    relation "impairs"
    weight 1
  ]
  edge [
    source 34
    target 562
    kind "mentions"
  ]
  edge [
    source 34
    target 564
    kind "relation"
    relation "impairs"
    weight 1
  ]
  edge [
    source 34
    target 636
    kind "mentions"
  ]
  edge [
    source 34
    target 602
    kind "relation"
    relation "changes into | is converted into | is changed into"
    weight 3
  ]
  edge [
    source 34
    target 601
    kind "relation"
    relation "remains as a thin liquid mixed with | requires less heat to vaporize than | mixes easily with | looks like"
    weight 4
  ]
  edge [
    source 34
    target 638
    kind "mentions"
  ]
  edge [
    source 34
    target 639
    kind "relation"
    relation "is a"
    weight 1
  ]
  edge [
    source 34
    target 643
    kind "mentions"
  ]
  edge [
    source 34
    target 607
    kind "relation"
    relation "is poisoned by"
    weight 1
  ]
  edge [
    source 34
    target 647
    kind "mentions"
  ]
  edge [
    source 34
    target 648
    kind "relation"
    relation "is partly | causes desire for more | is present in | is found in | contains"
    weight 5
  ]
  edge [
    source 34
    target 652
    kind "mentions"
  ]
  edge [
    source 34
    target 656
    kind "relation"
    relation "is formed in"
    weight 1
  ]
  edge [
    source 34
    target 659
    kind "mentions"
  ]
  edge [
    source 34
    target 276
    kind "relation"
    relation "harms | poisons | does not strengthen | should not reach"
    weight 4
  ]
  edge [
    source 34
    target 660
    kind "relation"
    relation "changes | makes"
    weight 2
  ]
  edge [
    source 34
    target 663
    kind "relation"
    relation "makes worse"
    weight 1
  ]
  edge [
    source 34
    target 665
    kind "mentions"
  ]
  edge [
    source 34
    target 600
    kind "relation"
    relation "changes into"
    weight 1
  ]
  edge [
    source 34
    target 678
    kind "mentions"
  ]
  edge [
    source 34
    target 681
    kind "mentions"
  ]
  edge [
    source 34
    target 671
    kind "relation"
    relation "contains"
    weight 1
  ]
  edge [
    source 34
    target 684
    kind "mentions"
  ]
  edge [
    source 34
    target 682
    kind "relation"
    relation "is found in"
    weight 1
  ]
  edge [
    source 34
    target 685
    kind "relation"
    relation "causes"
    weight 1
  ]
  edge [
    source 34
    target 688
    kind "mentions"
  ]
  edge [
    source 34
    target 689
    kind "mentions"
  ]
  edge [
    source 34
    target 690
    kind "mentions"
  ]
  edge [
    source 34
    target 695
    kind "mentions"
  ]
  edge [
    source 34
    target 696
    kind "relation"
    relation "is made from"
    weight 1
  ]
  edge [
    source 34
    target 704
    kind "relation"
    relation "is made from"
    weight 1
  ]
  edge [
    source 34
    target 720
    kind "mentions"
  ]
  edge [
    source 34
    target 723
    kind "relation"
    relation "produces"
    weight 1
  ]
  edge [
    source 34
    target 730
    kind "mentions"
  ]
  edge [
    source 34
    target 734
    kind "mentions"
  ]
  edge [
    source 34
    target 751
    kind "mentions"
  ]
  edge [
    source 34
    target 750
    kind "relation"
    relation "is used when talking about | boils into"
    weight 2
  ]
  edge [
    source 34
    target 753
    kind "mentions"
  ]
  edge [
    source 34
    target 755
    kind "relation"
    relation "contains nearly half alcohol | is nearly one half"
    weight 2
  ]
  edge [
    source 34
    target 776
    kind "mentions"
  ]
  edge [
    source 34
    target 777
    kind "relation"
    relation "increases danger with more consumption | are made through"
    weight 2
  ]
  edge [
    source 34
    target 778
    kind "mentions"
  ]
  edge [
    source 34
    target 779
    kind "relation"
    relation "burns with a blue flame"
    weight 1
  ]
  edge [
    source 34
    target 527
    kind "relation"
    relation "produces heat"
    weight 1
  ]
  edge [
    source 34
    target 780
    kind "relation"
    relation "does not produce"
    weight 1
  ]
  edge [
    source 34
    target 781
    kind "relation"
    relation "does not produce"
    weight 1
  ]
  edge [
    source 34
    target 782
    kind "mentions"
  ]
  edge [
    source 34
    target 783
    kind "relation"
    relation "was placed in | preserves | prevents decay of"
    weight 3
  ]
  edge [
    source 34
    target 787
    kind "mentions"
  ]
  edge [
    source 34
    target 788
    kind "mentions"
  ]
  edge [
    source 34
    target 666
    kind "relation"
    relation "contains"
    weight 1
  ]
  edge [
    source 34
    target 789
    kind "mentions"
  ]
  edge [
    source 34
    target 756
    kind "relation"
    relation "is nearly one half"
    weight 1
  ]
  edge [
    source 34
    target 757
    kind "relation"
    relation "is nearly one half"
    weight 1
  ]
  edge [
    source 34
    target 758
    kind "relation"
    relation "is nearly one half"
    weight 1
  ]
  edge [
    source 34
    target 791
    kind "mentions"
  ]
  edge [
    source 34
    target 794
    kind "mentions"
  ]
  edge [
    source 34
    target 795
    kind "relation"
    relation "leads to liking of"
    weight 1
  ]
  edge [
    source 34
    target 796
    kind "relation"
    relation "leads to liking of"
    weight 1
  ]
  edge [
    source 34
    target 797
    kind "relation"
    relation "leads to consumption of"
    weight 1
  ]
  edge [
    source 34
    target 800
    kind "mentions"
  ]
  edge [
    source 34
    target 805
    kind "mentions"
  ]
  edge [
    source 34
    target 810
    kind "relation"
    relation "is not described in terms of appearance"
    weight 1
  ]
  edge [
    source 34
    target 806
    kind "relation"
    relation "does not affect"
    weight 1
  ]
  edge [
    source 34
    target 346
    kind "relation"
    relation "is said to cheat people"
    weight 1
  ]
  edge [
    source 34
    target 866
    kind "mentions"
  ]
  edge [
    source 34
    target 873
    kind "relation"
    relation "is a narcotic that"
    weight 1
  ]
  edge [
    source 34
    target 998
    kind "mentions"
  ]
  edge [
    source 34
    target 891
    kind "relation"
    relation "affects | is carried away quickly | damages | is not a help to"
    weight 4
  ]
  edge [
    source 34
    target 1001
    kind "mentions"
  ]
  edge [
    source 34
    target 939
    kind "relation"
    relation "injures | reduces"
    weight 2
  ]
  edge [
    source 34
    target 1005
    kind "relation"
    relation "causes sores on"
    weight 1
  ]
  edge [
    source 34
    target 1003
    kind "relation"
    relation "if used daily, may lead to"
    weight 1
  ]
  edge [
    source 34
    target 1058
    kind "mentions"
  ]
  edge [
    source 34
    target 1144
    kind "mentions"
  ]
  edge [
    source 34
    target 1354
    kind "mentions"
  ]
  edge [
    source 34
    target 162
    kind "relation"
    relation "cannot make"
    weight 1
  ]
  edge [
    source 34
    target 406
    kind "relation"
    relation "cannot make"
    weight 1
  ]
  edge [
    source 34
    target 345
    kind "relation"
    relation "cannot give"
    weight 1
  ]
  edge [
    source 34
    target 1364
    kind "mentions"
  ]
  edge [
    source 34
    target 1112
    kind "relation"
    relation "has most of its food part turned into"
    weight 1
  ]
  edge [
    source 34
    target 1379
    kind "relation"
    relation "causes false feeling of strength"
    weight 1
  ]
  edge [
    source 34
    target 1382
    kind "mentions"
  ]
  edge [
    source 34
    target 1403
    kind "mentions"
  ]
  edge [
    source 34
    target 398
    kind "relation"
    relation "prevents"
    weight 1
  ]
  edge [
    source 34
    target 1419
    kind "relation"
    relation "has been poisoned by"
    weight 1
  ]
  edge [
    source 34
    target 1421
    kind "mentions"
  ]
  edge [
    source 34
    target 1423
    kind "relation"
    relation "does not increase"
    weight 1
  ]
  edge [
    source 34
    target 1388
    kind "relation"
    relation "does not help"
    weight 1
  ]
  edge [
    source 34
    target 1424
    kind "relation"
    relation "negatively affects"
    weight 1
  ]
  edge [
    source 34
    target 1446
    kind "mentions"
  ]
  edge [
    source 34
    target 1444
    kind "relation"
    relation "is poisoned by"
    weight 1
  ]
  edge [
    source 34
    target 1448
    kind "mentions"
  ]
  edge [
    source 34
    target 1457
    kind "mentions"
  ]
  edge [
    source 34
    target 311
    kind "relation"
    relation "harms"
    weight 1
  ]
  edge [
    source 34
    target 930
    kind "relation"
    relation "causes heart to beat too fast | gets too tired | is not mentioned as harming | is not a help to"
    weight 6
  ]
  edge [
    source 34
    target 1462
    kind "mentions"
  ]
  edge [
    source 34
    target 1477
    kind "mentions"
  ]
  edge [
    source 34
    target 1514
    kind "mentions"
  ]
  edge [
    source 34
    target 1526
    kind "relation"
    relation "harms"
    weight 1
  ]
  edge [
    source 34
    target 1527
    kind "mentions"
  ]
  edge [
    source 34
    target 191
    kind "relation"
    relation "is not a help to | damages lung tissue and impairs function"
    weight 2
  ]
  edge [
    source 34
    target 1529
    kind "mentions"
  ]
  edge [
    source 34
    target 1716
    kind "mentions"
  ]
  edge [
    source 34
    target 1721
    kind "relation"
    relation "causes hands to tremble"
    weight 1
  ]
  edge [
    source 34
    target 1722
    kind "relation"
    relation "makes speech thick"
    weight 1
  ]
  edge [
    source 34
    target 70
    kind "relation"
    relation "impairs walking"
    weight 1
  ]
  edge [
    source 34
    target 1723
    kind "relation"
    relation "leads to false visual perceptions"
    weight 1
  ]
  edge [
    source 34
    target 1819
    kind "mentions"
  ]
  edge [
    source 34
    target 1821
    kind "relation"
    relation "causes hot blood to rush into"
    weight 1
  ]
  edge [
    source 34
    target 1781
    kind "relation"
    relation "allows cold air to carry away more body heat"
    weight 1
  ]
  edge [
    source 34
    target 1826
    kind "relation"
    relation "are cheated into thinking alcohol keeps them warm"
    weight 1
  ]
  edge [
    source 34
    target 1827
    kind "relation"
    relation "are cheated into thinking alcohol keeps them warm"
    weight 1
  ]
  edge [
    source 34
    target 592
    kind "relation"
    relation "cannot really keep a person warm"
    weight 1
  ]
  edge [
    source 34
    target 1843
    kind "mentions"
  ]
  edge [
    source 34
    target 1844
    kind "relation"
    relation "does not keep"
    weight 1
  ]
  edge [
    source 34
    target 508
    kind "relation"
    relation "lessens resistance to"
    weight 1
  ]
  edge [
    source 34
    target 1867
    kind "mentions"
  ]
  edge [
    source 34
    target 1872
    kind "relation"
    relation "report about use of"
    weight 1
  ]
  edge [
    source 34
    target 1874
    kind "mentions"
  ]
  edge [
    source 34
    target 1405
    kind "relation"
    relation "costs a great deal of"
    weight 1
  ]
  edge [
    source 35
    target 36
    kind "relation"
    relation "affect"
    weight 1
  ]
  edge [
    source 35
    target 37
    kind "relation"
    relation "affect"
    weight 1
  ]
  edge [
    source 35
    target 38
    kind "relation"
    relation "affect"
    weight 1
  ]
  edge [
    source 36
    target 108
    kind "mentions"
  ]
  edge [
    source 36
    target 109
    kind "relation"
    relation "has"
    weight 1
  ]
  edge [
    source 36
    target 328
    kind "mentions"
  ]
  edge [
    source 36
    target 1100
    kind "mentions"
  ]
  edge [
    source 36
    target 601
    kind "relation"
    relation "does not drink all the water it needs"
    weight 1
  ]
  edge [
    source 36
    target 1101
    kind "relation"
    relation "contain water"
    weight 1
  ]
  edge [
    source 36
    target 1102
    kind "relation"
    relation "contain water"
    weight 1
  ]
  edge [
    source 36
    target 1103
    kind "relation"
    relation "contains water"
    weight 1
  ]
  edge [
    source 36
    target 944
    kind "relation"
    relation "contains water"
    weight 1
  ]
  edge [
    source 37
    target 1496
    kind "mentions"
  ]
  edge [
    source 43
    target 55
    kind "relation"
    relation "lacks"
    weight 1
  ]
  edge [
    source 43
    target 47
    kind "relation"
    relation "has limited"
    weight 1
  ]
  edge [
    source 43
    target 64
    kind "mentions"
  ]
  edge [
    source 43
    target 81
    kind "mentions"
  ]
  edge [
    source 43
    target 77
    kind "relation"
    relation "makes a polite bow to"
    weight 1
  ]
  edge [
    source 44
    target 518
    kind "mentions"
  ]
  edge [
    source 48
    target 56
    kind "relation"
    relation "is designed for"
    weight 1
  ]
  edge [
    source 48
    target 57
    kind "relation"
    relation "avoids"
    weight 1
  ]
  edge [
    source 48
    target 58
    kind "relation"
    relation "focuses on"
    weight 1
  ]
  edge [
    source 48
    target 59
    kind "relation"
    relation "covers"
    weight 1
  ]
  edge [
    source 48
    target 60
    kind "relation"
    relation "covers"
    weight 1
  ]
  edge [
    source 48
    target 61
    kind "relation"
    relation "covers"
    weight 1
  ]
  edge [
    source 48
    target 52
    kind "relation"
    relation "covers"
    weight 1
  ]
  edge [
    source 48
    target 341
    kind "mentions"
  ]
  edge [
    source 48
    target 361
    kind "mentions"
  ]
  edge [
    source 48
    target 424
    kind "mentions"
  ]
  edge [
    source 48
    target 294
    kind "relation"
    relation "are involved in"
    weight 1
  ]
  edge [
    source 48
    target 449
    kind "mentions"
  ]
  edge [
    source 48
    target 455
    kind "mentions"
  ]
  edge [
    source 48
    target 1283
    kind "mentions"
  ]
  edge [
    source 48
    target 1286
    kind "mentions"
  ]
  edge [
    source 48
    target 891
    kind "relation"
    relation "finds it hard to do more than its own part"
    weight 1
  ]
  edge [
    source 48
    target 1364
    kind "mentions"
  ]
  edge [
    source 48
    target 1403
    kind "mentions"
  ]
  edge [
    source 48
    target 1421
    kind "mentions"
  ]
  edge [
    source 48
    target 1653
    kind "mentions"
  ]
  edge [
    source 48
    target 1658
    kind "relation"
    relation "should not fall on"
    weight 1
  ]
  edge [
    source 50
    target 228
    kind "mentions"
  ]
  edge [
    source 50
    target 229
    kind "relation"
    relation "is worse for | are affected more by"
    weight 2
  ]
  edge [
    source 50
    target 258
    kind "mentions"
  ]
  edge [
    source 50
    target 273
    kind "mentions"
  ]
  edge [
    source 50
    target 274
    kind "relation"
    relation "is a great enemy to | always use"
    weight 2
  ]
  edge [
    source 50
    target 284
    kind "relation"
    relation "should be avoided in any form"
    weight 1
  ]
  edge [
    source 50
    target 291
    kind "mentions"
  ]
  edge [
    source 50
    target 109
    kind "relation"
    relation "affects"
    weight 1
  ]
  edge [
    source 50
    target 506
    kind "mentions"
  ]
  edge [
    source 50
    target 392
    kind "relation"
    relation "deadens"
    weight 1
  ]
  edge [
    source 50
    target 514
    kind "mentions"
  ]
  edge [
    source 50
    target 518
    kind "mentions"
  ]
  edge [
    source 50
    target 543
    kind "mentions"
  ]
  edge [
    source 50
    target 580
    kind "mentions"
  ]
  edge [
    source 50
    target 583
    kind "relation"
    relation "makes them feel"
    weight 1
  ]
  edge [
    source 50
    target 584
    kind "mentions"
  ]
  edge [
    source 50
    target 585
    kind "relation"
    relation "stimulates release of"
    weight 1
  ]
  edge [
    source 50
    target 588
    kind "mentions"
  ]
  edge [
    source 50
    target 592
    kind "relation"
    relation "does not really help | is smoked by"
    weight 2
  ]
  edge [
    source 50
    target 589
    kind "relation"
    relation "leads to"
    weight 1
  ]
  edge [
    source 50
    target 590
    kind "relation"
    relation "leads to"
    weight 1
  ]
  edge [
    source 50
    target 593
    kind "mentions"
  ]
  edge [
    source 50
    target 595
    kind "relation"
    relation "affects"
    weight 1
  ]
  edge [
    source 50
    target 596
    kind "relation"
    relation "affects"
    weight 1
  ]
  edge [
    source 50
    target 597
    kind "relation"
    relation "does not help"
    weight 1
  ]
  edge [
    source 50
    target 812
    kind "mentions"
  ]
  edge [
    source 50
    target 813
    kind "relation"
    relation "decided to plant | planted"
    weight 2
  ]
  edge [
    source 50
    target 823
    kind "relation"
    relation "contains | is the poison in"
    weight 2
  ]
  edge [
    source 50
    target 834
    kind "mentions"
  ]
  edge [
    source 50
    target 846
    kind "mentions"
  ]
  edge [
    source 50
    target 859
    kind "mentions"
  ]
  edge [
    source 50
    target 862
    kind "mentions"
  ]
  edge [
    source 50
    target 863
    kind "relation"
    relation "are processed"
    weight 1
  ]
  edge [
    source 50
    target 866
    kind "mentions"
  ]
  edge [
    source 50
    target 873
    kind "relation"
    relation "is a narcotic that"
    weight 1
  ]
  edge [
    source 50
    target 1006
    kind "mentions"
  ]
  edge [
    source 50
    target 431
    kind "relation"
    relation "makes mouth very dry | causes more saliva to flow | causes bad sores in"
    weight 3
  ]
  edge [
    source 50
    target 894
    kind "relation"
    relation "discolors"
    weight 2
  ]
  edge [
    source 50
    target 1009
    kind "relation"
    relation "often causes"
    weight 2
  ]
  edge [
    source 50
    target 1013
    kind "mentions"
  ]
  edge [
    source 50
    target 1014
    kind "relation"
    relation "causes"
    weight 1
  ]
  edge [
    source 50
    target 1065
    kind "mentions"
  ]
  edge [
    source 50
    target 1066
    kind "relation"
    relation "causes"
    weight 1
  ]
  edge [
    source 50
    target 901
    kind "relation"
    relation "weakens"
    weight 1
  ]
  edge [
    source 50
    target 1064
    kind "relation"
    relation "increases risk of"
    weight 1
  ]
  edge [
    source 50
    target 1067
    kind "relation"
    relation "causes"
    weight 1
  ]
  edge [
    source 50
    target 1403
    kind "mentions"
  ]
  edge [
    source 50
    target 398
    kind "relation"
    relation "prevents"
    weight 1
  ]
  edge [
    source 50
    target 1419
    kind "relation"
    relation "has been poisoned by"
    weight 1
  ]
  edge [
    source 50
    target 1446
    kind "mentions"
  ]
  edge [
    source 50
    target 1444
    kind "relation"
    relation "is poisoned by"
    weight 1
  ]
  edge [
    source 50
    target 1857
    kind "mentions"
  ]
  edge [
    source 50
    target 1859
    kind "relation"
    relation "all but one used"
    weight 1
  ]
  edge [
    source 50
    target 1863
    kind "mentions"
  ]
  edge [
    source 50
    target 891
    kind "relation"
    relation "weakened"
    weight 1
  ]
  edge [
    source 50
    target 1867
    kind "mentions"
  ]
  edge [
    source 50
    target 1873
    kind "relation"
    relation "affected"
    weight 1
  ]
  edge [
    source 50
    target 1891
    kind "mentions"
  ]
  edge [
    source 50
    target 1876
    kind "relation"
    relation "is bought with | is smoked"
    weight 2
  ]
  edge [
    source 50
    target 1907
    kind "mentions"
  ]
  edge [
    source 50
    target 1405
    kind "relation"
    relation "is spent on"
    weight 1
  ]
  edge [
    source 50
    target 1912
    kind "mentions"
  ]
  edge [
    source 50
    target 1915
    kind "relation"
    relation "is burned up | is wasted | is worse than wasted"
    weight 3
  ]
  edge [
    source 50
    target 1920
    kind "mentions"
  ]
  edge [
    source 50
    target 759
    kind "relation"
    relation "was planted instead of"
    weight 1
  ]
  edge [
    source 51
    target 866
    kind "mentions"
  ]
  edge [
    source 51
    target 868
    kind "relation"
    relation "is a narcotic made from"
    weight 1
  ]
  edge [
    source 51
    target 869
    kind "relation"
    relation "is used in"
    weight 1
  ]
  edge [
    source 51
    target 870
    kind "relation"
    relation "contain"
    weight 1
  ]
  edge [
    source 51
    target 877
    kind "mentions"
  ]
  edge [
    source 51
    target 874
    kind "relation"
    relation "injures"
    weight 1
  ]
  edge [
    source 51
    target 879
    kind "relation"
    relation "poisons"
    weight 1
  ]
  edge [
    source 51
    target 880
    kind "relation"
    relation "is a disguise for"
    weight 1
  ]
  edge [
    source 51
    target 881
    kind "relation"
    relation "would not give"
    weight 1
  ]
  edge [
    source 51
    target 882
    kind "mentions"
  ]
  edge [
    source 51
    target 885
    kind "relation"
    relation "is a"
    weight 1
  ]
  edge [
    source 51
    target 1403
    kind "mentions"
  ]
  edge [
    source 51
    target 1419
    kind "relation"
    relation "has been poisoned by"
    weight 1
  ]
  edge [
    source 53
    target 54
    kind "relation"
    relation "aims to provide"
    weight 1
  ]
  edge [
    source 63
    target 64
    kind "from_chunk"
  ]
  edge [
    source 63
    target 81
    kind "from_chunk"
  ]
  edge [
    source 64
    target 65
    kind "mentions"
  ]
  edge [
    source 64
    target 66
    kind "mentions"
  ]
  edge [
    source 64
    target 67
    kind "mentions"
  ]
  edge [
    source 64
    target 68
    kind "mentions"
  ]
  edge [
    source 64
    target 69
    kind "mentions"
  ]
  edge [
    source 64
    target 70
    kind "mentions"
  ]
  edge [
    source 64
    target 71
    kind "mentions"
  ]
  edge [
    source 64
    target 72
    kind "mentions"
  ]
  edge [
    source 64
    target 73
    kind "mentions"
  ]
  edge [
    source 64
    target 74
    kind "mentions"
  ]
  edge [
    source 64
    target 75
    kind "mentions"
  ]
  edge [
    source 64
    target 76
    kind "mentions"
  ]
  edge [
    source 64
    target 77
    kind "mentions"
  ]
  edge [
    source 64
    target 78
    kind "mentions"
  ]
  edge [
    source 64
    target 79
    kind "mentions"
  ]
  edge [
    source 64
    target 80
    kind "mentions"
  ]
  edge [
    source 64
    target 1944
    kind "summarizes"
  ]
  edge [
    source 65
    target 66
    kind "relation"
    relation "like to play with"
    weight 1
  ]
  edge [
    source 66
    target 67
    kind "relation"
    relation "can be bent in"
    weight 1
  ]
  edge [
    source 66
    target 68
    kind "relation"
    relation "can be made to"
    weight 1
  ]
  edge [
    source 66
    target 69
    kind "relation"
    relation "can be made to"
    weight 1
  ]
  edge [
    source 66
    target 70
    kind "relation"
    relation "can be played as"
    weight 1
  ]
  edge [
    source 66
    target 71
    kind "relation"
    relation "have better joints than"
    weight 1
  ]
  edge [
    source 70
    target 335
    kind "mentions"
  ]
  edge [
    source 70
    target 336
    kind "relation"
    relation "have small legs and feet"
    weight 1
  ]
  edge [
    source 70
    target 354
    kind "mentions"
  ]
  edge [
    source 70
    target 1514
    kind "mentions"
  ]
  edge [
    source 70
    target 1716
    kind "mentions"
  ]
  edge [
    source 72
    target 80
    kind "relation"
    relation "work like"
    weight 1
  ]
  edge [
    source 72
    target 73
    kind "relation"
    relation "are found in"
    weight 1
  ]
  edge [
    source 72
    target 74
    kind "relation"
    relation "are found in"
    weight 1
  ]
  edge [
    source 72
    target 75
    kind "relation"
    relation "are found in"
    weight 1
  ]
  edge [
    source 72
    target 76
    kind "relation"
    relation "are found in"
    weight 1
  ]
  edge [
    source 72
    target 77
    kind "relation"
    relation "uses many hinges"
    weight 1
  ]
  edge [
    source 72
    target 81
    kind "mentions"
  ]
  edge [
    source 73
    target 383
    kind "mentions"
  ]
  edge [
    source 73
    target 388
    kind "relation"
    relation "help move"
    weight 1
  ]
  edge [
    source 75
    target 108
    kind "mentions"
  ]
  edge [
    source 75
    target 118
    kind "relation"
    relation "are in"
    weight 1
  ]
  edge [
    source 75
    target 328
    kind "mentions"
  ]
  edge [
    source 75
    target 294
    kind "relation"
    relation "have many muscles"
    weight 1
  ]
  edge [
    source 75
    target 1756
    kind "mentions"
  ]
  edge [
    source 75
    target 431
    kind "relation"
    relation "warms"
    weight 1
  ]
  edge [
    source 76
    target 108
    kind "mentions"
  ]
  edge [
    source 76
    target 118
    kind "relation"
    relation "are in"
    weight 1
  ]
  edge [
    source 77
    target 81
    kind "mentions"
  ]
  edge [
    source 77
    target 82
    kind "relation"
    relation "uses one hinge per"
    weight 1
  ]
  edge [
    source 77
    target 79
    kind "relation"
    relation "is seen on"
    weight 1
  ]
  edge [
    source 78
    target 81
    kind "mentions"
  ]
  edge [
    source 79
    target 81
    kind "mentions"
  ]
  edge [
    source 79
    target 1019
    kind "mentions"
  ]
  edge [
    source 79
    target 1024
    kind "relation"
    relation "leaves behind"
    weight 1
  ]
  edge [
    source 81
    target 82
    kind "mentions"
  ]
  edge [
    source 81
    target 1944
    kind "summarizes"
  ]
  edge [
    source 83
    target 84
    kind "from_chunk"
  ]
  edge [
    source 83
    target 92
    kind "from_chunk"
  ]
  edge [
    source 83
    target 101
    kind "from_chunk"
  ]
  edge [
    source 83
    target 108
    kind "from_chunk"
  ]
  edge [
    source 84
    target 85
    kind "mentions"
  ]
  edge [
    source 84
    target 86
    kind "mentions"
  ]
  edge [
    source 84
    target 87
    kind "mentions"
  ]
  edge [
    source 84
    target 88
    kind "mentions"
  ]
  edge [
    source 84
    target 89
    kind "mentions"
  ]
  edge [
    source 84
    target 90
    kind "mentions"
  ]
  edge [
    source 84
    target 91
    kind "mentions"
  ]
  edge [
    source 84
    target 1958
    kind "summarizes"
  ]
  edge [
    source 85
    target 86
    kind "relation"
    relation "are used in"
    weight 1
  ]
  edge [
    source 85
    target 87
    kind "relation"
    relation "are used in"
    weight 1
  ]
  edge [
    source 85
    target 88
    kind "relation"
    relation "are used in"
    weight 1
  ]
  edge [
    source 85
    target 89
    kind "relation"
    relation "are used in"
    weight 1
  ]
  edge [
    source 85
    target 90
    kind "relation"
    relation "are used in"
    weight 1
  ]
  edge [
    source 85
    target 91
    kind "relation"
    relation "are used in"
    weight 1
  ]
  edge [
    source 92
    target 93
    kind "mentions"
  ]
  edge [
    source 92
    target 94
    kind "mentions"
  ]
  edge [
    source 92
    target 95
    kind "mentions"
  ]
  edge [
    source 92
    target 96
    kind "mentions"
  ]
  edge [
    source 92
    target 97
    kind "mentions"
  ]
  edge [
    source 92
    target 98
    kind "mentions"
  ]
  edge [
    source 92
    target 99
    kind "mentions"
  ]
  edge [
    source 92
    target 100
    kind "mentions"
  ]
  edge [
    source 92
    target 1958
    kind "summarizes"
  ]
  edge [
    source 94
    target 100
    kind "relation"
    relation "has"
    weight 1
  ]
  edge [
    source 95
    target 100
    kind "relation"
    relation "allows"
    weight 1
  ]
  edge [
    source 95
    target 291
    kind "mentions"
  ]
  edge [
    source 95
    target 295
    kind "relation"
    relation "moves when held | requires holding to move"
    weight 2
  ]
  edge [
    source 95
    target 304
    kind "mentions"
  ]
  edge [
    source 95
    target 307
    kind "mentions"
  ]
  edge [
    source 95
    target 324
    kind "mentions"
  ]
  edge [
    source 95
    target 1307
    kind "mentions"
  ]
  edge [
    source 96
    target 100
    kind "relation"
    relation "has"
    weight 1
  ]
  edge [
    source 97
    target 100
    kind "relation"
    relation "allows"
    weight 1
  ]
  edge [
    source 97
    target 329
    kind "mentions"
  ]
  edge [
    source 97
    target 330
    kind "relation"
    relation "are visible in"
    weight 1
  ]
  edge [
    source 99
    target 101
    kind "mentions"
  ]
  edge [
    source 99
    target 102
    kind "relation"
    relation "moves in"
    weight 1
  ]
  edge [
    source 100
    target 101
    kind "mentions"
  ]
  edge [
    source 100
    target 102
    kind "relation"
    relation "consists of"
    weight 1
  ]
  edge [
    source 101
    target 102
    kind "mentions"
  ]
  edge [
    source 101
    target 103
    kind "mentions"
  ]
  edge [
    source 101
    target 104
    kind "mentions"
  ]
  edge [
    source 101
    target 105
    kind "mentions"
  ]
  edge [
    source 101
    target 106
    kind "mentions"
  ]
  edge [
    source 101
    target 107
    kind "mentions"
  ]
  edge [
    source 101
    target 1958
    kind "summarizes"
  ]
  edge [
    source 103
    target 105
    kind "relation"
    relation "keeps"
    weight 1
  ]
  edge [
    source 103
    target 104
    kind "relation"
    relation "is similar to"
    weight 1
  ]
  edge [
    source 105
    target 106
    kind "relation"
    relation "do not creak or fail"
    weight 1
  ]
  edge [
    source 105
    target 107
    kind "relation"
    relation "do not creak or fail"
    weight 1
  ]
  edge [
    source 108
    target 109
    kind "mentions"
  ]
  edge [
    source 108
    target 110
    kind "mentions"
  ]
  edge [
    source 108
    target 111
    kind "mentions"
  ]
  edge [
    source 108
    target 112
    kind "mentions"
  ]
  edge [
    source 108
    target 113
    kind "mentions"
  ]
  edge [
    source 108
    target 114
    kind "mentions"
  ]
  edge [
    source 108
    target 115
    kind "mentions"
  ]
  edge [
    source 108
    target 116
    kind "mentions"
  ]
  edge [
    source 108
    target 117
    kind "mentions"
  ]
  edge [
    source 108
    target 118
    kind "mentions"
  ]
  edge [
    source 108
    target 1944
    kind "summarizes"
  ]
  edge [
    source 109
    target 110
    kind "relation"
    relation "number is about"
    weight 1
  ]
  edge [
    source 109
    target 113
    kind "relation"
    relation "include"
    weight 1
  ]
  edge [
    source 109
    target 118
    kind "relation"
    relation "include"
    weight 1
  ]
  edge [
    source 109
    target 120
    kind "mentions"
  ]
  edge [
    source 109
    target 150
    kind "mentions"
  ]
  edge [
    source 109
    target 152
    kind "mentions"
  ]
  edge [
    source 109
    target 153
    kind "relation"
    relation "are made of"
    weight 1
  ]
  edge [
    source 109
    target 154
    kind "relation"
    relation "contain"
    weight 1
  ]
  edge [
    source 109
    target 183
    kind "mentions"
  ]
  edge [
    source 109
    target 193
    kind "relation"
    relation "have easily bent bones"
    weight 1
  ]
  edge [
    source 109
    target 210
    kind "mentions"
  ]
  edge [
    source 109
    target 211
    kind "relation"
    relation "contain more lime in old people | break more easily"
    weight 2
  ]
  edge [
    source 109
    target 258
    kind "mentions"
  ]
  edge [
    source 109
    target 291
    kind "mentions"
  ]
  edge [
    source 109
    target 138
    kind "relation"
    relation "are located in"
    weight 1
  ]
  edge [
    source 109
    target 139
    kind "relation"
    relation "are located in"
    weight 1
  ]
  edge [
    source 109
    target 297
    kind "relation"
    relation "are made of"
    weight 1
  ]
  edge [
    source 109
    target 159
    kind "relation"
    relation "bend easily"
    weight 1
  ]
  edge [
    source 109
    target 292
    kind "relation"
    relation "break easily"
    weight 1
  ]
  edge [
    source 109
    target 267
    kind "relation"
    relation "is a risk to"
    weight 1
  ]
  edge [
    source 109
    target 329
    kind "mentions"
  ]
  edge [
    source 109
    target 294
    kind "relation"
    relation "are fastened to | are attached to"
    weight 2
  ]
  edge [
    source 109
    target 383
    kind "mentions"
  ]
  edge [
    source 109
    target 978
    kind "mentions"
  ]
  edge [
    source 109
    target 470
    kind "relation"
    relation "is carried to"
    weight 1
  ]
  edge [
    source 109
    target 986
    kind "relation"
    relation "need feeding"
    weight 1
  ]
  edge [
    source 109
    target 988
    kind "mentions"
  ]
  edge [
    source 109
    target 184
    kind "relation"
    relation "need food to grow"
    weight 1
  ]
  edge [
    source 109
    target 1025
    kind "mentions"
  ]
  edge [
    source 109
    target 1043
    kind "relation"
    relation "form a case or box"
    weight 1
  ]
  edge [
    source 109
    target 1164
    kind "mentions"
  ]
  edge [
    source 109
    target 945
    kind "relation"
    relation "makes"
    weight 1
  ]
  edge [
    source 109
    target 1205
    kind "mentions"
  ]
  edge [
    source 109
    target 1206
    kind "relation"
    relation "need"
    weight 1
  ]
  edge [
    source 109
    target 1207
    kind "relation"
    relation "need"
    weight 1
  ]
  edge [
    source 109
    target 1208
    kind "mentions"
  ]
  edge [
    source 109
    target 1209
    kind "relation"
    relation "is needed for"
    weight 1
  ]
  edge [
    source 112
    target 183
    kind "mentions"
  ]
  edge [
    source 112
    target 117
    kind "relation"
    relation "is made of | has cushions between"
    weight 2
  ]
  edge [
    source 113
    target 114
    kind "relation"
    relation "are in"
    weight 1
  ]
  edge [
    source 113
    target 115
    kind "relation"
    relation "are in"
    weight 1
  ]
  edge [
    source 114
    target 354
    kind "mentions"
  ]
  edge [
    source 114
    target 383
    kind "mentions"
  ]
  edge [
    source 114
    target 389
    kind "relation"
    relation "need strong muscles in"
    weight 1
  ]
  edge [
    source 115
    target 348
    kind "mentions"
  ]
  edge [
    source 115
    target 349
    kind "relation"
    relation "has strong muscles in | are used by"
    weight 2
  ]
  edge [
    source 115
    target 354
    kind "mentions"
  ]
  edge [
    source 115
    target 355
    kind "relation"
    relation "had strong muscles in"
    weight 1
  ]
  edge [
    source 116
    target 117
    kind "relation"
    relation "is called"
    weight 2
  ]
  edge [
    source 116
    target 120
    kind "mentions"
  ]
  edge [
    source 117
    target 120
    kind "mentions"
  ]
  edge [
    source 117
    target 122
    kind "relation"
    relation "is made up of"
    weight 1
  ]
  edge [
    source 117
    target 183
    kind "mentions"
  ]
  edge [
    source 117
    target 184
    kind "relation"
    relation "bends easily"
    weight 1
  ]
  edge [
    source 117
    target 185
    kind "relation"
    relation "presses the elastic cushions on the inner edge"
    weight 1
  ]
  edge [
    source 117
    target 188
    kind "relation"
    relation "do not spring back into shape"
    weight 1
  ]
  edge [
    source 117
    target 400
    kind "mentions"
  ]
  edge [
    source 117
    target 401
    kind "relation"
    relation "is formed by"
    weight 1
  ]
  edge [
    source 117
    target 928
    kind "mentions"
  ]
  edge [
    source 117
    target 929
    kind "relation"
    relation "curve from"
    weight 1
  ]
  edge [
    source 117
    target 935
    kind "relation"
    relation "and ribs"
    weight 1
  ]
  edge [
    source 117
    target 1427
    kind "mentions"
  ]
  edge [
    source 119
    target 120
    kind "from_chunk"
  ]
  edge [
    source 119
    target 150
    kind "from_chunk"
  ]
  edge [
    source 120
    target 121
    kind "mentions"
  ]
  edge [
    source 120
    target 122
    kind "mentions"
  ]
  edge [
    source 120
    target 123
    kind "mentions"
  ]
  edge [
    source 120
    target 124
    kind "mentions"
  ]
  edge [
    source 120
    target 125
    kind "mentions"
  ]
  edge [
    source 120
    target 126
    kind "mentions"
  ]
  edge [
    source 120
    target 127
    kind "mentions"
  ]
  edge [
    source 120
    target 128
    kind "mentions"
  ]
  edge [
    source 120
    target 129
    kind "mentions"
  ]
  edge [
    source 120
    target 130
    kind "mentions"
  ]
  edge [
    source 120
    target 131
    kind "mentions"
  ]
  edge [
    source 120
    target 132
    kind "mentions"
  ]
  edge [
    source 120
    target 133
    kind "mentions"
  ]
  edge [
    source 120
    target 134
    kind "mentions"
  ]
  edge [
    source 120
    target 135
    kind "mentions"
  ]
  edge [
    source 120
    target 136
    kind "mentions"
  ]
  edge [
    source 120
    target 137
    kind "mentions"
  ]
  edge [
    source 120
    target 138
    kind "mentions"
  ]
  edge [
    source 120
    target 139
    kind "mentions"
  ]
  edge [
    source 120
    target 140
    kind "mentions"
  ]
  edge [
    source 120
    target 141
    kind "mentions"
  ]
  edge [
    source 120
    target 142
    kind "mentions"
  ]
  edge [
    source 120
    target 143
    kind "mentions"
  ]
  edge [
    source 120
    target 144
    kind "mentions"
  ]
  edge [
    source 120
    target 145
    kind "mentions"
  ]
  edge [
    source 120
    target 146
    kind "mentions"
  ]
  edge [
    source 120
    target 147
    kind "mentions"
  ]
  edge [
    source 120
    target 148
    kind "mentions"
  ]
  edge [
    source 120
    target 149
    kind "mentions"
  ]
  edge [
    source 120
    target 1956
    kind "summarizes"
  ]
  edge [
    source 121
    target 1233
    kind "mentions"
  ]
  edge [
    source 121
    target 1153
    kind "relation"
    relation "eat"
    weight 1
  ]
  edge [
    source 121
    target 1236
    kind "relation"
    relation "provide"
    weight 1
  ]
  edge [
    source 121
    target 1237
    kind "relation"
    relation "provide"
    weight 1
  ]
  edge [
    source 123
    target 124
    kind "relation"
    relation "is formed from"
    weight 1
  ]
  edge [
    source 125
    target 142
    kind "relation"
    relation "is located between"
    weight 1
  ]
  edge [
    source 126
    target 143
    kind "relation"
    relation "causes"
    weight 1
  ]
  edge [
    source 126
    target 200
    kind "mentions"
  ]
  edge [
    source 130
    target 146
    kind "relation"
    relation "gives a jolting effect"
    weight 1
  ]
  edge [
    source 133
    target 147
    kind "relation"
    relation "reduce jolting"
    weight 1
  ]
  edge [
    source 134
    target 148
    kind "relation"
    relation "curve from"
    weight 1
  ]
  edge [
    source 134
    target 137
    kind "relation"
    relation "are covered by"
    weight 1
  ]
  edge [
    source 137
    target 1129
    kind "mentions"
  ]
  edge [
    source 138
    target 291
    kind "mentions"
  ]
  edge [
    source 138
    target 928
    kind "mentions"
  ]
  edge [
    source 138
    target 1427
    kind "mentions"
  ]
  edge [
    source 139
    target 149
    kind "relation"
    relation "are two"
    weight 1
  ]
  edge [
    source 139
    target 291
    kind "mentions"
  ]
  edge [
    source 139
    target 928
    kind "mentions"
  ]
  edge [
    source 139
    target 1427
    kind "mentions"
  ]
  edge [
    source 141
    target 150
    kind "mentions"
  ]
  edge [
    source 144
    target 145
    kind "relation"
    relation "return to original shape"
    weight 1
  ]
  edge [
    source 144
    target 183
    kind "mentions"
  ]
  edge [
    source 150
    target 1956
    kind "summarizes"
  ]
  edge [
    source 151
    target 152
    kind "from_chunk"
  ]
  edge [
    source 151
    target 166
    kind "from_chunk"
  ]
  edge [
    source 152
    target 153
    kind "mentions"
  ]
  edge [
    source 152
    target 154
    kind "mentions"
  ]
  edge [
    source 152
    target 155
    kind "mentions"
  ]
  edge [
    source 152
    target 156
    kind "mentions"
  ]
  edge [
    source 152
    target 157
    kind "mentions"
  ]
  edge [
    source 152
    target 158
    kind "mentions"
  ]
  edge [
    source 152
    target 159
    kind "mentions"
  ]
  edge [
    source 152
    target 160
    kind "mentions"
  ]
  edge [
    source 152
    target 161
    kind "mentions"
  ]
  edge [
    source 152
    target 162
    kind "mentions"
  ]
  edge [
    source 152
    target 163
    kind "mentions"
  ]
  edge [
    source 152
    target 164
    kind "mentions"
  ]
  edge [
    source 152
    target 165
    kind "mentions"
  ]
  edge [
    source 152
    target 1946
    kind "summarizes"
  ]
  edge [
    source 153
    target 158
    kind "relation"
    relation "is similar to"
    weight 1
  ]
  edge [
    source 153
    target 210
    kind "mentions"
  ]
  edge [
    source 153
    target 211
    kind "relation"
    relation "have bones with more"
    weight 1
  ]
  edge [
    source 153
    target 1104
    kind "mentions"
  ]
  edge [
    source 153
    target 162
    kind "relation"
    relation "need"
    weight 1
  ]
  edge [
    source 153
    target 1106
    kind "mentions"
  ]
  edge [
    source 153
    target 1107
    kind "relation"
    relation "absorbs"
    weight 1
  ]
  edge [
    source 153
    target 696
    kind "relation"
    relation "absorb"
    weight 1
  ]
  edge [
    source 153
    target 1111
    kind "mentions"
  ]
  edge [
    source 153
    target 1112
    kind "relation"
    relation "takes up | becomes part of"
    weight 2
  ]
  edge [
    source 153
    target 1116
    kind "mentions"
  ]
  edge [
    source 153
    target 1208
    kind "mentions"
  ]
  edge [
    source 153
    target 1209
    kind "relation"
    relation "is a form of"
    weight 1
  ]
  edge [
    source 153
    target 1210
    kind "relation"
    relation "contain"
    weight 1
  ]
  edge [
    source 153
    target 1211
    kind "relation"
    relation "contain"
    weight 1
  ]
  edge [
    source 153
    target 1326
    kind "mentions"
  ]
  edge [
    source 154
    target 159
    kind "relation"
    relation "have more | makes bones bend easily"
    weight 2
  ]
  edge [
    source 154
    target 160
    kind "relation"
    relation "have less"
    weight 1
  ]
  edge [
    source 154
    target 1689
    kind "mentions"
  ]
  edge [
    source 154
    target 1691
    kind "relation"
    relation "consist of"
    weight 1
  ]
  edge [
    source 154
    target 1692
    kind "relation"
    relation "is curved to catch"
    weight 1
  ]
  edge [
    source 155
    target 1104
    kind "mentions"
  ]
  edge [
    source 155
    target 1450
    kind "mentions"
  ]
  edge [
    source 155
    target 1456
    kind "relation"
    relation "warms body better than"
    weight 2
  ]
  edge [
    source 155
    target 1462
    kind "mentions"
  ]
  edge [
    source 159
    target 291
    kind "mentions"
  ]
  edge [
    source 162
    target 163
    kind "relation"
    relation "loses lime when"
    weight 1
  ]
  edge [
    source 162
    target 164
    kind "relation"
    relation "loses lime when"
    weight 1
  ]
  edge [
    source 162
    target 165
    kind "relation"
    relation "crumbles to dust when"
    weight 1
  ]
  edge [
    source 162
    target 307
    kind "mentions"
  ]
  edge [
    source 162
    target 396
    kind "mentions"
  ]
  edge [
    source 162
    target 397
    kind "relation"
    relation "is protected by"
    weight 1
  ]
  edge [
    source 162
    target 400
    kind "mentions"
  ]
  edge [
    source 162
    target 401
    kind "relation"
    relation "lies in"
    weight 1
  ]
  edge [
    source 162
    target 900
    kind "mentions"
  ]
  edge [
    source 162
    target 901
    kind "relation"
    relation "covers"
    weight 1
  ]
  edge [
    source 162
    target 1104
    kind "mentions"
  ]
  edge [
    source 162
    target 1105
    kind "relation"
    relation "becomes"
    weight 1
  ]
  edge [
    source 162
    target 1302
    kind "mentions"
  ]
  edge [
    source 162
    target 1354
    kind "mentions"
  ]
  edge [
    source 166
    target 167
    kind "mentions"
  ]
  edge [
    source 166
    target 168
    kind "mentions"
  ]
  edge [
    source 166
    target 169
    kind "mentions"
  ]
  edge [
    source 166
    target 170
    kind "mentions"
  ]
  edge [
    source 166
    target 171
    kind "mentions"
  ]
  edge [
    source 166
    target 172
    kind "mentions"
  ]
  edge [
    source 166
    target 173
    kind "mentions"
  ]
  edge [
    source 166
    target 1956
    kind "summarizes"
  ]
  edge [
    source 167
    target 173
    kind "relation"
    relation "has one leg shorter than"
    weight 1
  ]
  edge [
    source 167
    target 168
    kind "relation"
    relation "became lame due to"
    weight 1
  ]
  edge [
    source 167
    target 171
    kind "relation"
    relation "wears a boot with"
    weight 1
  ]
  edge [
    source 169
    target 175
    kind "mentions"
  ]
  edge [
    source 169
    target 200
    kind "mentions"
  ]
  edge [
    source 169
    target 208
    kind "relation"
    relation "leads to"
    weight 1
  ]
  edge [
    source 170
    target 172
    kind "relation"
    relation "has iron supports"
    weight 1
  ]
  edge [
    source 170
    target 175
    kind "mentions"
  ]
  edge [
    source 174
    target 175
    kind "from_chunk"
  ]
  edge [
    source 174
    target 183
    kind "from_chunk"
  ]
  edge [
    source 175
    target 176
    kind "mentions"
  ]
  edge [
    source 175
    target 177
    kind "mentions"
  ]
  edge [
    source 175
    target 178
    kind "mentions"
  ]
  edge [
    source 175
    target 179
    kind "mentions"
  ]
  edge [
    source 175
    target 180
    kind "mentions"
  ]
  edge [
    source 175
    target 181
    kind "mentions"
  ]
  edge [
    source 175
    target 182
    kind "mentions"
  ]
  edge [
    source 175
    target 1956
    kind "summarizes"
  ]
  edge [
    source 180
    target 181
    kind "relation"
    relation "found out the trouble came from"
    weight 1
  ]
  edge [
    source 180
    target 291
    kind "mentions"
  ]
  edge [
    source 180
    target 301
    kind "relation"
    relation "say"
    weight 1
  ]
  edge [
    source 180
    target 965
    kind "mentions"
  ]
  edge [
    source 180
    target 966
    kind "relation"
    relation "learned how"
    weight 1
  ]
  edge [
    source 180
    target 1676
    kind "mentions"
  ]
  edge [
    source 180
    target 984
    kind "relation"
    relation "have never been able to set"
    weight 1
  ]
  edge [
    source 180
    target 1819
    kind "mentions"
  ]
  edge [
    source 180
    target 1839
    kind "relation"
    relation "have learned that"
    weight 1
  ]
  edge [
    source 183
    target 184
    kind "mentions"
  ]
  edge [
    source 183
    target 185
    kind "mentions"
  ]
  edge [
    source 183
    target 186
    kind "mentions"
  ]
  edge [
    source 183
    target 187
    kind "mentions"
  ]
  edge [
    source 183
    target 188
    kind "mentions"
  ]
  edge [
    source 183
    target 189
    kind "mentions"
  ]
  edge [
    source 183
    target 190
    kind "mentions"
  ]
  edge [
    source 183
    target 191
    kind "mentions"
  ]
  edge [
    source 183
    target 192
    kind "mentions"
  ]
  edge [
    source 183
    target 193
    kind "mentions"
  ]
  edge [
    source 183
    target 194
    kind "mentions"
  ]
  edge [
    source 183
    target 195
    kind "mentions"
  ]
  edge [
    source 183
    target 196
    kind "mentions"
  ]
  edge [
    source 183
    target 197
    kind "mentions"
  ]
  edge [
    source 183
    target 198
    kind "mentions"
  ]
  edge [
    source 183
    target 1956
    kind "summarizes"
  ]
  edge [
    source 184
    target 210
    kind "mentions"
  ]
  edge [
    source 184
    target 211
    kind "relation"
    relation "should be kindly helpful to | have slower heart pumping rate than"
    weight 2
  ]
  edge [
    source 184
    target 443
    kind "mentions"
  ]
  edge [
    source 184
    target 448
    kind "relation"
    relation "say parents take care of"
    weight 1
  ]
  edge [
    source 184
    target 444
    kind "relation"
    relation "have some ways where only themselves can take care"
    weight 1
  ]
  edge [
    source 184
    target 968
    kind "mentions"
  ]
  edge [
    source 184
    target 969
    kind "relation"
    relation "tells"
    weight 1
  ]
  edge [
    source 184
    target 988
    kind "mentions"
  ]
  edge [
    source 184
    target 294
    kind "relation"
    relation "need food to grow"
    weight 1
  ]
  edge [
    source 184
    target 981
    kind "relation"
    relation "need food to grow"
    weight 1
  ]
  edge [
    source 184
    target 992
    kind "mentions"
  ]
  edge [
    source 184
    target 610
    kind "relation"
    relation "constantly eat"
    weight 1
  ]
  edge [
    source 184
    target 993
    kind "relation"
    relation "constantly eat | like"
    weight 2
  ]
  edge [
    source 184
    target 891
    kind "relation"
    relation "prevent stomach from resting"
    weight 1
  ]
  edge [
    source 184
    target 1187
    kind "mentions"
  ]
  edge [
    source 184
    target 602
    kind "relation"
    relation "is harmful when consumed in excess"
    weight 1
  ]
  edge [
    source 184
    target 1577
    kind "mentions"
  ]
  edge [
    source 184
    target 1585
    kind "relation"
    relation "often have"
    weight 1
  ]
  edge [
    source 184
    target 1586
    kind "relation"
    relation "often have"
    weight 1
  ]
  edge [
    source 184
    target 1590
    kind "relation"
    relation "need to be washed"
    weight 1
  ]
  edge [
    source 184
    target 1774
    kind "mentions"
  ]
  edge [
    source 184
    target 1776
    kind "relation"
    relation "have heart pumping rate of"
    weight 1
  ]
  edge [
    source 184
    target 1841
    kind "mentions"
  ]
  edge [
    source 184
    target 1828
    kind "relation"
    relation "are interested in stories about"
    weight 1
  ]
  edge [
    source 185
    target 189
    kind "relation"
    relation "leads to"
    weight 1
  ]
  edge [
    source 185
    target 190
    kind "relation"
    relation "leads to"
    weight 1
  ]
  edge [
    source 185
    target 191
    kind "relation"
    relation "cramps"
    weight 1
  ]
  edge [
    source 187
    target 1653
    kind "mentions"
  ]
  edge [
    source 187
    target 1657
    kind "relation"
    relation "should have light from"
    weight 1
  ]
  edge [
    source 189
    target 200
    kind "mentions"
  ]
  edge [
    source 189
    target 208
    kind "relation"
    relation "leads to"
    weight 1
  ]
  edge [
    source 190
    target 200
    kind "mentions"
  ]
  edge [
    source 190
    target 208
    kind "relation"
    relation "leads to"
    weight 1
  ]
  edge [
    source 191
    target 192
    kind "relation"
    relation "do not have room for"
    weight 1
  ]
  edge [
    source 191
    target 291
    kind "mentions"
  ]
  edge [
    source 191
    target 298
    kind "relation"
    relation "injures"
    weight 1
  ]
  edge [
    source 191
    target 928
    kind "mentions"
  ]
  edge [
    source 191
    target 419
    kind "relation"
    relation "contains | are located in"
    weight 2
  ]
  edge [
    source 191
    target 1288
    kind "mentions"
  ]
  edge [
    source 191
    target 1291
    kind "relation"
    relation "leads to"
    weight 1
  ]
  edge [
    source 191
    target 1293
    kind "mentions"
  ]
  edge [
    source 191
    target 1295
    kind "relation"
    relation "prevents food from going down the wrong way"
    weight 1
  ]
  edge [
    source 191
    target 1302
    kind "mentions"
  ]
  edge [
    source 191
    target 930
    kind "relation"
    relation "pumps blood to | are on each side of"
    weight 2
  ]
  edge [
    source 191
    target 450
    kind "relation"
    relation "distributes blood to"
    weight 1
  ]
  edge [
    source 191
    target 1467
    kind "mentions"
  ]
  edge [
    source 191
    target 1474
    kind "relation"
    relation "change"
    weight 1
  ]
  edge [
    source 191
    target 1475
    kind "relation"
    relation "require"
    weight 1
  ]
  edge [
    source 191
    target 1476
    kind "relation"
    relation "require"
    weight 1
  ]
  edge [
    source 191
    target 1477
    kind "mentions"
  ]
  edge [
    source 191
    target 1481
    kind "mentions"
  ]
  edge [
    source 191
    target 1451
    kind "relation"
    relation "take in"
    weight 1
  ]
  edge [
    source 191
    target 1483
    kind "relation"
    relation "expel"
    weight 1
  ]
  edge [
    source 191
    target 1482
    kind "relation"
    relation "prepare blood to be"
    weight 1
  ]
  edge [
    source 191
    target 1488
    kind "relation"
    relation "use fresh air to"
    weight 1
  ]
  edge [
    source 191
    target 1489
    kind "relation"
    relation "work continuously"
    weight 1
  ]
  edge [
    source 191
    target 1484
    kind "relation"
    relation "is a rest period for"
    weight 1
  ]
  edge [
    source 191
    target 1491
    kind "mentions"
  ]
  edge [
    source 191
    target 1493
    kind "relation"
    relation "cannot function properly if"
    weight 1
  ]
  edge [
    source 191
    target 1496
    kind "mentions"
  ]
  edge [
    source 191
    target 1497
    kind "relation"
    relation "cannot expand"
    weight 1
  ]
  edge [
    source 191
    target 1178
    kind "relation"
    relation "cannot take in enough air to purify | are needed to purify | cannot perform their work | make blood pure and red again | use fresh air to make | make blood bright and pure again"
    weight 6
  ]
  edge [
    source 191
    target 1498
    kind "mentions"
  ]
  edge [
    source 191
    target 1499
    kind "relation"
    relation "breathe out"
    weight 1
  ]
  edge [
    source 191
    target 1514
    kind "mentions"
  ]
  edge [
    source 191
    target 1469
    kind "relation"
    relation "have delicate muscular walls"
    weight 1
  ]
  edge [
    source 191
    target 1527
    kind "mentions"
  ]
  edge [
    source 191
    target 1529
    kind "mentions"
  ]
  edge [
    source 191
    target 1539
    kind "relation"
    relation "send blood to"
    weight 1
  ]
  edge [
    source 191
    target 1532
    kind "relation"
    relation "require"
    weight 1
  ]
  edge [
    source 191
    target 457
    kind "relation"
    relation "rest during"
    weight 1
  ]
  edge [
    source 191
    target 1625
    kind "mentions"
  ]
  edge [
    source 191
    target 1808
    kind "mentions"
  ]
  edge [
    source 191
    target 529
    kind "relation"
    relation "affects"
    weight 1
  ]
  edge [
    source 192
    target 418
    kind "mentions"
  ]
  edge [
    source 192
    target 419
    kind "relation"
    relation "involves movement of"
    weight 1
  ]
  edge [
    source 192
    target 397
    kind "relation"
    relation "is not involved in"
    weight 1
  ]
  edge [
    source 192
    target 421
    kind "mentions"
  ]
  edge [
    source 192
    target 423
    kind "relation"
    relation "are sent about"
    weight 1
  ]
  edge [
    source 192
    target 428
    kind "mentions"
  ]
  edge [
    source 192
    target 1298
    kind "mentions"
  ]
  edge [
    source 192
    target 1295
    kind "relation"
    relation "opens during"
    weight 1
  ]
  edge [
    source 192
    target 1514
    kind "mentions"
  ]
  edge [
    source 192
    target 1520
    kind "relation"
    relation "move during"
    weight 1
  ]
  edge [
    source 192
    target 1529
    kind "mentions"
  ]
  edge [
    source 192
    target 1533
    kind "relation"
    relation "restrict breathing and airflow"
    weight 1
  ]
  edge [
    source 194
    target 195
    kind "relation"
    relation "causes one shoulder to be higher than the other"
    weight 1
  ]
  edge [
    source 194
    target 196
    kind "relation"
    relation "causes one hip to be higher than the other"
    weight 1
  ]
  edge [
    source 197
    target 198
    kind "relation"
    relation "may cause"
    weight 1
  ]
  edge [
    source 197
    target 258
    kind "mentions"
  ]
  edge [
    source 197
    target 259
    kind "relation"
    relation "uses tobacco while"
    weight 1
  ]
  edge [
    source 199
    target 200
    kind "from_chunk"
  ]
  edge [
    source 199
    target 210
    kind "from_chunk"
  ]
  edge [
    source 199
    target 216
    kind "from_chunk"
  ]
  edge [
    source 199
    target 228
    kind "from_chunk"
  ]
  edge [
    source 200
    target 201
    kind "mentions"
  ]
  edge [
    source 200
    target 202
    kind "mentions"
  ]
  edge [
    source 200
    target 203
    kind "mentions"
  ]
  edge [
    source 200
    target 204
    kind "mentions"
  ]
  edge [
    source 200
    target 205
    kind "mentions"
  ]
  edge [
    source 200
    target 206
    kind "mentions"
  ]
  edge [
    source 200
    target 207
    kind "mentions"
  ]
  edge [
    source 200
    target 208
    kind "mentions"
  ]
  edge [
    source 200
    target 209
    kind "mentions"
  ]
  edge [
    source 200
    target 1956
    kind "summarizes"
  ]
  edge [
    source 201
    target 202
    kind "relation"
    relation "have | easily bend"
    weight 2
  ]
  edge [
    source 201
    target 208
    kind "relation"
    relation "must sit and stand erect to avoid"
    weight 1
  ]
  edge [
    source 201
    target 205
    kind "relation"
    relation "should avoid"
    weight 1
  ]
  edge [
    source 201
    target 206
    kind "relation"
    relation "should avoid"
    weight 1
  ]
  edge [
    source 201
    target 207
    kind "relation"
    relation "should avoid"
    weight 1
  ]
  edge [
    source 201
    target 209
    kind "relation"
    relation "are the goal of"
    weight 1
  ]
  edge [
    source 210
    target 211
    kind "mentions"
  ]
  edge [
    source 210
    target 212
    kind "mentions"
  ]
  edge [
    source 210
    target 213
    kind "mentions"
  ]
  edge [
    source 210
    target 214
    kind "mentions"
  ]
  edge [
    source 210
    target 215
    kind "mentions"
  ]
  edge [
    source 210
    target 1950
    kind "summarizes"
  ]
  edge [
    source 211
    target 1774
    kind "mentions"
  ]
  edge [
    source 213
    target 214
    kind "relation"
    relation "prevents"
    weight 1
  ]
  edge [
    source 214
    target 215
    kind "relation"
    relation "may cause"
    weight 1
  ]
  edge [
    source 216
    target 217
    kind "mentions"
  ]
  edge [
    source 216
    target 218
    kind "mentions"
  ]
  edge [
    source 216
    target 219
    kind "mentions"
  ]
  edge [
    source 216
    target 220
    kind "mentions"
  ]
  edge [
    source 216
    target 221
    kind "mentions"
  ]
  edge [
    source 216
    target 222
    kind "mentions"
  ]
  edge [
    source 216
    target 223
    kind "mentions"
  ]
  edge [
    source 216
    target 224
    kind "mentions"
  ]
  edge [
    source 216
    target 225
    kind "mentions"
  ]
  edge [
    source 216
    target 226
    kind "mentions"
  ]
  edge [
    source 216
    target 227
    kind "mentions"
  ]
  edge [
    source 216
    target 1945
    kind "summarizes"
  ]
  edge [
    source 217
    target 218
    kind "relation"
    relation "outgrow their shoes faster than they wear them out"
    weight 1
  ]
  edge [
    source 220
    target 221
    kind "relation"
    relation "cause"
    weight 1
  ]
  edge [
    source 220
    target 222
    kind "relation"
    relation "cause"
    weight 1
  ]
  edge [
    source 220
    target 223
    kind "relation"
    relation "cause | are very hard to get rid of"
    weight 2
  ]
  edge [
    source 221
    target 1166
    kind "mentions"
  ]
  edge [
    source 221
    target 697
    kind "relation"
    relation "comes from"
    weight 1
  ]
  edge [
    source 226
    target 227
    kind "relation"
    relation "should wear"
    weight 1
  ]
  edge [
    source 228
    target 229
    kind "mentions"
  ]
  edge [
    source 228
    target 230
    kind "mentions"
  ]
  edge [
    source 228
    target 231
    kind "mentions"
  ]
  edge [
    source 228
    target 232
    kind "mentions"
  ]
  edge [
    source 228
    target 1947
    kind "summarizes"
  ]
  edge [
    source 229
    target 247
    kind "mentions"
  ]
  edge [
    source 229
    target 255
    kind "relation"
    relation "build their bodies"
    weight 1
  ]
  edge [
    source 233
    target 234
    kind "from_chunk"
  ]
  edge [
    source 233
    target 247
    kind "from_chunk"
  ]
  edge [
    source 233
    target 258
    kind "from_chunk"
  ]
  edge [
    source 233
    target 265
    kind "from_chunk"
  ]
  edge [
    source 234
    target 235
    kind "mentions"
  ]
  edge [
    source 234
    target 236
    kind "mentions"
  ]
  edge [
    source 234
    target 237
    kind "mentions"
  ]
  edge [
    source 234
    target 238
    kind "mentions"
  ]
  edge [
    source 234
    target 239
    kind "mentions"
  ]
  edge [
    source 234
    target 240
    kind "mentions"
  ]
  edge [
    source 234
    target 241
    kind "mentions"
  ]
  edge [
    source 234
    target 242
    kind "mentions"
  ]
  edge [
    source 234
    target 243
    kind "mentions"
  ]
  edge [
    source 234
    target 244
    kind "mentions"
  ]
  edge [
    source 234
    target 245
    kind "mentions"
  ]
  edge [
    source 234
    target 246
    kind "mentions"
  ]
  edge [
    source 234
    target 1951
    kind "summarizes"
  ]
  edge [
    source 235
    target 245
    kind "relation"
    relation "would become weaker if"
    weight 1
  ]
  edge [
    source 236
    target 245
    kind "relation"
    relation "would become weaker if"
    weight 1
  ]
  edge [
    source 237
    target 245
    kind "relation"
    relation "would become weaker if"
    weight 1
  ]
  edge [
    source 238
    target 245
    kind "relation"
    relation "would become weaker if"
    weight 1
  ]
  edge [
    source 239
    target 245
    kind "relation"
    relation "would become weaker if"
    weight 1
  ]
  edge [
    source 239
    target 1571
    kind "mentions"
  ]
  edge [
    source 239
    target 981
    kind "relation"
    relation "grow from"
    weight 1
  ]
  edge [
    source 240
    target 245
    kind "relation"
    relation "would become weaker if"
    weight 1
  ]
  edge [
    source 241
    target 245
    kind "relation"
    relation "would become weaker if"
    weight 1
  ]
  edge [
    source 242
    target 244
    kind "relation"
    relation "is made weaker by"
    weight 1
  ]
  edge [
    source 244
    target 246
    kind "relation"
    relation "should be built with"
    weight 1
  ]
  edge [
    source 247
    target 248
    kind "mentions"
  ]
  edge [
    source 247
    target 249
    kind "mentions"
  ]
  edge [
    source 247
    target 250
    kind "mentions"
  ]
  edge [
    source 247
    target 251
    kind "mentions"
  ]
  edge [
    source 247
    target 252
    kind "mentions"
  ]
  edge [
    source 247
    target 253
    kind "mentions"
  ]
  edge [
    source 247
    target 254
    kind "mentions"
  ]
  edge [
    source 247
    target 255
    kind "mentions"
  ]
  edge [
    source 247
    target 256
    kind "mentions"
  ]
  edge [
    source 247
    target 257
    kind "mentions"
  ]
  edge [
    source 247
    target 1947
    kind "summarizes"
  ]
  edge [
    source 248
    target 255
    kind "relation"
    relation "build their bodies"
    weight 1
  ]
  edge [
    source 249
    target 256
    kind "relation"
    relation "reaches full size"
    weight 1
  ]
  edge [
    source 249
    target 257
    kind "relation"
    relation "must be repaired"
    weight 1
  ]
  edge [
    source 249
    target 258
    kind "mentions"
  ]
  edge [
    source 249
    target 424
    kind "mentions"
  ]
  edge [
    source 249
    target 425
    kind "relation"
    relation "is a"
    weight 1
  ]
  edge [
    source 249
    target 455
    kind "mentions"
  ]
  edge [
    source 249
    target 490
    kind "mentions"
  ]
  edge [
    source 249
    target 499
    kind "relation"
    relation "is of great service to"
    weight 1
  ]
  edge [
    source 249
    target 565
    kind "mentions"
  ]
  edge [
    source 249
    target 566
    kind "relation"
    relation "affects"
    weight 1
  ]
  edge [
    source 249
    target 569
    kind "mentions"
  ]
  edge [
    source 249
    target 659
    kind "mentions"
  ]
  edge [
    source 249
    target 734
    kind "mentions"
  ]
  edge [
    source 249
    target 735
    kind "relation"
    relation "is poisoning"
    weight 1
  ]
  edge [
    source 249
    target 850
    kind "mentions"
  ]
  edge [
    source 249
    target 851
    kind "relation"
    relation "tries to stop"
    weight 1
  ]
  edge [
    source 249
    target 866
    kind "mentions"
  ]
  edge [
    source 249
    target 965
    kind "mentions"
  ]
  edge [
    source 249
    target 966
    kind "relation"
    relation "support"
    weight 1
  ]
  edge [
    source 249
    target 978
    kind "mentions"
  ]
  edge [
    source 249
    target 470
    kind "relation"
    relation "is ready to be sent through | must be changed by | needs"
    weight 3
  ]
  edge [
    source 249
    target 988
    kind "mentions"
  ]
  edge [
    source 249
    target 991
    kind "relation"
    relation "causes wear and tear of body parts"
    weight 1
  ]
  edge [
    source 249
    target 989
    kind "relation"
    relation "need food for mending"
    weight 1
  ]
  edge [
    source 249
    target 1001
    kind "mentions"
  ]
  edge [
    source 249
    target 891
    kind "relation"
    relation "cannot do its work well"
    weight 1
  ]
  edge [
    source 249
    target 1055
    kind "mentions"
  ]
  edge [
    source 249
    target 1056
    kind "mentions"
  ]
  edge [
    source 249
    target 1072
    kind "mentions"
  ]
  edge [
    source 249
    target 601
    kind "relation"
    relation "is made of"
    weight 1
  ]
  edge [
    source 249
    target 1136
    kind "mentions"
  ]
  edge [
    source 249
    target 375
    kind "relation"
    relation "needs"
    weight 1
  ]
  edge [
    source 249
    target 1139
    kind "relation"
    relation "is necessary for"
    weight 1
  ]
  edge [
    source 249
    target 1177
    kind "mentions"
  ]
  edge [
    source 249
    target 602
    kind "relation"
    relation "helps feed"
    weight 1
  ]
  edge [
    source 249
    target 1248
    kind "mentions"
  ]
  edge [
    source 249
    target 1315
    kind "mentions"
  ]
  edge [
    source 249
    target 1323
    kind "relation"
    relation "will not be properly digested"
    weight 1
  ]
  edge [
    source 249
    target 1403
    kind "mentions"
  ]
  edge [
    source 249
    target 1416
    kind "relation"
    relation "should own"
    weight 1
  ]
  edge [
    source 249
    target 1427
    kind "mentions"
  ]
  edge [
    source 249
    target 1435
    kind "mentions"
  ]
  edge [
    source 249
    target 1481
    kind "mentions"
  ]
  edge [
    source 249
    target 930
    kind "relation"
    relation "pumps blood through"
    weight 1
  ]
  edge [
    source 249
    target 1496
    kind "mentions"
  ]
  edge [
    source 249
    target 1178
    kind "relation"
    relation "cannot perform its function | cannot perform its work | flows quickly"
    weight 3
  ]
  edge [
    source 249
    target 1498
    kind "mentions"
  ]
  edge [
    source 249
    target 1508
    kind "mentions"
  ]
  edge [
    source 249
    target 1512
    kind "relation"
    relation "is refreshed"
    weight 1
  ]
  edge [
    source 249
    target 1514
    kind "mentions"
  ]
  edge [
    source 249
    target 1541
    kind "mentions"
  ]
  edge [
    source 249
    target 981
    kind "relation"
    relation "removes waste matter continuously | is covered with | loses heat through"
    weight 3
  ]
  edge [
    source 249
    target 1543
    kind "relation"
    relation "has a more delicate lining of"
    weight 1
  ]
  edge [
    source 249
    target 1550
    kind "mentions"
  ]
  edge [
    source 249
    target 1570
    kind "relation"
    relation "removes worn-out matter through"
    weight 1
  ]
  edge [
    source 249
    target 1577
    kind "mentions"
  ]
  edge [
    source 249
    target 1588
    kind "relation"
    relation "comes from inside the body"
    weight 1
  ]
  edge [
    source 249
    target 1605
    kind "mentions"
  ]
  edge [
    source 249
    target 1609
    kind "relation"
    relation "cannot function without causing trouble to"
    weight 1
  ]
  edge [
    source 249
    target 1756
    kind "mentions"
  ]
  edge [
    source 249
    target 1757
    kind "relation"
    relation "keep warm"
    weight 1
  ]
  edge [
    source 249
    target 1764
    kind "relation"
    relation "has steady work of"
    weight 1
  ]
  edge [
    source 249
    target 1772
    kind "mentions"
  ]
  edge [
    source 249
    target 1758
    kind "relation"
    relation "increases heat delivery"
    weight 1
  ]
  edge [
    source 249
    target 1779
    kind "mentions"
  ]
  edge [
    source 249
    target 1781
    kind "relation"
    relation "exhales warm air when breathing"
    weight 1
  ]
  edge [
    source 249
    target 1867
    kind "mentions"
  ]
  edge [
    source 251
    target 988
    kind "mentions"
  ]
  edge [
    source 251
    target 1302
    kind "mentions"
  ]
  edge [
    source 253
    target 254
    kind "relation"
    relation "is foolish to make"
    weight 1
  ]
  edge [
    source 255
    target 859
    kind "mentions"
  ]
  edge [
    source 258
    target 259
    kind "mentions"
  ]
  edge [
    source 258
    target 260
    kind "mentions"
  ]
  edge [
    source 258
    target 261
    kind "mentions"
  ]
  edge [
    source 258
    target 262
    kind "mentions"
  ]
  edge [
    source 258
    target 263
    kind "mentions"
  ]
  edge [
    source 258
    target 264
    kind "mentions"
  ]
  edge [
    source 258
    target 1959
    kind "summarizes"
  ]
  edge [
    source 259
    target 263
    kind "relation"
    relation "makes his body less strong"
    weight 1
  ]
  edge [
    source 259
    target 264
    kind "relation"
    relation "has weaker bones"
    weight 1
  ]
  edge [
    source 259
    target 261
    kind "relation"
    relation "cannot become"
    weight 1
  ]
  edge [
    source 259
    target 262
    kind "relation"
    relation "causes body to be less strong | prevents bones from growing well"
    weight 2
  ]
  edge [
    source 259
    target 518
    kind "mentions"
  ]
  edge [
    source 259
    target 522
    kind "relation"
    relation "is not as good a scholar as"
    weight 1
  ]
  edge [
    source 259
    target 593
    kind "mentions"
  ]
  edge [
    source 259
    target 1307
    kind "mentions"
  ]
  edge [
    source 259
    target 1874
    kind "mentions"
  ]
  edge [
    source 262
    target 265
    kind "mentions"
  ]
  edge [
    source 262
    target 267
    kind "relation"
    relation "is a worse habit than | is more filthy than | is worse and more filthy than"
    weight 3
  ]
  edge [
    source 262
    target 273
    kind "mentions"
  ]
  edge [
    source 262
    target 1891
    kind "mentions"
  ]
  edge [
    source 262
    target 592
    kind "relation"
    relation "burns up the dollar | causes harm to"
    weight 2
  ]
  edge [
    source 262
    target 1907
    kind "mentions"
  ]
  edge [
    source 262
    target 1876
    kind "relation"
    relation "is consumed by"
    weight 1
  ]
  edge [
    source 265
    target 266
    kind "mentions"
  ]
  edge [
    source 265
    target 267
    kind "mentions"
  ]
  edge [
    source 265
    target 268
    kind "mentions"
  ]
  edge [
    source 265
    target 269
    kind "mentions"
  ]
  edge [
    source 265
    target 270
    kind "mentions"
  ]
  edge [
    source 265
    target 271
    kind "mentions"
  ]
  edge [
    source 265
    target 1959
    kind "summarizes"
  ]
  edge [
    source 266
    target 271
    kind "relation"
    relation "are small but"
    weight 1
  ]
  edge [
    source 266
    target 291
    kind "mentions"
  ]
  edge [
    source 266
    target 302
    kind "relation"
    relation "are said to"
    weight 1
  ]
  edge [
    source 267
    target 273
    kind "mentions"
  ]
  edge [
    source 267
    target 274
    kind "relation"
    relation "is damaged in every way"
    weight 1
  ]
  edge [
    source 267
    target 291
    kind "mentions"
  ]
  edge [
    source 272
    target 273
    kind "from_chunk"
  ]
  edge [
    source 273
    target 274
    kind "mentions"
  ]
  edge [
    source 273
    target 275
    kind "mentions"
  ]
  edge [
    source 273
    target 276
    kind "mentions"
  ]
  edge [
    source 273
    target 277
    kind "mentions"
  ]
  edge [
    source 273
    target 278
    kind "mentions"
  ]
  edge [
    source 273
    target 279
    kind "mentions"
  ]
  edge [
    source 273
    target 280
    kind "mentions"
  ]
  edge [
    source 273
    target 281
    kind "mentions"
  ]
  edge [
    source 273
    target 282
    kind "mentions"
  ]
  edge [
    source 273
    target 283
    kind "mentions"
  ]
  edge [
    source 273
    target 284
    kind "mentions"
  ]
  edge [
    source 273
    target 285
    kind "mentions"
  ]
  edge [
    source 273
    target 286
    kind "mentions"
  ]
  edge [
    source 273
    target 287
    kind "mentions"
  ]
  edge [
    source 273
    target 288
    kind "mentions"
  ]
  edge [
    source 273
    target 289
    kind "mentions"
  ]
  edge [
    source 273
    target 1959
    kind "summarizes"
  ]
  edge [
    source 274
    target 275
    kind "relation"
    relation "experiences stunted growth"
    weight 1
  ]
  edge [
    source 274
    target 276
    kind "relation"
    relation "has harmed mind"
    weight 1
  ]
  edge [
    source 274
    target 291
    kind "mentions"
  ]
  edge [
    source 275
    target 351
    kind "mentions"
  ]
  edge [
    source 275
    target 978
    kind "mentions"
  ]
  edge [
    source 275
    target 988
    kind "mentions"
  ]
  edge [
    source 275
    target 1055
    kind "mentions"
  ]
  edge [
    source 275
    target 1056
    kind "mentions"
  ]
  edge [
    source 276
    target 659
    kind "mentions"
  ]
  edge [
    source 276
    target 734
    kind "mentions"
  ]
  edge [
    source 276
    target 735
    kind "relation"
    relation "is poisoning"
    weight 1
  ]
  edge [
    source 276
    target 1403
    kind "mentions"
  ]
  edge [
    source 276
    target 1416
    kind "relation"
    relation "should own"
    weight 1
  ]
  edge [
    source 277
    target 1062
    kind "mentions"
  ]
  edge [
    source 277
    target 1063
    kind "relation"
    relation "spreads"
    weight 1
  ]
  edge [
    source 277
    target 1064
    kind "relation"
    relation "causes"
    weight 1
  ]
  edge [
    source 280
    target 1055
    kind "mentions"
  ]
  edge [
    source 280
    target 1056
    kind "mentions"
  ]
  edge [
    source 280
    target 1057
    kind "mentions"
  ]
  edge [
    source 280
    target 1158
    kind "mentions"
  ]
  edge [
    source 280
    target 375
    kind "relation"
    relation "is necessary for"
    weight 1
  ]
  edge [
    source 280
    target 1159
    kind "relation"
    relation "is necessary for"
    weight 1
  ]
  edge [
    source 280
    target 1160
    kind "relation"
    relation "is necessary for"
    weight 1
  ]
  edge [
    source 280
    target 1187
    kind "mentions"
  ]
  edge [
    source 285
    target 286
    kind "relation"
    relation "is disgusting to"
    weight 1
  ]
  edge [
    source 285
    target 287
    kind "relation"
    relation "hurts the health of"
    weight 1
  ]
  edge [
    source 288
    target 289
    kind "relation"
    relation "cannot begin using tobacco and still have | would have had if never used tobacco"
    weight 2
  ]
  edge [
    source 290
    target 291
    kind "from_chunk"
  ]
  edge [
    source 290
    target 304
    kind "from_chunk"
  ]
  edge [
    source 291
    target 292
    kind "mentions"
  ]
  edge [
    source 291
    target 293
    kind "mentions"
  ]
  edge [
    source 291
    target 294
    kind "mentions"
  ]
  edge [
    source 291
    target 295
    kind "mentions"
  ]
  edge [
    source 291
    target 296
    kind "mentions"
  ]
  edge [
    source 291
    target 297
    kind "mentions"
  ]
  edge [
    source 291
    target 298
    kind "mentions"
  ]
  edge [
    source 291
    target 299
    kind "mentions"
  ]
  edge [
    source 291
    target 300
    kind "mentions"
  ]
  edge [
    source 291
    target 301
    kind "mentions"
  ]
  edge [
    source 291
    target 302
    kind "mentions"
  ]
  edge [
    source 291
    target 303
    kind "mentions"
  ]
  edge [
    source 291
    target 1959
    kind "summarizes"
  ]
  edge [
    source 293
    target 617
    kind "mentions"
  ]
  edge [
    source 293
    target 621
    kind "relation"
    relation "press grapes with"
    weight 1
  ]
  edge [
    source 293
    target 1605
    kind "mentions"
  ]
  edge [
    source 294
    target 303
    kind "relation"
    relation "make limbs move"
    weight 1
  ]
  edge [
    source 294
    target 304
    kind "mentions"
  ]
  edge [
    source 294
    target 305
    kind "relation"
    relation "cause"
    weight 1
  ]
  edge [
    source 294
    target 328
    kind "mentions"
  ]
  edge [
    source 294
    target 312
    kind "relation"
    relation "has"
    weight 1
  ]
  edge [
    source 294
    target 329
    kind "mentions"
  ]
  edge [
    source 294
    target 333
    kind "relation"
    relation "appear as | are made of"
    weight 2
  ]
  edge [
    source 294
    target 330
    kind "relation"
    relation "are connected to"
    weight 1
  ]
  edge [
    source 294
    target 335
    kind "mentions"
  ]
  edge [
    source 294
    target 337
    kind "relation"
    relation "are moved by"
    weight 1
  ]
  edge [
    source 294
    target 338
    kind "relation"
    relation "are attached to"
    weight 1
  ]
  edge [
    source 294
    target 341
    kind "mentions"
  ]
  edge [
    source 294
    target 343
    kind "relation"
    relation "makes"
    weight 1
  ]
  edge [
    source 294
    target 348
    kind "mentions"
  ]
  edge [
    source 294
    target 351
    kind "mentions"
  ]
  edge [
    source 294
    target 361
    kind "mentions"
  ]
  edge [
    source 294
    target 357
    kind "relation"
    relation "helps to build"
    weight 1
  ]
  edge [
    source 294
    target 363
    kind "relation"
    relation "helps to build"
    weight 1
  ]
  edge [
    source 294
    target 364
    kind "relation"
    relation "helps to build"
    weight 1
  ]
  edge [
    source 294
    target 367
    kind "relation"
    relation "helps to build"
    weight 1
  ]
  edge [
    source 294
    target 368
    kind "mentions"
  ]
  edge [
    source 294
    target 370
    kind "relation"
    relation "is an enemy to"
    weight 1
  ]
  edge [
    source 294
    target 372
    kind "mentions"
  ]
  edge [
    source 294
    target 376
    kind "relation"
    relation "are lean meat"
    weight 1
  ]
  edge [
    source 294
    target 378
    kind "mentions"
  ]
  edge [
    source 294
    target 383
    kind "mentions"
  ]
  edge [
    source 294
    target 374
    kind "relation"
    relation "require muscles to function"
    weight 1
  ]
  edge [
    source 294
    target 385
    kind "relation"
    relation "have"
    weight 1
  ]
  edge [
    source 294
    target 390
    kind "relation"
    relation "become strong through"
    weight 1
  ]
  edge [
    source 294
    target 391
    kind "mentions"
  ]
  edge [
    source 294
    target 392
    kind "relation"
    relation "receive signals from | are directed by | send messages to | are kept at work by"
    weight 4
  ]
  edge [
    source 294
    target 393
    kind "relation"
    relation "send messages between towns"
    weight 1
  ]
  edge [
    source 294
    target 403
    kind "mentions"
  ]
  edge [
    source 294
    target 397
    kind "relation"
    relation "sends message to | sent a signal to | sends many orders to | keeps"
    weight 4
  ]
  edge [
    source 294
    target 404
    kind "relation"
    relation "contract quickly | bend joint of | remove | was pulled away by"
    weight 4
  ]
  edge [
    source 294
    target 413
    kind "mentions"
  ]
  edge [
    source 294
    target 414
    kind "mentions"
  ]
  edge [
    source 294
    target 418
    kind "mentions"
  ]
  edge [
    source 294
    target 420
    kind "relation"
    relation "move quietly and steadily"
    weight 1
  ]
  edge [
    source 294
    target 421
    kind "mentions"
  ]
  edge [
    source 294
    target 424
    kind "mentions"
  ]
  edge [
    source 294
    target 938
    kind "mentions"
  ]
  edge [
    source 294
    target 891
    kind "relation"
    relation "has a strong outer layer of"
    weight 1
  ]
  edge [
    source 294
    target 978
    kind "mentions"
  ]
  edge [
    source 294
    target 470
    kind "relation"
    relation "is carried to"
    weight 1
  ]
  edge [
    source 294
    target 986
    kind "relation"
    relation "need feeding"
    weight 1
  ]
  edge [
    source 294
    target 988
    kind "mentions"
  ]
  edge [
    source 294
    target 1129
    kind "mentions"
  ]
  edge [
    source 294
    target 1132
    kind "relation"
    relation "need"
    weight 1
  ]
  edge [
    source 294
    target 1144
    kind "mentions"
  ]
  edge [
    source 294
    target 1214
    kind "mentions"
  ]
  edge [
    source 294
    target 1215
    kind "relation"
    relation "need"
    weight 1
  ]
  edge [
    source 294
    target 1216
    kind "relation"
    relation "need"
    weight 1
  ]
  edge [
    source 294
    target 1217
    kind "relation"
    relation "need"
    weight 1
  ]
  edge [
    source 294
    target 1326
    kind "mentions"
  ]
  edge [
    source 294
    target 711
    kind "relation"
    relation "provides"
    weight 1
  ]
  edge [
    source 294
    target 1335
    kind "mentions"
  ]
  edge [
    source 294
    target 1354
    kind "mentions"
  ]
  edge [
    source 294
    target 1514
    kind "mentions"
  ]
  edge [
    source 294
    target 1527
    kind "mentions"
  ]
  edge [
    source 294
    target 1628
    kind "mentions"
  ]
  edge [
    source 295
    target 296
    kind "relation"
    relation "shuts itself when left open | closes automatically when open"
    weight 2
  ]
  edge [
    source 295
    target 304
    kind "mentions"
  ]
  edge [
    source 295
    target 307
    kind "mentions"
  ]
  edge [
    source 295
    target 308
    kind "relation"
    relation "is fastened to"
    weight 1
  ]
  edge [
    source 296
    target 304
    kind "mentions"
  ]
  edge [
    source 296
    target 307
    kind "mentions"
  ]
  edge [
    source 299
    target 300
    kind "relation"
    relation "may injure"
    weight 1
  ]
  edge [
    source 303
    target 304
    kind "mentions"
  ]
  edge [
    source 304
    target 305
    kind "mentions"
  ]
  edge [
    source 304
    target 1958
    kind "summarizes"
  ]
  edge [
    source 306
    target 307
    kind "from_chunk"
  ]
  edge [
    source 306
    target 324
    kind "from_chunk"
  ]
  edge [
    source 307
    target 308
    kind "mentions"
  ]
  edge [
    source 307
    target 309
    kind "mentions"
  ]
  edge [
    source 307
    target 310
    kind "mentions"
  ]
  edge [
    source 307
    target 311
    kind "mentions"
  ]
  edge [
    source 307
    target 312
    kind "mentions"
  ]
  edge [
    source 307
    target 313
    kind "mentions"
  ]
  edge [
    source 307
    target 314
    kind "mentions"
  ]
  edge [
    source 307
    target 315
    kind "mentions"
  ]
  edge [
    source 307
    target 316
    kind "mentions"
  ]
  edge [
    source 307
    target 317
    kind "mentions"
  ]
  edge [
    source 307
    target 318
    kind "mentions"
  ]
  edge [
    source 307
    target 319
    kind "mentions"
  ]
  edge [
    source 307
    target 320
    kind "mentions"
  ]
  edge [
    source 307
    target 321
    kind "mentions"
  ]
  edge [
    source 307
    target 322
    kind "mentions"
  ]
  edge [
    source 307
    target 323
    kind "mentions"
  ]
  edge [
    source 307
    target 1958
    kind "summarizes"
  ]
  edge [
    source 308
    target 309
    kind "relation"
    relation "is fastened to"
    weight 1
  ]
  edge [
    source 308
    target 317
    kind "relation"
    relation "stretches when"
    weight 1
  ]
  edge [
    source 308
    target 318
    kind "relation"
    relation "tightens after"
    weight 1
  ]
  edge [
    source 310
    target 319
    kind "relation"
    relation "is bent when"
    weight 1
  ]
  edge [
    source 310
    target 324
    kind "mentions"
  ]
  edge [
    source 311
    target 320
    kind "relation"
    relation "is attached to"
    weight 1
  ]
  edge [
    source 311
    target 321
    kind "relation"
    relation "has other end attached to"
    weight 1
  ]
  edge [
    source 311
    target 322
    kind "relation"
    relation "contracts to"
    weight 2
  ]
  edge [
    source 311
    target 323
    kind "relation"
    relation "returns to original shape when"
    weight 2
  ]
  edge [
    source 311
    target 324
    kind "mentions"
  ]
  edge [
    source 311
    target 1164
    kind "mentions"
  ]
  edge [
    source 311
    target 945
    kind "relation"
    relation "makes"
    weight 1
  ]
  edge [
    source 311
    target 1302
    kind "mentions"
  ]
  edge [
    source 311
    target 1457
    kind "mentions"
  ]
  edge [
    source 311
    target 930
    kind "relation"
    relation "is made of"
    weight 2
  ]
  edge [
    source 311
    target 1462
    kind "mentions"
  ]
  edge [
    source 312
    target 316
    kind "relation"
    relation "helps to move"
    weight 1
  ]
  edge [
    source 312
    target 324
    kind "mentions"
  ]
  edge [
    source 312
    target 328
    kind "mentions"
  ]
  edge [
    source 313
    target 324
    kind "mentions"
  ]
  edge [
    source 314
    target 324
    kind "mentions"
  ]
  edge [
    source 314
    target 403
    kind "mentions"
  ]
  edge [
    source 314
    target 1467
    kind "mentions"
  ]
  edge [
    source 316
    target 319
    kind "relation"
    relation "stretches when"
    weight 2
  ]
  edge [
    source 316
    target 324
    kind "mentions"
  ]
  edge [
    source 316
    target 326
    kind "relation"
    relation "assists in"
    weight 1
  ]
  edge [
    source 319
    target 324
    kind "mentions"
  ]
  edge [
    source 322
    target 324
    kind "mentions"
  ]
  edge [
    source 323
    target 324
    kind "mentions"
  ]
  edge [
    source 324
    target 325
    kind "mentions"
  ]
  edge [
    source 324
    target 326
    kind "mentions"
  ]
  edge [
    source 324
    target 1958
    kind "summarizes"
  ]
  edge [
    source 327
    target 328
    kind "from_chunk"
  ]
  edge [
    source 327
    target 329
    kind "from_chunk"
  ]
  edge [
    source 327
    target 335
    kind "from_chunk"
  ]
  edge [
    source 328
    target 1944
    kind "summarizes"
  ]
  edge [
    source 329
    target 330
    kind "mentions"
  ]
  edge [
    source 329
    target 331
    kind "mentions"
  ]
  edge [
    source 329
    target 332
    kind "mentions"
  ]
  edge [
    source 329
    target 333
    kind "mentions"
  ]
  edge [
    source 329
    target 334
    kind "mentions"
  ]
  edge [
    source 329
    target 1939
    kind "summarizes"
  ]
  edge [
    source 330
    target 334
    kind "relation"
    relation "hold meat firmly"
    weight 1
  ]
  edge [
    source 333
    target 372
    kind "mentions"
  ]
  edge [
    source 333
    target 1129
    kind "mentions"
  ]
  edge [
    source 334
    target 1129
    kind "mentions"
  ]
  edge [
    source 334
    target 1132
    kind "relation"
    relation "include"
    weight 2
  ]
  edge [
    source 334
    target 1133
    kind "mentions"
  ]
  edge [
    source 334
    target 1112
    kind "relation"
    relation "is made from"
    weight 1
  ]
  edge [
    source 334
    target 1107
    kind "relation"
    relation "is made from"
    weight 1
  ]
  edge [
    source 334
    target 1102
    kind "relation"
    relation "is made from"
    weight 1
  ]
  edge [
    source 334
    target 1218
    kind "mentions"
  ]
  edge [
    source 334
    target 1215
    kind "relation"
    relation "provides"
    weight 1
  ]
  edge [
    source 334
    target 1252
    kind "mentions"
  ]
  edge [
    source 334
    target 1259
    kind "relation"
    relation "must be cooked before"
    weight 1
  ]
  edge [
    source 334
    target 1261
    kind "mentions"
  ]
  edge [
    source 334
    target 1127
    kind "relation"
    relation "must be cooked"
    weight 1
  ]
  edge [
    source 334
    target 1315
    kind "mentions"
  ]
  edge [
    source 334
    target 1326
    kind "mentions"
  ]
  edge [
    source 334
    target 602
    kind "relation"
    relation "is listed with"
    weight 1
  ]
  edge [
    source 335
    target 336
    kind "mentions"
  ]
  edge [
    source 335
    target 337
    kind "mentions"
  ]
  edge [
    source 335
    target 338
    kind "mentions"
  ]
  edge [
    source 335
    target 339
    kind "mentions"
  ]
  edge [
    source 335
    target 1944
    kind "summarizes"
  ]
  edge [
    source 336
    target 339
    kind "relation"
    relation "need to fly"
    weight 1
  ]
  edge [
    source 336
    target 338
    kind "relation"
    relation "has large and strong muscles | need strong muscles in"
    weight 2
  ]
  edge [
    source 336
    target 383
    kind "mentions"
  ]
  edge [
    source 338
    target 383
    kind "mentions"
  ]
  edge [
    source 340
    target 341
    kind "from_chunk"
  ]
  edge [
    source 340
    target 348
    kind "from_chunk"
  ]
  edge [
    source 340
    target 351
    kind "from_chunk"
  ]
  edge [
    source 340
    target 354
    kind "from_chunk"
  ]
  edge [
    source 340
    target 361
    kind "from_chunk"
  ]
  edge [
    source 340
    target 368
    kind "from_chunk"
  ]
  edge [
    source 340
    target 372
    kind "from_chunk"
  ]
  edge [
    source 341
    target 342
    kind "mentions"
  ]
  edge [
    source 341
    target 343
    kind "mentions"
  ]
  edge [
    source 341
    target 344
    kind "mentions"
  ]
  edge [
    source 341
    target 345
    kind "mentions"
  ]
  edge [
    source 341
    target 346
    kind "mentions"
  ]
  edge [
    source 341
    target 347
    kind "mentions"
  ]
  edge [
    source 341
    target 1953
    kind "summarizes"
  ]
  edge [
    source 344
    target 887
    kind "mentions"
  ]
  edge [
    source 344
    target 888
    kind "relation"
    relation "has a special function"
    weight 1
  ]
  edge [
    source 344
    target 1283
    kind "mentions"
  ]
  edge [
    source 345
    target 372
    kind "mentions"
  ]
  edge [
    source 345
    target 378
    kind "mentions"
  ]
  edge [
    source 345
    target 382
    kind "relation"
    relation "cannot work well"
    weight 1
  ]
  edge [
    source 345
    target 543
    kind "mentions"
  ]
  edge [
    source 345
    target 1055
    kind "mentions"
  ]
  edge [
    source 345
    target 1056
    kind "mentions"
  ]
  edge [
    source 345
    target 1057
    kind "mentions"
  ]
  edge [
    source 345
    target 1354
    kind "mentions"
  ]
  edge [
    source 345
    target 1361
    kind "mentions"
  ]
  edge [
    source 345
    target 1112
    kind "relation"
    relation "would have given"
    weight 2
  ]
  edge [
    source 345
    target 379
    kind "relation"
    relation "does not provide"
    weight 1
  ]
  edge [
    source 345
    target 1364
    kind "mentions"
  ]
  edge [
    source 345
    target 1496
    kind "mentions"
  ]
  edge [
    source 346
    target 347
    kind "relation"
    relation "make muscles strong by"
    weight 1
  ]
  edge [
    source 346
    target 652
    kind "mentions"
  ]
  edge [
    source 346
    target 657
    kind "relation"
    relation "make home-made wine from"
    weight 1
  ]
  edge [
    source 346
    target 655
    kind "relation"
    relation "believe there is no alcohol in"
    weight 1
  ]
  edge [
    source 346
    target 805
    kind "mentions"
  ]
  edge [
    source 346
    target 796
    kind "relation"
    relation "should not be eaten"
    weight 1
  ]
  edge [
    source 346
    target 795
    kind "relation"
    relation "should not be eaten"
    weight 1
  ]
  edge [
    source 346
    target 1072
    kind "mentions"
  ]
  edge [
    source 346
    target 601
    kind "relation"
    relation "need to drink"
    weight 1
  ]
  edge [
    source 346
    target 1421
    kind "mentions"
  ]
  edge [
    source 346
    target 1423
    kind "relation"
    relation "imagine they feel"
    weight 1
  ]
  edge [
    source 346
    target 1577
    kind "mentions"
  ]
  edge [
    source 346
    target 1580
    kind "relation"
    relation "are disliked by"
    weight 1
  ]
  edge [
    source 348
    target 349
    kind "mentions"
  ]
  edge [
    source 348
    target 350
    kind "mentions"
  ]
  edge [
    source 348
    target 1944
    kind "summarizes"
  ]
  edge [
    source 349
    target 383
    kind "mentions"
  ]
  edge [
    source 349
    target 388
    kind "relation"
    relation "has strong arm muscles"
    weight 1
  ]
  edge [
    source 351
    target 352
    kind "mentions"
  ]
  edge [
    source 351
    target 353
    kind "mentions"
  ]
  edge [
    source 351
    target 1945
    kind "summarizes"
  ]
  edge [
    source 352
    target 353
    kind "relation"
    relation "helps muscles to"
    weight 1
  ]
  edge [
    source 354
    target 355
    kind "mentions"
  ]
  edge [
    source 354
    target 356
    kind "mentions"
  ]
  edge [
    source 354
    target 357
    kind "mentions"
  ]
  edge [
    source 354
    target 358
    kind "mentions"
  ]
  edge [
    source 354
    target 359
    kind "mentions"
  ]
  edge [
    source 354
    target 360
    kind "mentions"
  ]
  edge [
    source 354
    target 1944
    kind "summarizes"
  ]
  edge [
    source 355
    target 356
    kind "relation"
    relation "was active before | could hardly walk after | preferred to sit after | had to make new muscles as fast as possible after"
    weight 4
  ]
  edge [
    source 355
    target 361
    kind "mentions"
  ]
  edge [
    source 356
    target 361
    kind "mentions"
  ]
  edge [
    source 356
    target 490
    kind "mentions"
  ]
  edge [
    source 356
    target 502
    kind "relation"
    relation "reduces ability to bear | reduces likelihood of recovery"
    weight 2
  ]
  edge [
    source 356
    target 569
    kind "mentions"
  ]
  edge [
    source 356
    target 397
    kind "relation"
    relation "makes it harder for"
    weight 1
  ]
  edge [
    source 356
    target 392
    kind "relation"
    relation "makes it harder for"
    weight 1
  ]
  edge [
    source 356
    target 850
    kind "mentions"
  ]
  edge [
    source 356
    target 853
    kind "relation"
    relation "is the body's way of saying"
    weight 1
  ]
  edge [
    source 357
    target 361
    kind "mentions"
  ]
  edge [
    source 357
    target 1450
    kind "mentions"
  ]
  edge [
    source 357
    target 1454
    kind "relation"
    relation "causes feeling of"
    weight 1
  ]
  edge [
    source 357
    target 1514
    kind "mentions"
  ]
  edge [
    source 361
    target 362
    kind "mentions"
  ]
  edge [
    source 361
    target 363
    kind "mentions"
  ]
  edge [
    source 361
    target 364
    kind "mentions"
  ]
  edge [
    source 361
    target 365
    kind "mentions"
  ]
  edge [
    source 361
    target 366
    kind "mentions"
  ]
  edge [
    source 361
    target 367
    kind "mentions"
  ]
  edge [
    source 361
    target 1944
    kind "summarizes"
  ]
  edge [
    source 368
    target 369
    kind "mentions"
  ]
  edge [
    source 368
    target 370
    kind "mentions"
  ]
  edge [
    source 368
    target 371
    kind "mentions"
  ]
  edge [
    source 368
    target 1944
    kind "summarizes"
  ]
  edge [
    source 369
    target 371
    kind "relation"
    relation "make"
    weight 1
  ]
  edge [
    source 372
    target 373
    kind "mentions"
  ]
  edge [
    source 372
    target 374
    kind "mentions"
  ]
  edge [
    source 372
    target 375
    kind "mentions"
  ]
  edge [
    source 372
    target 376
    kind "mentions"
  ]
  edge [
    source 372
    target 1945
    kind "summarizes"
  ]
  edge [
    source 373
    target 374
    kind "relation"
    relation "cannot work joints"
    weight 1
  ]
  edge [
    source 373
    target 1161
    kind "mentions"
  ]
  edge [
    source 373
    target 375
    kind "relation"
    relation "makes"
    weight 1
  ]
  edge [
    source 373
    target 1166
    kind "mentions"
  ]
  edge [
    source 373
    target 1172
    kind "relation"
    relation "comes from"
    weight 1
  ]
  edge [
    source 374
    target 383
    kind "mentions"
  ]
  edge [
    source 374
    target 384
    kind "relation"
    relation "include inquiries about"
    weight 1
  ]
  edge [
    source 374
    target 391
    kind "mentions"
  ]
  edge [
    source 375
    target 378
    kind "mentions"
  ]
  edge [
    source 375
    target 380
    kind "relation"
    relation "reduces"
    weight 1
  ]
  edge [
    source 375
    target 1136
    kind "mentions"
  ]
  edge [
    source 375
    target 1137
    kind "relation"
    relation "provides"
    weight 1
  ]
  edge [
    source 375
    target 1138
    kind "relation"
    relation "provides"
    weight 1
  ]
  edge [
    source 375
    target 532
    kind "relation"
    relation "keeps"
    weight 1
  ]
  edge [
    source 375
    target 1018
    kind "relation"
    relation "makes"
    weight 1
  ]
  edge [
    source 375
    target 1142
    kind "relation"
    relation "has right and wrong places"
    weight 1
  ]
  edge [
    source 375
    target 1144
    kind "mentions"
  ]
  edge [
    source 375
    target 1158
    kind "mentions"
  ]
  edge [
    source 375
    target 1161
    kind "mentions"
  ]
  edge [
    source 375
    target 602
    kind "relation"
    relation "makes"
    weight 1
  ]
  edge [
    source 375
    target 697
    kind "relation"
    relation "makes"
    weight 1
  ]
  edge [
    source 375
    target 1162
    kind "relation"
    relation "makes"
    weight 1
  ]
  edge [
    source 375
    target 1163
    kind "relation"
    relation "makes"
    weight 1
  ]
  edge [
    source 375
    target 1159
    kind "relation"
    relation "makes"
    weight 1
  ]
  edge [
    source 375
    target 1164
    kind "mentions"
  ]
  edge [
    source 375
    target 945
    kind "relation"
    relation "makes"
    weight 1
  ]
  edge [
    source 375
    target 1220
    kind "mentions"
  ]
  edge [
    source 375
    target 1221
    kind "relation"
    relation "is needed for"
    weight 1
  ]
  edge [
    source 375
    target 1222
    kind "relation"
    relation "provides"
    weight 1
  ]
  edge [
    source 375
    target 1224
    kind "relation"
    relation "helps absorb"
    weight 1
  ]
  edge [
    source 375
    target 1326
    kind "mentions"
  ]
  edge [
    source 375
    target 527
    kind "relation"
    relation "provides | is used for"
    weight 2
  ]
  edge [
    source 375
    target 1160
    kind "relation"
    relation "is listed with"
    weight 2
  ]
  edge [
    source 375
    target 1131
    kind "relation"
    relation "is listed with"
    weight 1
  ]
  edge [
    source 377
    target 378
    kind "from_chunk"
  ]
  edge [
    source 377
    target 383
    kind "from_chunk"
  ]
  edge [
    source 377
    target 391
    kind "from_chunk"
  ]
  edge [
    source 378
    target 379
    kind "mentions"
  ]
  edge [
    source 378
    target 380
    kind "mentions"
  ]
  edge [
    source 378
    target 381
    kind "mentions"
  ]
  edge [
    source 378
    target 382
    kind "mentions"
  ]
  edge [
    source 378
    target 1945
    kind "summarizes"
  ]
  edge [
    source 379
    target 381
    kind "relation"
    relation "become fleshy"
    weight 1
  ]
  edge [
    source 379
    target 730
    kind "mentions"
  ]
  edge [
    source 379
    target 715
    kind "relation"
    relation "is made into"
    weight 1
  ]
  edge [
    source 379
    target 734
    kind "mentions"
  ]
  edge [
    source 379
    target 735
    kind "relation"
    relation "drinks"
    weight 1
  ]
  edge [
    source 379
    target 736
    kind "relation"
    relation "does not allow"
    weight 1
  ]
  edge [
    source 379
    target 753
    kind "mentions"
  ]
  edge [
    source 379
    target 776
    kind "mentions"
  ]
  edge [
    source 379
    target 777
    kind "relation"
    relation "can make"
    weight 1
  ]
  edge [
    source 379
    target 788
    kind "mentions"
  ]
  edge [
    source 379
    target 798
    kind "mentions"
  ]
  edge [
    source 379
    target 648
    kind "relation"
    relation "leads to"
    weight 1
  ]
  edge [
    source 379
    target 757
    kind "relation"
    relation "leads to"
    weight 1
  ]
  edge [
    source 379
    target 1328
    kind "mentions"
  ]
  edge [
    source 379
    target 1330
    kind "relation"
    relation "was not included on"
    weight 1
  ]
  edge [
    source 379
    target 1361
    kind "mentions"
  ]
  edge [
    source 379
    target 1364
    kind "mentions"
  ]
  edge [
    source 379
    target 1373
    kind "relation"
    relation "does not give"
    weight 1
  ]
  edge [
    source 379
    target 1421
    kind "mentions"
  ]
  edge [
    source 379
    target 1422
    kind "relation"
    relation "is a type of"
    weight 1
  ]
  edge [
    source 383
    target 384
    kind "mentions"
  ]
  edge [
    source 383
    target 385
    kind "mentions"
  ]
  edge [
    source 383
    target 386
    kind "mentions"
  ]
  edge [
    source 383
    target 387
    kind "mentions"
  ]
  edge [
    source 383
    target 388
    kind "mentions"
  ]
  edge [
    source 383
    target 389
    kind "mentions"
  ]
  edge [
    source 383
    target 390
    kind "mentions"
  ]
  edge [
    source 383
    target 1944
    kind "summarizes"
  ]
  edge [
    source 384
    target 1025
    kind "mentions"
  ]
  edge [
    source 384
    target 1315
    kind "mentions"
  ]
  edge [
    source 384
    target 1316
    kind "relation"
    relation "ask about"
    weight 1
  ]
  edge [
    source 384
    target 1317
    kind "relation"
    relation "ask about"
    weight 1
  ]
  edge [
    source 384
    target 1922
    kind "mentions"
  ]
  edge [
    source 384
    target 1931
    kind "relation"
    relation "include"
    weight 1
  ]
  edge [
    source 384
    target 1932
    kind "relation"
    relation "include"
    weight 1
  ]
  edge [
    source 384
    target 1933
    kind "relation"
    relation "include"
    weight 1
  ]
  edge [
    source 384
    target 1934
    kind "relation"
    relation "include"
    weight 1
  ]
  edge [
    source 384
    target 1935
    kind "relation"
    relation "include"
    weight 1
  ]
  edge [
    source 384
    target 1936
    kind "relation"
    relation "include"
    weight 1
  ]
  edge [
    source 384
    target 1937
    kind "relation"
    relation "include"
    weight 1
  ]
  edge [
    source 390
    target 543
    kind "mentions"
  ]
  edge [
    source 390
    target 397
    kind "relation"
    relation "must be kept strong and well by"
    weight 1
  ]
  edge [
    source 390
    target 1335
    kind "mentions"
  ]
  edge [
    source 390
    target 1450
    kind "mentions"
  ]
  edge [
    source 390
    target 1795
    kind "mentions"
  ]
  edge [
    source 390
    target 1758
    kind "relation"
    relation "promotes"
    weight 1
  ]
  edge [
    source 391
    target 392
    kind "mentions"
  ]
  edge [
    source 391
    target 393
    kind "mentions"
  ]
  edge [
    source 391
    target 394
    kind "mentions"
  ]
  edge [
    source 391
    target 1942
    kind "summarizes"
  ]
  edge [
    source 392
    target 393
    kind "relation"
    relation "function like"
    weight 1
  ]
  edge [
    source 392
    target 394
    kind "relation"
    relation "control"
    weight 1
  ]
  edge [
    source 392
    target 400
    kind "mentions"
  ]
  edge [
    source 392
    target 397
    kind "relation"
    relation "connect | send no message to"
    weight 2
  ]
  edge [
    source 392
    target 401
    kind "relation"
    relation "is a large nerve | has many nerves branching off"
    weight 2
  ]
  edge [
    source 392
    target 428
    kind "mentions"
  ]
  edge [
    source 392
    target 438
    kind "relation"
    relation "consist of"
    weight 1
  ]
  edge [
    source 392
    target 442
    kind "relation"
    relation "carry"
    weight 1
  ]
  edge [
    source 392
    target 434
    kind "relation"
    relation "enable | give us"
    weight 2
  ]
  edge [
    source 392
    target 435
    kind "relation"
    relation "enable | give us"
    weight 2
  ]
  edge [
    source 392
    target 430
    kind "relation"
    relation "could not ache without"
    weight 1
  ]
  edge [
    source 392
    target 431
    kind "relation"
    relation "could not taste food without"
    weight 1
  ]
  edge [
    source 392
    target 432
    kind "relation"
    relation "could not taste food without"
    weight 1
  ]
  edge [
    source 392
    target 433
    kind "relation"
    relation "might not feel pain without"
    weight 1
  ]
  edge [
    source 392
    target 455
    kind "mentions"
  ]
  edge [
    source 392
    target 465
    kind "relation"
    relation "get tired from"
    weight 1
  ]
  edge [
    source 392
    target 466
    kind "relation"
    relation "are rested by"
    weight 1
  ]
  edge [
    source 392
    target 467
    kind "mentions"
  ]
  edge [
    source 392
    target 490
    kind "mentions"
  ]
  edge [
    source 392
    target 506
    kind "mentions"
  ]
  edge [
    source 392
    target 514
    kind "mentions"
  ]
  edge [
    source 392
    target 525
    kind "mentions"
  ]
  edge [
    source 392
    target 530
    kind "mentions"
  ]
  edge [
    source 392
    target 546
    kind "mentions"
  ]
  edge [
    source 392
    target 565
    kind "mentions"
  ]
  edge [
    source 392
    target 566
    kind "relation"
    relation "damages"
    weight 1
  ]
  edge [
    source 392
    target 569
    kind "mentions"
  ]
  edge [
    source 392
    target 866
    kind "mentions"
  ]
  edge [
    source 392
    target 1364
    kind "mentions"
  ]
  edge [
    source 392
    target 1377
    kind "relation"
    relation "cannot sense"
    weight 1
  ]
  edge [
    source 392
    target 1378
    kind "relation"
    relation "cannot sense"
    weight 1
  ]
  edge [
    source 392
    target 1403
    kind "mentions"
  ]
  edge [
    source 392
    target 1448
    kind "mentions"
  ]
  edge [
    source 392
    target 1462
    kind "mentions"
  ]
  edge [
    source 392
    target 1449
    kind "relation"
    relation "leads to loss of"
    weight 1
  ]
  edge [
    source 392
    target 1514
    kind "mentions"
  ]
  edge [
    source 392
    target 1527
    kind "mentions"
  ]
  edge [
    source 392
    target 1520
    kind "relation"
    relation "control"
    weight 1
  ]
  edge [
    source 392
    target 891
    kind "relation"
    relation "control"
    weight 1
  ]
  edge [
    source 392
    target 930
    kind "relation"
    relation "control"
    weight 1
  ]
  edge [
    source 392
    target 1541
    kind "mentions"
  ]
  edge [
    source 392
    target 1628
    kind "mentions"
  ]
  edge [
    source 392
    target 1716
    kind "mentions"
  ]
  edge [
    source 392
    target 531
    kind "relation"
    relation "are responsible for"
    weight 1
  ]
  edge [
    source 392
    target 713
    kind "relation"
    relation "are responsible for"
    weight 1
  ]
  edge [
    source 392
    target 1718
    kind "relation"
    relation "are responsible for"
    weight 1
  ]
  edge [
    source 392
    target 1719
    kind "relation"
    relation "are responsible for"
    weight 1
  ]
  edge [
    source 392
    target 1720
    kind "relation"
    relation "are responsible for"
    weight 1
  ]
  edge [
    source 392
    target 1819
    kind "mentions"
  ]
  edge [
    source 392
    target 640
    kind "relation"
    relation "may not realize they are getting colder"
    weight 1
  ]
  edge [
    source 395
    target 396
    kind "from_chunk"
  ]
  edge [
    source 395
    target 400
    kind "from_chunk"
  ]
  edge [
    source 395
    target 403
    kind "from_chunk"
  ]
  edge [
    source 396
    target 397
    kind "mentions"
  ]
  edge [
    source 396
    target 398
    kind "mentions"
  ]
  edge [
    source 396
    target 399
    kind "mentions"
  ]
  edge [
    source 396
    target 1946
    kind "summarizes"
  ]
  edge [
    source 397
    target 399
    kind "relation"
    relation "is called"
    weight 1
  ]
  edge [
    source 397
    target 400
    kind "mentions"
  ]
  edge [
    source 397
    target 403
    kind "mentions"
  ]
  edge [
    source 397
    target 406
    kind "relation"
    relation "transmits message to"
    weight 1
  ]
  edge [
    source 397
    target 410
    kind "relation"
    relation "receives warning that"
    weight 1
  ]
  edge [
    source 397
    target 413
    kind "mentions"
  ]
  edge [
    source 397
    target 414
    kind "mentions"
  ]
  edge [
    source 397
    target 418
    kind "mentions"
  ]
  edge [
    source 397
    target 421
    kind "mentions"
  ]
  edge [
    source 397
    target 422
    kind "relation"
    relation "sends messages to"
    weight 1
  ]
  edge [
    source 397
    target 455
    kind "mentions"
  ]
  edge [
    source 397
    target 429
    kind "relation"
    relation "keeps all organs working"
    weight 1
  ]
  edge [
    source 397
    target 464
    kind "relation"
    relation "cannot go to sleep"
    weight 1
  ]
  edge [
    source 397
    target 459
    kind "relation"
    relation "functions for"
    weight 1
  ]
  edge [
    source 397
    target 467
    kind "mentions"
  ]
  edge [
    source 397
    target 469
    kind "mentions"
  ]
  edge [
    source 397
    target 470
    kind "relation"
    relation "requires proper food to function well"
    weight 1
  ]
  edge [
    source 397
    target 487
    kind "mentions"
  ]
  edge [
    source 397
    target 490
    kind "mentions"
  ]
  edge [
    source 397
    target 535
    kind "mentions"
  ]
  edge [
    source 397
    target 450
    kind "relation"
    relation "has the most work to do"
    weight 1
  ]
  edge [
    source 397
    target 540
    kind "relation"
    relation "processes | cannot process"
    weight 2
  ]
  edge [
    source 397
    target 541
    kind "relation"
    relation "controls"
    weight 1
  ]
  edge [
    source 397
    target 542
    kind "relation"
    relation "manages"
    weight 1
  ]
  edge [
    source 397
    target 543
    kind "mentions"
  ]
  edge [
    source 397
    target 457
    kind "relation"
    relation "must be kept strong and well by"
    weight 1
  ]
  edge [
    source 397
    target 544
    kind "relation"
    relation "must be kept strong and well by"
    weight 1
  ]
  edge [
    source 397
    target 545
    kind "relation"
    relation "should be avoided to keep"
    weight 1
  ]
  edge [
    source 397
    target 546
    kind "mentions"
  ]
  edge [
    source 397
    target 553
    kind "mentions"
  ]
  edge [
    source 397
    target 557
    kind "relation"
    relation "cannot make"
    weight 1
  ]
  edge [
    source 397
    target 565
    kind "mentions"
  ]
  edge [
    source 397
    target 566
    kind "relation"
    relation "damages"
    weight 1
  ]
  edge [
    source 397
    target 569
    kind "mentions"
  ]
  edge [
    source 397
    target 584
    kind "mentions"
  ]
  edge [
    source 397
    target 585
    kind "relation"
    relation "are in"
    weight 1
  ]
  edge [
    source 397
    target 1302
    kind "mentions"
  ]
  edge [
    source 397
    target 1354
    kind "mentions"
  ]
  edge [
    source 397
    target 1364
    kind "mentions"
  ]
  edge [
    source 397
    target 1403
    kind "mentions"
  ]
  edge [
    source 397
    target 1435
    kind "mentions"
  ]
  edge [
    source 397
    target 1443
    kind "relation"
    relation "needs very pure blood to | requires very pure blood to"
    weight 2
  ]
  edge [
    source 397
    target 1178
    kind "relation"
    relation "needs a great deal of"
    weight 1
  ]
  edge [
    source 397
    target 1446
    kind "mentions"
  ]
  edge [
    source 397
    target 1448
    kind "mentions"
  ]
  edge [
    source 397
    target 1449
    kind "relation"
    relation "causes loss of"
    weight 1
  ]
  edge [
    source 397
    target 1650
    kind "mentions"
  ]
  edge [
    source 397
    target 1689
    kind "mentions"
  ]
  edge [
    source 397
    target 1694
    kind "relation"
    relation "sends account of each sound to"
    weight 1
  ]
  edge [
    source 397
    target 1724
    kind "mentions"
  ]
  edge [
    source 397
    target 1728
    kind "relation"
    relation "transmits visual information to"
    weight 1
  ]
  edge [
    source 397
    target 1819
    kind "mentions"
  ]
  edge [
    source 398
    target 1403
    kind "mentions"
  ]
  edge [
    source 400
    target 401
    kind "mentions"
  ]
  edge [
    source 400
    target 402
    kind "mentions"
  ]
  edge [
    source 400
    target 1942
    kind "summarizes"
  ]
  edge [
    source 403
    target 404
    kind "mentions"
  ]
  edge [
    source 403
    target 405
    kind "mentions"
  ]
  edge [
    source 403
    target 406
    kind "mentions"
  ]
  edge [
    source 403
    target 407
    kind "mentions"
  ]
  edge [
    source 403
    target 408
    kind "mentions"
  ]
  edge [
    source 403
    target 409
    kind "mentions"
  ]
  edge [
    source 403
    target 410
    kind "mentions"
  ]
  edge [
    source 403
    target 411
    kind "mentions"
  ]
  edge [
    source 403
    target 1946
    kind "summarizes"
  ]
  edge [
    source 404
    target 405
    kind "relation"
    relation "is placed on | causes"
    weight 2
  ]
  edge [
    source 404
    target 406
    kind "relation"
    relation "sends a message via"
    weight 1
  ]
  edge [
    source 404
    target 411
    kind "relation"
    relation "will be burned if"
    weight 1
  ]
  edge [
    source 404
    target 413
    kind "mentions"
  ]
  edge [
    source 405
    target 413
    kind "mentions"
  ]
  edge [
    source 406
    target 900
    kind "mentions"
  ]
  edge [
    source 406
    target 894
    kind "relation"
    relation "have a nerve that feels pain quickly"
    weight 1
  ]
  edge [
    source 406
    target 1354
    kind "mentions"
  ]
  edge [
    source 412
    target 413
    kind "from_chunk"
  ]
  edge [
    source 412
    target 414
    kind "from_chunk"
  ]
  edge [
    source 412
    target 418
    kind "from_chunk"
  ]
  edge [
    source 412
    target 421
    kind "from_chunk"
  ]
  edge [
    source 412
    target 424
    kind "from_chunk"
  ]
  edge [
    source 413
    target 1946
    kind "summarizes"
  ]
  edge [
    source 414
    target 415
    kind "mentions"
  ]
  edge [
    source 414
    target 416
    kind "mentions"
  ]
  edge [
    source 414
    target 417
    kind "mentions"
  ]
  edge [
    source 414
    target 1938
    kind "summarizes"
  ]
  edge [
    source 415
    target 417
    kind "relation"
    relation "is equivalent to"
    weight 1
  ]
  edge [
    source 418
    target 419
    kind "mentions"
  ]
  edge [
    source 418
    target 420
    kind "mentions"
  ]
  edge [
    source 418
    target 1938
    kind "summarizes"
  ]
  edge [
    source 419
    target 925
    kind "mentions"
  ]
  edge [
    source 419
    target 928
    kind "mentions"
  ]
  edge [
    source 419
    target 930
    kind "relation"
    relation "contains | is located in | is placed in"
    weight 3
  ]
  edge [
    source 419
    target 1025
    kind "mentions"
  ]
  edge [
    source 419
    target 1044
    kind "relation"
    relation "contains"
    weight 1
  ]
  edge [
    source 419
    target 1427
    kind "mentions"
  ]
  edge [
    source 419
    target 1462
    kind "mentions"
  ]
  edge [
    source 419
    target 1467
    kind "mentions"
  ]
  edge [
    source 419
    target 1527
    kind "mentions"
  ]
  edge [
    source 421
    target 422
    kind "mentions"
  ]
  edge [
    source 421
    target 423
    kind "mentions"
  ]
  edge [
    source 421
    target 1938
    kind "summarizes"
  ]
  edge [
    source 423
    target 469
    kind "mentions"
  ]
  edge [
    source 424
    target 425
    kind "mentions"
  ]
  edge [
    source 424
    target 426
    kind "mentions"
  ]
  edge [
    source 424
    target 1947
    kind "summarizes"
  ]
  edge [
    source 425
    target 426
    kind "relation"
    relation "performs"
    weight 1
  ]
  edge [
    source 427
    target 428
    kind "from_chunk"
  ]
  edge [
    source 427
    target 443
    kind "from_chunk"
  ]
  edge [
    source 427
    target 449
    kind "from_chunk"
  ]
  edge [
    source 428
    target 429
    kind "mentions"
  ]
  edge [
    source 428
    target 430
    kind "mentions"
  ]
  edge [
    source 428
    target 431
    kind "mentions"
  ]
  edge [
    source 428
    target 432
    kind "mentions"
  ]
  edge [
    source 428
    target 433
    kind "mentions"
  ]
  edge [
    source 428
    target 434
    kind "mentions"
  ]
  edge [
    source 428
    target 435
    kind "mentions"
  ]
  edge [
    source 428
    target 436
    kind "mentions"
  ]
  edge [
    source 428
    target 437
    kind "mentions"
  ]
  edge [
    source 428
    target 438
    kind "mentions"
  ]
  edge [
    source 428
    target 439
    kind "mentions"
  ]
  edge [
    source 428
    target 440
    kind "mentions"
  ]
  edge [
    source 428
    target 441
    kind "mentions"
  ]
  edge [
    source 428
    target 442
    kind "mentions"
  ]
  edge [
    source 428
    target 1942
    kind "summarizes"
  ]
  edge [
    source 429
    target 455
    kind "mentions"
  ]
  edge [
    source 429
    target 1025
    kind "mentions"
  ]
  edge [
    source 429
    target 1071
    kind "mentions"
  ]
  edge [
    source 429
    target 470
    kind "relation"
    relation "partly prepare"
    weight 1
  ]
  edge [
    source 431
    target 1006
    kind "mentions"
  ]
  edge [
    source 431
    target 1062
    kind "mentions"
  ]
  edge [
    source 431
    target 1064
    kind "relation"
    relation "occur in"
    weight 1
  ]
  edge [
    source 431
    target 1065
    kind "mentions"
  ]
  edge [
    source 431
    target 1261
    kind "mentions"
  ]
  edge [
    source 431
    target 1127
    kind "relation"
    relation "prepares"
    weight 1
  ]
  edge [
    source 431
    target 1278
    kind "mentions"
  ]
  edge [
    source 431
    target 1514
    kind "mentions"
  ]
  edge [
    source 431
    target 1523
    kind "relation"
    relation "is closed during"
    weight 1
  ]
  edge [
    source 431
    target 1529
    kind "mentions"
  ]
  edge [
    source 431
    target 1756
    kind "mentions"
  ]
  edge [
    source 431
    target 883
    kind "relation"
    relation "puts cold fingers into"
    weight 1
  ]
  edge [
    source 433
    target 437
    kind "relation"
    relation "has a warm, soft hand"
    weight 1
  ]
  edge [
    source 434
    target 525
    kind "mentions"
  ]
  edge [
    source 434
    target 526
    kind "relation"
    relation "causes"
    weight 1
  ]
  edge [
    source 434
    target 527
    kind "relation"
    relation "causes"
    weight 1
  ]
  edge [
    source 434
    target 508
    kind "relation"
    relation "causes"
    weight 1
  ]
  edge [
    source 434
    target 528
    kind "relation"
    relation "causes"
    weight 1
  ]
  edge [
    source 434
    target 529
    kind "relation"
    relation "causes"
    weight 1
  ]
  edge [
    source 435
    target 530
    kind "mentions"
  ]
  edge [
    source 435
    target 531
    kind "relation"
    relation "causes"
    weight 1
  ]
  edge [
    source 435
    target 532
    kind "relation"
    relation "causes"
    weight 1
  ]
  edge [
    source 435
    target 533
    kind "relation"
    relation "cause"
    weight 1
  ]
  edge [
    source 435
    target 534
    kind "relation"
    relation "cause"
    weight 1
  ]
  edge [
    source 438
    target 439
    kind "relation"
    relation "form"
    weight 1
  ]
  edge [
    source 440
    target 441
    kind "relation"
    relation "travels on"
    weight 1
  ]
  edge [
    source 443
    target 444
    kind "mentions"
  ]
  edge [
    source 443
    target 445
    kind "mentions"
  ]
  edge [
    source 443
    target 446
    kind "mentions"
  ]
  edge [
    source 443
    target 447
    kind "mentions"
  ]
  edge [
    source 443
    target 448
    kind "mentions"
  ]
  edge [
    source 443
    target 1950
    kind "summarizes"
  ]
  edge [
    source 444
    target 446
    kind "relation"
    relation "become responsible for"
    weight 1
  ]
  edge [
    source 449
    target 450
    kind "mentions"
  ]
  edge [
    source 449
    target 451
    kind "mentions"
  ]
  edge [
    source 449
    target 452
    kind "mentions"
  ]
  edge [
    source 449
    target 453
    kind "mentions"
  ]
  edge [
    source 449
    target 1947
    kind "summarizes"
  ]
  edge [
    source 450
    target 453
    kind "relation"
    relation "perform work that helps"
    weight 1
  ]
  edge [
    source 450
    target 535
    kind "mentions"
  ]
  edge [
    source 450
    target 988
    kind "mentions"
  ]
  edge [
    source 450
    target 991
    kind "relation"
    relation "wear out slightly | require repair using food"
    weight 2
  ]
  edge [
    source 450
    target 1302
    kind "mentions"
  ]
  edge [
    source 450
    target 1305
    kind "relation"
    relation "are formed from"
    weight 1
  ]
  edge [
    source 454
    target 455
    kind "from_chunk"
  ]
  edge [
    source 454
    target 467
    kind "from_chunk"
  ]
  edge [
    source 455
    target 456
    kind "mentions"
  ]
  edge [
    source 455
    target 457
    kind "mentions"
  ]
  edge [
    source 455
    target 458
    kind "mentions"
  ]
  edge [
    source 455
    target 459
    kind "mentions"
  ]
  edge [
    source 455
    target 460
    kind "mentions"
  ]
  edge [
    source 455
    target 461
    kind "mentions"
  ]
  edge [
    source 455
    target 462
    kind "mentions"
  ]
  edge [
    source 455
    target 463
    kind "mentions"
  ]
  edge [
    source 455
    target 464
    kind "mentions"
  ]
  edge [
    source 455
    target 465
    kind "mentions"
  ]
  edge [
    source 455
    target 466
    kind "mentions"
  ]
  edge [
    source 455
    target 1942
    kind "summarizes"
  ]
  edge [
    source 456
    target 460
    kind "relation"
    relation "needs rest"
    weight 1
  ]
  edge [
    source 456
    target 461
    kind "relation"
    relation "wears out if"
    weight 1
  ]
  edge [
    source 457
    target 543
    kind "mentions"
  ]
  edge [
    source 457
    target 1529
    kind "mentions"
  ]
  edge [
    source 458
    target 992
    kind "mentions"
  ]
  edge [
    source 462
    target 463
    kind "relation"
    relation "is hard to repair"
    weight 1
  ]
  edge [
    source 467
    target 1942
    kind "summarizes"
  ]
  edge [
    source 468
    target 469
    kind "from_chunk"
  ]
  edge [
    source 468
    target 473
    kind "from_chunk"
  ]
  edge [
    source 468
    target 487
    kind "from_chunk"
  ]
  edge [
    source 469
    target 470
    kind "mentions"
  ]
  edge [
    source 469
    target 471
    kind "mentions"
  ]
  edge [
    source 469
    target 472
    kind "mentions"
  ]
  edge [
    source 469
    target 1938
    kind "summarizes"
  ]
  edge [
    source 470
    target 730
    kind "mentions"
  ]
  edge [
    source 470
    target 887
    kind "mentions"
  ]
  edge [
    source 470
    target 891
    kind "relation"
    relation "takes care of | is mixed and prepared in | is broken down in | is swallowed in a hurry"
    weight 4
  ]
  edge [
    source 470
    target 893
    kind "mentions"
  ]
  edge [
    source 470
    target 895
    kind "relation"
    relation "cut"
    weight 1
  ]
  edge [
    source 470
    target 896
    kind "relation"
    relation "grind"
    weight 1
  ]
  edge [
    source 470
    target 960
    kind "mentions"
  ]
  edge [
    source 470
    target 965
    kind "mentions"
  ]
  edge [
    source 470
    target 966
    kind "relation"
    relation "transform"
    weight 1
  ]
  edge [
    source 470
    target 968
    kind "mentions"
  ]
  edge [
    source 470
    target 977
    kind "relation"
    relation "must be changed"
    weight 1
  ]
  edge [
    source 470
    target 978
    kind "mentions"
  ]
  edge [
    source 470
    target 980
    kind "relation"
    relation "is carried to"
    weight 1
  ]
  edge [
    source 470
    target 981
    kind "relation"
    relation "is carried to"
    weight 1
  ]
  edge [
    source 470
    target 982
    kind "relation"
    relation "is carried to"
    weight 1
  ]
  edge [
    source 470
    target 983
    kind "relation"
    relation "is carried to"
    weight 1
  ]
  edge [
    source 470
    target 984
    kind "relation"
    relation "is carried to"
    weight 1
  ]
  edge [
    source 470
    target 988
    kind "mentions"
  ]
  edge [
    source 470
    target 1001
    kind "mentions"
  ]
  edge [
    source 470
    target 939
    kind "relation"
    relation "cannot mix with"
    weight 1
  ]
  edge [
    source 470
    target 1025
    kind "mentions"
  ]
  edge [
    source 470
    target 1053
    kind "relation"
    relation "is needed for"
    weight 1
  ]
  edge [
    source 470
    target 1055
    kind "mentions"
  ]
  edge [
    source 470
    target 1056
    kind "mentions"
  ]
  edge [
    source 470
    target 1057
    kind "mentions"
  ]
  edge [
    source 470
    target 1059
    kind "mentions"
  ]
  edge [
    source 470
    target 1007
    kind "relation"
    relation "moistens | moistens and mixes with | should be eaten slowly and chewed well | mixes with | must be chewed and mixed with"
    weight 5
  ]
  edge [
    source 470
    target 1071
    kind "mentions"
  ]
  edge [
    source 470
    target 931
    kind "relation"
    relation "partly prepares"
    weight 1
  ]
  edge [
    source 470
    target 1126
    kind "mentions"
  ]
  edge [
    source 470
    target 1109
    kind "relation"
    relation "need salt mixed with | get a little salt from"
    weight 2
  ]
  edge [
    source 470
    target 946
    kind "relation"
    relation "is present in | is used in"
    weight 2
  ]
  edge [
    source 470
    target 1212
    kind "mentions"
  ]
  edge [
    source 470
    target 1248
    kind "mentions"
  ]
  edge [
    source 470
    target 1249
    kind "relation"
    relation "is absorbed in"
    weight 1
  ]
  edge [
    source 470
    target 1278
    kind "mentions"
  ]
  edge [
    source 470
    target 1283
    kind "mentions"
  ]
  edge [
    source 470
    target 697
    kind "relation"
    relation "may not be changed"
    weight 1
  ]
  edge [
    source 470
    target 1286
    kind "mentions"
  ]
  edge [
    source 470
    target 1293
    kind "mentions"
  ]
  edge [
    source 470
    target 1298
    kind "mentions"
  ]
  edge [
    source 470
    target 1299
    kind "relation"
    relation "slips into"
    weight 1
  ]
  edge [
    source 470
    target 1294
    kind "relation"
    relation "tries to force back | cannot force back"
    weight 2
  ]
  edge [
    source 470
    target 1302
    kind "mentions"
  ]
  edge [
    source 470
    target 995
    kind "relation"
    relation "is transformed into"
    weight 1
  ]
  edge [
    source 470
    target 1315
    kind "mentions"
  ]
  edge [
    source 470
    target 1382
    kind "mentions"
  ]
  edge [
    source 470
    target 1435
    kind "mentions"
  ]
  edge [
    source 470
    target 1462
    kind "mentions"
  ]
  edge [
    source 470
    target 1464
    kind "relation"
    relation "reaches body parts through"
    weight 1
  ]
  edge [
    source 470
    target 1529
    kind "mentions"
  ]
  edge [
    source 470
    target 1178
    kind "relation"
    relation "carries"
    weight 1
  ]
  edge [
    source 471
    target 659
    kind "mentions"
  ]
  edge [
    source 471
    target 753
    kind "mentions"
  ]
  edge [
    source 471
    target 774
    kind "relation"
    relation "increases danger"
    weight 1
  ]
  edge [
    source 471
    target 791
    kind "mentions"
  ]
  edge [
    source 471
    target 850
    kind "mentions"
  ]
  edge [
    source 471
    target 851
    kind "relation"
    relation "experience sickness when playing with"
    weight 1
  ]
  edge [
    source 471
    target 859
    kind "mentions"
  ]
  edge [
    source 471
    target 862
    kind "mentions"
  ]
  edge [
    source 471
    target 1188
    kind "mentions"
  ]
  edge [
    source 471
    target 993
    kind "relation"
    relation "often contains"
    weight 1
  ]
  edge [
    source 472
    target 487
    kind "mentions"
  ]
  edge [
    source 473
    target 474
    kind "mentions"
  ]
  edge [
    source 473
    target 475
    kind "mentions"
  ]
  edge [
    source 473
    target 476
    kind "mentions"
  ]
  edge [
    source 473
    target 477
    kind "mentions"
  ]
  edge [
    source 473
    target 478
    kind "mentions"
  ]
  edge [
    source 473
    target 479
    kind "mentions"
  ]
  edge [
    source 473
    target 480
    kind "mentions"
  ]
  edge [
    source 473
    target 481
    kind "mentions"
  ]
  edge [
    source 473
    target 482
    kind "mentions"
  ]
  edge [
    source 473
    target 483
    kind "mentions"
  ]
  edge [
    source 473
    target 484
    kind "mentions"
  ]
  edge [
    source 473
    target 485
    kind "mentions"
  ]
  edge [
    source 473
    target 486
    kind "mentions"
  ]
  edge [
    source 473
    target 1943
    kind "summarizes"
  ]
  edge [
    source 474
    target 659
    kind "mentions"
  ]
  edge [
    source 474
    target 648
    kind "relation"
    relation "leads to | may cause to become"
    weight 2
  ]
  edge [
    source 474
    target 664
    kind "relation"
    relation "may become"
    weight 1
  ]
  edge [
    source 474
    target 690
    kind "mentions"
  ]
  edge [
    source 474
    target 798
    kind "mentions"
  ]
  edge [
    source 474
    target 799
    kind "relation"
    relation "leads to becoming"
    weight 1
  ]
  edge [
    source 474
    target 1857
    kind "mentions"
  ]
  edge [
    source 474
    target 1858
    kind "relation"
    relation "was the only one who had been a"
    weight 1
  ]
  edge [
    source 478
    target 562
    kind "mentions"
  ]
  edge [
    source 482
    target 483
    kind "relation"
    relation "causes"
    weight 1
  ]
  edge [
    source 482
    target 484
    kind "relation"
    relation "causes"
    weight 1
  ]
  edge [
    source 482
    target 485
    kind "relation"
    relation "causes"
    weight 1
  ]
  edge [
    source 482
    target 486
    kind "relation"
    relation "causes"
    weight 1
  ]
  edge [
    source 487
    target 488
    kind "mentions"
  ]
  edge [
    source 487
    target 1938
    kind "summarizes"
  ]
  edge [
    source 488
    target 490
    kind "mentions"
  ]
  edge [
    source 488
    target 1403
    kind "mentions"
  ]
  edge [
    source 488
    target 1505
    kind "mentions"
  ]
  edge [
    source 488
    target 1507
    kind "relation"
    relation "causes"
    weight 1
  ]
  edge [
    source 488
    target 1577
    kind "mentions"
  ]
  edge [
    source 488
    target 1596
    kind "relation"
    relation "may cause"
    weight 1
  ]
  edge [
    source 489
    target 490
    kind "from_chunk"
  ]
  edge [
    source 489
    target 506
    kind "from_chunk"
  ]
  edge [
    source 490
    target 491
    kind "mentions"
  ]
  edge [
    source 490
    target 492
    kind "mentions"
  ]
  edge [
    source 490
    target 493
    kind "mentions"
  ]
  edge [
    source 490
    target 494
    kind "mentions"
  ]
  edge [
    source 490
    target 495
    kind "mentions"
  ]
  edge [
    source 490
    target 496
    kind "mentions"
  ]
  edge [
    source 490
    target 497
    kind "mentions"
  ]
  edge [
    source 490
    target 498
    kind "mentions"
  ]
  edge [
    source 490
    target 499
    kind "mentions"
  ]
  edge [
    source 490
    target 500
    kind "mentions"
  ]
  edge [
    source 490
    target 501
    kind "mentions"
  ]
  edge [
    source 490
    target 502
    kind "mentions"
  ]
  edge [
    source 490
    target 503
    kind "mentions"
  ]
  edge [
    source 490
    target 504
    kind "mentions"
  ]
  edge [
    source 490
    target 505
    kind "mentions"
  ]
  edge [
    source 490
    target 1960
    kind "summarizes"
  ]
  edge [
    source 493
    target 571
    kind "mentions"
  ]
  edge [
    source 494
    target 503
    kind "relation"
    relation "asks if patient drinks | answers yes to drinking question | answers what he drinks | answers how much he drinks"
    weight 4
  ]
  edge [
    source 494
    target 497
    kind "relation"
    relation "show chances of recovery"
    weight 1
  ]
  edge [
    source 494
    target 571
    kind "mentions"
  ]
  edge [
    source 494
    target 572
    kind "relation"
    relation "asks"
    weight 1
  ]
  edge [
    source 494
    target 573
    kind "relation"
    relation "asks"
    weight 1
  ]
  edge [
    source 494
    target 574
    kind "relation"
    relation "asks"
    weight 1
  ]
  edge [
    source 494
    target 575
    kind "relation"
    relation "asks"
    weight 1
  ]
  edge [
    source 494
    target 576
    kind "mentions"
  ]
  edge [
    source 494
    target 951
    kind "mentions"
  ]
  edge [
    source 494
    target 952
    kind "relation"
    relation "hired | studied"
    weight 2
  ]
  edge [
    source 494
    target 891
    kind "relation"
    relation "wanted to learn about"
    weight 1
  ]
  edge [
    source 494
    target 1307
    kind "mentions"
  ]
  edge [
    source 494
    target 1314
    kind "relation"
    relation "binds together"
    weight 1
  ]
  edge [
    source 494
    target 1435
    kind "mentions"
  ]
  edge [
    source 494
    target 1441
    kind "relation"
    relation "checks pulse when"
    weight 1
  ]
  edge [
    source 495
    target 798
    kind "mentions"
  ]
  edge [
    source 495
    target 1072
    kind "mentions"
  ]
  edge [
    source 495
    target 1202
    kind "mentions"
  ]
  edge [
    source 495
    target 1203
    kind "mentions"
  ]
  edge [
    source 497
    target 576
    kind "mentions"
  ]
  edge [
    source 500
    target 501
    kind "relation"
    relation "often drink"
    weight 1
  ]
  edge [
    source 501
    target 565
    kind "mentions"
  ]
  edge [
    source 501
    target 566
    kind "relation"
    relation "is consumed in"
    weight 1
  ]
  edge [
    source 504
    target 505
    kind "relation"
    relation "will get well"
    weight 1
  ]
  edge [
    source 506
    target 507
    kind "mentions"
  ]
  edge [
    source 506
    target 508
    kind "mentions"
  ]
  edge [
    source 506
    target 509
    kind "mentions"
  ]
  edge [
    source 506
    target 510
    kind "mentions"
  ]
  edge [
    source 506
    target 511
    kind "mentions"
  ]
  edge [
    source 506
    target 512
    kind "mentions"
  ]
  edge [
    source 506
    target 1954
    kind "summarizes"
  ]
  edge [
    source 508
    target 511
    kind "relation"
    relation "does not feel"
    weight 1
  ]
  edge [
    source 508
    target 525
    kind "mentions"
  ]
  edge [
    source 508
    target 1382
    kind "mentions"
  ]
  edge [
    source 508
    target 1795
    kind "mentions"
  ]
  edge [
    source 508
    target 1804
    kind "relation"
    relation "leads to | may make"
    weight 2
  ]
  edge [
    source 508
    target 1807
    kind "relation"
    relation "causes"
    weight 1
  ]
  edge [
    source 508
    target 1808
    kind "mentions"
  ]
  edge [
    source 508
    target 529
    kind "relation"
    relation "leads to"
    weight 1
  ]
  edge [
    source 508
    target 1843
    kind "mentions"
  ]
  edge [
    source 511
    target 512
    kind "relation"
    relation "does not take pains to"
    weight 1
  ]
  edge [
    source 512
    target 1756
    kind "mentions"
  ]
  edge [
    source 512
    target 1759
    kind "relation"
    relation "uses physical activity to"
    weight 1
  ]
  edge [
    source 513
    target 514
    kind "from_chunk"
  ]
  edge [
    source 513
    target 518
    kind "from_chunk"
  ]
  edge [
    source 514
    target 515
    kind "mentions"
  ]
  edge [
    source 514
    target 516
    kind "mentions"
  ]
  edge [
    source 514
    target 517
    kind "mentions"
  ]
  edge [
    source 514
    target 1942
    kind "summarizes"
  ]
  edge [
    source 518
    target 519
    kind "mentions"
  ]
  edge [
    source 518
    target 520
    kind "mentions"
  ]
  edge [
    source 518
    target 521
    kind "mentions"
  ]
  edge [
    source 518
    target 522
    kind "mentions"
  ]
  edge [
    source 518
    target 523
    kind "mentions"
  ]
  edge [
    source 518
    target 1959
    kind "summarizes"
  ]
  edge [
    source 519
    target 523
    kind "relation"
    relation "remembers lessons less well"
    weight 1
  ]
  edge [
    source 522
    target 523
    kind "relation"
    relation "is less polite than | is less good-natured than"
    weight 2
  ]
  edge [
    source 524
    target 525
    kind "from_chunk"
  ]
  edge [
    source 524
    target 530
    kind "from_chunk"
  ]
  edge [
    source 524
    target 535
    kind "from_chunk"
  ]
  edge [
    source 524
    target 543
    kind "from_chunk"
  ]
  edge [
    source 524
    target 546
    kind "from_chunk"
  ]
  edge [
    source 524
    target 553
    kind "from_chunk"
  ]
  edge [
    source 524
    target 558
    kind "from_chunk"
  ]
  edge [
    source 524
    target 562
    kind "from_chunk"
  ]
  edge [
    source 524
    target 565
    kind "from_chunk"
  ]
  edge [
    source 524
    target 569
    kind "from_chunk"
  ]
  edge [
    source 524
    target 571
    kind "from_chunk"
  ]
  edge [
    source 524
    target 576
    kind "from_chunk"
  ]
  edge [
    source 524
    target 580
    kind "from_chunk"
  ]
  edge [
    source 524
    target 584
    kind "from_chunk"
  ]
  edge [
    source 524
    target 588
    kind "from_chunk"
  ]
  edge [
    source 524
    target 593
    kind "from_chunk"
  ]
  edge [
    source 524
    target 598
    kind "from_chunk"
  ]
  edge [
    source 525
    target 526
    kind "mentions"
  ]
  edge [
    source 525
    target 527
    kind "mentions"
  ]
  edge [
    source 525
    target 528
    kind "mentions"
  ]
  edge [
    source 525
    target 529
    kind "mentions"
  ]
  edge [
    source 525
    target 1942
    kind "summarizes"
  ]
  edge [
    source 526
    target 1571
    kind "mentions"
  ]
  edge [
    source 527
    target 778
    kind "mentions"
  ]
  edge [
    source 527
    target 1326
    kind "mentions"
  ]
  edge [
    source 527
    target 1769
    kind "mentions"
  ]
  edge [
    source 527
    target 1770
    kind "relation"
    relation "comes from"
    weight 1
  ]
  edge [
    source 527
    target 1772
    kind "mentions"
  ]
  edge [
    source 527
    target 1773
    kind "relation"
    relation "generate"
    weight 1
  ]
  edge [
    source 527
    target 1178
    kind "relation"
    relation "warms | carries"
    weight 2
  ]
  edge [
    source 527
    target 1779
    kind "mentions"
  ]
  edge [
    source 527
    target 981
    kind "relation"
    relation "passes off through"
    weight 1
  ]
  edge [
    source 527
    target 1867
    kind "mentions"
  ]
  edge [
    source 529
    target 1808
    kind "mentions"
  ]
  edge [
    source 529
    target 1810
    kind "relation"
    relation "affects"
    weight 1
  ]
  edge [
    source 529
    target 1008
    kind "relation"
    relation "affects"
    weight 1
  ]
  edge [
    source 529
    target 1811
    kind "relation"
    relation "leads to"
    weight 1
  ]
  edge [
    source 530
    target 531
    kind "mentions"
  ]
  edge [
    source 530
    target 532
    kind "mentions"
  ]
  edge [
    source 530
    target 533
    kind "mentions"
  ]
  edge [
    source 530
    target 534
    kind "mentions"
  ]
  edge [
    source 530
    target 1942
    kind "summarizes"
  ]
  edge [
    source 531
    target 1716
    kind "mentions"
  ]
  edge [
    source 531
    target 1724
    kind "mentions"
  ]
  edge [
    source 531
    target 1717
    kind "relation"
    relation "include"
    weight 1
  ]
  edge [
    source 532
    target 992
    kind "mentions"
  ]
  edge [
    source 532
    target 891
    kind "relation"
    relation "cannot work well unless"
    weight 1
  ]
  edge [
    source 532
    target 1136
    kind "mentions"
  ]
  edge [
    source 532
    target 1756
    kind "mentions"
  ]
  edge [
    source 532
    target 1758
    kind "relation"
    relation "causes"
    weight 1
  ]
  edge [
    source 535
    target 536
    kind "mentions"
  ]
  edge [
    source 535
    target 537
    kind "mentions"
  ]
  edge [
    source 535
    target 538
    kind "mentions"
  ]
  edge [
    source 535
    target 539
    kind "mentions"
  ]
  edge [
    source 535
    target 540
    kind "mentions"
  ]
  edge [
    source 535
    target 541
    kind "mentions"
  ]
  edge [
    source 535
    target 542
    kind "mentions"
  ]
  edge [
    source 535
    target 1947
    kind "summarizes"
  ]
  edge [
    source 540
    target 553
    kind "mentions"
  ]
  edge [
    source 543
    target 544
    kind "mentions"
  ]
  edge [
    source 543
    target 545
    kind "mentions"
  ]
  edge [
    source 543
    target 1957
    kind "summarizes"
  ]
  edge [
    source 545
    target 681
    kind "mentions"
  ]
  edge [
    source 545
    target 671
    kind "relation"
    relation "contains"
    weight 1
  ]
  edge [
    source 546
    target 547
    kind "mentions"
  ]
  edge [
    source 546
    target 548
    kind "mentions"
  ]
  edge [
    source 546
    target 549
    kind "mentions"
  ]
  edge [
    source 546
    target 550
    kind "mentions"
  ]
  edge [
    source 546
    target 551
    kind "mentions"
  ]
  edge [
    source 546
    target 552
    kind "mentions"
  ]
  edge [
    source 546
    target 1942
    kind "summarizes"
  ]
  edge [
    source 550
    target 1212
    kind "mentions"
  ]
  edge [
    source 550
    target 946
    kind "relation"
    relation "is essential for"
    weight 1
  ]
  edge [
    source 553
    target 554
    kind "mentions"
  ]
  edge [
    source 553
    target 555
    kind "mentions"
  ]
  edge [
    source 553
    target 556
    kind "mentions"
  ]
  edge [
    source 553
    target 557
    kind "mentions"
  ]
  edge [
    source 553
    target 1947
    kind "summarizes"
  ]
  edge [
    source 558
    target 559
    kind "mentions"
  ]
  edge [
    source 558
    target 560
    kind "mentions"
  ]
  edge [
    source 558
    target 561
    kind "mentions"
  ]
  edge [
    source 558
    target 1943
    kind "summarizes"
  ]
  edge [
    source 560
    target 562
    kind "mentions"
  ]
  edge [
    source 562
    target 563
    kind "mentions"
  ]
  edge [
    source 562
    target 564
    kind "mentions"
  ]
  edge [
    source 562
    target 1943
    kind "summarizes"
  ]
  edge [
    source 565
    target 566
    kind "mentions"
  ]
  edge [
    source 565
    target 567
    kind "mentions"
  ]
  edge [
    source 565
    target 568
    kind "mentions"
  ]
  edge [
    source 565
    target 1960
    kind "summarizes"
  ]
  edge [
    source 566
    target 568
    kind "relation"
    relation "reduces"
    weight 1
  ]
  edge [
    source 569
    target 570
    kind "mentions"
  ]
  edge [
    source 569
    target 1944
    kind "summarizes"
  ]
  edge [
    source 571
    target 572
    kind "mentions"
  ]
  edge [
    source 571
    target 573
    kind "mentions"
  ]
  edge [
    source 571
    target 574
    kind "mentions"
  ]
  edge [
    source 571
    target 575
    kind "mentions"
  ]
  edge [
    source 571
    target 1960
    kind "summarizes"
  ]
  edge [
    source 576
    target 577
    kind "mentions"
  ]
  edge [
    source 576
    target 578
    kind "mentions"
  ]
  edge [
    source 576
    target 579
    kind "mentions"
  ]
  edge [
    source 576
    target 1960
    kind "summarizes"
  ]
  edge [
    source 577
    target 579
    kind "relation"
    relation "depends upon"
    weight 1
  ]
  edge [
    source 578
    target 579
    kind "relation"
    relation "depends upon"
    weight 1
  ]
  edge [
    source 580
    target 581
    kind "mentions"
  ]
  edge [
    source 580
    target 582
    kind "mentions"
  ]
  edge [
    source 580
    target 583
    kind "mentions"
  ]
  edge [
    source 580
    target 1942
    kind "summarizes"
  ]
  edge [
    source 584
    target 585
    kind "mentions"
  ]
  edge [
    source 584
    target 586
    kind "mentions"
  ]
  edge [
    source 584
    target 587
    kind "mentions"
  ]
  edge [
    source 584
    target 1942
    kind "summarizes"
  ]
  edge [
    source 585
    target 586
    kind "relation"
    relation "produce"
    weight 1
  ]
  edge [
    source 585
    target 587
    kind "relation"
    relation "produce"
    weight 1
  ]
  edge [
    source 588
    target 589
    kind "mentions"
  ]
  edge [
    source 588
    target 590
    kind "mentions"
  ]
  edge [
    source 588
    target 591
    kind "mentions"
  ]
  edge [
    source 588
    target 592
    kind "mentions"
  ]
  edge [
    source 588
    target 1938
    kind "summarizes"
  ]
  edge [
    source 592
    target 1505
    kind "mentions"
  ]
  edge [
    source 592
    target 1483
    kind "relation"
    relation "poisons | should not breathe"
    weight 2
  ]
  edge [
    source 592
    target 1451
    kind "relation"
    relation "makes feel better"
    weight 1
  ]
  edge [
    source 592
    target 1819
    kind "mentions"
  ]
  edge [
    source 592
    target 1891
    kind "mentions"
  ]
  edge [
    source 592
    target 1907
    kind "mentions"
  ]
  edge [
    source 593
    target 594
    kind "mentions"
  ]
  edge [
    source 593
    target 595
    kind "mentions"
  ]
  edge [
    source 593
    target 596
    kind "mentions"
  ]
  edge [
    source 593
    target 597
    kind "mentions"
  ]
  edge [
    source 593
    target 1959
    kind "summarizes"
  ]
  edge [
    source 598
    target 599
    kind "mentions"
  ]
  edge [
    source 598
    target 600
    kind "mentions"
  ]
  edge [
    source 598
    target 601
    kind "mentions"
  ]
  edge [
    source 598
    target 602
    kind "mentions"
  ]
  edge [
    source 598
    target 603
    kind "mentions"
  ]
  edge [
    source 598
    target 1953
    kind "summarizes"
  ]
  edge [
    source 599
    target 600
    kind "relation"
    relation "is full of"
    weight 1
  ]
  edge [
    source 599
    target 602
    kind "relation"
    relation "is of its own"
    weight 1
  ]
  edge [
    source 600
    target 601
    kind "relation"
    relation "is mostly"
    weight 1
  ]
  edge [
    source 600
    target 602
    kind "relation"
    relation "is sweetened with"
    weight 1
  ]
  edge [
    source 600
    target 617
    kind "mentions"
  ]
  edge [
    source 600
    target 619
    kind "relation"
    relation "contain"
    weight 1
  ]
  edge [
    source 600
    target 620
    kind "relation"
    relation "are pressed to extract"
    weight 1
  ]
  edge [
    source 600
    target 622
    kind "relation"
    relation "is separated from"
    weight 1
  ]
  edge [
    source 600
    target 623
    kind "relation"
    relation "is separated from"
    weight 1
  ]
  edge [
    source 600
    target 624
    kind "relation"
    relation "is left in"
    weight 1
  ]
  edge [
    source 600
    target 665
    kind "mentions"
  ]
  edge [
    source 600
    target 668
    kind "relation"
    relation "produces"
    weight 1
  ]
  edge [
    source 600
    target 666
    kind "relation"
    relation "has little alcohol initially"
    weight 1
  ]
  edge [
    source 601
    target 605
    kind "mentions"
  ]
  edge [
    source 601
    target 606
    kind "relation"
    relation "is mostly composed of"
    weight 1
  ]
  edge [
    source 601
    target 610
    kind "relation"
    relation "contain"
    weight 1
  ]
  edge [
    source 601
    target 612
    kind "relation"
    relation "contain"
    weight 1
  ]
  edge [
    source 601
    target 615
    kind "relation"
    relation "contain"
    weight 1
  ]
  edge [
    source 601
    target 636
    kind "mentions"
  ]
  edge [
    source 601
    target 647
    kind "mentions"
  ]
  edge [
    source 601
    target 648
    kind "relation"
    relation "is partly"
    weight 1
  ]
  edge [
    source 601
    target 720
    kind "mentions"
  ]
  edge [
    source 601
    target 721
    kind "relation"
    relation "is soaked in"
    weight 1
  ]
  edge [
    source 601
    target 722
    kind "relation"
    relation "has water"
    weight 1
  ]
  edge [
    source 601
    target 745
    kind "mentions"
  ]
  edge [
    source 601
    target 746
    kind "relation"
    relation "involves boiling water and condensing steam into water"
    weight 1
  ]
  edge [
    source 601
    target 747
    kind "relation"
    relation "turns into | is the vapor form of | boils into"
    weight 3
  ]
  edge [
    source 601
    target 753
    kind "mentions"
  ]
  edge [
    source 601
    target 778
    kind "mentions"
  ]
  edge [
    source 601
    target 787
    kind "mentions"
  ]
  edge [
    source 601
    target 783
    kind "relation"
    relation "would have decayed in"
    weight 1
  ]
  edge [
    source 601
    target 1072
    kind "mentions"
  ]
  edge [
    source 601
    target 1073
    kind "relation"
    relation "is used in"
    weight 1
  ]
  edge [
    source 601
    target 1074
    kind "mentions"
  ]
  edge [
    source 601
    target 1075
    kind "relation"
    relation "provide"
    weight 1
  ]
  edge [
    source 601
    target 1076
    kind "relation"
    relation "is stored in"
    weight 1
  ]
  edge [
    source 601
    target 1077
    kind "relation"
    relation "is stored in"
    weight 1
  ]
  edge [
    source 601
    target 1078
    kind "mentions"
  ]
  edge [
    source 601
    target 1079
    kind "relation"
    relation "lead"
    weight 1
  ]
  edge [
    source 601
    target 1084
    kind "mentions"
  ]
  edge [
    source 601
    target 1086
    kind "relation"
    relation "may have | is mixed with"
    weight 2
  ]
  edge [
    source 601
    target 1088
    kind "mentions"
  ]
  edge [
    source 601
    target 1085
    kind "relation"
    relation "has lead mixed with it | can absorb from | can release into"
    weight 3
  ]
  edge [
    source 601
    target 1089
    kind "mentions"
  ]
  edge [
    source 601
    target 1092
    kind "relation"
    relation "may make a person very sick"
    weight 1
  ]
  edge [
    source 601
    target 1100
    kind "mentions"
  ]
  edge [
    source 601
    target 1191
    kind "mentions"
  ]
  edge [
    source 601
    target 1202
    kind "mentions"
  ]
  edge [
    source 601
    target 1252
    kind "mentions"
  ]
  edge [
    source 601
    target 949
    kind "relation"
    relation "is part of"
    weight 1
  ]
  edge [
    source 601
    target 1326
    kind "mentions"
  ]
  edge [
    source 601
    target 1427
    kind "mentions"
  ]
  edge [
    source 601
    target 1550
    kind "mentions"
  ]
  edge [
    source 602
    target 605
    kind "mentions"
  ]
  edge [
    source 602
    target 606
    kind "relation"
    relation "is sweetened with"
    weight 1
  ]
  edge [
    source 602
    target 610
    kind "relation"
    relation "contain"
    weight 1
  ]
  edge [
    source 602
    target 612
    kind "relation"
    relation "contain"
    weight 1
  ]
  edge [
    source 602
    target 615
    kind "relation"
    relation "contain"
    weight 1
  ]
  edge [
    source 602
    target 629
    kind "mentions"
  ]
  edge [
    source 602
    target 633
    kind "relation"
    relation "is changing into"
    weight 1
  ]
  edge [
    source 602
    target 636
    kind "mentions"
  ]
  edge [
    source 602
    target 637
    kind "relation"
    relation "changes into | is converted into | is changed into"
    weight 3
  ]
  edge [
    source 602
    target 652
    kind "mentions"
  ]
  edge [
    source 602
    target 665
    kind "mentions"
  ]
  edge [
    source 602
    target 678
    kind "mentions"
  ]
  edge [
    source 602
    target 695
    kind "mentions"
  ]
  edge [
    source 602
    target 697
    kind "relation"
    relation "is changed into | turns into | must be changed into | needs to be converted into"
    weight 5
  ]
  edge [
    source 602
    target 708
    kind "mentions"
  ]
  edge [
    source 602
    target 714
    kind "mentions"
  ]
  edge [
    source 602
    target 710
    kind "relation"
    relation "is stopped to preserve"
    weight 1
  ]
  edge [
    source 602
    target 720
    kind "mentions"
  ]
  edge [
    source 602
    target 716
    kind "relation"
    relation "add yeast to convert"
    weight 1
  ]
  edge [
    source 602
    target 723
    kind "relation"
    relation "converts"
    weight 1
  ]
  edge [
    source 602
    target 941
    kind "mentions"
  ]
  edge [
    source 602
    target 942
    kind "relation"
    relation "contains"
    weight 1
  ]
  edge [
    source 602
    target 1161
    kind "mentions"
  ]
  edge [
    source 602
    target 1166
    kind "mentions"
  ]
  edge [
    source 602
    target 1167
    kind "relation"
    relation "comes from"
    weight 1
  ]
  edge [
    source 602
    target 1168
    kind "relation"
    relation "comes from"
    weight 1
  ]
  edge [
    source 602
    target 1169
    kind "relation"
    relation "comes from"
    weight 1
  ]
  edge [
    source 602
    target 1177
    kind "mentions"
  ]
  edge [
    source 602
    target 1178
    kind "relation"
    relation "can mix with | is required before"
    weight 2
  ]
  edge [
    source 602
    target 1180
    kind "mentions"
  ]
  edge [
    source 602
    target 704
    kind "relation"
    relation "changes its starch into"
    weight 1
  ]
  edge [
    source 602
    target 1184
    kind "mentions"
  ]
  edge [
    source 602
    target 1187
    kind "mentions"
  ]
  edge [
    source 602
    target 993
    kind "relation"
    relation "contains"
    weight 1
  ]
  edge [
    source 602
    target 1188
    kind "mentions"
  ]
  edge [
    source 602
    target 1190
    kind "relation"
    relation "cannot sustain life if consumed alone"
    weight 1
  ]
  edge [
    source 602
    target 1189
    kind "relation"
    relation "may not be truly pure"
    weight 1
  ]
  edge [
    source 602
    target 1191
    kind "mentions"
  ]
  edge [
    source 602
    target 1198
    kind "mentions"
  ]
  edge [
    source 602
    target 1193
    kind "relation"
    relation "is used instead of | is cheaper than"
    weight 2
  ]
  edge [
    source 602
    target 1244
    kind "mentions"
  ]
  edge [
    source 602
    target 1192
    kind "relation"
    relation "contains"
    weight 1
  ]
  edge [
    source 602
    target 1278
    kind "mentions"
  ]
  edge [
    source 602
    target 1007
    kind "relation"
    relation "turns starch into | can turn starch into"
    weight 2
  ]
  edge [
    source 602
    target 1279
    kind "mentions"
  ]
  edge [
    source 602
    target 1282
    kind "mentions"
  ]
  edge [
    source 602
    target 1315
    kind "mentions"
  ]
  edge [
    source 602
    target 1326
    kind "mentions"
  ]
  edge [
    source 604
    target 605
    kind "from_chunk"
  ]
  edge [
    source 604
    target 617
    kind "from_chunk"
  ]
  edge [
    source 604
    target 629
    kind "from_chunk"
  ]
  edge [
    source 605
    target 606
    kind "mentions"
  ]
  edge [
    source 605
    target 607
    kind "mentions"
  ]
  edge [
    source 605
    target 608
    kind "mentions"
  ]
  edge [
    source 605
    target 609
    kind "mentions"
  ]
  edge [
    source 605
    target 610
    kind "mentions"
  ]
  edge [
    source 605
    target 611
    kind "mentions"
  ]
  edge [
    source 605
    target 612
    kind "mentions"
  ]
  edge [
    source 605
    target 613
    kind "mentions"
  ]
  edge [
    source 605
    target 614
    kind "mentions"
  ]
  edge [
    source 605
    target 615
    kind "mentions"
  ]
  edge [
    source 605
    target 616
    kind "mentions"
  ]
  edge [
    source 605
    target 1940
    kind "summarizes"
  ]
  edge [
    source 606
    target 607
    kind "relation"
    relation "has a flavor that identifies it as"
    weight 1
  ]
  edge [
    source 607
    target 629
    kind "mentions"
  ]
  edge [
    source 607
    target 631
    kind "relation"
    relation "has undergone a change"
    weight 1
  ]
  edge [
    source 607
    target 636
    kind "mentions"
  ]
  edge [
    source 607
    target 637
    kind "relation"
    relation "forms bubbles in | rises to the top and goes into the air"
    weight 2
  ]
  edge [
    source 607
    target 643
    kind "mentions"
  ]
  edge [
    source 607
    target 646
    kind "relation"
    relation "is not safe to drink"
    weight 1
  ]
  edge [
    source 610
    target 611
    kind "relation"
    relation "have"
    weight 1
  ]
  edge [
    source 610
    target 665
    kind "mentions"
  ]
  edge [
    source 610
    target 666
    kind "relation"
    relation "are used to make"
    weight 1
  ]
  edge [
    source 610
    target 941
    kind "mentions"
  ]
  edge [
    source 610
    target 942
    kind "relation"
    relation "contains"
    weight 1
  ]
  edge [
    source 610
    target 992
    kind "mentions"
  ]
  edge [
    source 610
    target 1364
    kind "mentions"
  ]
  edge [
    source 612
    target 613
    kind "relation"
    relation "have"
    weight 1
  ]
  edge [
    source 614
    target 615
    kind "relation"
    relation "follow the same pattern as"
    weight 1
  ]
  edge [
    source 614
    target 652
    kind "mentions"
  ]
  edge [
    source 614
    target 648
    kind "relation"
    relation "is made from"
    weight 1
  ]
  edge [
    source 615
    target 616
    kind "relation"
    relation "each have"
    weight 1
  ]
  edge [
    source 615
    target 1238
    kind "mentions"
  ]
  edge [
    source 615
    target 1315
    kind "mentions"
  ]
  edge [
    source 615
    target 1320
    kind "relation"
    relation "do not need cooking because"
    weight 1
  ]
  edge [
    source 617
    target 618
    kind "mentions"
  ]
  edge [
    source 617
    target 619
    kind "mentions"
  ]
  edge [
    source 617
    target 620
    kind "mentions"
  ]
  edge [
    source 617
    target 621
    kind "mentions"
  ]
  edge [
    source 617
    target 622
    kind "mentions"
  ]
  edge [
    source 617
    target 623
    kind "mentions"
  ]
  edge [
    source 617
    target 624
    kind "mentions"
  ]
  edge [
    source 617
    target 625
    kind "mentions"
  ]
  edge [
    source 617
    target 626
    kind "mentions"
  ]
  edge [
    source 617
    target 627
    kind "mentions"
  ]
  edge [
    source 617
    target 628
    kind "mentions"
  ]
  edge [
    source 617
    target 1953
    kind "summarizes"
  ]
  edge [
    source 618
    target 619
    kind "relation"
    relation "are gathered and put into"
    weight 1
  ]
  edge [
    source 618
    target 643
    kind "mentions"
  ]
  edge [
    source 620
    target 652
    kind "mentions"
  ]
  edge [
    source 620
    target 648
    kind "relation"
    relation "is made in a way similar to"
    weight 1
  ]
  edge [
    source 620
    target 681
    kind "mentions"
  ]
  edge [
    source 620
    target 1252
    kind "mentions"
  ]
  edge [
    source 620
    target 949
    kind "relation"
    relation "are part of"
    weight 1
  ]
  edge [
    source 623
    target 1228
    kind "mentions"
  ]
  edge [
    source 623
    target 1145
    kind "relation"
    relation "comes from"
    weight 1
  ]
  edge [
    source 623
    target 1232
    kind "relation"
    relation "are rich in"
    weight 1
  ]
  edge [
    source 624
    target 627
    kind "relation"
    relation "causes"
    weight 1
  ]
  edge [
    source 624
    target 665
    kind "mentions"
  ]
  edge [
    source 624
    target 675
    kind "mentions"
  ]
  edge [
    source 624
    target 676
    kind "relation"
    relation "causes"
    weight 1
  ]
  edge [
    source 624
    target 677
    kind "relation"
    relation "causes"
    weight 1
  ]
  edge [
    source 625
    target 628
    kind "relation"
    relation "form froth on"
    weight 1
  ]
  edge [
    source 625
    target 636
    kind "mentions"
  ]
  edge [
    source 625
    target 720
    kind "mentions"
  ]
  edge [
    source 625
    target 727
    kind "relation"
    relation "indicate"
    weight 1
  ]
  edge [
    source 625
    target 728
    kind "relation"
    relation "indicate"
    weight 1
  ]
  edge [
    source 629
    target 630
    kind "mentions"
  ]
  edge [
    source 629
    target 631
    kind "mentions"
  ]
  edge [
    source 629
    target 632
    kind "mentions"
  ]
  edge [
    source 629
    target 633
    kind "mentions"
  ]
  edge [
    source 629
    target 634
    kind "mentions"
  ]
  edge [
    source 629
    target 1940
    kind "summarizes"
  ]
  edge [
    source 630
    target 634
    kind "relation"
    relation "would say"
    weight 1
  ]
  edge [
    source 635
    target 636
    kind "from_chunk"
  ]
  edge [
    source 635
    target 638
    kind "from_chunk"
  ]
  edge [
    source 635
    target 643
    kind "from_chunk"
  ]
  edge [
    source 635
    target 647
    kind "from_chunk"
  ]
  edge [
    source 635
    target 652
    kind "from_chunk"
  ]
  edge [
    source 636
    target 637
    kind "mentions"
  ]
  edge [
    source 636
    target 1940
    kind "summarizes"
  ]
  edge [
    source 637
    target 652
    kind "mentions"
  ]
  edge [
    source 637
    target 678
    kind "mentions"
  ]
  edge [
    source 637
    target 720
    kind "mentions"
  ]
  edge [
    source 637
    target 723
    kind "relation"
    relation "produces"
    weight 1
  ]
  edge [
    source 638
    target 639
    kind "mentions"
  ]
  edge [
    source 638
    target 640
    kind "mentions"
  ]
  edge [
    source 638
    target 641
    kind "mentions"
  ]
  edge [
    source 638
    target 642
    kind "mentions"
  ]
  edge [
    source 638
    target 1948
    kind "summarizes"
  ]
  edge [
    source 640
    target 641
    kind "relation"
    relation "will harm"
    weight 1
  ]
  edge [
    source 640
    target 642
    kind "relation"
    relation "would kill"
    weight 1
  ]
  edge [
    source 640
    target 1819
    kind "mentions"
  ]
  edge [
    source 640
    target 1781
    kind "relation"
    relation "becomes colder than before"
    weight 1
  ]
  edge [
    source 640
    target 1787
    kind "relation"
    relation "may not put on more clothing"
    weight 1
  ]
  edge [
    source 640
    target 1835
    kind "relation"
    relation "may freeze | may freeze to death"
    weight 2
  ]
  edge [
    source 643
    target 644
    kind "mentions"
  ]
  edge [
    source 643
    target 645
    kind "mentions"
  ]
  edge [
    source 643
    target 646
    kind "mentions"
  ]
  edge [
    source 643
    target 1947
    kind "summarizes"
  ]
  edge [
    source 646
    target 859
    kind "mentions"
  ]
  edge [
    source 646
    target 861
    kind "relation"
    relation "is not safe and not helpful to"
    weight 1
  ]
  edge [
    source 647
    target 648
    kind "mentions"
  ]
  edge [
    source 647
    target 649
    kind "mentions"
  ]
  edge [
    source 647
    target 650
    kind "mentions"
  ]
  edge [
    source 647
    target 651
    kind "mentions"
  ]
  edge [
    source 647
    target 1943
    kind "summarizes"
  ]
  edge [
    source 648
    target 651
    kind "relation"
    relation "still has"
    weight 1
  ]
  edge [
    source 648
    target 652
    kind "mentions"
  ]
  edge [
    source 648
    target 653
    kind "relation"
    relation "is made from"
    weight 1
  ]
  edge [
    source 648
    target 654
    kind "relation"
    relation "is made from"
    weight 1
  ]
  edge [
    source 648
    target 659
    kind "mentions"
  ]
  edge [
    source 648
    target 665
    kind "mentions"
  ]
  edge [
    source 648
    target 671
    kind "relation"
    relation "turns into"
    weight 2
  ]
  edge [
    source 648
    target 675
    kind "mentions"
  ]
  edge [
    source 648
    target 684
    kind "mentions"
  ]
  edge [
    source 648
    target 688
    kind "mentions"
  ]
  edge [
    source 648
    target 690
    kind "mentions"
  ]
  edge [
    source 648
    target 734
    kind "mentions"
  ]
  edge [
    source 648
    target 735
    kind "relation"
    relation "drinks"
    weight 1
  ]
  edge [
    source 648
    target 736
    kind "relation"
    relation "does not allow"
    weight 1
  ]
  edge [
    source 648
    target 753
    kind "mentions"
  ]
  edge [
    source 648
    target 755
    kind "relation"
    relation "is distilled into"
    weight 1
  ]
  edge [
    source 648
    target 768
    kind "relation"
    relation "contains little alcohol initially"
    weight 1
  ]
  edge [
    source 648
    target 788
    kind "mentions"
  ]
  edge [
    source 648
    target 798
    kind "mentions"
  ]
  edge [
    source 648
    target 666
    kind "relation"
    relation "leads to"
    weight 1
  ]
  edge [
    source 648
    target 1001
    kind "mentions"
  ]
  edge [
    source 648
    target 1328
    kind "mentions"
  ]
  edge [
    source 648
    target 1330
    kind "relation"
    relation "was not included on"
    weight 1
  ]
  edge [
    source 648
    target 1421
    kind "mentions"
  ]
  edge [
    source 648
    target 1422
    kind "relation"
    relation "is a type of"
    weight 1
  ]
  edge [
    source 648
    target 1891
    kind "mentions"
  ]
  edge [
    source 648
    target 757
    kind "relation"
    relation "costs more than"
    weight 1
  ]
  edge [
    source 652
    target 653
    kind "mentions"
  ]
  edge [
    source 652
    target 654
    kind "mentions"
  ]
  edge [
    source 652
    target 655
    kind "mentions"
  ]
  edge [
    source 652
    target 656
    kind "mentions"
  ]
  edge [
    source 652
    target 657
    kind "mentions"
  ]
  edge [
    source 652
    target 1953
    kind "summarizes"
  ]
  edge [
    source 656
    target 678
    kind "mentions"
  ]
  edge [
    source 656
    target 680
    kind "relation"
    relation "undergoes change in warm place"
    weight 1
  ]
  edge [
    source 658
    target 659
    kind "from_chunk"
  ]
  edge [
    source 658
    target 665
    kind "from_chunk"
  ]
  edge [
    source 659
    target 660
    kind "mentions"
  ]
  edge [
    source 659
    target 661
    kind "mentions"
  ]
  edge [
    source 659
    target 662
    kind "mentions"
  ]
  edge [
    source 659
    target 663
    kind "mentions"
  ]
  edge [
    source 659
    target 664
    kind "mentions"
  ]
  edge [
    source 659
    target 1943
    kind "summarizes"
  ]
  edge [
    source 665
    target 666
    kind "mentions"
  ]
  edge [
    source 665
    target 667
    kind "mentions"
  ]
  edge [
    source 665
    target 668
    kind "mentions"
  ]
  edge [
    source 665
    target 669
    kind "mentions"
  ]
  edge [
    source 665
    target 670
    kind "mentions"
  ]
  edge [
    source 665
    target 671
    kind "mentions"
  ]
  edge [
    source 665
    target 672
    kind "mentions"
  ]
  edge [
    source 665
    target 673
    kind "mentions"
  ]
  edge [
    source 665
    target 1957
    kind "summarizes"
  ]
  edge [
    source 666
    target 672
    kind "relation"
    relation "develops alcohol over time"
    weight 1
  ]
  edge [
    source 666
    target 669
    kind "relation"
    relation "makes drinkers"
    weight 1
  ]
  edge [
    source 666
    target 670
    kind "relation"
    relation "makes drinkers"
    weight 1
  ]
  edge [
    source 666
    target 671
    kind "relation"
    relation "turns into"
    weight 2
  ]
  edge [
    source 666
    target 675
    kind "mentions"
  ]
  edge [
    source 666
    target 691
    kind "mentions"
  ]
  edge [
    source 666
    target 692
    kind "relation"
    relation "is made from"
    weight 1
  ]
  edge [
    source 666
    target 734
    kind "mentions"
  ]
  edge [
    source 666
    target 735
    kind "relation"
    relation "drinks"
    weight 1
  ]
  edge [
    source 666
    target 736
    kind "relation"
    relation "does not allow"
    weight 1
  ]
  edge [
    source 666
    target 753
    kind "mentions"
  ]
  edge [
    source 666
    target 756
    kind "relation"
    relation "is distilled into"
    weight 1
  ]
  edge [
    source 666
    target 757
    kind "relation"
    relation "is distilled into"
    weight 1
  ]
  edge [
    source 666
    target 758
    kind "relation"
    relation "is distilled into"
    weight 1
  ]
  edge [
    source 666
    target 776
    kind "mentions"
  ]
  edge [
    source 666
    target 777
    kind "relation"
    relation "can make"
    weight 1
  ]
  edge [
    source 666
    target 788
    kind "mentions"
  ]
  edge [
    source 666
    target 798
    kind "mentions"
  ]
  edge [
    source 666
    target 1001
    kind "mentions"
  ]
  edge [
    source 666
    target 1364
    kind "mentions"
  ]
  edge [
    source 666
    target 1365
    kind "relation"
    relation "is made from"
    weight 1
  ]
  edge [
    source 666
    target 1376
    kind "relation"
    relation "forms alcohol in"
    weight 1
  ]
  edge [
    source 667
    target 1019
    kind "mentions"
  ]
  edge [
    source 667
    target 1024
    kind "relation"
    relation "makes air unfit to breathe"
    weight 1
  ]
  edge [
    source 667
    target 1467
    kind "mentions"
  ]
  edge [
    source 667
    target 1469
    kind "relation"
    relation "swell out to take in | contract to release"
    weight 2
  ]
  edge [
    source 667
    target 1477
    kind "mentions"
  ]
  edge [
    source 667
    target 1496
    kind "mentions"
  ]
  edge [
    source 667
    target 1498
    kind "mentions"
  ]
  edge [
    source 667
    target 1499
    kind "relation"
    relation "poisons"
    weight 1
  ]
  edge [
    source 667
    target 1529
    kind "mentions"
  ]
  edge [
    source 667
    target 1534
    kind "relation"
    relation "becomes spoiled by"
    weight 1
  ]
  edge [
    source 667
    target 1536
    kind "relation"
    relation "can be kept fresh and pure by"
    weight 1
  ]
  edge [
    source 667
    target 1517
    kind "relation"
    relation "filters, warms and humidifies air"
    weight 1
  ]
  edge [
    source 671
    target 675
    kind "mentions"
  ]
  edge [
    source 671
    target 681
    kind "mentions"
  ]
  edge [
    source 671
    target 682
    kind "relation"
    relation "after standing"
    weight 1
  ]
  edge [
    source 671
    target 683
    kind "relation"
    relation "is not safe to drink"
    weight 1
  ]
  edge [
    source 671
    target 691
    kind "mentions"
  ]
  edge [
    source 671
    target 692
    kind "relation"
    relation "soon turns into | can be made by fermenting"
    weight 2
  ]
  edge [
    source 671
    target 693
    kind "mentions"
  ]
  edge [
    source 672
    target 673
    kind "relation"
    relation "contain"
    weight 1
  ]
  edge [
    source 674
    target 675
    kind "from_chunk"
  ]
  edge [
    source 674
    target 678
    kind "from_chunk"
  ]
  edge [
    source 674
    target 681
    kind "from_chunk"
  ]
  edge [
    source 674
    target 684
    kind "from_chunk"
  ]
  edge [
    source 675
    target 676
    kind "mentions"
  ]
  edge [
    source 675
    target 677
    kind "mentions"
  ]
  edge [
    source 675
    target 1953
    kind "summarizes"
  ]
  edge [
    source 678
    target 679
    kind "mentions"
  ]
  edge [
    source 678
    target 680
    kind "mentions"
  ]
  edge [
    source 678
    target 1940
    kind "summarizes"
  ]
  edge [
    source 679
    target 680
    kind "relation"
    relation "is not safe for"
    weight 1
  ]
  edge [
    source 681
    target 682
    kind "mentions"
  ]
  edge [
    source 681
    target 683
    kind "mentions"
  ]
  edge [
    source 681
    target 1957
    kind "summarizes"
  ]
  edge [
    source 682
    target 684
    kind "mentions"
  ]
  edge [
    source 684
    target 685
    kind "mentions"
  ]
  edge [
    source 684
    target 686
    kind "mentions"
  ]
  edge [
    source 684
    target 1957
    kind "summarizes"
  ]
  edge [
    source 687
    target 688
    kind "from_chunk"
  ]
  edge [
    source 687
    target 689
    kind "from_chunk"
  ]
  edge [
    source 687
    target 690
    kind "from_chunk"
  ]
  edge [
    source 687
    target 691
    kind "from_chunk"
  ]
  edge [
    source 687
    target 693
    kind "from_chunk"
  ]
  edge [
    source 687
    target 695
    kind "from_chunk"
  ]
  edge [
    source 688
    target 1943
    kind "summarizes"
  ]
  edge [
    source 689
    target 1943
    kind "summarizes"
  ]
  edge [
    source 690
    target 1943
    kind "summarizes"
  ]
  edge [
    source 691
    target 692
    kind "mentions"
  ]
  edge [
    source 691
    target 1957
    kind "summarizes"
  ]
  edge [
    source 692
    target 693
    kind "mentions"
  ]
  edge [
    source 693
    target 694
    kind "mentions"
  ]
  edge [
    source 693
    target 1957
    kind "summarizes"
  ]
  edge [
    source 695
    target 696
    kind "mentions"
  ]
  edge [
    source 695
    target 697
    kind "mentions"
  ]
  edge [
    source 695
    target 698
    kind "mentions"
  ]
  edge [
    source 695
    target 699
    kind "mentions"
  ]
  edge [
    source 695
    target 700
    kind "mentions"
  ]
  edge [
    source 695
    target 701
    kind "mentions"
  ]
  edge [
    source 695
    target 702
    kind "mentions"
  ]
  edge [
    source 695
    target 703
    kind "mentions"
  ]
  edge [
    source 695
    target 704
    kind "mentions"
  ]
  edge [
    source 695
    target 705
    kind "mentions"
  ]
  edge [
    source 695
    target 706
    kind "mentions"
  ]
  edge [
    source 695
    target 1941
    kind "summarizes"
  ]
  edge [
    source 696
    target 697
    kind "relation"
    relation "contain"
    weight 1
  ]
  edge [
    source 696
    target 705
    kind "relation"
    relation "when planted in moist and warm soil"
    weight 1
  ]
  edge [
    source 696
    target 706
    kind "relation"
    relation "send little roots down into the earth | send little stems up into the sunshine"
    weight 2
  ]
  edge [
    source 696
    target 1106
    kind "mentions"
  ]
  edge [
    source 696
    target 1129
    kind "mentions"
  ]
  edge [
    source 696
    target 1132
    kind "relation"
    relation "include"
    weight 1
  ]
  edge [
    source 696
    target 711
    kind "relation"
    relation "include"
    weight 1
  ]
  edge [
    source 696
    target 759
    kind "relation"
    relation "include"
    weight 1
  ]
  edge [
    source 696
    target 1130
    kind "relation"
    relation "include"
    weight 1
  ]
  edge [
    source 697
    target 708
    kind "mentions"
  ]
  edge [
    source 697
    target 709
    kind "relation"
    relation "begins to sprout"
    weight 1
  ]
  edge [
    source 697
    target 714
    kind "mentions"
  ]
  edge [
    source 697
    target 1161
    kind "mentions"
  ]
  edge [
    source 697
    target 1166
    kind "mentions"
  ]
  edge [
    source 697
    target 814
    kind "relation"
    relation "comes from"
    weight 1
  ]
  edge [
    source 697
    target 1163
    kind "relation"
    relation "comes from"
    weight 1
  ]
  edge [
    source 697
    target 1171
    kind "relation"
    relation "comes from"
    weight 1
  ]
  edge [
    source 697
    target 1177
    kind "mentions"
  ]
  edge [
    source 697
    target 1180
    kind "mentions"
  ]
  edge [
    source 697
    target 1181
    kind "relation"
    relation "transforms | converts"
    weight 2
  ]
  edge [
    source 697
    target 1184
    kind "mentions"
  ]
  edge [
    source 697
    target 1278
    kind "mentions"
  ]
  edge [
    source 697
    target 1279
    kind "mentions"
  ]
  edge [
    source 697
    target 1280
    kind "relation"
    relation "is mostly made of | is made mostly of"
    weight 2
  ]
  edge [
    source 697
    target 711
    kind "relation"
    relation "comes from | is full of"
    weight 2
  ]
  edge [
    source 697
    target 1282
    kind "mentions"
  ]
  edge [
    source 697
    target 1007
    kind "relation"
    relation "converts"
    weight 1
  ]
  edge [
    source 697
    target 1283
    kind "mentions"
  ]
  edge [
    source 697
    target 1315
    kind "mentions"
  ]
  edge [
    source 697
    target 1326
    kind "mentions"
  ]
  edge [
    source 697
    target 945
    kind "relation"
    relation "is listed with"
    weight 1
  ]
  edge [
    source 699
    target 714
    kind "mentions"
  ]
  edge [
    source 700
    target 714
    kind "mentions"
  ]
  edge [
    source 701
    target 708
    kind "mentions"
  ]
  edge [
    source 702
    target 708
    kind "mentions"
  ]
  edge [
    source 704
    target 1180
    kind "mentions"
  ]
  edge [
    source 704
    target 1181
    kind "relation"
    relation "causes to change | is ripened and sweetened by"
    weight 2
  ]
  edge [
    source 704
    target 1184
    kind "mentions"
  ]
  edge [
    source 704
    target 1268
    kind "mentions"
  ]
  edge [
    source 707
    target 708
    kind "from_chunk"
  ]
  edge [
    source 707
    target 714
    kind "from_chunk"
  ]
  edge [
    source 707
    target 720
    kind "from_chunk"
  ]
  edge [
    source 708
    target 709
    kind "mentions"
  ]
  edge [
    source 708
    target 710
    kind "mentions"
  ]
  edge [
    source 708
    target 711
    kind "mentions"
  ]
  edge [
    source 708
    target 712
    kind "mentions"
  ]
  edge [
    source 708
    target 713
    kind "mentions"
  ]
  edge [
    source 708
    target 1941
    kind "summarizes"
  ]
  edge [
    source 710
    target 714
    kind "mentions"
  ]
  edge [
    source 710
    target 716
    kind "relation"
    relation "keep grain warm and moist"
    weight 1
  ]
  edge [
    source 711
    target 713
    kind "relation"
    relation "can be chewed to detect sugar change"
    weight 1
  ]
  edge [
    source 711
    target 812
    kind "mentions"
  ]
  edge [
    source 711
    target 813
    kind "relation"
    relation "planted | planted instead of"
    weight 2
  ]
  edge [
    source 711
    target 862
    kind "mentions"
  ]
  edge [
    source 711
    target 1129
    kind "mentions"
  ]
  edge [
    source 711
    target 1279
    kind "mentions"
  ]
  edge [
    source 711
    target 1282
    kind "mentions"
  ]
  edge [
    source 711
    target 1326
    kind "mentions"
  ]
  edge [
    source 711
    target 1162
    kind "relation"
    relation "is listed with"
    weight 1
  ]
  edge [
    source 712
    target 1278
    kind "mentions"
  ]
  edge [
    source 712
    target 1279
    kind "mentions"
  ]
  edge [
    source 712
    target 1280
    kind "relation"
    relation "allows saliva to act on"
    weight 1
  ]
  edge [
    source 712
    target 1288
    kind "mentions"
  ]
  edge [
    source 712
    target 1289
    kind "relation"
    relation "comes next to | is followed by"
    weight 2
  ]
  edge [
    source 712
    target 1315
    kind "mentions"
  ]
  edge [
    source 713
    target 720
    kind "mentions"
  ]
  edge [
    source 713
    target 1716
    kind "mentions"
  ]
  edge [
    source 713
    target 1724
    kind "mentions"
  ]
  edge [
    source 713
    target 1717
    kind "relation"
    relation "include"
    weight 1
  ]
  edge [
    source 714
    target 715
    kind "mentions"
  ]
  edge [
    source 714
    target 716
    kind "mentions"
  ]
  edge [
    source 714
    target 717
    kind "mentions"
  ]
  edge [
    source 714
    target 718
    kind "mentions"
  ]
  edge [
    source 714
    target 719
    kind "mentions"
  ]
  edge [
    source 714
    target 1941
    kind "summarizes"
  ]
  edge [
    source 715
    target 716
    kind "relation"
    relation "is used by | must turn starch into sugar"
    weight 2
  ]
  edge [
    source 715
    target 717
    kind "relation"
    relation "is not planted in"
    weight 1
  ]
  edge [
    source 715
    target 730
    kind "mentions"
  ]
  edge [
    source 715
    target 731
    kind "relation"
    relation "can be ground into"
    weight 1
  ]
  edge [
    source 715
    target 732
    kind "relation"
    relation "can be processed into"
    weight 1
  ]
  edge [
    source 715
    target 753
    kind "mentions"
  ]
  edge [
    source 716
    target 720
    kind "mentions"
  ]
  edge [
    source 716
    target 726
    kind "relation"
    relation "add hops to give"
    weight 1
  ]
  edge [
    source 717
    target 1074
    kind "mentions"
  ]
  edge [
    source 717
    target 1133
    kind "mentions"
  ]
  edge [
    source 717
    target 1132
    kind "relation"
    relation "come from"
    weight 1
  ]
  edge [
    source 718
    target 1016
    kind "mentions"
  ]
  edge [
    source 720
    target 721
    kind "mentions"
  ]
  edge [
    source 720
    target 722
    kind "mentions"
  ]
  edge [
    source 720
    target 723
    kind "mentions"
  ]
  edge [
    source 720
    target 724
    kind "mentions"
  ]
  edge [
    source 720
    target 725
    kind "mentions"
  ]
  edge [
    source 720
    target 726
    kind "mentions"
  ]
  edge [
    source 720
    target 727
    kind "mentions"
  ]
  edge [
    source 720
    target 728
    kind "mentions"
  ]
  edge [
    source 720
    target 1940
    kind "summarizes"
  ]
  edge [
    source 721
    target 725
    kind "relation"
    relation "is called"
    weight 1
  ]
  edge [
    source 729
    target 730
    kind "from_chunk"
  ]
  edge [
    source 729
    target 734
    kind "from_chunk"
  ]
  edge [
    source 729
    target 737
    kind "from_chunk"
  ]
  edge [
    source 730
    target 731
    kind "mentions"
  ]
  edge [
    source 730
    target 732
    kind "mentions"
  ]
  edge [
    source 730
    target 733
    kind "mentions"
  ]
  edge [
    source 730
    target 1941
    kind "summarizes"
  ]
  edge [
    source 732
    target 733
    kind "relation"
    relation "is used to thicken"
    weight 1
  ]
  edge [
    source 734
    target 735
    kind "mentions"
  ]
  edge [
    source 734
    target 736
    kind "mentions"
  ]
  edge [
    source 734
    target 1943
    kind "summarizes"
  ]
  edge [
    source 735
    target 737
    kind "mentions"
  ]
  edge [
    source 735
    target 738
    kind "relation"
    relation "is not suitable for"
    weight 1
  ]
  edge [
    source 736
    target 737
    kind "mentions"
  ]
  edge [
    source 736
    target 738
    kind "relation"
    relation "is suitable for"
    weight 1
  ]
  edge [
    source 736
    target 742
    kind "relation"
    relation "is more likely to be selected for"
    weight 1
  ]
  edge [
    source 736
    target 743
    kind "relation"
    relation "is more likely to be selected for"
    weight 1
  ]
  edge [
    source 737
    target 738
    kind "mentions"
  ]
  edge [
    source 737
    target 739
    kind "mentions"
  ]
  edge [
    source 737
    target 740
    kind "mentions"
  ]
  edge [
    source 737
    target 741
    kind "mentions"
  ]
  edge [
    source 737
    target 742
    kind "mentions"
  ]
  edge [
    source 737
    target 743
    kind "mentions"
  ]
  edge [
    source 737
    target 1943
    kind "summarizes"
  ]
  edge [
    source 744
    target 745
    kind "from_chunk"
  ]
  edge [
    source 744
    target 751
    kind "from_chunk"
  ]
  edge [
    source 745
    target 746
    kind "mentions"
  ]
  edge [
    source 745
    target 747
    kind "mentions"
  ]
  edge [
    source 745
    target 748
    kind "mentions"
  ]
  edge [
    source 745
    target 749
    kind "mentions"
  ]
  edge [
    source 745
    target 750
    kind "mentions"
  ]
  edge [
    source 745
    target 1940
    kind "summarizes"
  ]
  edge [
    source 747
    target 749
    kind "relation"
    relation "turns into drops of water when it touches"
    weight 1
  ]
  edge [
    source 747
    target 751
    kind "mentions"
  ]
  edge [
    source 747
    target 750
    kind "relation"
    relation "is used instead of"
    weight 1
  ]
  edge [
    source 747
    target 753
    kind "mentions"
  ]
  edge [
    source 750
    target 751
    kind "mentions"
  ]
  edge [
    source 750
    target 753
    kind "mentions"
  ]
  edge [
    source 750
    target 763
    kind "relation"
    relation "when heated produces"
    weight 1
  ]
  edge [
    source 750
    target 764
    kind "relation"
    relation "contains alcohol first, then water"
    weight 1
  ]
  edge [
    source 751
    target 1940
    kind "summarizes"
  ]
  edge [
    source 752
    target 753
    kind "from_chunk"
  ]
  edge [
    source 753
    target 754
    kind "mentions"
  ]
  edge [
    source 753
    target 755
    kind "mentions"
  ]
  edge [
    source 753
    target 756
    kind "mentions"
  ]
  edge [
    source 753
    target 757
    kind "mentions"
  ]
  edge [
    source 753
    target 758
    kind "mentions"
  ]
  edge [
    source 753
    target 759
    kind "mentions"
  ]
  edge [
    source 753
    target 760
    kind "mentions"
  ]
  edge [
    source 753
    target 761
    kind "mentions"
  ]
  edge [
    source 753
    target 762
    kind "mentions"
  ]
  edge [
    source 753
    target 763
    kind "mentions"
  ]
  edge [
    source 753
    target 764
    kind "mentions"
  ]
  edge [
    source 753
    target 765
    kind "mentions"
  ]
  edge [
    source 753
    target 766
    kind "mentions"
  ]
  edge [
    source 753
    target 767
    kind "mentions"
  ]
  edge [
    source 753
    target 768
    kind "mentions"
  ]
  edge [
    source 753
    target 769
    kind "mentions"
  ]
  edge [
    source 753
    target 770
    kind "mentions"
  ]
  edge [
    source 753
    target 771
    kind "mentions"
  ]
  edge [
    source 753
    target 772
    kind "mentions"
  ]
  edge [
    source 753
    target 773
    kind "mentions"
  ]
  edge [
    source 753
    target 774
    kind "mentions"
  ]
  edge [
    source 753
    target 1961
    kind "summarizes"
  ]
  edge [
    source 754
    target 767
    kind "relation"
    relation "increases alcohol concentration and reduces water content"
    weight 1
  ]
  edge [
    source 755
    target 789
    kind "mentions"
  ]
  edge [
    source 755
    target 798
    kind "mentions"
  ]
  edge [
    source 755
    target 757
    kind "relation"
    relation "leads to"
    weight 1
  ]
  edge [
    source 755
    target 756
    kind "relation"
    relation "leads to"
    weight 1
  ]
  edge [
    source 755
    target 1001
    kind "mentions"
  ]
  edge [
    source 756
    target 789
    kind "mentions"
  ]
  edge [
    source 756
    target 798
    kind "mentions"
  ]
  edge [
    source 756
    target 1382
    kind "mentions"
  ]
  edge [
    source 756
    target 1386
    kind "relation"
    relation "is distilled from"
    weight 1
  ]
  edge [
    source 756
    target 1387
    kind "relation"
    relation "contains about half alcohol"
    weight 1
  ]
  edge [
    source 756
    target 1388
    kind "relation"
    relation "were given | received twice the usual amount of | felt stronger when going without"
    weight 3
  ]
  edge [
    source 756
    target 1383
    kind "relation"
    relation "decided to sail without"
    weight 1
  ]
  edge [
    source 756
    target 1399
    kind "mentions"
  ]
  edge [
    source 757
    target 789
    kind "mentions"
  ]
  edge [
    source 757
    target 798
    kind "mentions"
  ]
  edge [
    source 757
    target 1813
    kind "mentions"
  ]
  edge [
    source 757
    target 1891
    kind "mentions"
  ]
  edge [
    source 758
    target 789
    kind "mentions"
  ]
  edge [
    source 759
    target 812
    kind "mentions"
  ]
  edge [
    source 759
    target 813
    kind "relation"
    relation "planted | planted instead of"
    weight 2
  ]
  edge [
    source 759
    target 862
    kind "mentions"
  ]
  edge [
    source 759
    target 1129
    kind "mentions"
  ]
  edge [
    source 759
    target 1166
    kind "mentions"
  ]
  edge [
    source 759
    target 1326
    kind "mentions"
  ]
  edge [
    source 759
    target 1130
    kind "relation"
    relation "is listed with"
    weight 1
  ]
  edge [
    source 759
    target 1920
    kind "mentions"
  ]
  edge [
    source 762
    target 850
    kind "mentions"
  ]
  edge [
    source 765
    target 766
    kind "relation"
    relation "must be distilled multiple times to become pure"
    weight 1
  ]
  edge [
    source 766
    target 788
    kind "mentions"
  ]
  edge [
    source 769
    target 770
    kind "relation"
    relation "injures more and faster than"
    weight 1
  ]
  edge [
    source 771
    target 772
    kind "relation"
    relation "are consumed in larger quantities"
    weight 1
  ]
  edge [
    source 772
    target 773
    kind "relation"
    relation "can become drunkards through excessive consumption"
    weight 1
  ]
  edge [
    source 774
    target 798
    kind "mentions"
  ]
  edge [
    source 774
    target 799
    kind "relation"
    relation "leads to increased desire for"
    weight 1
  ]
  edge [
    source 775
    target 776
    kind "from_chunk"
  ]
  edge [
    source 775
    target 778
    kind "from_chunk"
  ]
  edge [
    source 775
    target 782
    kind "from_chunk"
  ]
  edge [
    source 776
    target 777
    kind "mentions"
  ]
  edge [
    source 776
    target 1943
    kind "summarizes"
  ]
  edge [
    source 777
    target 805
    kind "mentions"
  ]
  edge [
    source 778
    target 779
    kind "mentions"
  ]
  edge [
    source 778
    target 780
    kind "mentions"
  ]
  edge [
    source 778
    target 781
    kind "mentions"
  ]
  edge [
    source 778
    target 1944
    kind "summarizes"
  ]
  edge [
    source 780
    target 1019
    kind "mentions"
  ]
  edge [
    source 780
    target 1024
    kind "relation"
    relation "produces | emits"
    weight 2
  ]
  edge [
    source 780
    target 1068
    kind "mentions"
  ]
  edge [
    source 780
    target 964
    kind "relation"
    relation "is unpleasant to"
    weight 1
  ]
  edge [
    source 782
    target 783
    kind "mentions"
  ]
  edge [
    source 782
    target 784
    kind "mentions"
  ]
  edge [
    source 782
    target 785
    kind "mentions"
  ]
  edge [
    source 782
    target 1940
    kind "summarizes"
  ]
  edge [
    source 783
    target 787
    kind "mentions"
  ]
  edge [
    source 786
    target 787
    kind "from_chunk"
  ]
  edge [
    source 786
    target 788
    kind "from_chunk"
  ]
  edge [
    source 786
    target 789
    kind "from_chunk"
  ]
  edge [
    source 786
    target 791
    kind "from_chunk"
  ]
  edge [
    source 786
    target 794
    kind "from_chunk"
  ]
  edge [
    source 786
    target 798
    kind "from_chunk"
  ]
  edge [
    source 786
    target 800
    kind "from_chunk"
  ]
  edge [
    source 787
    target 1940
    kind "summarizes"
  ]
  edge [
    source 788
    target 1961
    kind "summarizes"
  ]
  edge [
    source 789
    target 790
    kind "mentions"
  ]
  edge [
    source 789
    target 1943
    kind "summarizes"
  ]
  edge [
    source 791
    target 792
    kind "mentions"
  ]
  edge [
    source 791
    target 793
    kind "mentions"
  ]
  edge [
    source 791
    target 1953
    kind "summarizes"
  ]
  edge [
    source 792
    target 793
    kind "relation"
    relation "is formed in"
    weight 1
  ]
  edge [
    source 793
    target 805
    kind "mentions"
  ]
  edge [
    source 793
    target 811
    kind "relation"
    relation "is sometimes formed"
    weight 1
  ]
  edge [
    source 794
    target 795
    kind "mentions"
  ]
  edge [
    source 794
    target 796
    kind "mentions"
  ]
  edge [
    source 794
    target 797
    kind "mentions"
  ]
  edge [
    source 794
    target 1953
    kind "summarizes"
  ]
  edge [
    source 795
    target 805
    kind "mentions"
  ]
  edge [
    source 796
    target 805
    kind "mentions"
  ]
  edge [
    source 798
    target 799
    kind "mentions"
  ]
  edge [
    source 798
    target 1943
    kind "summarizes"
  ]
  edge [
    source 800
    target 801
    kind "mentions"
  ]
  edge [
    source 800
    target 802
    kind "mentions"
  ]
  edge [
    source 800
    target 803
    kind "mentions"
  ]
  edge [
    source 800
    target 1949
    kind "summarizes"
  ]
  edge [
    source 803
    target 850
    kind "mentions"
  ]
  edge [
    source 803
    target 1891
    kind "mentions"
  ]
  edge [
    source 803
    target 1907
    kind "mentions"
  ]
  edge [
    source 804
    target 805
    kind "from_chunk"
  ]
  edge [
    source 804
    target 812
    kind "from_chunk"
  ]
  edge [
    source 805
    target 806
    kind "mentions"
  ]
  edge [
    source 805
    target 807
    kind "mentions"
  ]
  edge [
    source 805
    target 808
    kind "mentions"
  ]
  edge [
    source 805
    target 809
    kind "mentions"
  ]
  edge [
    source 805
    target 810
    kind "mentions"
  ]
  edge [
    source 805
    target 811
    kind "mentions"
  ]
  edge [
    source 805
    target 1953
    kind "summarizes"
  ]
  edge [
    source 812
    target 813
    kind "mentions"
  ]
  edge [
    source 812
    target 814
    kind "mentions"
  ]
  edge [
    source 812
    target 815
    kind "mentions"
  ]
  edge [
    source 812
    target 816
    kind "mentions"
  ]
  edge [
    source 812
    target 817
    kind "mentions"
  ]
  edge [
    source 812
    target 818
    kind "mentions"
  ]
  edge [
    source 812
    target 819
    kind "mentions"
  ]
  edge [
    source 812
    target 820
    kind "mentions"
  ]
  edge [
    source 812
    target 821
    kind "mentions"
  ]
  edge [
    source 812
    target 822
    kind "mentions"
  ]
  edge [
    source 812
    target 823
    kind "mentions"
  ]
  edge [
    source 812
    target 824
    kind "mentions"
  ]
  edge [
    source 812
    target 825
    kind "mentions"
  ]
  edge [
    source 812
    target 826
    kind "mentions"
  ]
  edge [
    source 812
    target 827
    kind "mentions"
  ]
  edge [
    source 812
    target 1939
    kind "summarizes"
  ]
  edge [
    source 813
    target 814
    kind "relation"
    relation "planted | planted instead of"
    weight 2
  ]
  edge [
    source 813
    target 818
    kind "relation"
    relation "harvested"
    weight 1
  ]
  edge [
    source 813
    target 825
    kind "relation"
    relation "dried"
    weight 1
  ]
  edge [
    source 813
    target 820
    kind "relation"
    relation "processed into"
    weight 1
  ]
  edge [
    source 813
    target 821
    kind "relation"
    relation "processed into"
    weight 1
  ]
  edge [
    source 813
    target 822
    kind "relation"
    relation "processed into"
    weight 1
  ]
  edge [
    source 813
    target 862
    kind "mentions"
  ]
  edge [
    source 813
    target 1119
    kind "mentions"
  ]
  edge [
    source 813
    target 946
    kind "relation"
    relation "gives"
    weight 1
  ]
  edge [
    source 813
    target 1920
    kind "mentions"
  ]
  edge [
    source 813
    target 1921
    kind "relation"
    relation "did not do any good to"
    weight 1
  ]
  edge [
    source 814
    target 862
    kind "mentions"
  ]
  edge [
    source 814
    target 941
    kind "mentions"
  ]
  edge [
    source 814
    target 942
    kind "relation"
    relation "contains"
    weight 1
  ]
  edge [
    source 814
    target 1166
    kind "mentions"
  ]
  edge [
    source 814
    target 1252
    kind "mentions"
  ]
  edge [
    source 814
    target 949
    kind "relation"
    relation "are part of"
    weight 1
  ]
  edge [
    source 815
    target 816
    kind "relation"
    relation "grew as tall as"
    weight 1
  ]
  edge [
    source 815
    target 817
    kind "relation"
    relation "developed"
    weight 1
  ]
  edge [
    source 821
    target 1328
    kind "mentions"
  ]
  edge [
    source 821
    target 1330
    kind "relation"
    relation "were not included on"
    weight 1
  ]
  edge [
    source 821
    target 1891
    kind "mentions"
  ]
  edge [
    source 821
    target 1907
    kind "mentions"
  ]
  edge [
    source 823
    target 826
    kind "relation"
    relation "is a strong poison"
    weight 1
  ]
  edge [
    source 823
    target 859
    kind "mentions"
  ]
  edge [
    source 823
    target 862
    kind "mentions"
  ]
  edge [
    source 823
    target 824
    kind "relation"
    relation "can kill a"
    weight 1
  ]
  edge [
    source 823
    target 865
    kind "relation"
    relation "if taken pure from a cigar"
    weight 1
  ]
  edge [
    source 824
    target 827
    kind "relation"
    relation "is enough to kill"
    weight 1
  ]
  edge [
    source 824
    target 829
    kind "mentions"
  ]
  edge [
    source 824
    target 831
    kind "relation"
    relation "is enough to kill"
    weight 1
  ]
  edge [
    source 824
    target 862
    kind "mentions"
  ]
  edge [
    source 826
    target 1164
    kind "mentions"
  ]
  edge [
    source 826
    target 945
    kind "relation"
    relation "is the best kind of food"
    weight 1
  ]
  edge [
    source 828
    target 829
    kind "from_chunk"
  ]
  edge [
    source 828
    target 834
    kind "from_chunk"
  ]
  edge [
    source 828
    target 840
    kind "from_chunk"
  ]
  edge [
    source 828
    target 846
    kind "from_chunk"
  ]
  edge [
    source 828
    target 850
    kind "from_chunk"
  ]
  edge [
    source 828
    target 854
    kind "from_chunk"
  ]
  edge [
    source 829
    target 830
    kind "mentions"
  ]
  edge [
    source 829
    target 831
    kind "mentions"
  ]
  edge [
    source 829
    target 832
    kind "mentions"
  ]
  edge [
    source 829
    target 833
    kind "mentions"
  ]
  edge [
    source 829
    target 1939
    kind "summarizes"
  ]
  edge [
    source 832
    target 833
    kind "relation"
    relation "when taken pure is enough to kill"
    weight 1
  ]
  edge [
    source 834
    target 835
    kind "mentions"
  ]
  edge [
    source 834
    target 836
    kind "mentions"
  ]
  edge [
    source 834
    target 837
    kind "mentions"
  ]
  edge [
    source 834
    target 838
    kind "mentions"
  ]
  edge [
    source 834
    target 839
    kind "mentions"
  ]
  edge [
    source 834
    target 1949
    kind "summarizes"
  ]
  edge [
    source 835
    target 840
    kind "mentions"
  ]
  edge [
    source 835
    target 841
    kind "relation"
    relation "stood beside"
    weight 1
  ]
  edge [
    source 835
    target 843
    kind "relation"
    relation "bent over"
    weight 1
  ]
  edge [
    source 836
    target 839
    kind "relation"
    relation "is so strong that"
    weight 1
  ]
  edge [
    source 837
    target 1335
    kind "mentions"
  ]
  edge [
    source 837
    target 1508
    kind "mentions"
  ]
  edge [
    source 840
    target 841
    kind "mentions"
  ]
  edge [
    source 840
    target 842
    kind "mentions"
  ]
  edge [
    source 840
    target 843
    kind "mentions"
  ]
  edge [
    source 840
    target 844
    kind "mentions"
  ]
  edge [
    source 840
    target 845
    kind "mentions"
  ]
  edge [
    source 840
    target 1949
    kind "summarizes"
  ]
  edge [
    source 841
    target 842
    kind "relation"
    relation "turned"
    weight 1
  ]
  edge [
    source 844
    target 845
    kind "relation"
    relation "was blowing through"
    weight 1
  ]
  edge [
    source 846
    target 847
    kind "mentions"
  ]
  edge [
    source 846
    target 848
    kind "mentions"
  ]
  edge [
    source 846
    target 849
    kind "mentions"
  ]
  edge [
    source 846
    target 1949
    kind "summarizes"
  ]
  edge [
    source 850
    target 851
    kind "mentions"
  ]
  edge [
    source 850
    target 852
    kind "mentions"
  ]
  edge [
    source 850
    target 853
    kind "mentions"
  ]
  edge [
    source 850
    target 1961
    kind "summarizes"
  ]
  edge [
    source 854
    target 855
    kind "mentions"
  ]
  edge [
    source 854
    target 856
    kind "mentions"
  ]
  edge [
    source 854
    target 857
    kind "mentions"
  ]
  edge [
    source 854
    target 1949
    kind "summarizes"
  ]
  edge [
    source 858
    target 859
    kind "from_chunk"
  ]
  edge [
    source 858
    target 862
    kind "from_chunk"
  ]
  edge [
    source 858
    target 866
    kind "from_chunk"
  ]
  edge [
    source 859
    target 860
    kind "mentions"
  ]
  edge [
    source 859
    target 861
    kind "mentions"
  ]
  edge [
    source 859
    target 1947
    kind "summarizes"
  ]
  edge [
    source 860
    target 1019
    kind "mentions"
  ]
  edge [
    source 860
    target 1021
    kind "relation"
    relation "emits strong bad smell"
    weight 1
  ]
  edge [
    source 862
    target 863
    kind "mentions"
  ]
  edge [
    source 862
    target 864
    kind "mentions"
  ]
  edge [
    source 862
    target 865
    kind "mentions"
  ]
  edge [
    source 862
    target 1939
    kind "summarizes"
  ]
  edge [
    source 864
    target 1019
    kind "mentions"
  ]
  edge [
    source 866
    target 867
    kind "mentions"
  ]
  edge [
    source 866
    target 868
    kind "mentions"
  ]
  edge [
    source 866
    target 869
    kind "mentions"
  ]
  edge [
    source 866
    target 870
    kind "mentions"
  ]
  edge [
    source 866
    target 871
    kind "mentions"
  ]
  edge [
    source 866
    target 872
    kind "mentions"
  ]
  edge [
    source 866
    target 873
    kind "mentions"
  ]
  edge [
    source 866
    target 874
    kind "mentions"
  ]
  edge [
    source 866
    target 875
    kind "mentions"
  ]
  edge [
    source 866
    target 1954
    kind "summarizes"
  ]
  edge [
    source 870
    target 871
    kind "relation"
    relation "are given to | are kept from crying by"
    weight 2
  ]
  edge [
    source 870
    target 874
    kind "relation"
    relation "injure"
    weight 1
  ]
  edge [
    source 870
    target 875
    kind "relation"
    relation "poison"
    weight 1
  ]
  edge [
    source 874
    target 877
    kind "mentions"
  ]
  edge [
    source 876
    target 877
    kind "from_chunk"
  ]
  edge [
    source 876
    target 882
    kind "from_chunk"
  ]
  edge [
    source 876
    target 887
    kind "from_chunk"
  ]
  edge [
    source 876
    target 893
    kind "from_chunk"
  ]
  edge [
    source 877
    target 878
    kind "mentions"
  ]
  edge [
    source 877
    target 879
    kind "mentions"
  ]
  edge [
    source 877
    target 880
    kind "mentions"
  ]
  edge [
    source 877
    target 881
    kind "mentions"
  ]
  edge [
    source 877
    target 1954
    kind "summarizes"
  ]
  edge [
    source 878
    target 880
    kind "relation"
    relation "appears as a friend"
    weight 1
  ]
  edge [
    source 878
    target 882
    kind "mentions"
  ]
  edge [
    source 878
    target 883
    kind "relation"
    relation "should not be tempted to quiet | should take best and kindest care of"
    weight 2
  ]
  edge [
    source 882
    target 883
    kind "mentions"
  ]
  edge [
    source 882
    target 884
    kind "mentions"
  ]
  edge [
    source 882
    target 885
    kind "mentions"
  ]
  edge [
    source 882
    target 886
    kind "mentions"
  ]
  edge [
    source 882
    target 1954
    kind "summarizes"
  ]
  edge [
    source 883
    target 884
    kind "relation"
    relation "may be left with"
    weight 1
  ]
  edge [
    source 883
    target 1756
    kind "mentions"
  ]
  edge [
    source 887
    target 888
    kind "mentions"
  ]
  edge [
    source 887
    target 889
    kind "mentions"
  ]
  edge [
    source 887
    target 890
    kind "mentions"
  ]
  edge [
    source 887
    target 891
    kind "mentions"
  ]
  edge [
    source 887
    target 892
    kind "mentions"
  ]
  edge [
    source 887
    target 1955
    kind "summarizes"
  ]
  edge [
    source 889
    target 890
    kind "relation"
    relation "is the organ of"
    weight 1
  ]
  edge [
    source 889
    target 1648
    kind "mentions"
  ]
  edge [
    source 889
    target 1649
    kind "relation"
    relation "is located in"
    weight 1
  ]
  edge [
    source 889
    target 1650
    kind "mentions"
  ]
  edge [
    source 889
    target 1651
    kind "relation"
    relation "takes pictures of"
    weight 1
  ]
  edge [
    source 889
    target 1724
    kind "mentions"
  ]
  edge [
    source 889
    target 1725
    kind "relation"
    relation "controls amount of light"
    weight 1
  ]
  edge [
    source 891
    target 928
    kind "mentions"
  ]
  edge [
    source 891
    target 926
    kind "relation"
    relation "contains"
    weight 1
  ]
  edge [
    source 891
    target 938
    kind "mentions"
  ]
  edge [
    source 891
    target 939
    kind "relation"
    relation "has a lining that produces | is always ready for use | mixes with | mixes food with"
    weight 4
  ]
  edge [
    source 891
    target 941
    kind "mentions"
  ]
  edge [
    source 891
    target 942
    kind "relation"
    relation "is like"
    weight 1
  ]
  edge [
    source 891
    target 917
    kind "relation"
    relation "takes in"
    weight 1
  ]
  edge [
    source 891
    target 949
    kind "relation"
    relation "takes in"
    weight 1
  ]
  edge [
    source 891
    target 950
    kind "relation"
    relation "takes in"
    weight 1
  ]
  edge [
    source 891
    target 947
    kind "relation"
    relation "squeezes with"
    weight 1
  ]
  edge [
    source 891
    target 948
    kind "relation"
    relation "changes food into"
    weight 1
  ]
  edge [
    source 891
    target 951
    kind "mentions"
  ]
  edge [
    source 891
    target 960
    kind "mentions"
  ]
  edge [
    source 891
    target 978
    kind "mentions"
  ]
  edge [
    source 891
    target 992
    kind "mentions"
  ]
  edge [
    source 891
    target 894
    kind "relation"
    relation "needs rest | must work faithfully"
    weight 2
  ]
  edge [
    source 891
    target 997
    kind "relation"
    relation "wears out if no rest"
    weight 1
  ]
  edge [
    source 891
    target 994
    kind "relation"
    relation "stops digestive process when poured into stomach"
    weight 1
  ]
  edge [
    source 891
    target 998
    kind "mentions"
  ]
  edge [
    source 891
    target 1001
    kind "mentions"
  ]
  edge [
    source 891
    target 1025
    kind "mentions"
  ]
  edge [
    source 891
    target 1046
    kind "relation"
    relation "is an organ"
    weight 1
  ]
  edge [
    source 891
    target 1058
    kind "mentions"
  ]
  edge [
    source 891
    target 1248
    kind "mentions"
  ]
  edge [
    source 891
    target 1261
    kind "mentions"
  ]
  edge [
    source 891
    target 1127
    kind "relation"
    relation "prepares"
    weight 1
  ]
  edge [
    source 891
    target 1286
    kind "mentions"
  ]
  edge [
    source 891
    target 1007
    kind "relation"
    relation "has extra work"
    weight 1
  ]
  edge [
    source 891
    target 1287
    kind "relation"
    relation "aches"
    weight 1
  ]
  edge [
    source 891
    target 1288
    kind "mentions"
  ]
  edge [
    source 891
    target 1292
    kind "relation"
    relation "leads to"
    weight 1
  ]
  edge [
    source 891
    target 1293
    kind "mentions"
  ]
  edge [
    source 891
    target 1298
    kind "mentions"
  ]
  edge [
    source 891
    target 1302
    kind "mentions"
  ]
  edge [
    source 891
    target 1435
    kind "mentions"
  ]
  edge [
    source 891
    target 1178
    kind "relation"
    relation "prepares food for"
    weight 2
  ]
  edge [
    source 891
    target 1514
    kind "mentions"
  ]
  edge [
    source 891
    target 1527
    kind "mentions"
  ]
  edge [
    source 891
    target 1625
    kind "mentions"
  ]
  edge [
    source 891
    target 1863
    kind "mentions"
  ]
  edge [
    source 893
    target 894
    kind "mentions"
  ]
  edge [
    source 893
    target 895
    kind "mentions"
  ]
  edge [
    source 893
    target 896
    kind "mentions"
  ]
  edge [
    source 893
    target 897
    kind "mentions"
  ]
  edge [
    source 893
    target 898
    kind "mentions"
  ]
  edge [
    source 893
    target 1952
    kind "summarizes"
  ]
  edge [
    source 894
    target 900
    kind "mentions"
  ]
  edge [
    source 894
    target 901
    kind "relation"
    relation "is broken when | breaks | cannot be mended once broken"
    weight 3
  ]
  edge [
    source 894
    target 904
    kind "relation"
    relation "decay when"
    weight 1
  ]
  edge [
    source 894
    target 905
    kind "mentions"
  ]
  edge [
    source 894
    target 914
    kind "relation"
    relation "should be picked from between"
    weight 1
  ]
  edge [
    source 894
    target 924
    kind "relation"
    relation "must not decay"
    weight 1
  ]
  edge [
    source 894
    target 992
    kind "mentions"
  ]
  edge [
    source 894
    target 1006
    kind "mentions"
  ]
  edge [
    source 894
    target 1013
    kind "mentions"
  ]
  edge [
    source 894
    target 1025
    kind "mentions"
  ]
  edge [
    source 894
    target 1037
    kind "relation"
    relation "are made of"
    weight 1
  ]
  edge [
    source 894
    target 1041
    kind "relation"
    relation "should be well brushed to"
    weight 1
  ]
  edge [
    source 894
    target 1042
    kind "relation"
    relation "should be brushed"
    weight 1
  ]
  edge [
    source 894
    target 1065
    kind "mentions"
  ]
  edge [
    source 895
    target 900
    kind "mentions"
  ]
  edge [
    source 895
    target 1025
    kind "mentions"
  ]
  edge [
    source 895
    target 1035
    kind "relation"
    relation "do"
    weight 1
  ]
  edge [
    source 896
    target 900
    kind "mentions"
  ]
  edge [
    source 896
    target 1025
    kind "mentions"
  ]
  edge [
    source 896
    target 1036
    kind "relation"
    relation "do"
    weight 1
  ]
  edge [
    source 899
    target 900
    kind "from_chunk"
  ]
  edge [
    source 899
    target 905
    kind "from_chunk"
  ]
  edge [
    source 899
    target 925
    kind "from_chunk"
  ]
  edge [
    source 900
    target 901
    kind "mentions"
  ]
  edge [
    source 900
    target 902
    kind "mentions"
  ]
  edge [
    source 900
    target 903
    kind "mentions"
  ]
  edge [
    source 900
    target 904
    kind "mentions"
  ]
  edge [
    source 900
    target 1952
    kind "summarizes"
  ]
  edge [
    source 901
    target 905
    kind "mentions"
  ]
  edge [
    source 901
    target 906
    kind "relation"
    relation "is apt to break"
    weight 1
  ]
  edge [
    source 901
    target 907
    kind "relation"
    relation "is apt to break"
    weight 1
  ]
  edge [
    source 901
    target 1025
    kind "mentions"
  ]
  edge [
    source 901
    target 1039
    kind "relation"
    relation "is often broken by"
    weight 1
  ]
  edge [
    source 901
    target 1065
    kind "mentions"
  ]
  edge [
    source 903
    target 1261
    kind "mentions"
  ]
  edge [
    source 905
    target 906
    kind "mentions"
  ]
  edge [
    source 905
    target 907
    kind "mentions"
  ]
  edge [
    source 905
    target 908
    kind "mentions"
  ]
  edge [
    source 905
    target 909
    kind "mentions"
  ]
  edge [
    source 905
    target 910
    kind "mentions"
  ]
  edge [
    source 905
    target 911
    kind "mentions"
  ]
  edge [
    source 905
    target 912
    kind "mentions"
  ]
  edge [
    source 905
    target 913
    kind "mentions"
  ]
  edge [
    source 905
    target 914
    kind "mentions"
  ]
  edge [
    source 905
    target 915
    kind "mentions"
  ]
  edge [
    source 905
    target 916
    kind "mentions"
  ]
  edge [
    source 905
    target 917
    kind "mentions"
  ]
  edge [
    source 905
    target 918
    kind "mentions"
  ]
  edge [
    source 905
    target 919
    kind "mentions"
  ]
  edge [
    source 905
    target 920
    kind "mentions"
  ]
  edge [
    source 905
    target 921
    kind "mentions"
  ]
  edge [
    source 905
    target 922
    kind "mentions"
  ]
  edge [
    source 905
    target 923
    kind "mentions"
  ]
  edge [
    source 905
    target 924
    kind "mentions"
  ]
  edge [
    source 905
    target 1952
    kind "summarizes"
  ]
  edge [
    source 908
    target 909
    kind "relation"
    relation "can fill"
    weight 1
  ]
  edge [
    source 908
    target 921
    kind "relation"
    relation "cannot cover"
    weight 1
  ]
  edge [
    source 910
    target 922
    kind "relation"
    relation "is made of"
    weight 1
  ]
  edge [
    source 910
    target 913
    kind "relation"
    relation "should not be made of"
    weight 1
  ]
  edge [
    source 910
    target 1025
    kind "mentions"
  ]
  edge [
    source 910
    target 1040
    kind "relation"
    relation "should be used to"
    weight 1
  ]
  edge [
    source 913
    target 1689
    kind "mentions"
  ]
  edge [
    source 913
    target 1695
    kind "relation"
    relation "sometimes insert"
    weight 1
  ]
  edge [
    source 913
    target 1696
    kind "relation"
    relation "breaks | is broken by"
    weight 2
  ]
  edge [
    source 915
    target 916
    kind "relation"
    relation "is necessary for"
    weight 1
  ]
  edge [
    source 915
    target 917
    kind "relation"
    relation "should occur before | tastes better when"
    weight 2
  ]
  edge [
    source 915
    target 918
    kind "relation"
    relation "should occur before"
    weight 1
  ]
  edge [
    source 916
    target 923
    kind "relation"
    relation "keeps"
    weight 1
  ]
  edge [
    source 916
    target 1637
    kind "mentions"
  ]
  edge [
    source 916
    target 1619
    kind "relation"
    relation "should be removed to maintain"
    weight 1
  ]
  edge [
    source 917
    target 941
    kind "mentions"
  ]
  edge [
    source 917
    target 968
    kind "mentions"
  ]
  edge [
    source 918
    target 919
    kind "relation"
    relation "happens in mouth during"
    weight 1
  ]
  edge [
    source 918
    target 1514
    kind "mentions"
  ]
  edge [
    source 918
    target 1611
    kind "mentions"
  ]
  edge [
    source 918
    target 1023
    kind "relation"
    relation "should not be worn through"
    weight 1
  ]
  edge [
    source 918
    target 1634
    kind "mentions"
  ]
  edge [
    source 918
    target 1635
    kind "relation"
    relation "should be changed at"
    weight 1
  ]
  edge [
    source 925
    target 926
    kind "mentions"
  ]
  edge [
    source 925
    target 1952
    kind "summarizes"
  ]
  edge [
    source 926
    target 928
    kind "mentions"
  ]
  edge [
    source 926
    target 931
    kind "relation"
    relation "contains"
    weight 1
  ]
  edge [
    source 926
    target 937
    kind "relation"
    relation "contains"
    weight 1
  ]
  edge [
    source 926
    target 1025
    kind "mentions"
  ]
  edge [
    source 926
    target 1045
    kind "relation"
    relation "contains"
    weight 1
  ]
  edge [
    source 927
    target 928
    kind "from_chunk"
  ]
  edge [
    source 927
    target 938
    kind "from_chunk"
  ]
  edge [
    source 928
    target 929
    kind "mentions"
  ]
  edge [
    source 928
    target 930
    kind "mentions"
  ]
  edge [
    source 928
    target 931
    kind "mentions"
  ]
  edge [
    source 928
    target 932
    kind "mentions"
  ]
  edge [
    source 928
    target 933
    kind "mentions"
  ]
  edge [
    source 928
    target 934
    kind "mentions"
  ]
  edge [
    source 928
    target 935
    kind "mentions"
  ]
  edge [
    source 928
    target 936
    kind "mentions"
  ]
  edge [
    source 928
    target 937
    kind "mentions"
  ]
  edge [
    source 928
    target 1956
    kind "summarizes"
  ]
  edge [
    source 929
    target 934
    kind "relation"
    relation "curve to"
    weight 1
  ]
  edge [
    source 929
    target 1427
    kind "mentions"
  ]
  edge [
    source 930
    target 1302
    kind "mentions"
  ]
  edge [
    source 930
    target 1178
    kind "relation"
    relation "carries nutrients to | pumps | removes worn-out matter"
    weight 3
  ]
  edge [
    source 930
    target 1427
    kind "mentions"
  ]
  edge [
    source 930
    target 1433
    kind "relation"
    relation "is made of"
    weight 1
  ]
  edge [
    source 930
    target 1430
    kind "relation"
    relation "functions like"
    weight 1
  ]
  edge [
    source 930
    target 1435
    kind "mentions"
  ]
  edge [
    source 930
    target 1432
    kind "relation"
    relation "carry blood away from"
    weight 2
  ]
  edge [
    source 930
    target 1436
    kind "relation"
    relation "bring blood back to | carry blood back to"
    weight 2
  ]
  edge [
    source 930
    target 1450
    kind "mentions"
  ]
  edge [
    source 930
    target 1455
    kind "relation"
    relation "rests between"
    weight 2
  ]
  edge [
    source 930
    target 1456
    kind "relation"
    relation "improves function of"
    weight 2
  ]
  edge [
    source 930
    target 1457
    kind "mentions"
  ]
  edge [
    source 930
    target 1462
    kind "mentions"
  ]
  edge [
    source 930
    target 1463
    kind "relation"
    relation "does the work of"
    weight 1
  ]
  edge [
    source 930
    target 1467
    kind "mentions"
  ]
  edge [
    source 930
    target 1474
    kind "relation"
    relation "does not pump out"
    weight 1
  ]
  edge [
    source 930
    target 1477
    kind "mentions"
  ]
  edge [
    source 930
    target 1481
    kind "mentions"
  ]
  edge [
    source 930
    target 1482
    kind "relation"
    relation "returns to"
    weight 1
  ]
  edge [
    source 930
    target 1514
    kind "mentions"
  ]
  edge [
    source 930
    target 1527
    kind "mentions"
  ]
  edge [
    source 930
    target 1625
    kind "mentions"
  ]
  edge [
    source 930
    target 1351
    kind "relation"
    relation "pumps blood to | carries food to"
    weight 2
  ]
  edge [
    source 930
    target 1774
    kind "mentions"
  ]
  edge [
    source 931
    target 1071
    kind "mentions"
  ]
  edge [
    source 931
    target 1225
    kind "mentions"
  ]
  edge [
    source 931
    target 1226
    kind "relation"
    relation "harms"
    weight 1
  ]
  edge [
    source 932
    target 933
    kind "relation"
    relation "is divided by"
    weight 1
  ]
  edge [
    source 933
    target 936
    kind "relation"
    relation "divides the box into"
    weight 1
  ]
  edge [
    source 938
    target 939
    kind "mentions"
  ]
  edge [
    source 938
    target 1952
    kind "summarizes"
  ]
  edge [
    source 939
    target 941
    kind "mentions"
  ]
  edge [
    source 939
    target 1001
    kind "mentions"
  ]
  edge [
    source 939
    target 1025
    kind "mentions"
  ]
  edge [
    source 939
    target 1058
    kind "mentions"
  ]
  edge [
    source 939
    target 1302
    kind "mentions"
  ]
  edge [
    source 940
    target 941
    kind "from_chunk"
  ]
  edge [
    source 940
    target 951
    kind "from_chunk"
  ]
  edge [
    source 941
    target 942
    kind "mentions"
  ]
  edge [
    source 941
    target 943
    kind "mentions"
  ]
  edge [
    source 941
    target 944
    kind "mentions"
  ]
  edge [
    source 941
    target 945
    kind "mentions"
  ]
  edge [
    source 941
    target 946
    kind "mentions"
  ]
  edge [
    source 941
    target 947
    kind "mentions"
  ]
  edge [
    source 941
    target 948
    kind "mentions"
  ]
  edge [
    source 941
    target 949
    kind "mentions"
  ]
  edge [
    source 941
    target 950
    kind "mentions"
  ]
  edge [
    source 941
    target 1939
    kind "summarizes"
  ]
  edge [
    source 942
    target 943
    kind "relation"
    relation "contains"
    weight 1
  ]
  edge [
    source 942
    target 944
    kind "relation"
    relation "contains"
    weight 1
  ]
  edge [
    source 942
    target 945
    kind "relation"
    relation "contains"
    weight 1
  ]
  edge [
    source 942
    target 946
    kind "relation"
    relation "contains"
    weight 1
  ]
  edge [
    source 944
    target 1100
    kind "mentions"
  ]
  edge [
    source 944
    target 1116
    kind "mentions"
  ]
  edge [
    source 944
    target 1112
    kind "relation"
    relation "is present in"
    weight 1
  ]
  edge [
    source 944
    target 1252
    kind "mentions"
  ]
  edge [
    source 944
    target 949
    kind "relation"
    relation "is part of"
    weight 1
  ]
  edge [
    source 944
    target 1259
    kind "relation"
    relation "must be cooked before"
    weight 1
  ]
  edge [
    source 944
    target 1261
    kind "mentions"
  ]
  edge [
    source 944
    target 1127
    kind "relation"
    relation "must be cooked"
    weight 1
  ]
  edge [
    source 945
    target 968
    kind "mentions"
  ]
  edge [
    source 945
    target 972
    kind "relation"
    relation "does not look like"
    weight 1
  ]
  edge [
    source 945
    target 1106
    kind "mentions"
  ]
  edge [
    source 945
    target 1108
    kind "relation"
    relation "turn into"
    weight 1
  ]
  edge [
    source 945
    target 1109
    kind "relation"
    relation "contains lime"
    weight 1
  ]
  edge [
    source 945
    target 1129
    kind "mentions"
  ]
  edge [
    source 945
    target 1132
    kind "relation"
    relation "include"
    weight 1
  ]
  edge [
    source 945
    target 1164
    kind "mentions"
  ]
  edge [
    source 945
    target 1326
    kind "mentions"
  ]
  edge [
    source 946
    target 1119
    kind "mentions"
  ]
  edge [
    source 946
    target 1120
    kind "relation"
    relation "need"
    weight 1
  ]
  edge [
    source 946
    target 1108
    kind "relation"
    relation "lick up"
    weight 1
  ]
  edge [
    source 946
    target 1121
    kind "relation"
    relation "lick up"
    weight 1
  ]
  edge [
    source 946
    target 1122
    kind "relation"
    relation "go in great herds to get"
    weight 1
  ]
  edge [
    source 946
    target 1123
    kind "relation"
    relation "go in great herds to get"
    weight 1
  ]
  edge [
    source 946
    target 1126
    kind "mentions"
  ]
  edge [
    source 946
    target 1212
    kind "mentions"
  ]
  edge [
    source 946
    target 1213
    kind "relation"
    relation "is essential for"
    weight 1
  ]
  edge [
    source 946
    target 1252
    kind "mentions"
  ]
  edge [
    source 946
    target 949
    kind "relation"
    relation "is part of"
    weight 1
  ]
  edge [
    source 946
    target 1326
    kind "mentions"
  ]
  edge [
    source 949
    target 1252
    kind "mentions"
  ]
  edge [
    source 949
    target 1253
    kind "relation"
    relation "is part of"
    weight 1
  ]
  edge [
    source 949
    target 1254
    kind "relation"
    relation "are part of"
    weight 1
  ]
  edge [
    source 949
    target 1255
    kind "relation"
    relation "is part of"
    weight 1
  ]
  edge [
    source 949
    target 1159
    kind "relation"
    relation "is part of"
    weight 1
  ]
  edge [
    source 949
    target 1256
    kind "relation"
    relation "are part of"
    weight 1
  ]
  edge [
    source 949
    target 1257
    kind "relation"
    relation "are part of"
    weight 1
  ]
  edge [
    source 949
    target 1258
    kind "relation"
    relation "are part of"
    weight 1
  ]
  edge [
    source 949
    target 1302
    kind "mentions"
  ]
  edge [
    source 949
    target 1304
    kind "relation"
    relation "helps repair"
    weight 1
  ]
  edge [
    source 949
    target 1307
    kind "mentions"
  ]
  edge [
    source 949
    target 1312
    kind "relation"
    relation "feeds"
    weight 1
  ]
  edge [
    source 949
    target 1308
    kind "relation"
    relation "mends"
    weight 1
  ]
  edge [
    source 949
    target 1315
    kind "mentions"
  ]
  edge [
    source 951
    target 952
    kind "mentions"
  ]
  edge [
    source 951
    target 953
    kind "mentions"
  ]
  edge [
    source 951
    target 954
    kind "mentions"
  ]
  edge [
    source 951
    target 955
    kind "mentions"
  ]
  edge [
    source 951
    target 956
    kind "mentions"
  ]
  edge [
    source 951
    target 957
    kind "mentions"
  ]
  edge [
    source 951
    target 958
    kind "mentions"
  ]
  edge [
    source 951
    target 1960
    kind "summarizes"
  ]
  edge [
    source 952
    target 953
    kind "relation"
    relation "was shot in"
    weight 1
  ]
  edge [
    source 954
    target 955
    kind "relation"
    relation "has"
    weight 1
  ]
  edge [
    source 954
    target 956
    kind "relation"
    relation "forms"
    weight 1
  ]
  edge [
    source 956
    target 957
    kind "relation"
    relation "is like"
    weight 1
  ]
  edge [
    source 959
    target 960
    kind "from_chunk"
  ]
  edge [
    source 959
    target 965
    kind "from_chunk"
  ]
  edge [
    source 959
    target 968
    kind "from_chunk"
  ]
  edge [
    source 959
    target 978
    kind "from_chunk"
  ]
  edge [
    source 960
    target 961
    kind "mentions"
  ]
  edge [
    source 960
    target 962
    kind "mentions"
  ]
  edge [
    source 960
    target 963
    kind "mentions"
  ]
  edge [
    source 960
    target 964
    kind "mentions"
  ]
  edge [
    source 960
    target 1944
    kind "summarizes"
  ]
  edge [
    source 962
    target 964
    kind "relation"
    relation "is shared with"
    weight 1
  ]
  edge [
    source 964
    target 1068
    kind "mentions"
  ]
  edge [
    source 964
    target 1069
    kind "relation"
    relation "are unpleasant to"
    weight 1
  ]
  edge [
    source 965
    target 966
    kind "mentions"
  ]
  edge [
    source 965
    target 967
    kind "mentions"
  ]
  edge [
    source 965
    target 1948
    kind "summarizes"
  ]
  edge [
    source 968
    target 969
    kind "mentions"
  ]
  edge [
    source 968
    target 970
    kind "mentions"
  ]
  edge [
    source 968
    target 971
    kind "mentions"
  ]
  edge [
    source 968
    target 972
    kind "mentions"
  ]
  edge [
    source 968
    target 973
    kind "mentions"
  ]
  edge [
    source 968
    target 974
    kind "mentions"
  ]
  edge [
    source 968
    target 975
    kind "mentions"
  ]
  edge [
    source 968
    target 976
    kind "mentions"
  ]
  edge [
    source 968
    target 977
    kind "mentions"
  ]
  edge [
    source 968
    target 1950
    kind "summarizes"
  ]
  edge [
    source 969
    target 975
    kind "relation"
    relation "says eating"
    weight 1
  ]
  edge [
    source 969
    target 976
    kind "relation"
    relation "says eating oat-meal and milk helps"
    weight 1
  ]
  edge [
    source 970
    target 971
    kind "relation"
    relation "does not look like"
    weight 1
  ]
  edge [
    source 974
    target 1025
    kind "mentions"
  ]
  edge [
    source 978
    target 979
    kind "mentions"
  ]
  edge [
    source 978
    target 980
    kind "mentions"
  ]
  edge [
    source 978
    target 981
    kind "mentions"
  ]
  edge [
    source 978
    target 982
    kind "mentions"
  ]
  edge [
    source 978
    target 983
    kind "mentions"
  ]
  edge [
    source 978
    target 984
    kind "mentions"
  ]
  edge [
    source 978
    target 985
    kind "mentions"
  ]
  edge [
    source 978
    target 986
    kind "mentions"
  ]
  edge [
    source 978
    target 1951
    kind "summarizes"
  ]
  edge [
    source 980
    target 986
    kind "relation"
    relation "need feeding"
    weight 1
  ]
  edge [
    source 981
    target 986
    kind "relation"
    relation "need feeding"
    weight 1
  ]
  edge [
    source 981
    target 988
    kind "mentions"
  ]
  edge [
    source 981
    target 1302
    kind "mentions"
  ]
  edge [
    source 981
    target 1541
    kind "mentions"
  ]
  edge [
    source 981
    target 1550
    kind "mentions"
  ]
  edge [
    source 981
    target 1557
    kind "relation"
    relation "continuously exits through"
    weight 1
  ]
  edge [
    source 981
    target 1571
    kind "mentions"
  ]
  edge [
    source 981
    target 1611
    kind "mentions"
  ]
  edge [
    source 981
    target 1625
    kind "mentions"
  ]
  edge [
    source 981
    target 1582
    kind "relation"
    relation "carries away waste matter through"
    weight 1
  ]
  edge [
    source 981
    target 1779
    kind "mentions"
  ]
  edge [
    source 981
    target 1786
    kind "mentions"
  ]
  edge [
    source 982
    target 986
    kind "relation"
    relation "need feeding"
    weight 1
  ]
  edge [
    source 983
    target 986
    kind "relation"
    relation "need feeding"
    weight 1
  ]
  edge [
    source 983
    target 1302
    kind "mentions"
  ]
  edge [
    source 984
    target 986
    kind "relation"
    relation "need feeding"
    weight 1
  ]
  edge [
    source 984
    target 1302
    kind "mentions"
  ]
  edge [
    source 984
    target 1643
    kind "mentions"
  ]
  edge [
    source 984
    target 1663
    kind "mentions"
  ]
  edge [
    source 984
    target 1673
    kind "relation"
    relation "caused harm to"
    weight 1
  ]
  edge [
    source 984
    target 1676
    kind "mentions"
  ]
  edge [
    source 984
    target 1677
    kind "relation"
    relation "tried to turn | could not turn back"
    weight 2
  ]
  edge [
    source 984
    target 1681
    kind "mentions"
  ]
  edge [
    source 984
    target 1684
    kind "relation"
    relation "must not be given too much | must be given enough"
    weight 2
  ]
  edge [
    source 984
    target 1724
    kind "mentions"
  ]
  edge [
    source 984
    target 1540
    kind "relation"
    relation "must be careful of"
    weight 1
  ]
  edge [
    source 985
    target 1001
    kind "mentions"
  ]
  edge [
    source 987
    target 988
    kind "from_chunk"
  ]
  edge [
    source 987
    target 992
    kind "from_chunk"
  ]
  edge [
    source 987
    target 998
    kind "from_chunk"
  ]
  edge [
    source 988
    target 989
    kind "mentions"
  ]
  edge [
    source 988
    target 990
    kind "mentions"
  ]
  edge [
    source 988
    target 991
    kind "mentions"
  ]
  edge [
    source 988
    target 1947
    kind "summarizes"
  ]
  edge [
    source 992
    target 993
    kind "mentions"
  ]
  edge [
    source 992
    target 994
    kind "mentions"
  ]
  edge [
    source 992
    target 995
    kind "mentions"
  ]
  edge [
    source 992
    target 996
    kind "mentions"
  ]
  edge [
    source 992
    target 997
    kind "mentions"
  ]
  edge [
    source 992
    target 1952
    kind "summarizes"
  ]
  edge [
    source 993
    target 1187
    kind "mentions"
  ]
  edge [
    source 993
    target 1188
    kind "mentions"
  ]
  edge [
    source 993
    target 1241
    kind "mentions"
  ]
  edge [
    source 993
    target 1242
    kind "relation"
    relation "may contain"
    weight 1
  ]
  edge [
    source 995
    target 1302
    kind "mentions"
  ]
  edge [
    source 995
    target 1249
    kind "relation"
    relation "moves into"
    weight 1
  ]
  edge [
    source 995
    target 1435
    kind "mentions"
  ]
  edge [
    source 995
    target 1178
    kind "relation"
    relation "transports"
    weight 1
  ]
  edge [
    source 998
    target 999
    kind "mentions"
  ]
  edge [
    source 998
    target 1952
    kind "summarizes"
  ]
  edge [
    source 1000
    target 1001
    kind "from_chunk"
  ]
  edge [
    source 1000
    target 1006
    kind "from_chunk"
  ]
  edge [
    source 1001
    target 1002
    kind "mentions"
  ]
  edge [
    source 1001
    target 1003
    kind "mentions"
  ]
  edge [
    source 1001
    target 1004
    kind "mentions"
  ]
  edge [
    source 1001
    target 1005
    kind "mentions"
  ]
  edge [
    source 1001
    target 1943
    kind "summarizes"
  ]
  edge [
    source 1002
    target 1006
    kind "mentions"
  ]
  edge [
    source 1003
    target 1006
    kind "mentions"
  ]
  edge [
    source 1005
    target 1025
    kind "mentions"
  ]
  edge [
    source 1005
    target 1047
    kind "relation"
    relation "does"
    weight 1
  ]
  edge [
    source 1006
    target 1007
    kind "mentions"
  ]
  edge [
    source 1006
    target 1008
    kind "mentions"
  ]
  edge [
    source 1006
    target 1009
    kind "mentions"
  ]
  edge [
    source 1006
    target 1010
    kind "mentions"
  ]
  edge [
    source 1006
    target 1011
    kind "mentions"
  ]
  edge [
    source 1006
    target 1941
    kind "summarizes"
  ]
  edge [
    source 1007
    target 1010
    kind "relation"
    relation "mixes with"
    weight 1
  ]
  edge [
    source 1007
    target 1011
    kind "relation"
    relation "is removed when"
    weight 1
  ]
  edge [
    source 1007
    target 1059
    kind "mentions"
  ]
  edge [
    source 1007
    target 1061
    kind "relation"
    relation "breaks down"
    weight 1
  ]
  edge [
    source 1007
    target 1278
    kind "mentions"
  ]
  edge [
    source 1007
    target 1279
    kind "mentions"
  ]
  edge [
    source 1007
    target 1282
    kind "mentions"
  ]
  edge [
    source 1007
    target 1280
    kind "relation"
    relation "becomes sweet"
    weight 1
  ]
  edge [
    source 1007
    target 1283
    kind "mentions"
  ]
  edge [
    source 1007
    target 1286
    kind "mentions"
  ]
  edge [
    source 1007
    target 1315
    kind "mentions"
  ]
  edge [
    source 1007
    target 1322
    kind "relation"
    relation "turns"
    weight 1
  ]
  edge [
    source 1008
    target 1013
    kind "mentions"
  ]
  edge [
    source 1008
    target 1288
    kind "mentions"
  ]
  edge [
    source 1008
    target 1290
    kind "relation"
    relation "has two passages leading down"
    weight 1
  ]
  edge [
    source 1008
    target 1808
    kind "mentions"
  ]
  edge [
    source 1009
    target 1013
    kind "mentions"
  ]
  edge [
    source 1012
    target 1013
    kind "from_chunk"
  ]
  edge [
    source 1012
    target 1016
    kind "from_chunk"
  ]
  edge [
    source 1012
    target 1019
    kind "from_chunk"
  ]
  edge [
    source 1012
    target 1025
    kind "from_chunk"
  ]
  edge [
    source 1013
    target 1014
    kind "mentions"
  ]
  edge [
    source 1013
    target 1015
    kind "mentions"
  ]
  edge [
    source 1013
    target 1941
    kind "summarizes"
  ]
  edge [
    source 1016
    target 1017
    kind "mentions"
  ]
  edge [
    source 1016
    target 1018
    kind "mentions"
  ]
  edge [
    source 1016
    target 1945
    kind "summarizes"
  ]
  edge [
    source 1018
    target 1136
    kind "mentions"
  ]
  edge [
    source 1019
    target 1020
    kind "mentions"
  ]
  edge [
    source 1019
    target 1021
    kind "mentions"
  ]
  edge [
    source 1019
    target 1022
    kind "mentions"
  ]
  edge [
    source 1019
    target 1023
    kind "mentions"
  ]
  edge [
    source 1019
    target 1024
    kind "mentions"
  ]
  edge [
    source 1019
    target 1944
    kind "summarizes"
  ]
  edge [
    source 1020
    target 1024
    kind "relation"
    relation "leaves behind"
    weight 1
  ]
  edge [
    source 1021
    target 1024
    kind "relation"
    relation "leaves behind"
    weight 1
  ]
  edge [
    source 1021
    target 1023
    kind "relation"
    relation "emits strong bad smell"
    weight 1
  ]
  edge [
    source 1023
    target 1467
    kind "mentions"
  ]
  edge [
    source 1023
    target 1471
    kind "relation"
    relation "if too tight, restrict"
    weight 1
  ]
  edge [
    source 1023
    target 1477
    kind "mentions"
  ]
  edge [
    source 1023
    target 1611
    kind "mentions"
  ]
  edge [
    source 1023
    target 1612
    kind "relation"
    relation "contain"
    weight 1
  ]
  edge [
    source 1024
    target 1068
    kind "mentions"
  ]
  edge [
    source 1024
    target 1069
    kind "relation"
    relation "produces"
    weight 1
  ]
  edge [
    source 1025
    target 1026
    kind "mentions"
  ]
  edge [
    source 1025
    target 1027
    kind "mentions"
  ]
  edge [
    source 1025
    target 1028
    kind "mentions"
  ]
  edge [
    source 1025
    target 1029
    kind "mentions"
  ]
  edge [
    source 1025
    target 1030
    kind "mentions"
  ]
  edge [
    source 1025
    target 1031
    kind "mentions"
  ]
  edge [
    source 1025
    target 1032
    kind "mentions"
  ]
  edge [
    source 1025
    target 1033
    kind "mentions"
  ]
  edge [
    source 1025
    target 1034
    kind "mentions"
  ]
  edge [
    source 1025
    target 1035
    kind "mentions"
  ]
  edge [
    source 1025
    target 1036
    kind "mentions"
  ]
  edge [
    source 1025
    target 1037
    kind "mentions"
  ]
  edge [
    source 1025
    target 1038
    kind "mentions"
  ]
  edge [
    source 1025
    target 1039
    kind "mentions"
  ]
  edge [
    source 1025
    target 1040
    kind "mentions"
  ]
  edge [
    source 1025
    target 1041
    kind "mentions"
  ]
  edge [
    source 1025
    target 1042
    kind "mentions"
  ]
  edge [
    source 1025
    target 1043
    kind "mentions"
  ]
  edge [
    source 1025
    target 1044
    kind "mentions"
  ]
  edge [
    source 1025
    target 1045
    kind "mentions"
  ]
  edge [
    source 1025
    target 1046
    kind "mentions"
  ]
  edge [
    source 1025
    target 1047
    kind "mentions"
  ]
  edge [
    source 1025
    target 1048
    kind "mentions"
  ]
  edge [
    source 1025
    target 1049
    kind "mentions"
  ]
  edge [
    source 1025
    target 1050
    kind "mentions"
  ]
  edge [
    source 1025
    target 1051
    kind "mentions"
  ]
  edge [
    source 1025
    target 1052
    kind "mentions"
  ]
  edge [
    source 1025
    target 1053
    kind "mentions"
  ]
  edge [
    source 1025
    target 1952
    kind "summarizes"
  ]
  edge [
    source 1027
    target 1038
    kind "relation"
    relation "is caused by"
    weight 1
  ]
  edge [
    source 1030
    target 1043
    kind "relation"
    relation "has an upper room"
    weight 1
  ]
  edge [
    source 1031
    target 1043
    kind "relation"
    relation "has a lower room"
    weight 1
  ]
  edge [
    source 1033
    target 1050
    kind "relation"
    relation "was discovered by"
    weight 1
  ]
  edge [
    source 1048
    target 1049
    kind "relation"
    relation "break down"
    weight 1
  ]
  edge [
    source 1051
    target 1052
    kind "relation"
    relation "must be changed"
    weight 1
  ]
  edge [
    source 1054
    target 1055
    kind "from_chunk"
  ]
  edge [
    source 1054
    target 1056
    kind "from_chunk"
  ]
  edge [
    source 1054
    target 1057
    kind "from_chunk"
  ]
  edge [
    source 1054
    target 1058
    kind "from_chunk"
  ]
  edge [
    source 1054
    target 1059
    kind "from_chunk"
  ]
  edge [
    source 1054
    target 1062
    kind "from_chunk"
  ]
  edge [
    source 1054
    target 1065
    kind "from_chunk"
  ]
  edge [
    source 1054
    target 1068
    kind "from_chunk"
  ]
  edge [
    source 1054
    target 1071
    kind "from_chunk"
  ]
  edge [
    source 1054
    target 1072
    kind "from_chunk"
  ]
  edge [
    source 1054
    target 1074
    kind "from_chunk"
  ]
  edge [
    source 1054
    target 1078
    kind "from_chunk"
  ]
  edge [
    source 1054
    target 1081
    kind "from_chunk"
  ]
  edge [
    source 1054
    target 1084
    kind "from_chunk"
  ]
  edge [
    source 1055
    target 1945
    kind "summarizes"
  ]
  edge [
    source 1056
    target 1945
    kind "summarizes"
  ]
  edge [
    source 1057
    target 1945
    kind "summarizes"
  ]
  edge [
    source 1058
    target 1952
    kind "summarizes"
  ]
  edge [
    source 1059
    target 1060
    kind "mentions"
  ]
  edge [
    source 1059
    target 1061
    kind "mentions"
  ]
  edge [
    source 1059
    target 1941
    kind "summarizes"
  ]
  edge [
    source 1060
    target 1248
    kind "mentions"
  ]
  edge [
    source 1060
    target 1250
    kind "relation"
    relation "involves"
    weight 1
  ]
  edge [
    source 1060
    target 1251
    kind "relation"
    relation "involves"
    weight 1
  ]
  edge [
    source 1062
    target 1063
    kind "mentions"
  ]
  edge [
    source 1062
    target 1064
    kind "mentions"
  ]
  edge [
    source 1062
    target 1954
    kind "summarizes"
  ]
  edge [
    source 1064
    target 1065
    kind "mentions"
  ]
  edge [
    source 1065
    target 1066
    kind "mentions"
  ]
  edge [
    source 1065
    target 1067
    kind "mentions"
  ]
  edge [
    source 1065
    target 1954
    kind "summarizes"
  ]
  edge [
    source 1068
    target 1069
    kind "mentions"
  ]
  edge [
    source 1068
    target 1070
    kind "mentions"
  ]
  edge [
    source 1068
    target 1944
    kind "summarizes"
  ]
  edge [
    source 1071
    target 1942
    kind "summarizes"
  ]
  edge [
    source 1072
    target 1073
    kind "mentions"
  ]
  edge [
    source 1072
    target 1940
    kind "summarizes"
  ]
  edge [
    source 1074
    target 1075
    kind "mentions"
  ]
  edge [
    source 1074
    target 1076
    kind "mentions"
  ]
  edge [
    source 1074
    target 1077
    kind "mentions"
  ]
  edge [
    source 1074
    target 1940
    kind "summarizes"
  ]
  edge [
    source 1076
    target 1078
    kind "mentions"
  ]
  edge [
    source 1076
    target 1079
    kind "relation"
    relation "connect"
    weight 1
  ]
  edge [
    source 1077
    target 1078
    kind "mentions"
  ]
  edge [
    source 1077
    target 1079
    kind "relation"
    relation "connect"
    weight 1
  ]
  edge [
    source 1077
    target 1081
    kind "mentions"
  ]
  edge [
    source 1078
    target 1079
    kind "mentions"
  ]
  edge [
    source 1078
    target 1080
    kind "mentions"
  ]
  edge [
    source 1078
    target 1940
    kind "summarizes"
  ]
  edge [
    source 1079
    target 1080
    kind "relation"
    relation "deliver to"
    weight 1
  ]
  edge [
    source 1081
    target 1082
    kind "mentions"
  ]
  edge [
    source 1081
    target 1083
    kind "mentions"
  ]
  edge [
    source 1081
    target 1940
    kind "summarizes"
  ]
  edge [
    source 1084
    target 1085
    kind "mentions"
  ]
  edge [
    source 1084
    target 1086
    kind "mentions"
  ]
  edge [
    source 1084
    target 1940
    kind "summarizes"
  ]
  edge [
    source 1085
    target 1086
    kind "relation"
    relation "contain"
    weight 1
  ]
  edge [
    source 1085
    target 1088
    kind "mentions"
  ]
  edge [
    source 1085
    target 1202
    kind "mentions"
  ]
  edge [
    source 1086
    target 1088
    kind "mentions"
  ]
  edge [
    source 1086
    target 1241
    kind "mentions"
  ]
  edge [
    source 1086
    target 1242
    kind "relation"
    relation "include"
    weight 1
  ]
  edge [
    source 1087
    target 1088
    kind "from_chunk"
  ]
  edge [
    source 1087
    target 1089
    kind "from_chunk"
  ]
  edge [
    source 1087
    target 1093
    kind "from_chunk"
  ]
  edge [
    source 1087
    target 1097
    kind "from_chunk"
  ]
  edge [
    source 1087
    target 1100
    kind "from_chunk"
  ]
  edge [
    source 1087
    target 1104
    kind "from_chunk"
  ]
  edge [
    source 1087
    target 1106
    kind "from_chunk"
  ]
  edge [
    source 1087
    target 1111
    kind "from_chunk"
  ]
  edge [
    source 1088
    target 1940
    kind "summarizes"
  ]
  edge [
    source 1089
    target 1090
    kind "mentions"
  ]
  edge [
    source 1089
    target 1091
    kind "mentions"
  ]
  edge [
    source 1089
    target 1092
    kind "mentions"
  ]
  edge [
    source 1089
    target 1940
    kind "summarizes"
  ]
  edge [
    source 1090
    target 1203
    kind "mentions"
  ]
  edge [
    source 1090
    target 1204
    kind "relation"
    relation "is contaminated by"
    weight 1
  ]
  edge [
    source 1091
    target 1203
    kind "mentions"
  ]
  edge [
    source 1091
    target 1204
    kind "relation"
    relation "is contaminated by"
    weight 1
  ]
  edge [
    source 1092
    target 1467
    kind "mentions"
  ]
  edge [
    source 1092
    target 1477
    kind "mentions"
  ]
  edge [
    source 1092
    target 1514
    kind "mentions"
  ]
  edge [
    source 1093
    target 1094
    kind "mentions"
  ]
  edge [
    source 1093
    target 1095
    kind "mentions"
  ]
  edge [
    source 1093
    target 1096
    kind "mentions"
  ]
  edge [
    source 1093
    target 1939
    kind "summarizes"
  ]
  edge [
    source 1095
    target 1096
    kind "relation"
    relation "is better than"
    weight 1
  ]
  edge [
    source 1097
    target 1098
    kind "mentions"
  ]
  edge [
    source 1097
    target 1099
    kind "mentions"
  ]
  edge [
    source 1097
    target 1938
    kind "summarizes"
  ]
  edge [
    source 1098
    target 1099
    kind "relation"
    relation "is as important as"
    weight 1
  ]
  edge [
    source 1098
    target 1364
    kind "mentions"
  ]
  edge [
    source 1099
    target 1435
    kind "mentions"
  ]
  edge [
    source 1099
    target 1444
    kind "relation"
    relation "is made from"
    weight 2
  ]
  edge [
    source 1099
    target 1446
    kind "mentions"
  ]
  edge [
    source 1100
    target 1101
    kind "mentions"
  ]
  edge [
    source 1100
    target 1102
    kind "mentions"
  ]
  edge [
    source 1100
    target 1103
    kind "mentions"
  ]
  edge [
    source 1100
    target 1939
    kind "summarizes"
  ]
  edge [
    source 1102
    target 1133
    kind "mentions"
  ]
  edge [
    source 1102
    target 1131
    kind "relation"
    relation "are made from"
    weight 1
  ]
  edge [
    source 1102
    target 1134
    kind "relation"
    relation "eat"
    weight 1
  ]
  edge [
    source 1102
    target 1135
    kind "relation"
    relation "eat"
    weight 1
  ]
  edge [
    source 1102
    target 1252
    kind "mentions"
  ]
  edge [
    source 1102
    target 1259
    kind "relation"
    relation "must be cooked before"
    weight 1
  ]
  edge [
    source 1102
    target 1261
    kind "mentions"
  ]
  edge [
    source 1102
    target 1127
    kind "relation"
    relation "must be cooked"
    weight 1
  ]
  edge [
    source 1102
    target 1315
    kind "mentions"
  ]
  edge [
    source 1104
    target 1105
    kind "mentions"
  ]
  edge [
    source 1104
    target 1946
    kind "summarizes"
  ]
  edge [
    source 1106
    target 1107
    kind "mentions"
  ]
  edge [
    source 1106
    target 1108
    kind "mentions"
  ]
  edge [
    source 1106
    target 1109
    kind "mentions"
  ]
  edge [
    source 1106
    target 1110
    kind "mentions"
  ]
  edge [
    source 1106
    target 1939
    kind "summarizes"
  ]
  edge [
    source 1107
    target 1108
    kind "relation"
    relation "eat"
    weight 1
  ]
  edge [
    source 1107
    target 1133
    kind "mentions"
  ]
  edge [
    source 1107
    target 1131
    kind "relation"
    relation "are made from"
    weight 1
  ]
  edge [
    source 1107
    target 1134
    kind "relation"
    relation "eat"
    weight 1
  ]
  edge [
    source 1107
    target 1135
    kind "relation"
    relation "eat"
    weight 1
  ]
  edge [
    source 1107
    target 1166
    kind "mentions"
  ]
  edge [
    source 1108
    target 1119
    kind "mentions"
  ]
  edge [
    source 1109
    target 1126
    kind "mentions"
  ]
  edge [
    source 1111
    target 1112
    kind "mentions"
  ]
  edge [
    source 1111
    target 1113
    kind "mentions"
  ]
  edge [
    source 1111
    target 1114
    kind "mentions"
  ]
  edge [
    source 1111
    target 1939
    kind "summarizes"
  ]
  edge [
    source 1112
    target 1114
    kind "relation"
    relation "takes up"
    weight 1
  ]
  edge [
    source 1112
    target 1116
    kind "mentions"
  ]
  edge [
    source 1112
    target 1117
    kind "relation"
    relation "is present in"
    weight 1
  ]
  edge [
    source 1112
    target 1118
    kind "relation"
    relation "is present in"
    weight 1
  ]
  edge [
    source 1112
    target 1133
    kind "mentions"
  ]
  edge [
    source 1112
    target 1131
    kind "relation"
    relation "are made from"
    weight 1
  ]
  edge [
    source 1112
    target 1134
    kind "relation"
    relation "eat"
    weight 1
  ]
  edge [
    source 1112
    target 1135
    kind "relation"
    relation "eat"
    weight 1
  ]
  edge [
    source 1112
    target 1166
    kind "mentions"
  ]
  edge [
    source 1112
    target 1361
    kind "mentions"
  ]
  edge [
    source 1112
    target 1364
    kind "mentions"
  ]
  edge [
    source 1115
    target 1116
    kind "from_chunk"
  ]
  edge [
    source 1115
    target 1119
    kind "from_chunk"
  ]
  edge [
    source 1115
    target 1126
    kind "from_chunk"
  ]
  edge [
    source 1115
    target 1129
    kind "from_chunk"
  ]
  edge [
    source 1115
    target 1133
    kind "from_chunk"
  ]
  edge [
    source 1115
    target 1136
    kind "from_chunk"
  ]
  edge [
    source 1116
    target 1117
    kind "mentions"
  ]
  edge [
    source 1116
    target 1118
    kind "mentions"
  ]
  edge [
    source 1116
    target 1939
    kind "summarizes"
  ]
  edge [
    source 1119
    target 1120
    kind "mentions"
  ]
  edge [
    source 1119
    target 1121
    kind "mentions"
  ]
  edge [
    source 1119
    target 1122
    kind "mentions"
  ]
  edge [
    source 1119
    target 1123
    kind "mentions"
  ]
  edge [
    source 1119
    target 1124
    kind "mentions"
  ]
  edge [
    source 1119
    target 1125
    kind "mentions"
  ]
  edge [
    source 1119
    target 1939
    kind "summarizes"
  ]
  edge [
    source 1120
    target 1166
    kind "mentions"
  ]
  edge [
    source 1122
    target 1124
    kind "relation"
    relation "seek out"
    weight 1
  ]
  edge [
    source 1123
    target 1124
    kind "relation"
    relation "seek out"
    weight 1
  ]
  edge [
    source 1126
    target 1127
    kind "mentions"
  ]
  edge [
    source 1126
    target 1128
    kind "mentions"
  ]
  edge [
    source 1126
    target 1939
    kind "summarizes"
  ]
  edge [
    source 1127
    target 1252
    kind "mentions"
  ]
  edge [
    source 1127
    target 1261
    kind "mentions"
  ]
  edge [
    source 1127
    target 1270
    kind "mentions"
  ]
  edge [
    source 1127
    target 1271
    kind "relation"
    relation "may have charge of"
    weight 1
  ]
  edge [
    source 1129
    target 1130
    kind "mentions"
  ]
  edge [
    source 1129
    target 1131
    kind "mentions"
  ]
  edge [
    source 1129
    target 1132
    kind "mentions"
  ]
  edge [
    source 1129
    target 1939
    kind "summarizes"
  ]
  edge [
    source 1130
    target 1326
    kind "mentions"
  ]
  edge [
    source 1131
    target 1132
    kind "relation"
    relation "include"
    weight 2
  ]
  edge [
    source 1131
    target 1133
    kind "mentions"
  ]
  edge [
    source 1131
    target 1218
    kind "mentions"
  ]
  edge [
    source 1131
    target 1215
    kind "relation"
    relation "provide"
    weight 1
  ]
  edge [
    source 1131
    target 1326
    kind "mentions"
  ]
  edge [
    source 1132
    target 1133
    kind "mentions"
  ]
  edge [
    source 1132
    target 1218
    kind "mentions"
  ]
  edge [
    source 1132
    target 1210
    kind "relation"
    relation "include"
    weight 1
  ]
  edge [
    source 1132
    target 1219
    kind "relation"
    relation "include"
    weight 1
  ]
  edge [
    source 1133
    target 1134
    kind "mentions"
  ]
  edge [
    source 1133
    target 1135
    kind "mentions"
  ]
  edge [
    source 1133
    target 1939
    kind "summarizes"
  ]
  edge [
    source 1136
    target 1137
    kind "mentions"
  ]
  edge [
    source 1136
    target 1138
    kind "mentions"
  ]
  edge [
    source 1136
    target 1139
    kind "mentions"
  ]
  edge [
    source 1136
    target 1140
    kind "mentions"
  ]
  edge [
    source 1136
    target 1141
    kind "mentions"
  ]
  edge [
    source 1136
    target 1142
    kind "mentions"
  ]
  edge [
    source 1136
    target 1945
    kind "summarizes"
  ]
  edge [
    source 1143
    target 1144
    kind "from_chunk"
  ]
  edge [
    source 1143
    target 1147
    kind "from_chunk"
  ]
  edge [
    source 1143
    target 1152
    kind "from_chunk"
  ]
  edge [
    source 1143
    target 1158
    kind "from_chunk"
  ]
  edge [
    source 1143
    target 1161
    kind "from_chunk"
  ]
  edge [
    source 1143
    target 1164
    kind "from_chunk"
  ]
  edge [
    source 1143
    target 1166
    kind "from_chunk"
  ]
  edge [
    source 1143
    target 1173
    kind "from_chunk"
  ]
  edge [
    source 1143
    target 1177
    kind "from_chunk"
  ]
  edge [
    source 1143
    target 1180
    kind "from_chunk"
  ]
  edge [
    source 1144
    target 1145
    kind "mentions"
  ]
  edge [
    source 1144
    target 1146
    kind "mentions"
  ]
  edge [
    source 1144
    target 1953
    kind "summarizes"
  ]
  edge [
    source 1145
    target 1146
    kind "relation"
    relation "comes from"
    weight 1
  ]
  edge [
    source 1145
    target 1228
    kind "mentions"
  ]
  edge [
    source 1145
    target 1229
    kind "relation"
    relation "comes from"
    weight 1
  ]
  edge [
    source 1145
    target 1230
    kind "relation"
    relation "comes from"
    weight 1
  ]
  edge [
    source 1145
    target 1231
    kind "relation"
    relation "comes from"
    weight 1
  ]
  edge [
    source 1147
    target 1148
    kind "mentions"
  ]
  edge [
    source 1147
    target 1149
    kind "mentions"
  ]
  edge [
    source 1147
    target 1150
    kind "mentions"
  ]
  edge [
    source 1147
    target 1151
    kind "mentions"
  ]
  edge [
    source 1147
    target 1948
    kind "summarizes"
  ]
  edge [
    source 1148
    target 1149
    kind "relation"
    relation "requires more fatty food than"
    weight 1
  ]
  edge [
    source 1148
    target 1786
    kind "mentions"
  ]
  edge [
    source 1148
    target 1793
    kind "relation"
    relation "should be worn in"
    weight 1
  ]
  edge [
    source 1149
    target 1550
    kind "mentions"
  ]
  edge [
    source 1150
    target 1151
    kind "relation"
    relation "need fatty food all the time"
    weight 1
  ]
  edge [
    source 1151
    target 1867
    kind "mentions"
  ]
  edge [
    source 1152
    target 1153
    kind "mentions"
  ]
  edge [
    source 1152
    target 1154
    kind "mentions"
  ]
  edge [
    source 1152
    target 1155
    kind "mentions"
  ]
  edge [
    source 1152
    target 1156
    kind "mentions"
  ]
  edge [
    source 1152
    target 1157
    kind "mentions"
  ]
  edge [
    source 1152
    target 1956
    kind "summarizes"
  ]
  edge [
    source 1153
    target 1154
    kind "relation"
    relation "live in"
    weight 1
  ]
  edge [
    source 1153
    target 1155
    kind "relation"
    relation "catch"
    weight 1
  ]
  edge [
    source 1153
    target 1156
    kind "relation"
    relation "catch"
    weight 1
  ]
  edge [
    source 1153
    target 1157
    kind "relation"
    relation "eat"
    weight 1
  ]
  edge [
    source 1153
    target 1233
    kind "mentions"
  ]
  edge [
    source 1153
    target 1234
    kind "relation"
    relation "eat"
    weight 1
  ]
  edge [
    source 1153
    target 1235
    kind "relation"
    relation "eat"
    weight 1
  ]
  edge [
    source 1158
    target 1159
    kind "mentions"
  ]
  edge [
    source 1158
    target 1160
    kind "mentions"
  ]
  edge [
    source 1158
    target 1945
    kind "summarizes"
  ]
  edge [
    source 1159
    target 1161
    kind "mentions"
  ]
  edge [
    source 1159
    target 1166
    kind "mentions"
  ]
  edge [
    source 1159
    target 1162
    kind "relation"
    relation "comes from"
    weight 1
  ]
  edge [
    source 1159
    target 1252
    kind "mentions"
  ]
  edge [
    source 1160
    target 1166
    kind "mentions"
  ]
  edge [
    source 1160
    target 1170
    kind "relation"
    relation "comes from"
    weight 1
  ]
  edge [
    source 1160
    target 1326
    kind "mentions"
  ]
  edge [
    source 1160
    target 1819
    kind "mentions"
  ]
  edge [
    source 1160
    target 1828
    kind "relation"
    relation "drink"
    weight 2
  ]
  edge [
    source 1160
    target 1841
    kind "mentions"
  ]
  edge [
    source 1161
    target 1162
    kind "mentions"
  ]
  edge [
    source 1161
    target 1163
    kind "mentions"
  ]
  edge [
    source 1161
    target 1945
    kind "summarizes"
  ]
  edge [
    source 1162
    target 1166
    kind "mentions"
  ]
  edge [
    source 1162
    target 1326
    kind "mentions"
  ]
  edge [
    source 1163
    target 1166
    kind "mentions"
  ]
  edge [
    source 1164
    target 1165
    kind "mentions"
  ]
  edge [
    source 1164
    target 1939
    kind "summarizes"
  ]
  edge [
    source 1166
    target 1167
    kind "mentions"
  ]
  edge [
    source 1166
    target 1168
    kind "mentions"
  ]
  edge [
    source 1166
    target 1169
    kind "mentions"
  ]
  edge [
    source 1166
    target 1170
    kind "mentions"
  ]
  edge [
    source 1166
    target 1171
    kind "mentions"
  ]
  edge [
    source 1166
    target 1172
    kind "mentions"
  ]
  edge [
    source 1166
    target 1945
    kind "summarizes"
  ]
  edge [
    source 1173
    target 1174
    kind "mentions"
  ]
  edge [
    source 1173
    target 1175
    kind "mentions"
  ]
  edge [
    source 1173
    target 1176
    kind "mentions"
  ]
  edge [
    source 1173
    target 1941
    kind "summarizes"
  ]
  edge [
    source 1174
    target 1176
    kind "relation"
    relation "are not ready for"
    weight 1
  ]
  edge [
    source 1175
    target 1176
    kind "relation"
    relation "are not ready for"
    weight 1
  ]
  edge [
    source 1175
    target 1238
    kind "mentions"
  ]
  edge [
    source 1175
    target 1181
    kind "relation"
    relation "causes to ripen"
    weight 1
  ]
  edge [
    source 1175
    target 1239
    kind "relation"
    relation "produce"
    weight 1
  ]
  edge [
    source 1175
    target 1240
    kind "relation"
    relation "increase in"
    weight 1
  ]
  edge [
    source 1177
    target 1178
    kind "mentions"
  ]
  edge [
    source 1177
    target 1179
    kind "mentions"
  ]
  edge [
    source 1177
    target 1941
    kind "summarizes"
  ]
  edge [
    source 1178
    target 1278
    kind "mentions"
  ]
  edge [
    source 1178
    target 1302
    kind "mentions"
  ]
  edge [
    source 1178
    target 1249
    kind "relation"
    relation "absorbs food into"
    weight 1
  ]
  edge [
    source 1178
    target 1307
    kind "mentions"
  ]
  edge [
    source 1178
    target 1310
    kind "relation"
    relation "brings"
    weight 1
  ]
  edge [
    source 1178
    target 1335
    kind "mentions"
  ]
  edge [
    source 1178
    target 1343
    kind "relation"
    relation "provides supplies to"
    weight 1
  ]
  edge [
    source 1178
    target 1351
    kind "relation"
    relation "delivers supplies to | carries food to"
    weight 2
  ]
  edge [
    source 1178
    target 1427
    kind "mentions"
  ]
  edge [
    source 1178
    target 1432
    kind "relation"
    relation "flows through"
    weight 1
  ]
  edge [
    source 1178
    target 1435
    kind "mentions"
  ]
  edge [
    source 1178
    target 1442
    kind "relation"
    relation "leaves with"
    weight 1
  ]
  edge [
    source 1178
    target 1448
    kind "mentions"
  ]
  edge [
    source 1178
    target 1467
    kind "mentions"
  ]
  edge [
    source 1178
    target 1473
    kind "relation"
    relation "becomes dull and bluish"
    weight 1
  ]
  edge [
    source 1178
    target 1477
    kind "mentions"
  ]
  edge [
    source 1178
    target 1481
    kind "mentions"
  ]
  edge [
    source 1178
    target 1496
    kind "mentions"
  ]
  edge [
    source 1178
    target 1498
    kind "mentions"
  ]
  edge [
    source 1178
    target 1505
    kind "mentions"
  ]
  edge [
    source 1178
    target 1508
    kind "mentions"
  ]
  edge [
    source 1178
    target 1509
    kind "relation"
    relation "makes | becomes pure"
    weight 2
  ]
  edge [
    source 1178
    target 1529
    kind "mentions"
  ]
  edge [
    source 1178
    target 1530
    kind "relation"
    relation "transports"
    weight 1
  ]
  edge [
    source 1178
    target 1436
    kind "relation"
    relation "appear blue due to light absorption"
    weight 1
  ]
  edge [
    source 1178
    target 1625
    kind "mentions"
  ]
  edge [
    source 1178
    target 1772
    kind "mentions"
  ]
  edge [
    source 1180
    target 1181
    kind "mentions"
  ]
  edge [
    source 1180
    target 1182
    kind "mentions"
  ]
  edge [
    source 1180
    target 1941
    kind "summarizes"
  ]
  edge [
    source 1181
    target 1184
    kind "mentions"
  ]
  edge [
    source 1181
    target 1238
    kind "mentions"
  ]
  edge [
    source 1181
    target 1268
    kind "mentions"
  ]
  edge [
    source 1181
    target 1663
    kind "mentions"
  ]
  edge [
    source 1181
    target 1665
    kind "relation"
    relation "began to look at"
    weight 1
  ]
  edge [
    source 1182
    target 1268
    kind "mentions"
  ]
  edge [
    source 1183
    target 1184
    kind "from_chunk"
  ]
  edge [
    source 1183
    target 1187
    kind "from_chunk"
  ]
  edge [
    source 1183
    target 1188
    kind "from_chunk"
  ]
  edge [
    source 1183
    target 1191
    kind "from_chunk"
  ]
  edge [
    source 1183
    target 1198
    kind "from_chunk"
  ]
  edge [
    source 1184
    target 1185
    kind "mentions"
  ]
  edge [
    source 1184
    target 1186
    kind "mentions"
  ]
  edge [
    source 1184
    target 1941
    kind "summarizes"
  ]
  edge [
    source 1185
    target 1186
    kind "relation"
    relation "have more sugar than"
    weight 1
  ]
  edge [
    source 1187
    target 1950
    kind "summarizes"
  ]
  edge [
    source 1188
    target 1189
    kind "mentions"
  ]
  edge [
    source 1188
    target 1190
    kind "mentions"
  ]
  edge [
    source 1188
    target 1950
    kind "summarizes"
  ]
  edge [
    source 1191
    target 1192
    kind "mentions"
  ]
  edge [
    source 1191
    target 1193
    kind "mentions"
  ]
  edge [
    source 1191
    target 1194
    kind "mentions"
  ]
  edge [
    source 1191
    target 1195
    kind "mentions"
  ]
  edge [
    source 1191
    target 1196
    kind "mentions"
  ]
  edge [
    source 1191
    target 1197
    kind "mentions"
  ]
  edge [
    source 1191
    target 1940
    kind "summarizes"
  ]
  edge [
    source 1192
    target 1195
    kind "relation"
    relation "when placed in water"
    weight 1
  ]
  edge [
    source 1192
    target 1196
    kind "relation"
    relation "when placed in water"
    weight 1
  ]
  edge [
    source 1192
    target 1244
    kind "mentions"
  ]
  edge [
    source 1192
    target 1245
    kind "relation"
    relation "contains"
    weight 1
  ]
  edge [
    source 1193
    target 1197
    kind "relation"
    relation "is not good food"
    weight 1
  ]
  edge [
    source 1193
    target 1198
    kind "mentions"
  ]
  edge [
    source 1193
    target 1199
    kind "relation"
    relation "use"
    weight 1
  ]
  edge [
    source 1198
    target 1199
    kind "mentions"
  ]
  edge [
    source 1198
    target 1200
    kind "mentions"
  ]
  edge [
    source 1198
    target 1940
    kind "summarizes"
  ]
  edge [
    source 1201
    target 1202
    kind "from_chunk"
  ]
  edge [
    source 1201
    target 1203
    kind "from_chunk"
  ]
  edge [
    source 1201
    target 1205
    kind "from_chunk"
  ]
  edge [
    source 1201
    target 1208
    kind "from_chunk"
  ]
  edge [
    source 1201
    target 1212
    kind "from_chunk"
  ]
  edge [
    source 1201
    target 1214
    kind "from_chunk"
  ]
  edge [
    source 1201
    target 1218
    kind "from_chunk"
  ]
  edge [
    source 1201
    target 1220
    kind "from_chunk"
  ]
  edge [
    source 1201
    target 1225
    kind "from_chunk"
  ]
  edge [
    source 1201
    target 1228
    kind "from_chunk"
  ]
  edge [
    source 1201
    target 1233
    kind "from_chunk"
  ]
  edge [
    source 1201
    target 1238
    kind "from_chunk"
  ]
  edge [
    source 1201
    target 1241
    kind "from_chunk"
  ]
  edge [
    source 1201
    target 1244
    kind "from_chunk"
  ]
  edge [
    source 1201
    target 1248
    kind "from_chunk"
  ]
  edge [
    source 1201
    target 1252
    kind "from_chunk"
  ]
  edge [
    source 1202
    target 1940
    kind "summarizes"
  ]
  edge [
    source 1203
    target 1204
    kind "mentions"
  ]
  edge [
    source 1203
    target 1940
    kind "summarizes"
  ]
  edge [
    source 1205
    target 1206
    kind "mentions"
  ]
  edge [
    source 1205
    target 1207
    kind "mentions"
  ]
  edge [
    source 1205
    target 1939
    kind "summarizes"
  ]
  edge [
    source 1208
    target 1209
    kind "mentions"
  ]
  edge [
    source 1208
    target 1210
    kind "mentions"
  ]
  edge [
    source 1208
    target 1211
    kind "mentions"
  ]
  edge [
    source 1208
    target 1939
    kind "summarizes"
  ]
  edge [
    source 1210
    target 1218
    kind "mentions"
  ]
  edge [
    source 1210
    target 1215
    kind "relation"
    relation "provide"
    weight 1
  ]
  edge [
    source 1212
    target 1213
    kind "mentions"
  ]
  edge [
    source 1212
    target 1939
    kind "summarizes"
  ]
  edge [
    source 1214
    target 1215
    kind "mentions"
  ]
  edge [
    source 1214
    target 1216
    kind "mentions"
  ]
  edge [
    source 1214
    target 1217
    kind "mentions"
  ]
  edge [
    source 1214
    target 1939
    kind "summarizes"
  ]
  edge [
    source 1215
    target 1218
    kind "mentions"
  ]
  edge [
    source 1215
    target 1219
    kind "relation"
    relation "provide"
    weight 1
  ]
  edge [
    source 1218
    target 1219
    kind "mentions"
  ]
  edge [
    source 1218
    target 1939
    kind "summarizes"
  ]
  edge [
    source 1220
    target 1221
    kind "mentions"
  ]
  edge [
    source 1220
    target 1222
    kind "mentions"
  ]
  edge [
    source 1220
    target 1223
    kind "mentions"
  ]
  edge [
    source 1220
    target 1224
    kind "mentions"
  ]
  edge [
    source 1220
    target 1945
    kind "summarizes"
  ]
  edge [
    source 1225
    target 1226
    kind "mentions"
  ]
  edge [
    source 1225
    target 1227
    kind "mentions"
  ]
  edge [
    source 1225
    target 1942
    kind "summarizes"
  ]
  edge [
    source 1226
    target 1227
    kind "relation"
    relation "interferes with"
    weight 1
  ]
  edge [
    source 1227
    target 1628
    kind "mentions"
  ]
  edge [
    source 1227
    target 1489
    kind "relation"
    relation "go on"
    weight 1
  ]
  edge [
    source 1227
    target 1629
    kind "relation"
    relation "occur without"
    weight 1
  ]
  edge [
    source 1228
    target 1229
    kind "mentions"
  ]
  edge [
    source 1228
    target 1230
    kind "mentions"
  ]
  edge [
    source 1228
    target 1231
    kind "mentions"
  ]
  edge [
    source 1228
    target 1232
    kind "mentions"
  ]
  edge [
    source 1228
    target 1953
    kind "summarizes"
  ]
  edge [
    source 1229
    target 1232
    kind "relation"
    relation "are rich in"
    weight 1
  ]
  edge [
    source 1230
    target 1232
    kind "relation"
    relation "are rich in"
    weight 1
  ]
  edge [
    source 1231
    target 1232
    kind "relation"
    relation "are rich in"
    weight 1
  ]
  edge [
    source 1233
    target 1234
    kind "mentions"
  ]
  edge [
    source 1233
    target 1235
    kind "mentions"
  ]
  edge [
    source 1233
    target 1236
    kind "mentions"
  ]
  edge [
    source 1233
    target 1237
    kind "mentions"
  ]
  edge [
    source 1233
    target 1956
    kind "summarizes"
  ]
  edge [
    source 1234
    target 1236
    kind "relation"
    relation "provide"
    weight 1
  ]
  edge [
    source 1234
    target 1237
    kind "relation"
    relation "provide"
    weight 1
  ]
  edge [
    source 1238
    target 1239
    kind "mentions"
  ]
  edge [
    source 1238
    target 1240
    kind "mentions"
  ]
  edge [
    source 1238
    target 1941
    kind "summarizes"
  ]
  edge [
    source 1241
    target 1242
    kind "mentions"
  ]
  edge [
    source 1241
    target 1243
    kind "mentions"
  ]
  edge [
    source 1241
    target 1940
    kind "summarizes"
  ]
  edge [
    source 1242
    target 1243
    kind "relation"
    relation "include"
    weight 1
  ]
  edge [
    source 1243
    target 1756
    kind "mentions"
  ]
  edge [
    source 1244
    target 1245
    kind "mentions"
  ]
  edge [
    source 1244
    target 1246
    kind "mentions"
  ]
  edge [
    source 1244
    target 1247
    kind "mentions"
  ]
  edge [
    source 1244
    target 1940
    kind "summarizes"
  ]
  edge [
    source 1245
    target 1246
    kind "relation"
    relation "is added to prevent"
    weight 1
  ]
  edge [
    source 1245
    target 1247
    kind "relation"
    relation "is added to preserve"
    weight 1
  ]
  edge [
    source 1248
    target 1249
    kind "mentions"
  ]
  edge [
    source 1248
    target 1250
    kind "mentions"
  ]
  edge [
    source 1248
    target 1251
    kind "mentions"
  ]
  edge [
    source 1248
    target 1952
    kind "summarizes"
  ]
  edge [
    source 1249
    target 1302
    kind "mentions"
  ]
  edge [
    source 1252
    target 1253
    kind "mentions"
  ]
  edge [
    source 1252
    target 1254
    kind "mentions"
  ]
  edge [
    source 1252
    target 1255
    kind "mentions"
  ]
  edge [
    source 1252
    target 1256
    kind "mentions"
  ]
  edge [
    source 1252
    target 1257
    kind "mentions"
  ]
  edge [
    source 1252
    target 1258
    kind "mentions"
  ]
  edge [
    source 1252
    target 1259
    kind "mentions"
  ]
  edge [
    source 1252
    target 1939
    kind "summarizes"
  ]
  edge [
    source 1260
    target 1261
    kind "from_chunk"
  ]
  edge [
    source 1260
    target 1268
    kind "from_chunk"
  ]
  edge [
    source 1260
    target 1270
    kind "from_chunk"
  ]
  edge [
    source 1260
    target 1278
    kind "from_chunk"
  ]
  edge [
    source 1260
    target 1279
    kind "from_chunk"
  ]
  edge [
    source 1261
    target 1262
    kind "mentions"
  ]
  edge [
    source 1261
    target 1263
    kind "mentions"
  ]
  edge [
    source 1261
    target 1264
    kind "mentions"
  ]
  edge [
    source 1261
    target 1265
    kind "mentions"
  ]
  edge [
    source 1261
    target 1266
    kind "mentions"
  ]
  edge [
    source 1261
    target 1267
    kind "mentions"
  ]
  edge [
    source 1261
    target 1939
    kind "summarizes"
  ]
  edge [
    source 1262
    target 1264
    kind "relation"
    relation "would cause"
    weight 1
  ]
  edge [
    source 1262
    target 1265
    kind "relation"
    relation "would cause"
    weight 1
  ]
  edge [
    source 1262
    target 1266
    kind "relation"
    relation "would cause"
    weight 1
  ]
  edge [
    source 1263
    target 1267
    kind "relation"
    relation "would cause"
    weight 1
  ]
  edge [
    source 1268
    target 1269
    kind "mentions"
  ]
  edge [
    source 1268
    target 1941
    kind "summarizes"
  ]
  edge [
    source 1270
    target 1271
    kind "mentions"
  ]
  edge [
    source 1270
    target 1272
    kind "mentions"
  ]
  edge [
    source 1270
    target 1273
    kind "mentions"
  ]
  edge [
    source 1270
    target 1274
    kind "mentions"
  ]
  edge [
    source 1270
    target 1275
    kind "mentions"
  ]
  edge [
    source 1270
    target 1276
    kind "mentions"
  ]
  edge [
    source 1270
    target 1277
    kind "mentions"
  ]
  edge [
    source 1270
    target 1941
    kind "summarizes"
  ]
  edge [
    source 1273
    target 1274
    kind "relation"
    relation "is worth twice as much as"
    weight 1
  ]
  edge [
    source 1275
    target 1276
    kind "relation"
    relation "has more influence on"
    weight 1
  ]
  edge [
    source 1275
    target 1315
    kind "mentions"
  ]
  edge [
    source 1275
    target 1321
    kind "relation"
    relation "is described as"
    weight 1
  ]
  edge [
    source 1278
    target 1941
    kind "summarizes"
  ]
  edge [
    source 1279
    target 1280
    kind "mentions"
  ]
  edge [
    source 1279
    target 1941
    kind "summarizes"
  ]
  edge [
    source 1280
    target 1282
    kind "mentions"
  ]
  edge [
    source 1281
    target 1282
    kind "from_chunk"
  ]
  edge [
    source 1281
    target 1283
    kind "from_chunk"
  ]
  edge [
    source 1281
    target 1286
    kind "from_chunk"
  ]
  edge [
    source 1281
    target 1288
    kind "from_chunk"
  ]
  edge [
    source 1281
    target 1293
    kind "from_chunk"
  ]
  edge [
    source 1282
    target 1941
    kind "summarizes"
  ]
  edge [
    source 1283
    target 1284
    kind "mentions"
  ]
  edge [
    source 1283
    target 1285
    kind "mentions"
  ]
  edge [
    source 1283
    target 1941
    kind "summarizes"
  ]
  edge [
    source 1284
    target 1285
    kind "relation"
    relation "neglects its work"
    weight 1
  ]
  edge [
    source 1286
    target 1287
    kind "mentions"
  ]
  edge [
    source 1286
    target 1952
    kind "summarizes"
  ]
  edge [
    source 1288
    target 1289
    kind "mentions"
  ]
  edge [
    source 1288
    target 1290
    kind "mentions"
  ]
  edge [
    source 1288
    target 1291
    kind "mentions"
  ]
  edge [
    source 1288
    target 1292
    kind "mentions"
  ]
  edge [
    source 1288
    target 1941
    kind "summarizes"
  ]
  edge [
    source 1289
    target 1298
    kind "mentions"
  ]
  edge [
    source 1289
    target 1295
    kind "relation"
    relation "closes during"
    weight 1
  ]
  edge [
    source 1289
    target 1315
    kind "mentions"
  ]
  edge [
    source 1289
    target 1324
    kind "relation"
    relation "is described as wonderful because"
    weight 1
  ]
  edge [
    source 1293
    target 1294
    kind "mentions"
  ]
  edge [
    source 1293
    target 1295
    kind "mentions"
  ]
  edge [
    source 1293
    target 1296
    kind "mentions"
  ]
  edge [
    source 1293
    target 1938
    kind "summarizes"
  ]
  edge [
    source 1294
    target 1296
    kind "relation"
    relation "is in front of"
    weight 1
  ]
  edge [
    source 1294
    target 1295
    kind "relation"
    relation "has at its top"
    weight 1
  ]
  edge [
    source 1294
    target 1298
    kind "mentions"
  ]
  edge [
    source 1294
    target 1300
    kind "relation"
    relation "causes"
    weight 1
  ]
  edge [
    source 1295
    target 1298
    kind "mentions"
  ]
  edge [
    source 1297
    target 1298
    kind "from_chunk"
  ]
  edge [
    source 1297
    target 1302
    kind "from_chunk"
  ]
  edge [
    source 1298
    target 1299
    kind "mentions"
  ]
  edge [
    source 1298
    target 1300
    kind "mentions"
  ]
  edge [
    source 1298
    target 1301
    kind "mentions"
  ]
  edge [
    source 1298
    target 1938
    kind "summarizes"
  ]
  edge [
    source 1302
    target 1303
    kind "mentions"
  ]
  edge [
    source 1302
    target 1304
    kind "mentions"
  ]
  edge [
    source 1302
    target 1305
    kind "mentions"
  ]
  edge [
    source 1302
    target 1938
    kind "summarizes"
  ]
  edge [
    source 1306
    target 1307
    kind "from_chunk"
  ]
  edge [
    source 1306
    target 1315
    kind "from_chunk"
  ]
  edge [
    source 1307
    target 1308
    kind "mentions"
  ]
  edge [
    source 1307
    target 1309
    kind "mentions"
  ]
  edge [
    source 1307
    target 1310
    kind "mentions"
  ]
  edge [
    source 1307
    target 1311
    kind "mentions"
  ]
  edge [
    source 1307
    target 1312
    kind "mentions"
  ]
  edge [
    source 1307
    target 1313
    kind "mentions"
  ]
  edge [
    source 1307
    target 1314
    kind "mentions"
  ]
  edge [
    source 1307
    target 1960
    kind "summarizes"
  ]
  edge [
    source 1309
    target 1313
    kind "relation"
    relation "does not grow together when"
    weight 1
  ]
  edge [
    source 1310
    target 1311
    kind "relation"
    relation "enables"
    weight 1
  ]
  edge [
    source 1315
    target 1316
    kind "mentions"
  ]
  edge [
    source 1315
    target 1317
    kind "mentions"
  ]
  edge [
    source 1315
    target 1318
    kind "mentions"
  ]
  edge [
    source 1315
    target 1319
    kind "mentions"
  ]
  edge [
    source 1315
    target 1320
    kind "mentions"
  ]
  edge [
    source 1315
    target 1321
    kind "mentions"
  ]
  edge [
    source 1315
    target 1322
    kind "mentions"
  ]
  edge [
    source 1315
    target 1323
    kind "mentions"
  ]
  edge [
    source 1315
    target 1324
    kind "mentions"
  ]
  edge [
    source 1315
    target 1941
    kind "summarizes"
  ]
  edge [
    source 1318
    target 1319
    kind "relation"
    relation "are cooked to"
    weight 1
  ]
  edge [
    source 1325
    target 1326
    kind "from_chunk"
  ]
  edge [
    source 1325
    target 1328
    kind "from_chunk"
  ]
  edge [
    source 1326
    target 1327
    kind "mentions"
  ]
  edge [
    source 1326
    target 1939
    kind "summarizes"
  ]
  edge [
    source 1328
    target 1329
    kind "mentions"
  ]
  edge [
    source 1328
    target 1330
    kind "mentions"
  ]
  edge [
    source 1328
    target 1331
    kind "mentions"
  ]
  edge [
    source 1328
    target 1332
    kind "mentions"
  ]
  edge [
    source 1328
    target 1333
    kind "mentions"
  ]
  edge [
    source 1328
    target 1949
    kind "summarizes"
  ]
  edge [
    source 1329
    target 1330
    kind "relation"
    relation "were not included on"
    weight 1
  ]
  edge [
    source 1329
    target 1813
    kind "mentions"
  ]
  edge [
    source 1329
    target 1817
    kind "relation"
    relation "were believed to warm"
    weight 1
  ]
  edge [
    source 1331
    target 1335
    kind "mentions"
  ]
  edge [
    source 1332
    target 1333
    kind "relation"
    relation "is done to"
    weight 1
  ]
  edge [
    source 1334
    target 1335
    kind "from_chunk"
  ]
  edge [
    source 1334
    target 1354
    kind "from_chunk"
  ]
  edge [
    source 1334
    target 1361
    kind "from_chunk"
  ]
  edge [
    source 1335
    target 1336
    kind "mentions"
  ]
  edge [
    source 1335
    target 1337
    kind "mentions"
  ]
  edge [
    source 1335
    target 1338
    kind "mentions"
  ]
  edge [
    source 1335
    target 1339
    kind "mentions"
  ]
  edge [
    source 1335
    target 1340
    kind "mentions"
  ]
  edge [
    source 1335
    target 1341
    kind "mentions"
  ]
  edge [
    source 1335
    target 1342
    kind "mentions"
  ]
  edge [
    source 1335
    target 1343
    kind "mentions"
  ]
  edge [
    source 1335
    target 1344
    kind "mentions"
  ]
  edge [
    source 1335
    target 1345
    kind "mentions"
  ]
  edge [
    source 1335
    target 1346
    kind "mentions"
  ]
  edge [
    source 1335
    target 1347
    kind "mentions"
  ]
  edge [
    source 1335
    target 1348
    kind "mentions"
  ]
  edge [
    source 1335
    target 1349
    kind "mentions"
  ]
  edge [
    source 1335
    target 1350
    kind "mentions"
  ]
  edge [
    source 1335
    target 1351
    kind "mentions"
  ]
  edge [
    source 1335
    target 1352
    kind "mentions"
  ]
  edge [
    source 1335
    target 1353
    kind "mentions"
  ]
  edge [
    source 1335
    target 1949
    kind "summarizes"
  ]
  edge [
    source 1336
    target 1337
    kind "relation"
    relation "helps to"
    weight 1
  ]
  edge [
    source 1336
    target 1338
    kind "relation"
    relation "helps to"
    weight 1
  ]
  edge [
    source 1339
    target 1340
    kind "relation"
    relation "is attached to"
    weight 1
  ]
  edge [
    source 1339
    target 1341
    kind "relation"
    relation "allows pulling of"
    weight 1
  ]
  edge [
    source 1339
    target 1352
    kind "relation"
    relation "marks the height of"
    weight 1
  ]
  edge [
    source 1340
    target 1341
    kind "relation"
    relation "passes over"
    weight 1
  ]
  edge [
    source 1342
    target 1348
    kind "relation"
    relation "helps to"
    weight 1
  ]
  edge [
    source 1346
    target 1347
    kind "relation"
    relation "enables tracking of"
    weight 1
  ]
  edge [
    source 1349
    target 1350
    kind "relation"
    relation "helps to"
    weight 1
  ]
  edge [
    source 1351
    target 1435
    kind "mentions"
  ]
  edge [
    source 1351
    target 1625
    kind "mentions"
  ]
  edge [
    source 1352
    target 1353
    kind "relation"
    relation "is repeated"
    weight 1
  ]
  edge [
    source 1354
    target 1355
    kind "mentions"
  ]
  edge [
    source 1354
    target 1356
    kind "mentions"
  ]
  edge [
    source 1354
    target 1357
    kind "mentions"
  ]
  edge [
    source 1354
    target 1358
    kind "mentions"
  ]
  edge [
    source 1354
    target 1359
    kind "mentions"
  ]
  edge [
    source 1354
    target 1360
    kind "mentions"
  ]
  edge [
    source 1354
    target 1946
    kind "summarizes"
  ]
  edge [
    source 1361
    target 1362
    kind "mentions"
  ]
  edge [
    source 1361
    target 1945
    kind "summarizes"
  ]
  edge [
    source 1363
    target 1364
    kind "from_chunk"
  ]
  edge [
    source 1364
    target 1365
    kind "mentions"
  ]
  edge [
    source 1364
    target 1366
    kind "mentions"
  ]
  edge [
    source 1364
    target 1367
    kind "mentions"
  ]
  edge [
    source 1364
    target 1368
    kind "mentions"
  ]
  edge [
    source 1364
    target 1369
    kind "mentions"
  ]
  edge [
    source 1364
    target 1370
    kind "mentions"
  ]
  edge [
    source 1364
    target 1371
    kind "mentions"
  ]
  edge [
    source 1364
    target 1372
    kind "mentions"
  ]
  edge [
    source 1364
    target 1373
    kind "mentions"
  ]
  edge [
    source 1364
    target 1374
    kind "mentions"
  ]
  edge [
    source 1364
    target 1375
    kind "mentions"
  ]
  edge [
    source 1364
    target 1376
    kind "mentions"
  ]
  edge [
    source 1364
    target 1377
    kind "mentions"
  ]
  edge [
    source 1364
    target 1378
    kind "mentions"
  ]
  edge [
    source 1364
    target 1379
    kind "mentions"
  ]
  edge [
    source 1364
    target 1380
    kind "mentions"
  ]
  edge [
    source 1364
    target 1957
    kind "summarizes"
  ]
  edge [
    source 1365
    target 1374
    kind "relation"
    relation "begins to turn sour or hard when"
    weight 1
  ]
  edge [
    source 1365
    target 1375
    kind "relation"
    relation "becomes poisonous as soon as"
    weight 1
  ]
  edge [
    source 1369
    target 1379
    kind "relation"
    relation "lasts only a little while"
    weight 1
  ]
  edge [
    source 1370
    target 1373
    kind "relation"
    relation "cannot give"
    weight 1
  ]
  edge [
    source 1379
    target 1380
    kind "relation"
    relation "feel weaker than before"
    weight 1
  ]
  edge [
    source 1381
    target 1382
    kind "from_chunk"
  ]
  edge [
    source 1381
    target 1399
    kind "from_chunk"
  ]
  edge [
    source 1382
    target 1383
    kind "mentions"
  ]
  edge [
    source 1382
    target 1384
    kind "mentions"
  ]
  edge [
    source 1382
    target 1385
    kind "mentions"
  ]
  edge [
    source 1382
    target 1386
    kind "mentions"
  ]
  edge [
    source 1382
    target 1387
    kind "mentions"
  ]
  edge [
    source 1382
    target 1388
    kind "mentions"
  ]
  edge [
    source 1382
    target 1389
    kind "mentions"
  ]
  edge [
    source 1382
    target 1390
    kind "mentions"
  ]
  edge [
    source 1382
    target 1391
    kind "mentions"
  ]
  edge [
    source 1382
    target 1392
    kind "mentions"
  ]
  edge [
    source 1382
    target 1393
    kind "mentions"
  ]
  edge [
    source 1382
    target 1394
    kind "mentions"
  ]
  edge [
    source 1382
    target 1395
    kind "mentions"
  ]
  edge [
    source 1382
    target 1396
    kind "mentions"
  ]
  edge [
    source 1382
    target 1397
    kind "mentions"
  ]
  edge [
    source 1382
    target 1398
    kind "mentions"
  ]
  edge [
    source 1382
    target 1961
    kind "summarizes"
  ]
  edge [
    source 1383
    target 1397
    kind "relation"
    relation "told a story about"
    weight 1
  ]
  edge [
    source 1383
    target 1398
    kind "relation"
    relation "observed that drinking rum made"
    weight 1
  ]
  edge [
    source 1383
    target 1399
    kind "mentions"
  ]
  edge [
    source 1383
    target 1400
    kind "relation"
    relation "concluded that going without rum improved"
    weight 1
  ]
  edge [
    source 1383
    target 1401
    kind "relation"
    relation "observed that drinking rum made"
    weight 1
  ]
  edge [
    source 1388
    target 1389
    kind "relation"
    relation "caused them to have hard work"
    weight 1
  ]
  edge [
    source 1388
    target 1399
    kind "mentions"
  ]
  edge [
    source 1388
    target 1391
    kind "relation"
    relation "performed better when given"
    weight 1
  ]
  edge [
    source 1388
    target 1421
    kind "mentions"
  ]
  edge [
    source 1389
    target 1399
    kind "mentions"
  ]
  edge [
    source 1390
    target 1550
    kind "mentions"
  ]
  edge [
    source 1390
    target 1565
    kind "relation"
    relation "causes"
    weight 1
  ]
  edge [
    source 1391
    target 1399
    kind "mentions"
  ]
  edge [
    source 1395
    target 1399
    kind "mentions"
  ]
  edge [
    source 1396
    target 1399
    kind "mentions"
  ]
  edge [
    source 1399
    target 1400
    kind "mentions"
  ]
  edge [
    source 1399
    target 1401
    kind "mentions"
  ]
  edge [
    source 1399
    target 1961
    kind "summarizes"
  ]
  edge [
    source 1402
    target 1403
    kind "from_chunk"
  ]
  edge [
    source 1403
    target 1404
    kind "mentions"
  ]
  edge [
    source 1403
    target 1405
    kind "mentions"
  ]
  edge [
    source 1403
    target 1406
    kind "mentions"
  ]
  edge [
    source 1403
    target 1407
    kind "mentions"
  ]
  edge [
    source 1403
    target 1408
    kind "mentions"
  ]
  edge [
    source 1403
    target 1409
    kind "mentions"
  ]
  edge [
    source 1403
    target 1410
    kind "mentions"
  ]
  edge [
    source 1403
    target 1411
    kind "mentions"
  ]
  edge [
    source 1403
    target 1412
    kind "mentions"
  ]
  edge [
    source 1403
    target 1413
    kind "mentions"
  ]
  edge [
    source 1403
    target 1414
    kind "mentions"
  ]
  edge [
    source 1403
    target 1415
    kind "mentions"
  ]
  edge [
    source 1403
    target 1416
    kind "mentions"
  ]
  edge [
    source 1403
    target 1417
    kind "mentions"
  ]
  edge [
    source 1403
    target 1418
    kind "mentions"
  ]
  edge [
    source 1403
    target 1419
    kind "mentions"
  ]
  edge [
    source 1403
    target 1954
    kind "summarizes"
  ]
  edge [
    source 1404
    target 1415
    kind "relation"
    relation "is the best kind of strength"
    weight 1
  ]
  edge [
    source 1405
    target 1874
    kind "mentions"
  ]
  edge [
    source 1405
    target 1891
    kind "mentions"
  ]
  edge [
    source 1405
    target 1907
    kind "mentions"
  ]
  edge [
    source 1411
    target 1417
    kind "relation"
    relation "has"
    weight 1
  ]
  edge [
    source 1412
    target 1417
    kind "relation"
    relation "can study"
    weight 1
  ]
  edge [
    source 1413
    target 1417
    kind "relation"
    relation "can understand"
    weight 1
  ]
  edge [
    source 1414
    target 1417
    kind "relation"
    relation "can think well"
    weight 1
  ]
  edge [
    source 1417
    target 1418
    kind "relation"
    relation "has"
    weight 1
  ]
  edge [
    source 1417
    target 1419
    kind "relation"
    relation "would prefer"
    weight 1
  ]
  edge [
    source 1420
    target 1421
    kind "from_chunk"
  ]
  edge [
    source 1420
    target 1427
    kind "from_chunk"
  ]
  edge [
    source 1421
    target 1422
    kind "mentions"
  ]
  edge [
    source 1421
    target 1423
    kind "mentions"
  ]
  edge [
    source 1421
    target 1424
    kind "mentions"
  ]
  edge [
    source 1421
    target 1425
    kind "mentions"
  ]
  edge [
    source 1421
    target 1426
    kind "mentions"
  ]
  edge [
    source 1421
    target 1943
    kind "summarizes"
  ]
  edge [
    source 1424
    target 1426
    kind "relation"
    relation "is"
    weight 1
  ]
  edge [
    source 1427
    target 1428
    kind "mentions"
  ]
  edge [
    source 1427
    target 1429
    kind "mentions"
  ]
  edge [
    source 1427
    target 1430
    kind "mentions"
  ]
  edge [
    source 1427
    target 1431
    kind "mentions"
  ]
  edge [
    source 1427
    target 1432
    kind "mentions"
  ]
  edge [
    source 1427
    target 1433
    kind "mentions"
  ]
  edge [
    source 1427
    target 1938
    kind "summarizes"
  ]
  edge [
    source 1428
    target 1429
    kind "relation"
    relation "is structurally similar to"
    weight 1
  ]
  edge [
    source 1430
    target 1431
    kind "relation"
    relation "pumps water through"
    weight 1
  ]
  edge [
    source 1431
    target 1432
    kind "relation"
    relation "are shaped like"
    weight 1
  ]
  edge [
    source 1432
    target 1435
    kind "mentions"
  ]
  edge [
    source 1432
    target 1462
    kind "mentions"
  ]
  edge [
    source 1434
    target 1435
    kind "from_chunk"
  ]
  edge [
    source 1434
    target 1446
    kind "from_chunk"
  ]
  edge [
    source 1435
    target 1436
    kind "mentions"
  ]
  edge [
    source 1435
    target 1437
    kind "mentions"
  ]
  edge [
    source 1435
    target 1438
    kind "mentions"
  ]
  edge [
    source 1435
    target 1439
    kind "mentions"
  ]
  edge [
    source 1435
    target 1440
    kind "mentions"
  ]
  edge [
    source 1435
    target 1441
    kind "mentions"
  ]
  edge [
    source 1435
    target 1442
    kind "mentions"
  ]
  edge [
    source 1435
    target 1443
    kind "mentions"
  ]
  edge [
    source 1435
    target 1444
    kind "mentions"
  ]
  edge [
    source 1435
    target 1445
    kind "mentions"
  ]
  edge [
    source 1435
    target 1938
    kind "summarizes"
  ]
  edge [
    source 1436
    target 1437
    kind "relation"
    relation "has visible veins in"
    weight 1
  ]
  edge [
    source 1436
    target 1462
    kind "mentions"
  ]
  edge [
    source 1436
    target 1467
    kind "mentions"
  ]
  edge [
    source 1436
    target 1529
    kind "mentions"
  ]
  edge [
    source 1438
    target 1439
    kind "relation"
    relation "allows feeling of"
    weight 1
  ]
  edge [
    source 1438
    target 1440
    kind "relation"
    relation "indicates"
    weight 1
  ]
  edge [
    source 1438
    target 1462
    kind "mentions"
  ]
  edge [
    source 1438
    target 1460
    kind "relation"
    relation "indicates"
    weight 1
  ]
  edge [
    source 1443
    target 1446
    kind "mentions"
  ]
  edge [
    source 1444
    target 1445
    kind "relation"
    relation "is not made when"
    weight 1
  ]
  edge [
    source 1444
    target 1446
    kind "mentions"
  ]
  edge [
    source 1446
    target 1938
    kind "summarizes"
  ]
  edge [
    source 1447
    target 1448
    kind "from_chunk"
  ]
  edge [
    source 1447
    target 1450
    kind "from_chunk"
  ]
  edge [
    source 1447
    target 1457
    kind "from_chunk"
  ]
  edge [
    source 1447
    target 1462
    kind "from_chunk"
  ]
  edge [
    source 1448
    target 1449
    kind "mentions"
  ]
  edge [
    source 1448
    target 1942
    kind "summarizes"
  ]
  edge [
    source 1449
    target 1462
    kind "mentions"
  ]
  edge [
    source 1450
    target 1451
    kind "mentions"
  ]
  edge [
    source 1450
    target 1452
    kind "mentions"
  ]
  edge [
    source 1450
    target 1453
    kind "mentions"
  ]
  edge [
    source 1450
    target 1454
    kind "mentions"
  ]
  edge [
    source 1450
    target 1455
    kind "mentions"
  ]
  edge [
    source 1450
    target 1456
    kind "mentions"
  ]
  edge [
    source 1450
    target 1938
    kind "summarizes"
  ]
  edge [
    source 1451
    target 1481
    kind "mentions"
  ]
  edge [
    source 1451
    target 1498
    kind "mentions"
  ]
  edge [
    source 1451
    target 1504
    kind "relation"
    relation "has no fresh air entry"
    weight 1
  ]
  edge [
    source 1451
    target 1505
    kind "mentions"
  ]
  edge [
    source 1451
    target 1514
    kind "mentions"
  ]
  edge [
    source 1451
    target 1515
    kind "relation"
    relation "prevent access to"
    weight 1
  ]
  edge [
    source 1451
    target 1605
    kind "mentions"
  ]
  edge [
    source 1451
    target 1557
    kind "relation"
    relation "causes"
    weight 1
  ]
  edge [
    source 1451
    target 1625
    kind "mentions"
  ]
  edge [
    source 1452
    target 1462
    kind "mentions"
  ]
  edge [
    source 1455
    target 1462
    kind "mentions"
  ]
  edge [
    source 1456
    target 1462
    kind "mentions"
  ]
  edge [
    source 1457
    target 1458
    kind "mentions"
  ]
  edge [
    source 1457
    target 1459
    kind "mentions"
  ]
  edge [
    source 1457
    target 1460
    kind "mentions"
  ]
  edge [
    source 1457
    target 1461
    kind "mentions"
  ]
  edge [
    source 1457
    target 1938
    kind "summarizes"
  ]
  edge [
    source 1458
    target 1459
    kind "relation"
    relation "cannot work as well as"
    weight 1
  ]
  edge [
    source 1460
    target 1462
    kind "mentions"
  ]
  edge [
    source 1462
    target 1463
    kind "mentions"
  ]
  edge [
    source 1462
    target 1464
    kind "mentions"
  ]
  edge [
    source 1462
    target 1465
    kind "mentions"
  ]
  edge [
    source 1462
    target 1938
    kind "summarizes"
  ]
  edge [
    source 1466
    target 1467
    kind "from_chunk"
  ]
  edge [
    source 1466
    target 1477
    kind "from_chunk"
  ]
  edge [
    source 1467
    target 1468
    kind "mentions"
  ]
  edge [
    source 1467
    target 1469
    kind "mentions"
  ]
  edge [
    source 1467
    target 1470
    kind "mentions"
  ]
  edge [
    source 1467
    target 1471
    kind "mentions"
  ]
  edge [
    source 1467
    target 1472
    kind "mentions"
  ]
  edge [
    source 1467
    target 1473
    kind "mentions"
  ]
  edge [
    source 1467
    target 1474
    kind "mentions"
  ]
  edge [
    source 1467
    target 1475
    kind "mentions"
  ]
  edge [
    source 1467
    target 1476
    kind "mentions"
  ]
  edge [
    source 1467
    target 1938
    kind "summarizes"
  ]
  edge [
    source 1468
    target 1477
    kind "mentions"
  ]
  edge [
    source 1469
    target 1514
    kind "mentions"
  ]
  edge [
    source 1471
    target 1477
    kind "mentions"
  ]
  edge [
    source 1471
    target 1481
    kind "mentions"
  ]
  edge [
    source 1477
    target 1478
    kind "mentions"
  ]
  edge [
    source 1477
    target 1479
    kind "mentions"
  ]
  edge [
    source 1477
    target 1938
    kind "summarizes"
  ]
  edge [
    source 1480
    target 1481
    kind "from_chunk"
  ]
  edge [
    source 1480
    target 1491
    kind "from_chunk"
  ]
  edge [
    source 1481
    target 1482
    kind "mentions"
  ]
  edge [
    source 1481
    target 1483
    kind "mentions"
  ]
  edge [
    source 1481
    target 1484
    kind "mentions"
  ]
  edge [
    source 1481
    target 1485
    kind "mentions"
  ]
  edge [
    source 1481
    target 1486
    kind "mentions"
  ]
  edge [
    source 1481
    target 1487
    kind "mentions"
  ]
  edge [
    source 1481
    target 1488
    kind "mentions"
  ]
  edge [
    source 1481
    target 1489
    kind "mentions"
  ]
  edge [
    source 1481
    target 1490
    kind "mentions"
  ]
  edge [
    source 1481
    target 1938
    kind "summarizes"
  ]
  edge [
    source 1483
    target 1505
    kind "mentions"
  ]
  edge [
    source 1485
    target 1486
    kind "relation"
    relation "restricts"
    weight 1
  ]
  edge [
    source 1486
    target 1490
    kind "relation"
    relation "is necessary for | is required for"
    weight 2
  ]
  edge [
    source 1486
    target 1491
    kind "mentions"
  ]
  edge [
    source 1486
    target 1492
    kind "relation"
    relation "is necessary for"
    weight 1
  ]
  edge [
    source 1487
    target 1491
    kind "mentions"
  ]
  edge [
    source 1489
    target 1628
    kind "mentions"
  ]
  edge [
    source 1490
    target 1491
    kind "mentions"
  ]
  edge [
    source 1491
    target 1492
    kind "mentions"
  ]
  edge [
    source 1491
    target 1493
    kind "mentions"
  ]
  edge [
    source 1491
    target 1494
    kind "mentions"
  ]
  edge [
    source 1491
    target 1938
    kind "summarizes"
  ]
  edge [
    source 1492
    target 1494
    kind "relation"
    relation "prevents"
    weight 1
  ]
  edge [
    source 1495
    target 1496
    kind "from_chunk"
  ]
  edge [
    source 1495
    target 1498
    kind "from_chunk"
  ]
  edge [
    source 1495
    target 1505
    kind "from_chunk"
  ]
  edge [
    source 1495
    target 1508
    kind "from_chunk"
  ]
  edge [
    source 1496
    target 1497
    kind "mentions"
  ]
  edge [
    source 1496
    target 1938
    kind "summarizes"
  ]
  edge [
    source 1498
    target 1499
    kind "mentions"
  ]
  edge [
    source 1498
    target 1500
    kind "mentions"
  ]
  edge [
    source 1498
    target 1501
    kind "mentions"
  ]
  edge [
    source 1498
    target 1502
    kind "mentions"
  ]
  edge [
    source 1498
    target 1503
    kind "mentions"
  ]
  edge [
    source 1498
    target 1504
    kind "mentions"
  ]
  edge [
    source 1498
    target 1938
    kind "summarizes"
  ]
  edge [
    source 1499
    target 1541
    kind "mentions"
  ]
  edge [
    source 1499
    target 1550
    kind "mentions"
  ]
  edge [
    source 1499
    target 1577
    kind "mentions"
  ]
  edge [
    source 1499
    target 1581
    kind "relation"
    relation "involves removing"
    weight 1
  ]
  edge [
    source 1499
    target 1582
    kind "relation"
    relation "passes through | fail to expel"
    weight 2
  ]
  edge [
    source 1499
    target 1598
    kind "relation"
    relation "can clog"
    weight 1
  ]
  edge [
    source 1499
    target 1583
    kind "relation"
    relation "should be washed off with"
    weight 1
  ]
  edge [
    source 1499
    target 1625
    kind "mentions"
  ]
  edge [
    source 1499
    target 1808
    kind "mentions"
  ]
  edge [
    source 1500
    target 1504
    kind "relation"
    relation "are closed"
    weight 1
  ]
  edge [
    source 1501
    target 1504
    kind "relation"
    relation "are closed"
    weight 1
  ]
  edge [
    source 1502
    target 1504
    kind "relation"
    relation "is closed"
    weight 1
  ]
  edge [
    source 1503
    target 1504
    kind "relation"
    relation "is closed"
    weight 1
  ]
  edge [
    source 1504
    target 1618
    kind "mentions"
  ]
  edge [
    source 1504
    target 1779
    kind "mentions"
  ]
  edge [
    source 1505
    target 1506
    kind "mentions"
  ]
  edge [
    source 1505
    target 1507
    kind "mentions"
  ]
  edge [
    source 1505
    target 1938
    kind "summarizes"
  ]
  edge [
    source 1506
    target 1507
    kind "relation"
    relation "causes"
    weight 1
  ]
  edge [
    source 1508
    target 1509
    kind "mentions"
  ]
  edge [
    source 1508
    target 1510
    kind "mentions"
  ]
  edge [
    source 1508
    target 1511
    kind "mentions"
  ]
  edge [
    source 1508
    target 1512
    kind "mentions"
  ]
  edge [
    source 1508
    target 1938
    kind "summarizes"
  ]
  edge [
    source 1513
    target 1514
    kind "from_chunk"
  ]
  edge [
    source 1513
    target 1527
    kind "from_chunk"
  ]
  edge [
    source 1514
    target 1515
    kind "mentions"
  ]
  edge [
    source 1514
    target 1516
    kind "mentions"
  ]
  edge [
    source 1514
    target 1517
    kind "mentions"
  ]
  edge [
    source 1514
    target 1518
    kind "mentions"
  ]
  edge [
    source 1514
    target 1519
    kind "mentions"
  ]
  edge [
    source 1514
    target 1520
    kind "mentions"
  ]
  edge [
    source 1514
    target 1521
    kind "mentions"
  ]
  edge [
    source 1514
    target 1522
    kind "mentions"
  ]
  edge [
    source 1514
    target 1523
    kind "mentions"
  ]
  edge [
    source 1514
    target 1524
    kind "mentions"
  ]
  edge [
    source 1514
    target 1525
    kind "mentions"
  ]
  edge [
    source 1514
    target 1526
    kind "mentions"
  ]
  edge [
    source 1514
    target 1938
    kind "summarizes"
  ]
  edge [
    source 1517
    target 1529
    kind "mentions"
  ]
  edge [
    source 1518
    target 1577
    kind "mentions"
  ]
  edge [
    source 1518
    target 1637
    kind "mentions"
  ]
  edge [
    source 1518
    target 1619
    kind "relation"
    relation "accumulate"
    weight 1
  ]
  edge [
    source 1520
    target 1527
    kind "mentions"
  ]
  edge [
    source 1521
    target 1522
    kind "relation"
    relation "filters out"
    weight 1
  ]
  edge [
    source 1524
    target 1525
    kind "relation"
    relation "reduces"
    weight 1
  ]
  edge [
    source 1527
    target 1938
    kind "summarizes"
  ]
  edge [
    source 1528
    target 1529
    kind "from_chunk"
  ]
  edge [
    source 1528
    target 1541
    kind "from_chunk"
  ]
  edge [
    source 1529
    target 1530
    kind "mentions"
  ]
  edge [
    source 1529
    target 1531
    kind "mentions"
  ]
  edge [
    source 1529
    target 1532
    kind "mentions"
  ]
  edge [
    source 1529
    target 1533
    kind "mentions"
  ]
  edge [
    source 1529
    target 1534
    kind "mentions"
  ]
  edge [
    source 1529
    target 1535
    kind "mentions"
  ]
  edge [
    source 1529
    target 1536
    kind "mentions"
  ]
  edge [
    source 1529
    target 1537
    kind "mentions"
  ]
  edge [
    source 1529
    target 1538
    kind "mentions"
  ]
  edge [
    source 1529
    target 1539
    kind "mentions"
  ]
  edge [
    source 1529
    target 1540
    kind "mentions"
  ]
  edge [
    source 1529
    target 1938
    kind "summarizes"
  ]
  edge [
    source 1537
    target 1540
    kind "relation"
    relation "should breathe"
    weight 1
  ]
  edge [
    source 1540
    target 1724
    kind "mentions"
  ]
  edge [
    source 1541
    target 1542
    kind "mentions"
  ]
  edge [
    source 1541
    target 1543
    kind "mentions"
  ]
  edge [
    source 1541
    target 1544
    kind "mentions"
  ]
  edge [
    source 1541
    target 1545
    kind "mentions"
  ]
  edge [
    source 1541
    target 1546
    kind "mentions"
  ]
  edge [
    source 1541
    target 1547
    kind "mentions"
  ]
  edge [
    source 1541
    target 1548
    kind "mentions"
  ]
  edge [
    source 1541
    target 1951
    kind "summarizes"
  ]
  edge [
    source 1542
    target 1544
    kind "relation"
    relation "meets lining skin at"
    weight 1
  ]
  edge [
    source 1542
    target 1546
    kind "relation"
    relation "is under the thin outer layer"
    weight 1
  ]
  edge [
    source 1545
    target 1548
    kind "relation"
    relation "can be pulled off without hurting"
    weight 1
  ]
  edge [
    source 1546
    target 1547
    kind "relation"
    relation "contains many nerves"
    weight 1
  ]
  edge [
    source 1546
    target 1550
    kind "mentions"
  ]
  edge [
    source 1546
    target 1551
    kind "relation"
    relation "protects"
    weight 1
  ]
  edge [
    source 1546
    target 1564
    kind "relation"
    relation "must be covered to prevent harm when"
    weight 1
  ]
  edge [
    source 1549
    target 1550
    kind "from_chunk"
  ]
  edge [
    source 1549
    target 1571
    kind "from_chunk"
  ]
  edge [
    source 1550
    target 1551
    kind "mentions"
  ]
  edge [
    source 1550
    target 1552
    kind "mentions"
  ]
  edge [
    source 1550
    target 1553
    kind "mentions"
  ]
  edge [
    source 1550
    target 1554
    kind "mentions"
  ]
  edge [
    source 1550
    target 1555
    kind "mentions"
  ]
  edge [
    source 1550
    target 1556
    kind "mentions"
  ]
  edge [
    source 1550
    target 1557
    kind "mentions"
  ]
  edge [
    source 1550
    target 1558
    kind "mentions"
  ]
  edge [
    source 1550
    target 1559
    kind "mentions"
  ]
  edge [
    source 1550
    target 1560
    kind "mentions"
  ]
  edge [
    source 1550
    target 1561
    kind "mentions"
  ]
  edge [
    source 1550
    target 1562
    kind "mentions"
  ]
  edge [
    source 1550
    target 1563
    kind "mentions"
  ]
  edge [
    source 1550
    target 1564
    kind "mentions"
  ]
  edge [
    source 1550
    target 1565
    kind "mentions"
  ]
  edge [
    source 1550
    target 1566
    kind "mentions"
  ]
  edge [
    source 1550
    target 1567
    kind "mentions"
  ]
  edge [
    source 1550
    target 1568
    kind "mentions"
  ]
  edge [
    source 1550
    target 1569
    kind "mentions"
  ]
  edge [
    source 1550
    target 1570
    kind "mentions"
  ]
  edge [
    source 1550
    target 1951
    kind "summarizes"
  ]
  edge [
    source 1552
    target 1565
    kind "relation"
    relation "causes"
    weight 1
  ]
  edge [
    source 1553
    target 1565
    kind "relation"
    relation "causes"
    weight 1
  ]
  edge [
    source 1554
    target 1556
    kind "relation"
    relation "is covered with"
    weight 1
  ]
  edge [
    source 1555
    target 1556
    kind "relation"
    relation "is covered with"
    weight 1
  ]
  edge [
    source 1557
    target 1558
    kind "relation"
    relation "comes through"
    weight 1
  ]
  edge [
    source 1557
    target 1569
    kind "relation"
    relation "is not always visible because"
    weight 1
  ]
  edge [
    source 1557
    target 1562
    kind "relation"
    relation "helps keep"
    weight 1
  ]
  edge [
    source 1557
    target 1577
    kind "mentions"
  ]
  edge [
    source 1557
    target 1605
    kind "mentions"
  ]
  edge [
    source 1557
    target 1610
    kind "relation"
    relation "allows"
    weight 1
  ]
  edge [
    source 1557
    target 1611
    kind "mentions"
  ]
  edge [
    source 1557
    target 1612
    kind "relation"
    relation "brings out"
    weight 1
  ]
  edge [
    source 1557
    target 1625
    kind "mentions"
  ]
  edge [
    source 1559
    target 1566
    kind "relation"
    relation "is the mouth of"
    weight 1
  ]
  edge [
    source 1559
    target 1567
    kind "relation"
    relation "carries off"
    weight 1
  ]
  edge [
    source 1560
    target 1568
    kind "relation"
    relation "would form a line longer than"
    weight 1
  ]
  edge [
    source 1561
    target 1786
    kind "mentions"
  ]
  edge [
    source 1561
    target 1789
    kind "relation"
    relation "keep warm in"
    weight 1
  ]
  edge [
    source 1571
    target 1572
    kind "mentions"
  ]
  edge [
    source 1571
    target 1573
    kind "mentions"
  ]
  edge [
    source 1571
    target 1574
    kind "mentions"
  ]
  edge [
    source 1571
    target 1575
    kind "mentions"
  ]
  edge [
    source 1571
    target 1950
    kind "summarizes"
  ]
  edge [
    source 1572
    target 1573
    kind "relation"
    relation "are shields that protect | would be badly off without"
    weight 2
  ]
  edge [
    source 1573
    target 1574
    kind "relation"
    relation "are full of"
    weight 1
  ]
  edge [
    source 1574
    target 1577
    kind "mentions"
  ]
  edge [
    source 1574
    target 1578
    kind "relation"
    relation "are full of"
    weight 1
  ]
  edge [
    source 1576
    target 1577
    kind "from_chunk"
  ]
  edge [
    source 1577
    target 1578
    kind "mentions"
  ]
  edge [
    source 1577
    target 1579
    kind "mentions"
  ]
  edge [
    source 1577
    target 1580
    kind "mentions"
  ]
  edge [
    source 1577
    target 1581
    kind "mentions"
  ]
  edge [
    source 1577
    target 1582
    kind "mentions"
  ]
  edge [
    source 1577
    target 1583
    kind "mentions"
  ]
  edge [
    source 1577
    target 1584
    kind "mentions"
  ]
  edge [
    source 1577
    target 1585
    kind "mentions"
  ]
  edge [
    source 1577
    target 1586
    kind "mentions"
  ]
  edge [
    source 1577
    target 1587
    kind "mentions"
  ]
  edge [
    source 1577
    target 1588
    kind "mentions"
  ]
  edge [
    source 1577
    target 1589
    kind "mentions"
  ]
  edge [
    source 1577
    target 1590
    kind "mentions"
  ]
  edge [
    source 1577
    target 1591
    kind "mentions"
  ]
  edge [
    source 1577
    target 1592
    kind "mentions"
  ]
  edge [
    source 1577
    target 1593
    kind "mentions"
  ]
  edge [
    source 1577
    target 1594
    kind "mentions"
  ]
  edge [
    source 1577
    target 1595
    kind "mentions"
  ]
  edge [
    source 1577
    target 1596
    kind "mentions"
  ]
  edge [
    source 1577
    target 1597
    kind "mentions"
  ]
  edge [
    source 1577
    target 1598
    kind "mentions"
  ]
  edge [
    source 1577
    target 1599
    kind "mentions"
  ]
  edge [
    source 1577
    target 1600
    kind "mentions"
  ]
  edge [
    source 1577
    target 1601
    kind "mentions"
  ]
  edge [
    source 1577
    target 1602
    kind "mentions"
  ]
  edge [
    source 1577
    target 1603
    kind "mentions"
  ]
  edge [
    source 1577
    target 1950
    kind "summarizes"
  ]
  edge [
    source 1578
    target 1579
    kind "relation"
    relation "depend on"
    weight 1
  ]
  edge [
    source 1582
    target 1625
    kind "mentions"
  ]
  edge [
    source 1582
    target 1808
    kind "mentions"
  ]
  edge [
    source 1582
    target 1809
    kind "relation"
    relation "causes closure of"
    weight 1
  ]
  edge [
    source 1588
    target 1599
    kind "relation"
    relation "is just as harmful as"
    weight 1
  ]
  edge [
    source 1588
    target 1600
    kind "relation"
    relation "is released gradually"
    weight 1
  ]
  edge [
    source 1590
    target 1591
    kind "relation"
    relation "keeps"
    weight 1
  ]
  edge [
    source 1590
    target 1592
    kind "relation"
    relation "keeps"
    weight 1
  ]
  edge [
    source 1591
    target 1593
    kind "relation"
    relation "is able to do"
    weight 1
  ]
  edge [
    source 1593
    target 1601
    kind "relation"
    relation "is essential for"
    weight 1
  ]
  edge [
    source 1594
    target 1602
    kind "relation"
    relation "prevent"
    weight 1
  ]
  edge [
    source 1594
    target 1632
    kind "mentions"
  ]
  edge [
    source 1594
    target 1608
    kind "relation"
    relation "should not be worn in"
    weight 1
  ]
  edge [
    source 1595
    target 1602
    kind "relation"
    relation "prevent"
    weight 1
  ]
  edge [
    source 1596
    target 1603
    kind "relation"
    relation "cause"
    weight 1
  ]
  edge [
    source 1596
    target 1597
    kind "relation"
    relation "lead to"
    weight 1
  ]
  edge [
    source 1604
    target 1605
    kind "from_chunk"
  ]
  edge [
    source 1604
    target 1611
    kind "from_chunk"
  ]
  edge [
    source 1604
    target 1618
    kind "from_chunk"
  ]
  edge [
    source 1605
    target 1606
    kind "mentions"
  ]
  edge [
    source 1605
    target 1607
    kind "mentions"
  ]
  edge [
    source 1605
    target 1608
    kind "mentions"
  ]
  edge [
    source 1605
    target 1609
    kind "mentions"
  ]
  edge [
    source 1605
    target 1610
    kind "mentions"
  ]
  edge [
    source 1605
    target 1950
    kind "summarizes"
  ]
  edge [
    source 1606
    target 1607
    kind "relation"
    relation "requires wearing"
    weight 1
  ]
  edge [
    source 1607
    target 1608
    kind "relation"
    relation "must be removed when entering"
    weight 1
  ]
  edge [
    source 1608
    target 1632
    kind "mentions"
  ]
  edge [
    source 1609
    target 1808
    kind "mentions"
  ]
  edge [
    source 1609
    target 1812
    kind "relation"
    relation "causes suffering in"
    weight 1
  ]
  edge [
    source 1611
    target 1612
    kind "mentions"
  ]
  edge [
    source 1611
    target 1613
    kind "mentions"
  ]
  edge [
    source 1611
    target 1614
    kind "mentions"
  ]
  edge [
    source 1611
    target 1615
    kind "mentions"
  ]
  edge [
    source 1611
    target 1616
    kind "mentions"
  ]
  edge [
    source 1611
    target 1617
    kind "mentions"
  ]
  edge [
    source 1611
    target 1951
    kind "summarizes"
  ]
  edge [
    source 1612
    target 1613
    kind "relation"
    relation "should be removed by"
    weight 1
  ]
  edge [
    source 1613
    target 1618
    kind "mentions"
  ]
  edge [
    source 1613
    target 1619
    kind "relation"
    relation "should have | may have"
    weight 2
  ]
  edge [
    source 1613
    target 1620
    kind "relation"
    relation "should have | may have"
    weight 2
  ]
  edge [
    source 1613
    target 1623
    kind "mentions"
  ]
  edge [
    source 1613
    target 1624
    kind "relation"
    relation "requires"
    weight 1
  ]
  edge [
    source 1614
    target 1615
    kind "relation"
    relation "should not be rolled up and placed under"
    weight 1
  ]
  edge [
    source 1614
    target 1616
    kind "relation"
    relation "should be aired at"
    weight 1
  ]
  edge [
    source 1614
    target 1617
    kind "relation"
    relation "should be hung where"
    weight 1
  ]
  edge [
    source 1614
    target 1636
    kind "mentions"
  ]
  edge [
    source 1614
    target 1621
    kind "relation"
    relation "should be placed in"
    weight 1
  ]
  edge [
    source 1618
    target 1619
    kind "mentions"
  ]
  edge [
    source 1618
    target 1620
    kind "mentions"
  ]
  edge [
    source 1618
    target 1621
    kind "mentions"
  ]
  edge [
    source 1618
    target 1951
    kind "summarizes"
  ]
  edge [
    source 1619
    target 1620
    kind "relation"
    relation "should be removed from"
    weight 1
  ]
  edge [
    source 1619
    target 1623
    kind "mentions"
  ]
  edge [
    source 1619
    target 1637
    kind "mentions"
  ]
  edge [
    source 1619
    target 1638
    kind "relation"
    relation "accumulate"
    weight 1
  ]
  edge [
    source 1619
    target 1639
    kind "relation"
    relation "accumulate"
    weight 1
  ]
  edge [
    source 1620
    target 1623
    kind "mentions"
  ]
  edge [
    source 1621
    target 1634
    kind "mentions"
  ]
  edge [
    source 1621
    target 1635
    kind "relation"
    relation "should be changed at"
    weight 1
  ]
  edge [
    source 1621
    target 1636
    kind "mentions"
  ]
  edge [
    source 1622
    target 1623
    kind "from_chunk"
  ]
  edge [
    source 1622
    target 1625
    kind "from_chunk"
  ]
  edge [
    source 1622
    target 1628
    kind "from_chunk"
  ]
  edge [
    source 1623
    target 1624
    kind "mentions"
  ]
  edge [
    source 1623
    target 1951
    kind "summarizes"
  ]
  edge [
    source 1625
    target 1626
    kind "mentions"
  ]
  edge [
    source 1625
    target 1627
    kind "mentions"
  ]
  edge [
    source 1625
    target 1938
    kind "summarizes"
  ]
  edge [
    source 1628
    target 1629
    kind "mentions"
  ]
  edge [
    source 1628
    target 1630
    kind "mentions"
  ]
  edge [
    source 1628
    target 1942
    kind "summarizes"
  ]
  edge [
    source 1631
    target 1632
    kind "from_chunk"
  ]
  edge [
    source 1631
    target 1634
    kind "from_chunk"
  ]
  edge [
    source 1631
    target 1636
    kind "from_chunk"
  ]
  edge [
    source 1631
    target 1637
    kind "from_chunk"
  ]
  edge [
    source 1631
    target 1640
    kind "from_chunk"
  ]
  edge [
    source 1632
    target 1633
    kind "mentions"
  ]
  edge [
    source 1632
    target 1950
    kind "summarizes"
  ]
  edge [
    source 1634
    target 1635
    kind "mentions"
  ]
  edge [
    source 1634
    target 1951
    kind "summarizes"
  ]
  edge [
    source 1636
    target 1951
    kind "summarizes"
  ]
  edge [
    source 1637
    target 1638
    kind "mentions"
  ]
  edge [
    source 1637
    target 1639
    kind "mentions"
  ]
  edge [
    source 1637
    target 1951
    kind "summarizes"
  ]
  edge [
    source 1640
    target 1641
    kind "mentions"
  ]
  edge [
    source 1640
    target 1951
    kind "summarizes"
  ]
  edge [
    source 1642
    target 1643
    kind "from_chunk"
  ]
  edge [
    source 1642
    target 1648
    kind "from_chunk"
  ]
  edge [
    source 1642
    target 1650
    kind "from_chunk"
  ]
  edge [
    source 1642
    target 1653
    kind "from_chunk"
  ]
  edge [
    source 1642
    target 1660
    kind "from_chunk"
  ]
  edge [
    source 1643
    target 1644
    kind "mentions"
  ]
  edge [
    source 1643
    target 1645
    kind "mentions"
  ]
  edge [
    source 1643
    target 1646
    kind "mentions"
  ]
  edge [
    source 1643
    target 1647
    kind "mentions"
  ]
  edge [
    source 1643
    target 1955
    kind "summarizes"
  ]
  edge [
    source 1644
    target 1647
    kind "relation"
    relation "uses large pupils to gather light"
    weight 1
  ]
  edge [
    source 1645
    target 1647
    kind "relation"
    relation "are large in"
    weight 1
  ]
  edge [
    source 1645
    target 1648
    kind "mentions"
  ]
  edge [
    source 1645
    target 1649
    kind "relation"
    relation "opens into"
    weight 1
  ]
  edge [
    source 1645
    target 1660
    kind "mentions"
  ]
  edge [
    source 1647
    target 1648
    kind "mentions"
  ]
  edge [
    source 1647
    target 1649
    kind "relation"
    relation "cannot bear too much light"
    weight 1
  ]
  edge [
    source 1647
    target 1681
    kind "mentions"
  ]
  edge [
    source 1648
    target 1649
    kind "mentions"
  ]
  edge [
    source 1648
    target 1955
    kind "summarizes"
  ]
  edge [
    source 1649
    target 1650
    kind "mentions"
  ]
  edge [
    source 1649
    target 1652
    kind "relation"
    relation "describes"
    weight 1
  ]
  edge [
    source 1649
    target 1653
    kind "mentions"
  ]
  edge [
    source 1649
    target 1659
    kind "relation"
    relation "needs great care"
    weight 1
  ]
  edge [
    source 1649
    target 1660
    kind "mentions"
  ]
  edge [
    source 1649
    target 1654
    kind "relation"
    relation "asks for pupil to be made small when | asks for eyelid curtains to be put down when"
    weight 2
  ]
  edge [
    source 1650
    target 1651
    kind "mentions"
  ]
  edge [
    source 1650
    target 1652
    kind "mentions"
  ]
  edge [
    source 1650
    target 1955
    kind "summarizes"
  ]
  edge [
    source 1653
    target 1654
    kind "mentions"
  ]
  edge [
    source 1653
    target 1655
    kind "mentions"
  ]
  edge [
    source 1653
    target 1656
    kind "mentions"
  ]
  edge [
    source 1653
    target 1657
    kind "mentions"
  ]
  edge [
    source 1653
    target 1658
    kind "mentions"
  ]
  edge [
    source 1653
    target 1659
    kind "mentions"
  ]
  edge [
    source 1653
    target 1955
    kind "summarizes"
  ]
  edge [
    source 1654
    target 1655
    kind "relation"
    relation "should not involve"
    weight 1
  ]
  edge [
    source 1654
    target 1660
    kind "mentions"
  ]
  edge [
    source 1654
    target 1724
    kind "mentions"
  ]
  edge [
    source 1654
    target 1725
    kind "relation"
    relation "becomes smaller in"
    weight 1
  ]
  edge [
    source 1655
    target 1681
    kind "mentions"
  ]
  edge [
    source 1655
    target 1724
    kind "mentions"
  ]
  edge [
    source 1655
    target 1729
    kind "relation"
    relation "should be directly in front of"
    weight 1
  ]
  edge [
    source 1656
    target 1724
    kind "mentions"
  ]
  edge [
    source 1656
    target 1729
    kind "relation"
    relation "should be directly in front of"
    weight 1
  ]
  edge [
    source 1660
    target 1661
    kind "mentions"
  ]
  edge [
    source 1660
    target 1955
    kind "summarizes"
  ]
  edge [
    source 1661
    target 1663
    kind "mentions"
  ]
  edge [
    source 1662
    target 1663
    kind "from_chunk"
  ]
  edge [
    source 1662
    target 1676
    kind "from_chunk"
  ]
  edge [
    source 1662
    target 1681
    kind "from_chunk"
  ]
  edge [
    source 1663
    target 1664
    kind "mentions"
  ]
  edge [
    source 1663
    target 1665
    kind "mentions"
  ]
  edge [
    source 1663
    target 1666
    kind "mentions"
  ]
  edge [
    source 1663
    target 1667
    kind "mentions"
  ]
  edge [
    source 1663
    target 1668
    kind "mentions"
  ]
  edge [
    source 1663
    target 1669
    kind "mentions"
  ]
  edge [
    source 1663
    target 1670
    kind "mentions"
  ]
  edge [
    source 1663
    target 1671
    kind "mentions"
  ]
  edge [
    source 1663
    target 1672
    kind "mentions"
  ]
  edge [
    source 1663
    target 1673
    kind "mentions"
  ]
  edge [
    source 1663
    target 1674
    kind "mentions"
  ]
  edge [
    source 1663
    target 1675
    kind "mentions"
  ]
  edge [
    source 1663
    target 1955
    kind "summarizes"
  ]
  edge [
    source 1664
    target 1665
    kind "relation"
    relation "told"
    weight 1
  ]
  edge [
    source 1665
    target 1672
    kind "relation"
    relation "refused to do"
    weight 1
  ]
  edge [
    source 1665
    target 1673
    kind "relation"
    relation "tried to see which could bear it the longest"
    weight 1
  ]
  edge [
    source 1666
    target 1669
    kind "relation"
    relation "felt"
    weight 1
  ]
  edge [
    source 1666
    target 1670
    kind "relation"
    relation "begged to have"
    weight 1
  ]
  edge [
    source 1666
    target 1671
    kind "relation"
    relation "begged to have"
    weight 1
  ]
  edge [
    source 1668
    target 1673
    kind "relation"
    relation "caused harm to"
    weight 1
  ]
  edge [
    source 1674
    target 1675
    kind "relation"
    relation "died from"
    weight 1
  ]
  edge [
    source 1676
    target 1677
    kind "mentions"
  ]
  edge [
    source 1676
    target 1678
    kind "mentions"
  ]
  edge [
    source 1676
    target 1679
    kind "mentions"
  ]
  edge [
    source 1676
    target 1680
    kind "mentions"
  ]
  edge [
    source 1676
    target 1955
    kind "summarizes"
  ]
  edge [
    source 1677
    target 1680
    kind "relation"
    relation "has had"
    weight 1
  ]
  edge [
    source 1681
    target 1682
    kind "mentions"
  ]
  edge [
    source 1681
    target 1683
    kind "mentions"
  ]
  edge [
    source 1681
    target 1684
    kind "mentions"
  ]
  edge [
    source 1681
    target 1685
    kind "mentions"
  ]
  edge [
    source 1681
    target 1686
    kind "mentions"
  ]
  edge [
    source 1681
    target 1687
    kind "mentions"
  ]
  edge [
    source 1681
    target 1955
    kind "summarizes"
  ]
  edge [
    source 1683
    target 1685
    kind "relation"
    relation "says"
    weight 1
  ]
  edge [
    source 1683
    target 1686
    kind "relation"
    relation "is hurt by"
    weight 1
  ]
  edge [
    source 1686
    target 1687
    kind "relation"
    relation "occurs when"
    weight 1
  ]
  edge [
    source 1688
    target 1689
    kind "from_chunk"
  ]
  edge [
    source 1688
    target 1703
    kind "from_chunk"
  ]
  edge [
    source 1689
    target 1690
    kind "mentions"
  ]
  edge [
    source 1689
    target 1691
    kind "mentions"
  ]
  edge [
    source 1689
    target 1692
    kind "mentions"
  ]
  edge [
    source 1689
    target 1693
    kind "mentions"
  ]
  edge [
    source 1689
    target 1694
    kind "mentions"
  ]
  edge [
    source 1689
    target 1695
    kind "mentions"
  ]
  edge [
    source 1689
    target 1696
    kind "mentions"
  ]
  edge [
    source 1689
    target 1697
    kind "mentions"
  ]
  edge [
    source 1689
    target 1698
    kind "mentions"
  ]
  edge [
    source 1689
    target 1699
    kind "mentions"
  ]
  edge [
    source 1689
    target 1700
    kind "mentions"
  ]
  edge [
    source 1689
    target 1701
    kind "mentions"
  ]
  edge [
    source 1689
    target 1702
    kind "mentions"
  ]
  edge [
    source 1689
    target 1946
    kind "summarizes"
  ]
  edge [
    source 1690
    target 1699
    kind "relation"
    relation "if killed, prevent regrowth of nerves"
    weight 1
  ]
  edge [
    source 1691
    target 1702
    kind "relation"
    relation "should not be inserted into"
    weight 1
  ]
  edge [
    source 1692
    target 1693
    kind "relation"
    relation "are passed along to"
    weight 1
  ]
  edge [
    source 1693
    target 1700
    kind "relation"
    relation "are deeper in the head"
    weight 1
  ]
  edge [
    source 1693
    target 1694
    kind "relation"
    relation "contain"
    weight 1
  ]
  edge [
    source 1693
    target 1741
    kind "mentions"
  ]
  edge [
    source 1693
    target 1720
    kind "relation"
    relation "are the internal structures for"
    weight 1
  ]
  edge [
    source 1697
    target 1701
    kind "relation"
    relation "should use only"
    weight 1
  ]
  edge [
    source 1703
    target 1704
    kind "mentions"
  ]
  edge [
    source 1703
    target 1705
    kind "mentions"
  ]
  edge [
    source 1703
    target 1706
    kind "mentions"
  ]
  edge [
    source 1703
    target 1707
    kind "mentions"
  ]
  edge [
    source 1703
    target 1708
    kind "mentions"
  ]
  edge [
    source 1703
    target 1709
    kind "mentions"
  ]
  edge [
    source 1703
    target 1710
    kind "mentions"
  ]
  edge [
    source 1703
    target 1711
    kind "mentions"
  ]
  edge [
    source 1703
    target 1712
    kind "mentions"
  ]
  edge [
    source 1703
    target 1713
    kind "mentions"
  ]
  edge [
    source 1703
    target 1714
    kind "mentions"
  ]
  edge [
    source 1703
    target 1946
    kind "summarizes"
  ]
  edge [
    source 1704
    target 1705
    kind "relation"
    relation "was a small boy"
    weight 1
  ]
  edge [
    source 1704
    target 1707
    kind "relation"
    relation "laid his ear to"
    weight 1
  ]
  edge [
    source 1704
    target 1708
    kind "relation"
    relation "felt"
    weight 1
  ]
  edge [
    source 1704
    target 1713
    kind "relation"
    relation "did not know it was wrong"
    weight 1
  ]
  edge [
    source 1704
    target 1714
    kind "relation"
    relation "developed"
    weight 1
  ]
  edge [
    source 1704
    target 1710
    kind "relation"
    relation "often had"
    weight 1
  ]
  edge [
    source 1709
    target 1713
    kind "relation"
    relation "followed"
    weight 1
  ]
  edge [
    source 1710
    target 1712
    kind "relation"
    relation "began when"
    weight 1
  ]
  edge [
    source 1715
    target 1716
    kind "from_chunk"
  ]
  edge [
    source 1715
    target 1724
    kind "from_chunk"
  ]
  edge [
    source 1716
    target 1717
    kind "mentions"
  ]
  edge [
    source 1716
    target 1718
    kind "mentions"
  ]
  edge [
    source 1716
    target 1719
    kind "mentions"
  ]
  edge [
    source 1716
    target 1720
    kind "mentions"
  ]
  edge [
    source 1716
    target 1721
    kind "mentions"
  ]
  edge [
    source 1716
    target 1722
    kind "mentions"
  ]
  edge [
    source 1716
    target 1723
    kind "mentions"
  ]
  edge [
    source 1716
    target 1942
    kind "summarizes"
  ]
  edge [
    source 1717
    target 1724
    kind "mentions"
  ]
  edge [
    source 1717
    target 1718
    kind "relation"
    relation "include"
    weight 1
  ]
  edge [
    source 1717
    target 1719
    kind "relation"
    relation "include"
    weight 1
  ]
  edge [
    source 1717
    target 1720
    kind "relation"
    relation "include"
    weight 1
  ]
  edge [
    source 1718
    target 1724
    kind "mentions"
  ]
  edge [
    source 1719
    target 1724
    kind "mentions"
  ]
  edge [
    source 1720
    target 1724
    kind "mentions"
  ]
  edge [
    source 1720
    target 1741
    kind "mentions"
  ]
  edge [
    source 1724
    target 1725
    kind "mentions"
  ]
  edge [
    source 1724
    target 1726
    kind "mentions"
  ]
  edge [
    source 1724
    target 1727
    kind "mentions"
  ]
  edge [
    source 1724
    target 1728
    kind "mentions"
  ]
  edge [
    source 1724
    target 1729
    kind "mentions"
  ]
  edge [
    source 1724
    target 1730
    kind "mentions"
  ]
  edge [
    source 1724
    target 1731
    kind "mentions"
  ]
  edge [
    source 1724
    target 1732
    kind "mentions"
  ]
  edge [
    source 1724
    target 1733
    kind "mentions"
  ]
  edge [
    source 1724
    target 1734
    kind "mentions"
  ]
  edge [
    source 1724
    target 1735
    kind "mentions"
  ]
  edge [
    source 1724
    target 1955
    kind "summarizes"
  ]
  edge [
    source 1725
    target 1726
    kind "relation"
    relation "becomes larger in"
    weight 1
  ]
  edge [
    source 1727
    target 1734
    kind "relation"
    relation "can adjust to low light"
    weight 1
  ]
  edge [
    source 1730
    target 1735
    kind "relation"
    relation "experienced eye damage from"
    weight 1
  ]
  edge [
    source 1731
    target 1732
    kind "relation"
    relation "intentionally caused eyes to misalign"
    weight 1
  ]
  edge [
    source 1736
    target 1737
    kind "from_chunk"
  ]
  edge [
    source 1736
    target 1741
    kind "from_chunk"
  ]
  edge [
    source 1736
    target 1742
    kind "from_chunk"
  ]
  edge [
    source 1736
    target 1747
    kind "from_chunk"
  ]
  edge [
    source 1736
    target 1751
    kind "from_chunk"
  ]
  edge [
    source 1736
    target 1756
    kind "from_chunk"
  ]
  edge [
    source 1736
    target 1769
    kind "from_chunk"
  ]
  edge [
    source 1737
    target 1738
    kind "mentions"
  ]
  edge [
    source 1737
    target 1739
    kind "mentions"
  ]
  edge [
    source 1737
    target 1740
    kind "mentions"
  ]
  edge [
    source 1737
    target 1946
    kind "summarizes"
  ]
  edge [
    source 1738
    target 1740
    kind "relation"
    relation "when killed leads to"
    weight 1
  ]
  edge [
    source 1741
    target 1946
    kind "summarizes"
  ]
  edge [
    source 1742
    target 1743
    kind "mentions"
  ]
  edge [
    source 1742
    target 1744
    kind "mentions"
  ]
  edge [
    source 1742
    target 1745
    kind "mentions"
  ]
  edge [
    source 1742
    target 1746
    kind "mentions"
  ]
  edge [
    source 1742
    target 1946
    kind "summarizes"
  ]
  edge [
    source 1743
    target 1744
    kind "relation"
    relation "can be injured by"
    weight 1
  ]
  edge [
    source 1743
    target 1745
    kind "relation"
    relation "can be injured by"
    weight 1
  ]
  edge [
    source 1743
    target 1746
    kind "relation"
    relation "can be injured by"
    weight 1
  ]
  edge [
    source 1743
    target 1747
    kind "mentions"
  ]
  edge [
    source 1743
    target 1750
    kind "relation"
    relation "damaged"
    weight 1
  ]
  edge [
    source 1747
    target 1748
    kind "mentions"
  ]
  edge [
    source 1747
    target 1749
    kind "mentions"
  ]
  edge [
    source 1747
    target 1750
    kind "mentions"
  ]
  edge [
    source 1747
    target 1946
    kind "summarizes"
  ]
  edge [
    source 1748
    target 1749
    kind "relation"
    relation "injured"
    weight 1
  ]
  edge [
    source 1748
    target 1750
    kind "relation"
    relation "was exposed to"
    weight 1
  ]
  edge [
    source 1751
    target 1752
    kind "mentions"
  ]
  edge [
    source 1751
    target 1753
    kind "mentions"
  ]
  edge [
    source 1751
    target 1754
    kind "mentions"
  ]
  edge [
    source 1751
    target 1755
    kind "mentions"
  ]
  edge [
    source 1751
    target 1946
    kind "summarizes"
  ]
  edge [
    source 1752
    target 1753
    kind "relation"
    relation "impairs"
    weight 1
  ]
  edge [
    source 1752
    target 1754
    kind "relation"
    relation "reduces"
    weight 1
  ]
  edge [
    source 1752
    target 1755
    kind "relation"
    relation "causes"
    weight 1
  ]
  edge [
    source 1756
    target 1757
    kind "mentions"
  ]
  edge [
    source 1756
    target 1758
    kind "mentions"
  ]
  edge [
    source 1756
    target 1759
    kind "mentions"
  ]
  edge [
    source 1756
    target 1760
    kind "mentions"
  ]
  edge [
    source 1756
    target 1761
    kind "mentions"
  ]
  edge [
    source 1756
    target 1762
    kind "mentions"
  ]
  edge [
    source 1756
    target 1763
    kind "mentions"
  ]
  edge [
    source 1756
    target 1764
    kind "mentions"
  ]
  edge [
    source 1756
    target 1765
    kind "mentions"
  ]
  edge [
    source 1756
    target 1766
    kind "mentions"
  ]
  edge [
    source 1756
    target 1767
    kind "mentions"
  ]
  edge [
    source 1756
    target 1768
    kind "mentions"
  ]
  edge [
    source 1756
    target 1954
    kind "summarizes"
  ]
  edge [
    source 1758
    target 1760
    kind "relation"
    relation "increases"
    weight 1
  ]
  edge [
    source 1758
    target 1772
    kind "mentions"
  ]
  edge [
    source 1758
    target 1795
    kind "mentions"
  ]
  edge [
    source 1759
    target 1766
    kind "relation"
    relation "claps hands and swings arms to"
    weight 1
  ]
  edge [
    source 1761
    target 1767
    kind "relation"
    relation "shows same temperature as"
    weight 1
  ]
  edge [
    source 1763
    target 1813
    kind "mentions"
  ]
  edge [
    source 1765
    target 1768
    kind "relation"
    relation "results in"
    weight 1
  ]
  edge [
    source 1769
    target 1770
    kind "mentions"
  ]
  edge [
    source 1769
    target 1948
    kind "summarizes"
  ]
  edge [
    source 1771
    target 1772
    kind "from_chunk"
  ]
  edge [
    source 1771
    target 1774
    kind "from_chunk"
  ]
  edge [
    source 1771
    target 1779
    kind "from_chunk"
  ]
  edge [
    source 1771
    target 1786
    kind "from_chunk"
  ]
  edge [
    source 1772
    target 1773
    kind "mentions"
  ]
  edge [
    source 1772
    target 1948
    kind "summarizes"
  ]
  edge [
    source 1774
    target 1775
    kind "mentions"
  ]
  edge [
    source 1774
    target 1776
    kind "mentions"
  ]
  edge [
    source 1774
    target 1777
    kind "mentions"
  ]
  edge [
    source 1774
    target 1778
    kind "mentions"
  ]
  edge [
    source 1774
    target 1950
    kind "summarizes"
  ]
  edge [
    source 1777
    target 1778
    kind "relation"
    relation "contributes to"
    weight 1
  ]
  edge [
    source 1779
    target 1780
    kind "mentions"
  ]
  edge [
    source 1779
    target 1781
    kind "mentions"
  ]
  edge [
    source 1779
    target 1782
    kind "mentions"
  ]
  edge [
    source 1779
    target 1783
    kind "mentions"
  ]
  edge [
    source 1779
    target 1784
    kind "mentions"
  ]
  edge [
    source 1779
    target 1785
    kind "mentions"
  ]
  edge [
    source 1779
    target 1948
    kind "summarizes"
  ]
  edge [
    source 1780
    target 1867
    kind "mentions"
  ]
  edge [
    source 1781
    target 1786
    kind "mentions"
  ]
  edge [
    source 1781
    target 1819
    kind "mentions"
  ]
  edge [
    source 1784
    target 1785
    kind "relation"
    relation "feels warmer than"
    weight 1
  ]
  edge [
    source 1786
    target 1787
    kind "mentions"
  ]
  edge [
    source 1786
    target 1788
    kind "mentions"
  ]
  edge [
    source 1786
    target 1789
    kind "mentions"
  ]
  edge [
    source 1786
    target 1790
    kind "mentions"
  ]
  edge [
    source 1786
    target 1791
    kind "mentions"
  ]
  edge [
    source 1786
    target 1792
    kind "mentions"
  ]
  edge [
    source 1786
    target 1793
    kind "mentions"
  ]
  edge [
    source 1786
    target 1948
    kind "summarizes"
  ]
  edge [
    source 1787
    target 1788
    kind "relation"
    relation "retains"
    weight 1
  ]
  edge [
    source 1787
    target 1792
    kind "relation"
    relation "prevents"
    weight 1
  ]
  edge [
    source 1787
    target 1819
    kind "mentions"
  ]
  edge [
    source 1794
    target 1795
    kind "from_chunk"
  ]
  edge [
    source 1794
    target 1808
    kind "from_chunk"
  ]
  edge [
    source 1794
    target 1813
    kind "from_chunk"
  ]
  edge [
    source 1795
    target 1796
    kind "mentions"
  ]
  edge [
    source 1795
    target 1797
    kind "mentions"
  ]
  edge [
    source 1795
    target 1798
    kind "mentions"
  ]
  edge [
    source 1795
    target 1799
    kind "mentions"
  ]
  edge [
    source 1795
    target 1800
    kind "mentions"
  ]
  edge [
    source 1795
    target 1801
    kind "mentions"
  ]
  edge [
    source 1795
    target 1802
    kind "mentions"
  ]
  edge [
    source 1795
    target 1803
    kind "mentions"
  ]
  edge [
    source 1795
    target 1804
    kind "mentions"
  ]
  edge [
    source 1795
    target 1805
    kind "mentions"
  ]
  edge [
    source 1795
    target 1806
    kind "mentions"
  ]
  edge [
    source 1795
    target 1807
    kind "mentions"
  ]
  edge [
    source 1795
    target 1954
    kind "summarizes"
  ]
  edge [
    source 1796
    target 1798
    kind "relation"
    relation "are unsafe for"
    weight 1
  ]
  edge [
    source 1796
    target 1805
    kind "relation"
    relation "may look"
    weight 1
  ]
  edge [
    source 1797
    target 1798
    kind "relation"
    relation "are unsafe for"
    weight 1
  ]
  edge [
    source 1800
    target 1806
    kind "relation"
    relation "is pleasanter to look at than"
    weight 1
  ]
  edge [
    source 1808
    target 1809
    kind "mentions"
  ]
  edge [
    source 1808
    target 1810
    kind "mentions"
  ]
  edge [
    source 1808
    target 1811
    kind "mentions"
  ]
  edge [
    source 1808
    target 1812
    kind "mentions"
  ]
  edge [
    source 1808
    target 1950
    kind "summarizes"
  ]
  edge [
    source 1813
    target 1814
    kind "mentions"
  ]
  edge [
    source 1813
    target 1815
    kind "mentions"
  ]
  edge [
    source 1813
    target 1816
    kind "mentions"
  ]
  edge [
    source 1813
    target 1817
    kind "mentions"
  ]
  edge [
    source 1813
    target 1949
    kind "summarizes"
  ]
  edge [
    source 1814
    target 1815
    kind "relation"
    relation "causes"
    weight 1
  ]
  edge [
    source 1814
    target 1816
    kind "relation"
    relation "leads to"
    weight 1
  ]
  edge [
    source 1818
    target 1819
    kind "from_chunk"
  ]
  edge [
    source 1818
    target 1841
    kind "from_chunk"
  ]
  edge [
    source 1819
    target 1820
    kind "mentions"
  ]
  edge [
    source 1819
    target 1821
    kind "mentions"
  ]
  edge [
    source 1819
    target 1822
    kind "mentions"
  ]
  edge [
    source 1819
    target 1823
    kind "mentions"
  ]
  edge [
    source 1819
    target 1824
    kind "mentions"
  ]
  edge [
    source 1819
    target 1825
    kind "mentions"
  ]
  edge [
    source 1819
    target 1826
    kind "mentions"
  ]
  edge [
    source 1819
    target 1827
    kind "mentions"
  ]
  edge [
    source 1819
    target 1828
    kind "mentions"
  ]
  edge [
    source 1819
    target 1829
    kind "mentions"
  ]
  edge [
    source 1819
    target 1830
    kind "mentions"
  ]
  edge [
    source 1819
    target 1831
    kind "mentions"
  ]
  edge [
    source 1819
    target 1832
    kind "mentions"
  ]
  edge [
    source 1819
    target 1833
    kind "mentions"
  ]
  edge [
    source 1819
    target 1834
    kind "mentions"
  ]
  edge [
    source 1819
    target 1835
    kind "mentions"
  ]
  edge [
    source 1819
    target 1836
    kind "mentions"
  ]
  edge [
    source 1819
    target 1837
    kind "mentions"
  ]
  edge [
    source 1819
    target 1838
    kind "mentions"
  ]
  edge [
    source 1819
    target 1839
    kind "mentions"
  ]
  edge [
    source 1819
    target 1840
    kind "mentions"
  ]
  edge [
    source 1819
    target 1948
    kind "summarizes"
  ]
  edge [
    source 1822
    target 1836
    kind "relation"
    relation "can freeze"
    weight 1
  ]
  edge [
    source 1822
    target 1847
    kind "mentions"
  ]
  edge [
    source 1826
    target 1838
    kind "relation"
    relation "have a hard time on"
    weight 1
  ]
  edge [
    source 1827
    target 1838
    kind "relation"
    relation "have a hard time on"
    weight 1
  ]
  edge [
    source 1828
    target 1840
    kind "relation"
    relation "are interested in stories about"
    weight 1
  ]
  edge [
    source 1828
    target 1830
    kind "relation"
    relation "have ships that get frozen into"
    weight 2
  ]
  edge [
    source 1828
    target 1832
    kind "relation"
    relation "travel on sledges drawn by"
    weight 1
  ]
  edge [
    source 1828
    target 1833
    kind "relation"
    relation "sometimes live in | live in"
    weight 2
  ]
  edge [
    source 1828
    target 1834
    kind "relation"
    relation "eat"
    weight 2
  ]
  edge [
    source 1828
    target 1841
    kind "mentions"
  ]
  edge [
    source 1828
    target 1831
    kind "relation"
    relation "travel on"
    weight 1
  ]
  edge [
    source 1830
    target 1841
    kind "mentions"
  ]
  edge [
    source 1831
    target 1841
    kind "mentions"
  ]
  edge [
    source 1831
    target 1832
    kind "relation"
    relation "are drawn by"
    weight 1
  ]
  edge [
    source 1832
    target 1841
    kind "mentions"
  ]
  edge [
    source 1833
    target 1841
    kind "mentions"
  ]
  edge [
    source 1834
    target 1841
    kind "mentions"
  ]
  edge [
    source 1836
    target 1837
    kind "relation"
    relation "would have frozen much quicker"
    weight 1
  ]
  edge [
    source 1841
    target 1948
    kind "summarizes"
  ]
  edge [
    source 1842
    target 1843
    kind "from_chunk"
  ]
  edge [
    source 1842
    target 1847
    kind "from_chunk"
  ]
  edge [
    source 1842
    target 1857
    kind "from_chunk"
  ]
  edge [
    source 1842
    target 1863
    kind "from_chunk"
  ]
  edge [
    source 1843
    target 1844
    kind "mentions"
  ]
  edge [
    source 1843
    target 1845
    kind "mentions"
  ]
  edge [
    source 1843
    target 1846
    kind "mentions"
  ]
  edge [
    source 1843
    target 1954
    kind "summarizes"
  ]
  edge [
    source 1844
    target 1846
    kind "relation"
    relation "are located in"
    weight 1
  ]
  edge [
    source 1847
    target 1848
    kind "mentions"
  ]
  edge [
    source 1847
    target 1849
    kind "mentions"
  ]
  edge [
    source 1847
    target 1850
    kind "mentions"
  ]
  edge [
    source 1847
    target 1851
    kind "mentions"
  ]
  edge [
    source 1847
    target 1852
    kind "mentions"
  ]
  edge [
    source 1847
    target 1853
    kind "mentions"
  ]
  edge [
    source 1847
    target 1854
    kind "mentions"
  ]
  edge [
    source 1847
    target 1855
    kind "mentions"
  ]
  edge [
    source 1847
    target 1856
    kind "mentions"
  ]
  edge [
    source 1847
    target 1948
    kind "summarizes"
  ]
  edge [
    source 1848
    target 1849
    kind "relation"
    relation "consisted of"
    weight 1
  ]
  edge [
    source 1848
    target 1850
    kind "relation"
    relation "was rescued from"
    weight 1
  ]
  edge [
    source 1848
    target 1856
    kind "relation"
    relation "endured"
    weight 1
  ]
  edge [
    source 1848
    target 1853
    kind "relation"
    relation "resulted in"
    weight 1
  ]
  edge [
    source 1848
    target 1854
    kind "relation"
    relation "had"
    weight 1
  ]
  edge [
    source 1848
    target 1863
    kind "mentions"
  ]
  edge [
    source 1850
    target 1867
    kind "mentions"
  ]
  edge [
    source 1854
    target 1855
    kind "relation"
    relation "included"
    weight 1
  ]
  edge [
    source 1857
    target 1858
    kind "mentions"
  ]
  edge [
    source 1857
    target 1859
    kind "mentions"
  ]
  edge [
    source 1857
    target 1860
    kind "mentions"
  ]
  edge [
    source 1857
    target 1861
    kind "mentions"
  ]
  edge [
    source 1857
    target 1862
    kind "mentions"
  ]
  edge [
    source 1857
    target 1943
    kind "summarizes"
  ]
  edge [
    source 1860
    target 1861
    kind "relation"
    relation "included"
    weight 1
  ]
  edge [
    source 1860
    target 1862
    kind "relation"
    relation "included"
    weight 1
  ]
  edge [
    source 1863
    target 1864
    kind "mentions"
  ]
  edge [
    source 1863
    target 1865
    kind "mentions"
  ]
  edge [
    source 1863
    target 1948
    kind "summarizes"
  ]
  edge [
    source 1864
    target 1865
    kind "relation"
    relation "prevented effective use of"
    weight 1
  ]
  edge [
    source 1866
    target 1867
    kind "from_chunk"
  ]
  edge [
    source 1866
    target 1874
    kind "from_chunk"
  ]
  edge [
    source 1867
    target 1868
    kind "mentions"
  ]
  edge [
    source 1867
    target 1869
    kind "mentions"
  ]
  edge [
    source 1867
    target 1870
    kind "mentions"
  ]
  edge [
    source 1867
    target 1871
    kind "mentions"
  ]
  edge [
    source 1867
    target 1872
    kind "mentions"
  ]
  edge [
    source 1867
    target 1873
    kind "mentions"
  ]
  edge [
    source 1867
    target 1948
    kind "summarizes"
  ]
  edge [
    source 1871
    target 1873
    kind "relation"
    relation "went with"
    weight 1
  ]
  edge [
    source 1874
    target 1875
    kind "mentions"
  ]
  edge [
    source 1874
    target 1876
    kind "mentions"
  ]
  edge [
    source 1874
    target 1877
    kind "mentions"
  ]
  edge [
    source 1874
    target 1878
    kind "mentions"
  ]
  edge [
    source 1874
    target 1879
    kind "mentions"
  ]
  edge [
    source 1874
    target 1880
    kind "mentions"
  ]
  edge [
    source 1874
    target 1881
    kind "mentions"
  ]
  edge [
    source 1874
    target 1882
    kind "mentions"
  ]
  edge [
    source 1874
    target 1883
    kind "mentions"
  ]
  edge [
    source 1874
    target 1884
    kind "mentions"
  ]
  edge [
    source 1874
    target 1885
    kind "mentions"
  ]
  edge [
    source 1874
    target 1886
    kind "mentions"
  ]
  edge [
    source 1874
    target 1887
    kind "mentions"
  ]
  edge [
    source 1874
    target 1888
    kind "mentions"
  ]
  edge [
    source 1874
    target 1889
    kind "mentions"
  ]
  edge [
    source 1874
    target 1949
    kind "summarizes"
  ]
  edge [
    source 1876
    target 1886
    kind "relation"
    relation "takes ten weeks to save"
    weight 1
  ]
  edge [
    source 1876
    target 1891
    kind "mentions"
  ]
  edge [
    source 1876
    target 1904
    kind "relation"
    relation "will be wasted in"
    weight 1
  ]
  edge [
    source 1876
    target 1906
    kind "relation"
    relation "would be wasted if"
    weight 1
  ]
  edge [
    source 1876
    target 1901
    kind "relation"
    relation "hurts the person holding it"
    weight 1
  ]
  edge [
    source 1876
    target 1907
    kind "mentions"
  ]
  edge [
    source 1880
    target 1887
    kind "relation"
    relation "consumes"
    weight 1
  ]
  edge [
    source 1880
    target 1888
    kind "relation"
    relation "spends a dollar in"
    weight 1
  ]
  edge [
    source 1882
    target 1889
    kind "relation"
    relation "should not use word"
    weight 1
  ]
  edge [
    source 1883
    target 1884
    kind "relation"
    relation "is wasted"
    weight 1
  ]
  edge [
    source 1885
    target 1886
    kind "relation"
    relation "saves"
    weight 1
  ]
  edge [
    source 1890
    target 1891
    kind "from_chunk"
  ]
  edge [
    source 1890
    target 1907
    kind "from_chunk"
  ]
  edge [
    source 1891
    target 1892
    kind "mentions"
  ]
  edge [
    source 1891
    target 1893
    kind "mentions"
  ]
  edge [
    source 1891
    target 1894
    kind "mentions"
  ]
  edge [
    source 1891
    target 1895
    kind "mentions"
  ]
  edge [
    source 1891
    target 1896
    kind "mentions"
  ]
  edge [
    source 1891
    target 1897
    kind "mentions"
  ]
  edge [
    source 1891
    target 1898
    kind "mentions"
  ]
  edge [
    source 1891
    target 1899
    kind "mentions"
  ]
  edge [
    source 1891
    target 1900
    kind "mentions"
  ]
  edge [
    source 1891
    target 1901
    kind "mentions"
  ]
  edge [
    source 1891
    target 1902
    kind "mentions"
  ]
  edge [
    source 1891
    target 1903
    kind "mentions"
  ]
  edge [
    source 1891
    target 1904
    kind "mentions"
  ]
  edge [
    source 1891
    target 1905
    kind "mentions"
  ]
  edge [
    source 1891
    target 1906
    kind "mentions"
  ]
  edge [
    source 1891
    target 1949
    kind "summarizes"
  ]
  edge [
    source 1892
    target 1893
    kind "relation"
    relation "leads to"
    weight 1
  ]
  edge [
    source 1892
    target 1894
    kind "relation"
    relation "leads to"
    weight 1
  ]
  edge [
    source 1892
    target 1895
    kind "relation"
    relation "leads to"
    weight 1
  ]
  edge [
    source 1892
    target 1896
    kind "relation"
    relation "leads to"
    weight 1
  ]
  edge [
    source 1892
    target 1897
    kind "relation"
    relation "reduces need for"
    weight 1
  ]
  edge [
    source 1892
    target 1898
    kind "relation"
    relation "reduces need for"
    weight 1
  ]
  edge [
    source 1892
    target 1899
    kind "relation"
    relation "reduces need for"
    weight 1
  ]
  edge [
    source 1892
    target 1905
    kind "relation"
    relation "absent leads to"
    weight 1
  ]
  edge [
    source 1900
    target 1907
    kind "mentions"
  ]
  edge [
    source 1901
    target 1907
    kind "mentions"
  ]
  edge [
    source 1902
    target 1907
    kind "mentions"
  ]
  edge [
    source 1903
    target 1907
    kind "mentions"
  ]
  edge [
    source 1903
    target 1910
    kind "relation"
    relation "is proposed as a challenge"
    weight 1
  ]
  edge [
    source 1903
    target 1912
    kind "mentions"
  ]
  edge [
    source 1907
    target 1908
    kind "mentions"
  ]
  edge [
    source 1907
    target 1909
    kind "mentions"
  ]
  edge [
    source 1907
    target 1910
    kind "mentions"
  ]
  edge [
    source 1907
    target 1949
    kind "summarizes"
  ]
  edge [
    source 1908
    target 1909
    kind "relation"
    relation "is compared to"
    weight 1
  ]
  edge [
    source 1911
    target 1912
    kind "from_chunk"
  ]
  edge [
    source 1911
    target 1920
    kind "from_chunk"
  ]
  edge [
    source 1911
    target 1922
    kind "from_chunk"
  ]
  edge [
    source 1912
    target 1913
    kind "mentions"
  ]
  edge [
    source 1912
    target 1914
    kind "mentions"
  ]
  edge [
    source 1912
    target 1915
    kind "mentions"
  ]
  edge [
    source 1912
    target 1916
    kind "mentions"
  ]
  edge [
    source 1912
    target 1917
    kind "mentions"
  ]
  edge [
    source 1912
    target 1918
    kind "mentions"
  ]
  edge [
    source 1912
    target 1919
    kind "mentions"
  ]
  edge [
    source 1912
    target 1949
    kind "summarizes"
  ]
  edge [
    source 1915
    target 1916
    kind "relation"
    relation "are spent"
    weight 1
  ]
  edge [
    source 1916
    target 1922
    kind "mentions"
  ]
  edge [
    source 1920
    target 1921
    kind "mentions"
  ]
  edge [
    source 1920
    target 1939
    kind "summarizes"
  ]
  edge [
    source 1922
    target 1923
    kind "mentions"
  ]
  edge [
    source 1922
    target 1924
    kind "mentions"
  ]
  edge [
    source 1922
    target 1925
    kind "mentions"
  ]
  edge [
    source 1922
    target 1926
    kind "mentions"
  ]
  edge [
    source 1922
    target 1927
    kind "mentions"
  ]
  edge [
    source 1922
    target 1928
    kind "mentions"
  ]
  edge [
    source 1922
    target 1929
    kind "mentions"
  ]
  edge [
    source 1922
    target 1930
    kind "mentions"
  ]
  edge [
    source 1922
    target 1931
    kind "mentions"
  ]
  edge [
    source 1922
    target 1932
    kind "mentions"
  ]
  edge [
    source 1922
    target 1933
    kind "mentions"
  ]
  edge [
    source 1922
    target 1934
    kind "mentions"
  ]
  edge [
    source 1922
    target 1935
    kind "mentions"
  ]
  edge [
    source 1922
    target 1936
    kind "mentions"
  ]
  edge [
    source 1922
    target 1937
    kind "mentions"
  ]
  edge [
    source 1922
    target 1941
    kind "summarizes"
  ]
]
